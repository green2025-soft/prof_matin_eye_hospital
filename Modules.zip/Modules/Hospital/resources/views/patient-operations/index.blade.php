@extends('core::layouts.app')

@section('title', $pageTitle)

@section('content')
    @include('core::partials.heading', [
        'title' => $pageTitle,
        'description' => '',
        'create' => ['model' => resourceModel($routePrefix.'.create'), 'url' => route($routePrefix.'.create'), 'label' => 'Operation Bill'],
    ])

    <section class="app-card overflow-hidden">

        <form class="px-3 px-md-4 py-3 border-bottom" action="{{ route($routePrefix.'.index') }}" method="GET" aria-label="Filter patient operations">
            <div class="row g-2 align-items-end">
                <div class="col-md-6 col-xxl-3">
                    <label class="form-label small" for="search">Search Patient Operation</label>
                    <div class="app-input-wrap app-search-field">
                        <i class="fa-solid fa-magnifying-glass app-search-icon" aria-hidden="true"></i>
                        <input class="{{ inputClass('search') }}" id="search" name="search" type="search" value="{{ getValue('search', null, $filters['search'] ?? '') }}" maxlength="80" placeholder="Invoice, ID or entry date starts with..." {{ inputAttrs('search') }}>
                    </div>
                    @error('search')<div class="invalid-feedback d-block" id="search-error">{{ $message }}</div>@enderror
                </div>
                <div class="col-md-6 col-xxl-3">
                    <label class="form-label small" for="filter_doctor_id">Select Doctor</label>
                    <select class="{{ inputClass('filter_doctor_id', 'form-select') }}" id="filter_doctor_id" name="filter_doctor_id" data-ajax-select data-url="{{ route('hospital.doctors.options') }}" data-value-field="id" data-label-field="text" data-placeholder="All doctors" {{ inputAttrs('filter_doctor_id') }}>
                        <option value=""></option>
                        @if (($filterDoctor ?? null) !== null)
                            <option value="{{ $filterDoctor->id }}" selected>{{ $filterDoctor->doctor_id ?: $filterDoctor->id }} — {{ $filterDoctor->name }}</option>
                        @endif
                    </select>
                    @error('filter_doctor_id')<div class="invalid-feedback d-block" id="filter_doctor_id-error">{{ $message }}</div>@enderror
                </div>
                <div class="col-md-8 col-xxl-4">
                    <label class="form-label small" for="filter_patient_id">Patient</label>
                    <select class="{{ inputClass('filter_patient_id', 'form-select') }}" id="filter_patient_id" name="filter_patient_id"
                        data-ajax-select data-url="{{ route('hospital.patients.options') }}"
                        data-value-field="id" data-label-field="text" data-placeholder="All patients"
                        {{ inputAttrs('filter_patient_id') }}>
                        <option value=""></option>
                        @if (($filterPatient ?? null) !== null)
                            <option value="{{ $filterPatient->id }}" selected>{{ $filterPatient->patient_id }} — {{ $filterPatient->name }} — {{ $filterPatient->mobile_no }}</option>
                        @endif
                    </select>
                    @error('filter_patient_id')<div class="invalid-feedback d-block" id="filter_patient_id-error">{{ $message }}</div>@enderror
                </div>
                <div class="col-md-4 col-xxl-2">
                    @include('core::partials.filter-actions', ['routePrefix' => $routePrefix])
                </div>
            </div>
        </form>

        @if ($records->isEmpty())
            @include('core::partials.empty', ['title' => 'No patient operations found', 'description' => 'Try another entry ID or clear the filters.', 'icon' => 'file-invoice'])
        @else
            <div class="table-responsive">
                <table class="table app-table align-middle mb-0">
                    <caption class="visually-hidden">Patient operations with patient, Doctor, and payment details</caption>
                    <thead>
                        <tr>
                            <th scope="col">Date</th>
                            <th scope="col">Invoice</th>
                            <th scope="col">Patient</th>
                            <th scope="col">Doctor</th>
                            <th class="text-end" scope="col">Amount</th>
                            <th class="text-end" scope="col">Discount</th>
                            <th class="text-end" scope="col">Current payable</th>
                            <th class="text-end" scope="col">Current paid</th>
                            <th class="text-end" scope="col">Current due</th>
                            <th class="text-end" scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($records as $patient_operation)
                            <tr>
                                <td class="small text-nowrap">

                                    {{ $patient_operation->entry_date?->format('d M Y') }}
                                    <div class="small text-body-secondary">Operation {{ $patient_operation->operation_date?->format('d M Y') }}</div>

                                </td>
                                <td>{{ $patient_operation->invoice_no }}</td>
                                <td >
                                    <div>{{ $patient_operation->patient?->patient_id }}</div>
                                    <div >{{ $patient_operation->patient?->name }}</div>
                                </td>
                                <td class="small text-break">{{ $patient_operation->doctor?->name }}</td>
                                <td class="text-end text-nowrap">{{ $patient_operation->amount }}</td>
                                <td class="text-end text-nowrap">{{ $patient_operation->discount_amount }}</td>
                                <td class="text-end text-nowrap">{{ $invoiceBalances[$patient_operation->id]['remaining_amount'] }}</td>
                                <td class="text-end text-nowrap">
                                    {{ $invoiceBalances[$patient_operation->id]['remaining_paid'] }}
                                    <div class="small text-body-secondary">{{ $patient_operation->paymentType?->name }}</div>
                                </td>
                                <td class="text-end text-nowrap">
                                    {{ $invoiceBalances[$patient_operation->id]['remaining_due'] }}

                                </td>
                                <td>
                                    <div class="d-flex justify-content-end gap-2 text-nowrap">
                                        @can('view', $patient_operation)
                                            <a class="btn btn-outline-primary btn-sm app-action-button" href="{{ route($routePrefix.'.show', $patient_operation) }}" aria-label="Print operation invoice #{{ $patient_operation->id }}" title="Print invoice"><i class="fa-solid fa-print" aria-hidden="true"></i></a>
                                        @endcan
                                        @can('update', $patient_operation)
                                            <a class="btn btn-outline-secondary btn-sm app-action-button" href="{{ route($routePrefix.'.edit', $patient_operation) }}" aria-label="Edit operation #{{ $patient_operation->id }}" title="Edit"><i class="fa-solid fa-pen-to-square" aria-hidden="true"></i></a>
                                        @endcan
                                        @can('delete', $patient_operation)
                                            <form class="d-inline-flex" action="{{ route($routePrefix.'.destroy', $patient_operation) }}" method="POST" data-confirm="Delete this operation? This cannot be undone.">
                                                @csrf
                                                @method('DELETE')
                                                <button class="btn btn-outline-danger btn-sm app-action-button" type="submit" aria-label="Delete operation #{{ $patient_operation->id }}" title="Delete"><i class="fa-solid fa-trash-can" aria-hidden="true"></i></button>
                                            </form>
                                        @endcan
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @endif

        @include('core::partials.pagination', ['paginator' => $records, 'filters' => $filters])
    </section>
@endsection
