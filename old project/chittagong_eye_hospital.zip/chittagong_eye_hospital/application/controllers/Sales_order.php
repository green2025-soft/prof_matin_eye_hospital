<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Sales_order extends CI_Controller
{

	static $library 	 = array('user_agent');
	static $model 	 = array('Common_model');
	static $helper 	 = array('utility');

	public function __construct()
	{
		parent::__construct();
		$this->load->model(self::$model);
		$this->load->library(self::$library);
		$this->load->helper(self::$helper);
	}
	public function index()
	{
		$data['title'] = "Sales List";
		$data['page_title'] = "Sales List";
		$data['main_menu'] = "Sales Management";
		$data['sub_menu'] = "Sales List";
		$data['sub_sub_menu'] = "";

		$from_date = $this->input->get('from_date');
		$to_date = $this->input->get('to_date');
		if (!isset($from_date) && !isset($to_date)) {
			$from_date = $to_date = date('Y-m-d');
		}
		$where = array();
		if (!admin()) {
			$where['show_hide'] = 'Show';
		}
		if (!empty($from_date) && !empty($to_date)) {
			$where['sales_date >= '] = $from_date;
			$where['sales_date <= '] = $to_date;
		} elseif (!empty($from_date) && empty($to_date)) {
			$where['sales_date'] = $from_date;
		} elseif (empty($from_date) && !empty($to_date)) {
			$where['sales_date'] = $to_date;
		}
		$data['values'] = $this->Common_model->findAll("sales_orders", $where, "sales_id", "desc");
		$data['from_date'] = $from_date;
		$data['to_date'] = $to_date;

		$this->load->view('admin/layouts/header');
		$this->load->view('admin/sales_order/index', $data);
		$this->load->view('admin/layouts/footer');
	}
	public function create()
	{
		$data['title'] = "Sales Medicine/Product";
		$data['page_title'] = "Sales Medicine/Product";
		$data['info_header'] = "";


		$where = array();
		$select = '--Select--';
		if (isset($value)) {
			$where['record_id'] = $value->admission_id;
			$select = '';
		} else {
			//$where['patient_status'] = 'Admitted';
			$select = '--Select--';
		}
		$data['patients'] = $this->Common_model->findAll('admission_fee_invoice', $where, 'record_id', 'desc');
		$data['select'] = $select ;

		$this->load->view('admin/layouts/header');
		$this->load->view('admin/sales_order/create', $data);
		$this->load->view('admin/layouts/footer');
	}
	public function saveOrUpdate()
	{
		$data = $_POST;
		$update_id = $data['update_id'];
		$admission_id = $data['admission_id'];
		if (!empty($admission_id) or $admission_id != 0) {
			$admission = $this->Common_model->findById('admission_fee_invoice', array('record_id' => $admission_id));
			$data['customer_id'] = isset($admission) ? $admission->patient_id : 0;
		}
		$sales_order_details_ids = $data['sales_order_details_id'];
		$sales_date = $data['sales_date'];
		$product_ids = $data['product_id'];
		$unit_names = $data['unit_name'];
		$unit_ids = $data['unit_id'];
		$purchase_prices = $data['purchase_price'];
		$sales_prices = $data['sales_price'];
		$order_qtys = $data['order_qty'];
		$free_qtys = $data['free_qty'];
		$vat_amounts = $data['vat_amount'];
		$discount_per_products = $data['discount_per_product'];
		$discount_amounts = $data['discount_amount'];
		$net_totals = $data['net_total'];
		$sub_totals = $data['sub_total'];
		$item_sales_types = $data['item_sales_type'];

		unset($data['update_id']);
		unset($data['sales_order_details_id']);
		unset($data['product_id']);
		unset($data['unit_name']);
		unset($data['unit_id']);
		unset($data['purchase_price']);
		unset($data['sales_price']);
		unset($data['order_qty']);
		unset($data['free_qty']);
		unset($data['vat_amount']);
		unset($data['discount_per_product']);
		unset($data['discount_amount']);
		unset($data['net_total']);
		unset($data['sub_total']);
		unset($data['item_sales_type']);
		if ($update_id == 0) {
			$prefix = str_replace('-', '', $sales_date);
			$maxSalesOrder = $this->Common_model->findMax('sales_orders', array('prefix' => $prefix), 'sales_no');
			$data['prefix'] = $prefix;
			$sales_no = isset($maxSalesOrder) ? $maxSalesOrder->sales_no + 1 : 1;
			$data['sales_no'] = $sales_no;
			$insert = $this->Common_model->saveData('sales_orders', $data);
			$update_id = $insert;
			if ($insert) {
				foreach ($order_qtys as $key => $value) {
					if ($value) {
						$salesDetails = array(
							'sales_order_id' => $insert,
							'sales_type' => $item_sales_types[$key],
							'product_id' => $product_ids[$key],
							'unit_id' => $unit_ids[$key],
							'unit_name' => $unit_names[$key],
							'purchase_price' => $purchase_prices[$key],
							'sales_price' => $sales_prices[$key],
							'order_qty' => $order_qtys[$key],
							'free_qty' => $free_qtys[$key],
							'vat_amount' => $vat_amounts[$key],
							'discount_per_product' => $discount_per_products[$key],
							'discount_amount' => $discount_amounts[$key],
							'sub_total' => $sub_totals[$key],
							'net_total' => $net_totals[$key],
							'sales_date' => $sales_date
						);
						$detailId = $this->Common_model->saveData('sales_order_details', $salesDetails);

					$this->updateStock($product_ids[$key], $order_qtys[$key], $sales_date, $detailId, $purchase_prices[$key], $sales_prices[$key]);


					// 	$this->Common_model->updateData('product_name', array('sales_price' => $sales_prices[$key]), array('record_id' => $product_ids[$key]));

					
					// $stock_info = $this->Common_model->findById('drug_medicine', array('record_id' => $product_ids[$key]));
					// $new_stock = $stock_info->product_stock-$order_qtys[$key];
					// $this->Common_model->updateData('drug_medicine', array('unit_mrp' => $sales_prices[$key], 'product_stock' => $new_stock), array('record_id' => $product_ids[$key]));

					// $stock_history = $this->Common_model->findById('product_stock_history', array('product_id' => $product_ids[$key], 'stock_date' =>$sales_date));
					
					// if(!empty($stock_history)){
					// 	$history = array(
					// 		'stock_qty' => $new_stock,
					// 		'sales_qty' => $stock_history->sales_qty+$order_qtys[$key]
					// 	);
					// 	$this->Common_model->updateData('product_stock_history', $history, array('record_id' => $stock_history->record_id));
					// }else{
					// 	$history = array(
					// 		'stock_date' => $sales_date,
					// 		'product_id' => $product_ids[$key],
					// 		'stock_qty' => $new_stock,
					// 		'sales_qty' => $order_qtys[$key],
					// 	);
					// 	$this->Common_model->saveData('product_stock_history', $history);
					// }
				}
			}
				$this->session->set_userdata('alertMsg', INSERT_MSG);
			} else {
				$this->session->set_userdata('alertMsg', INSERT_ERROR_MSG);
			}
		} else {
			$this->db->trans_start();
			$sales = $this->Common_model->findById('sales_orders', array('sales_id' => $update_id));
			if ($sales_date != $sales->sales_date) {
				$prefix = str_replace('-', '', $sales_date);
				$maxSalesOrder = $this->Common_model->findMax('sales_orders', array('prefix' => $prefix), 'sales_no');
				$data['prefix'] = $prefix;
				$sales_no = isset($maxSalesOrder) ? $maxSalesOrder->sales_no + 1 : 1;
				$data['sales_no'] = $sales_no;
			}
			$update = $this->Common_model->updateData('sales_orders', $data, array('sales_id' => $update_id));
			if ($update) {
				$this->deleteStock($update_id);
				$this->Common_model->delete_info('sales_order_id', $update_id, 'sales_order_details');
				foreach ($order_qtys as $key => $value) {
					if ($value) {
						$salesDetails = array(
							'sales_order_id' => $update_id,
							'product_id' => $product_ids[$key],
							'sales_type' => $item_sales_types[$key],
							'unit_id' => $unit_ids[$key],
							'unit_name' => $unit_names[$key],
							'purchase_price' => $purchase_prices[$key],
							'sales_price' => $sales_prices[$key],
							'order_qty' => $order_qtys[$key],
							'free_qty' => $free_qtys[$key],
							'vat_amount' => $vat_amounts[$key],
							'discount_per_product' => $discount_per_products[$key],
							'discount_amount' => $discount_amounts[$key],
							'sub_total' => $sub_totals[$key],
							'net_total' => $net_totals[$key],
							'sales_date' => $sales_date
						);
						// $sales_order_details_id = $sales_order_details_ids[$key];
						// if ($sales_order_details_id) {
						// 	$this->Common_model->updateData('sales_order_details', $salesDetails, array('sales_order_details_id' => $sales_order_details_id));
						// } else {
						$detailId =	$this->Common_model->saveData('sales_order_details', $salesDetails);
							
						//}
						$this->Common_model->updateData('product_name', array('sales_price' => $sales_prices[$key]), array('record_id' => $product_ids[$key]));

						$this->updateStock($product_ids[$key], $order_qtys[$key], $sales_date, $detailId, $purchase_prices[$key], $sales_prices[$key]);

					// $stock_info = $this->Common_model->findById('drug_medicine', array('record_id' => $product_ids[$key]));
					// $new_stock = $stock_info->product_stock-$order_qtys[$key];
					// $this->Common_model->updateData('drug_medicine', array('unit_mrp' => $sales_prices[$key], 'product_stock' => $new_stock), array('record_id' => $product_ids[$key]));

					// $stock_history = $this->Common_model->findById('product_stock_history', array('product_id' => $product_ids[$key], 'stock_date' =>$sales_date));
					
					// if(!empty($stock_history)){
					// 	$history = array(
					// 		'stock_qty' => $new_stock,
					// 		'sales_qty' => $stock_history->sales_qty+$order_qtys[$key]
					// 	);
					// 	$this->Common_model->updateData('product_stock_history', $history, array('record_id' => $stock_history->record_id));
					// }else{
					// 	$history = array(
					// 		'stock_date' => $sales_date,
					// 		'product_id' => $product_ids[$key],
					// 		'stock_qty' => $new_stock,
					// 		'sales_qty' => $order_qtys[$key],
					// 	);
					// 	$this->Common_model->saveData('product_stock_history', $history);
					// }
					 }
				}
				if ($update) {
					$this->session->set_userdata('alertMsg', UPDATE_MSG);
				} else {
					$this->session->set_userdata('alertMsg', UPDATE_ERROR_MSG);
				}
			}
			$this->db->trans_complete();
		}
		redirect("sales_order/view/$update_id");
	}

	public function edit($sales_id)
	{
		$data['title'] = "Edit Sales Order";
		$data['page_title'] = "Edit Sales Order";
		$data['info_header'] = "";
		$data['value'] = $this->Common_model->findById('sales_orders', array('sales_id' => $sales_id));
		$data['customer'] = $this->Common_model->findById('patient', array('record_id' => $data['value']->customer_id));

		$where = array();
		$select = '--Select--';
		if (isset($data['value'])) {
			$where['record_id'] = $data['value']->admission_id;
			$select = '';
		} else {
			$where['patient_status'] = 'Admitted';
			$select = '--Select--';
		}
		$data['patients'] = $this->Common_model->findAll('admission_fee_invoice', $where, 'record_id', 'desc');
		$data['select'] = $select ;

		$where1 = array('type' => 'Medicine');
		$options1 = array(
			'joins' => array(
				array(
					'table' => 'units',
					'condition' => 'units.record_id = product_name.unit_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'generic_names',
					'condition' => 'generic_names.record_id = product_name.product_category_generic_name_id',
					'jointype' => 'LEFT'
				),
			),
			'select' => 'product_name.*,units.unit_short_name,generic_names.generic_name',
			'where' => $where1,
			'order' => array(
				'product_name.product_name' => 'asc',
			),
		);

		$data['products'] = $this->Common_model->commonJoins("product_name", $options1);


		$where = array('sales_order_details.sales_order_id ' => $sales_id);
		$options = array(
			'joins' => array(
				array(
					'table' => 'product_name',
					'condition' => 'product_name.record_id = sales_order_details.product_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'generic_names',
					'condition' => 'generic_names.record_id = product_name.product_category_generic_name_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'units',
					'condition' => 'units.record_id = sales_order_details.unit_id',
					'jointype' => 'LEFT'
				),

			),
			'select' => 'sales_order_details.*,product_name.product_name,product_name.product_category,units.unit_short_name,generic_names.generic_name',
			'where' => $where,
			'order' => array(
				'sales_order_details.sales_order_details_id' => 'asc',
			),
		);
		$data['values'] = $this->Common_model->commonJoins("sales_order_details", $options);


		$this->load->view('admin/layouts/header');
		$this->load->view('admin/sales_order/create', $data);
		$this->load->view('admin/layouts/footer');
	}
	public function view($sales_id)
	{
		$data['title'] = "Bill/Invoice";
		$data['page_title'] = "Bill/Invoice";
		$data['info_header'] = "";
		$data['signatureType'] = 'Staff';
		$data['redirect'] = base_url('sales_order/create');
		$data['value'] = $this->Common_model->findById('sales_orders', array('sales_id' => $sales_id));
		$data['value']->record_id = $data['value']->sales_id;
		$data['value']->date = $data['value']->sales_date;
		$data['customer'] = $this->Common_model->findById('patient', array('record_id' => $data['value']->customer_id));


		$where = array('sales_order_details.sales_order_id ' => $sales_id);
		$options = array(
			'joins' => array(
				array(
					'table' => 'units',
					'condition' => 'units.record_id = sales_order_details.unit_id',
					'jointype' => 'LEFT'
				),

			),
			'select' => 'sales_order_details.*,units.unit_short_name',
			'where' => $where,
			'order' => array(
				'sales_order_details.sales_order_details_id' => 'asc',
			),
		);
		$data['values'] = $this->Common_model->commonJoins("sales_order_details", $options);


		$this->load->view('admin/layouts/header');
		$this->load->view('admin/sales_order/invoice', $data);
		$this->load->view('admin/layouts/footer');
	}
	public function view2($sales_id)
	{
		$data['title'] = "Bill/Invoice";
		$data['page_title'] = "Bill/Invoice";
		$data['info_header'] = "";
		$data['signatureType'] = 'Staff';
		$data['redirect'] = base_url('sales_order');
		$data['value'] = $this->Common_model->findById('sales_orders', array('sales_id' => $sales_id));
		$data['value']->record_id = $data['value']->sales_id;
		$data['value']->date = $data['value']->sales_date;
		$data['customer'] = $this->Common_model->findById('patient', array('record_id' => $data['value']->customer_id));


		$where = array('sales_order_details.sales_order_id ' => $sales_id);
		$options = array(
			'joins' => array(
				
				array(
					'table' => 'units',
					'condition' => 'units.record_id = sales_order_details.unit_id',
					'jointype' => 'LEFT'
				),

			),
			'select' => 'sales_order_details.*,units.unit_short_name',
			'where' => $where,
			'order' => array(
				'sales_order_details.sales_order_details_id' => 'asc',
			),
		);
		$data['values'] = $this->Common_model->commonJoins("sales_order_details", $options);


		$this->load->view('admin/layouts/header');
		$this->load->view('admin/sales_order/invoice', $data);
		$this->load->view('admin/layouts/footer');
	}

	public function delete($id)
	{
		$user_type = $this->session->ses_user_type;
		if ($user_type == "admin"  || $user_type == "staff") {
			$this->deleteStock($id);
			if ($this->Common_model->delete_info('sales_id', $id, 'sales_orders')) {
				$this->Common_model->delete_info('sales_order_id', $id, 'sales_order_details');
				$this->session->set_flashdata('message', DELETE_MSG);
			} else {
				$this->session->set_flashdata('message', DELETE_ERROR_MSG);
			}
			redirect('sales_order', 'refresh');
		} else {
			$data['wrong_msg'] = "";
			$this->load->view('website/login_check', $data);
		}
	}

	public function find_stock()
	{
		$product_id = $this->input->post('product_id');
		$stock = $this->Common_model->item_balance($product_id);
		echo $stock;
		exit(0);
	}

	public function add_stock()
	{
		$product_id = $this->input->post('product_id');
		$order_qty = $this->input->post('order_qty');
		$stock_info = $this->Common_model->findById('product_stock', array('product_id' => $product_id));
					$new_stock = $stock_info->stock_qty+$order_qty;
					$this->Common_model->updateData('product_stock', array('stock_qty' => $new_stock), array('product_id' => $product_id));
					echo $new_stock;
		exit;
	}

	public function load_product()
	{
		$sales_type = $this->input->post('sales_type');
		$warehouse = $this->input->post('warehouse');
		$option = "<option value=''>--Select $sales_type--</option>";
		$purchase = $this->Common_model->group_by_usual('purchase_type', $sales_type, 'product_id', 'purchase_order_details');
		foreach ($purchase as $key => $value) {
			$medicine = $this->Common_model->getProductById($value->product_id);
			if($medicine->product_stock > 0){
			$product_category = !empty($medicine->dosage_name) ? ' - ' . $medicine->dosage_name : '';
			$generic_name = !empty($medicine->generic_name) ? ' - ' . $medicine->generic_name : '';
			$strength = !empty($medicine->strength) ? ' - ' . $medicine->strength : '';
			$dose = !empty($medicine->dosage_name) ? ' - ' . $medicine->dosage_name : '';
			$stock = !empty($medicine->product_stock) ? $medicine->product_stock : 0;
			$option .= '<option value="' . $medicine->record_id . '" data-product_name="' . $medicine->brand_name . $product_category . $generic_name . $strength . '" data-unit_price="' . $medicine->unit_price . '" data-unit_mrp="' . $medicine->unit_mrp . '" data-unit_id="1" data-unit_name="Pcs" data-product_code="' . $medicine->record_id . '" data-stock="' . $stock. '">' . $medicine->brand_name . $strength .$dose." - ".$medicine->record_id.'</option>';
		}
	}
	
		echo $option;
		exit;
	}

	public function delete_stock()
	{
		$id = $this->input->post('id');
		
		$order_info = $this->Common_model->findById('sales_order_details', array('sales_order_details_id' => $id));
		$stock_info = $this->Common_model->findById('drug_medicine', array('record_id' => $order_info->product_id));
		$new_stock = $stock_info->product_stock+$order_info->order_qty;
		$this->Common_model->updateData('drug_medicine', array('product_stock' => $new_stock), array('record_id' => $stock_info->record_id));

		$stock_history = $this->Common_model->findById('product_stock_history', array('product_id' => $stock_info->record_id, 'stock_date' =>$order_info->sales_date));
			$history = array(
				'stock_qty' => $new_stock,
				'sales_qty' => $stock_history->sales_qty-$order_info->order_qty
			);
			$this->Common_model->updateData('product_stock_history', $history, array('record_id' => $stock_history->record_id));
		//echo $new_stock;
		exit;
	}

	public function delete_sales_stock($id)
	{
	$sales_order_details = $this->Common_model->findAll('sales_order_details',array('sales_order_id'=>$id),'sales_order_details_id ','asc');
			foreach($sales_order_details as $detail){
				$stock_info = $this->Common_model->findById('drug_medicine', array('record_id' => $detail->product_id));
				$new_stock = $stock_info->product_stock+$detail->order_qty;
				$this->Common_model->updateData('drug_medicine', array('product_stock' => $new_stock), array('record_id' => $stock_info->record_id));

				$stock_history = $this->Common_model->findById('product_stock_history', array('product_id' => $stock_info->record_id, 'stock_date' =>$detail->sales_date));
					$history = array(
						'stock_qty' => $new_stock,
						'sales_qty' => $stock_history->sales_qty-$detail->order_qty
					);
					$this->Common_model->updateData('product_stock_history', $history, array('record_id' => $stock_history->record_id));

			}
			//exit;
	}

	public function load_package()
	{
		$package_id = $this->input->post('package_id');
		$packages = $this->Common_model->findAll("package_details", array('package_id' => $package_id), "record_id", "asc");
		$tr = "";
		foreach ($packages as $key => $value) {
				$product = $this->Common_model->getProductById($value->product_id);
				$stock = !empty($product->product_stock) ? $product->product_stock : 0;
			if ($stock > 0) {
				$unit_id = 1;
				$product_name = isset($product) ? $product->brand_name . ' - ' . $product->strength .' - ' . $product->dosage_name. ' - ' .$product->record_id : "";
				$purchase_price = isset($product) ? $product->unit_price : 0;
				$unit_name = 'Pcs';

				$html  = '<input type="hidden" name="product_id[]" value="' . $value->product_id . '">';
				$html .= '<input type="hidden" name="sales_order_details_id[]" value="0">';
				$html .= '<input type="hidden" name="item_sales_type[]" value="' . $value->type . '">';
				$html .= '<input type="hidden" name="unit_id[]" value="' . $unit_id . '">';
				$html .= '<input type="hidden" name="unit_name[]" value="' . $unit_name . '">';
				$html .= '<input type="hidden" name="sales_price[]" value="' . $value->unit_price . '">';
				$html .= '<input type="hidden" name="purchase_price[]" value="' . $purchase_price . '">';
				$html .= '<input type="hidden" name="order_qty[]" value="' . $value->quantity . '">';
				$html .= '<input type="hidden" name="free_qty[]" value="0">';
				$html .= '<input type="hidden" name="vat_amount[]" value="0">';
				$html .= '<input type="hidden" name="discount_amount[]" value="0">';
				$html .= '<input type="hidden" name="discount_per_product[]" value="0">';
				$html .= '<input type="hidden" name="sub_total[]" value="' . $value->total_price . '">';
				$html .= '<input type="hidden" name="net_total[]" value="' . $value->total_price . '">';

				$editRow = '<a data-sales_order_details_id="0" href="javascript:void(0)" style="margin-right:5px;" class="btn btn-info btn-sm editRow hide"><span class="fa fa-pencil"></span></a>';
				$deleteRow = '<a data-sales_order_details_id="0" href="javascript:void(0)" class="btn btn-danger btn-sm deleteRow"><span class="fa fa-trash-o"></span></a>';

				$tr .= '<tr>';
				$tr .= '<td class="hide">' . $html . '</td>';
				$tr .= '<td class="serial"></td>';
				$tr .= '<td class="">' . $product_name . '</td>';
				$tr .= '<td class="hide">' . $unit_name . '</td>';
				$tr .= '<td style="text-align:right;" class="">' . $value->unit_price . '</td>';
				$tr .= '<td style="text-align:right;" class="order_qty">' . $value->quantity . '</td>';
				$tr .= '<td style="text-align:right;" class="hide free_qty">0</td>';
				$tr .= '<td style="text-align:right;" class="hide vat_amount">0</td>';
				$tr .= '<td style="text-align:right;" class="hide sub_total">' . $value->total_price . '</td>';
				$tr .= '<td style="text-align:right;" class="hide discount_amount">0</td>';
				$tr .= '<td style="text-align:right;" class="net_total">' . $value->total_price . '</td>';
				$tr .= '<td class="">' . $editRow . '' . $deleteRow . '</td>';
				$tr .= '</tr>';
			}
		}
		echo $tr;
		exit;
	}

	
	private function updateStock($product_id, $qty, $date, $detailId, $price=0, $salePrice=0){
		updateStock($product_id,$detailId, $qty, $date,'sales',$price, $salePrice);
	}

	private function deleteStock($id){
		$purchase_order_details = $this->Common_model->findAll('sales_order_details',['sales_order_id'=>$id, 'sales_type'=>'Medicine'],'sales_order_details_id','asc');
		foreach($purchase_order_details as $detail){
			deleteStock($detail->sales_order_details_id, $detail->product_id, 'sales');
		}
		
	}
}
