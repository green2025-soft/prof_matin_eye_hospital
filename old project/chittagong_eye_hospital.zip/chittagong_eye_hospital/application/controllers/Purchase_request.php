<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Purchase_request extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'All Purchase Request';
            $data['page_title'] = 'Purchase Request';
            $data['info_header'] = 'All Purchase Request';
            $where = array() ;
            if(!admin()){
                $where['show_hide'] = "Show" ;
            }
            $data['values'] = $this->Common_model->findAll('purchase_request',$where,'record_id','desc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/purchase_request/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function create() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Purchase Request';
            $data['page_title'] = 'Purchase Request';
            $data['info_header'] = 'All Purchase Request';
            $data['in_values'] = $this->Common_model->findAll('purchase_request',array(),'record_id','desc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/purchase_request/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function edit($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Purchase Request';
            $data['page_title'] = 'Purchase Request';
            $data['info_header'] = 'All Purchase Request';
            $data['value'] = $this->Common_model->findById('purchase_request',array('record_id'=>$record_id)) ;
            $data['supplier'] = $this->Common_model->findById('suppliers',array('record_id'=>$data['value']->supplier_id)) ;
            $data['values'] = $this->Common_model->findAll('purchase_request_details',array('purchase_request_id'=>$record_id),'record_id','asc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/purchase_request/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function view($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Purchase Request';
            $data['page_title'] = 'Purchase Request';
            $data['info_header'] = 'All Purchase Request';
            $data['redirect'] = base_url('purchase_request/create');
            $data['signatureType'] = "Staff";
            $data['value'] = $this->Common_model->findById('purchase_request',array('record_id'=>$record_id)) ;
            $data['supplier'] = $this->Common_model->findById('suppliers',array('record_id'=>$data['value']->supplier_id)) ;
            $data['values'] = $this->Common_model->findAll('purchase_request_details',array('purchase_request_id'=>$record_id),'record_id','asc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/purchase_request/invoice', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }    
    public function view2($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Purchase Request';
            $data['page_title'] = 'Purchase Request';
            $data['info_header'] = 'All Purchase Request';
            $data['redirect'] = base_url('purchase_request');
            $data['signatureType'] = "Staff";
            $data['value'] = $this->Common_model->findById('purchase_request',array('record_id'=>$record_id)) ;
            $data['supplier'] = $this->Common_model->findById('suppliers',array('record_id'=>$data['value']->supplier_id)) ;
            $data['values'] = $this->Common_model->findAll('purchase_request_details',array('purchase_request_id'=>$record_id),'record_id','asc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/purchase_request/invoice', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            $record_ids = $input['record_id'] ;
            $product_ids = $input['product_id'] ;
            $quantitys = $input['quantity'] ;
            $unit_prices = $input['unit_price'] ;
            $total_prices = $input['total_price'] ;
            $category_id = $input['category_id'] ;
           
            unset($input['update_id']);
            unset($input['record_id']);
            unset($input['product_id']);
            unset($input['quantity']);
            unset($input['unit_price']);
            unset($input['total_price']);
            unset($input['product_category']);
            unset($input['category_id']);

            $request_date = $input['request_date'] ; 

            $prefix = str_replace('-', '', $request_date);

            $max = $this->Common_model->findMax('purchase_request',array('prefix'=>$prefix),'request_no');
            $request_no = isset($max)?$max->request_no + 1 : 1 ;

            $input['prefix'] = $prefix ;
            $input['request_no'] = $request_no ;

            if($update_id == 0 || empty($update_id)){       
                $insert = $this->Common_model->saveData('purchase_request', $input);
                if($insert){
                    foreach ($record_ids as $key => $value) {
                        $data = array(
                            'purchase_request_id'=>$insert,
                            'request_date'=>$request_date,
                            'product_id'=>$product_ids[$key],
                            'quantity'=>$quantitys[$key],
                            'unit_price'=>$unit_prices[$key],
                            'total_price'=>$total_prices[$key],
                            'category_id'=>$category_id[$key]
                        );
                        $this->Common_model->saveData('purchase_request_details',$data);
                    }
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $info = $this->Common_model->findById('purchase_request',array('record_id'=>$update_id));
                if($info->request_date == $request_date){
                    $input['request_no'] = $info->request_no;
                }
                $update = $this->Common_model->updateData('purchase_request', $input,array('record_id'=>$update_id));
                if($update){
                    foreach ($record_ids as $key => $value) {
                        $data = array(
                            'purchase_request_id'=>$update_id,
                            'request_date'=>$request_date,
                            'product_id'=>$product_ids[$key],
                            'quantity'=>$quantitys[$key],
                            'unit_price'=>$unit_prices[$key],
                            'total_price'=>$total_prices[$key]
                        );
                        if($value){
                            $this->Common_model->updateData('purchase_request_details',$data,array('record_id'=>$value));
                        }else{
                            $this->Common_model->saveData('purchase_request_details',$data);
                        }
                    }

                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            redirect('purchase_request', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function in_out() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Purchase Request/Out';
            $data['page_title'] = 'Purchase Request/Out';
            $data['info_header'] = 'All Purchase Request/Out';

            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $product_id = $this->input->get('product_id');
            $transaction_type = $this->input->get('transaction_type');

            $where = array() ;

            if(! isset($from_date) && !isset($to_date) && !isset($product_id) && !isset($transaction_type)){
                $where['date'] = date('Y-m-d') ;
            }

            if($product_id) $where['record_id'] = $product_id ;

            if(!empty($from_date) && !empty($to_date)){
                $where['date >= '] = $from_date ;
                $where['date <= '] = $to_date ;
            }elseif(!empty($from_date) && empty($to_date)){
                $where['date'] = $from_date ;
            }elseif(empty($from_date) && !empty($to_date)){
                $where['date'] = $to_date ;
            }

            $data['values'] = $this->Common_model->findAllGroupBySum('lab_product_use_in',$where,'product_id','qty') ;
            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;
            $data['product_id'] = $product_id;
            $data['transaction_type'] = $transaction_type;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/lab_product/in_out', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $id, 'purchase_request')){
                $this->Common_model->delete_info('purchase_request_id', $id, 'purchase_request_details');
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
            redirect('purchase_request', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function approved($record_id)
    {
        $bill = $this->Common_model->findById('purchase_request', array('record_id' => $record_id));
        if (isset($bill)) {
            $status = '';
            if ($bill->status == 'Pending') {
                $status = 'Approved';
            } else {
                $status = 'Pending';
            }
            $this->Common_model->updateData('purchase_request', array('status' => $status), array('record_id' => $record_id));
            $this->Common_model->updateData('purchase_request_details', array('status' => $status), array('purchase_request_id' => $record_id));
            $this->session->set_flashdata('message', UPDATE_MSG);
        } else {
            $this->session->set_flashdata('message', UPDATE_ERROR_MSG);
        }
        // redirect('test_honorarium/appointment', 'refresh');
        redirect($_SERVER['HTTP_REFERER']);
    }

    public function load_product()
	{
		$purchase_type = $this->input->post('purchase_type');
		//$products = $this->Common_model->findAll('product_name',array('type'=>$purchase_type),'product_name','asc');

		$where = array();
		$where['product_category_generic_name_id'] = $purchase_type;
		
		$options = array(
			'joins' => array(
				array(
					'table' => 'units',
					'condition' => 'units.record_id = product_name.unit_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'generic_names',
					'condition' => 'generic_names.record_id = product_name.product_category_generic_name_id',
					'jointype' => 'LEFT'
				),
			),
			'select' => 'product_name.*,units.unit_short_name,generic_names.generic_name',
			'where' => $where,
			'order' => array(
				'product_name.product_name' => 'asc',
			),
		);
		$products = $this->Common_model->commonJoins("product_name", $options);

		$option = "<option value=''>--Select Product--</option>";

		foreach ($products as $key => $value) {
			$product_category = !empty($value->product_category) ? ' - ' . $value->product_category : '';
			$generic_name = !empty($value->generic_name) ? ' - ' . $value->generic_name : '';
			$strength = !empty($value->strength) ? ' - ' . $value->strength : '';
			$option .= '<option value=' . $value->record_id . ' data-product_name=' . $value->product_name . $product_category . $generic_name . $strength . ' data-purchase_price=' . $value->purchase_price . ' data-sales_price=' . $value->sales_price . ' data-unit_id=' . $value->unit_id . ' data-unit_name=' . $value->unit_short_name . ' data-product_code=' . $value->code_no . '>' . $value->product_name . '</option>';
		}
		echo $option;
		exit;
	}

    public function loadStockProduct(){
        $purchaseType = $this->input->post('purchase_type');

        $this->db->select("
            p.*,
            u.unit_short_name,
            g.generic_name,
            COALESCE(stock_in.total_in,0) - COALESCE(stock_out.total_out,0) AS stock_qty
        ");

        $this->db->from('product_name p');

        $this->db->join('units u', 'u.record_id = p.unit_id', 'left');
        $this->db->join('generic_names g', 'g.record_id = p.product_category_generic_name_id', 'left');

        $this->db->join("
            (
                SELECT
                    product_id,
                    category_id,
                    SUM(quantity) AS total_in
                FROM lab_product_in_details
                GROUP BY product_id, category_id
            ) stock_in",
            "stock_in.product_id = p.record_id
            AND stock_in.category_id = p.product_category_generic_name_id",
            "left"
        );

        $this->db->join("
            (
                SELECT
                    product_id,
                    category_id,
                    SUM(quantity) AS total_out
                FROM lab_product_out_details
                GROUP BY product_id, category_id
            ) stock_out",
            "stock_out.product_id = p.record_id
            AND stock_out.category_id = p.product_category_generic_name_id",
            "left"
        );

        $this->db->where('p.product_category_generic_name_id', $purchaseType);

        $this->db->where('(COALESCE(stock_in.total_in,0) - COALESCE(stock_out.total_out,0)) >', 0, FALSE);

        $query = $this->db->get();

       $products =  $query->result();

      $option = "<option value=''>--Select Product--</option>";

		foreach ($products as $key => $value) {
			$product_category = !empty($value->product_category) ? ' - ' . $value->product_category : '';
			$generic_name = !empty($value->generic_name) ? ' - ' . $value->generic_name : '';
			$strength = !empty($value->strength) ? ' - ' . $value->strength : '';
			$option .= '<option value=' . $value->record_id . ' data-product_name=' . $value->product_name . $product_category . $generic_name . $strength . ' data-purchase_price=' . $value->purchase_price . ' data-sales_price=' . $value->sales_price . ' data-unit_id=' . $value->unit_id . ' data-unit_name=' . $value->unit_short_name . ' data-product_code=' . $value->code_no . '>' . $value->product_name . '</option>';
		}
		echo $option;
		exit;
    }
}
