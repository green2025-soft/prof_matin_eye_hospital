<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Supplier extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Common_model');
        $this->load->library('user_agent');
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Manufacturer/Supplier';
            $data['page_title'] = 'Manufacturer/Supplier';
            $data['info_header'] = 'All Manufacturer/Supplier';
            $data['values'] = $this->Common_model->findAll('drug_manufacturer',array(),'record_id','desc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/supplier/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function payable_info() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Payable List';
            $data['page_title'] = 'Payable List';
            $data['info_header'] = '';
            $suppliers = $this->Common_model->findAll('drug_manufacturer',array(),'record_id','desc');
            $supplierArr = [];
            foreach($suppliers as $row){
                $supplierArr[$row->record_id] = new stdClass();
                $supplierArr[$row->record_id] = $row;
            }
            $data['suppliers'] = $supplierArr;
            $data['values'] = $this->Common_model->findAll('supplier_payments',array(),'payment_id','desc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/supplier/payable_list', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function payable() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Supplier Payable';
            $data['page_title'] = 'Supplier Payable';
            $data['info_header'] = '';
            $data['values'] = $this->Common_model->findAll('drug_manufacturer',array(),'record_id','desc') ;
            // ddd($data['values']);
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/supplier/payable', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST;
            $update_id = $input['update_id'];
            unset($input['update_id']);
            $manufacturer_name = $input['manufacturer_name'];
            $contact_no = $input['contact_no'];
            if($update_id == 0 || empty($update_id)){       
                $getRow = $this->Common_model->findById('drug_manufacturer',array('manufacturer_name'=>$manufacturer_name,'contact_no'=>$contact_no));
                if(isset($getRow)){
                    $this->session->set_flashdata('message', EXIST_MSG);
                    redirect('supplier', 'refresh');
                }
                $insert = $this->Common_model->saveData('drug_manufacturer', $input);
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $update = $this->Common_model->updateData('drug_manufacturer', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            redirect('supplier', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function paymentSaveOrUpdate()
    {
      $payment_date = $this->input->post('payment_date');
      $supplier_id = $this->input->post('supplier_id');
      $purchase_amounts = $this->input->post('purchase_amount');
      $purchase_ids = $this->input->post('purchase_id');
      $payment_type = $this->input->post('payment_type');
      $current_collections = $this->input->post('current_collection');
      $payment_amount = array_sum($current_collections) ; 
      $prefix  = str_replace('-', '', $payment_date);
      $maxPayment = $this->Common_model->findMax('supplier_payments',array('prefix'=>$prefix),'payment_no');
      $payment_no = isset($maxPayment)?$maxPayment->payment_no + 1 : 1 ;

      $payment = array(
        'supplier_id'=>$supplier_id,
        'payment_type'=>$payment_type,
        'prefix'=>$prefix,
        'payment_no'=>$payment_no,
        'payment_date'=>$payment_date,
        'payment_amount'=>$payment_amount,
    );

      $insert = $payment_id = $this->Common_model->saveData('supplier_payments',$payment);

      if($payment_id){
          foreach ($current_collections as $key => $value) {
            if($value > 0){
              $data = array(
                  'payment_id'=>$payment_id,
                  'payment_date'=>$payment_date,
                  'payment_type'=>$payment_type,
                  'supplier_id'=>$supplier_id,
                  'purchase_id'=>$purchase_ids[$key],
                  'purchase_amount'=>$purchase_amounts[$key],
                  'current_collection'=>$value,
              );
              $this->Common_model->saveData('supplier_payment_details',$data);
          }
      }
      if($insert){
        $this->session->set_flashdata('message',INSERT_MSG);
    }else{
        $this->session->set_flashdata('message',INSERT_ERROR_MSG);
    }
}
redirect("supplier/payment_view/$payment_id");
}

public function load_supplier_invoice(){
    $supplier_id = $this->input->post('supplier_id');
    $where['supplier_id'] = $supplier_id ;
    $data['values'] = $this->Common_model->findAll('purchase_orders',$where,'purchase_id','asc') ;
    $this->load->view('admin/supplier/invoice_list',$data);
}

public function delete($id) {
    $user_type = $this->session->ses_user_type;
    if ($user_type == "admin"  || $user_type == "staff") {
        if($this->Common_model->delete_info('record_id', $id, 'drug_manufacturer')){
            $this->session->set_flashdata('message',DELETE_MSG);
        }else{
            $this->session->set_flashdata('message',DELETE_ERROR_MSG);
        }
           // redirect("crud/previousPage");
        redirect('supplier', 'refresh');
    } else {
        $data['wrong_msg'] = "";
        $this->load->view('website/login_check', $data);
    }
}


public function payment_view($payment_id)
{
    $data['title'] = "Supplier Payment";
    $data['page_title'] = "Supplier Payment";
    $data['info_header'] = "";
    $data['signatureType'] = 'Staff';
    $data['redirect'] = base_url('supplier/payable');
    $data['value'] = $this->Common_model->findById('supplier_payments',array('payment_id'=>$payment_id));
    $manufacturer =  $this->Common_model->findById('drug_manufacturer', array('record_id' => $data['value']->supplier_id));
    $data['supplier'] = $manufacturer->manufacturer_name.'['.$manufacturer->record_id.']';
    $data['supplier_contact'] = !empty($manufacturer->contact_no) ? $manufacturer->contact_no : "";
    

    $where = array('supplier_payment_details.payment_id '=>$payment_id);
    $options = array(
      'joins' => array(
        array(
          'table' => 'purchase_orders',
          'condition' => 'purchase_orders.purchase_id = supplier_payment_details.purchase_id',
          'jointype' => 'LEFT'
      )
    ),
      'select' => 'supplier_payment_details.*,purchase_orders.prefix,purchase_orders.purchase_no,purchase_orders.grand_net_total',
      'where' => $where,
      'order' => array(
        'supplier_payment_details.payment_details_id' => 'asc',
    ),
  );
    $data['values'] = $this->Common_model->commonJoins("supplier_payment_details", $options);

    $this->load->view('admin/layouts/header');
    $this->load->view('admin/supplier/invoice', $data);
    $this->load->view('admin/layouts/footer');
}

public function payment_delete($id) {
    $user_type = $this->session->ses_user_type;
    if($this->Common_model->delete_info('payment_id', $id, 'supplier_payments')){
        $this->Common_model->delete_info('payment_id', $id, 'supplier_payment_details');
        $this->session->set_flashdata('message',DELETE_MSG);
    }else{
        $this->session->set_flashdata('message',DELETE_ERROR_MSG);
    }
    redirect('supplier/payable_info', 'refresh');
} 

public function due_list() {
    $user_type = $this->session->ses_user_type;
    if ($user_type == "admin" || $user_type == "staff") {
        $supplierID = $data['supplier_id'] = $this->input->get('supplier_id') ?? 0;
        $data['title'] = 'Supplier Due List';
        $data['page_title'] = 'Supplier Due List';
        $data['info_header'] = '';
        $data['suppliers'] =  $this->Common_model->one_column_group_by('supplier_id', 'purchase_orders');

        //$data['due_data'] = $this->drug_model->getSupplierDueList($supplierID);
        //ddd($data['due_data']);
        // die('Here');

        // $supplierArr = [];
        // foreach($suppliers as $row){
        //     $supplierArr[$row->record_id] = new stdClass();
        //     $supplierArr[$row->record_id] = $row;
        // }
        // $data['suppliers'] = $supplierArr;
        // $data['values'] = $this->Common_model->findAll('supplier_payments',array('warehouse' => 'Pharmacy'),'payment_id','desc');
        $this->load->view('admin/layouts/header');
        $this->load->view('admin/supplier/due_list', $data);
        $this->load->view('admin/layouts/footer');
    } else {
        $data['wrong_msg'] = "";
        $this->load->view('website/login_check', $data);
    }
}
}
