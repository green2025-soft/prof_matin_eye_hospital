<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Auditors extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Auditors';
            $data['page_title'] = 'Auditors';
            $data['info_header'] = 'Auditors';
            $data['values'] = $this->Common_model->findAll('auditors',array(),'record_id','desc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/auditors/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function uri_segment(){
        $segment = $this->uri->segment_array() ;
        $segment = implode('/', $segment) ;
        $menu = $this->Common_model->findById('menu_list',array('menu_link'=>$segment));
        var_dump($menu) ; die;
    }
}
