<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Generic_name extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Common_model');
        $this->load->model('drug_model');
        $this->load->library('user_agent');
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff" || $user_type == "doctor") {
            $data['title'] = 'Generic/Category Name';
            $data['page_title'] = $data['title'];
            $data['info_header'] = 'All Generic/Category Name';
            //$data['values'] = $this->Common_model->findAll('generic_names',array(),'record_id','desc') ;
            $data['values'] = $this->drug_model->get_generic();
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/generic_name/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff" || $user_type == "doctor") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            unset($input['update_id']);
            $generic_name = $input['generic_name'];
            $popup = $this->input->post('popup');
            if(isset($popup)){
                unset($input['popup']);
            }
            if($update_id == 0 || empty($update_id)){       
                $getRow = $this->Common_model->findById('drug_generic',array('generic_name'=>$generic_name));
                if(isset($getRow)){
                    $this->session->set_flashdata('message', EXIST_MSG);
                    redirect('generic_name', 'refresh');
                }
                $insert = $this->Common_model->saveData('drug_generic', $input);
                $record_id = $insert ;
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
                if(isset($popup)){
                    $bank = $this->Common_model->findById('drug_generic',array('record_id'=>$record_id));
                    echo json_encode($bank);
                    exit;
                }
            }else{
                $update = $this->Common_model->updateData('drug_generic', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            redirect('generic_name', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $id, 'generic_names')){
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
           // redirect("crud/previousPage");
            redirect('generic_name', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
