<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Staff extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Common_model');
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['all_staff'] = $this->Common_model->get_all_info('staff');
            $data['all_doctor'] = $this->Common_model->get_allinfo_byid('staff', 'staff_type', "doctor");
            $data['all_dept'] = $this->Common_model->get_all_info('departments');
            $data['all_desig'] = $this->Common_model->get_all_info('designation');
            $data['all_doc'] = $this->Common_model->get_all_info('doctor');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/staff/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function create() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            /*$data['all_staff'] = $this->Common_model->get_all_info('staff');
            $data['all_doctor'] = $this->Common_model->get_allinfo_byid('staff', 'staff_type', "doctor");*/
            $data['all_dept'] = $this->Common_model->get_all_info('departments');
            $data['all_desig'] = $this->Common_model->get_all_info('designation');
            //$data['all_doc'] = $this->Common_model->get_all_info('doctor');
            $data['menues'] = $this->Common_model->findAll('menu_list',array('parent_id'=>null,'status'=>'active'),'order','asc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/staff/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

   

    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $edit_action = $this->input->post('edit_action');
            if(!isset($edit_action)){
                $input['edit_action'] = 0 ;
            }
            $delete_action = $this->input->post('delete_action');
            if(!isset($delete_action)){
                $input['delete_action'] = 0 ;
            }
            $update_id = $input['update_id'] ;
            unset($input['update_id']);
            $name = $input['name'];
            $mobile = $input['mobile'];
            $menues = $this->input->post('menu_ids') ;
            $password = $input['password'];
            if($menues) {
                $input['menu_ids'] = implode(',', $menues);
            }else{
                $input['menu_ids'] = '' ;
            }
            $input['staff_type'] = "Staff" ;
            //$config['file_name'] = $img_name;
            $config['upload_path'] = 'assets/img/staff/';
            $config['allowed_types'] = 'gif|jpg|jpeg|png';
            $config['max_size'] = 0;
            $config['max_width'] = 0;
            $config['max_height'] = 0;
            $config['overwrite'] = TRUE;
            $file_field = 'image' ;

            $this->load->library('upload', $config);
            if($update_id == 0 || empty($update_id)){
                if(!empty($_FILES[$file_field]["name"])){
                    if($this->upload->do_upload($file_field)) {
                        $uploadData = $this->upload->data();
                        $input['image'] =   $config['upload_path'] . $uploadData['file_name'];
                    }
                }          

                $getRow = $this->Common_model->findById('staff',array('name'=>$name,'mobile'=>$mobile));
                if(isset($getRow)){
                    $this->session->set_flashdata('message', EXIST_MSG);
                    redirect("crud/previousPage");
                }
                  //  var_dump($input);die;
                $insert = $this->Common_model->saveData('staff', $input);
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                     redirect("crud/previousPage");
                }
            }else{
                $staff = $this->Common_model->findById('staff',array('record_id'=>$update_id));
                if(!empty($password)){
                    $input['password'] = $password ;
                }else{
                    $input['password'] = $staff->password ;
                }

                if(!empty($_FILES[$file_field]["name"])){
                    if($this->upload->do_upload($file_field)) {
                        if(isset($staff)){
                            if(file_exists($staff->image)){
                                unlink('./'.$staff->image);
                            }
                        }
                        $uploadData = $this->upload->data();
                        $input['image'] =   $config['upload_path'] . $uploadData['file_name'];
                    }
                }          

                /*$getRow = $this->Common_model->findById('staff',array('name'=>$name,'mobile'=>$mobile));
                if(isset($getRow)){
                    $this->session->set_flashdata('message', EXIST_MSG);
                    redirect("crud/previousPage");
                }*/
                  //  var_dump($input);die;
                $update = $this->Common_model->updateData('staff', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                     redirect("crud/previousPage");
                }
            }
            redirect('staff', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function edit($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
           /// $data['all_staff'] = $this->Common_model->get_all_info('staff');
           // $data['all_doctor'] = $this->Common_model->get_allinfo_byid('staff', 'staff_type', "doctor");
            $data['all_dept'] = $this->Common_model->get_all_info('departments');
            $data['all_desig'] = $this->Common_model->get_all_info('designation');
          //  $data['all_doc'] = $this->Common_model->get_all_info('doctor');
            $data['menues'] = $this->Common_model->findAll('menu_list',array('parent_id'=>null,'status'=>'active'),'order','asc');
            $data['staff'] = $this->Common_model->findById('staff',array('record_id'=>$record_id));
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/staff/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $id, 'staff')){
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
            redirect('staff', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
