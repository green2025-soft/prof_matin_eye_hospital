<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class MY_Model extends CI_Model {

    protected $table        = '';        // Table name
    protected $primaryKey   = 'id'; // Primary key name
    protected $timestamp    = true; // Primary key name
    protected $updateedAt   = true; // Primary key name
    protected $createOrUpdateBy= false;


    function __construct() {

        parent::__construct();
        if (!$this->timestamp){
            $this->updateedAt = $this->timestamp;
        }
    }

       // Create a new record
    public function create($data) {
        if ($this->timestamp){
            $data['created_at'] = date('Y-m-d H:i:s');
        }
        if ($this->createOrUpdateBy) {
            $userId = $this->session->userdata('ses_record_id');
            $data['created_by'] = $userId;
        }
        unset($data['update_id']);	
        
        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
    }

    public function updateData($id, $data, $primaryKey=null) {
        $primaryKey = $primaryKey ?? $this->primaryKey;
        unset($data['update_id']);	
        if ($this->updateedAt){
            $data['updated_at'] = date('Y-m-d H:i:s');
        }
        if ($this->createOrUpdateBy && $this->updateedAt) {
            $userId = $this->session->userdata('ses_record_id');
            $data['updated_by'] = $userId;
        }
        $this->db->where($primaryKey, $id);
       
        $this->db->update($this->table, $data);
        return $id;
    }

    public function updateOrInsert($data, $id = null, $primaryKey=null) {
        // If the ID is provided, try to update the record
        if ($id) {
           return $this->updateData($id, $data, $primaryKey); 
        }else{
        
           return $this->create($data);
        }
    }

    public function all() {
        return $this->db->get($this->table)->result(); 
    }

    public function find($id, $primaryKey=null) {
        if (!$id) return null;
        $primaryKey = $primaryKey ?? $this->primaryKey;
        return $this->db->get_where($this->table, [$primaryKey => $id])->row();
    }

    public function first() {
        return $this->db->get($this->table)->row();
    }

    public function getDelete($id, $primaryKey=null){
         $primaryKey = $primaryKey ?? $this->primaryKey;
        return $this->db->delete($this->table, [$primaryKey => $id]);
    }



    public function groupBy($field){
        $this->db->group_by($field);
        return $this; 
    }

    public function filterTableData($data)
    {
        if (!is_array($data) || empty($this->table)) {
            return [];
        }

        $fields = $this->db->list_fields($this->table);

        return array_intersect_key(
            $data,
            array_flip($fields)
        );
    }

    public function __call($method, $params)
    {
        if (!is_callable([$this->db, $method])) {
            throw new BadMethodCallException(
                "Method [{$method}] does not exist in Model or CI3 Database."
            );
        }
        $result = call_user_func_array(
            [$this->db, $method],
            $params
        );

        if ($result === $this->db) {
            return $this;
        }

        return $result;
    }


}