<?php
if (!defined('BASEPATH'))
  exit('No direct script access allowed');
class Number_to_word_convert {
    function convert_number($number) {
        if (($number < 0) || ($number > 999999999)) {
            throw new Exception("Number is out of range");
        }
        $piga = floor($number / 10000000); /* Core */
		$number -= $piga * 10000000;
		$giga = floor($number / 100000);  /* lakh  */ 
		$number -= $giga * 100000; 
		$kilo = floor($number / 1000);     /* Thousands (kilo) */ 
		$number -= $kilo * 1000; 
		$hecto = floor($number / 100);      /* Hundreds (hecto) */ 
		$number -= $hecto * 100; 
		$deca = floor($number / 10);      /* Ten (deca) */ 
		$n = $number % 10;               /* Ones */ 

        $result = "";
        if ($piga) {
            $result .= $this->convert_number($piga) .  " Core ";
        }
		if ($giga) {
            $result .= $this->convert_number($giga) .  " Lakh";
        }
        if ($kilo) {
            $result .= (empty($result) ? "" : " ") .$this->convert_number($kilo) . " Thousand";
        }
        if ($hecto) {
            $result .= (empty($result) ? "" : " ") .$this->convert_number($hecto) . " Hundred";
        }
        $ones = array("", "One", " Two", " Three", "Four", " Five", " Six", " Seven", " Eight", " Nine", " Ten", " Eleven", " Twelve", " Thirteen", " Fourteen", " Fifteen", " Sixteen", " Seventeen", " Eightteen", " Nineteen");
        $tens = array(" ", " ", " Twenty", " Thirty", " Fourty", " Fifty", " Sixty", " Seventy", " Eigthy", " Ninety");
        if ($deca || $n) {
            if (!empty($result)) {
                $result .= " and ";
            }
            if ($deca < 2) {
                $result .= $ones[$deca * 10 + $n];
            } else {
                $result .= $tens[$deca];
                if ($n) {
                    $result .= " " . $ones[$n];
                }
            }
        }
        if (empty($result)) {
            $result = "Zero";
        }
        return $result;
    }
}
?>