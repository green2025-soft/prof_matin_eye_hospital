<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PermissionHook
{
    public function checkPermission()
    {
        $CI =& get_instance();

        $method = $CI->router->fetch_method();
        
        if ($method === 'edit' && !hasEditPermission()) {
            show_error('Access Denied', 403);
        }

        if ($method === 'delete' && !hasDeletePermission()) {
            show_error('Access Denied', 403);
        }
    }
}