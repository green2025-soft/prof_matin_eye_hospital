<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Purchase_order extends CI_Controller
{

	static $library 	 = array('user_agent', 'Numbertowords');
	static $model 	 = array('Common_model');
	static $helper 	 = array('utility');

	public function __construct()
	{
		parent::__construct();
		$this->load->model(self::$model);
		$this->load->model(self::$model);
		$this->load->library(self::$library);
	}
	public function index()
	{
		$data['title'] = "Purchase List";
		$data['page_title'] = "Purchase List";
		$data['info_header'] = "";

		$from_date = $this->input->get('from_date');
		$to_date = $this->input->get('to_date');
		if (!isset($from_date) && !isset($to_date)) {
			$from_date = $to_date = date('Y-m-d');
		}
		$where = array();
		if (!admin()) {
			$where['show_hide'] = 'Show';
		}
		if (!empty($from_date) && !empty($to_date)) {
			$where['purchase_date >= '] = $from_date;
			$where['purchase_date <= '] = $to_date;
		} elseif (!empty($from_date) && empty($to_date)) {
			$where['purchase_date'] = $from_date;
		} elseif (empty($from_date) && !empty($to_date)) {
			$where['purchase_date'] = $to_date;
		}
		$data['values'] = $this->Common_model->findAll("purchase_orders", $where, "purchase_id", "desc");
		$data['from_date'] = $from_date;
		$data['to_date'] = $to_date;
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/purchase_order/index', $data);
		$this->load->view('admin/layouts/footer');
	}
	public function create()
	{
		$data['title'] = "Purchase Medicine/Products";
		$data['page_title'] = "Purchase Medicine/Products";
		$data['info_header'] = "";
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/purchase_order/create', $data);
		$this->load->view('admin/layouts/footer');
	}
	public function saveOrUpdate()
	{
		$data = $_POST;

		$update_id = $data['update_id'];
		$purchase_order_details_ids = $data['purchase_order_details_id'];
		$purchase_date = $data['purchase_date'];
		$product_ids = $data['product_id'];
		$item_purchase_types = $data['item_purchase_type'];
		$sales_prices = $data['sales_price'];
		$whole_sales_prices = $data['whole_sales_price'];
		$purchase_prices = $data['purchase_price'];
		$unit_prices = $data['unit_price'];
		$order_qtys = $data['order_qty'];
		$free_qtys = $data['free_qty'];
		$tp_amounts = $data['tp_amount'];
		$vat_amounts = $data['vat_amount'];
		$discount_amounts = $data['discount_amount'];
		$discount_per_products = $data['discount_per_product'];
		$unit_ids = $data['unit_id'];
		$unit_names = $data['unit_name'];
		$sub_totals = $data['sub_total'];
		$net_totals = $data['net_total'];
		$expired_dates = $data['expired_date'];
		unset($data['update_id']);
		unset($data['item_supplier_id']);
		unset($data['purchase_order_details_id']);
		unset($data['product_id']);
		unset($data['sales_price']);
		unset($data['whole_sales_price']);
		unset($data['purchase_price']);
		unset($data['order_qty']);
		unset($data['free_qty']);
		unset($data['tp_amount']);
		unset($data['vat_amount']);
		unset($data['discount_amount']);
		unset($data['discount_per_product']);
		unset($data['unit_id']);
		unset($data['unit_name']);
		unset($data['sub_total']);
		unset($data['net_total']);
		unset($data['expired_date']);
		unset($data['unit_price']);
		unset($data['item_purchase_type']);
		//unset($data['punit_price']);
		//var_dump($data);die;
		if ($update_id == 0) {
			$prefix = str_replace('-', '', $purchase_date);
			$maxPurschaseOrder = $this->Common_model->findMax('purchase_orders', array('prefix' => $prefix), 'purchase_no');
			$data['prefix'] = $prefix;
			$purchase_no = isset($maxPurschaseOrder) ? $maxPurschaseOrder->purchase_no + 1 : 1;
			$data['purchase_no'] = $purchase_no;
			$insert = $this->Common_model->saveData('purchase_orders', $data);
			$update_id = $insert;
			if ($insert) {
				foreach ($product_ids as $key => $value) {
					$purchaseDetails = array(
						'purchase_order_id' => $insert,
						'purchase_type' => $item_purchase_types[$key],
						'product_id' => $product_ids[$key],
						'unit_id' => $unit_ids[$key],
						'unit_name' => $unit_names[$key],
						'unit_price' => $unit_prices[$key],
						'sales_price' => $sales_prices[$key],
						'whole_sales_price' => $whole_sales_prices[$key],
						'purchase_price' => $purchase_prices[$key],
						'order_qty' => $order_qtys[$key],
						'free_qty' => $free_qtys[$key],
						'tp_amount' => $tp_amounts[$key],
						'vat_amount' => $vat_amounts[$key],
						'discount_per_product' => $discount_per_products[$key],
						'discount_amount' => $discount_amounts[$key],
						'sub_total' => $sub_totals[$key],
						'net_total' => $net_totals[$key],
						'expired_date' => $expired_dates[$key],
						'purchase_date' => $purchase_date
					);
				$detailsId = $this->Common_model->saveData('purchase_order_details', $purchaseDetails);
					$stock_info = $this->Common_model->findById('drug_medicine', array('record_id' => $product_ids[$key]));
					$new_stock = $stock_info->product_stock+$order_qtys[$key];
					$this->Common_model->updateData('drug_medicine', array('unit_price' => $unit_prices[$key], 'unit_mrp' => $sales_prices[$key], 'product_stock' => $new_stock), array('record_id' => $product_ids[$key]));

					$this->updateStock($product_ids[$key],$detailsId, $order_qtys[$key], $purchase_date, $unit_prices[$key],$purchase_prices[$key]);

					// $stock_history = $this->Common_model->findById('product_stock_history', array('product_id' => $product_ids[$key], 'stock_date' =>$purchase_date));
					
					// if(!empty($stock_history)){
					// 	$history = array(
					// 		'stock_qty' => $new_stock,
					// 		'purchase_qty' => $stock_history->purchase_qty+$order_qtys[$key]
					// 	);
					// 	$this->Common_model->updateData('product_stock_history', $history, array('record_id' => $stock_history->record_id));

					// }else{
					// 	$history = array(
					// 		'stock_date' => $purchase_date,
					// 		'product_id' => $product_ids[$key],
					// 		'stock_qty' => $new_stock,
					// 		'purchase_qty' => $order_qtys[$key],
					// 	);
					// 	$this->Common_model->saveData('product_stock_history', $history);
					// }
				}
				$this->session->set_userdata('alertMsg', INSERT_MSG);
			} else {
				$this->session->set_userdata('alertMsg', INSERT_ERROR_MSG);
			}
		} else {
			// $this->delete_purchase_stock($update_id);
			$this->deleteStock($update_id);
			$purchase = $this->Common_model->findById('purchase_orders', array('purchase_id' => $update_id));
			$prefix = str_replace('-', '', $purchase_date);
			$maxPurschaseOrder = $this->Common_model->findMax('purchase_orders', array('prefix' => $prefix), 'purchase_no');
			$data['prefix'] = $prefix;
			$purchase_no = isset($maxPurschaseOrder) ? $maxPurschaseOrder->purchase_no + 1 : 1;
			if ($purchase->purchase_date == $purchase_date) {
				$data['purchase_no'] = $purchase->purchase_no;
			} else {
				$data['purchase_no'] = $purchase_no;
			}
			$update = $this->Common_model->updateData('purchase_orders', $data, array('purchase_id' => $update_id));
			if ($update) {
				foreach ($product_ids as $key => $value) {
					$purchaseDetails = array(
						'purchase_order_id' => $update_id,
						'product_id' => $product_ids[$key],
						'purchase_type' => $item_purchase_types[$key],
						'unit_id' => $unit_ids[$key],
						'unit_name' => $unit_names[$key],
						'unit_price' => $unit_prices[$key],
						'sales_price' => $sales_prices[$key],
						'whole_sales_price' => $whole_sales_prices[$key],
						'purchase_price' => $purchase_prices[$key],
						'order_qty' => $order_qtys[$key],
						'free_qty' => $free_qtys[$key],
						'tp_amount' => $tp_amounts[$key],
						'vat_amount' => $vat_amounts[$key],
						'discount_per_product' => $discount_per_products[$key],
						'discount_amount' => $discount_amounts[$key],
						'sub_total' => $sub_totals[$key],
						'net_total' => $net_totals[$key],
						'expired_date' => $expired_dates[$key],
						'purchase_date' => $purchase_date
						
					);
					$purchase_order_details_id = $purchase_order_details_ids[$key];
					$detailsId = $purchase_order_details_id;
					if ($purchase_order_details_id) {
						$this->Common_model->updateData('purchase_order_details', $purchaseDetails, array('purchase_order_details_id' => $purchase_order_details_id));
					} else {
						$detailsId = $this->Common_model->saveData('purchase_order_details', $purchaseDetails);
					}
					 
					$stock_info = $this->Common_model->findById('drug_medicine', array('record_id' => $product_ids[$key]));
					$new_stock = $stock_info->product_stock+$order_qtys[$key];
					$this->Common_model->updateData('drug_medicine', array('unit_price' => $unit_prices[$key], 'unit_mrp' => $sales_prices[$key], 'product_stock' => $new_stock), array('record_id' => $product_ids[$key]));

					$this->updateStock($product_ids[$key],$detailsId, $order_qtys[$key], $purchase_date, $unit_prices[$key],$purchase_prices[$key]);

					// $stock_history = $this->Common_model->findById('product_stock_history', array('product_id' => $product_ids[$key], 'stock_date' =>$purchase_date));
					
					// if(!empty($stock_history)){
					// 	$history = array(
					// 		'stock_qty' => $new_stock,
					// 		'purchase_qty' => $stock_history->purchase_qty+$order_qtys[$key]
					// 	);
					// 	$this->Common_model->updateData('product_stock_history', $history, array('record_id' => $stock_history->record_id));

					// }else{
					// 	$history = array(
					// 		'stock_date' => $purchase_date,
					// 		'product_id' => $product_ids[$key],
					// 		'stock_qty' => $new_stock,
					// 		'purchase_qty' => $order_qtys[$key],
					// 	);
					// 	$this->Common_model->saveData('product_stock_history', $history);
					// }
				}
				if ($update) {
					$this->session->set_userdata('alertMsg', UPDATE_MSG);
				} else {
					$this->session->set_userdata('alertMsg', UPDATE_ERROR_MSG);
				}
			}
			redirect("purchase_order/view2/$update_id");
		}
		redirect("purchase_order/view/$update_id");
	}

	public function edit($purchase_id)
	{
		$data['title'] = "Purchase Medicine/Products";
		$data['page_title'] = "Purchase Medicine/Products";
		$data['info_header'] = "";
		$data['value'] = $this->Common_model->findById('purchase_orders', array('purchase_id' => $purchase_id));
		$where = array('purchase_order_details.purchase_order_id ' => $purchase_id);
		$options = array(
			'joins' => array(
				array(
					'table' => 'units',
					'condition' => 'units.record_id = purchase_order_details.unit_id',
					'jointype' => 'LEFT'
				),
			),
			'select' => 'purchase_order_details.*,units.unit_short_name',
			'where' => $where,
			'order' => array(
				'purchase_order_details.purchase_order_details_id' => 'asc',
			),
		);
		$data['values'] = $this->Common_model->commonJoins("purchase_order_details", $options);
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/purchase_order/create', $data);
		$this->load->view('admin/layouts/footer');
	}
	public function view($purchase_id)
	{
		$data['title'] = "Purchase Invoice";
		$data['page_title'] = "Purchase Invoice";
		$data['info_header'] = "";
		$data['signatureType'] = 'Staff';
		$data['redirect'] = base_url('purchase_order/create');
		$data['value'] = $this->Common_model->findById('purchase_orders', array('purchase_id' => $purchase_id));
		$data['value']->record_id = $data['value']->purchase_id;
		$data['value']->date = $data['value']->purchase_date;
		$manufacturer = $this->Common_model->findById('drug_manufacturer', array( 'record_id' => $data['value']->supplier_id));
		$data['supplier'] = $manufacturer->manufacturer_name.'['.$manufacturer->record_id.']';
		$data['supplier_contact'] = !empty($manufacturer->contact_no) ? $manufacturer->contact_no : "";
		

		$where = array('purchase_order_details.purchase_order_id ' => $purchase_id);
		$options = array(
			'joins' => array(
				array(
					'table' => 'units',
					'condition' => 'units.record_id = purchase_order_details.unit_id',
					'jointype' => 'LEFT'
				),

			),
			'select' => 'purchase_order_details.*,units.unit_short_name',
			'where' => $where,
			'order' => array(
				'purchase_order_details.purchase_order_details_id' => 'asc',
			),
		);
		$data['values'] = $this->Common_model->commonJoins("purchase_order_details", $options);
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/purchase_order/invoice', $data);
		$this->load->view('admin/layouts/footer');
	}
	public function view2($purchase_id)
	{
		$data['title'] = "Purchase Invoice";
		$data['page_title'] = "Purchase Invoice";
		$data['info_header'] = "";
		$data['signatureType'] = 'Staff';
		$data['redirect'] = base_url('purchase_order');
		$data['value'] = $this->Common_model->findById('purchase_orders', array('purchase_id' => $purchase_id));
		$data['value']->record_id = $data['value']->purchase_id;
		$data['value']->date = $data['value']->purchase_date;
		$supplier = $this->Common_model->findById('suppliers', array( 'record_id' => $data['value']->supplier_id));
		$manufacturer = $this->Common_model->findById('drug_manufacturer', array( 'record_id' => $data['value']->supplier_id));
		$data['supplier'] = $manufacturer->manufacturer_name.'['.$manufacturer->record_id.']';
		$data['supplier_contact'] = !empty($manufacturer->contact_no) ? $manufacturer->contact_no : "";

		$where = array('purchase_order_details.purchase_order_id ' => $purchase_id);
		$options = array(
			'joins' => array(
				array(
					'table' => 'units',
					'condition' => 'units.record_id = purchase_order_details.unit_id',
					'jointype' => 'LEFT'
				),

			),
			'select' => 'purchase_order_details.*,units.unit_short_name',
			'where' => $where,
			'order' => array(
				'purchase_order_details.purchase_order_details_id' => 'asc',
			),
		);
		$data['values'] = $this->Common_model->commonJoins("purchase_order_details", $options);
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/purchase_order/invoice', $data);
		$this->load->view('admin/layouts/footer');
	}

	public function barcode($purchase_order_details_id)
	{
		$data['title'] = "Generate Barcode";
		$data['page_title'] = "Generate Barcode";
		$data['info_header'] = "";
		$data['signatureType'] = 'Staff';


		$where = array('purchase_order_details.purchase_order_details_id ' => $purchase_order_details_id);
		$options = array(
			'joins' => array(
				array(
					'table' => 'product_name',
					'condition' => 'product_name.record_id = purchase_order_details.product_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'generic_names',
					'condition' => 'generic_names.record_id = product_name.product_category_generic_name_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'units',
					'condition' => 'units.record_id = purchase_order_details.unit_id',
					'jointype' => 'LEFT'
				),

			),
			'select' => 'purchase_order_details.*,product_name.product_name,product_name.product_category,units.unit_short_name,generic_names.generic_name',
			'where' => $where,
			'order' => array(
				'purchase_order_details.purchase_order_details_id' => 'asc',
			),
		);
		$product = $this->Common_model->commonJoinsRow("purchase_order_details", $options);
		$data['redirect'] = base_url("purchase_order/view/$product->purchase_order_id");
		$data['product'] = $product;
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/purchase_order/barcode', $data);
		$this->load->view('admin/layouts/footer');
	}

	public function generate_barcode()
	{
		$purchase_order_details_id = $this->input->post('purchase_order_details_id');
		$product_id = $this->input->post('product_id');
		$data['code_no'] = $purchase_order_details_id . ' - ' . $product_id . '.jpg';
		$data['quantity'] = $this->input->post('quantity');
		$this->load->view('admin/purchase_order/barcode_list', $data);
	}

	public function delete($id)
	{
		$user_type = $this->session->ses_user_type;
		if ($user_type == "admin"  || $user_type == "staff") {
			// $this->delete_purchase_stock($id);
			$this->deleteStock($id);
			if ($this->Common_model->delete_info('purchase_id', $id, 'purchase_orders')) {
				$this->Common_model->delete_info('purchase_order_id', $id, 'purchase_order_details');
				$this->session->set_flashdata('message', DELETE_MSG);
			} else {
				$this->session->set_flashdata('message', DELETE_ERROR_MSG);
			}
			redirect('purchase_order', 'refresh');
		} else {
			$data['wrong_msg'] = "";
			$this->load->view('website/login_check', $data);
		}
	}

	public function load_product()
	{
		$purchase_type = $this->input->post('purchase_type');
		$supplier_id = $this->input->post('supplier_id');
		$warehouse = $this->input->post('warehouse');
			
		$option = "<option value=''>--Select $purchase_type--</option>";
		$products = $this->Common_model->getAllProduct($supplier_id, $purchase_type, $warehouse, 0);
		// ddd($products);
		$prodArr = [];
		$serializedArr = [];
		foreach($products as $prod){
			$prodArr[] = $prod->record_id;
			$serializedArr[$prod->record_id] = new stdClass();
			$serializedArr[$prod->record_id] = $prod;
		}
		$newProducts = [];
		if(sizeof($prodArr) > 0){
			//$newProducts = $this->db->select('*')->from('product_name_new')->where_in('product_id', $prodArr)->get()->result();

			foreach ($products as $newProd) {
				$value = new stdClass();
				if(isset($serializedArr[$newProd->record_id])){
					$value = $serializedArr[$newProd->record_id];
				}
				$product_category = !empty($value->dosage_name) ? ' - ' . $value->dosage_name : '';
				$generic_name = !empty($value->generic_name) ? ' - ' . $value->generic_name : '';
				$strength = !empty($value->strength) ? ' - ' . $value->strength : '';
				$dose = !empty($value->dosage_name) ? ' - ' . $value->dosage_name : '';
				$stock = !empty($value->product_stock) ? $value->product_stock : 0;
				$option .= '<option value="' . $newProd->record_id . '" data-product_name="' . $newProd->brand_name . $product_category . $generic_name . $strength . '" data-unit_price="' . $newProd->unit_price . '" data-unit_mrp="' . $newProd->unit_mrp . '" data-unit_id="1" data-unit_name="Pcs" data-product_code="' . $newProd->record_id . '" data-stock="' . $stock. '">' . $newProd->brand_name . $strength .$dose." - ".$newProd->record_id.'</option>';
			}
		}
	
		echo $option;
		exit;
	}

	public function delete_stock()
	{
		$id = $this->input->post('id');
		
		$order_info = $this->Common_model->findById('purchase_order_details', array('purchase_order_details_id' => $id));
		$stock_info = $this->Common_model->findById('drug_medicine', array('record_id' => $order_info->product_id));
		$new_stock = $stock_info->product_stock-$order_info->order_qty;
		$this->Common_model->updateData('drug_medicine', array('product_stock' => $new_stock), array('record_id' => $stock_info->record_id));

		$this->Common_model->delete_info('purchase_order_details_id', $id, 'purchase_order_details');
		$this->Common_model->deleteData('product_stocks', ['details_id'=>$id, 'type'=>'purchase']);
		//echo $new_stock;
		exit;
	}
	public function delete_purchase_stock($id)
	{
	$purchase_order_details = $this->Common_model->findAll('purchase_order_details',array('purchase_order_id'=>$id),'purchase_order_details_id','asc');
			foreach($purchase_order_details as $detail){
				$stock_info = $this->Common_model->findById('drug_medicine', array('record_id' => $detail->product_id));
				$new_stock = $stock_info->product_stock-$detail->order_qty;
				$this->Common_model->updateData('drug_medicine', array('product_stock' => $new_stock), array('record_id' => $stock_info->record_id));

				$this->Common_model->delete_info('purchase_order_details_id', $id, 'purchase_order_details');
				$this->Common_model->deleteData('product_stocks', ['details_id'=>$id, 'type'=>'purchase']);

			}
			//exit;
	}

	public function get_product() {
        $term = $this->input->get('term');
        $results = $this->Common_model->search_product($term);
        
        echo json_encode($results);
    }



	

	private function updateStock($productId,$detailsId, $qty, $date, $price=0,$salePrice=0){
	
		updateStock($productId,$detailsId, $qty, $date, 'purchase', $price,$salePrice,);
	}

	private function deleteStock($id){
		$purchase_order_details = $this->Common_model->findAll('purchase_order_details',['purchase_order_id'=>$id, ],'purchase_order_details_id','asc');
		foreach($purchase_order_details as $detail){
			deleteStock($detail->purchase_order_details_id, $detail->product_id);
		}
	}







	public function history_data_recovery(){
		$user_type = $this->session->ses_user_type;
		if ($user_type == "admin" ) {
			$this->db->trans_start();
			$this->db->truncate('product_stocks');
			$purchaseData = $this->db->select('*')->where('purchase_type', 'Medicine')->get('purchase_order_details')->result();
			foreach($purchaseData as $value){
				$data = [
					'created_by' 		=> $value->created_by,
					'created_at' 		=> $value->created_at,
					'product_id' 		=> $value->product_id,
					'details_id'		=> $value->purchase_order_details_id, 
					'type'				=> 'purchase',
					'quantity'			=> $value->order_qty,
					'price'				=> $value->unit_price,
					'sale_price'		=> $value->sales_price,
					'date'				=> $value->purchase_date
				];
				$this->db->insert('product_stocks',$data);
			}

			$salesData = $this->db->where('sales_type', 'Medicine')->get('sales_order_details')->result();

			foreach($salesData as $value){
				$data = [
					'created_by' 		=> $value->created_by,
					'created_at' 		=> $value->created_at,
					'product_id' 		=> $value->product_id,
					'details_id'		=> $value->sales_order_details_id , 
					'type'				=> 'sales',
					'quantity'			=> $value->order_qty,
					'price'				=> $value->purchase_price,
					'sale_price'		=> $value->sales_price,
					'date'				=> $value->sales_date
				];
				$this->db->insert('product_stocks',$data);
			}

			$returnData = $this->db->where('return_type', 'Medicine')->get('customer_return_details')->result();

			foreach($returnData as $value){
				$data = [
					'created_by' 		=> $value->created_by,
					'created_at' 		=> $value->created_at,
					'product_id' 		=> $value->product_id,
					'details_id'		=> $value->return_details_id, 
					'type'				=> 'sales_return',
					'quantity'			=> $value->return_qty,
					'price'				=> $value->return_price??$value->purchase_price,
					'sale_price'		=> $value->sales_price,
					'date'				=> $value->return_date
				];
				$this->db->insert('product_stocks',$data);
			}

		

			$this->db->trans_complete();

			dd('Successful data recovery complete');
		}
	}



	


	function recovery_data() {
    if ($this->session->ses_user_type !== "admin") return;

    $this->db->trans_start();

    $query = $this->db->query("
        SELECT 
            dm.record_id,

            COALESCE(p.purchase_qty, 0) as purchase_qty,
            COALESCE(s.sales_qty, 0) as sales_qty,
            COALESCE(r.return_qty, 0) as return_qty,
            COALESCE(sr.sales_return_qty, 0) as sales_return_qty

        FROM drug_medicine dm

        LEFT JOIN (
            SELECT product_id, SUM(order_qty) as purchase_qty
            FROM purchase_order_details
            GROUP BY product_id
        ) p ON p.product_id = dm.record_id

        LEFT JOIN (
            SELECT product_id, SUM(order_qty) as sales_qty
            FROM sales_order_details
            GROUP BY product_id
        ) s ON s.product_id = dm.record_id

        LEFT JOIN (
            SELECT product_id, SUM(return_qty) as return_qty
            FROM return_details
            GROUP BY product_id
        ) r ON r.product_id = dm.record_id

        LEFT JOIN (
            SELECT product_id, SUM(return_qty) as sales_return_qty
            FROM customer_return_details
            GROUP BY product_id
        ) sr ON sr.product_id = dm.record_id

        WHERE dm.type = 'Medicine'
    ")->result();

    $negativeStock = [];

    foreach ($query as $row) {
        $currentStock = ($row->purchase_qty + $row->sales_return_qty) 
                        - ($row->sales_qty + $row->return_qty);

        $this->db->where('record_id', $row->record_id)
                 ->update('drug_medicine', ['product_stock' => $currentStock]);

        if ($currentStock < 0) {
            $negativeStock[$row->record_id] = $currentStock;
        }
    }

    $this->db->trans_complete();

    if (!empty($negativeStock)) {
		 $this->db->trans_start();
		foreach($negativeStock as $productId=>$value){
			 $this->db->where('product_id', $productId)->delete('purchase_order_details');
			 $this->db->where('product_id', $productId)->delete('sales_order_details');
		}
		 $this->db->trans_complete();
        dd($negativeStock);
    }

    dd('Successful data recovery complete');
}

}
