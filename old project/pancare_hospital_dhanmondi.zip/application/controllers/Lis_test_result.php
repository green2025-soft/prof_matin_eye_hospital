<?php

class Lis_test_result extends MY_Controller
{

    protected $title = 'Lis Test Result';
     protected $bUrl = 'lis_test_result';
    
    public function __construct()
    {
        parent::__construct();
        $this->loadModel('LisTestResult_model');
    }

    protected function laoute($pageName) {
        $this->render('lis_test_result/'.$pageName);
    }

    public function index()
	{
        $toDate     = date('Y-m-d');
        $from_date  = $this->input->get('from_date')?? $toDate ;
        $to_date    = $this->input->get('to_date')?? $toDate ;
	
		$allData = $this->model->orderDesc()->where('DATE(created_at) >=',  $from_date)
        ->where('DATE(created_at) <=',  $to_date)->get();
        $this->model->belongsTo($allData, 'sample_id', 'create_bill', 'record_id', 'invoice');
        $this->model->withSingle($allData,'invoice','patient_id', 'patient', 'record_id');
        $this->model->withSingle($allData,'invoice','doctor_id', 'doctor', 'record_id');
          
        

		$this->data = [
			 'title'     		=> $this->title.' List',
			 'values'			=> $allData,
             'from_date'        => $from_date,
             'to_date'          => $to_date,
		];
		
		$this->laoute('index');
	}

    public function edit($id){
        $objData 	= $this->model->find($id);
       
         $this->model->belongsToSingle($objData, 'sample_id', 'create_bill', 'record_id', 'invoice');
        $invoice =  $objData->invoice;
        $this->model->belongsToSingle($invoice, 'patient_id', 'patient', 'record_id');
        $this->model->belongsToSingle($invoice, 'doctor_id', 'doctor', 'record_id');
         $doctor = $invoice->doctor;
        $this->model->belongsToSingle($doctor, 'designation_id', 'designation', 'record_id');

        $last_result = $this->Common_model->findFirstOrLast('test_reports', [], 'record_id', 'desc');

        $testsJson  = $objData->tests;
        $tests      = $this->getTestDecode($testsJson);

        $testsObjects = array_map(function($item) {
            return (object) $item;
        }, $tests);
        
       

          $this->data = [
			 'title'     		=> $this->title,
			 'objData'			=> $objData,
             'invoice'          => $invoice,
			 'patientData'	    => $invoice->patient??'',
             'doctor'           => $doctor,
            'tests'             => $testsObjects,
		];

        $this->data['duty_doctor_id'] = isset($last_result) ? $last_result->duty_doctor_id : 0;
        $this->data['duty_staff_id'] = isset($last_result) ? $last_result->duty_staff_id : 0;
        $this->data['duty_staff_id2'] = isset($last_result) ? $last_result->duty_staff_id2 : 0;
		
		$this->laoute('edit');
    }

    public function update(){
        $request    = $this->input->post();
        $id         = $request['id'];
        $invoice_id = $request['invoice_id'];
        $objData 	= $this->model->find($id);
        $testsJson  = $objData->tests;
        $tests_1      = $this->getTestDecode($testsJson);
        $testsObjects = array_map(function($item) {
            return (object) $item;
        }, $tests_1);
        $tests      = $testsObjects;

        $listData = [
            'sample_id'         => $request['sample_id'],
            'sig_staff_id'      => $request['duty_staff_id'],
            'sig_staff2_id'     => $request['duty_staff_id2'],
            'sig_doctor_id'     => $request['duty_doctor_id'],
            'test_category_id'  => $request['test_category_id'],
            'specimen'          => $request['specimen'],
        ];

        $resultArray = $request['result']; 
        $nameArray = $request['name']; 
        $unitArray = $request['unit']; 
        $referenceArray = $request['reference']; 
        $testCodeArray = $request['test_code'];
        $remove = $request['remove'];
        if($tests && !empty($resultArray)) {
            foreach ($tests as $key => $test) {
                if(isset($testCodeArray[$key]) && $test->test_code == $testCodeArray[$key]) {
                    if(!isset($remove[$key])){
                        unset($tests[$key]);
                         continue;
                    }
                    $tests[$key]->result_value = str_ireplace('^', '', $resultArray[$key]);
                    $tests[$key]->test_name = $nameArray[$key];
                    $tests[$key]->unit = $unitArray[$key];
                    $tests[$key]->reference_range = $referenceArray[$key];
                }
            }
        }
        
        

        $listData['tests'] = json_encode($tests);

        $this->model->update($id, $listData);


         $this->session->set_flashdata('message',UPDATE_MSG);
         redirect($this->bUrl."/view/$id");
    }

    private function getTestDecode($test = '')
    {
        if (empty($test)) {
            return [];
        }

        // Remove extra quotes
        $test = trim($test);
        if ($test[0] === '"' && substr($test, -1) === '"') {
            $test = trim($test, '"');
        }

        // Remove slashes
        $test = stripslashes($test);

        $decoded = json_decode($test, true);

        return is_array($decoded) ? $decoded : [];
    }

    private function processCBC(array $tests)
    {
        $cbc = [];
        $platelet = [];
        $diff = [];
        $flags = [];
        $otherTests = [];
        $esr = null;

        $addedCodes = [];

        foreach ($tests as $row) {

            if (!isset($row['test_code'], $row['test_name'])) {
                continue;
            }

            $code = explode('^^', $row['test_code'])[0];
            $name = explode('^^', $row['test_name'])[0];

            if (
                strpos($row['test_code'], '-IM') !== false ||
                stripos($row['test_name'], 'Histogram') !== false ||
                stripos($row['test_name'], 'Scattergram') !== false ||
                stripos($row['test_name'], 'Meta') !== false
            ) {
                continue;
            }

            $item = [
                'code'  => $code,
                'name'  => $name,
                'value' => $row['result_value'] ?? '',
                'unit'  => str_replace('&S&', '^', $row['unit'] ?? ''),
                'range' => str_replace('^', ' – ', $row['reference_range'] ?? ''),
                'flag'  => explode('^^', $row['flag'] ?? '')[0]
            ];

            if (in_array($code, ['WBC','RBC','HGB','HCT','MCV','MCH','MCHC','RDW-CV','RDW-SD'])) {
                if (!in_array($code, $addedCodes)) {
                    $cbc[] = $item;
                    $addedCodes[] = $code;
                }
                continue;
            }

            if (in_array($code, ['PLT','MPV','PDW','PCT'])) {
                $platelet[] = $item;
                continue;
            }

            // =====================
            // DIFFERENTIAL
            // =====================
            if (in_array($code, [
                'NEU%','LYM%','MON%','EOS%','BAS%',
                'NEU#','LYM#','MON#','EOS#','BAS#'
            ])) {
                $diff[] = $item;
                continue;
            }

            // =====================
            // ESR
            // =====================
            if (strtoupper($code) === 'ESR') {
                $esr = $item;
                continue;
            }

            // =====================
            // FLAGS / ABNORMAL
            // =====================
            if (($row['result_value'] ?? '') === 'T') {
                $flags[] = $name;
            }

            // =====================
            // OTHER TESTS
            // =====================
            $otherTests[] = (object)$item;
        }

        return [
            'cbc'        => $cbc,
            'platelet'   => $platelet,
            'diff'       => $diff,
            'flags'      => array_unique($flags),
            'esr'        => $esr,
            'others' => $otherTests
        ];
    }


    public function view($id)
    {
        $objData = $this->model->find($id);

        // =====================
        // Relations
        // =====================
        $this->model->belongsToSingle($objData, 'sig_staff_id', 'staff', 'record_id');
        $this->model->belongsToSingle($objData, 'sig_staff2_id', 'staff', 'record_id', 'staff2');
        $this->model->belongsToSingle($objData, 'test_category_id', 'test_category', 'record_id', 'test_category');
        $this->model->belongsToSingle($objData, 'sample_id', 'create_bill', 'record_id', 'invoice');

        $invoice = $objData->invoice;
        $this->model->belongsToSingle($invoice, 'patient_id', 'patient', 'record_id');
        $this->model->belongsToSingle($invoice, 'doctor_id', 'doctor', 'record_id', 'refDoctor');
        $this->model->belongsToSingle($objData, 'sig_doctor_id', 'doctor', 'record_id');
        
        $refDoctor  = $invoice->refDoctor;
        $doctor     = $objData->doctor;
        $this->model->belongsToSingle($doctor, 'designation_id', 'designation', 'record_id');
        $this->model->belongsToSingle($refDoctor, 'designation_id', 'designation', 'record_id');

        // =====================
        // Decode Tests
        // =====================
        $testsRaw = $this->getTestDecode($objData->tests);

        // =====================
        // Detect CBC Machine
        // =====================
        $isCBC = ( !empty($objData->machine_id) && trim($objData->machine_id) === '127.0.0.1, Mindray BC-760' );

        // =====================
        // Decide layout
        // =====================
        $layout = 'report_print'; // default

        // =====================
        // CBC → NEW LOGIC
        // =====================
        if ($isCBC) {

            $cbcData = $this->processCBC($testsRaw);

            $this->data['cbc']        = $cbcData['cbc'];
            $this->data['platelet']   = $cbcData['platelet'];
            $this->data['diff']       = $cbcData['diff'];
            $this->data['flags']      = $cbcData['flags'];
            $this->data['reportType'] = 'CBC';

            // Use CBC layout
            $layout = 'report_print_cbc';
        }
        // =====================
        // OTHERS → OLD LOGIC
        // =====================
        else {

            // Convert associative array to object for old layout
            $testsObjects = array_map(function($item) {
                return (object) $item;
            }, $testsRaw);

            $this->data['tests']      = $testsObjects;
            $this->data['reportType'] = 'OTHERS';
            $layout = 'report_print';
        }

        // =====================
        // Common View Data
        // =====================
        $objData->staff_name         = $objData->staff->name ?? '';
        $objData->staff_designation  = $objData->staff->designation ?? '';
        $objData->staff_name2        = $objData->staff2->name ?? '';
        $objData->staff2_designation = $objData->staff2->designation ?? '';
        $objData->duty_doc_name      = $doctor->name ?? '';
        $objData->duty_doc_designation = $doctor->designation->designation ?? '';
       

        $testCategory = $objData->test_category;
        $category = fn($key) => $testCategory ? $testCategory->$key : '';

        $this->data['title']        = $this->title;
        $this->data['analyzerName'] = $category('analyzer_name') ?: $objData->analyzer_name;
        $this->data['reportTitle']  = $category('report_header') ?: 'Test Report ';

        $this->data['objData']      = $objData;
        $this->data['invoice']      = $invoice;
        $this->data['doctor']       = $refDoctor;
        $this->data['testDetails']  = $objData;
        $this->data['machine_id']   = $objData->machine_id;

        // =====================
        // Load final layout
        // =====================
        $this->laoute($layout);
    }

}
