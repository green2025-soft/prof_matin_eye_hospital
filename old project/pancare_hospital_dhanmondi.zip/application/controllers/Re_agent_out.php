<?php

defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Re_agent_out extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
    }
    public function index()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Allocated Product Out List';
            $data['page_title'] = 'Allocated Product Out List';
            $data['info_header'] = 'Allocated Product Out List';

            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            if (!isset($from_date) && !isset($to_date)) {
                $from_date = $to_date = date('Y-m-d');
            }
            $where = array();
            if (!admin()) {
                $where['show_hide'] = 'Show';
            }
            if (!empty($from_date) && !empty($to_date)) {
                $where['out_date >= '] = $from_date;
                $where['out_date <= '] = $to_date;
            } elseif (!empty($from_date) && empty($to_date)) {
                $where['out_date'] = $from_date;
            } elseif (empty($from_date) && !empty($to_date)) {
                $where['out_date'] = $to_date;
            }
            $data['values'] = $this->Common_model->findAll("re_agent_out", $where, "record_id", "desc");
            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/re_agent_out/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function create()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Allocated Product Out';
            $data['page_title'] = 'Allocated Product Out';
            $data['info_header'] = 'Allocated Product Out';
            $data['in_values'] = $this->Common_model->findAll('re_agent_out', array(), 'record_id', 'desc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/re_agent_out/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function edit($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Allocated Product Out';
            $data['page_title'] = 'Allocated Product Out';
            $data['info_header'] = 'Allocated Product Out';
            $data['value'] = $this->Common_model->findById('re_agent_out', array('record_id' => $record_id));
            $data['staff'] = $this->Common_model->findById('staff', array('record_id' => $data['value']->staff_id));
            // $data['values'] = $this->Common_model->findAll('re_agent_out_details', array('re_agent_out_id' => $record_id), 'record_id', 'asc');
            $data['values'] = $this->Common_model->getReAgentOutProducts($record_id);
            // ddd($data['values']);
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/re_agent_out/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function view($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Allocated Product Out';
            $data['page_title'] = 'Allocated Product Out';
            $data['info_header'] = 'Allocated Product Out';
            $data['redirect'] = base_url('re_agent_out/create');
            $data['signatureType'] = "Staff";
            $data['value'] = $this->Common_model->findById('re_agent_out', array('record_id' => $record_id));
            $data['staff'] = $this->Common_model->findById('staff', array('record_id' => $data['value']->staff_id));
            $data['values'] = $this->Common_model->findAll('re_agent_out_details', array('re_agent_out_id' => $record_id), 'record_id', 'asc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/re_agent_out/invoice', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function view2($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Allocated Product Out';
            $data['page_title'] = 'Allocated Product Out';
            $data['info_header'] = 'Allocated Product Out';
            $data['redirect'] = base_url('re_agent_out/create');
            $data['signatureType'] = "Staff";
            $data['value'] = $this->Common_model->findById('re_agent_out', array('record_id' => $record_id));
            $data['staff'] = $this->Common_model->findById('staff', array('record_id' => $data['value']->staff_id));
            $data['values'] = $this->Common_model->findAll('re_agent_out_details', array('re_agent_out_id' => $record_id), 'record_id', 'asc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/re_agent_out/invoice', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST;
            $update_id = $input['update_id'];
            $record_ids = $input['record_id'];
            $product_ids = $input['product_id'];
            $category_ids = $input['category_id'];
            $quantitys = $input['quantity'];

            unset($input['update_id']);
            unset($input['record_id']);
            unset($input['product_id']);
            unset($input['quantity']);
            unset($input['category_id']);
            unset($input['product_category']);

            $out_date = $input['out_date'];

            $prefix = str_replace('-', '', $out_date);

            $max = $this->Common_model->findMax('re_agent_out', array('prefix' => $prefix), 'out_no');
            $out_no = isset($max) ? $max->out_no + 1 : 1;

            $input['prefix'] = $prefix;
            $input['out_no'] = $out_no;

            if ($update_id == 0 || empty($update_id)) {
                $insert = $this->Common_model->saveData('re_agent_out', $input);
               
                if ($insert) {
                    foreach ($record_ids as $key => $value) {
                        $data = array(
                            're_agent_out_id' => $insert,
                            'staff_id' => $input['staff_id'],
                            'out_date' => $out_date,
                            'category_id' => $category_ids[$key],
                            'product_id' => $product_ids[$key],
                            'quantity' => $quantitys[$key],
                        );
                        $this->Common_model->saveData('re_agent_out_details', $data);
                    }
                
                    $this->session->set_flashdata('message', INSERT_MSG);
                } else {
                    $this->session->set_flashdata('message', INSERT_ERROR_MSG);
                }
            } else {
                $info = $this->Common_model->findById('re_agent_out', array('record_id' => $update_id));
                if ($info->out_date == $out_date) {
                    $input['out_no'] = $info->out_no;
                }
                $update = $this->Common_model->updateData('re_agent_out', $input, array('record_id' => $update_id));
                if ($update) {
                    foreach ($record_ids as $key => $value) {
                        $data = array(
                            're_agent_out_id' => $update_id,
                            'staff_id' => $input['staff_id'],
                            'out_date' => $out_date,
                            'category_id' => $category_ids[$key],
                            'product_id' => $product_ids[$key],
                            'quantity' => $quantitys[$key],
                        );
                        if ($value) {
                            $this->Common_model->updateData('re_agent_out_details', $data, array('record_id' => $value));
                        } else {
                            $this->Common_model->saveData('re_agent_out_details', $data);
                        }

                        
                    }

                    $this->session->set_flashdata('message', UPDATE_MSG);
                } else {
                    $this->session->set_flashdata('message', UPDATE_ERROR_MSG);
                }
            }
            redirect('re_agent_out', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            $re_agent_out = $this->Common_model->findById('re_agent_out', array('record_id' => $id));
            if ($this->Common_model->delete_info('record_id', $id, 're_agent_out')) {
                $this->Common_model->delete_info('re_agent_out_id', $id, ' re_agent_out_details');
                
                $this->session->set_flashdata('message', DELETE_MSG);
            } else {
                $this->session->set_flashdata('message', DELETE_ERROR_MSG);
            }
            redirect('re_agent_out', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
   

 

    public function load_staff_product()
    {
        $staff_id = $this->input->post('staff_id');
        $category_id = $this->input->post('category_id');

       
        //$products = $this->Common_model->findAll('product_name', array('product_category_generic_name_id' => $category_id, 'warehouse' => 'lab'), "record_id", "asc");
        $products = $this->Common_model->get_staff_product($staff_id, $category_id);
        if($products){
            echo '<option value="">Select Product</option>';
        foreach($products as $product){
            echo '<option value="'.$product->productid.'">'.$product->code_no.'-'.$product->product_name.'</option>';
        }
        }
       
    }
}
