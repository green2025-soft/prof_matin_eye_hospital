<?php

defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Re_agent_in extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
    }
    public function index()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Product Allocation List';
            $data['page_title'] = 'Product Allocation List';
            $data['info_header'] = 'Product Allocation List';

            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            if (!isset($from_date) && !isset($to_date)) {
                $from_date = $to_date = date('Y-m-d');
            }
            $where = array();
            if (!admin()) {
                $where['show_hide'] = 'Show';
            }
            if (!empty($from_date) && !empty($to_date)) {
                $where['in_date >= '] = $from_date;
                $where['in_date <= '] = $to_date;
            } elseif (!empty($from_date) && empty($to_date)) {
                $where['in_date'] = $from_date;
            } elseif (empty($from_date) && !empty($to_date)) {
                $where['in_date'] = $to_date;
            }
            $data['values'] = $this->Common_model->findAll("re_agent_in", $where, "record_id", "desc");
            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/re_agent_in/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function create()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Product Allocation';
            $data['page_title'] = 'Product Allocation';
            $data['info_header'] = 'Product Allocation   ';
            $data['in_values'] = $this->Common_model->findAll('re_agent_in', array(), 'record_id', 'desc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/re_agent_in/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function edit($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Product Allocation';
            $data['page_title'] = 'Product Allocation';
            $data['info_header'] = 'Product Allocation';
            $data['value'] = $this->Common_model->findById('re_agent_in', array('record_id' => $record_id));
            $data['staff'] = $this->Common_model->findById('staff', array('record_id' => $data['value']->staff_id));
            // $data['values'] = $this->Common_model->findAll('re_agent_in_details', array('re_agent_in_id' => $record_id), 'record_id', 'asc');
            $data['values'] = $this->Common_model->getReAgentInProducts($record_id);
            // ddd($data['values']);
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/re_agent_in/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function view($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Product Allocation';
            $data['page_title'] = 'Product Allocation';
            $data['info_header'] = 'Product Allocation';
            $data['redirect'] = base_url('lab_product_in/create');
            $data['signatureType'] = "Staff";
            $data['value'] = $this->Common_model->findById('re_agent_in', array('record_id' => $record_id));
            $data['staff'] = $this->Common_model->findById('staff', array('record_id' => $data['value']->staff_id));
            $data['values'] = $this->Common_model->findAll('re_agent_in_details', array('re_agent_in_id' => $record_id), 'record_id', 'asc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/re_agent_in/invoice', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function view2($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Product Allocation';
            $data['page_title'] = 'Product Allocation';
            $data['info_header'] = 'Product Allocation';
            $data['redirect'] = base_url('re_agent_in');
            $data['signatureType'] = "Staff";
            $data['value'] = $this->Common_model->findById('re_agent_in', array('record_id' => $record_id));
            $data['staff'] = $this->Common_model->findById('staff', array('record_id' => $data['value']->staff_id));
            $data['values'] = $this->Common_model->findAll('re_agent_in_details', array('re_agent_in_id' => $record_id), 'record_id', 'asc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/re_agent_in/invoice', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST;
            $update_id = $input['update_id'];
            $record_ids = $input['record_id'];
            $product_ids = $input['product_id'];
            $category_ids = $input['category_id'];
            $quantitys = $input['quantity'];

            unset($input['update_id']);
            unset($input['record_id']);
            unset($input['product_id']);
            unset($input['quantity']);
            unset($input['category_id']);
            unset($input['product_category']);

            $in_date = $input['in_date'];

            $prefix = str_replace('-', '', $in_date);

            $max = $this->Common_model->findMax('re_agent_in', array('prefix' => $prefix), 'in_no');
            $in_no = isset($max) ? $max->in_no + 1 : 1;

            $input['prefix'] = $prefix;
            $input['in_no'] = $in_no;

            if ($update_id == 0 || empty($update_id)) {
                $insert = $this->Common_model->saveData('re_agent_in', $input);
               
                if ($insert) {
                    foreach ($record_ids as $key => $value) {
                        $data = array(
                            're_agent_in_id' => $insert,
                            'staff_id' => $input['staff_id'],
                            'in_date' => $in_date,
                            'category_id' => $category_ids[$key],
                            'product_id' => $product_ids[$key],
                            'quantity' => $quantitys[$key],
                        );
                        $this->Common_model->saveData('re_agent_in_details', $data);
                    }

                    if(sizeof($product_ids) > 0 ){

                        $out_date = date("Y-m-d");
                        $prefix = str_replace('-', '', $out_date);
            
                        $max = $this->Common_model->findMax('lab_product_out', array('prefix' => $prefix), 'out_no');
                        $out_no = isset($max) ? $max->out_no + 1 : 1;
                        $productOutData = [];
                        $productOutData['allocation_id'] = $insert;
                        $productOutData['out_date'] = $out_date;
                        $productOutData['prefix'] = $prefix;
                        $productOutData['out_no'] = $out_no;
                        $productOutData['grand_quantity'] = array_sum($quantitys);
                        $productOutData['comments'] = 'Sub-Store In';
                        $productOutData['created_by'] = $this->session->userData('ses_record_id');
                        $this->db->insert('lab_product_out', $productOutData);
    
                        $labProductOutID = $this->db->insert_id();
    
                        for($i = 0; $i< sizeof($product_ids); $i++){
    
                            $labProdOutDetailsData = [];
                            $labProdOutDetailsData['lab_product_out_id'] = $labProductOutID;
                            $labProdOutDetailsData['allocation_id'] = $insert;
                            $labProdOutDetailsData['category_id'] = $category_ids[$i];
                            $labProdOutDetailsData['out_date'] = date("Y-m-d");
                            $labProdOutDetailsData['product_id'] = $product_ids[$i];
                            $labProdOutDetailsData['quantity'] = $quantitys[$i];
                            $labProdOutDetailsData['unit_price'] = 0;
                            $labProdOutDetailsData['total_price'] = 0;
                            $labProdOutDetailsData['created_by'] = $this->session->userData('ses_record_id');
    
                            $this->db->insert('lab_product_out_details', $labProdOutDetailsData);
                        }
    
                    }
                    $this->session->set_flashdata('message', INSERT_MSG);
                } else {
                    $this->session->set_flashdata('message', INSERT_ERROR_MSG);
                }
            } else {
                $info = $this->Common_model->findById('re_agent_in', array('record_id' => $update_id));
                if ($info->in_date == $in_date) {
                    $input['in_no'] = $info->in_no;
                }
                $update = $this->Common_model->updateData('re_agent_in', $input, array('record_id' => $update_id));
                if ($update) {
                    $this->db->delete('re_agent_in_details', ['re_agent_in_id' => $update_id]);

                    foreach ($record_ids as $key => $value) {
                        $data = array(
                            're_agent_in_id' => $update_id,
                            'staff_id' => $input['staff_id'],
                            'in_date' => $in_date,
                            'category_id' => $category_ids[$key],
                            'product_id' => $product_ids[$key],
                            'quantity' => $quantitys[$key],
                        );
                        $this->Common_model->saveData('re_agent_in_details', $data);
                        if ($value) {
                            $this->Common_model->updateData('re_agent_in_details', $data, array('record_id' => $value));
                        } else {
                            $this->Common_model->saveData('re_agent_in_details', $data);
                        }

                    // $this->Common_model->deleteData('lab_product_out',array('allocation_id'=>$update_id));
                    // $this->Common_model->deleteData('lab_product_out_details',array('allocation_id'=>$update_id));

                        if(sizeof($product_ids) > 0 ){
                            $out_date = date("Y-m-d");
                            $prefix = str_replace('-', '', $out_date);
                
                            $max = $this->Common_model->findMax('lab_product_out', array('prefix' => $prefix), 'out_no');
                            $out_no = isset($max) ? $max->out_no + 1 : 1;
                            $productOutData = [];
                            $productOutData['allocation_id'] = $update;
                            $productOutData['out_date'] = $out_date;
                            $productOutData['prefix'] = $prefix;
                            $productOutData['out_no'] = $out_no;
                            $productOutData['grand_quantity'] = array_sum($quantitys);
                            $productOutData['comments'] = 'Sub-Store In';
                            $productOutData['created_by'] = $this->session->userData('ses_record_id');
                            $this->db->insert('lab_product_out', $productOutData);
        
                            $labProductOutID = $this->db->insert_id();
        
                            for($i = 0; $i< sizeof($product_ids); $i++){
        
                                $labProdOutDetailsData = [];
                                $labProdOutDetailsData['lab_product_out_id'] = $labProductOutID;
                                $labProdOutDetailsData['allocation_id'] = $update;
                                $labProdOutDetailsData['category_id'] = $category_ids[$i];
                                $labProdOutDetailsData['out_date'] = date("Y-m-d");
                                $labProdOutDetailsData['product_id'] = $product_ids[$i];
                                $labProdOutDetailsData['quantity'] = $quantitys[$i];
                                $labProdOutDetailsData['unit_price'] = 0;
                                $labProdOutDetailsData['total_price'] = 0;
                                $labProdOutDetailsData['created_by'] = $this->session->userData('ses_record_id');
        
                                $this->db->insert('lab_product_out_details', $labProdOutDetailsData);
                            }
        
                        }
                    }

                    $this->session->set_flashdata('message', UPDATE_MSG);
                } else {
                    $this->session->set_flashdata('message', UPDATE_ERROR_MSG);
                }
            }
            redirect('re_agent_in', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function in_out()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Product In/Out';
            $data['page_title'] = 'Product In/Out';
            $data['info_header'] = 'All Product In/Out';

            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $product_id = $this->input->get('product_id');
            $transaction_type = $this->input->get('transaction_type');

            $where = array();

            if (!isset($from_date) && !isset($to_date) && !isset($product_id) && !isset($transaction_type)) {
                $where['date'] = date('Y-m-d');
            }

            if ($product_id) $where['record_id'] = $product_id;

            if (!empty($from_date) && !empty($to_date)) {
                $where['date >= '] = $from_date;
                $where['date <= '] = $to_date;
            } elseif (!empty($from_date) && empty($to_date)) {
                $where['date'] = $from_date;
            } elseif (empty($from_date) && !empty($to_date)) {
                $where['date'] = $to_date;
            }

            $data['values'] = $this->Common_model->findAllGroupBySum('lab_product_use_in', $where, 'product_id', 'qty');
            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;
            $data['product_id'] = $product_id;
            $data['transaction_type'] = $transaction_type;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/lab_product/in_out', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            $re_agent_in = $this->Common_model->findById('re_agent_in', array('record_id' => $id));
            if ($this->Common_model->delete_info('record_id', $id, 're_agent_in')) {
                $this->Common_model->delete_info('re_agent_in_id', $id, ' re_agent_in_details');
                $this->Common_model->deleteData('lab_product_out',array('allocation_id'=>$id));
                    $this->Common_model->deleteData('lab_product_out_details',array('allocation_id'=>$id));
                
                //$this->Common_model->updateData('purchase_request', array('status' => "Approved"), array('record_id' => $lab_product_id->purchase_request_id));
                //$this->Common_model->updateData('purchase_request_details', array('status' => "Approved"), array('purchase_request_id' => $lab_product_id->purchase_request_id));
                $this->session->set_flashdata('message', DELETE_MSG);
            } else {
                $this->session->set_flashdata('message', DELETE_ERROR_MSG);
            }
            redirect('re_agent_in', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function load_products()
    {
        $purchase_request_id = $this->input->post('purchase_request_id');
        $data['value'] = $this->Common_model->findById('purchase_request', array('record_id' => $purchase_request_id));
        $data['values'] = $this->Common_model->findAll('purchase_request_details', array('purchase_request_id' => $purchase_request_id), "record_id", "asc");
        $this->load->view("admin/lab_product_in/product_list", $data);
    }

    public function approved($record_id)
    {
        $bill = $this->Common_model->findById('lab_product_in', array('record_id' => $record_id));
        if (isset($bill)) {
            $status = '';
            if ($bill->approval == 'Unpaid') {
                $status = 'paid';
            } else {
                $status = 'Unpaid';
            }
            $this->Common_model->updateData('lab_product_in', array('approval' => $status), array('record_id' => $record_id));
            $this->Common_model->updateData('lab_product_in_details', array('approval' => $status), array('purchase_request_id' => $record_id));
            $this->session->set_flashdata('message', UPDATE_MSG);
        } else {
            $this->session->set_flashdata('message', UPDATE_ERROR_MSG);
        }
        // redirect('test_honorarium/appointment', 'refresh');
        redirect($_SERVER['HTTP_REFERER']);
    }
}
