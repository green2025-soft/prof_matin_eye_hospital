<?php

defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Forbidden extends CI_Controller
{
    
    public function __construct()
    {
        parent::__construct();
    }
    
    public function index()
    {
        $data = [
            'title' => '403 Forbidden',
        ];
        
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/403_view');
        $this->load->view('admin/layouts/footer');
       
    }
}