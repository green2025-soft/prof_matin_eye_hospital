<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Home extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->helper('text');
    }

    public function home(){
        $data['title']          = "Home";
        $data['active']         = $data['title'];
        $output['page_title']   = $data['title'];

    $data['content'] = $this->load->view('website/home', $output, true);

        $this->load->view('website/layouts/master',$data);
    }
    public function index() {
        $data['title'] = "Home";
        $data['active'] = 'Home';
        $output['page_title'] = "Home";

        $type = $this->session->userdata('__selected_center__');
        $serviceType = $type =='ivf'?'Yes':'No';
        $output['specialists'] = $this->Common_model->findAll("specialists",array(),'record_id','asc') ;
        $output['sliders'] = $this->Common_model->findAll("sliders",array('types'=>$type),'record_id','asc') ;
        // dd($output);
        $output['departments'] = $this->Common_model->findAll('department',array("published"=>"Yes", 'types'=>$type),'record_id','desc');
        $output['services'] = $this->Common_model->findAll('services',array('is_featured'=>'Yes', 'is_ivf'=>$serviceType),'record_id','desc');
        $output['all_doctors'] = $this->Common_model->findAll('doctor',array('website_show'=>1, 'types'=>$type),'record_id','asc');
        $output['news'] = $this->Common_model->findAll('news',array('is_featured'=>'Yes', 'types'=>$type),'record_id','desc');
       // var_dump($output['news']);die;
        $output['hospital_rooms'] = $this->Common_model->countAll('beds',array()) ;
        $output['total_doctor'] = $this->Common_model->countAll('doctor',array()) ;
        $output['total_patient'] = $this->Common_model->countAll('patient',array()) ;
        $data['content'] = $this->load->view('website/layouts/home',$output,TRUE);
        $this->load->view('website/layouts/master',$data);
    }
/*     public function index() {
        $this->load->model('Common_model');        
        $this->load->model('Counter_model');
        $counter_value=$this->Counter_model->get_counter_value();
        foreach($counter_value as $value){
           $total=$value->count;
           if($total == 0){
                $this->Counter_model->update_counter_value(1);
                $sescounter = array('hit_counter' => $total);
                $this->session->set_userdata($sescounter);
           }
           else{
                $one_count=$total+1;
                $sescounter = array('hit_counter' => $total);
                $this->session->set_userdata($sescounter);
                $this->Counter_model->update_counter_value($one_count);
           } 
        } 
        $data['all_photo'] = $this->Common_model->findAll('photo_gallery',array(),'record_id','desc');
        $data['all_value']=$this->Common_model->findAll('single_page_content',array(),'record_id','desc');
        $data['sliders']=$this->Common_model->findAll('sliders',array(),'record_id','desc');
        $data['serviceList']=$this->Common_model->get_all_info_limit('test_price',4);
        $this->load->view('website/header');
        $this->load->view('website/home', $data);
        $this->load->view('website/footer');
    } */

    public function load_doctor()
    {
        
        $speciality = $this->input->post('speciality') ;
        $where['specialists like'] = '%'.$speciality.'%' ;
        $doctors = $this->Common_model->findAll('doctor',$where,'record_id','desc');
        $options = "<option value=''>Select Doctor</option>";
        foreach ($doctors as $key => $value) {
            $options .= "<option value='$value->record_id'>$value->name</option>";
        }
        echo $options ;
        exit;
    }

     public function select_center($type = null)
    {
        if (in_array($type, ['general', 'ivf'])) {
            $this->session->set_userdata('__selected_center__', $type);
           return  redirect('home');
        }

         return redirect('/');
       
    }
}
