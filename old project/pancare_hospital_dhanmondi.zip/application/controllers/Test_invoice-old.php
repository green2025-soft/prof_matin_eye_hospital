<?php

defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Test_invoice extends CI_Controller
{

    static $helper   = array('utility');
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Common_model');
        $this->load->helper(self::$helper);
    }
    public function index()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'All Test Invoice';
            $data['page_title'] = 'All Test Invoice';
            $data['info_header'] = 'All Test Invoice';

            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $admission_id = $this->input->get('admission_id');
            $created_by = $this->input->get('created_by');
            $doctor_id = $this->input->get('doctor_id');


            if (!isset($from_date) && !isset($to_date)) {
                $from_date = $to_date = date('Y-m-d');
            }

            $where = array();
            if (!admin()) {
                $where['show_hide'] = 'Show';
            }
            $where['type'] = 'Test Invoice';
            if (!empty($from_date) && !empty($to_date)) {
                $where['date >= '] = $from_date;
                $where['date <= '] = $to_date;
            } elseif (!empty($from_date) && empty($to_date)) {
                $where['date'] = $from_date;
            } elseif (empty($from_date) && !empty($to_date)) {
                $where['date'] = $to_date;
            }
            if ($doctor_id) $where['doctor_id'] = $doctor_id;
            if ($admission_id) $where['admission_id'] = $admission_id;
            if ($created_by) $where['created_by'] = $created_by;

            $data['values'] = $this->Common_model->findAll('create_bill', $where, 'record_id', 'desc');
            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;
            $data['admission_id'] = $admission_id;
            $data['created_by'] = $created_by;
            $data['doctor_id'] = $doctor_id;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_invoice/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function test_wise_search()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Monthly Test Info';
            $data['page_title'] = 'Monthly Test Info';
            $data['info_header'] = 'Monthly Test Info';

            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $doctor_id = $this->input->get('doctor_id');
            $test_category_id = $this->input->get('test_category_id');
            $test_id = $this->input->get('test_id');

            if (!isset($from_date) && !isset($to_date) && !isset($doctor_id) && !isset($test_id)) {
                $from_date = $to_date = date('Y-m-d');
            }

            $where = array();
            if (!admin()) {
                $where['show_hide'] = 'Show';
            }
            if ($doctor_id) $where['doctor_id'] = $doctor_id;
            if ($test_category_id) $where['test_category_id'] = $test_category_id;
            if ($test_id) $where['test_id'] = $test_id;
            if (!empty($from_date) && !empty($to_date)) {
                $where['date >= '] = $from_date;
                $where['date <= '] = $to_date;
            } elseif (!empty($from_date) && empty($to_date)) {
                $where['date'] = $from_date;
            } elseif (empty($from_date) && !empty($to_date)) {
                $where['date'] = $to_date;
            }

            $data['values'] = $this->Common_model->findAllGroupByCount('sales_test', $where, 'doctor_id', 'test_id', 'record_id', 'desc');
            // var_dump($data['values']);die;
            $data['date_range'] = date('d F, Y', strtotime($from_date)) . ' to ' . date('d F, Y', strtotime($to_date));
            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;
            $data['doctor_id'] = $doctor_id;
            $data['test_category_id'] = $test_category_id;
            $data['test_id'] = $test_id;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_invoice/test_wise_search', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function dr_wise_ultra_info()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Dr wise Ultra Info';
            $data['page_title'] = 'Dr wise Ultra Info';
            $data['info_header'] = 'Dr wise Ultra Info';

            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $doctor_id = $this->input->get('doctor_id');
            $test_category_id = $this->input->get('test_category_id');
            $reference_by = $this->input->get('reference_by');

            if (!isset($from_date) && !isset($to_date) && !isset($doctor_id) && !isset($test_id) && !isset($reference_by)) {
                $from_date = $to_date = date('Y-m-d');
            }

            $where = array();
            if (!admin()) {
                $where['show_hide'] = 'Show';
            }
            if ($doctor_id) $where['doctor_id'] = $doctor_id;
            if ($test_category_id) $where['test_category_id'] = $test_category_id;
            if ($reference_by) $where['reference_by'] = $reference_by;
            if (!empty($from_date) && !empty($to_date)) {
                $where['date >= '] = $from_date;
                $where['date <= '] = $to_date;
            } elseif (!empty($from_date) && empty($to_date)) {
                $where['date'] = $from_date;
            } elseif (empty($from_date) && !empty($to_date)) {
                $where['date'] = $to_date;
            }

            $data['values'] = $this->Common_model->findAll('sales_test', $where, 'record_id', 'desc');
            // var_dump($data['values']);die;
            $data['date_range'] = date('d F, Y', strtotime($from_date)) . ' to ' . date('d F, Y', strtotime($to_date));
            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;
            $data['doctor_id'] = $doctor_id;
            $data['test_category_id'] = $test_category_id;
            $data['reference_by'] = $reference_by;
            $data['doctor'] = $this->Common_model->findById('doctor', array('record_id' => $doctor_id));
            $data['test_category'] = $this->Common_model->findById('test_category', array('record_id' => $test_category_id));
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_invoice/dr_wise_ultra_info', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function create()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Create Test Invoice';
            $data['page_title'] = 'Create Test Invoice';
            $data['page_title2'] = 'Today Test Invoice List';
            $data['info_header'] = '';

            $record_id = $this->input->get('record_id');


            $data['test_names'] = $this->Common_model->findAll('test_name', array(), 'record_id', 'asc');
            $today = date('Y-m-d');
            $where = array();
            $where['date'] = $today;
            $where['type'] = 'Test Invoice';
            if ($record_id) $where['record_id'] = $record_id;
            $data['invoice_list'] = $this->Common_model->findAll('create_bill', $where, 'record_id', 'desc');
            $data['record_id'] = $record_id;
            $where = array();
            $data['admissionInvoice'] = $this->Common_model->findAll("admission_fee_invoice", $where, "record_id", "desc");
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_invoice/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function edit($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Create Test Invoice';
            $data['page_title'] = 'Create Test Invoice';
            $data['info_header'] = '';
            $data['test_names'] = $this->Common_model->findAll('test_name', array(), 'record_id', 'asc');
            $data['value'] = $this->Common_model->findById('create_bill', array('record_id' => $record_id));
            $data['values'] = $this->Common_model->findAll('sales_test', array('invoice_no' => $record_id), 'record_id', 'asc');
            $data['accessories'] = $this->Common_model->findAll('sales_accessories', array('invoice_id' => $record_id), 'record_id', 'asc');
            if (isset($data['value'])) {
                $data['patient'] = $this->Common_model->findById('patient', array('record_id' => $data['value']->patient_id));
            }
            $where = array();
            $where['record_id'] = $data['value']->admission_id;
            $data['admissionInvoice'] = $this->Common_model->findAll("admission_fee_invoice", $where, "record_id", "desc");
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_invoice/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST;
            $update_id = $input['update_id'];
            unset($input['update_id']);
            $date = $input['date'];
            $reference_by = $input['reference_by'];
            $sales_test_ids = $input['sales_test_id'];
            $doctor_ids = $input['doctor_id'];
            $doctor_names = $input['doctor_name'];
            $test_ids = $input['test_id'];
            $test_category_ids = $input['test_category_id'];
            $test_names = $input['test_name'];
            $test_categorys = $input['test_category'];
            $test_prices = $input['test_price'];
            $accessories_names = $input['accessories_name'];
            $accessories_prices = $input['accessories_price'];
            $ultra_doctor_ids = $input['ultra_doctor_id'];
            $ultra_amounts = $input['ultra_amount'];
            $test_wise_discount_percentages = $input['test_wise_discount_percentage'];
            $test_wise_discount_amounts = $input['test_wise_discount_amount'];
            $test_wise_reference_by_commission_percentages = $input['test_wise_reference_by_commission_percentage'];
            $test_wise_reference_by_commissions = $input['test_wise_reference_by_commission']; 
            if (array_key_exists('accessories_id', $input)) {
                $accessories_ids = $input['accessories_id'];
                $accessories_names = $input['accessories_name'];
                $accessories_prices = $input['accessories_price'];
                $accessories_qtys = $input['accessories_qty'];
                $accessories_total_prices = $input['accessories_total_price'];
                unset($input['accessories_id']);
                unset($input['accessories_name']);
                unset($input['accessories_price']);
                unset($input['accessories_qty']);
                unset($input['accessories_total_price']);
            }

            unset($input['sales_test_id']);
            unset($input['doctor_id']);
            unset($input['doctor_name']);
            unset($input['test_id']);
            unset($input['test_category_id']);
            unset($input['test_name']);
            unset($input['test_category']);
            unset($input['test_price']);
            unset($input['accessories_name']);
            unset($input['accessories_price']);
            unset($input['ultra_doctor_id']);
            unset($input['ultra_amount']);
            unset($input['test_wise_discount_percentage']);
            unset($input['test_wise_discount_amount']);
            unset($input['test_wise_reference_by_commission_percentage']);
            unset($input['test_wise_reference_by_commission']);

            $prefix = 'Inv' . date("Ymd", strtotime($date));
            $maxSalesTest = $this->Common_model->findMax('create_bill', array('prefix' => $prefix, 'type' => 'Test Invoice'), 'invoice_no');
            $invoice_no = isset($maxSalesTest) ? $maxSalesTest->invoice_no + 1 : 1;


            $input['doctor_id'] = $doctor_ids[0];
            $input['prefix'] = $prefix;
            $input['invoice_no'] = $invoice_no;
            $input['type'] = 'Test Invoice';
            $input['particular'] = "Test Invoice";

            // calculate commission 

            // $this->calculateCommission($input);


            if ($update_id == 0 || empty($update_id)) {
                $insert = $this->Common_model->saveData('create_bill', $input);
                $invoice = $this->Common_model->findById('create_bill', array('record_id' => $insert));
                $invoice_no = $invoice->prefix . $invoice->invoice_no;
                $code_no = $invoice_no;
                $this->zend->load('Zend/Barcode');
                $image_file = Zend_Barcode::draw('code128', 'image', array('text' => sprintf('%s', $code_no), 'drawText' => false), array());
                imagejpeg($image_file, "./assets/img/barcode/$insert.jpg");

                foreach ($test_ids as $key => $value) {
                    $data = array(
                        'invoice_no' => $insert,
                        'date' => $date,
                        'patient_id' => $input['patient_id'],
                        'doctor_id' => $doctor_ids[$key],
                        'reference_by' => $reference_by,
                        'test_id' => $test_ids[$key],
                        'test_category_id' => $test_category_ids[$key],
                        'test_name' => $test_names[$key],
                        'accessories_name' => $accessories_names[$key],
                        'test_category' => $test_categorys[$key],
                        'test_price' => $test_prices[$key],
                        'accessories_price' => $accessories_prices[$key],
                        'ultra_doctor_id' => $ultra_doctor_ids[$key],
                        'ultra_amount' => $ultra_amounts[$key],
                        'test_wise_discount_amount' => $test_wise_discount_amounts[$key],
                        'test_wise_discount_percentage' => $test_wise_discount_percentages[$key],
                        'test_wise_reference_by_commission' => $test_wise_reference_by_commissions[$key],
                        'test_wise_reference_by_commission_percentage' => $test_wise_reference_by_commission_percentages[$key],
                    );
                    $this->Common_model->saveData('sales_test', $data);
                }
                if ($insert) {
                    $this->session->set_flashdata('message', INSERT_MSG);
                    if(isset($accessories_ids)){
                        $accessoriesList = array() ;
                        foreach ($accessories_ids as $key1 => $value1) {
                            $data = array(
                                'invoice_id'=> $insert,
                                'accessories_id'=>$accessories_ids[$key1],
                                'accessories_name'=>$accessories_names[$key1],
                                'accessories_price'=>$accessories_prices[$key1],
                                'accessories_qty'=>$accessories_qtys[$key1],
                                'accessories_total_price'=>$accessories_total_prices[$key1],
                            );
                            $accessoriesList[] = $data ;
                        } 
                        $this->Common_model->save_batch('sales_accessories',$accessoriesList) ;
                    }
                } else {
                    $this->session->set_flashdata('message', INSERT_ERROR_MSG);
                }

                foreach ($ultra_doctor_ids as $key => $value) {
                    if ($value) {
                        $ultraData = array(
                            'date' => $date,
                            'invoice_id' => $insert,
                            'test_category_id' => $test_category_ids[$key],
                            'test_id' => $test_ids[$key],
                            'doctor_id' => $ultra_doctor_ids[$key],
                            'amount' => $ultra_amounts[$key]
                        );
                        $this->Common_model->saveData('sonologist', $ultraData);
                    }
                }

                $update_id = $insert;
            } else {

                $invoice = $this->Common_model->findById('create_bill', array('record_id' => $update_id));
                $invoice_no = $invoice->prefix . $invoice->invoice_no;

                $code_no = $invoice_no;
                $barcode = "assets/img/barcode/$code_no.jpg";
                if (!file_exists($barcode)) {
                    $this->zend->load('Zend/Barcode');
                    $image_file = Zend_Barcode::draw('code128', 'image', array('text' => sprintf('%s', $code_no), 'drawText' => false), array());
                    imagejpeg($image_file, "./assets/img/barcode/$update_id.jpg");
                }

                if (isset($invoice)) {
                    if ($invoice->date == $date) {
                        $input['invoice_no'] = $invoice->invoice_no;
                    }
                }
                $update = $this->Common_model->updateData('create_bill', $input, array('record_id' => $update_id));
                // var_dump($test_ids);die;
                foreach ($test_ids as $key => $value) {
                    $sales_test_id = $sales_test_ids[$key];
                    $data = array(
                        'invoice_no' => $update_id,
                        'date' => $date,
                        'patient_id' => $input['patient_id'],
                        'doctor_id' => $doctor_ids[$key],
                        'reference_by' => $reference_by,
                        'test_id' => $test_ids[$key],
                        'test_category_id' => $test_category_ids[$key],
                        'test_name' => $test_names[$key],
                        'accessories_name' => $accessories_names[$key],
                        'test_category' => $test_categorys[$key],
                        'test_price' => $test_prices[$key],
                        'accessories_price' => $accessories_prices[$key],
                        'ultra_doctor_id' => $ultra_doctor_ids[$key],
                        'ultra_amount' => $ultra_amounts[$key],
                        'test_wise_discount_amount' => $test_wise_discount_amounts[$key],
                        'test_wise_discount_percentage' => $test_wise_discount_percentages[$key],
                        'test_wise_reference_by_commission' => $test_wise_reference_by_commissions[$key],
                        'test_wise_reference_by_commission_percentage' => $test_wise_reference_by_commission_percentages[$key],
                    );
                    if ($sales_test_id) {
                        $this->Common_model->updateData('sales_test', $data, array('record_id' => $sales_test_id));
                    } else {
                        $this->Common_model->saveData('sales_test', $data);
                    }
                }
                if(isset($accessories_ids)){
                    $this->Common_model->deleteData('sales_accessories',array('invoice_id'=>$update_id));
                    $accessoriesList = array() ;
                    foreach ($accessories_ids as $key1 => $value1) {
                        $data = array(
                            'invoice_id'=> $update_id,
                            'accessories_id'=>$accessories_ids[$key1],
                            'accessories_name'=>$accessories_names[$key1],
                            'accessories_price'=>$accessories_prices[$key1],
                            'accessories_qty'=>$accessories_qtys[$key1],
                            'accessories_total_price'=>$accessories_total_prices[$key1],
                        );
                        $accessoriesList[] = $data ;
                    } 
                    $this->Common_model->save_batch('sales_accessories',$accessoriesList);
                }



                foreach ($ultra_doctor_ids as $key => $value) {
                    if ($value) {
                        $test_category_id = $test_category_ids[$key];
                        $test_id = $test_ids[$key];
                        $doctor_id = $ultra_doctor_ids[$key];
                        $ultraData = array(
                            'date' => $date,
                            'invoice_id' => $update_id,
                            'test_category_id' => $test_category_ids[$key],
                            'test_id' => $test_ids[$key],
                            'doctor_id' => $ultra_doctor_ids[$key],
                            'amount' => $ultra_amounts[$key]
                        );
                        $sonologist = $this->Common_model->findById('sonologist', array('invoice_id' => $update_id, 'test_category_id' => $test_category_id, 'test_id' => $test_id));
                        if (isset($sonologist)) {
                            $this->Common_model->updateData('sonologist', $ultraData, array('record_id' => $sonologist->record_id));
                        } else {
                            $this->Common_model->saveData('sonologist', $ultraData);
                        }
                    }
                }

                if ($update) {
                    $this->session->set_flashdata('message', UPDATE_MSG);
                } else {
                    $this->session->set_flashdata('message', UPDATE_ERROR_MSG);
                }
                redirect("test_invoice/view2/$update_id", 'refresh');
            }
            redirect("test_invoice/view/$update_id", 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    private function calculateCommission($postData){

        $refByDetails = $this->db->get_where('reference_by', ['record_id'=>$postData['reference_by']])->row();

        if(!empty($refByDetails)){

        }

    }

    public function view($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Test Invoice';
            $data['page_title'] = 'Test Invoice';
            $data['info_header'] = '';
            $data['signatureType'] = 'Patient';
            $data['redirect'] = base_url('test_invoice/create');
            $data['value'] = $this->Common_model->findById('create_bill', array('record_id' => $record_id));
            $data['values'] = $this->Common_model->findAll('sales_test', array('invoice_no' => $record_id), 'record_id', 'asc');
            $data['accessories'] = $this->Common_model->findAll('sales_accessories', array('invoice_id' => $record_id), 'record_id', 'asc');
            if (isset($data['value'])) {
                $data['patient'] = $this->Common_model->findById('patient', array('record_id' => $data['value']->patient_id));
                $data['doctor'] = $this->Common_model->findById('doctor', array('record_id' => $data['value']->doctor_id));
            }
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_invoice/invoice', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function view2($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Test Invoice';
            $data['page_title'] = 'Test Invoice';
            $data['info_header'] = '';
            $data['signatureType'] = 'Patient';
            $data['redirect'] =  base_url('test_invoice');
            $data['value'] = $this->Common_model->findById('create_bill', array('record_id' => $record_id));
            $data['values'] = $this->Common_model->findAll('sales_test', array('invoice_no' => $record_id), 'record_id', 'asc');
            $data['accessories'] = $this->Common_model->findAll('sales_accessories', array('invoice_id' => $record_id), 'record_id', 'asc');
            if (isset($data['value'])) {
                $data['patient'] = $this->Common_model->findById('patient', array('record_id' => $data['value']->patient_id));
                $data['doctor'] = $this->Common_model->findById('doctor', array('record_id' => $data['value']->doctor_id));
            }
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_invoice/invoice', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function patient_label($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Test Invoice';
            $data['page_title'] = 'Test Invoice';
            $data['info_header'] = '';
            $data['signatureType'] = 'Patient';
            $data['redirect'] =  base_url('test_invoice');
            $data['value'] = $this->Common_model->findById('create_bill', array('record_id' => $record_id));
            $data['values'] = $this->Common_model->findAll('sales_test', array('invoice_no' => $record_id), 'record_id', 'asc');
            if (isset($data['value'])) {
                $data['patient'] = $this->Common_model->findById('patient', array('record_id' => $data['value']->patient_id));
                $data['doctor'] = $this->Common_model->findById('doctor', array('record_id' => $data['value']->doctor_id));
            }
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_invoice/patient_label', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function patient_label2($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Test Invoice';
            $data['page_title'] = 'Test Invoice';
            $data['info_header'] = '';
            $data['signatureType'] = 'Patient';
            $data['redirect'] =  base_url('test_invoice/create');
            $data['value'] = $this->Common_model->findById('create_bill', array('record_id' => $record_id));
            $data['values'] = $this->Common_model->findAll('sales_test', array('invoice_no' => $record_id), 'record_id', 'asc');
            if (isset($data['value'])) {
                $data['patient'] = $this->Common_model->findById('patient', array('record_id' => $data['value']->patient_id));
                $data['doctor'] = $this->Common_model->findById('doctor', array('record_id' => $data['value']->doctor_id));
            }
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_invoice/patient_label', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function print_barcode($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Test Invoice';
            $data['page_title'] = 'Test Invoice';
            $data['redirect'] =  base_url('test_invoice');
            $data['record_id'] = $record_id;

            $quantity = $this->input->post('quantity');
            if (isset($quantity)) {
                $barcodeList = array();
                $barcode = "assets/img/barcode/$record_id.jpg";;
                for ($i = 0; $i < $quantity; $i++) {
                    $obj = new stdClass;
                    $obj->barcode = base_url($barcode);
                    $barcodeList[] = $obj;
                }
                $data['values'] = $barcodeList;
            }
            $data['quantity'] = $quantity;

            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_invoice/print_barcode', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function generate_barcode()
    {
        $record_id = $this->input->post('record_id');

        $data['record_id'] = $record_id;
    }

    public function delete($id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if ($this->Common_model->delete_info('record_id', $id, 'create_bill')) {
                $this->Common_model->delete_info('invoice_no', $id, 'sales_test');
                $this->Common_model->deleteData('sales_accessories',array('invoice_id'=>$id));
                $code_no = $id;
                $barcode = "assets/img/barcode/$code_no.jpg";
                if (file_exists($barcode)) {
                    unlink('./' . $barcode);
                }
                $this->session->set_flashdata('message', DELETE_MSG);
            } else {
                $this->session->set_flashdata('message', DELETE_ERROR_MSG);
            }
            // redirect("crud/previousPage");
            // redirect('test_invoice', 'refresh');
            redirect($_SERVER['HTTP_REFERER']);
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function delete_sale_test()
    {
        $user_type = $this->session->ses_user_type;
        $record_id = $this->input->post('record_id');
        if ($user_type == "admin"  || $user_type == "staff") {
            $sales_test = $this->Common_model->findById('sales_test', array('record_id' => $record_id));
            if ($this->Common_model->delete_info('record_id', $record_id, 'sales_test')) {
                $sonologist = $this->Common_model->findById('sonologist', array('invoice_id' => $sales_test->invoice_no, 'test_category_id' => $sales_test->test_category_id, 'test_id' => $sales_test->test_id));
                if (isset($sonologist)) {
                    $this->Common_model->delete_info('record_id', $sonologist->record_id, 'sonologist');
                }
                $this->session->set_flashdata('message', DELETE_MSG);
                echo 1;
            } else {
                echo 0;
            }
            exit;
        } else {
            echo 0;
            exit;
        }
    }
    public function load_discount_type()
    {
        $discount_type = $this->input->post('discount_type');
        $options = "<option value=''>--Select--</option>";
        if ($discount_type == 1 or $discount_type == 4) {
            $references = $this->Common_model->findAll('reference_by', array(), 'record_id', 'asc');
            foreach ($references as $key => $value) {
                $options .= "<option value='$value->record_id' data-ultraxray='$value->ultraxray'  data-xray='$value->xray'  data-echo_cardiogram='$value->echo_cardiogram'  data-endoscopy='$value->endoscopy' data-ecg='$value->ecg' data-ct_scan='$value->ct_scan' data-mri='$value->mri'  data-commission='$value->commission' >$value->reference_prefix$value->reference_no - $value->reference_name</option>";
            }
        } elseif ($discount_type == 2 or $discount_type == 5) {
            $doctors = $this->Common_model->findAll('doctor', array(), 'record_id', 'asc');
            foreach ($doctors as $key => $value) {
                $options .= "<option value='$value->record_id'>$value->doctor_prefix$value->doctor_no - $value->name</option>";
            }
        } elseif ($discount_type == 3) {
            $options = "<option value='0'  data-ultraxray='0' data-xray='0'  data-echo_cardiogram='0'  data-endoscopy='0' data-ecg='0' data-ct_scan='0' data-mri='0'   data-commission='0' >Hospital</option>";
        }
        echo $options;
        exit;
    }
}
