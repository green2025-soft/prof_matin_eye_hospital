<?php

class Test_result extends CI_Controller
{

    //put your code here
    public function __construct()
    {
        parent::__construct();
        $this->load->library('upload');
    }

    public function index()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Pathological Test Result';
            $data['page_title'] = 'Pathological Test Result';
            $data['info_header'] = 'Pathological Test Result';
            $data['test_names'] = $this->Common_model->findAll('test_name', array(), 'record_id', 'asc');
            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $test_id = $this->input->get('test_id');

            if (!isset($from_date) && !isset($to_date) && !isset($test_id)) {
                $from_date = $to_date = date('Y-m-d');
            }

            $where = array();
            if (!admin()) {
                $where['show_hide'] = 'Show';
            }

            $whereNotIn = array(11,19);
            $whereNotInColumn = 'test_category_id' ;


            if ($test_id) $where['test_id'] = $test_id;
            if (!empty($from_date) && !empty($to_date)) {
                $where['date >= '] = $from_date;
                $where['date <= '] = $to_date;
            } elseif (!empty($from_date) && empty($to_date)) {
                $where['date'] = $from_date;
            } elseif (empty($from_date) && !empty($to_date)) {
                $where['date'] = $to_date;
            }
           // var_dump($where) ; die ;
            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;
            $data['test_id'] = $test_id;

            // $data['all_test_result'] = $this->Common_model->findAllWhereNotIn('test_result', $where,$whereNotIn,$whereNotInColumn, 'record_id', 'DESC');
            $data['all_test_result'] = $this->Common_model->getAllReports($from_date, $to_date, $test_id);
            // ddd($data['all_test_result']);
            // ddd($this->db->last_query());
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_result/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function ultra()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Sono Test Result';
            $data['page_title'] = 'Sono Test Result';
            $data['info_header'] = 'Sono Test Result';
            $data['test_names'] = $this->Common_model->findAll('test_name', array('test_category_id' => 11), 'record_id', 'asc');
            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $test_id = $this->input->get('test_id');

            if (!isset($from_date) && !isset($to_date) && !isset($test_id)) {
                $from_date = $to_date = date('Y-m-d');
            }

            $where = array();
            $where['test_category_id'] = 11;
            if ($test_id) $where['test_id'] = $test_id;
            if (!empty($from_date) && !empty($to_date)) {
                $where['date >= '] = $from_date;
                $where['date <= '] = $to_date;
            } elseif (!empty($from_date) && empty($to_date)) {
                $where['date'] = $from_date;
            } elseif (empty($from_date) && !empty($to_date)) {
                $where['date'] = $to_date;
            }
            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;
            $data['test_id'] = $test_id;

            $data['all_test_result'] = $this->Common_model->findAll('test_result', $where, 'record_id', 'DESC');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_result/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function echo()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Echo-Cardiogram Test Result';
            $data['page_title'] = 'Echo-Cardiogram Test Result';
            $data['info_header'] = 'Echo-Cardiogram Test Result';
            $data['test_names'] = $this->Common_model->findAll('test_name', array('test_category_id' => 11), 'record_id', 'asc');
            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $test_id = $this->input->get('test_id');

            if (!isset($from_date) && !isset($to_date) && !isset($test_id)) {
                $from_date = $to_date = date('Y-m-d');
            }

            $where = array();
            $where['test_category_id'] = 19;
            if ($test_id) $where['test_id'] = $test_id;
            if (!empty($from_date) && !empty($to_date)) {
                $where['date >= '] = $from_date;
                $where['date <= '] = $to_date;
            } elseif (!empty($from_date) && empty($to_date)) {
                $where['date'] = $from_date;
            } elseif (empty($from_date) && !empty($to_date)) {
                $where['date'] = $to_date;
            }
            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;
            $data['test_id'] = $test_id;

            $data['all_test_result'] = $this->Common_model->findAll('test_result', $where, 'record_id', 'DESC');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_result/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function create()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Test Result Input';
            $data['page_title'] = 'Test Result Input';
            $data['info_header'] = 'All Test Result Input';

            $today = date('Y-m-d');
            $where = array();
            $where['date'] = $today;
            $where['type'] = 'Test Invoice';
            $data['invoice_list'] = $this->Common_model->findAll('create_bill', $where, 'record_id', 'desc');
            $last_out_product = $this->Common_model->findFirstOrLast('lab_product_out_details', array('out_from' => 'Result Input'), 'record_id', 'desc');
            $data['last_out_product_id'] = isset($last_out_product) ? $last_out_product->product_id : 0;

            $last_result = $this->Common_model->findFirstOrLast('test_reports', [], 'record_id', 'desc');
            
            $data['duty_doctor_id'] = isset($last_result) ? $last_result->duty_doctor_id : 0;
            $data['duty_staff_id'] = isset($last_result) ? $last_result->duty_staff_id : 0;
            $data['duty_staff_id2'] = isset($last_result) ? $last_result->duty_staff_id2 : 0;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_result/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function saveOrUpdate()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            // ddd($_POST);
            $loginId = $this->session->userData('ses_record_id');
            $date = $this->input->post('date');
            $blank_result = $this->input->post('blank_result');

            if (isset($blank_result)) {
                $blank_result = 1;
            } else {
                $blank_result = 0;
            }
            //  var_dump($blank_result);die;
            $patient_id = $this->input->post('patient_id');
            $patient = $this->Common_model->findById('patient', array('record_id' => $patient_id));
            $patient_name = isset($patient) ? $patient->name : '';
            $duty_doctor_id = $this->input->post('duty_doctor_id');
            $duty_staff_id = $this->input->post('duty_staff_id');
            $duty_staff_id2 = $this->input->post('duty_staff_id2');
            $test_id = $this->input->post('test_id');
            $invoice_id = $this->input->post('invoice_id');
            $sales_test_id = $this->input->post('sales_test_id');
            $doctor_id = $this->input->post('doctor_id');
            $comments = $this->input->post('comments');
            $staff_id = $this->input->post('staff_id');
            $reAgentQuantity = $this->input->post('quantity');
            $reAgentID = $this->input->post('product_id');

            // $test = $this->Common_model->findById('test_name', array('record_id' => $test_id));
            // $test_category_id = isset($test) ? $test->test_category_id : 0;
            // $test_name = isset($test) ? $test->test_name : 0;
            // $category = $this->Common_model->findById('test_category', array('record_id' => $test_category_id));
            // $test_category = isset($category) ? $category->test_category : '';
            $age = $this->input->post('age');
            $sex = $this->input->post('sex');
            $ref_by = $this->input->post('ref_by');
            $report_date = $this->input->post('report_date');
            $report_fields = $this->input->post('report_field');

            $config['upload_path']      = 'assets/img/attached_file/';
            $config['allowed_types']    = '*';
            $config['max_size']         = '0';
            //$config['file_name']      = time(); 
            $file_field                 = "attached_file";
            $attached_file = '';
            $this->upload->initialize($config);
            if (!empty($_FILES[$file_field]["name"])) {
                if ($this->upload->do_upload($file_field)) {
                    $uploadData = $this->upload->data();
                    $attached_file =   $config['upload_path'] . $uploadData['file_name'];
                }
            }
            
            if(sizeof($test_id) > 0){

                $testDetails = $this->Common_model->getTestDetails($test_id);

                // ddd($testDetails);

                //check same category

                $testCat = 0;
                $categoryFlag = true;
                foreach($testDetails  as $row){
                    if($testCat == 0){
                        $testCat = $row->test_category_id;
                    }
                    if($testCat !== $row->test_category_id){
                        $categoryFlag = false;
                    }
                }

                if($categoryFlag){

                    $reportFieldData = [];
                    $testNameDataArr = [];

                    $testReportData = array(
                        'collection_date' => $date,
                        'report_date' => date("Y-m-d"),
                        'invoice_id' => $invoice_id,
                        'patient_id' => $patient_id,
                        'duty_doctor_id' => $duty_doctor_id,
                        'duty_staff_id' => $duty_staff_id,
                        'duty_staff_id2' => $duty_staff_id2,
                        'test_category_id' => $testCat,
                        'doctor_id' => $doctor_id,
                        'comments' => $comments,
                    );

                    $test_inserted_id = $this->Common_model->saveData('test_reports', $testReportData);

                    // reduce re agent from stock
                    if(sizeof($reAgentQuantity) > 0 && sizeof($reAgentID) > 0 && array_sum($reAgentQuantity) > 0){

                        $out_date = date("Y-m-d");
                        $prefix = str_replace('-', '', $out_date);
            
                        $max = $this->Common_model->findMax('re_agent_out', array('prefix' => $prefix), 'out_no');
                        $out_no = isset($max) ? $max->out_no + 1 : 1;

                        $productOutData = [];
                        $productOutData['out_type'] = 4;
                        $productOutData['staff_id'] = $staff_id;
                        $productOutData['patient_id'] = $patient_id;
                        $productOutData['test_result_id'] = $test_inserted_id;
                        $productOutData['test_id'] = $test_id[0];
                        $productOutData['test_category_id'] = $testDetails[0]->test_category_id;
                        $productOutData['out_date'] = $out_date;
                        $productOutData['prefix'] = $prefix;
                        $productOutData['out_no'] = $out_no;
                        $productOutData['grand_quantity'] = array_sum($reAgentQuantity);
                        $productOutData['comments'] = 'Result Input';
                        $productOutData['created_by'] = $this->session->userData('ses_record_id');

                        $this->db->insert('re_agent_out', $productOutData);

                        $labProductOutID = $this->db->insert_id();

                        for($i = 0; $i< sizeof($reAgentID); $i++){

                            $labProdOutDetailsData = [];
                            // $labProdOutDetailsData['patient_id'] = $patient_id;
                            $labProdOutDetailsData['re_agent_out_id'] = $labProductOutID;
                            $labProdOutDetailsData['staff_id'] = $staff_id;
                            $labProdOutDetailsData['category_id'] = 4;
                            $labProdOutDetailsData['out_date'] = date("Y-m-d");
                            $labProdOutDetailsData['product_id'] = $reAgentID[$i];
                            $labProdOutDetailsData['quantity'] = $reAgentQuantity[$i];
                            $labProdOutDetailsData['unit_price'] = 0;
                            $labProdOutDetailsData['total_price'] = 0;
                            $labProdOutDetailsData['created_by'] = $this->session->userData('ses_record_id');

                            $this->db->insert('re_agent_out_details', $labProdOutDetailsData);
                        }

                    }

                    // ddd($test_inserted_id);

                    foreach($test_id as $test){
                        
                        $reportFields = $_POST['report_'.$test.'_fields'];
    
                        if(sizeof($reportFields) > 0){
                            $flag = false;
                            foreach($reportFields as $field){
                                if(isset($field)){
                                    $flag = true;
                                    $testNameDataArr[] = [
                                        'test_report_id' => $test_inserted_id,
                                        'test_name_id' => $test,
                                    ];
                                    break;
                                }
                            }

                            if($flag){
                                foreach($reportFields as $key => $value){
                                    $reportFieldData[] = array(
                                        'test_report_id' => $test_inserted_id,
                                        'test_field_id' => $key,
                                        // 'value' => $value,
                                        'value' => str_replace("@#", "<br>", $value),
                                    );
                                }
                            }
                        }
                    }
                    
                    if(sizeof($reportFieldData) > 0 && sizeof($testNameDataArr) > 0){
                        $this->db->insert_batch('test_report_names', $testNameDataArr);
                        $this->db->insert_batch('test_report_fields', $reportFieldData);
                    }

                    echo $test_inserted_id;
                    exit;
                }

            }
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function get_test_detailed_form(){
        $date = $this->input->post('date');
        $invoice_id = $this->input->post('invoice_id');
        $patient_id = $this->input->post('patient_id');
        $testIdArr = $this->input->post('test_id');

        $testDetailsArr = [];
        $previousSimilarData = [];
        $i = 0;
        foreach($testIdArr as $test_id){
            $testDetails = $this->Common_model->getTestDetails($test_id);
            $test_category_id = isset($testDetails->test_category_id) ? $testDetails->test_category_id : 0;
            $test_name = isset($testDetails) ? $testDetails->test_name : 0;

            $where = array();
            $where['collection_date'] = $date;
            $where['invoice_id'] = $invoice_id;
            $where['patient_id'] = $patient_id;
            $where['test_category_id'] = $testDetails->test_category_id;
            $where['test_name_id'] = $test_id;

            $result = $this->Common_model
                           ->checkIfTestExists($date, 
                                               $invoice_id, 
                                               $patient_id,
                                               $testDetails->test_category_id,
                                               $test_id);


            $testDetailsArr[$i] = new stdClass;
            $testDetailsArr[$i]->flag = true;
            $testDetailsArr[$i]->details = $testDetails;
            
            if(empty($result)) {
                $testDetailsArr[$i]->flag = false;
                $testFields = $this->Common_model->findAll('test_fields', array('test_name_id' => $test_id),'priority', 'asc');
                $testFieldgroup = $this->Common_model->group_by_usual('test_name_id', $test_id, 'test_group_id', 'test_fields');
                
                $testDetailsArr[$i]->testFields = $testFields;
                $testDetailsArr[$i]->testFieldgroup = $testFieldgroup;
                if($testDetails->test_category_id == 5 || $testDetails->test_category_id == 46){
                    
                    $previousSimilarData[$test_id] = $this->Common_model->getPreviousSimilarResult($testDetails->test_category_id, $test_id);
                }
            }
            $i++;
        }
        

        $data['testDetailsData'] = $testDetailsArr;
        $data['previousSimilarData'] = $previousSimilarData;

        $this->load->view('admin/Test/new/report_input_form', $data);
    }

    public function today_patient_test_categories(){
        $invoice_id = $this->input->post('invoice_id');
        $patient_id = $this->input->post('patient_id');
        $date = $this->input->post('date');

        $testCategories = $this->Common_model->getInvoiceTestCategories($invoice_id, $patient_id, $date);
        $option = "<option value=>--Select--</option>";

        foreach($testCategories as $category){
            $option .= "<option value='$category->record_id' >$category->test_category</option>";
        }
        $data = array('option' => $option);
        echo json_encode($data);
    }


    public function get_test_form()
    {
        $date = $this->input->post('date');
        $patient_id = $this->input->post('patient_id');
        $test_id = $this->input->post('test_id');

        $test = $this->Common_model->findById('test_name', array('record_id' => $test_id));
        $test_category_id = isset($test) ? $test->test_category_id : 0;
        $test_name = isset($test) ? $test->test_name : 0;

        $test_category = $this->Common_model->findById('test_category', array('record_id' => $test_category_id));

        $where = array();
        $where['date'] = $date;
        $where['patient_id'] = $patient_id;
        $where['test_category'] = isset($test_category) ? $test_category->test_category : '';
        $where['test_name'] = $test_name;

        $data['test_name'] = $test_name;

        $result = $this->Common_model->findById('test_result', $where);

        if (isset($result)) {
            $this->load->view('admin/test_result/default_result');
        } elseif ($test_category_id == 1) {
            $data['value'] = $this->Common_model->findFirstOrLast('report_haematology', array(), 'record_id', 'desc');
            $this->load->view('admin/Test/haematology', $data);
        } elseif ($test_category_id == 2) {
            $data['value'] = $this->Common_model->findFirstOrLast('report_biochemistry', array(), 'record_id', 'desc');
            $this->load->view('admin/Test/biochemistry', $data);
        } elseif ($test_category_id == 3) {
            $data['value'] = $this->Common_model->findFirstOrLast('report_immunology', array(), 'record_id', 'desc');
            $this->load->view('admin/Test/IMMUNOLOGY', $data);
        } elseif ($test_category_id == 4) {
            $data['value'] = $this->Common_model->findFirstOrLast('report_mt', array(), 'record_id', 'desc');
            $this->load->view('admin/Test/MT', $data);
        } elseif ($test_category_id == 5) {
            $data['value'] = $this->Common_model->findFirstOrLast('report_urinerme', array(), 'record_id', 'desc');
            $this->load->view('admin/Test/Urine_RME', $data);
        } elseif ($test_category_id == 6) {
            $data['value'] = $this->Common_model->findFirstOrLast('report_stool_rme', array(), 'record_id', 'desc');
            $this->load->view('admin/Test/Stool_RME', $data);
        } elseif ($test_category_id == 7) {
            $data['value'] = $this->Common_model->findFirstOrLast('report_cross_matching', array(), 'record_id', 'desc');
            $this->load->view('admin/Test/Cross_matching', $data);
        } elseif ($test_category_id == 8) {
            $data['value'] = $this->Common_model->findFirstOrLast('report_semen_analysis_report', array(), 'record_id', 'desc');
            $this->load->view('admin/Test/Semen_Analysis_Report', $data);
        } elseif ($test_category_id == 9) {
            $data['value'] = $this->Common_model->findFirstOrLast('report_skin_scraping', array(), 'record_id', 'desc');
            $this->load->view('admin/Test/Skin_Scraping_Report', $data);
        } elseif ($test_category_id == 10) {
            $data['value'] = $this->Common_model->findFirstOrLast('report_serological', array(), 'record_id', 'desc');
            $this->load->view('admin/Test/Serological_Test_Report', $data);
        } elseif ($test_category_id == 11) {
            $data['value'] = $this->Common_model->findFirstOrLast('report_ultra_usg', array(), 'record_id', 'desc');
            $this->load->view('admin/Test/ultra_usg', $data);
        } elseif ($test_category_id == 19) {
            $data['value'] = $this->Common_model->findFirstOrLast('report_echo_cardiogram', array(), 'record_id', 'desc');
            $this->load->view('admin/Test/echo_cardiogram', $data);
        }else {
            $this->load->view('admin/test_result/attached_file', $data);
        }
    }


    public function show_report($report_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {

            $testDetails = $this->Common_model->getTestReportDetails($report_id);
            $patientData = $this->Common_model->findById('patient', ['record_id'=>$testDetails->patient_id]);
            $test_name_id = $this->Common_model->findById('test_report_names', ['test_report_id'=>$report_id]);

            $dutyDoctor = $this->Common_model->findById('report_signatures', ['id'=>$testDetails->duty_doctor_id]);
            $dutyStaff = $this->Common_model->findById('report_signatures', ['id'=>$testDetails->duty_staff_id]);
            $dutyStaff2 = $this->Common_model->findById('report_signatures', ['id'=>$testDetails->duty_staff_id2]);

            
            $testDetails->dutyStaff     =  $dutyStaff;
            $testDetails->dutyStaff2    =  $dutyStaff2;
            $testDetails->dutyDoctor    =  $dutyDoctor;
            // dd($testDetails);

            $data['testDetails'] = $testDetails;
            $data['patientData'] = $patientData;
            $data['redirect'] = base_url('test_result');

            // dd($data['testDetails']);

            $this->load->view('admin/layouts/header');
            
            
            if($test_name_id->test_name_id == 48){
                $this->load->view('admin/test_result/report_print_urine', $data);
            }else if($test_name_id->test_name_id == 807){
                $data['fields'] = $this->Common_model->findAll('test_fields', array('test_name_id' => 807), 'priority', 'asc');
				$this->load->view('admin/test_result/report_print_semen_analysis', $data);
            }else if($testDetails->test_category_id == 47){
                

				$this->load->view('admin/test_result/report_print_abg', $data);
            }
            else{
            $this->load->view('admin/test_result/report_print_new', $data);
        }
            $this->load->view('admin/layouts/footer');

        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function today_patient_test()
    {
        $invoice_id = $this->input->post('invoice_id');
        $patient_id = $this->input->post('patient_id');
        $date = $this->input->post('date');
        $test_category = $this->input->post('test_category');

        $where = array();
        $where['invoice_no'] = $invoice_id;
        $where["date"] = $date;
        $where["patient_id"] = $patient_id;
        $where["test_category_id"] = $test_category;
        //var_dump($invoice_id) ; die ;
        $result = $this->Common_model->findAll('sales_test', $where, 'record_id', 'asc');
        $option = "";
        $doctor_name = "";
        $doctor_id = 0;
        $invoice_no = 0;
        $test = '';
        $category = '';
        foreach ($result as $info) {
            $invoice_no = $info->invoice_no;
            $test_category = $this->Common_model->findById('test_category', array('record_id' => $info->test_category_id));
            $test_name = $this->Common_model->findById('test_name', array('record_id' => $info->test_id));
            $category = isset($test_category) ? $test_category->test_category : '';
            $test = isset($test_name) ? $test_name->test_name : '';
            $option .= "<option selected  value='$info->test_id' data-invoice_id='$info->invoice_no' data-sales_test_id='$info->record_id' data-doctor_id='$info->doctor_id' data-category_id='$info->test_category_id'>$test_name->record_id - $test - $category</option>";
        }
        if ($invoice_id) {
            $invoice = $this->Common_model->findById('create_bill', array('record_id' => $invoice_id));
            $doctor = $this->Common_model->findById('doctor', array('record_id' => isset($invoice) ? $invoice->doctor_id : 0));
            $designation = $this->Common_model->findById('designation', array('record_id' => isset($doctor) ? $doctor->designation_id : 0));
            $designation_name = isset($designation) ? ' - ' . $designation->designation : '';
            $doctor_name = isset($doctor) ? $doctor->name . $designation_name : '';
            /* var_dump($invoice->referred_doctor) ; die ;
            if(isset($invoice->referred_doctor)){
                $doctor_name =  $invoice->referred_doctor ; 
            }*/
        }
        $data = array('option' => $option, 'doctor_name' => $doctor_name);
        echo json_encode($data);
    }
    public function today_generated_invoice()
    {
        $invoice_id = $this->input->post('invoice_id');
        $patient_id = $this->input->post('patient_id');
        $date = $this->input->post('date');
        $today = $date;
        $where = array();
        $where['date'] = $today;
        $where['type'] = 'Test Invoice';
        $invoice_list = $this->Common_model->findAll('create_bill', $where, 'record_id', 'desc');
        $option = "<option value=>--Select--</option>";
        $doctor_name = "";
        foreach ($invoice_list as $key1 => $value1) {
            $patient = $this->Common_model->findById('patient', array('record_id' => $value1->patient_id));
            $patient_name = isset($patient) ? $patient->name . "[$patient->record_id]" : "";
            $option .= '<option value=' . $value1->record_id . ' data-patient_id=' . $value1->patient_id . ' data-patient_age=' . $patient->age . ' data-patient_gender=' . $patient->gender . ' data-patient_mobile=' . $patient->mobile . '>
            ' . generate_invoice_no($value1) . " - " . $patient_name . '</option>';
        }
        echo $option;
        exit;
    }
    public function delete($id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            $test_result = $this->Common_model->findById('test_reports', array('record_id' => $id));

            $res1 = $this->Common_model->delete_info('record_id', $id, 'test_reports');
            $res2 = $this->Common_model->delete_info('test_report_id', $id, 'test_report_names');
            $res3 = $this->Common_model->delete_info('test_report_id', $id, 'test_report_fields');

            $out_info = $this->Common_model->findById('re_agent_out', array('test_result_id' => $id));
            $this->Common_model->deleteData('re_agent_out',array('test_result_id'=>$id));
            $this->Common_model->deleteData('re_agent_out_details',array('re_agent_out_id'=>$out_info->record_id));

            if($res1 && $res2 && $res3){
                $this->session->set_flashdata('message', DELETE_MSG);
            }else{
                $this->session->set_flashdata('message', DELETE_ERROR_MSG);
            }
            redirect('test_result', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function edit_report($report_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            
            $testDetails = $this->Common_model->getTestReportDetails($report_id);
            $patientData = $this->Common_model->findById('patient', ['record_id'=>$testDetails->patient_id]);

            if($testDetails->doctor_id){
                $options = array(
                    'joins' => array(
                        array(
                            'table' => 'designation',
                            'condition' => 'designation.record_id = doctor.designation_id',
                            'jointype' => 'LEFT'
                        ),
                        
                    ),
                    'select' => '*',
                    'where' => array(
                        'doctor.record_id' => $testDetails->doctor_id,
                    ),
                   
                );
        
                $doctor_info = $this->Common_model->commonJoinsRow("doctor", $options);
                $data['designation'] = $doctor_info->designation;
            }else{
                $data['designation'] = "";
            }

            $data['title'] = 'Test Result Edit';
            $data['page_title'] = 'Test Result Edit';
            $data['info_header'] = 'Test Result Edit';
            $data['duty_doctor_id'] = isset($last_result) ? $last_result->duty_doctor_id : 0;
            $data['duty_staff_id'] = isset($last_result) ? $last_result->duty_staff_id : 0;
            $data['duty_staff_id2'] = isset($last_result) ? $last_result->duty_staff_id2 : 0;
            $data['testDetails'] = $testDetails;
            $data['patientData'] = $patientData;
            $data['redirect'] = base_url('test_result');
            $data['test_id'] = $report_id;


            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_result/edit_report', $data);
            $this->load->view('admin/layouts/footer');

        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function update()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $update_id = $this->input->post('test_report_id');
            $duty_doctor_id = $this->input->post('duty_doctor_id');
            $duty_staff_id = $this->input->post('duty_staff_id');
            $duty_staff_id2 = $this->input->post('duty_staff_id2');            
            $specimen = $this->input->post('specimen');
            $comments = $this->input->post('comments');
            $testvalues = $this->input->post('testvalue');
            
            

            $testDetails = $this->Common_model->getTestDetails($test_id);

            $testReportData = array(
                'duty_doctor_id' => $duty_doctor_id,
                'duty_staff_id' => $duty_staff_id,
                'duty_staff_id2' => $duty_staff_id2,
                'comments' => $comments,
                //'specimen' => $specimen
            );

           

            $update = $this->Common_model->updateData('test_reports', $testReportData, array('record_id'=>$update_id));

            if (!empty($testvalues) && is_array($testvalues)) {
                
                foreach ($testvalues as $test_field_id => $value) {
                    $update_item = $this->Common_model->updateData('test_report_fields', array('value'=>$value), array('test_report_id'=>$update_id, 'test_field_id'=>$test_field_id));
                }
            }

                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                    redirect("test_result/show_report/".$update_id);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                     redirect("crud/previousPage");
                }

    } else {
        $data['wrong_msg'] = "";
        $this->load->view('website/login_check', $data);
    }
}
}
