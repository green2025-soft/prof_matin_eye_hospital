<?php

/**
 * 
 */
class Patient_admission extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		$data['title'] = 'Admission Invoice List';
		$data['page_title'] = 'Admission Invoice List';
		$data['info_header'] = 'Admission Invoice List';
		$from_date = $this->input->get('from_date');
		$to_date = $this->input->get('to_date');


		if (!isset($from_date) && !isset($to_date)) {
			$from_date = $to_date = date('Y-m-d');
		}

		$where = array();
		if (!admin()) {
			$where['show_hide'] = 'Show';
		}
		if (!empty($from_date) && !empty($to_date)) {
			$where['admission_date >= '] = $from_date;
			$where['admission_date <= '] = $to_date;
		} elseif (!empty($from_date) && empty($to_date)) {
			$where['admission_date'] = $from_date;
		} elseif (empty($from_date) && !empty($to_date)) {
			$where['admission_date'] = $to_date;
		}

		$data['values'] = $this->Common_model->findAll('admission_fee_invoice', $where, 'record_id', 'desc');
		$data['from_date'] = $from_date;
		$data['to_date'] = $to_date;

		$this->load->view('admin/layouts/header');
		$this->load->view('admin/patient_admission/index', $data);
		$this->load->view('admin/layouts/footer');
	}
	public function release_patient()
	{
		$data['title'] = 'All Release Patient';
		$data['page_title'] = 'All Release Patient';
		$data['info_header'] = 'All Release Patient';
		$where['patient_status'] = 'Release';
		$data['values'] = $this->Common_model->findAll('admission_fee_invoice', $where, 'record_id', 'desc');

		$where = array();
		if (!admin()) {
			$where['show_hide'] = 'Show';
		}
		$options = array(
			'joins' => array(
				array(
					'table' => 'patient',
					'condition' => 'patient.record_id = operation_invoice.patient_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor sergeon',
					'condition' => 'sergeon.record_id = operation_invoice.sergeon_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor anesthesia',
					'condition' => 'anesthesia.record_id = operation_invoice.anesthesia_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_category',
					'condition' => 'operation_category.record_id = operation_invoice.operation_category_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_name',
					'condition' => 'operation_name.record_id = operation_invoice.operation_name_id',
					'jointype' => 'LEFT'
				), array(
					'table' => 'beds',
					'condition' => 'beds.record_id = operation_invoice.bed_id',
					'jointype' => 'LEFT'
				),
			),
			'select' => 'operation_invoice.*,operation_invoice.created_by as user_by,operation_invoice.record_id as operation_invoice_record_id,patient.*,sergeon.name as sergeon_name,sergeon.designation as sergeon_designation,anesthesia.name as anesthesia_name,anesthesia.designation as anesthesia_designation,operation_category.category_name,operation_name.operation_name,beds.*',
			'where' => $where,
			'order' => array(
				'operation_invoice.record_id' => 'desc',
			),
		);
		$data['values'] = $this->Common_model->commonJoins("operation_invoice", $options);

		$this->load->view('admin/layouts/header');
		$this->load->view('admin/patient_admission/release_patient', $data);
		$this->load->view('admin/layouts/footer');
	}
	public function create()
	{
		$data['title'] = 'Admission Invoice';
		$data['page_title'] = 'Admission Invoice';
		$data['info_header'] = '';
		$max = $this->Common_model->findMax('admission_fee_invoice', array(), 'admission_no');
		$admission_no = isset($max) ? $max->admission_no + 1 : 1;
		$data['admission_no'] = str_pad($admission_no, 4, 0, STR_PAD_LEFT);
		$data['blood_group'] = $this->Common_model->findAll('blood_groups',array(''),'group_name','asc');
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/patient_admission/create', $data);
		$this->load->view('admin/layouts/footer');
	}
	public function edit($record_id)
	{
		$data['title'] = 'Edit Admission OBS/OPS';
		$data['page_title'] = 'Edit Admission OBS/OPS';
		$data['info_header'] = '';
		$data['value'] = $this->Common_model->findById('admission_fee_invoice', array('record_id' => $record_id));
		$data['patient'] = $this->Common_model->findById('patient', array('record_id' => $data['value']->patient_id));
		$data['operation_names'] = $this->Common_model->findAll('operation_name',array('category_id'=>$data['value']->operation_category_id),'operation_name','asc');

		$data['bed'] = $this->Common_model->findById('beds',array('record_id'=>$data['value']->bed_id));
		 $data['beds'] = $this->Common_model->findAll('beds',array('opd_cabin_ward'=>$data['value']->opd_cabin_ward),'bed_no','asc');

		$this->load->view('admin/layouts/header');
		$this->load->view('admin/patient_admission/create', $data);
		$this->load->view('admin/layouts/footer');
	}
	public function saveOrUpdate()
	{
		$input = $_POST;
		$patient_id = $input['patient_id'];
		$patient_name = $input['patient_name'];
		$patient_father_name = $input['patient_father_name'];
		$patient_mother_name = $input['patient_mother_name'];
		$patient_spouse_name = $input['patient_spouse_name'];
		$patient_blood_group = $input['patient_blood_group'];
		$patient_occupation = $input['patient_occupation'];
		$mobile = $input['mobile'];
		$age = $input['age'];
		$gender = $input['gender'];
		$address = $input['address'];
		$village = $input['village'];
		$post_office = $input['post_office'];
		$thana = $input['thana'];
		$district = $input['district'];
		$update_id = $input['update_id'];
		$operation_category_id = $input['operation_category_id'];
		$operation_name_id = $input['operation_name_id'];
		unset($input['update_id']);
		unset($input['patient_name']);
		unset($input['patient_father_name']);
		unset($input['patient_mother_name']);
		unset($input['patient_spouse_name']);
		unset($input['patient_blood_group']);
		unset($input['patient_occupation']);
		unset($input['age']);
		unset($input['gender']);
		unset($input['mobile']);
		unset($input['address']);
		unset($input['village']);
		unset($input['post_office']);
		unset($input['district']);
		unset($input['thana']);
		//unset($input['operation_category_id']);
		//unset($input['operation_name_id']);
		if (!$patient_id) {
			$patient_data = array(
				'name' => $patient_name,
				'patient_father_name' => $patient_father_name,
				'patient_mother_name' => $patient_mother_name,
				'patient_spouse_name' => $patient_spouse_name,
				'patient_blood_group' => $patient_blood_group,
				'patient_occupation' => $patient_occupation,
				'mobile' => $mobile,
				'age' => $age,
				'gender' => $gender,
				'address' => $address,
				'village' => $village,
				'post_office' => $post_office,
				'district' => $district,
				'thana' => $thana
			);
			$patient_id = $this->Common_model->saveData('patient', $patient_data);
		}
		$input['patient_id'] = $patient_id;
		$date  = $input['admission_date'];
		$prefix = 'Adm' . date("Ymd", strtotime($date));
		$maxInvoice = $this->Common_model->findMax('create_bill', array('prefix' => $prefix, 'type' => 'Admission'), 'invoice_no');
		$invoice_no = isset($maxInvoice) ? $maxInvoice->invoice_no + 1 : 1;
		$invoice_data = array(
			'date' => $date,
			'prefix' => $prefix,
			'invoice_no' => $invoice_no,
			'type' => 'Admission',
			'particular' => "Admission Invoice Fee",
			'patient_id' => $input['patient_id'],
			'amount' => $input['admission_fee'],
			'discount' => 0,
			'sub_total' => $input['admission_fee'],
			'paid' => $input['admission_fee'],
			'due' => 0,
			'advance' => $input['advance_amount']
		);
		if ($update_id == 0 || empty($update_id)) {
			$invoice_id = $this->Common_model->saveData('create_bill', $invoice_data);
			$input['invoice_id'] = $invoice_id;
			$input['prefix'] = $prefix;
			$input['invoice_no'] = $invoice_no;
				$this->Common_model->updateData('beds', array('bed_status'=>'Booked'), array('record_id'=>$input['bed_id']));
			$insert = $this->Common_model->saveData('admission_fee_invoice', $input);
			$update_id = $insert;
			if ($insert) {
				$this->session->set_flashdata('message', INSERT_MSG);
			} else {
				$this->session->set_flashdata('message', INSERT_ERROR_MSG);
			}
		} else {
			$admission_invoice = $this->Common_model->findById('admission_fee_invoice', array('record_id' => $update_id));
			if ($date == $admission_invoice->admission_date) {
				$bill = $this->Common_model->findById('create_bill', array('record_id' => $admission_invoice->invoice_id));
				$invoice_data['invoice_no'] = $bill->invoice_no;
				$input['invoice_no'] = $admission_invoice->invoice_no;
			}
			$this->Common_model->updateData('create_bill', $invoice_data, array('record_id' => $admission_invoice->invoice_id));
				$this->Common_model->updateData('beds', array('bed_status'=>'Booked'), array('record_id'=>$input['bed_id']));
			$update = $this->Common_model->updateData('admission_fee_invoice', $input, array('record_id' => $update_id));
			if ($update) {
				$this->session->set_flashdata('message', UPDATE_MSG);
			} else {
				$this->session->set_flashdata('message', UPDATE_ERROR_MSG);
			}
			redirect("patient_admission/view2/$update_id");
		}
		redirect("patient_admission/view/$update_id");
	}

	public function view($record_id)
	{
		$data['title'] = 'View Patient Admission';
		$data['page_title'] = 'View Patient Admission';
		$data['info_header'] = '';
		$data['redirect'] =  base_url('patient_admission/create');
		$data['value'] = $this->Common_model->findById('admission_fee_invoice', array('record_id' => $record_id));
		$data['value']->date = $data['value']->admission_date;
		$data['patient'] = $this->Common_model->findById('patient', array('record_id' => $data['value']->patient_id));
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/patient_admission/view', $data);
		$this->load->view('admin/layouts/footer');
	}
	public function view2($record_id)
	{
		$data['title'] = 'View Patient Admission';
		$data['page_title'] = 'View Patient Admission';
		$data['info_header'] = '';
		$data['redirect'] =  base_url('patient_admission');
		$data['value'] = $this->Common_model->findById('admission_fee_invoice', array('record_id' => $record_id));
		$data['value']->date = $data['value']->admission_date;
		$data['patient'] = $this->Common_model->findById('patient', array('record_id' => $data['value']->patient_id));
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/patient_admission/view', $data);
		$this->load->view('admin/layouts/footer');
	}

	public function release($record_id)
	{
		$user_type = $this->session->ses_user_type;
		if ($user_type == "admin"  || $user_type == "staff") {
			$data['patient_status'] = 'Release';
			$update = $this->Common_model->updateData('admission_fee_invoice', $data, array('record_id' => $record_id));
			if ($update) {
				$this->session->set_flashdata('message', UPDATE_MSG);
			} else {
				$this->session->set_flashdata('message', UPDATE_ERROR_MSG);
			}
			redirect('patient_admission/release_patient', 'refresh');
		} else {
			$data['wrong_msg'] = "";
			$this->load->view('website/login_check', $data);
		}
	}

	public function delete($id)
	{
		$user_type = $this->session->ses_user_type;
		if ($user_type == "admin"  || $user_type == "staff") {
			$admission_fee_invoice = $this->Common_model->findById('admission_fee_invoice', array('record_id' => $id));
			if ($this->Common_model->delete_info('record_id', $id, 'admission_fee_invoice')) {
				$this->Common_model->delete_info('record_id', $admission_fee_invoice->invoice_id, 'create_bill');
				$this->session->set_flashdata('message', DELETE_MSG);
			} else {
				$this->session->set_flashdata('message', DELETE_ERROR_MSG);
			}
			redirect('patient_admission', 'refresh');
		} else {
			$data['wrong_msg'] = "";
			$this->load->view('website/login_check', $data);
		}
	}

	public function getOperationName()
	{
		$category_id = $this->input->post('category_id');
		$names = $this->Common_model->get_all_info_by_array('operation_name', ['category_id' => $category_id]);
		$data = "<option value=''>-- Select --</option>";
		foreach ($names as $name) {
			$data .= "<option value='$name->record_id'>$name->operation_name</option>";
		}
		echo json_encode($data);
	}
	public function getOperationPrice()
	{
		$operation_id = $this->input->post('operation_id');
		$patient_id = $this->input->post('patient_id');

		$operationsPrices = 0;
		$advanceAmount = 0;

		$operation = $this->Common_model->findById('operation_name', ['record_id' => $operation_id]);
		//var_dump($operation_id);die;
		$operationsPrices = isset($operation) ? $operation->rate : 0;
		$where['patient_id'] = $patient_id;
		//$where['operation_id'] = $operation_id ;

		$advance_amount = $this->Common_model->calCulateSum('admission_fee_invoice', $where, 'advance_amount');


		$paid_amount = $this->Common_model->calCulateSum('operation_details', $where, 'advance_amount');
		$return_amount = $this->Common_model->calCulateSum('operation_details', $where, 'return_amount');


		$patientPaidAmount = $paid_amount + $return_amount;

		$balannce = $advance_amount - $patientPaidAmount;

		$data = array(
			'rate' => $operationsPrices,
			'advance_fee' => $balannce,
		);
		echo json_encode($data);
	}
	public function get_admissiom()
	{
		$record_id  = $this->input->post('admission_id');
		$admission = $this->Common_model->findById('admission_fee_invoice', array('record_id' => $record_id));
		$patient = $this->Common_model->findById('patient', array('record_id' => $admission->patient_id));
		$ot = $this->Common_model->findById('operation_name', array('record_id' => $admission->operation_name_id));
		$admission->patient = $patient;
		$admission->ot = $ot;
		echo json_encode($admission);
		exit;
	}
}
