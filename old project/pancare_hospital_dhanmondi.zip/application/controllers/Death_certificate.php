<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Death_certificate extends CI_Controller
{

 	private $table = 'death_certificates';
 	private $title = 'Death Certificate';
 	private $bUrl = 'death_certificate';
	
	public function __construct()
	{
		parent::__construct();
	}
	public function index()
	{
		$data['title'] = "{$this->title} List";
		$data['page_title'] = $data['title'];
		
		$data['values'] = $this->db->order_by('id', 'DESC')->get($this->table)->result();
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/death_certificate/index', $data);
		$this->load->view('admin/layouts/footer');
	}
	public function create()
	{
		$data['title'] = "Create {$this->title}";
		$data['page_title'] = $data['title'];
		
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/death_certificate/create', $data);
		$this->load->view('admin/layouts/footer');
	}



	public function saveOrUpdate()
	{

		$input 		= $this->input->post();
		$user_type 	= $this->session->ses_user_type;
		if ($user_type == "admin" || $user_type == "staff") {
			$update_id = $input['update_id'];
			unset($input['update_id']);
			if (empty($update_id) || $update_id == 0) {
				$input['reg_no'] = $this->generate_reg_no();
				$this->db->insert($this->table, $input);
				 $this->session->set_flashdata('message', INSERT_MSG);
			}else{
				$this->db->where('id', $update_id)
				->update($this->table, $input);
				$this->session->set_flashdata('message', UPDATE_MSG);
			}
			redirect($this->bUrl, 'refresh');
		}
	}

	public function view($income_id)
	{
		$data['title'] = "View {$this->title}";
		$data['page_title'] = $data['title'];
		$data['signatureType'] = 'Staff';
		$data['redirect'] = base_url($this->bUrl);
		$data['value'] = $this->Common_model->findById( $this->table, array('id' => $income_id));
		
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/death_certificate/view', $data);
		$this->load->view('admin/layouts/footer');
	}

	public function edit($income_id)
	{
		$data['title'] = "Edit {$this->title}";
		$data['page_title'] = $data['title'];
		$data['value'] = $this->Common_model->findById( $this->table, array('id' => $income_id));
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/death_certificate/create', $data);
		$this->load->view('admin/layouts/footer');;
	}

	public function delete($id)
	{
		$user_type = $this->session->ses_user_type;
		if ($user_type == "admin"  || $user_type == "staff") {
			$delete = $this->Common_model->delete_info('id', $id, $this->table);;
			if (isset($delete)) {
				$this->session->set_flashdata('message', DELETE_MSG);
			} else {
				$this->session->set_flashdata('message', DELETE_ERROR_MSG);
			}
			redirect($this->bUrl, 'refresh');
		} else {
			$data['wrong_msg'] = "";
			$this->load->view('website/login_check', $data);
		}
	}


	private function generate_reg_no()
	{
		$this->db->select_max('id');

		$row = $this->db->get($this->table)->row();

		$next_id = ($row->id ?? 0) + 1;

		return str_pad($next_id, 8, '0', STR_PAD_LEFT);
	}

	
}
