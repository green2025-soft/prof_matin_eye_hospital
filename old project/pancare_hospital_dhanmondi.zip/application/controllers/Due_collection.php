<?php

defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

/** @property Common_model $Common_model */

class Due_collection extends CI_Controller
{

  public function __construct()
  {
    parent::__construct();
  }
  public function index()
  {
    $user_type = $this->session->ses_user_type;
    if ($user_type == "admin" || $user_type == "staff") {
      $data['title'] = 'Due Collection List';
      $data['page_title'] = 'Due Collection List';

      $from_date  = $this->input->get('from_date')??date('Y-m-d');
      $to_date    = $this->input->get('to_date')??date('Y-m-d');
      $type       = $this->input->get('type')??'outdoor';

     
     
      $data['values']     = $this->Common_model->getDueCollections($from_date, $to_date, $type);
      $data['from_date']  = $from_date;
      $data['to_date']    = $to_date;
      $data['type']       = $type;

      $this->load->view('admin/layouts/header');
      $this->load->view('admin/due_collection/index', $data);
      $this->load->view('admin/layouts/footer');
    } else {
      $data['wrong_msg'] = "";
      $this->load->view('website/login_check', $data);
    }
  }
  public function Create()
  {
    $user_type = $this->session->ses_user_type;
    if ($user_type == "admin" || $user_type == "staff") {
      $data['title'] = 'Due Collection';
      $data['page_title'] = 'Due Collection';
      $data['page_title2'] = 'Patient Due List';
      $data['info_header'] = '';
      $today = date('Y-m-d');
      $where = array();
      $where['date'] = $today;
      //$where['type'] = 'Test Invoice'; 
      // if($record_id) $where['record_id'] = $record_id ;
      $invoices = $this->Common_model->findAll('create_bill', $where, 'record_id', 'desc');
      $invoice_list = array();
      foreach ($invoices as $info) {
        $sub_total = $info->sub_total;
        if ($info->type == 'Collection') {
          $sub_total = 0;
        }
        if ($info->type == 'Admission') {
          $sub_total += $info->advance;
        }


        $paid = $info->paid;
        if ($info->type == 'Operation') {
          $paid += ($info->medicine_cost);
        }
        if ($info->type == 'Admission') {
          $paid += ($info->advance);
        }

        $collection = $this->Common_model->calCulateSum('due_collection_details', array('invoice_id' => $info->record_id), 'current_collection');
        $collection = isset($collection) ? $collection : 0;
        $paid_amount = $paid + $collection;

        $due_amount = $sub_total - $paid_amount;

        if ($due_amount > 0) {
          $invoice_list[] = $info;
        }
      }

      $data['invoice_list'] = $invoice_list;

      $this->load->view('admin/layouts/header');
      $this->load->view('admin/due_collection/create', $data);
      $this->load->view('admin/layouts/footer');
    } else {
      $data['wrong_msg'] = "";
      $this->load->view('website/login_check', $data);
    }
  }
  public function saveOrUpdate()
  {
    $mr_date = $this->input->post('mr_date');
    $patient_id = $this->input->post('patient_id');
    $invoice_amounts = $this->input->post('invoice_amount');
    $discount_types = $this->input->post('discount_type');
    $reference_bys = $this->input->post('reference_by');
    $invoice_ids = $this->input->post('invoice_id');
    $invoice_types = $this->input->post('invoice_type');
    $collection_type = $this->input->post('collection_type');
    $discount_amounts = $this->input->post('discount_amount');
    $current_collections = $this->input->post('current_collection');
    $remarkss = $this->input->post('remarks');
    $mr_amount = array_sum($current_collections);
    $prefix  = str_replace('-', '', $mr_date);
    $maxMr = $this->Common_model->findMax('due_collections', array('prefix' => $prefix), 'mr_no');
    $mr_no = isset($maxMr) ? $maxMr->mr_no + 1 : 1;

    if ($mr_amount > 0) {
      $prefix1 = 'Col' . date("Ymd", strtotime($mr_date));
      $maxInvoice1 = $this->Common_model->findMax('create_bill', array('prefix' => $prefix, 'type' => 'Collection'), 'invoice_no');
      $invoice_no1 = isset($maxInvoice1) ? $maxInvoice1->invoice_no + 1 : 1;

      $invoice_data = array(
        'date' => $mr_date,
        'prefix' => $prefix1,
        'invoice_no' => $invoice_no1,
        'type' => 'Collection',
        'particular' =>'Due Collection',
        'patient_id' => $patient_id[0],
        'amount' => $mr_amount,
        'sub_total' => $mr_amount,
        'paid' => $mr_amount,
        'due' => 0,
        'advance' => 0,
        'return_amount' => 0,
        'comments' => $remarkss[0],
      );

      $loginId = $this->session->userData('ses_record_id');
      $invoice_data['created_by'] = $loginId;
       $this->db->insert('create_bill', $invoice_data);
      $invoice_id = $this->db->insert_id();

      // $invoice_id = $this->Common_model->saveData('create_bill', $invoice_data);

      $mr = array(
        'invoice_id' => $invoice_id,
        'patient_id' => $patient_id[0],
        'collection_type' => $collection_type,
        'prefix' => $prefix,
        'mr_no' => $mr_no,
        'mr_date' => $mr_date,
        'mr_amount' => $mr_amount,
        'discount_type' => $discount_types[0],
        'reference_by' => $reference_bys[0],
        'discount_amount' => $discount_amounts[0],
        'remarks' => $remarkss[0],
        'ivf_status' => ($invoice_types[0] === 'IVF Test Invoice') ? 1 : 0,
      );
    }
    $insert = $mr_id = $this->Common_model->saveData('due_collections', $mr);

    if ($mr_id) {
      foreach ($current_collections as $key => $value) {
        if ($value > 0) {
          $data = array(
            'mr_id' => $mr_id,
            'mr_date' => $mr_date,
            'invoice_type' => $invoice_types[$key],
            'collection_type' => $collection_type,
            'patient_id' => $patient_id[$key],
            'invoice_id' => $invoice_ids[$key],
            'invoice_amount' => $invoice_amounts[$key],
            'current_collection' => $value,
            'discount_amount' => $discount_amounts[$key],
            'discount_type' => $discount_types[$key],
            'reference_by' => $reference_bys[$key],
            'remarks' => $remarkss[$key],
            'ivf_status' => ($invoice_types[$key] === 'IVF Test Invoice') ? 1 : 0,
          );
          $this->Common_model->saveData('due_collection_details', $data);
          $invoice = $this->Common_model->findById('create_bill', array('record_id' => $invoice_ids[$key]));
          $prev_discount_amount = isset($invoice) ? $invoice->discount : 0;
          $prev_paid_amount = isset($invoice) ? $invoice->paid : 0;
          $invoice_amount = isset($invoice) ? $invoice->amount : 0;
          $discount_amount = $discount_amounts[$key] + $prev_discount_amount;
          $discount_percentage = ($discount_amount * 100) / $invoice_amount;
          $sub_total = $invoice_amount - $discount_amount;
          $paid_amount = $value + $prev_paid_amount;
          $due_amount = $sub_total - $prev_paid_amount; //$paid_amount ;

          $updateInvoice = array(
            'discount_percentage' => round($discount_percentage, 2),
            'discount' => $discount_amount,
            'sub_total' => $sub_total,
            'due' => $due_amount,
            'comments' => $remarkss[$key],
          );

          $this->db->update('create_bill', $updateInvoice, ['record_id' => $invoice_ids[$key]]);
          // $this->Common_model->updateData('create_bill', $updateInvoice, array('record_id' => $invoice_ids[$key]));
        }
      }
      if ($insert) {
        $this->session->set_flashdata('message', INSERT_MSG);
      } else {
        $this->session->set_flashdata('message', INSERT_ERROR_MSG);
      }
    }
    redirect("due_collection/view/$mr_id");
  }

  public function view($mr_id)
  {
    $data['title'] = "Due Collection";
    $data['page_title'] = "Due Collection";
    $data['info_header'] = "";
    $data['signatureType'] = 'Staff';
    $data['redirect'] = base_url('due_collection/create');
    $data['value'] = $this->Common_model->findById('due_collections', array('mr_id' => $mr_id));
    $data['value']->date = $data['value']->mr_date;
    $data['patient'] = $this->Common_model->findById('patient', array('record_id' => $data['value']->patient_id));

    $where = array('due_collection_details.mr_id ' => $mr_id);
    $options = array(
      'joins' => array(
        array(
          'table' => 'create_bill',
          'condition' => 'create_bill.record_id = due_collection_details.invoice_id',
          'jointype' => 'LEFT'
        )
      ),
      'select' => 'due_collection_details.*,create_bill.prefix,create_bill.invoice_no,create_bill.amount,create_bill.sub_total,create_bill.discount,create_bill.paid',
      'where' => $where,
      'order' => array(
        'due_collection_details.mr_details_id' => 'asc',
      ),
    );
    $data['values'] = $this->Common_model->commonJoins("due_collection_details", $options);

    $this->load->view('admin/layouts/header');
    $this->load->view('admin/due_collection/invoice', $data);
    $this->load->view('admin/layouts/footer');
  }
  public function view2($mr_id)
  {
    $data['title'] = "Due Collection";
    $data['page_title'] = "Due Collection";
    $data['info_header'] = "";
    $data['signatureType'] = 'Staff';
    $data['redirect'] = base_url('due_collection');
    $data['value'] = $this->Common_model->findById('due_collections', array('mr_id' => $mr_id));
    $data['value']->date = $data['value']->mr_date;
    $data['patient'] = $this->Common_model->findById('patient', array('record_id' => $data['value']->patient_id));

    $where = array('due_collection_details.mr_id ' => $mr_id);
    $options = array(
      'joins' => array(
        array(
          'table' => 'create_bill',
          'condition' => 'create_bill.record_id = due_collection_details.invoice_id',
          'jointype' => 'LEFT'
        )
      ),
      'select' => 'due_collection_details.*,create_bill.prefix,create_bill.invoice_no,create_bill.amount,create_bill.sub_total,create_bill.discount,create_bill.paid',
      'where' => $where,
      'order' => array(
        'due_collection_details.mr_details_id' => 'asc',
      ),
    );
    $data['values'] = $this->Common_model->commonJoins("due_collection_details", $options);

    $this->load->view('admin/layouts/header');
    $this->load->view('admin/due_collection/invoice', $data);
    $this->load->view('admin/layouts/footer');
  }

  public function load_patient()
  {
    $invoice_id = $this->input->post('invoice_id');
    $where['record_id'] = $invoice_id;
    $data['values'] = $this->Common_model->findAll('create_bill', $where, 'record_id', 'asc');
    $this->load->view('admin/due_collection/invoice_list', $data);
  }

  public function delete($id)
  {
    $user_type = $this->session->ses_user_type;
    if ($user_type == "admin"  || $user_type == "staff") {
      $mr = $this->Common_model->findById('due_collections', array('mr_id' => $id));
      $mr_details = $this->Common_model->findAll('due_collection_details', array('mr_id' => $id), 'mr_details_id', 'asc');
      if (isset($mr)) {
        $this->Common_model->delete_info('mr_id', $id, 'due_collections');
        foreach ($mr_details as $key => $value) {
          $bill = $this->Common_model->findById('create_bill', array('record_id' => $value->invoice_id));
          $discount_amount = $bill->discount - $value->discount_amount;
          $sub_total = $bill->sub_total + $value->discount_amount;
          $due = $sub_total - $bill->paid;
          $updataData = array(
            'sub_total' => $sub_total,
            'discount' => $discount_amount,
            'due' => $due
          );
          //var_dump($updataData);die;
          $this->db->update('create_bill', $updataData, array('record_id' => $value->invoice_id));
          //$this->Common_model->updateData('create_bill',$updataData,array('record_id'=>$value->invoice_id));
        }
        $this->Common_model->delete_info('mr_id', $id, 'due_collection_details');
         $this->db->where('record_id',  $mr->invoice_id)->delete('create_bill');
        // $this->Common_model->delete_info('record_id', $mr->invoice_id, 'create_bill');


        $this->session->set_flashdata('message', DELETE_MSG);
      } else {
        $this->session->set_flashdata('message', DELETE_ERROR_MSG);
      }
      redirect('due_collection', 'refresh');
    } else {
      $data['wrong_msg'] = "";
      $this->load->view('website/login_check', $data);
    }
  }

  public function show_patient_due_invoice()
  {
    $date = $this->input->post("date");
    $where = array();
    $where['date'] = $date;
    //$where['type'] = 'Test Invoice'; 
    // if($record_id) $where['record_id'] = $record_id ;
    $invoices = $this->Common_model->findAll('create_bill', $where, 'record_id', 'desc');
    $options = "<option value=''>--Select--</option>";
    foreach ($invoices as $info) {
      $patient = $this->Common_model->findById('patient', array('record_id' => $info->patient_id));
      $patient_name = isset($patient) ? ' - ' . $patient->name . "[$info->patient_id]" : "";
      $sub_total = $info->sub_total;
      if ($info->type == 'Collection') {
        $sub_total = 0;
      }
      if ($info->type == 'Admission') {
        $sub_total += $info->advance;
      }


      $paid = $info->paid;
      if ($info->type == 'Operation') {
        $paid += ($info->medicine_cost);
      }
      if ($info->type == 'Admission') {
        $paid += ($info->advance);
      }

      $collection = $this->Common_model->calCulateSum('due_collection_details', array('invoice_id' => $info->record_id), 'current_collection');
      $collection = isset($collection) ? $collection : 0;
      $paid_amount = $paid + $collection;

      $due_amount = $sub_total - $paid_amount;

      if ($due_amount > 0) {
        $patient_invoice = $info->prefix . $info->invoice_no . $patient_name;
        $options .= "<option value='$info->record_id'>$patient_invoice</option>";
      }
    }
    echo $options;
    exit;
  }
}
