<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Dressing extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
        
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Dressing List';
            $data['page_title'] = 'Dressing List';
            $data['info_header'] = 'Dressing List';
            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');

            if (!isset($from_date) && !isset($to_date) && !isset($doctor_id) && !isset($test_id)) {
                $from_date = $to_date = date('Y-m-d');
            }
            $where = array();
            if (!admin()) {
                $where['dressing.show_hide'] = 'Show';
            }

            if (!empty($from_date) && !empty($to_date)) {
                $where['date >= '] = $from_date;
                $where['date <= '] = $to_date;
            } elseif (!empty($from_date) && empty($to_date)) {
                $where['date'] = $from_date;
            } elseif (empty($from_date) && !empty($to_date)) {
                $where['date'] = $to_date;
            }
            $options = array(
                'joins' => array(
                    array(
                        'table' => 'doctor as service',
                        'condition' => 'service.record_id = dressing.service_doctor',
                        'jointype' => 'LEFT'
                    ),
                    array(
                        'table' => 'doctor as referred',
                        'condition' => 'referred.record_id = dressing.referred_doctor',
                        'jointype' => 'LEFT'
                    ),
                    array(
                        'table' => 'patient',
                        'condition' => 'patient.record_id = dressing.patient_id',
                        'jointype' => 'LEFT'
                    ),
                    array(
                        'table' => 'department',
                        'condition' => 'department.record_id = dressing.department_id',
                        'jointype' => 'LEFT'
                    ),
                ),
                'select' => 'dressing.*,dressing.record_id as dressing_id,service.record_id as service_id,service.name as service_doctor,service.mobile as service_doctor_mobile,service.designation as service_doctor_designation,referred.record_id as referred_id ,referred.name as referred_doctor,referred.mobile as referred_doctor_mobile,referred.designation as referred_doctor_designation,department.department,patient.*',
                'where' => $where,
                'order' => array(
                    'dressing.record_id' => 'desc',
                ),
            );

            $data['values'] = $this->Common_model->commonJoins("dressing", $options);
            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;

            $this->load->view('admin/layouts/header');
            $this->load->view('admin/dressing/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }    
    public function create() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Create Dressing';
            $data['page_title'] = 'Create Dressing';
            $data['info_header'] = '';
            $max = $this->Common_model->findMax('dressing',array(),'dressing_no') ;
            $dressing_no = isset($max)?$max->dressing_no + 1 : 1;
            $data['dressing_no'] = str_pad($dressing_no,4,0,STR_PAD_LEFT );
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/dressing/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function edit($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Create Dressing';
            $data['page_title'] = 'Create Dressing';
            $data['info_header'] = '';
            $data['value'] = $this->Common_model->findById('dressing',array('record_id'=>$record_id));
            $data['values'] = $this->Common_model->findAll('dressing_details',array('dressing_id'=>$record_id),"record_id","asc");
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/dressing/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            if(array_key_exists('record_id',$input)){
                $record_ids = $input['record_id'] ;
                $head_ids = $input['head_id'] ;
                $unit_names = $input['unit_name'] ;
                $amounts = $input['amount'] ;
                $total_amounts = $input['total_amount'] ;
                unset($input['record_id']);
                unset($input['head_id']);
                unset($input['unit_name']);
                unset($input['amount']);
                unset($input['total_amount']);
            }
            unset($input['update_id']);

            $date = $input['date'];
            $prefix = 'Dre'. str_replace('-', '', $date) ;
            $max = $this->Common_model->findMax('create_bill',array('prefix'=>$prefix),'invoice_no') ;
            $invoice_no = isset($max)?$max->invoice_no + 1 : 1;
                
            $data = array(
                'type'=>'Dressing',
                'prefix'=>$prefix,
                'invoice_no'=>$invoice_no,
                'date'=>$date,
                'particular'=>'Dressing',
                'patient_id'=>$input['patient_id'],
                'doctor_id'=>$input['service_doctor'],
                'doctor_commission'=>$input['doctor_commission'],
                'amount'=>$input['receive_amount'],
                'discount'=>$input['discount_amount'],
                'sub_total'=>$input['sub_total_amount'],
                'paid'=>$input['sub_total_amount'],
                'comments'=>$input['comments'],
            );
               

            if($update_id == 0 || empty($update_id)){     
                $invoice_id = $this->Common_model->saveData('create_bill', $data);  
                $input['invoice_id'] = $invoice_id ;
                $insert = $this->Common_model->saveData('dressing', $input);
                if(isset($record_ids)){
                    $details = array();
                    foreach ($record_ids as $key => $value) {
                        $data = array(
                            'dressing_id'=>$insert,
                            'date'=>$date,
                            'head_id'=>$head_ids[$key],
                            'unit_name'=>$unit_names[$key],
                            'amount'=>$amounts[$key],
                            'total_amount'=>$total_amounts[$key],
                            'created_by'=>$this->session->userdata('ses_record_id')
                        );
                        $details[] = $data ;
                    }
                    $this->Common_model->save_batch("dressing_details",$details);
                }
                $update_id = $insert ;
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $emergency = $this->Common_model->findById('dressing',array('record_id'=>$update_id));
                if($date == $emergency->date){
                    $bill = $this->Common_model->findById('create_bill',array('record_id'=>$emergency->invoice_id));
                    $data['invoice_no'] = $bill->invoice_no ;
                }
                $this->Common_model->updateData('create_bill', $data,array('record_id'=>$emergency->invoice_id));
                $update = $this->Common_model->updateData('dressing', $input,array('record_id'=>$update_id));
                if(isset($record_ids)){
                    $details = array();
                    foreach ($record_ids as $key => $value) {
                        $data = array(
                            'dressing_id'=>$update_id,
                            'date'=>$date,
                            'head_id'=>$head_ids[$key],
                            'unit_name'=>$unit_names[$key],
                            'amount'=>$amounts[$key],
                            'total_amount'=>$total_amounts[$key], 
                        );
                        if($value){
                            $this->Common_model->updateData("dressing_details",$data,array('record_id'=>$value));
                        }else{
                            $this->Common_model->saveData("dressing_details",$data);
                        }
                    }
                }
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
                 redirect("dressing/view2/$update_id", 'refresh');
            }
            redirect("dressing/view/$update_id", 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function view($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Dressing Service Receipt';
            $data['page_title'] = 'Dressing Service Receipt';
            $data['info_header'] = '';
            $data['signatureType'] = 'Patient';
            $data['redirect'] = base_url('dressing/create');
            $where = array('dressing.record_id'=>$record_id);
            $options = array(
                'joins' => array(
                    array(
                        'table' => 'doctor as service',
                        'condition' => 'service.record_id = dressing.service_doctor',
                        'jointype' => 'LEFT'
                    ),
                    array(
                        'table' => 'patient',
                        'condition' => 'patient.record_id = dressing.patient_id',
                        'jointype' => 'LEFT'
                    ),
                ),
                'select' => 'dressing.*,dressing.created_at as dress_created_at,dressing.record_id as dressing_id,service.record_id as service_id,service.name as service_doctor,service.mobile as service_doctor_mobile,service.designation as service_doctor_designation,patient.*',
                'where' => $where,
                'order' => array(
                    'dressing.record_id' => 'desc',
                ),
            );

            $data['value'] = $this->Common_model->commonJoinsRow("dressing", $options);
            $data['values'] = $this->Common_model->findAll('dressing_details',array('dressing_id'=>$record_id),"record_id","asc");
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/dressing/view', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function view2($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Dressing Service Receipt';
            $data['page_title'] = 'Dressing Service Receipt';
            $data['info_header'] = '';
            $data['signatureType'] = 'Patient';
            $data['redirect'] = base_url('dressing');
            $where = array('dressing.record_id'=>$record_id);
            $options = array(
                'joins' => array(
                    array(
                        'table' => 'doctor as service',
                        'condition' => 'service.record_id = dressing.service_doctor',
                        'jointype' => 'LEFT'
                    ),
                    array(
                        'table' => 'patient',
                        'condition' => 'patient.record_id = dressing.patient_id',
                        'jointype' => 'LEFT'
                    ),
                ),
                'select' => 'dressing.*,dressing.created_at as dress_created_at,dressing.record_id as dressing_id,service.record_id as service_id,service.name as service_doctor,service.mobile as service_doctor_mobile,service.designation as service_doctor_designation,patient.*',
                'where' => $where,
                'order' => array(
                    'dressing.record_id' => 'desc',
                ),
            );

            $data['value'] = $this->Common_model->commonJoinsRow("dressing", $options);
            $data['values'] = $this->Common_model->findAll('dressing_details',array('dressing_id'=>$record_id),"record_id","asc");
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/dressing/view', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            $dressing = $this->Common_model->findById('dressing',array('record_id'=>$id));
            if($this->Common_model->delete_info('record_id', $id, 'dressing')){
                $this->Common_model->delete_info('record_id', $dressing->invoice_id, 'create_bill') ;
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
            redirect('dressing', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
