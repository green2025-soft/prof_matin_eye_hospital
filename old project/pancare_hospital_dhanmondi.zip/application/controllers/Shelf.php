<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Shelf extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Shelf';
            $data['page_title'] = 'Shelf';
            $data['info_header'] = 'All Shelf';
            $data['values'] = $this->Common_model->findAll('shelf',array(),'record_id','desc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/shelf/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            unset($input['update_id']);
            //$shelf_name = $input['shelf_name'];
            if($update_id == 0 || empty($update_id)){       
                // $getRow = $this->Common_model->findById('shelf',array('shelf_name'=>$shelf_name));
                // if(isset($getRow)){
                //     $this->session->set_flashdata('message', EXIST_MSG);
                //     redirect('shelf', 'refresh');
                // }
                $insert = $this->Common_model->saveData('shelf', $input);
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $update = $this->Common_model->updateData('shelf', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            redirect('shelf', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $id, 'shelf')){
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
           // redirect("crud/previousPage");
            redirect('shelf', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
