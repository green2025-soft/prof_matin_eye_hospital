<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Patient extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Patient Information';
            $data['page_title'] = 'Patient Information';
            $data['values'] = $this->Common_model->findAll('patient',array(),'record_id','desc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/patient/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function create() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Insert Patient Information';
            $data['page_title'] = 'Insert Patient Information';
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/patient/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function edit($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Edit Patient Information';
            $data['page_title'] = 'Edit Patient Information';
            $data['value'] = $this->Common_model->findById('patient',array('record_id'=>$record_id)) ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/patient/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            unset($input['update_id']);
            if($update_id == 0 || empty($update_id)){       
                $popup = $this->input->post('popup');
                if(isset($popup)){
                    unset($input['popup']);
                }
                $insert = $this->Common_model->saveData('patient', $input);
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
                if(isset($popup)){
                    $patient = $this->Common_model->findById('patient',array('record_id'=>$insert));
                    echo json_encode($patient);
                    exit(0);
                }
            }else{
                $update = $this->Common_model->updateData('patient', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            redirect('patient', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $id, 'patient')){
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
            redirect('patient', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function getPatientInfo($patientId){


        $patientData = $this->db->select('record_id, 
                                          patient_father_name, 
                                          patient_mother_name, 
                                          patient_spouse_name, 
                                          patient_blood_group,
                                          gender,
                                          age,
                                          mobile,
                                          address,
                                          village,
                                          post_office,
                                          thana,
                                          address,
                                          district')
                                ->get_where('patient', ['record_id' => $patientId])
                                ->row();

        if(!empty($patientData)){
            echo json_encode($patientData);
            exit;
        }

        echo 0;
    }
}
