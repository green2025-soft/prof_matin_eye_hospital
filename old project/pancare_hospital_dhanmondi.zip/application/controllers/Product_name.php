<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Product_name extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('upload');
    }
    public function create_lab_product() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $warehouse = "Lab" ;
            $data['warehouse'] = "Lab" ;
            $data['title'] = "Product Name";
            $data['page_title'] = "Product Name";
            $data['info_header'] = "All Product Name List";
            $where = array() ;
            $where['type'] = 'Product' ;
            $where['warehouse'] = 'Lab' ; 
            $data['values'] = $this->Common_model->findAll('product_name',$where,'code_no','asc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/product_name/store_product_index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function create_pharmacy_product() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $warehouse = "Pharmacy" ;
            $data['warehouse'] = "Pharmacy" ;
            $data['title'] = "Product Name";
            $data['page_title'] = "$warehouse Product Name";
            $data['info_header'] = "All $warehouse Product Name List";
            $where = array() ;
            $where['type'] = 'Product' ;
            $where['warehouse'] = 'Pharmacy' ; 
            $data['values'] = $this->Common_model->findAll('drug_medicine',$where,'brand_name','asc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/product_name/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            $warehouse = $input['warehouse'] ;
            unset($input['update_id']);
            $product_name = $input['brand_name'];
            $product_category = $input['product_category'];
            $popup = $this->input->post('popup');
            if(isset($popup)){
                unset($input['popup']);
            }

            $product_category_obj = $this->Common_model->findById('types_of_product',array('types_of_product'=>$product_category));
            $input['product_category'] = isset($product_category_obj)?$product_category_obj->record_id:0 ;
            
            if($update_id == 0 || empty($update_id)){       
                $getRow = $this->Common_model->findById('drug_medicine',array('product_category'=>$product_category,'brand_name'=>$product_name));
                if(isset($getRow)){
                    $this->session->set_flashdata('message', EXIST_MSG);
                    if(isset($popup)){
                        echo 0;
                        exit;
                    }
                   // redirect('product_name', 'refresh');
                   if($warehouse == "Pharmacy"){
                    $redirect = base_url("product_name/create_pharmacy_product") ;
                }elseif($warehouse == "Lab"){
                    $redirect = base_url("product_name/create_lab_product") ;
                }
                redirect($redirect, 'refresh');
                }

                $insert = $this->Common_model->saveData('drug_medicine', $input);
                $record_id = $insert ;
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
                
            }else{
                $update = $this->Common_model->updateData('drug_medicine', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            if(isset($popup)){
                $medicine_name = $this->Common_model->findById('drug_medicine',array('record_id'=>$record_id));
                echo json_encode($medicine_name);
                exit;
            }
            if($warehouse == "Pharmacy"){
                $redirect = base_url("product_name/create_pharmacy_product") ;
            }elseif($warehouse == "Lab"){
                $redirect = base_url("product_name/create_lab_product") ;
            }
            redirect($redirect, 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function saveOrUpdateLab() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            $warehouse = $input['warehouse'] ;
            unset($input['update_id']);
            $product_name = $input['product_name'];
            $product_category = $input['product_category'];
            $popup = $this->input->post('popup');
            if(isset($popup)){
                unset($input['popup']);
            }

            $product_category_obj = $this->Common_model->findById('types_of_product',array('types_of_product'=>$product_category));
            $input['product_category_generic_name_id'] = isset($product_category_obj)?$product_category_obj->record_id:0 ;

            $config['upload_path']      = 'assets/img/product/';
            $config['allowed_types']    = '*';
            $config['max_size']         = '0';
               //$config['file_name']      = time(); 
            $file_field                 = "image";

            $this->upload->initialize($config);

            if($update_id == 0 || empty($update_id)){       
                $getRow = $this->Common_model->findById('product_name',array('product_category'=>$product_category,'product_name'=>$product_name));
                if(isset($getRow)){
                    $this->session->set_flashdata('message', EXIST_MSG);
                    if(isset($popup)){
                        echo 0;
                        exit;
                    }
                   // redirect('product_name', 'refresh');
                   if($warehouse == "Pharmacy"){
                    $redirect = base_url("product_name/create_pharmacy_product") ;
                }elseif($warehouse == "Lab"){
                    $redirect = base_url("product_name/create_lab_product") ;
                }
                redirect($redirect, 'refresh');
                }

               

                if(!empty($_FILES[$file_field]["name"])){
                    if($this->upload->do_upload($file_field)) {
                        $uploadData = $this->upload->data();
                        $input['image'] =   $config['upload_path'] . $uploadData['file_name'];
                    }
                }
                $insert = $this->Common_model->saveData('product_name', $input);
                $record_id = $insert ;
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
                
            }else{
                $info = $this->Common_model->findById('product_name',array('record_id'=>$update_id));
                if(!empty($_FILES[$file_field]["name"])){
                    if(file_exists($info->image) && !empty($info->image)) {
                        unlink('./'.$info->image);
                    }
                    if($this->upload->do_upload($file_field)) {
                            $uploadData = $this->upload->data();
                            $input['image'] =   $config['upload_path'] . $uploadData['file_name'];
                    }
                }
                $update = $this->Common_model->updateData('product_name', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            if(isset($popup)){
                $medicine_name = $this->Common_model->findById('product_name',array('record_id'=>$record_id));
                $unit = $this->Common_model->findById('units',array('record_id'=>$medicine_name->unit_id));
                $unit_name = isset($unit)?$unit->unit_short_name:'';
                $medicine_name->unit_name = $unit_name ;
                echo json_encode($medicine_name);
                exit;
            }
            if($warehouse == "Pharmacy"){
                $redirect = base_url("product_name/create_pharmacy_product") ;
            }elseif($warehouse == "Lab"){
                $redirect = base_url("product_name/create_lab_product") ;
            }
            redirect($redirect, 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            $value = $this->Common_model->findById('product_name',array('record_id'=>$id)) ;
            $warehouse = $value->warehouse ;
            if($this->Common_model->delete_info('record_id', $id, 'product_name')){
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
            if($warehouse == "Pharmacy"){
                $redirect = base_url("product_name/create_pharmacy_product") ;
            }elseif($warehouse == "Lab"){
                $redirect = base_url("product_name/create_lab_product") ;
            }
            redirect($redirect, 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function generate_code_no(){
        $warehouse = $this->input->post('warehouse');
        $purchase_type = $this->input->post('purchase_type');
        $where = array() ;
        $where['type'] = $purchase_type ;
        if(! empty($warehouse)) $where['warehouse'] = $warehouse ;
        $code_no = '' ; 
        $max = $this->Common_model->findMax('product_name',$where,'code_no');
        $code_no = isset($max)?$max->code_no + 1 : 1 ;
        $code_no = str_pad($code_no,4,"0",STR_PAD_LEFT);
        echo $code_no;
        exit;
    }
}
