<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class News  extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('upload');
        $this->load->helper('text');
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Blog';
            $data['page_title'] = 'Blog';
            $data['info_header'] = 'All Blog';
            $data['values'] = $this->Common_model->findAll('news',array(),'record_id','desc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/news/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            unset($input['update_id']);
            
            $is_featured = $this->input->post("is_featured") ;
            if(isset($is_featured)){
                $input['is_featured'] = "Yes";
            }else{
                $input['is_featured'] = "No";
            }

          $config['upload_path']      = 'assets/img/news/';
          $config['allowed_types']    = '*';
          $config['max_size']         = '0';
          //$config['file_name']      = time(); 
          $file_field                 = "photo";

          $this->upload->initialize($config);
            if($update_id == 0 || empty($update_id)){     

                if(!empty($_FILES[$file_field]["name"])){
                    if($this->upload->do_upload($file_field)) {
                        $uploadData = $this->upload->data();
                        $input['photo'] =   $config['upload_path'] . $uploadData['file_name'];
                    }
                }

                $insert = $this->Common_model->saveData('news', $input);
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $info = $this->Common_model->findById('news',array('record_id'=>$update_id));
                if(!empty($_FILES[$file_field]["name"])){
                    if(file_exists($info->photo) && !empty($info->photo)) {
                        unlink('./'.$info->photo);
                    }
                    if($this->upload->do_upload($file_field)) {
                            $uploadData = $this->upload->data();
                            $input['photo'] =   $config['upload_path'] . $uploadData['file_name'];
                    }
                }
                $update = $this->Common_model->updateData('news', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            redirect('news', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            $info = $this->Common_model->findById('news',array('record_id'=>$id)) ;
                if($info){
                    if(file_exists($info->image) && !empty($info->image)) {
                    unlink('./'.$info->image);
                }
                $this->Common_model->delete_info('record_id', $id, 'news');
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
            redirect('news', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
