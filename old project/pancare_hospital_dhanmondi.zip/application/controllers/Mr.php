<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Mr extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Receivable List';
            $data['page_title'] = 'Receivable List';
            $where= [];

            $from_date  = $this->input->get('from_date')??date('Y-m-d');
            $to_date    = $this->input->get('to_date')??date('Y-m-d');
            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;
            
            $where['mr_date >= '] = $from_date;
            $where['mr_date <= '] = $to_date;

            $data['values'] = $this->Common_model->findAll('mr',$where,'mr_id','desc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/mr/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function Create() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Customer Receivable';
            $data['page_title'] = 'Customer Receivable';
            $data['info_header'] = '';
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/mr/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate()
    {
      $mr_date = $this->input->post('mr_date');
      $customer_id = $this->input->post('customer_id');
      $sales_amounts = $this->input->post('sales_amount');
      $sales_ids = $this->input->post('sales_id');
      $collection_type = $this->input->post('collection_type');
      $current_collections = $this->input->post('current_collection');
      $discount_amount = $this->input->post('discount_amount');
      $mr_amount = array_sum($current_collections) ; 
      $mr_discount = array_sum($discount_amount) ; 
      $prefix  = str_replace('-', '', $mr_date);
      $maxMr = $this->Common_model->findMax('mr',array('prefix'=>$prefix),'mr_no');
      $mr_no = isset($maxMr)?$maxMr->mr_no + 1 : 1 ;

      $mr = [
        'customer_id'       => $customer_id,
        'collection_type'   => $collection_type,
        'prefix'            => $prefix,
        'mr_no'             => $mr_no,
        'mr_date'           => $mr_date,
        'mr_amount'         => $mr_amount,
        'mr_discount'       => $mr_discount,
      ];

      $insert = $mr_id = $this->Common_model->saveData('mr',$mr);

      if($mr_id){
          foreach ($current_collections as $key => $value) {
            if($value > 0){
                
              $data = [
                  'mr_id'               => $mr_id,
                  'mr_date'             => $mr_date,
                  'collection_type'     => $collection_type,
                  'customer_id'         => $customer_id,
                  'sales_id'            => $sales_ids[$key],
                  'sales_amount'        => $sales_amounts[$key],
                  'discount_amount'     => $discount_amount[$key],
                  'current_collection'  => $value,
              ];

              $this->Common_model->saveData('mr_details',$data);
          }
      }
      if($insert){
        $this->session->set_flashdata('message',INSERT_MSG);
    }else{
        $this->session->set_flashdata('message',INSERT_ERROR_MSG);
    }
}
redirect("mr/view/$mr_id");
}

public function load_customer(){
    $customer_id = $this->input->post('customer_id');
    $where['customer_id'] = $customer_id ;
    $data['values'] = $this->Common_model->findAll('sales_orders',$where,'sales_id','asc') ;
    $this->load->view('admin/mr/invoice_list',$data);
}

public function view($mr_id)
  {
    $data['title'] = "View Collection";
    $data['page_title'] = "View Collection";
    $data['info_header'] = "";
    $data['signatureType'] = 'Staff';
    $data['redirect'] = base_url('mr/create');
    $data['value'] = $this->Common_model->findById('mr',array('mr_id'=>$mr_id));
    $data['patient'] = $this->Common_model->findById('patient',array('record_id'=>$data['value']->customer_id));

    $where = array('mr_details.mr_id '=>$mr_id);
    $options = array(
      'joins' => array(
        array(
          'table' => 'sales_orders',
          'condition' => 'sales_orders.sales_id = mr_details.sales_id',
          'jointype' => 'LEFT'
        )
      ),
      'select' => 'mr_details.*,sales_orders.prefix,sales_orders.sales_no,sales_orders.grand_net_total',
      'where' => $where,
      'order' => array(
        'mr_details.mr_details_id' => 'asc',
      ),
    );
    $data['values'] = $this->Common_model->commonJoins("mr_details", $options);

        $this->load->view('admin/layouts/header');
        $this->load->view('admin/mr/invoice', $data);
        $this->load->view('admin/layouts/footer');
  }
  public function delete($id) {
    $user_type = $this->session->ses_user_type;
    if ($user_type == "admin"  || $user_type == "staff") {
        if($this->Common_model->delete_info('mr_id', $id, 'mr')){
            $this->Common_model->delete_info('mr_id', $id, 'mr_details');
            $this->session->set_flashdata('message',DELETE_MSG);
        }else{
            $this->session->set_flashdata('message',DELETE_ERROR_MSG);
        }
        redirect('mr', 'refresh');
    } else {
        $data['wrong_msg'] = "";
        $this->load->view('website/login_check', $data);
    }
}
}
