<?php

defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Balance_transfer extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
    }
    public function index()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Balance Transfer';
            $data['page_title'] = 'Balance Transfer';
            $data['info_header'] = 'All Balance Transfer';
            $data['values'] = $this->Common_model->findAll('balance_transfer', array(), 'record_id', 'asc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/balance_transfer/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST;
            $update_id = $input['update_id'];
            unset($input['update_id']);
            $input['date'] = date('Y-m-d');
            $month_no = $input['month'];
            $months = month();
            $input['month_name'] = $months[$month_no];

            if ($update_id == 0 || empty($update_id)) {
                $insert = $this->Common_model->saveData('balance_transfer', $input);
                if ($insert) {
                    $this->session->set_flashdata('message', INSERT_MSG);
                } else {
                    $this->session->set_flashdata('message', INSERT_ERROR_MSG);
                }
            } else {
                $update = $this->Common_model->updateData('balance_transfer', $input, array('record_id' => $update_id));
                if ($update) {
                    $this->session->set_flashdata('message', UPDATE_MSG);
                } else {
                    $this->session->set_flashdata('message', UPDATE_ERROR_MSG);
                }
            }
            redirect('balance_transfer', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if ($this->Common_model->delete_info('record_id', $id, 'balance_transfer')) {
                $this->session->set_flashdata('message', DELETE_MSG);
            } else {
                $this->session->set_flashdata('message', DELETE_ERROR_MSG);
            }
            // redirect("crud/previousPage");
            redirect('balance_transfer', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function get_balance()
    {
        $count = 0;
        $grand_total_income = 0;
        $grand_total_expense = 0;
        $grand_total_balance = 0;
        $data['total_paid_amount'] = 0;
        $data['total_expense_amount'] = 0;
        $data['total_balance'] = 0;
        $year = $this->input->post('year');
        $month = $this->input->post('month');
        $start_date =  $date_from = date("$year-$month-01");
        $days = cal_days_in_month(CAL_GREGORIAN, $month, $year);
        $date_to = date("$year-$month-$days");
        $previous_date =  date_sub(date_create($date_from), date_interval_create_from_date_string("1 days"));
        $previous_date = date_format($previous_date, "Y-m-d");

        $transfer_amount = $this->Common_model->calCulateSum("balance_transfer", array('year' => $year, 'month' => $month), 'transfer_amount');
        $transfer_amount = isset($transfer_amount) ? $transfer_amount : 0;

        while (strtotime($date_from) <= strtotime($date_to)) {
            $count++;

            $pathologyWhere = array();
            if (!admin()) {
                $pathologyWhere['show_hide'] = "Show";
            }
            $pathologyWhere['date'] = $date_from;
            $pathologyWhere['type'] = 'Test Invoice';
            $operationWhere['date'] = $date_from;
            $operationInvoiceWhere = array();
            if (!admin()) {
                $operationInvoiceWhere['show_hide'] = "Show";
            }
            $operationInvoiceWhere['date'] = $date_from;
            $operationInvoiceWhere['type'] = 'Admission';
            // $operationWhere = array() ;
            if (!admin()) {
                $operationWhere['show_hide'] = "Show";
            }
            $operationWhere['type'] = 'Operation';

            $operationAdmissionAdvanceInvoiceWhere = array();
            if (!admin()) {
                $operationAdmissionAdvanceInvoiceWhere['show_hide'] = "Show";
            }
            $operationAdmissionAdvanceInvoiceWhere['date'] = $date_from;
            $operationAdmissionAdvanceInvoiceWhere['type'] = 'AdmissionAdvance';

            $operationDetailsWhere = array();
            if (!admin()) {
                $operationDetailsWhere['show_hide'] = "Show";
            }
            $operationDetailsWhere['operation_date'] = $date_from;

            $ecgWhere['date'] = $date_from;
            $ecgWhere['test_category'] = 'ECG';
            $xrayWhere['date'] = $date_from;
            $xrayWhere['test_category'] = '%X-Ray%';
            $ultraWhere['date'] = $date_from;
            $ultraWhere['test_category like'] = 'Ultrasonogram';

            $generalIncomeWhere = array();
            if (!admin()) {
                $generalIncomeWhere['show_hide'] = "Show";
            }
            $generalIncomeWhere['date'] = $date_from;

            $consultancyWhere = array();
            if (!admin()) {
                $consultancyWhere['show_hide'] = "Show";
            }
            $consultancyWhere['type'] = 'Appointment';
            $consultancyWhere['date'] = $date_from;

            $commission_patholgyWhere = array();
            if (!admin()) {
                $commission_patholgyWhere['show_hide'] = "Show";
            }
            $commission_patholgyWhere['test_invoice_payment_status'] = 'Paid';
            $commission_patholgyWhere['type'] = 'Test Invoice';
            $commission_patholgyWhere['date'] = $date_from;



            $operation_commissionWhere = array();
            if (!admin()) {
                $operation_commissionWhere['show_hide'] = "Show";
            }
            $operation_commissionWhere['operation_date'] = $date_from;

            $sonologistExpenseWhere = array();
            if (!admin()) {
                $sonologistExpenseWhere['show_hide'] = "Show";
            }
            $sonologistExpenseWhere['date'] = $date_from;

            $generalExpenseWhere = array();
            if (!admin()) {
                $generalExpenseWhere['show_hide'] = "Show";
            }
            $generalExpenseWhere['date'] = $date_from;
            $staffSalaryWhere = array();
            if (!admin()) {
                $staffSalaryWhere['show_hide'] = "Show";
            }
            $staffSalaryWhere['status'] = 'Paid';
            $staffSalaryWhere['date'] = $date_from;

            $dueCollectionWhere = array();
            if (!admin()) {
                $dueCollectionWhere['show_hide'] = "Show";
            }
            $dueCollectionWhere['mr_date'] = $date_from;


            $salesWhere = array();
            if (!admin()) {
                $salesWhere['show_hide'] = "Show";
            }
            $salesWhere['sales_from'] = 'Direct';
            $salesWhere['sales_date'] = $date_from;

            $mrWhere = array();
            if (!admin()) {
                $mrWhere['show_hide'] = "Show";
            }
            $mrWhere['mr_date'] = $date_from;

            $emergencyWhere = array();
            if (!admin()) {
                $emergencyWhere['show_hide'] = "Show";
            }
            $emergencyWhere['type'] = 'Emergency';
            $emergencyWhere['date'] = $date_from;

            $ambulanceWhere = array();
            if (!admin()) {
                $ambulanceWhere['show_hide'] = "Show";
            }
            $ambulanceWhere['type'] = 'Ambulance';
            $ambulanceWhere['date'] = $date_from;

            $doctorServiceWhere = array();
            if (!admin()) {
                $doctorServiceWhere['show_hide'] = "Show";
            }
            $doctorServiceWhere['type'] = 'Doctor Service';
            $doctorServiceWhere['date'] = $date_from;

            $donorWhere = array();
            if (!admin()) {
                $donorWhere['show_hide'] = "Show";
            }
            $donorWhere['type'] = 'Donor';
            $donorWhere['date'] = $date_from;

            $dressingWhere = array();
            if (!admin()) {
                $dressingWhere['show_hide'] = "Show";
            }
            $dressingWhere['type'] = 'Dressing';
            $dressingWhere['date'] = $date_from;

            $supplier_paymentsWhere = array();
            if (!admin()) {
                $supplier_paymentsWhere['show_hide'] = "Show";
            }
            $supplier_paymentsWhere['payment_date'] = $date_from;

            $incomeWhere = array();
            if (!admin()) {
                $incomeWhere['show_hide'] = "Show";
            }
            $incomeWhere['income_type != '] = 'Pharmacy';
            $incomeWhere['income_date'] = $date_from;
            $expenseWhere = array();
            if (!admin()) {
                $expenseWhere['show_hide'] = "Show";
            }
            // $expenseWhere['approval'] = 'Approved' ;
            $expenseWhere['expense_type != '] = 'Pharmacy';
            $expenseWhere['expense_date'] = $date_from;

            $labInWhere = array();
            $labInWhere['approval'] = "Approved";
            if (!admin()) {
                $labInWhere['show_hide'] = "Show";
            }
            $labInWhere['in_date'] = $date_from;

            $dressingWhere = array();
            if (!admin()) {
                $dressingWhere['show_hide'] = "Show";
            }
            $dressingWhere['type'] = 'Dressing';
            $dressingWhere['date'] = $date_from;



            $data['pathology'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhere, 'sub_total');
            $data['pathology_paid'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhere, 'paid');
            $data['pathology_due'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhere, 'due');
            $data['operation'] = $this->Common_model->calCulateSum('create_bill', $operationWhere, 'sub_total');
            //  var_dump($operationWhere) ; die ;
            $operation_paid =  $this->Common_model->calculateSumMultiple('create_bill', $operationWhere, array('paid', 'medicine_cost', 'advance'));



            $operationInvoice = $this->Common_model->calculateSumMultiple('create_bill', $operationInvoiceWhere, array('sub_total', 'advance'));
            $data['operationInvoice'] = $operationInvoice->sub_total + $operationInvoice->advance;

            $operationAdmissionAdvanceInvoice = $this->Common_model->calculateSum('create_bill', $operationAdmissionAdvanceInvoiceWhere, 'sub_total');
            $data['operationAdmissionAdvanceInvoice'] = isset($operationAdmissionAdvanceInvoice) ? $operationAdmissionAdvanceInvoice : 0;

            $data['operation_paid'] = $operation_paid->paid;
            $data['operation_due'] = $this->Common_model->calCulateSum('create_bill', $operationWhere, 'due');

            $data['ecg'] = $this->Common_model->calCulateSum('sales_test', $ecgWhere, 'test_price');
            $data['xray'] = $this->Common_model->calCulateSum('sales_test', $xrayWhere, 'test_price');
            $data['ultra'] = $this->Common_model->calCulateSum('sales_test', $ultraWhere, 'test_price');


            $consultancy = $this->Common_model->calculateSumMultiple('create_bill', $consultancyWhere, array('sub_total', 'paid', 'due', 'doctor_commission'));
            // var_dump($consultancyWhere) ; die;
            $data['consultancy'] = isset($consultancy) ?  $consultancy->sub_total : 0;
            $data['consultancy_paid'] = isset($consultancy) ?  $consultancy->paid : 0;
            $data['consultancy_due'] = isset($consultancy) ?  $consultancy->due : 0;
            $data['consultancy_doctor_commission'] = isset($consultancy) ?  $consultancy->doctor_commission : 0;
            //  $data['doctor_commission_patholgy'] = $this->Common_model->calCulateSum('create_bill',$commission_patholgyWhere,'doctor_commission');
            $doctor_commission_patholgy = $this->Common_model->calculateSumMultiple('create_bill', $commission_patholgyWhere, array('discount', 'doctor_commission', 'reference_by_commission'));
            $test_invoice_discount = isset($doctor_commission_patholgy) ? $doctor_commission_patholgy->discount : 0;
            $doctor_commission = isset($doctor_commission_patholgy) ? $doctor_commission_patholgy->doctor_commission : 0;
            $reference_by_commission = isset($doctor_commission_patholgy) ? $doctor_commission_patholgy->reference_by_commission : 0;
            $data['doctor_commission_patholgy'] = $doctor_commission + $reference_by_commission - $test_invoice_discount;


            $operation_commission =  $this->Common_model->calculateSumMultiple('operation_details', $operationDetailsWhere, array('surgeon_commission', 'surgeon_assistant_commission', 'surgeon_team_commission', 'anesthesia_commission', 'medicine_cost', 'service_fee'));
            $surgeon_commission = isset($operation_commission) ? $operation_commission->surgeon_commission : 0;
            $anesthesia_commission = isset($operation_commission) ? $operation_commission->anesthesia_commission : 0;
            $medicine_cost = isset($operation_commission) ? $operation_commission->medicine_cost : 0;
            $surgeon_assistant_commission = isset($operation_commission) ? $operation_commission->surgeon_assistant_commission : 0;
            $surgeon_team_commission = isset($operation_commission) ? $operation_commission->surgeon_team_commission : 0;
            $service_fee = isset($operation_commission) ? $operation_commission->service_fee : 0;
            $data['operation_commission'] =  $surgeon_commission + $anesthesia_commission + $medicine_cost + $surgeon_assistant_commission + $surgeon_team_commission + $service_fee;

            $data['sonologistExpense'] = $this->Common_model->calCulateSum('sonologist', $sonologistExpenseWhere, 'amount');

            $data['staffSalary'] = $this->Common_model->calCulateSum('create_salary_sheet', $staffSalaryWhere, 'net_salary');

            $data['dueCollection'] = $this->Common_model->calCulateSum('due_collections', $dueCollectionWhere, 'mr_amount');

            $sales_orders = $this->Common_model->calculateSumMultiple('sales_orders', $salesWhere, array('grand_net_total', 'paid_amount', 'due_amount'));
            $data['sales_amount'] = $sales_orders->grand_net_total;
            $data['sales_paid_amount'] = $sales_orders->paid_amount;
            $data['sales_due_amount'] = $sales_orders->due_amount;
            $data['pharmacy_collection'] = $this->Common_model->calCulateSum('mr', $mrWhere, 'mr_amount');

            $data['supplier_payments'] = $this->Common_model->calCulateSum('supplier_payments', $supplier_paymentsWhere, 'payment_amount');



            $emergency = $this->Common_model->calculateSumMultiple('create_bill', $emergencyWhere, array('sub_total', 'paid', 'doctor_commission', 'others_cost'));
            $data['emergency_total'] = isset($emergency) ? $emergency->sub_total : 0;
            $data['emergency_paid'] =  isset($emergency) ? $emergency->paid : 0;
            $data['emergency_doctor_commission'] = isset($emergency) ? $emergency->doctor_commission : 0;
            $data['emergency_others_cost'] = isset($emergency) ? $emergency->others_cost : 0;

            $ambulance = $this->Common_model->calculateSumMultiple('create_bill', $ambulanceWhere, array('sub_total', 'paid', 'fuel_cost', 'road_cost', 'service_maintanance_cost'));
            $data['ambulance_total'] = isset($ambulance) ? $ambulance->sub_total : 0;
            $data['ambulance_paid'] = isset($ambulance) ? $ambulance->paid : 0;
            $data['ambulance_fuel_cost'] = isset($ambulance) ? $ambulance->fuel_cost : 0;
            $data['ambulance_road_cost'] = isset($ambulance) ? $ambulance->road_cost : 0;
            $data['ambulance_service_maintanance_cost'] = isset($ambulance) ? $ambulance->service_maintanance_cost : 0;

            $doctor_service = $this->Common_model->calculateSumMultiple('create_bill', $doctorServiceWhere, array('sub_total', 'paid', 'due', 'doctor_commission', 'reference_by_commission'));
            $data['doctor_service_total'] = isset($doctor_service) ? $doctor_service->sub_total : 0;
            $data['doctor_service_paid'] = isset($doctor_service) ? $doctor_service->paid : 0;
            $data['doctor_service_reference_by_commission'] = isset($doctor_service) ? $doctor_service->reference_by_commission : 0;
            $data['doctor_service_commission'] = isset($doctor_service) ? $doctor_service->doctor_commission : 0;
            $data['doctor_service_commission'] = $data['doctor_service_reference_by_commission'] + $data['doctor_service_commission'];
            $data['doctor_service_due'] = isset($doctor_service) ? $doctor_service->due : 0;




            $donor = $this->Common_model->calculateSumMultiple('create_bill', $donorWhere, array('sub_total', 'paid'));
            $data['donor_total'] = isset($donor) ? $donor->sub_total : 0;
            $data['donor_paid'] = isset($donor) ? $donor->paid : 0;

            $dressing = $this->Common_model->calculateSumMultiple('create_bill', $dressingWhere, array('sub_total', 'paid', 'doctor_commission'));
            $data['dressing_total'] = isset($dressing) ? $dressing->sub_total : 0;
            $data['dressing_paid'] = isset($dressing) ? $dressing->paid : 0;
            $data['dressing_cost'] = isset($dressing) ? $dressing->doctor_commission : 0;

            $data['general_income'] = $this->Common_model->calCulateSum('incomes', $incomeWhere, 'voucher_amount');
            $data['general_expense'] = $this->Common_model->calCulateSum('expenses', $expenseWhere, 'voucher_amount');
            $data['lab_product'] = $this->Common_model->calCulateSum('lab_product_in', $labInWhere, 'grand_total_price');

            $data['total_paid_amount'] = $data['pathology_paid'] +  $data['operation_paid'] + $data['operationInvoice'] +  $data['consultancy_paid'] + $data['dueCollection']  + $data['emergency_paid']  + $data['ambulance_paid'] + $data['doctor_service_paid'] + $data['donor_paid'] + $data['dressing_paid'] + $data['general_income'] + $data['operationAdmissionAdvanceInvoice']; // + $data['sales_paid_amount'] + $data['pharmacy_collection'] ;
            //$data['total_paid_amount'] = $data['pathology_paid'] +  $data['operation_paid'] ; // + $data['operationInvoice'] +  $data['consultancy_paid'] + $data['dueCollection']  + $data['emergency_paid']  + $data['ambulance_paid'] + $data['doctor_service_paid'] + $data['donor_paid'] + $data['dressing_paid'] + $data['general_income'] + $data['operationAdmissionAdvanceInvoice']; // + $data['sales_paid_amount'] + $data['pharmacy_collection'] ;
            $data['total_expense_amount'] = $data['doctor_commission_patholgy'] + $data['consultancy_doctor_commission']  + $data['operation_commission'] + $data['sonologistExpense'] + $data['staffSalary'] + $data['emergency_doctor_commission'] + $data['emergency_others_cost'] + $data['ambulance_fuel_cost'] +  $data['ambulance_road_cost'] + $data['ambulance_service_maintanance_cost'] + $data['doctor_service_commission'] + $data['general_expense'] + $data['lab_product'] + $data['dressing_cost'];
            $data['balance_amount'] = $data['total_paid_amount'] - $data['total_expense_amount']; //  + $data['supplier_payments'] ;

            $grand_total_income += round($data['total_paid_amount']);
            $grand_total_expense += round($data['total_expense_amount']);
            $grand_total_balance += round($data['balance_amount']);

            $response['date' . $count] = date('d-m-y', strtotime($date_from));
            $response['con_in_sum' . $count] = $data['consultancy_paid'];
            $response['test_invoice_in_sub_total' . $count] = 0;
            $response['test_invoice_in_paid' . $count] = $data['pathology_paid'];
            $response['test_invoice_in_due' . $count] = 0;
            $response['total_pharmacy' . $count] = $data['sales_paid_amount'];
            $response['emergency_paid' . $count] = $data['emergency_paid'];
            $response['ambulance_paid' . $count] = $data['ambulance_paid'];
            $response['doctor_service_paid' . $count] = $data['doctor_service_paid'];
            $response['donor_paid' . $count] = $data['donor_paid'];
            $response['due_collection' . $count] = $data['pharmacy_collection'] + $data['dueCollection'];
            $response['income' . $count] =  $data['general_income'];
            $response['con_ex_sum' . $count] = $data['consultancy_doctor_commission'];
            $response['operation_admission_invoice' . $count] =  $data['operationInvoice'];
            $response['operation_in_sub_total' . $count] = 0;
            $response['operation_in_paid' . $count] = $data['operation_paid'] + $data['operationInvoice'];
            $response['operation_in_due' . $count] = 0;
            $response['test_invoice_ex_sum' . $count] = $data['doctor_commission_patholgy'];
            $response['operation_ex' . $count] = $data['operation_commission'];
            $response['emergency_expense' . $count] = $data['emergency_doctor_commission'] + $data['emergency_others_cost'];
            $response['ambulance_expense' . $count] = $data['ambulance_fuel_cost'] + $data['ambulance_road_cost'] + $data['ambulance_service_maintanance_cost'];
            $response['doctor_service_commission' . $count] = $data['doctor_service_commission'];
            $response['supplier_payments' . $count] = $data['supplier_payments'];
            $response['expense' . $count] = $data['general_expense'];
            $response['son_expense' . $count] =  $data['sonologistExpense'];
            $response['staffSalary' . $count] = $data['staffSalary'];
            $response['lab_product' . $count] = $data['lab_product'];
            $response['total_paid_amount' . $count] = round($data['total_paid_amount']);
            $response['balance' . $count] = round($data['balance_amount']);
            $response['total_expense_amount' . $count] = round($data['total_expense_amount']);


            $date_from = date("Y-m-d", strtotime("+1 day", strtotime($date_from)));
        }
        
        $response['start_date'] = $start_date;
        $response['end_date'] = $date_to;
        $response['count_it'] = $count;
        $response['page_title'] = "Monthly Cash Report";
        $response['redirect'] = base_url('reports/cash_report');
        $response['grand_total_income'] = round($grand_total_income);
        $response['grand_total_expense'] = round($grand_total_expense);
        $response['grand_total_balance'] = round($grand_total_balance);
        //$this->load->view('admin/reports/show_total_cash_report', $response);
        $balance = $response['grand_total_balance'] - $transfer_amount;
        echo $balance;
        exit;
    }
}
