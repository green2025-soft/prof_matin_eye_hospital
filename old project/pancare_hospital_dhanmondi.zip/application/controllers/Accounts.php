<?php defined('BASEPATH') or exit('No direct script access allowed');

class Accounts extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();

		date_default_timezone_set("Asia/Dhaka");


		$this->load->language('information');
	}

	/* ------------------------------------------------------
	Index Function
	------------------------------------------------------- */
	function index()
	{
		$data = array(
			"page_title"			=> $this->lang->line('chart_of_accounts'),
			"page_name"				=> $this->lang->line('chart_of_accounts')
		);
		$this->load->view('header', $data);
		$this->load->view('accounts/chart-of-accounts');
		$this->load->view('footer');
	}

	/* ------------------------------------------------------
	Chart of Accounts Function
	------------------------------------------------------- */
	function chart_of_accounts()
	{
		$data = array(
			"page_title"			=> 'Chart of Accounts',
			"page_name"				=> 'Chart of Accounts'
		);
		$this->load->view('header', $data);
		//$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/chart-of-accounts');
		$this->load->view('footer');
	}

	/* ------------------------------------------------------
	Chart of Accounts List Function
	------------------------------------------------------- */
	function chart_of_accounts_list()
	{
		echo $this->accounts_model->chart_of_accounts_list();
	}

	/* ------------------------------------------------------
	Chart of Accounts Add Function
	------------------------------------------------------- */
	function chart_of_accounts_add()
	{
		$data = array(
			"accounts_category" 	=> $this->input->get('accounts_category'),
			"page_title"			=> 'Chart of Accounts',
			"page_name"				=> 'Chart of Accounts'
		);
		$this->load->view('accounts/chart-of-accounts-add', $data);
	}

	/* ------------------------------------------------------
	Chart of Accounts Create Function
	------------------------------------------------------- */
	function chart_of_accounts_create()
	{
		$chart_of_accounts_code = $this->input->post('chart_of_accounts_code');
		
		$chart_of_accounts_link_slug = '';
		if(!empty($this->input->post('chart_of_accounts_link'))) {
		$accounts_link =  $this->db->select("*") ->from('accounts_link')->where('accounts_link_id', $this->input->post('chart_of_accounts_link'))->get()->row();
		$chart_of_accounts_link_slug = $accounts_link->accounts_link_slug;	
		}
		
		$data = array(
			'chart_of_accounts_code' 				=> $this->input->post('chart_of_accounts_code'),
			'chart_of_accounts_name' 				=> $this->input->post('chart_of_accounts_name'),
			'chart_of_accounts_accounts_category' 	=> $this->input->post('chart_of_accounts_accounts_category'),
			'chart_of_accounts_link' 				=> $this->input->post('chart_of_accounts_link'),
			'chart_of_accounts_link_slug' 			=> $chart_of_accounts_link_slug,
			'chart_of_accounts_status' 				=> $this->input->post('chart_of_accounts_status'),
			'chart_of_accounts_create_date' 		=> date('Y-m-d H:i:s')
		);

		$chart_of_accounts_code_check = $this->accounts_model->chart_of_accounts_code_check($chart_of_accounts_code);

		if ($this->accounts_model->chart_of_accounts_create($data)) {
			$this->load->view('data-insert-success.php');
		} else {
			$this->load->view('data-insert-error.php');
		}
	}

	/* ------------------------------------------------------
	Accounts Type Edit Function
	------------------------------------------------------- */
	function accounts_type_edit($id)
	{
		$data = array(
			"accounts_type_edit"		=>  $this->accounts_model->accounts_type_edit($id),
			"page_title"				=> $this->lang->line('accounts_type'),
			"page_name"					=> $this->lang->line('accounts_type')
		);
		$this->load->view('accounts/account-type-edit', $data);
	}

	/* ------------------------------------------------------
	Accounts Type Update Function
	------------------------------------------------------- */
	function accounts_type_update()
	{

		$accounts_type_code = $this->input->post('accounts_type_code');

		$data = array(
			'accounts_type_id' 					=> $this->input->post('accounts_type_id'),
			'accounts_type_code' 				=> $this->input->post('accounts_type_code'),
			'accounts_type_name' 				=> $this->input->post('accounts_type_name'),
			'accounts_type_inventory' 			=> $this->input->post('accounts_type_inventory'),
			'accounts_type_status' 				=> $this->input->post('accounts_type_status'),
			'accounts_type_update' 				=> date('Y-m-d H:i:s')
		);

		if ($this->accounts_model->accounts_type_update($data)) {
			$this->load->view('data-update-success.php');
		} else {
			$this->load->view('data-insert-error.php');
		}
	}

	/* ------------------------------------------------------
	Chart of Accounts Edit Function
	------------------------------------------------------- */
	function chart_of_accounts_edit($id)
	{
		$data = array(
			"chart_of_accounts_edit"	=>  $this->accounts_model->chart_of_accounts_edit($id),
			"page_title"				=> $this->lang->line('chart_of_accounts'),
			"page_name"					=> $this->lang->line('chart_of_accounts')
		);
		$this->load->view('accounts/chart-of-accounts-edit', $data);
	}

	/* ------------------------------------------------------
	Chart of Accounts Update Function
	------------------------------------------------------- */
	function chart_of_accounts_update()
	{
		$chart_of_accounts_code = $this->input->post('chart_of_accounts_code');
		
		$chart_of_accounts_link_slug = '';
		if(!empty($this->input->post('chart_of_accounts_link'))) {
		$accounts_link =  $this->db->select("*") ->from('accounts_link')->where('accounts_link_id', $this->input->post('chart_of_accounts_link'))->get()->row();
		$chart_of_accounts_link_slug = $accounts_link->accounts_link_slug;	
		}
		
		$data = array(
			'chart_of_accounts_id' 					=> $this->input->post('chart_of_accounts_id'),
			'chart_of_accounts_code' 				=> $this->input->post('chart_of_accounts_code'),
			'chart_of_accounts_name' 				=> $this->input->post('chart_of_accounts_name'),
			'chart_of_accounts_link' 				=> $this->input->post('chart_of_accounts_link'),
			'chart_of_accounts_link_slug' 			=> $chart_of_accounts_link_slug,
			'chart_of_accounts_status' 				=> $this->input->post('chart_of_accounts_status'),
			'chart_of_accounts_update' 				=> date('Y-m-d H:i:s')
		);

		if ($this->accounts_model->chart_of_accounts_update($data)) {

			$this->load->view('data-update-success');
		} else {
			$this->load->view('data-insert-error');
		}
	}

	/* ------------------------------------------------------
	Chart of Accounts Print Function
	------------------------------------------------------- */
	function chart_of_accounts_print()
	{
		$data = array(
			"page_title"			=> $this->lang->line('chart_of_accounts'),
			"page_name"				=> $this->lang->line('chart_of_accounts')
		);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/chart-of-accounts-print');
	}

	/* ------------------------------------------------------
	Voucher Posting Function
	------------------------------------------------------- */
	function voucher_posting()
	{
		$data = array(
			"voucher_type"			=> $this->accounts_model->voucher_type_list_option(),
			"page_title"			=> $this->lang->line('voucher_posting'),
			"page_name"				=> $this->lang->line('voucher_posting')
		);
		// ddd($data);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/voucher-posting');
		$this->load->view('accounts/footer');
	}

	/* ------------------------------------------------------
	Get Voucher Number Info Function
	------------------------------------------------------- */
	function get_voucher_number_info()
	{
		$posting_date			= $this->input->post('accounts_voucher_posting_date');
		$accounts_voucher_type	= $this->input->post('accounts_voucher_type');

		echo $this->accounts_model->get_voucher_number_info($posting_date, $accounts_voucher_type);
	}

	/* ------------------------------------------------------
	Voucher Posting Accounts Category Info Function
	------------------------------------------------------- */
	function voucher_posting_accounts_category_info()
	{
		$accounts_category			= $this->input->post('accounts_category');

		echo $this->accounts_model->voucher_posting_accounts_category_info($accounts_category);
	}

	/* ------------------------------------------------------
	Voucher Information Function
	------------------------------------------------------- */
	function voucher_information()
	{
		$data = array(
			"page_title"			=> $this->lang->line('voucher_information'),
			"page_name"				=> $this->lang->line('voucher_information')
		);
		$this->load->view('header', $data);
		$this->load->view('accounts/voucher-information');
		$this->load->view('footer');
	}

	/* ------------------------------------------------------
	Get Voucher Posting Report Function
	------------------------------------------------------- */
	function get_voucher_information()
	{
		$voucher_type	= $this->input->post('voucher_type');
		$posting_from_date	= $this->input->post('posting_from_date');
		$posting_to_date	= $this->input->post('posting_to_date');

		echo $this->accounts_model->voucher_information($voucher_type, $posting_from_date, $posting_to_date);
	}


	/* ------------------------------------------------------
	Voucher Posting Create Function
	------------------------------------------------------- */
	function voucher_posting_create()
	{

		$previous_date	= date('Y-m-d', strtotime("-2 days"));
		$today_date		= date('Y-m-d');
		$posting_date	= $this->input->post('accounts_voucher_posting_date');

		$accounts_total_debit		= $this->input->post('accounts_total_debit');
		$accounts_total_credit		= $this->input->post('accounts_total_credit');
		$count						= $this->input->post('count');

		$posting_date				= $this->input->post('accounts_voucher_posting_date');
		$project					= $this->input->post('accounts_project');
		$amount						= $this->input->post('accounts_total_debit');

		if ($accounts_total_debit == $accounts_total_credit) {

			//acoounts table
			$data = array(
				'accounts_project' 						=> $this->input->post('accounts_project'),
				'accounts_voucher_posting_date' 		=> $this->input->post('accounts_voucher_posting_date'),
				'accounts_voucher_posting_month' 		=> date('F-Y', strtotime($this->input->post('accounts_voucher_posting_date'))),
				'accounts_voucher_posting_year' 		=> date('Y', strtotime($this->input->post('accounts_voucher_posting_date'))),
				'accounts_voucher_type' 				=> $this->input->post('accounts_voucher_type'),
				'accounts_voucher_type_code' 			=> $this->input->post('accounts_voucher_type_code'),
				'accounts_voucher_type_name' 			=> $this->input->post('accounts_voucher_type_name'),
				'accounts_voucher_number' 				=> $this->input->post('accounts_voucher_number'),
				'accounts_reference_number' 			=> $this->input->post('accounts_reference_number'),
				'accounts_narration' 					=> $this->input->post('accounts_narration'),
				//'accounts_total_debit_quantity' 		=> $this->input->post('accounts_total_debit_quantity'),
				//'accounts_total_credit_quantity' 		=> $this->input->post('accounts_total_credit_quantity'),
				'accounts_total_debit' 					=> $this->input->post('accounts_total_debit'),
				'accounts_total_credit' 				=> $this->input->post('accounts_total_credit'),
				'accounts_status' 						=> 1,
				'accounts_create_date' 					=> date('Y-m-d H:i:s')
			);

			if ($this->accounts_model->voucher_posting_accounts_create($data)) {
				$accounts_details_accounts_id = $this->db->insert_id();

				for ($i = 0; $i < $count; $i++) {
					$g_ledger =  $this->db->select("*")
						->from('chart_of_accounts')
						->where('chart_of_accounts_id', $this->input->post('accounts_details_general_ledger')[$i])
						->order_by('chart_of_accounts_id', 'ASC')
						->get()
						->result();
					foreach ($g_ledger as $g_ledger_row) {
					}

					$c_group =  $this->db->select("*")
						->from('chart_of_accounts')
						->where('chart_of_accounts_id', $g_ledger_row->chart_of_accounts_accounts_category)
						->order_by('chart_of_accounts_id', 'ASC')
						->get()
						->result();
					foreach ($c_group as $c_group_row) {
						$control_group_id = $c_group_row->chart_of_accounts_id;
					}

					$a_category =  $this->db->select("*")
						->from('chart_of_accounts')
						->where('chart_of_accounts_id', $c_group_row->chart_of_accounts_accounts_category)
						->order_by('chart_of_accounts_id', 'ASC')
						->get()
						->result();
					foreach ($a_category as $a_category_row) {
						$accounts_category_id = $a_category_row->chart_of_accounts_id;
					}

					$a_type =  $this->db->select("*")
						->from('accounts_type')
						->where('accounts_type_code', $a_category_row->chart_of_accounts_accounts_category)
						->order_by('accounts_type_code', 'ASC')
						->get()
						->result();
					foreach ($a_type as $a_type_row) {
						$accounts_type_id = $a_type_row->accounts_type_code;
					}

					//accounts_details table
					$data_1[] = array(
						'accounts_details_accounts_id' 				=> $accounts_details_accounts_id,
						'accounts_details_project' 					=> $this->input->post('accounts_project'),
						'accounts_details_voucher_posting_date' 	=> $this->input->post('accounts_voucher_posting_date'),
						'accounts_details_voucher_posting_month' 	=> date('F-Y', strtotime($this->input->post('accounts_voucher_posting_date'))),
						'accounts_details_voucher_posting_year' 	=> date('Y', strtotime($this->input->post('accounts_voucher_posting_date'))),
						'accounts_details_voucher_type' 			=> $this->input->post('accounts_voucher_type'),
						'accounts_details_voucher_type_code' 		=> $this->input->post('accounts_voucher_type_code'),
						'accounts_details_voucher_type_name' 		=> $this->input->post('accounts_voucher_type_name'),
						'accounts_details_voucher_number' 			=> $this->input->post('accounts_voucher_number'),
						'accounts_details_reference_number' 		=> $this->input->post('accounts_reference_number'),
						'accounts_details_narration' 				=> $this->input->post('accounts_narration'),
						'accounts_details_accounts_type' 			=> $accounts_type_id,
						'accounts_details_accounts_category' 		=> $accounts_category_id,
						'accounts_details_control_group' 			=> $control_group_id,
						'accounts_details_general_ledger' 			=> $this->input->post('accounts_details_general_ledger')[$i],
						'accounts_details_subsidiary_ledger' 		=> $this->input->post('accounts_details_subsidiary_ledger')[$i],
						//'accounts_details_debit_quantity' 			=> $this->input->post('accounts_details_debit_quantity')[$i],
						//'accounts_details_credit_quantity' 			=> $this->input->post('accounts_details_credit_quantity')[$i],
						'accounts_details_debit' 					=> $this->input->post('accounts_details_debit')[$i],
						'accounts_details_credit' 					=> $this->input->post('accounts_details_credit')[$i],
						'accounts_details_status' 					=> 1,
						'accounts_details_create_date' 				=> date('Y-m-d H:i:s'),
						'accounts_details_create_by' 				=> $user_id,
						'accounts_details_update_by' 				=> $user_id,
					);
				}

				$this->accounts_model->voucher_posting_accounts_details_create($data_1);
				$this->session->set_flashdata('success', $this->lang->line('data_insert_success'));
			} else {
				$this->session->set_flashdata('error', $this->lang->line('data_insert_error'));
			}
		} else {
			$this->session->set_flashdata('error', $this->lang->line('debit_credit_amount_do_not_match'));
		}
		redirect('accounts/voucher_posting');
	}

	/* ------------------------------------------------------
	Voucher Posting Create Function
	------------------------------------------------------- */
	function voucher_posting_create_bk()
	{

		$previous_date	= date('Y-m-d', strtotime("-2 days"));
		$today_date		= date('Y-m-d');
		$posting_date	= $this->input->post('accounts_voucher_posting_date');

		$accounts_total_debit		= $this->input->post('accounts_total_debit');
		$accounts_total_credit		= $this->input->post('accounts_total_credit');
		$count						= $this->input->post('count');

		$posting_date				= $this->input->post('accounts_voucher_posting_date');
		$project					= $this->input->post('accounts_project');
		$amount						= $this->input->post('accounts_total_debit');

		if ($accounts_total_debit == $accounts_total_credit) {
			//acoounts table
			$data = array(
				'accounts_project' 						=> $this->input->post('accounts_project'),
				'accounts_voucher_posting_date' 		=> $this->input->post('accounts_voucher_posting_date'),
				'accounts_voucher_posting_month' 		=> date('F-Y', strtotime($this->input->post('accounts_voucher_posting_date'))),
				'accounts_voucher_posting_year' 		=> date('Y', strtotime($this->input->post('accounts_voucher_posting_date'))),
				'accounts_voucher_type' 				=> $this->input->post('accounts_voucher_type'),
				'accounts_voucher_type_code' 			=> $this->input->post('accounts_voucher_type_code'),
				'accounts_voucher_type_name' 			=> $this->input->post('accounts_voucher_type_name'),
				'accounts_voucher_number' 				=> $this->input->post('accounts_voucher_number'),
				'accounts_reference_number' 			=> $this->input->post('accounts_reference_number'),
				'accounts_narration' 					=> $this->input->post('accounts_narration'),
				//'accounts_total_debit_quantity' 		=> $this->input->post('accounts_total_debit_quantity'),
				//'accounts_total_credit_quantity' 		=> $this->input->post('accounts_total_credit_quantity'),
				'accounts_total_debit' 					=> $this->input->post('accounts_total_debit'),
				'accounts_total_credit' 				=> $this->input->post('accounts_total_credit'),
				'accounts_status' 						=> 1,
				'accounts_create_date' 					=> date('Y-m-d H:i:s')
			);



			if ($this->accounts_model->voucher_posting_accounts_create($data)) {
				$accounts_details_accounts_id = $this->db->insert_id();

				for ($i = 0; $i < $count; $i++) {
					//accounts_details table
					$data_1[] = array(
						'accounts_details_accounts_id' 				=> $accounts_details_accounts_id,
						'accounts_details_project' 					=> $this->input->post('accounts_project'),
						'accounts_details_voucher_posting_date' 	=> $this->input->post('accounts_voucher_posting_date'),
						'accounts_details_voucher_posting_month' 	=> date('F-Y', strtotime($this->input->post('accounts_voucher_posting_date'))),
						'accounts_details_voucher_posting_year' 	=> date('Y', strtotime($this->input->post('accounts_voucher_posting_date'))),
						'accounts_details_voucher_type' 			=> $this->input->post('accounts_voucher_type'),
						'accounts_details_voucher_type_code' 		=> $this->input->post('accounts_voucher_type_code'),
						'accounts_details_voucher_type_name' 		=> $this->input->post('accounts_voucher_type_name'),
						'accounts_details_voucher_number' 			=> $this->input->post('accounts_voucher_number'),
						'accounts_details_reference_number' 		=> $this->input->post('accounts_reference_number'),
						'accounts_details_narration' 				=> $this->input->post('accounts_narration'),
						'accounts_details_accounts_type' 			=> $this->input->post('accounts_details_accounts_type')[$i],
						'accounts_details_accounts_category' 		=> $this->input->post('accounts_details_accounts_category')[$i],
						'accounts_details_control_group' 			=> $this->input->post('accounts_details_control_group')[$i],
						'accounts_details_general_ledger' 			=> $this->input->post('accounts_details_general_ledger')[$i],
						'accounts_details_subsidiary_ledger' 		=> $this->input->post('accounts_details_subsidiary_ledger')[$i],
						//'accounts_details_debit_quantity' 			=> $this->input->post('accounts_details_debit_quantity')[$i],
						//'accounts_details_credit_quantity' 			=> $this->input->post('accounts_details_credit_quantity')[$i],
						'accounts_details_debit' 					=> $this->input->post('accounts_details_debit')[$i],
						'accounts_details_credit' 					=> $this->input->post('accounts_details_credit')[$i],
						'accounts_details_status' 					=> 1,
						'accounts_details_create_date' 				=> date('Y-m-d H:i:s'),
						'accounts_details_create_by' 				=> $user_id,
						'accounts_details_update_by' 				=> $user_id,
					);
				}


				$this->accounts_model->voucher_posting_accounts_details_create($data_1);
				$this->session->set_flashdata('success', $this->lang->line('data_insert_success'));
			} else {
				$this->session->set_flashdata('error', $this->lang->line('data_insert_error'));
			}
		} else {
			$this->session->set_flashdata('error', $this->lang->line('debit_credit_amount_do_not_match'));
		}
		redirect('accounts/voucher_posting');
	}

	/* ------------------------------------------------------
	Voucher Posting Create Function
	------------------------------------------------------- */
	function voucher_posting_create_ipd_opd()
	{
		$user_id = $this->session->userdata('user_id');
		if (!$user_id) {
			redirect('dashboard');
		}

		$accounts_total_debit		= $this->input->post('accounts_total_debit');
		$accounts_total_credit		= $this->input->post('accounts_total_credit');
		$count						= $this->input->post('count');

		$posting_date				= $this->input->post('posting_date');

		if (date('m', strtotime($posting_date)) < '07') {
			$start_financial_year = date('Y-07-01', strtotime($posting_date . "last year"));
		} else {
			$start_financial_year = date('Y-07-01', strtotime($posting_date));
		}

		if (date('m', strtotime($posting_date)) < '07') {
			$end_financial_year = date('Y-m-t', strtotime($posting_date));
		} else {
			$end_financial_year = date('Y-06-t', strtotime($posting_date . "+1 year"));
		}
		$accounts_voucher_type = 1;

		$accounts =  $this->db->select("COUNT(accounts_id) as voucher_number")
			->from('accounts')
			->where('accounts_voucher_posting_date BETWEEN "' . $start_financial_year . '" and "' . $end_financial_year . '"')
			->where('accounts_voucher_type', $accounts_voucher_type)
			->order_by('accounts_voucher_posting_date', 'ASC')
			->get()
			->result();

		$voucher_type =  $this->db->select("")
			->from('voucher_type')
			->where('voucher_type_id', $accounts_voucher_type)
			->order_by('voucher_type_id', 'ASC')
			->get()
			->result();

		foreach ($voucher_type as $voucher_type_row) {
			$voucher_type_code = $voucher_type_row->voucher_type_code;
			$accounts_voucher_type_code = $voucher_type_row->voucher_type_code;
			$accounts_voucher_type_name = $voucher_type_row->voucher_type_name;
		}

		foreach ($accounts as $row) {
			$voucher_number = str_pad($row->voucher_number + 1, 4, '0', STR_PAD_LEFT);
		}

		$accounts_voucher_number			= $voucher_type_code . '-' . $voucher_number;

		if ($accounts_total_debit == $accounts_total_credit) {
			//acoounts table
			$data = array(
				'accounts_project' 						=> 0,
				'accounts_voucher_posting_date' 		=> $this->input->post('posting_date'),
				'accounts_voucher_posting_month' 		=> date('F-Y', strtotime($this->input->post('posting_date'))),
				'accounts_voucher_posting_year' 		=> date('Y', strtotime($this->input->post('posting_date'))),
				'accounts_voucher_type' 				=> 1,
				'accounts_voucher_type_code' 			=> 'RV',
				'accounts_voucher_type_name' 			=> 'Receive Voucher',
				'accounts_voucher_number' 				=> $accounts_voucher_number,
				'accounts_narration' 					=> 'Cash Receive from Nurul Amin Khan Medical Center (IPD & OPD)',
				'accounts_total_debit' 					=> $this->input->post('accounts_total_debit'),
				'accounts_total_credit' 				=> $this->input->post('accounts_total_credit'),
				'accounts_status' 						=> 1,
				'accounts_create_date' 					=> date('Y-m-d H:i:s'),
				'accounts_create_by' 					=> $user_id,
				'accounts_update_by' 					=> $user_id,
			);

			//$posting_check = $this->project_accounts_model->posting_check($posting_date);

			if ($this->accounts_model->voucher_posting_accounts_create($data)) {
				$accounts_details_accounts_id = $this->db->insert_id();

				for ($i = 0; $i < $count; $i++) {

					//accounts_details table
					$data_1[] = array(
						'accounts_details_accounts_id' 				=> $accounts_details_accounts_id,
						'accounts_details_project' 					=> $this->input->post('accounts_details_project')[$i],
						'accounts_details_voucher_posting_date' 	=> $this->input->post('posting_date'),
						'accounts_details_voucher_posting_month' 	=> date('F-Y', strtotime($this->input->post('posting_date'))),
						'accounts_details_voucher_posting_year' 	=> date('Y', strtotime($this->input->post('posting_date'))),
						'accounts_details_voucher_type' 			=> 1,
						'accounts_details_voucher_type_code' 		=> 'RV',
						'accounts_details_voucher_type_name' 		=> 'Receive Voucher',
						'accounts_details_voucher_number' 			=> $accounts_voucher_number,
						'accounts_details_narration' 				=> 'Cash Receive from Nurul Amin Khan Medical Center (IPD & OPD)',
						'accounts_details_accounts_type' 			=> $this->input->post('accounts_details_accounts_type')[$i],
						'accounts_details_accounts_category' 		=> $this->input->post('accounts_details_accounts_category')[$i],
						'accounts_details_control_group' 			=> $this->input->post('accounts_details_control_group')[$i],
						'accounts_details_general_ledger' 			=> $this->input->post('accounts_details_general_ledger')[$i],
						'accounts_details_subsidiary_ledger' 		=> $this->input->post('accounts_details_subsidiary_ledger')[$i],
						'accounts_details_debit' 					=> $this->input->post('accounts_details_debit')[$i],
						'accounts_details_credit' 					=> $this->input->post('accounts_details_credit')[$i],
						'accounts_details_status' 					=> 1,
						'accounts_details_create_date' 				=> date('Y-m-d H:i:s'),
						'accounts_details_create_by' 				=> $user_id,
						'accounts_details_update_by' 				=> $user_id,
					);
				}

				$this->accounts_model->voucher_posting_accounts_details_create($data_1);
				echo '
				<div class="form-row">
					<div class="col-md-12">
						<div class="text-center mg-b-20">
							<img class="img  rounded-circle" src="' . base_url('assets/images/success-icon.png') . '" alt=""><br>
							<span class="tx-13 tx-danger tx-uppercase">' . $this->lang->line('data_insert_success') . '</span>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-outline-danger tx-uppercase" data-dismiss="modal">' . $this->lang->line('closed') . '</button>
				</div>
				';
			} else {
				echo '
				<div class="form-row">
					<div class="col-md-12">
						<div class="text-center mg-b-20">
							<img class="img  rounded-circle" src="' . base_url('assets/images/error-icon.png') . '" alt=""><br>
							<span class="tx-13 tx-danger tx-uppercase">' . $this->lang->line('data_insert_error') . '</span>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-outline-danger tx-uppercase" data-dismiss="modal">' . $this->lang->line('closed') . '</button>
				</div>
				';
			}
		} else {
			echo '
			<div class="form-row">
				<div class="col-md-12">
					<div class="text-center mg-b-20">
						<img class="img  rounded-circle" src="' . base_url('assets/images/error-icon.png') . '" alt=""><br>
						<span class="tx-13 tx-danger tx-uppercase">' . $this->lang->line('data_insert_error') . '</span>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-outline-danger tx-uppercase" data-dismiss="modal">' . $this->lang->line('closed') . '</button>
			</div>
			';
		}
	}


	/* ------------------------------------------------------
	Voucher Edit Function
	------------------------------------------------------- */
	function voucher_edit($id)
	{
		$data = array(
			"voucher_edit" 			=> $this->accounts_model->voucher_view($id),
			"page_title"			=> $this->lang->line('voucher_posting_edit'),
			"page_name"				=> $this->lang->line('voucher_posting_update')
		);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/voucher-edit');
		$this->load->view('footer');
	}


	/* ------------------------------------------------------
	Voucher Update Function
	------------------------------------------------------- */
	// function voucher_update()
	// {


	// 	$accounts_id				= $this->input->post('accounts_id');
	// 	$accounts_total_debit		= $this->input->post('accounts_total_debit');
	// 	$accounts_total_credit		= $this->input->post('accounts_total_credit');
	// 	$count						= $this->input->post('count');

	// 	if ($accounts_total_debit == $accounts_total_credit) {
	// 		//acoounts table
	// 		$data = array(
	// 			'accounts_id' 							=> $this->input->post('accounts_id'),
	// 			'accounts_voucher_posting_date' 		=> $this->input->post('accounts_voucher_posting_date'),
	// 			'accounts_narration' 					=> $this->input->post('accounts_narration'),
	// 			//'accounts_total_debit_quantity' 		=> $this->input->post('accounts_total_debit_quantity'),
	// 			//'accounts_total_credit_quantity' 		=> $this->input->post('accounts_total_credit_quantity'),
	// 			'accounts_total_debit' 					=> $this->input->post('accounts_total_debit'),
	// 			'accounts_total_credit' 				=> $this->input->post('accounts_total_credit'),
	// 			'accounts_update' 								=> date('Y-m-d H:i:s'),
	// 			'accounts_update_by' 							=> $user_id,
	// 		);

	// 		if ($this->accounts_model->voucher_update($data)) {

	// 			for ($i = 0; $i < $count; $i++) {
	// 				//accounts_details table
	// 				$data_1[] = array(
	// 					'accounts_details_id' 						=> $this->input->post('accounts_details_id')[$i],
	// 					'accounts_details_accounts_id' 				=> $this->input->post('accounts_id'),
	// 					'accounts_details_voucher_posting_date' 	=> $this->input->post('accounts_voucher_posting_date'),
	// 					'accounts_details_narration' 				=> $this->input->post('accounts_narration'),
	// 					'accounts_details_accounts_type' 			=> $this->input->post('accounts_details_accounts_type')[$i],
	// 					'accounts_details_accounts_category' 		=> $this->input->post('accounts_details_accounts_category')[$i],
	// 					'accounts_details_control_group' 			=> $this->input->post('accounts_details_control_group')[$i],
	// 					'accounts_details_general_ledger' 			=> $this->input->post('accounts_details_general_ledger')[$i],
	// 					'accounts_details_subsidiary_ledger' 		=> $this->input->post('accounts_details_subsidiary_ledger')[$i],
	// 					//'accounts_details_debit_quantity' 			=> $this->input->post('accounts_details_debit_quantity')[$i],
	// 					//'accounts_details_credit_quantity' 			=> $this->input->post('accounts_details_credit_quantity')[$i],
	// 					'accounts_details_debit' 					=> $this->input->post('accounts_details_debit')[$i],
	// 					'accounts_details_credit' 					=> $this->input->post('accounts_details_credit')[$i],
	// 					'accounts_details_update' 									=> date('Y-m-d H:i:s'),
	// 					'accounts_details_update_by' 								=> $user_id,
	// 				);
	// 			}

	// 			$this->accounts_model->voucher_details_update($data_1);
	// 			$this->session->set_flashdata('update', $this->lang->line('data_update_success'));
	// 		} else {
	// 			$this->session->set_flashdata('error', $this->lang->line('data_update_error'));
	// 		}
	// 	} else {
	// 		$this->session->set_flashdata('error', $this->lang->line('debit_credit_amount_do_not_match'));
	// 	}
	// 	redirect("accounts/voucher_edit/$accounts_id");
	// }

	function voucher_update()
	{

		// dd($this->input->post('accounts_voucher_type'));
		$accounts_id				= $this->input->post('accounts_id');
		$accounts_total_debit		= $this->input->post('accounts_total_debit');
		$accounts_total_credit		= $this->input->post('accounts_total_credit');
		$count						= $this->input->post('count');
		
		$voucherType = $this->db->select('*')->from('voucher_type')->where('voucher_type_id', $this->input->post('accounts_voucher_type'))->order_by('voucher_type_id', 'ASC')->get()->row();
		$accountsData = $this->db->select('*')->from('accounts')->where('accounts_id', $this->input->post('accounts_id'))->order_by('accounts_id', 'ASC')->get()->row();

		// dd($accountsData);
		if ($accounts_total_debit == $accounts_total_credit) {
			//acoounts table
			$data = array(
				'accounts_id' 							=> $this->input->post('accounts_id'),
				'accounts_voucher_posting_date' 		=> $this->input->post('accounts_voucher_posting_date'),
				'accounts_voucher_posting_date' 		=> $this->input->post('accounts_voucher_posting_date'),
				'accounts_voucher_posting_month' 		=> date('F-y', strtotime($this->input->post('accounts_voucher_posting_date'))),
				'accounts_voucher_posting_year' 		=> date('y', strtotime($this->input->post('accounts_voucher_posting_date'))),
				'accounts_narration' 					=> $this->input->post('accounts_narration'),
				'accounts_voucher_type' 				=> $this->input->post('accounts_voucher_type'),
				'accounts_voucher_type_code' 			=> $voucherType->voucher_type_code,
				'accounts_voucher_type_name' 			=> $voucherType->voucher_type_name,
				'accounts_voucher_number' 				=> $this->input->post('accounts_voucher_number'),
				'accounts_reference_number' 			=> $this->input->post('accounts_reference_number'),

				//'accounts_total_debit_quantity' 		=> $this->input->post('accounts_total_debit_quantity'),
				//'accounts_total_credit_quantity' 		=> $this->input->post('accounts_total_credit_quantity'),
				'accounts_total_debit' 					=> $this->input->post('accounts_total_debit'),
				'accounts_total_credit' 				=> $this->input->post('accounts_total_credit'),
				'accounts_update' 						=> date('Y-m-d H:i:s'),
				'accounts_update_by' 					=> $user_id,
			);

			$voucherTypes = [
				'RV' => 1,
				'PV' => 2,
				'JV' => 3,
				'CV' => 4,
			];

			if ($this->accounts_model->voucher_update($data)) {

				for ($i = 0; $i < $count; $i++) {
					$g_ledger =  $this->db->select("*")
						->from('chart_of_accounts')
						->where('chart_of_accounts_id', $this->input->post('accounts_details_general_ledger')[$i])
						->order_by('chart_of_accounts_id', 'ASC')
						->get()
						->result();
					foreach ($g_ledger as $g_ledger_row) {
					}

					$c_group =  $this->db->select("*")
						->from('chart_of_accounts')
						->where('chart_of_accounts_id', $g_ledger_row->chart_of_accounts_accounts_category)
						->order_by('chart_of_accounts_id', 'ASC')
						->get()
						->result();
					foreach ($c_group as $c_group_row) {
						$control_group_id = $c_group_row->chart_of_accounts_id;
					}

					$a_category =  $this->db->select("*")
						->from('chart_of_accounts')
						->where('chart_of_accounts_id', $c_group_row->chart_of_accounts_accounts_category)
						->order_by('chart_of_accounts_id', 'ASC')
						->get()
						->result();
					foreach ($a_category as $a_category_row) {
						$accounts_category_id = $a_category_row->chart_of_accounts_id;
					}

					$a_type =  $this->db->select("*")
						->from('accounts_type')
						->where('accounts_type_code', $a_category_row->chart_of_accounts_accounts_category)
						->order_by('accounts_type_code', 'ASC')
						->get()
						->result();
					foreach ($a_type as $a_type_row) {
						$accounts_type_id = $a_type_row->accounts_type_code;
					}
					//accounts_details table
					$data_1[] = array(
						'accounts_details_id' 						=> $this->input->post('accounts_details_id')[$i],
						'accounts_details_accounts_id' 				=> $this->input->post('accounts_id'),
						'accounts_details_voucher_posting_date' 	=> $this->input->post('accounts_voucher_posting_date'),
						'accounts_details_voucher_posting_month' 	=> date('F-y', strtotime($this->input->post('accounts_voucher_posting_date'))),
						'accounts_details_voucher_posting_year' 	=> date('y', strtotime($this->input->post('accounts_voucher_posting_date'))),
						'accounts_details_narration' 				=> $this->input->post('accounts_narration'),
						
						'accounts_details_voucher_type' 			=> (int)$this->input->post('accounts_voucher_type'),
						'accounts_details_voucher_type_code' 		=> $voucherType->voucher_type_code,
						'accounts_details_voucher_type_name' 		=> $voucherType->voucher_type_name,
						'accounts_details_voucher_number' 			=> $this->input->post('accounts_voucher_number'),
						'accounts_details_reference_number' 		=> $this->input->post('accounts_reference_number'),

						'accounts_details_accounts_category' 		=> $accounts_category_id,
						'accounts_details_control_group' 			=> $control_group_id,
						'accounts_details_general_ledger' 			=> $this->input->post('accounts_details_general_ledger')[$i],
						'accounts_details_subsidiary_ledger' 		=> $this->input->post('accounts_details_subsidiary_ledger')[$i],
						'accounts_details_debit' 					=> $this->input->post('accounts_details_debit')[$i],
						'accounts_details_credit' 					=> $this->input->post('accounts_details_credit')[$i],
						'accounts_details_update' 					=> date('Y-m-d H:i:s'),
						'accounts_details_status' 					=> 1,
						'accounts_details_update_by' 				=> $user_id,
					);
					
				}

				$this->accounts_model->voucher_details_update($this->input->post('accounts_id'), $data_1);
				$this->session->set_flashdata('update', $this->lang->line('data_update_success'));
			} else {
				$this->session->set_flashdata('error', $this->lang->line('data_update_error'));
			}
		} else {
			$this->session->set_flashdata('error', $this->lang->line('debit_credit_amount_do_not_match'));
		}
		redirect("accounts/voucher_edit/$accounts_id");
	}




	/* ------------------------------------------------------
	Voucher Delete Function
	------------------------------------------------------- */
	function voucher_delete($data)
	{
		$user_type = $this->session->ses_user_type;
        if ($user_type == "admin") {
			if ($this->accounts_model->voucher_delete($data)) {
				$this->session->set_flashdata('success', $this->lang->line('data_delete_success'));
			} else {
				$this->session->set_flashdata('error', $this->lang->line('data_delete_error'));
			}
			redirect('accounts/voucher_information');
		} else {
			$this->session->set_flashdata('error', $this->lang->line('you_have_not_permission'));
			redirect('/');
		}
	}

	/* ------------------------------------------------------
	Voucher Posting Report Print Function
	------------------------------------------------------- */
	function voucher_information_print()
	{
		$data = array(
			"voucher_type"			=> $this->input->post('voucher_type'),
			"posting_from_date"		=> $this->input->post('posting_from_date'),
			"posting_to_date"		=> $this->input->post('posting_to_date'),
			"page_title"			=> $this->lang->line('voucher_posting_report'),
			"page_name"				=> $this->lang->line('voucher_information')
		);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/voucher-information-print');
	}

	/* ------------------------------------------------------
	Voucher Posting Report Function
	------------------------------------------------------- */
	function voucher_view($id)
	{
		$data = array(
			"voucher_information" 	=> $this->accounts_model->voucher_view($id),
			"page_title"			=> $this->lang->line('voucher_posting_report'),
			"page_name"				=> $this->lang->line('voucher_information')
		);
		$this->load->view('accounts/voucher-view', $data);
	}

	/* ------------------------------------------------------
	Voucher Posting Report Function
	------------------------------------------------------- */
	function voucher_print($id)
	{
		$data = array(
			"voucher_information" 	=> $this->accounts_model->voucher_view($id),
			"page_title"			=> $this->lang->line('voucher_posting_print'),
			"page_name"				=> $this->lang->line('voucher_information')
		);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/voucher-print');
	}

	/* ------------------------------------------------------
	Voucher Posting Report Function
	------------------------------------------------------- */
	function voucher_number_search()
	{
		$data = array(
			"page_title"			=> $this->lang->line('voucher_number_search'),
			"page_name"				=> $this->lang->line('voucher_number_search')
		);
		$this->load->view('header', $data);
		//$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/voucher-number-search');
		$this->load->view('footer');
	}

	/* ------------------------------------------------------
	Get Voucher Number Search Function
	------------------------------------------------------- */
	function get_voucher_number_search()
	{
		$voucher_number			= $this->input->post('voucher_number');
		$posting_from_date		= $this->input->post('posting_from_date');
		$posting_to_date		= $this->input->post('posting_to_date');

		echo $this->accounts_model->voucher_number_search($voucher_number, $posting_from_date, $posting_to_date);
	}

	/* ------------------------------------------------------
	General Ledger Function
	------------------------------------------------------- */
	function general_ledger()
	{
		$data = array(
			"page_title"			=> $this->lang->line('general_ledger'),
			"page_name"				=> $this->lang->line('general_ledger')
		);
		//$this->load->view('header', $data);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/general-ledger');
		$this->load->view('footer');
	}

	/* ------------------------------------------------------
	Get General Ledger Function
	------------------------------------------------------- */
	function get_general_ledger()
	{
		$accounts_type		= $this->input->post('accounts_type');
		$accounts_category	= $this->input->post('accounts_category');
		$control_group		= $this->input->post('control_group');
		$general_ledger		= $this->input->post('general_ledger');
		$starting_date		= $this->input->post('starting_date');
		$closing_date		= $this->input->post('closing_date');

		echo $this->accounts_model->general_ledger($accounts_type, $accounts_category, $control_group, $general_ledger, $starting_date, $closing_date);
	}

	/* ------------------------------------------------------
	General Ledger Print Function
	------------------------------------------------------- */
	function general_ledger_print()
	{
		$data = array(
			"accounts_type"			=> $this->input->post('accounts_type'),
			"accounts_category"		=> $this->input->post('accounts_category'),
			"control_group"			=> $this->input->post('control_group'),
			"general_ledger"		=> $this->input->post('general_ledger'),
			"starting_date"			=> $this->input->post('starting_date'),
			"closing_date"			=> $this->input->post('closing_date'),
			"page_title"			=> $this->lang->line('general_ledger'),
			"page_name"				=> $this->lang->line('general_ledger')
		);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/general-ledger-print');
	}

	/* ------------------------------------------------------
	Subsidiary Ledger Function
	------------------------------------------------------- */
	function subsidiary_ledger()
	{
		$data = array(
			"page_title"			=> $this->lang->line('subsidiary_ledger'),
			"page_name"				=> $this->lang->line('subsidiary_ledger')
		);
		//$this->load->view('header', $data);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/subsidiary-ledger');
		$this->load->view('footer');
	}

	/* ------------------------------------------------------
	Get Subsidiary Ledger Function
	------------------------------------------------------- */
	function get_subsidiary_ledger()
	{
		$accounts_type		= $this->input->post('accounts_type');
		$accounts_category	= $this->input->post('accounts_category');
		$control_group		= $this->input->post('control_group');
		$general_ledger		= $this->input->post('general_ledger');
		$subsidiary_ledger		= $this->input->post('subsidiary_ledger');
		$starting_date		= $this->input->post('starting_date');
		$closing_date		= $this->input->post('closing_date');

		echo $this->accounts_model->subsidiary_ledger($accounts_type, $accounts_category, $control_group, $general_ledger, $subsidiary_ledger, $starting_date, $closing_date);
	}

	/* ------------------------------------------------------
	Subsidiary Ledger Print Function
	------------------------------------------------------- */
	function subsidiary_ledger_print()
	{
		$data = array(
			"accounts_type"			=> $this->input->post('accounts_type'),
			"accounts_category"		=> $this->input->post('accounts_category'),
			"control_group"			=> $this->input->post('control_group'),
			"general_ledger"		=> $this->input->post('general_ledger'),
			"subsidiary_ledger"		=> $this->input->post('subsidiary_ledger'),
			"starting_date"			=> $this->input->post('starting_date'),
			"closing_date"			=> $this->input->post('closing_date'),
			"page_title"			=> $this->lang->line('subsidiary_ledger'),
			"page_name"				=> $this->lang->line('subsidiary_ledger')
		);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/subsidiary-ledger-print');
	}

	/* ------------------------------------------------------
	Trial Balance Function
	------------------------------------------------------- */
	function trial_balance()
	{
		$data = array(
			"page_title"			=> $this->lang->line('trial_balance'),
			"page_name"				=> $this->lang->line('trial_balance')
		);
		//$this->load->view('header', $data);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/trial-balance');
		$this->load->view('footer');
	}

	/* ------------------------------------------------------
	Get Trial Balance Function
	------------------------------------------------------- */
	function get_trial_balance()
	{
		$posting_to_date		= $this->input->post('posting_to_date');

		echo $this->accounts_model->trial_balance($posting_to_date);
	}
	/* ------------------------------------------------------
	Trial Balance Print Function
	------------------------------------------------------- */
	function trial_balance_print()
	{
		$data = array(
			"posting_to_date"		=> $this->input->post('posting_to_date'),
			"page_title"			=> $this->lang->line('trial_balance'),
			"page_name"				=> $this->lang->line('trial_balance')
		);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/trial-balance-print');
	}


	/* ------------------------------------------------------
	Balance Sheet Function
	------------------------------------------------------- */
	function balance_sheet()
	{
		$data = array(
			"page_title"			=> $this->lang->line('balance_sheet'),
			"page_name"				=> $this->lang->line('balance_sheet')
		);
		//$this->load->view('header', $data);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/balance-sheet');
		$this->load->view('footer');
	}

	/* ------------------------------------------------------
	Get Balance Sheet Function
	------------------------------------------------------- */
	function get_balance_sheet()
	{
		$closing_month		= $this->input->post('closing_month');

		echo $this->accounts_model->balance_sheet($closing_month);
	}
	/* ------------------------------------------------------
	Balance Sheet Print Function
	------------------------------------------------------- */
	function balance_sheet_print()
	{
		$data = array(
			"closing_month"			=> $this->input->post('closing_month'),
			"page_title"			=> $this->lang->line('balance_sheet'),
			"page_name"				=> $this->lang->line('balance_sheet')
		);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/balance-sheet-print');
	}

	/* ------------------------------------------------------
	Income & Expenditure Statement Function
	------------------------------------------------------- */
	function income_expenditure_statement()
	{
		$data = array(
			"page_title"			=> $this->lang->line('income_expenditure_statement'),
			"page_name"				=> $this->lang->line('income_expenditure_statement')
		);
		//$this->load->view('header', $data);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/income-expenditure-statement');
		$this->load->view('footer');
	}

	/* ------------------------------------------------------
	Get Income & Expenditure Statement Function
	------------------------------------------------------- */
	function get_income_expenditure_statement()
	{
		$closing_month		= $this->input->post('closing_month');

		echo $this->accounts_model->income_expenditure_statement($closing_month);
	}
	/* ------------------------------------------------------
	Income & Expenditure Statement Print Function
	------------------------------------------------------- */
	function income_expenditure_statement_print()
	{
		$data = array(
			"closing_month"			=> $this->input->post('closing_month'),
			"page_title"			=> $this->lang->line('income_expenditure_statement'),
			"page_name"				=> $this->lang->line('income_expenditure_statement')
		);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/income-expenditure-statement-print');
	}

	/* ------------------------------------------------------
	Balance Sheet Note Function
	------------------------------------------------------- */
	function balance_sheet_notes_view()
	{
		$data = array(
			"type"					=> $this->input->get('type'),
			"note"					=> $this->input->get('note'),
			"coa"					=> $this->input->get('coa'),
			"closing_month"			=> $this->input->get('closing_month'),
			"page_title"			=> $this->lang->line('balance_sheet_note'),
			"page_name"				=> $this->lang->line('balance_sheet_note'),
		);

		$this->load->view('accounts/balance-sheet-notes-view', $data);
	}

	/* ------------------------------------------------------
	Balance Sheet Note Function
	------------------------------------------------------- */
	function balance_sheet_note_view_print()
	{
		$data = array(
			"type"					=> $this->input->get('type'),
			"note"					=> $this->input->get('note'),
			"coa"					=> $this->input->get('coa'),
			"closing_month"			=> $this->input->get('closing_month'),
			"page_title"			=> $this->lang->line('balance_sheet_note'),
			"page_name"				=> $this->lang->line('balance_sheet_note'),
		);

		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/balance-sheet-notes-view-print');
	}

	/* ------------------------------------------------------
	Balance Sheet Note Function
	------------------------------------------------------- */
	function income_expenditure_notes_view()
	{
		$data = array(
			"type"					=> $this->input->get('type'),
			"note"					=> $this->input->get('note'),
			"s_coa"					=> $this->input->get('s_coa'),
			"coa"					=> $this->input->get('coa'),
			"closing_month"			=> $this->input->get('closing_month'),
			"page_title"			=> $this->lang->line('income_expenditure_note'),
			"page_name"				=> $this->lang->line('income_expenditure_note'),
		);

		$this->load->view('accounts/income-expenditure-notes-view', $data);
	}

	/* ------------------------------------------------------
	Balance Sheet Note Function
	------------------------------------------------------- */
	function income_expenditure_notes_view_print()
	{
		$data = array(
			"type"					=> $this->input->get('type'),
			"note"					=> $this->input->get('note'),
			"s_coa"					=> $this->input->get('s_coa'),
			"coa"					=> $this->input->get('coa'),
			"closing_month"			=> $this->input->get('closing_month'),
			"page_title"			=> $this->lang->line('income_expenditure_note'),
			"page_name"				=> $this->lang->line('income_expenditure_note'),
		);

		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/income-expenditure-notes-view-print');
	}

	/* ------------------------------------------------------
	Balance Sheet Note Function
	------------------------------------------------------- */
	function balance_sheet_note()
	{
		$data = array(
			"page_title"			=> $this->lang->line('balance_sheet_note'),
			"page_name"				=> $this->lang->line('balance_sheet_note')
		);
		//$this->load->view('header', $data);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/balance-sheet-note');
		$this->load->view('footer');
	}

	/* ------------------------------------------------------
	Get Balance Sheet Note Function
	------------------------------------------------------- */
	function get_balance_sheet_note()
	{
		$closing_month		= $this->input->post('closing_month');

		echo $this->accounts_model->balance_sheet_note($closing_month);
	}
	/* ------------------------------------------------------
	Balance Sheet Note Print Function
	------------------------------------------------------- */
	function balance_sheet_note_print()
	{
		$data = array(
			"closing_month"			=> $this->input->post('closing_month'),
			"page_title"			=> $this->lang->line('balance_sheet_note'),
			"page_name"				=> $this->lang->line('notes_to_the_financial_statements')
		);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/balance-sheet-note-print');
	}

	/* ------------------------------------------------------
	Income & Expenditure Note Function
	------------------------------------------------------- */
	function income_expenditure_note()
	{
		$data = array(
			"page_title"			=> $this->lang->line('income_expenditure_note'),
			"page_name"				=> $this->lang->line('income_expenditure_note')
		);
		//$this->load->view('header', $data);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/income-expenditure-note');
		$this->load->view('footer');
	}

	/* ------------------------------------------------------
	Get Income & Expenditure Note Function
	------------------------------------------------------- */
	function get_income_expenditure_note()
	{
		$closing_month		= $this->input->post('closing_month');

		echo $this->accounts_model->income_expenditure_note($closing_month);
	}

	/* ------------------------------------------------------
	Income & Expenditure Note Print Function
	------------------------------------------------------- */
	function income_expenditure_note_print()
	{
		$data = array(
			"closing_month"			=> $this->input->post('closing_month'),
			"page_title"			=> $this->lang->line('income_expenditure_note'),
			"page_name"				=> $this->lang->line('notes_to_the_financial_statements')
		);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/income-expenditure-note-print');
	}

	/* ------------------------------------------------------
	Receipt & Payment Statement Function
	------------------------------------------------------- */
	/* ------------------------------------------------------
	Receipt & Payment Statement Function
	------------------------------------------------------- */
	function receipt_payment()
	{
		$data = array(
			"page_title"			=> $this->lang->line('receipt_payment'),
			"page_name"				=> $this->lang->line('receipt_payment')
		);
		//$this->load->view('header', $data);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/receipt-payment');
		$this->load->view('footer');
	}

	/* ------------------------------------------------------
	Get Receipt & Payment Statement Function
	------------------------------------------------------- */
	function get_receipt_payment()
	{
		$closing_month		= $this->input->post('closing_month');

		echo $this->accounts_model->receipt_payment($closing_month);
	}

	/* ------------------------------------------------------
	Receipt & Payment Statement Print Function
	------------------------------------------------------- */
	function receipt_payment_print()
	{
		$data = array(
			"closing_month"			=> $this->input->post('closing_month'),
			"page_title"			=> $this->lang->line('receipt_payment'),
			"page_name"				=> $this->lang->line('receipt_payment')
		);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/receipt-payment-print');
	}
	
	function receipt_payment_old()
	{
		$data = array(
			"page_title"			=> $this->lang->line('receipt_payment'),
			"page_name"				=> $this->lang->line('receipt_payment')
		);
		//$this->load->view('header', $data);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/receipt-payment');
		$this->load->view('footer');
	}

	/* ------------------------------------------------------
	Get Receipt & Payment Statement Function
	------------------------------------------------------- */
	function get_receipt_payment_old()
	{
		$starting_date		= $this->input->post('starting_date');
		$closing_date		= $this->input->post('closing_date');

		echo $this->accounts_model->receipt_payment($starting_date, $closing_date);
	}

	/* ------------------------------------------------------
	Receipt & Payment Statement Print Function
	------------------------------------------------------- */
	function receipt_payment_print_old()
	{
		$data = array(
			"starting_date"			=> $this->input->post('starting_date'),
			"closing_date"			=> $this->input->post('closing_date'),
			"page_title"			=> $this->lang->line('receipt_payment'),
			"page_name"				=> $this->lang->line('receipt_payment')
		);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/receipt-payment-print');
	}

	/* ------------------------------------------------------
	Cash Book Ledger Function
	------------------------------------------------------- */
	function cash_book_ledger()
	{
		$data = array(
			"page_title"			=> $this->lang->line('cash_book'),
			"page_name"				=> $this->lang->line('cash_book')
		);
		//$this->load->view('header', $data);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/cash-book-ledger');
		$this->load->view('footer');
	}

	/* ------------------------------------------------------
	Get Cash Book Ledger Function
	------------------------------------------------------- */
	function get_cash_book_ledger()
	{
		$from_date		= $this->input->post('from_date');
		$to_date		= $this->input->post('to_date');

		echo $this->accounts_model->cash_book_ledger($from_date, $to_date);
	}

	/* ------------------------------------------------------
	Cash Book Ledger Print Function
	------------------------------------------------------- */
	function cash_book_ledger_print()
	{
		$data = array(
			"from_date"			=> $this->input->post('from_date'),
			"to_date"			=> $this->input->post('to_date'),

			"page_title"			=> $this->lang->line('cash_book'),
			"page_name"				=> $this->lang->line('cash_book')
		);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/cash-book-ledger-print');
	}

	/* ------------------------------------------------------
	Cash Flow Statement Function
	------------------------------------------------------- */
	function cash_flow_statement()
	{
		$data = array(
			"page_title"			=> $this->lang->line('cash_flow_statement'),
			"page_name"				=> $this->lang->line('cash_flow_statement')
		);
		//$this->load->view('header', $data);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/cash-flow-statement');
		$this->load->view('footer');
	}

	/* ------------------------------------------------------
	Get Cash Flow Statement Function
	------------------------------------------------------- */
	function get_cash_flow_statement()
	{
		$closing_month		= $this->input->post('closing_month');

		echo $this->accounts_model->cash_flow_statement($closing_month);
	}

	/* ------------------------------------------------------
	Cash Flow Statement Print Function
	------------------------------------------------------- */
	function cash_flow_statement_print()
	{
		$data = array(
			"closing_month"			=> $this->input->post('closing_month'),

			"page_title"			=> $this->lang->line('cash_flow_statement'),
			"page_name"				=> $this->lang->line('cash_flow_statement')
		);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/cash-flow-statement-print');
	}

	/* ------------------------------------------------------
	Changes in Equity Function
	------------------------------------------------------- */
	function changes_in_equity()
	{
		$data = array(
			"page_title"			=> $this->lang->line('changes_in_equity'),
			"page_name"				=> $this->lang->line('changes_in_equity_statement')
		);
		//$this->load->view('header', $data);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/changes-in-equity');
		$this->load->view('footer');
	}

	/* ------------------------------------------------------
	Get Changes in Equity Function
	------------------------------------------------------- */
	function get_changes_in_equity()
	{
		$closing_month		= $this->input->post('closing_month');

		echo $this->accounts_model->changes_in_equity($closing_month);
	}

	/* ------------------------------------------------------
	Changes in Equity Print Function
	------------------------------------------------------- */
	function changes_in_equity_print()
	{
		$data = array(
			"closing_month"			=> $this->input->post('closing_month'),

			"page_title"			=> $this->lang->line('changes_in_equity'),
			"page_name"				=> $this->lang->line('changes_in_equity_statement')
		);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/changes-in-equity-print');
	}

	/* ------------------------------------------------------
	Fixed Assets Schedule Function
	------------------------------------------------------- */
	function fixed_assets_schedule()
	{
		$data = array(
			"page_title"			=> $this->lang->line('fixed_assets_schedule'),
			"page_name"				=> $this->lang->line('fixed_assets_schedule')
		);
		$this->load->view('header', $data);
		$this->load->view('accounts/fixed-assets-schedule');
		$this->load->view('footer');
	}

	/* ------------------------------------------------------
	Get Fixed Assets Schedule Function
	------------------------------------------------------- */
	function get_fixed_assets_schedule()
	{
		$closing_year		= $this->input->post('closing_year');

		echo $this->accounts_model->fixed_assets_schedule($closing_year);
	}
	/* ------------------------------------------------------
	Fixed Assets Schedule Print Function
	------------------------------------------------------- */
	function fixed_assets_schedule_print()
	{
		$data = array(
			"closing_year"			=> $this->input->post('closing_year'),
			"page_title"			=> $this->lang->line('fixed_assets_schedule'),
			"page_name"				=> $this->lang->line('fixed_assets_schedule')
		);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/fixed-assets-schedule-print');
	}

	/* ------------------------------------------------------
	Salary Function
	------------------------------------------------------- */
	function salary()
	{
		$data = array(
			"page_title"			=> $this->lang->line('salary'),
			"page_name"				=> $this->lang->line('salary')
		);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/salary');
		$this->load->view('footer');
	}

	/* ------------------------------------------------------
	Get Salary Process Info Function
	------------------------------------------------------- */
	function get_salary_process_info()
	{
		$salary_month		= $this->input->post('salary_month');
		$salary_date		= $this->input->post('salary_date');

		echo $this->accounts_model->get_salary_process_info($salary_month, $salary_date);
	}

	/* ------------------------------------------------------
	Voucher Posting Create Function
	------------------------------------------------------- */
	function salary_create()
	{

		$count						= $this->input->post('count');


		for ($i = 0; $i < $count; $i++) {
			$salary_due_amount[] = $this->input->post('salary_payable_amount')[$i] - $this->input->post('salary_paid_amount')[$i];
			$data[] = array(
				'salary_employee' 			=> $this->input->post('salary_employee')[$i],
				'salary_employee_id_number' 		=> $this->input->post('salary_employee_id_number')[$i],
				'salary_employee_name' 		=> $this->input->post('salary_employee_name')[$i],
				'salary_employee_designation' 		=> $this->input->post('salary_employee_designation')[$i],
				'salary_employee_department' 		=> $this->input->post('salary_employee_department')[$i],
				'salary_employee_grade' 		=> $this->input->post('salary_employee_grade')[$i],
				'salary_basic_salary' 		=> $this->input->post('salary_basic_salary')[$i],
				'salary_house_rent_salary' 		=> $this->input->post('salary_house_rent_salary')[$i],
				'salary_medical_allowance' 		=> $this->input->post('salary_medical_allowance')[$i],
				'salary_conveyance_allowance' 		=> $this->input->post('salary_conveyance_allowance')[$i],
				'salary_others_allowance' 		=> $this->input->post('salary_others_allowance')[$i],
				'salary_gross_salary' 		=> $this->input->post('salary_gross_salary')[$i],
				'salary_deduction_stamp' 		=> $this->input->post('salary_deduction_stamp')[$i],
				'salary_deduction_tax' 		=> $this->input->post('salary_deduction_tax')[$i],
				'salary_deduction_vat' 		=> $this->input->post('salary_deduction_vat')[$i],
				'salary_deduction_others' 		=> $this->input->post('salary_deduction_others')[$i],
				'salary_payable_amount' 		=> $this->input->post('salary_payable_amount')[$i],
				'salary_paid_amount' 		=> $this->input->post('salary_paid_amount')[$i],
				'salary_due_amount' 		=> $salary_due_amount[$i],
				'salary_month' 		=> date('Y-m-d', strtotime($this->input->post('salary_month'))),
				'salary_date' 		=> $this->input->post('salary_date'),
				'salary_status' 					=> 1,
				'salary_create_date' 				=> date('Y-m-d H:i:s'),
				'salary_create_by' 				=> $user_id,
				'salary_update_by' 				=> $user_id,
			);
		}
		if ($this->accounts_model->salary_create($data)) {
			$this->session->set_flashdata('success', $this->lang->line('data_insert_success'));
		} else {
			$this->session->set_flashdata('error', $this->lang->line('data_insert_error'));
		}
		redirect('accounts/salary');
	}

	/* ------------------------------------------------------
	Salary Function
	------------------------------------------------------- */
	function salary_sheet()
	{
		$data = array(
			"page_title"			=> $this->lang->line('salary_sheet'),
			"page_name"				=> $this->lang->line('salary_sheet')
		);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/salary-sheet');
		$this->load->view('footer');
	}

	/* ------------------------------------------------------
	Get Salary Sheet Function
	------------------------------------------------------- */
	function get_salary_sheet()
	{
		$salary_month		= $this->input->post('salary_month');

		echo $this->accounts_model->salary_sheet($salary_month);
	}

	/* ------------------------------------------------------
	Receipt & Payment Statement Print Function
	------------------------------------------------------- */
	function salary_sheet_print()
	{
		$data = array(
			"salary_month"			=> $this->input->post('salary_month'),
			"page_title"			=> $this->lang->line('salary_sheet'),
			"page_name"				=> $this->lang->line('salary_sheet')
		);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/salary-sheet-print');
	}

	/* ------------------------------------------------------
	Collection Summary Report Function
	------------------------------------------------------- */
	function collection_summary_report()
	{
		$data = array(
			"page_title"			=> $this->lang->line('collection_summary_report'),
			"page_name"				=> $this->lang->line('collection_summary_report')
		);
		$this->load->view('header', $data);
		$this->load->view('accounts/collection-summary-report');
		$this->load->view('footer');
	}

	/* ------------------------------------------------------
	Get Collection Summary Report Function
	------------------------------------------------------- */
	function get_collection_summary_report()
	{
		$from_date 		= $this->input->post('from_date');
		$to_date 		= $this->input->post('to_date');
		$user 			= $this->input->post('user');
		echo $this->accounts_model->collection_summary_report($from_date, $to_date, $user);
	}

	/* ------------------------------------------------------
	Collection Summary Report Print Function
	------------------------------------------------------- */
	function collection_summary_report_print()
	{
		$data = array(
			"from_date"				=> $this->input->post('from_date'),
			"to_date"				=> $this->input->post('to_date'),
			"user"					=> $this->input->post('user'),
			"page_title"			=> $this->lang->line('collection_summary_report'),
			"page_name"				=> $this->lang->line('collection_summary_report')
		);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/collection-summary-report-print');
	}

	/* ------------------------------------------------------
	Daily Collection Summary Function
	------------------------------------------------------- */
	function daily_collection_summary()
	{
		$data = array(
			"page_title"			=> $this->lang->line('daily_summary_report'),
			"page_name"				=> $this->lang->line('daily_summary_report')
		);
		//$this->load->view('header', $data);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/daily-collection-summary');
		$this->load->view('footer');
	}

	/* ------------------------------------------------------
	Get Daily Collection Summary Function
	------------------------------------------------------- */
	function get_daily_collection_summary()
	{
		$to_date 		= $this->input->post('to_date');
		$user 			= $this->input->post('user');
		echo $this->accounts_model->daily_collection_summary($to_date, $user);
	}

	/* ------------------------------------------------------
	Daily Collection Summary Print Function
	------------------------------------------------------- */
	function daily_collection_summary_print()
	{
		$data = array(
			"to_date"				=> $this->input->post('to_date'),
			"user"					=> $this->input->post('user'),
			"page_title"			=> $this->lang->line('daily_collection_summary'),
			"page_name"				=> $this->lang->line('daily_collection_summary')
		);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/daily-collection-summary-print');
	}

	/* ------------------------------------------------------
	Day Close Function
	------------------------------------------------------- */
	function day_close()
	{
		$data = array(
			"page_title"			=> $this->lang->line('day_close'),
			"page_name"				=> $this->lang->line('day_close')
		);
		$this->load->view('accounts/header-top', $data);
		$this->load->view('accounts/day-close');
		$this->load->view('footer');
	}

	/* ------------------------------------------------------
	Get Day Close Function
	------------------------------------------------------- */
	function get_day_close()
	{
		$project 		= $this->input->post('project');
		$to_date 		= $this->input->post('to_date');
		$user 			= $this->input->post('user');
		echo $this->accounts_model->day_close($to_date, $user);
	}

	private function get_coa_details_data($data)
	{
		$coa_data = $this->db->get_where('chart_of_accounts', ['chart_of_accounts_link' => $data])->row();
		return $coa_data;
	}

	private function get_coa_cat_data($data)
	{
		$coa_data = $this->db->get_where('chart_of_accounts', ['chart_of_accounts_accounts_category' => $data])->row();
		return $coa_data;
	}

	private function get_coa_id_data($data)
	{
		$coa_data = $this->db->get_where('chart_of_accounts', ['chart_of_accounts_id' => $data])->row();
		return $coa_data;
	}

	function ledgerData()
	{
		$ledgers = $this->accounts_model->getLedgeers();
		// ddd($this->db->last_query());

		$html = "<option value='0'>Select</option>";

		foreach($ledgers as $row){
			$html.= "<option value='$row->chart_of_accounts_id'>$row->chart_of_accounts_name ($row->chart_of_accounts_code)</option>";
		}

		echo $html;
	}

	/* ------------------------------------------------------
	Day Close Create Function
	------------------------------------------------------- */
	function day_close_create()
	{
		$rv_accounts_data 			= $this->input->post('rv_accounts_data');
		$rv_accounts_details_data 	= $this->input->post('rv_accounts_details_data');
		
		$pv_accounts_data 			= $this->input->post('pv_accounts_data');
		$pv_accounts_details_data 	= $this->input->post('pv_accounts_details_data');
		
		// $jv_1_accounts_data 			= $this->input->post('jv_1_accounts_data');
		// $jv_1_accounts_details_data 	= $this->input->post('jv_1_accounts_details_data');
		
		// $jv_2_accounts_data 			= $this->input->post('jv_2_accounts_data');
		// $jv_2_accounts_details_data 	= $this->input->post('jv_2_accounts_details_data');
		
		// $jv_3_accounts_data 			= $this->input->post('jv_3_accounts_data');
		// $jv_3_accounts_details_data 	= $this->input->post('jv_3_accounts_details_data');
		
		$rv_cb_accounts_data 			= $this->input->post('rv_cb_accounts_data');
		$rv_cb_accounts_details_data 	= $this->input->post('rv_cb_accounts_details_data');
		
		$posting_date				= $rv_accounts_data['accounts_voucher_posting_date'];
		
		$posting_check = $this->db->select("*")
		->from('accounts')
		->where('accounts_voucher_posting_date',$posting_date)
		->where('accounts_voucher_posting_status','Auto')
		->get()
		->row();
		
		if($posting_check) {
		echo '
			<div class="form-row">
				<div class="col-md-12">
					<div class="text-center mg-b-20">
						<img class="img  rounded-circle" src="' . base_url('assets/assets/images/error-icon.png') . '" alt=""><br>
						<span class="tx-13 tx-danger tx-uppercase">' . $this->lang->line('day_close_error') . '</span>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-outline-danger tx-uppercase" data-dismiss="modal">' . $this->lang->line('closed') . '</button>
			</div>
			';
		} else {

		if (date('m', strtotime($posting_date)) < '07') {
			$start_financial_year = date('Y-07-01', strtotime($posting_date . "last year"));
		} else {
			$start_financial_year = date('Y-07-01', strtotime($posting_date));
		}

		if (date('m', strtotime($posting_date)) < '07') {
			$end_financial_year = date('Y-m-t', strtotime($posting_date));
		} else {
			$end_financial_year = date('Y-06-t', strtotime($posting_date . "+1 year"));
		}
		
		$rv_accounts_v_number =  $this->db->select("COUNT(accounts_id) as voucher_number")
		->from('accounts')
		->where('accounts_voucher_posting_date BETWEEN "' . $start_financial_year . '" and "' . $end_financial_year . '"')
		->where('accounts_voucher_type', $rv_accounts_data['accounts_voucher_type'])
		->get()
		->row();
		$rv_voucher_number = str_pad($rv_accounts_v_number->voucher_number + 1, 4, '0', STR_PAD_LEFT);
		$rv_accounts_voucher_number = $rv_accounts_data['accounts_voucher_type_code'].'-'.$rv_voucher_number;
		
		$pv_accounts_v_number =  $this->db->select("COUNT(accounts_id) as voucher_number")
		->from('accounts')
		->where('accounts_voucher_posting_date BETWEEN "' . $start_financial_year . '" and "' . $end_financial_year . '"')
		->where('accounts_voucher_type', $pv_accounts_data['accounts_voucher_type'])
		->get()
		->row();
		$pv_voucher_number = str_pad($pv_accounts_v_number->voucher_number + 1, 4, '0', STR_PAD_LEFT);
		$pv_accounts_voucher_number = $pv_accounts_data['accounts_voucher_type_code'].'-'.$pv_voucher_number;
		
		$rv_data = array(
			'accounts_project' 						=> $rv_accounts_data['accounts_project'],
			'accounts_voucher_posting_date' 		=> $rv_accounts_data['accounts_voucher_posting_date'],
			'accounts_voucher_posting_month' 		=> $rv_accounts_data['accounts_voucher_posting_month'],
			'accounts_voucher_posting_year' 		=> $rv_accounts_data['accounts_voucher_posting_year'],
			'accounts_voucher_type' 				=> $rv_accounts_data['accounts_voucher_type'],
			'accounts_voucher_type_code' 			=> $rv_accounts_data['accounts_voucher_type_code'],
			'accounts_voucher_type_name' 			=> $rv_accounts_data['accounts_voucher_type_name'],
			'accounts_voucher_number' 				=> $rv_accounts_voucher_number,
			'accounts_narration' 					=> $rv_accounts_data['accounts_narration'],
			'accounts_total_debit' 					=> $rv_accounts_data['accounts_total_debit'],
			'accounts_total_credit' 				=> $rv_accounts_data['accounts_total_credit'],
			'accounts_voucher_posting_status' 		=> 'Auto',
			'accounts_status' 						=> 1,
			'accounts_create_date' 					=> date('Y-m-d H:i:s'),
			'accounts_create_by' 					=> 0,
			'accounts_update_by' 					=> 0,
		);
		
		$data = $this->accounts_model->voucher_posting_accounts_create($rv_data);
		
		if($data){
			$rv_accounts_id = $this->db->insert_id();
			foreach($rv_accounts_details_data as $row){
				
				$accounts_details_general_ledger = $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_accounts_category',array('chart_of_accounts_id'=>$row['accounts_details_subsidiary_ledger']),'chart_of_accounts_accounts_category');
				
				$accounts_details_control_group = $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_accounts_category',array('chart_of_accounts_id'=>$accounts_details_general_ledger),'chart_of_accounts_accounts_category');
				
				$accounts_details_accounts_category = $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_accounts_category',array('chart_of_accounts_id'=>$accounts_details_control_group),'chart_of_accounts_accounts_category');
				
				$accounts_details_accounts_type = $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_accounts_category',array('chart_of_accounts_id'=>$accounts_details_accounts_category),'chart_of_accounts_accounts_category');
				
				$rv_details_data = array(
					'accounts_details_accounts_id' 				=> $rv_accounts_id,
					'accounts_details_project' 					=> $row['accounts_details_project'],
					'accounts_details_voucher_posting_date' 	=> $row['accounts_details_voucher_posting_date'],
					'accounts_details_voucher_posting_month' 	=> $row['accounts_details_voucher_posting_month'],
					'accounts_details_voucher_posting_year' 	=> $row['accounts_details_voucher_posting_year'],
					'accounts_details_voucher_type' 			=> $row['accounts_details_voucher_type'],
					'accounts_details_voucher_type_code' 		=> $row['accounts_details_voucher_type_code'],
					'accounts_details_voucher_type_name' 		=> $row['accounts_details_voucher_type_name'],
					'accounts_details_voucher_number' 			=> $rv_accounts_voucher_number,
					'accounts_details_narration' 				=> $row['accounts_details_narration'],
					'accounts_details_accounts_type' 			=> $accounts_details_accounts_type,
					'accounts_details_accounts_category' 		=> $accounts_details_accounts_category,
					'accounts_details_control_group' 			=> $accounts_details_control_group,
					'accounts_details_general_ledger' 			=> $accounts_details_general_ledger,
					'accounts_details_subsidiary_ledger' 		=> $row['accounts_details_subsidiary_ledger'],
					'accounts_details_debit' 					=> $row['accounts_details_debit'],
					'accounts_details_credit' 					=> $row['accounts_details_credit'],
					'accounts_details_status' 					=> 1,
					'accounts_details_create_date' 				=> date('Y-m-d H:i:s'),
					'accounts_details_create_by' 				=> 0,
					'accounts_details_update_by' 				=> 0,
				);
				$this->db->insert('accounts_details', $rv_details_data);
			}
			if($pv_accounts_data['accounts_total_debit']>0) {
			$pv_data = array(
				'accounts_project' 						=> $pv_accounts_data['accounts_project'],
				'accounts_voucher_posting_date' 		=> $pv_accounts_data['accounts_voucher_posting_date'],
				'accounts_voucher_posting_month' 		=> $pv_accounts_data['accounts_voucher_posting_month'],
				'accounts_voucher_posting_year' 		=> $pv_accounts_data['accounts_voucher_posting_year'],
				'accounts_voucher_type' 				=> $pv_accounts_data['accounts_voucher_type'],
				'accounts_voucher_type_code' 			=> $pv_accounts_data['accounts_voucher_type_code'],
				'accounts_voucher_type_name' 			=> $pv_accounts_data['accounts_voucher_type_name'],
				'accounts_voucher_number' 				=> $pv_accounts_voucher_number,
				'accounts_narration' 					=> $pv_accounts_data['accounts_narration'],
				'accounts_total_debit' 					=> $pv_accounts_data['accounts_total_debit'],
				'accounts_total_credit' 				=> $pv_accounts_data['accounts_total_credit'],
				'accounts_voucher_posting_status' 		=> 'Auto',
				'accounts_status' 						=> 1,
				'accounts_create_date' 					=> date('Y-m-d H:i:s'),
				'accounts_create_by' 					=> 0,
				'accounts_update_by' 					=> 0,
			);
			$this->accounts_model->voucher_posting_accounts_create($pv_data);
			
			$pv_accounts_id = $this->db->insert_id();
			foreach($pv_accounts_details_data as $row){
				
				$accounts_details_general_ledger = $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_accounts_category',array('chart_of_accounts_id'=>$row['accounts_details_subsidiary_ledger']),'chart_of_accounts_accounts_category');
				
				$accounts_details_control_group = $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_accounts_category',array('chart_of_accounts_id'=>$accounts_details_general_ledger),'chart_of_accounts_accounts_category');
				
				$accounts_details_accounts_category = $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_accounts_category',array('chart_of_accounts_id'=>$accounts_details_control_group),'chart_of_accounts_accounts_category');
				
				$accounts_details_accounts_type = $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_accounts_category',array('chart_of_accounts_id'=>$accounts_details_accounts_category),'chart_of_accounts_accounts_category');
				
				$pv_details_data = array(
					'accounts_details_accounts_id' 				=> $pv_accounts_id,
					'accounts_details_project' 					=> $row['accounts_details_project'],
					'accounts_details_voucher_posting_date' 	=> $row['accounts_details_voucher_posting_date'],
					'accounts_details_voucher_posting_month' 	=> $row['accounts_details_voucher_posting_month'],
					'accounts_details_voucher_posting_year' 	=> $row['accounts_details_voucher_posting_year'],
					'accounts_details_voucher_type' 			=> $row['accounts_details_voucher_type'],
					'accounts_details_voucher_type_code' 		=> $row['accounts_details_voucher_type_code'],
					'accounts_details_voucher_type_name' 		=> $row['accounts_details_voucher_type_name'],
					'accounts_details_voucher_number' 			=> $pv_accounts_voucher_number,
					'accounts_details_narration' 				=> $row['accounts_details_narration'],
					'accounts_details_accounts_type' 			=> $accounts_details_accounts_type,
					'accounts_details_accounts_category' 		=> $accounts_details_accounts_category,
					'accounts_details_control_group' 			=> $accounts_details_control_group,
					'accounts_details_general_ledger' 			=> $accounts_details_general_ledger,
					'accounts_details_subsidiary_ledger' 		=> $row['accounts_details_subsidiary_ledger'],
					'accounts_details_debit' 					=> $row['accounts_details_debit'],
					'accounts_details_credit' 					=> $row['accounts_details_credit'],
					'accounts_details_status' 					=> 1,
					'accounts_details_create_date' 				=> date('Y-m-d H:i:s'),
					'accounts_details_create_by' 				=> 0,
					'accounts_details_update_by' 				=> 0,
				);
				$this->db->insert('accounts_details', $pv_details_data);
			}
		    }
			
			if($rv_cb_accounts_data['accounts_total_credit'] > 0){
				$rv_cb_accounts_v_number =  $this->db->select("COUNT(accounts_id) as voucher_number")
				->from('accounts')
				->where('accounts_voucher_posting_date BETWEEN "' . $start_financial_year . '" and "' . $end_financial_year . '"')
				->where('accounts_voucher_type', $rv_cb_accounts_data['accounts_voucher_type'])
				->get()
				->row();
				$rv_cb_voucher_number = str_pad($rv_cb_accounts_v_number->voucher_number + 1, 4, '0', STR_PAD_LEFT);
				$rv_cb_accounts_voucher_number = $rv_cb_accounts_data['accounts_voucher_type_code'].'-'.$rv_cb_voucher_number;
				
				$rv_cb_data = array(
					'accounts_project' 						=> $rv_cb_accounts_data['accounts_project'],
					'accounts_voucher_posting_date' 		=> $rv_cb_accounts_data['accounts_voucher_posting_date'],
					'accounts_voucher_posting_month' 		=> $rv_cb_accounts_data['accounts_voucher_posting_month'],
					'accounts_voucher_posting_year' 		=> $rv_cb_accounts_data['accounts_voucher_posting_year'],
					'accounts_voucher_type' 				=> $rv_cb_accounts_data['accounts_voucher_type'],
					'accounts_voucher_type_code' 			=> $rv_cb_accounts_data['accounts_voucher_type_code'],
					'accounts_voucher_type_name' 			=> $rv_cb_accounts_data['accounts_voucher_type_name'],
					'accounts_voucher_number' 				=> $rv_cb_accounts_voucher_number,
					'accounts_narration' 					=> $rv_cb_accounts_data['accounts_narration'],
					'accounts_total_debit' 					=> $rv_cb_accounts_data['accounts_total_debit'],
					'accounts_total_credit' 				=> $rv_cb_accounts_data['accounts_total_credit'],
					'accounts_voucher_posting_status' 		=> 'Auto',
					'accounts_status' 						=> 1,
					'accounts_create_date' 					=> date('Y-m-d H:i:s'),
					'accounts_create_by' 					=> 0,
					'accounts_update_by' 					=> 0,
				);
				$this->accounts_model->voucher_posting_accounts_create($rv_cb_data);
				
				$rv_cb_accounts_id = $this->db->insert_id();
				foreach($rv_cb_accounts_details_data as $row){
					
					$invest_payment_type = $this->input->post('invest_payment_type');
					if($invest_payment_type == 'Bank') {
					$accounts_details_subsidiary_ledger = $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'Bank'),'chart_of_accounts_id');
					} else {
					$accounts_details_subsidiary_ledger = $row['accounts_details_subsidiary_ledger'];	
					}
					
					$accounts_details_general_ledger = $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_accounts_category',array('chart_of_accounts_id'=>$accounts_details_subsidiary_ledger),'chart_of_accounts_accounts_category');
					
					$accounts_details_control_group = $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_accounts_category',array('chart_of_accounts_id'=>$accounts_details_general_ledger),'chart_of_accounts_accounts_category');
					
					$accounts_details_accounts_category = $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_accounts_category',array('chart_of_accounts_id'=>$accounts_details_control_group),'chart_of_accounts_accounts_category');
					
					$accounts_details_accounts_type = $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_accounts_category',array('chart_of_accounts_id'=>$accounts_details_accounts_category),'chart_of_accounts_accounts_category');
					
					$rv_cb_details_data = array(
						'accounts_details_accounts_id' 				=> $rv_cb_accounts_id,
						'accounts_details_project' 					=> $row['accounts_details_project'],
						'accounts_details_voucher_posting_date' 	=> $row['accounts_details_voucher_posting_date'],
						'accounts_details_voucher_posting_month' 	=> $row['accounts_details_voucher_posting_month'],
						'accounts_details_voucher_posting_year' 	=> $row['accounts_details_voucher_posting_year'],
						'accounts_details_voucher_type' 			=> $row['accounts_details_voucher_type'],
						'accounts_details_voucher_type_code' 		=> $row['accounts_details_voucher_type_code'],
						'accounts_details_voucher_type_name' 		=> $row['accounts_details_voucher_type_name'],
						'accounts_details_voucher_number' 			=> $rv_cb_accounts_voucher_number,
						'accounts_details_narration' 				=> $row['accounts_details_narration'],
						'accounts_details_accounts_type' 			=> $accounts_details_accounts_type,
						'accounts_details_accounts_category' 		=> $accounts_details_accounts_category,
						'accounts_details_control_group' 			=> $accounts_details_control_group,
						'accounts_details_general_ledger' 			=> $accounts_details_general_ledger,
						'accounts_details_subsidiary_ledger' 		=> $accounts_details_subsidiary_ledger,
						'accounts_details_debit' 					=> $row['accounts_details_debit'],
						'accounts_details_credit' 					=> $row['accounts_details_credit'],
						'accounts_details_status' 					=> 1,
						'accounts_details_create_date' 				=> date('Y-m-d H:i:s'),
						'accounts_details_create_by' 				=> 0,
						'accounts_details_update_by' 				=> 0,
					);
					$this->db->insert('accounts_details', $rv_cb_details_data);
				}
			}
			echo 'You Have Successfully Day Close';
		} else {
			echo 'Error! You Allready Day Close';
		}
		}
	}
}
