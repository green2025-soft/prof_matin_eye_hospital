<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Test_category extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Test Category';
            $data['page_title'] = 'Test Category';
            $data['info_header'] = 'All Test Category';
            $data['values'] = $this->Common_model->findAll('test_category',array(),'test_category','asc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_category/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            unset($input['update_id']);
            $test_category = $input['test_category'];
            if($update_id == 0 || empty($update_id)){       
                $getRow = $this->Common_model->findById('test_category',array('test_category'=>$test_category));
                if(isset($getRow)){
                    $this->session->set_flashdata('message', EXIST_MSG);
                    redirect('test_category', 'refresh');
                }
                $insert = $this->Common_model->saveData('test_category', $input);
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $update = $this->Common_model->updateData('test_category', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            redirect('test_category', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $id, 'test_category')){
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
           // redirect("crud/previousPage");
            redirect('test_category', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
