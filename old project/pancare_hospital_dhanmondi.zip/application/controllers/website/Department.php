<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Department extends CI_Controller
{
    public function __construct() {
        parent::__construct();
        $this->load->helper('text');
    }
    public function index()
    {
        $type = $this->session->userdata('__selected_center__');
        $data['title'] = "Our Department";
        $data['active'] = 'Department';
        $output['page_title'] = "Our Department";
        $output['values'] = $this->Common_model->findAll('department',array('published'=>'Yes', 'types'=>$type ),'record_id','asc');
        $data['content'] = $this->load->view('website/department/index',$output,TRUE);
        $this->load->view("website/layouts/master",$data);
    }
}
