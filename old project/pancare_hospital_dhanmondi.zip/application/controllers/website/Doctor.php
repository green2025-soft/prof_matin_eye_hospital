<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Doctor extends CI_Controller
{
    public function __construct() {
        parent::__construct();
        $this->load->helper('text');
    }
    public function index()
    {
        $pramType = $this->input->get('type');
        if($pramType){
            if (in_array($pramType, ['general', 'ivf'])) {
                $this->session->set_userdata('__selected_center__', $pramType);
            }
        }
        
        $type = $this->session->userdata('__selected_center__');
        
        $data['title'] = "Our Doctors";
        $data['active'] = 'Doctor';
        $output['type'] = $type;
        $output['page_title'] = "Our Doctors";
        $output['values'] = $this->Common_model->findAllGroupBy('doctor',array('department != '=>'', 'types' =>  $type),'department','record_id','asc');
        
        //var_dump($output['values']) ; die;

        $data['content'] = $this->load->view('website/doctor/index',$output,TRUE);
        $this->load->view("website/layouts/master",$data);
    }
    public function general()
    {
        $data['title'] = "Our General Doctors";
        $data['active'] = 'Doctor';
        $output['page_title'] = "Our General Doctors";
        $output['values'] = $this->Common_model->findAllGroupBy('doctor',array('department != '=>'', 'types' => 'general'),'department','record_id','asc');
        //var_dump($output['values']) ; die;
        $data['content'] = $this->load->view('website/doctor/index',$output,TRUE);
        $this->load->view("website/layouts/master",$data);
    }

    public function ivf()
    {
        $data['title'] = "Our IVF Doctors";
        $data['active'] = 'Doctor';
        $output['page_title'] = "Our IVF Doctors";
        $output['values'] = $this->Common_model->findAllGroupBy('doctor',array('department != '=>'', 'types' => 'ivf'),'department','record_id','asc');
        //var_dump($output['values']) ; die;
        $data['content'] = $this->load->view('website/doctor/index',$output,TRUE);
        $this->load->view("website/layouts/master",$data);
    }
}
