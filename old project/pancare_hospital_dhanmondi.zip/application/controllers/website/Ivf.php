<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Ivf extends CI_Controller
{
    public function __construct() {
        parent::__construct();
    }
    public function index()
    {
        $data['title'] = "IVF";
        $data['active'] = 'IVF';
        $output['page_title'] = "IVF";
        $output['services'] = $this->Common_model->findAll('services',['is_ivf' => 'Yes'],'record_id','asc');
        $data['content'] = $this->load->view('website/ivf/index',$output,TRUE);
        $this->load->view("website/layouts/master",$data);
    }
    public function details($record_id)
    {
        $data['title'] = "IVF Details";
        $data['active'] = 'IVF';
        $output['page_title'] = "IVF Details";
        $output['value'] = $this->Common_model->findById('services',array('record_id'=>$record_id));
        $data['content'] = $this->load->view('website/ivf/details',$output,TRUE);
        $this->load->view("website/layouts/master",$data);
    }
}
