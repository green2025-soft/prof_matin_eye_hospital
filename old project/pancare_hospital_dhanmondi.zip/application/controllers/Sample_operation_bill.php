<?php

/**
 * 
 */
class Sample_operation_bill extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
	}
	public function index()
	{
		$data['title'] = "IPD Bill Preview List";
		$data['page_title'] = "IPD Bill Preview List";
		$data['info_header'] = "";


		$from_date = $this->input->get('from_date');
		$to_date = $this->input->get('to_date');
		$doctor_id = $this->input->get('doctor_id');
		$operation_id = $this->input->get('operation_id');
		$reference_by = $this->input->get('reference_by');

		if (!isset($from_date) && !isset($to_date) && !isset($doctor_id) && !isset($test_id) && !isset($reference_by)) {
			$from_date = $to_date = date('Y-m-d');
		}

		$where = array();
		if (!admin()) {
			$where['sample_operation_details.show_hide'] = 'Show';
		}
		if ($doctor_id) $where['doctor_id'] = $doctor_id;
		if ($operation_id) $where['operation_id'] = $operation_id;
		if ($reference_by) $where['reference_by'] = $reference_by;
		if (!empty($from_date) && !empty($to_date)) {
			$where['operation_date >= '] = $from_date;
			$where['operation_date <= '] = $to_date;
		} elseif (!empty($from_date) && empty($to_date)) {
			$where['operation_date'] = $from_date;
		} elseif (empty($from_date) && !empty($to_date)) {
			$where['operation_date'] = $to_date;
		}

		$data['from_date'] = $from_date;
		$data['to_date'] = $to_date;
		$data['doctor_id'] = $doctor_id;
		$data['operation_id'] = $operation_id;
		$data['reference_by'] = $reference_by;

		$options = array(
			'joins' => array(
				array(
					'table' => 'patient',
					'condition' => 'patient.record_id = sample_operation_details.patient_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor sergeon',
					'condition' => 'sergeon.record_id = sample_operation_details.doctor_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor anesthesia',
					'condition' => 'anesthesia.record_id = sample_operation_details.anesthesia_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation sergeon_designation',
					'condition' => 'sergeon_designation.record_id = sergeon.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation anesthesia_designation',
					'condition' => 'anesthesia_designation.record_id = anesthesia.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_category',
					'condition' => 'operation_category.record_id = sample_operation_details.category_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_name',
					'condition' => 'operation_name.record_id = sample_operation_details.operation_id',
					'jointype' => 'LEFT'
				), array(
					'table' => 'beds',
					'condition' => 'beds.record_id = sample_operation_details.bed_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'reference_by',
					'condition' => 'reference_by.record_id = sample_operation_details.reference_by',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'admission_fee_invoice',
					'condition' => 'admission_fee_invoice.record_id = sample_operation_details.admission_id',
					'jointype' => 'LEFT'
				),
			),
			'select' => 'sample_operation_details.*,sample_operation_details.created_by as user_by,sample_operation_details.record_id as sample_operation_details_id,sample_operation_details.advance_amount as adv_amount,patient.*,patient.record_id as patient_id,sergeon.record_id as sergeon_id,sergeon.name as sergeon_name,sergeon_designation.designation as sergeon_designation,anesthesia.record_id as anesthesia_id,anesthesia.name as anesthesia_name,anesthesia_designation.designation as anesthesia_designation,operation_category.record_id as operation_category_id,operation_category.category_name,operation_name.record_id as operation_name_id,operation_name.operation_name,beds.*,reference_by.reference_name,reference_by.record_id as reference_id, admission_fee_invoice.admission_no',
			'where' => $where,
			'order' => array(
				'sample_operation_details.record_id' => 'desc',
			),
		);
		$data['values'] = $this->Common_model->commonJoins("sample_operation_details", $options);
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/sample_operation_bill/index', $data);
		$this->load->view('admin/layouts/footer');
	}

	public function create()
	{
		$data['title'] = "IPD Bill Preview";
		$data['page_title'] = "IPD Bill Preview";
		$data['info_header'] = "";
		$admission_invoices = $this->Common_model->findAll('admission_fee_invoice', array('patient_status' => 'Admitted'), 'record_id', 'asc');
		$data['beds'] = $this->Common_model->findAll('beds', array(), 'record_id', 'desc');
		$patient_ids = array();
		foreach ($admission_invoices as $key1 => $value1) {
			$patient_ids[] = $value1->patient_id;
		}
		$data['patient_list'] = $this->Common_model->findAllWhereIn('patient', array(), $patient_ids, 'record_id', 'record_id', 'asc');
		$where = array() ;
		$where['patient_status'] = 'Admitted' ;
		$data['admissionInvoice'] = $this->Common_model->findAll("admission_fee_invoice",$where,"record_id","desc");
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/sample_operation_bill/create', $data);
		$this->load->view('admin/layouts/footer');
	}


	public function edit($record_id)
	{
		$data['title'] = "Edit IPD Bill Preview";
		$data['page_title'] = "Edit IPD Bill Preview";
		$data['info_header'] = "";
		$admission_invoices = $this->Common_model->findAll('admission_fee_invoice', array('patient_status' => 'Admitted'), 'record_id', 'asc');
		foreach ($admission_invoices as $key1 => $value1) {
			$patient_ids[] = $value1->patient_id;
		}
		$data['patient_list'] = $this->Common_model->findAllWhereIn('patient', array(), $patient_ids, 'record_id', 'record_id', 'asc');
		$data['value'] = $this->Common_model->findById('sample_operation_details', array('record_id' => $record_id));
		$where = array() ;
		$where['record_id'] = $data['value']->admission_id ;
		$data['admissionInvoice'] = $this->Common_model->findAll("admission_fee_invoice",$where,"record_id","desc");
		//var_dump($data['value']);die;
		$data['bed'] = $this->Common_model->findById('beds', array('record_id' => $data['value']->bed_id));
		$data['beds'] = $this->Common_model->findAll('beds', array('record_id' => $data['value']->bed_id), 'record_id', 'asc');
		//var_dump($data['beds']);die;
		$data['operation_names'] = $this->Common_model->findAll('operation_name', array('category_id' => $data['value']->category_id), 'operation_name', 'asc');
		//var_dump($data['operation_names']);die;
		$data['patient'] = $this->Common_model->findById('patient', array('record_id' => $data['value']->patient_id));

		$data['expenditures'] = $this->Common_model->findAll('sample_operation_equipment', array('sample_operation_details_id' => $record_id), 'record_id', 'asc');
		//	var_dump($data['expenditures']);die;
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/sample_operation_bill/create', $data);
		$this->load->view('admin/layouts/footer');
	}

	public function view($record_id)
	{
		$data['title'] = "Edit IPD Details";
		$data['page_title'] = "Edit IPD Details";
		$data['info_header'] = "";
		$data['equipments'] = $this->Common_model->findAll('sample_operation_equipment', array('sample_operation_details_id' => $record_id), 'record_id', 'asc');
		$where = array('sample_operation_details.record_id' => $record_id);
		$options = array(
			'joins' => array(
				array(
					'table' => 'patient',
					'condition' => 'patient.record_id = sample_operation_details.patient_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor sergeon',
					'condition' => 'sergeon.record_id = sample_operation_details.doctor_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor anesthesia',
					'condition' => 'anesthesia.record_id = sample_operation_details.anesthesia_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_category',
					'condition' => 'operation_category.record_id = sample_operation_details.category_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation sergeon_designation',
					'condition' => 'sergeon_designation.record_id = sergeon.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation anesthesia_designation',
					'condition' => 'anesthesia_designation.record_id = anesthesia.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_name',
					'condition' => 'operation_name.record_id = sample_operation_details.operation_id',
					'jointype' => 'LEFT'
				), array(
					'table' => 'beds',
					'condition' => 'beds.record_id = sample_operation_details.bed_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'admission_fee_invoice',
					'condition' => 'admission_fee_invoice.record_id = sample_operation_details.admission_id',
					'jointype' => 'LEFT'
				),
			),
			'select' => 'sample_operation_details.*,sample_operation_details.created_by as user_by,sample_operation_details.created_at as op_created_at,sample_operation_details.record_id as sample_operation_details_id,sample_operation_details.advance_amount as adv_amount,patient.*,patient.record_id as patient_id,sergeon.record_id as sergeon_id,sergeon.name as sergeon_name,sergeon_designation.designation as sergeon_designation,anesthesia.record_id as anesthesia_id,anesthesia.name as anesthesia_name,anesthesia_designation.designation as anesthesia_designation,operation_category.record_id as operation_category_id,operation_category.category_name,operation_name.record_id as operation_name_id,operation_name.operation_name,beds.*, admission_fee_invoice.admission_no',
			'where' => $where,
			'order' => array(
				'sample_operation_details.record_id' => 'desc',
			),
		);
		$data['value'] = $this->Common_model->commonJoinsRow("sample_operation_details", $options);
		$data['value']->date = $data['value']->operation_date;
		$data['value']->created_by = $data['value']->user_by;

		$data['bill'] = $this->Common_model->findById('create_bill', array('record_id' => $data['value']->invoice_id));
		$data['signatureType'] = 'Patient';
		$data['redirect'] = base_url('operation_bill/create');

		$this->load->view('admin/layouts/header');
		$this->load->view('admin/sample_operation_bill/view', $data);
		$this->load->view('admin/layouts/footer');
	}

	public function view2($record_id)
	{
		$data['title'] = "Edit IPD Details";
		$data['page_title'] = "Edit IPD Details";
		$data['info_header'] = "";
		$data['equipments'] = $this->Common_model->findAll('sample_operation_equipment', array('sample_operation_details_id' => $record_id), 'record_id', 'asc');
		$where = array('sample_operation_details.record_id' => $record_id);
		$options = array(
			'joins' => array(
				array(
					'table' => 'patient',
					'condition' => 'patient.record_id = sample_operation_details.patient_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor sergeon',
					'condition' => 'sergeon.record_id = sample_operation_details.doctor_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor anesthesia',
					'condition' => 'anesthesia.record_id = sample_operation_details.anesthesia_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation sergeon_designation',
					'condition' => 'sergeon_designation.record_id = sergeon.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation anesthesia_designation',
					'condition' => 'anesthesia_designation.record_id = anesthesia.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_category',
					'condition' => 'operation_category.record_id = sample_operation_details.category_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_name',
					'condition' => 'operation_name.record_id = sample_operation_details.operation_id',
					'jointype' => 'LEFT'
				), array(
					'table' => 'beds',
					'condition' => 'beds.record_id = sample_operation_details.bed_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'admission_fee_invoice',
					'condition' => 'admission_fee_invoice.record_id = sample_operation_details.admission_id',
					'jointype' => 'LEFT'
				),
			),
			'select' => 'sample_operation_details.*,sample_operation_details.created_by as user_by,sample_operation_details.created_at as op_created_at,sample_operation_details.record_id as sample_operation_details_id,sample_operation_details.advance_amount as adv_amount,patient.*,patient.record_id as patient_id,sergeon.record_id as sergeon_id,sergeon.name as sergeon_name,sergeon_designation.designation as sergeon_designation,anesthesia.record_id as anesthesia_id,anesthesia.name as anesthesia_name,anesthesia_designation.designation as anesthesia_designation,operation_category.record_id as operation_category_id,operation_category.category_name,operation_name.record_id as operation_name_id,operation_name.operation_name,beds.*, admission_fee_invoice.admission_no',
			'where' => $where,
			'order' => array(
				'sample_operation_details.record_id' => 'desc',
			),
		);
		$data['value'] = $this->Common_model->commonJoinsRow("sample_operation_details", $options);
		$data['value']->date = $data['value']->operation_date;
		$data['value']->created_by = $data['value']->user_by;

		$data['bill'] = $this->Common_model->findById('create_bill', array('record_id' => $data['value']->invoice_id));
		$data['signatureType'] = 'Patient';
		$data['redirect'] = base_url('operation_bill');

		$this->load->view('admin/layouts/header');
		$this->load->view('admin/sample_operation_bill/view', $data);
		$this->load->view('admin/layouts/footer');
	}
	public function get_admissiom_invoice()
	{
		$admission_id = $this->input->post('admission_id');
		$where = array('record_id' => $admission_id);
		$admission_invoice = $this->Common_model->findById('admission_fee_invoice', $where);
		$patient = $this->Common_model->findById('patient', array('record_id' => $admission_invoice->patient_id));
		$patient_name = isset($patient) ? $patient->name : '';
		$admission_invoice->patient_name = $patient_name;

		$advance_amount = $this->Common_model->calCulateSum("admission_advance_invoice", array("admission_id" => $admission_id), "advance_amount");
		$advance_amount = isset($advance_amount) ? $advance_amount : 0;

		$admission_invoice->advance_amount += $advance_amount;

		$where = array();
		$where['type'] = 'Test Invoice';
		$where['admission_id'] = $admission_id;
		$test_invoice = $this->Common_model->calCulateSum('create_bill', $where, 'sub_total');
		$test_invoice = isset($test_invoice) ? $test_invoice : 0;
		$admission_invoice->test_invoice = $test_invoice;

		$indoor_expeniture = $this->Common_model->findAll("operation_expenditure_details", array("admission_id" => $admission_id), "record_id", "asc");
		//$admission_invoice->indoor_expenditure = $indoor_expeniture ;
		$html = '';
		$tr = '';
		foreach ($indoor_expeniture as $key => $value) {
			$expenditure = $this->Common_model->findById("expenditure", array("record_id" => $value->expenditure_id));
			$expenditure_title = isset($expenditure) ? $expenditure->expenditure_title : "";
			$expenditure_id = $value->expenditure_id;
			$expenditure_rate = $value->expenditure_rate;
			$no_of_qty = $value->no_of_qty;
			$total_amount = $value->total_amount;
			$html = '<input type="hidden" name="expenditure_id[]" value="' . $expenditure_id . '">';
			$html .= '<input type="hidden" name="expenditure_price[]" value="' . $expenditure_rate . '">';
			$html .= '<input type="hidden" name="no_of_qty[]" value="' . $no_of_qty . '">';
			$html .= '<input type="hidden" name="total_amount[]" value="' . $total_amount . '">';
			$editRow = '<a href="javascript:void(0)" class="btn btn-primary btn-xs editRow"><span class="fa fa-pencil"></span></a>';
			$deleteRow = '<a href="javascript:void(0)" class="btn btn-danger btn-xs deleteRow"><span class="fa fa-trash-o"></span></a>';
			$tr .= '<tr>';
			$tr .= '<td class="hide">' . $html . '</td>';
			$tr .= '<td class="serial"></td>';
			$tr .= '<td>' . $expenditure_title . '</td>';
			$tr .= '<td class="text-right expenditure_price">' . $expenditure_rate . '</td>';
			$tr .= '<td class="text-right no_of_qty">' . $no_of_qty . '</td>';
			$tr .= '<td class="text-right total_amount">' . $total_amount . '</td>';
			$tr .= '<td class="text-center">' . $editRow . ' ' . $deleteRow . '</td>';
			$tr .= '</tr>';
		}
		$admission_invoice->tr = $tr;
		echo json_encode($admission_invoice);
		exit;
	}

	public function get_admissiom()
	{
		$admission_id = $this->input->post('admission_id');
		$where = array('operation_invoice.admission_id' => $admission_id);
		$options = array(
			'joins' => array(
				array(
					'table' => 'patient',
					'condition' => 'patient.record_id = operation_invoice.patient_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor sergeon',
					'condition' => 'sergeon.record_id = operation_invoice.sergeon_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor anesthesia',
					'condition' => 'anesthesia.record_id = operation_invoice.anesthesia_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_category',
					'condition' => 'operation_category.record_id = operation_invoice.operation_category_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation sergeon_designation',
					'condition' => 'sergeon_designation.record_id = sergeon.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation anesthesia_designation',
					'condition' => 'anesthesia_designation.record_id = anesthesia.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_name',
					'condition' => 'operation_name.record_id = operation_invoice.operation_name_id',
					'jointype' => 'LEFT'
				), array(
					'table' => 'beds',
					'condition' => 'beds.record_id = operation_invoice.bed_id',
					'jointype' => 'LEFT'
				),
			),
			'select' => 'operation_invoice.*,operation_invoice.record_id as operation_invoice_record_id,patient.*,patient.record_id as patient_id,patient.name as patient_name,sergeon.name as sergeon_name,sergeon_designation.designation as sergeon_designation,anesthesia.name as anesthesia_name,anesthesia_designation.designation as anesthesia_designation,operation_category.record_id as operation_category_id,operation_category.category_name,operation_name.record_id as operation_name_id,operation_name.operation_name,beds.*',
			'where' => $where,
			'order' => array(
				'operation_invoice.record_id' => 'desc',
			),
		);
		$admission = $this->Common_model->commonJoinsRow("operation_invoice", $options);

		$advance_amount1 = $this->Common_model->calCulateSum("admission_advance_invoice", array("admission_id" => $admission_id), "advance_amount");
		$advance_amount1 = isset($advance_amount1) ? $advance_amount1 : 0;


		$advance_amount2 = $this->Common_model->calCulateSum('admission_fee_invoice', array('record_id' => $admission->admission_id), 'advance_amount');
		$admission->advance_amount = $advance_amount1 + $advance_amount2;

		$invoice_ids = $this->Common_model->Columns('create_bill', array('admission_id' => $admission_id), 'record_id');
		if (!count($invoice_ids)) {
			$invoice_ids = array(-1);
		}
		$collection = $this->Common_model->calCulateSum('due_collection_details', array(), 'current_collection', $invoice_ids, 'invoice_id');
		$collection = isset($collection) ? $collection : 0;

		$medicine_cost = $this->Common_model->calCulateSumMultiple('create_bill', array('admission_id' => $admission->patient_id, 'admission_id' => $admission_id), array('sub_total', 'paid'));
		$sub_total = isset($medicine_cost) ? $medicine_cost->sub_total : 0;
		$paid_amount = isset($medicine_cost) ? $medicine_cost->paid : 0;
		$total_paid_amount = $paid_amount + $collection;
		$admission->medicine_cost = $sub_total - $total_paid_amount;

		$indoor_expeniture = $this->Common_model->findAll("operation_expenditure_details", array("admission_id" => $admission_id), "record_id", "asc");
		//$admission_invoice->indoor_expenditure = $indoor_expeniture ;
		$html = '';
		$tr = '';
		$total_expenditure_price = 0;
		foreach ($indoor_expeniture as $key => $value) {
			$expenditure = $this->Common_model->findById("expenditure", array("record_id" => $value->expenditure_id));
			$expenditure_title = isset($expenditure) ? $expenditure->expenditure_title : "";
			$expenditure_id = $value->expenditure_id;
			$expenditure_rate = $value->expenditure_rate;
			$no_of_qty = $value->no_of_qty;
			$total_amount = $value->total_amount;
			$total_expenditure_price += $total_amount;
			$html = '<input type="hidden" name="expenditure_id[]" value="' . $expenditure_id . '">';
			$html .= '<input type="hidden" name="expenditure_price[]" value="' . $expenditure_rate . '">';
			$html .= '<input type="hidden" name="no_of_qty[]" value="' . $no_of_qty . '">';
			$html .= '<input type="hidden" name="total_amounts[]" value="' . $total_amount . '">';
			$editRow = '<a href="javascript:void(0)" class="btn btn-primary btn-xs editRow"><span class="fa fa-pencil"></span></a>';
			$deleteRow = '<a href="javascript:void(0)" class="btn btn-danger btn-xs deleteRow"><span class="fa fa-trash-o"></span></a>';
			$tr .= '<tr>';
			$tr .= '<td class="hide">' . $html . '</td>';
			$tr .= '<td class="serial"></td>';
			$tr .= '<td>' . $expenditure_title . '</td>';
			$tr .= '<td class="text-right">' . $expenditure_rate . '</td>';
			$tr .= '<td class="text-right no_of_qty">' . $no_of_qty . '</td>';
			$tr .= '<td class="text-right expenditure_price total_amount">' . $total_amount . '</td>';
			$tr .= '<td class="text-center">' . $editRow . ' ' . $deleteRow . '</td>';
			$tr .= '</tr>';
		}
		$admission->tr = $tr;

		$current_date = date('Y-m-d');
		$admission_date = $admission->admission_date;
		if(isset($admission_date)){
			if(!empty($admission_date)){
				$no_of_day = dayDuration($admission_date, $current_date);
			}else{
				$no_of_day = 0 ;
			}
		}else{
			$no_of_day = 0 ;
		}
		
		$charge = $admission->charge;
		$bed_charge = $no_of_day * $charge;

		$admission->no_of_day = $no_of_day;
		$admission->bed_charge = $bed_charge;
		$admission->total_expenditure_price = $total_expenditure_price;
		$admission->invoice_amount = $admission->medicine_cost + $bed_charge +  $total_expenditure_price + $admission->operation_price;

		echo json_encode($admission);
		exit;
	}

	public function getOperationName()
	{
		$category_id = $this->input->post('category_id');
		$names = $this->Common_model->get_all_info_by_array('operation_name', ['category_id' => $category_id]);
		$data = "<option value=''>-- Select --</option>";
		foreach ($names as $name) {
			$data .= "<option value='$name->record_id'>$name->operation_name</option>";
		}
		echo json_encode($data);
	}

	public function saveOrUpdate()
	{
		$input = $_POST;
		//var_dump($input);die;
		$update_id = $input['update_id'];
		$operation_date = $input['operation_date'];
		$expenditure_ids = array();
		$expenditure_prices = array();
		$no_of_qtys = array();
		$total_amounts = array();
		if (array_key_exists('expenditure_id', $input)) {
			$expenditure_ids = $input['expenditure_id'];
			$expenditure_prices = $input['expenditure_price'];
			$no_of_qtys = $input['no_of_qty'];
			$total_amounts = $input['total_amounts'];
			unset($input['expenditure_id']);
			unset($input['expenditure_price']);
			unset($input['no_of_qty']);
			unset($input['total_amounts']);
			unset($input['exp_total']);
		}
		unset($input['update_id']);

		$prefix = 'Ope' . date("Ymd", strtotime($operation_date));
		$maxInvoice = $this->Common_model->findMax('create_bill', array('prefix' => $prefix, 'type' => 'Operation'), 'invoice_no');
		$invoice_no = isset($maxInvoice) ? $maxInvoice->invoice_no + 1 : 1;

		$paid = $input['paid_amount'];
		$medicine_cost = $input['medicine_cost'];
		/*if($paid > $medicine_cost){
			$paid = $paid - $medicine_cost ;
		}*/

		$invoice_data = array(
			'date' => $operation_date,
			'prefix' => $prefix,
			'invoice_no' => $invoice_no,
			'type' => 'Operation',
			'particular' => "Operation Details Information",
			'patient_id' => $input['patient_id'],
			'amount' => $input['payable_amount'],
			'discount_type' => $input['discount_type'],
			'discount' => $input['discount'],
			'sub_total' => $input['sub_total'],
			'paid' => $paid,
			'medicine_cost' => $input['medicine_cost'],
			'due' => $input['due_amount'],
			'advance' => $input['advance_amount'],
			'return_amount' => $input['return_amount'],
			'reference_by' => $input['reference_by'],
			//'reference_by_commission_percentage' => $input['reference_by_commission_percentage'],
			//'reference_by_commission' => $input['reference_by_commission'],
		);

		if ($update_id == 0 || empty($update_id)) {
			//$invoice_id = $this->Common_model->saveData('create_bill', $invoice_data);
			//$input['invoice_id'] = $invoice_id;
			$sample_operation_details_id = $this->Common_model->saveData('sample_operation_details', $input);
			$update_id = $sample_operation_details_id;
			//$this->Common_model->updateData('admission_fee_invoice', array('patient_status' => 'Release'), array('record_id' => $input['admission_id']));
			//$operationInvoice = $this->Common_model->findById('operation_invoice',array('admission_id'=>$input['admission_id'])) ;
			//$this->Common_model->updateData('beds', array('bed_status'=>'Vacant'), array('record_id'=>$operationInvoice->bed_id));

			
			foreach ($expenditure_ids as $key => $value) {
				$ex = array(
					'sample_operation_details_id' => $sample_operation_details_id,
					'admission_id' => $input['admission_id'],
					'patient_id' => $input['patient_id'],
					'expenditure_id' => $expenditure_ids[$key],
					'expenditure_price' => $expenditure_prices[$key],
					'no_of_qty' => $no_of_qtys[$key],
					'total_amount' => $total_amounts[$key],
				);
				$this->Common_model->saveData('sample_operation_equipment', $ex);
			}
			$this->session->set_flashdata('message', INSERT_MSG);
		} else {
			$sample_operation_details = $this->Common_model->findById('sample_operation_details', array('record_id' => $update_id));
			if ($sample_operation_details->operation_date == $operation_date) {
				//$bill = $this->Common_model->findById('create_bill', array('record_id' => $sample_operation_details->invoice_id));
				//$invoice_data['invoice_no'] = $bill->invoice_no;
			}

			//$this->Common_model->updateData('create_bill', $invoice_data, array('record_id' => $sample_operation_details->invoice_id));
			$this->Common_model->updateData('sample_operation_details', $input, array('record_id' => $update_id));
			$this->Common_model->delete_info('sample_operation_details_id', $update_id, 'sample_operation_equipment');
			foreach ($expenditure_ids as $key => $value) {
				$ex = array(
					'sample_operation_details_id' => $update_id,
					'expenditure_id' => $expenditure_ids[$key],
					'expenditure_price' => $expenditure_prices[$key],
					'no_of_qty' => $no_of_qtys[$key],
					'total_amount' => $total_amounts[$key],
				);
				$this->Common_model->saveData('sample_operation_equipment', $ex);
			}
			$this->session->set_flashdata('message', UPDATE_MSG);
		}

		redirect("sample_operation_bill/view/$update_id");
	}
	public function delete($id)
	{
		$user_type = $this->session->ses_user_type;
		if ($user_type == "admin"  || $user_type == "staff") {
			$sample_operation_details = $this->Common_model->findById('sample_operation_details', array('record_id' => $id));
			if ($this->Common_model->delete_info('record_id', $id, 'sample_operation_details')) {
				//$this->Common_model->delete_info('record_id', $sample_operation_details->invoice_id, 'create_bill');
				$this->Common_model->delete_info('sample_operation_details_id', $id, 'sample_operation_equipment');
				//$this->Common_model->updateData('admission_fee_invoice', array('patient_status' => 'Admitted'), array('record_id' => $sample_operation_details->admission_id));
				//$operationInvoice = $this->Common_model->findById('operation_invoice',array('admission_id'=>$sample_operation_details->admission_id)) ;
			//$this->Common_model->updateData('beds', array('bed_status'=>'Booked'), array('record_id'=>$operationInvoice->bed_id));
				$this->session->set_flashdata('message', DELETE_MSG);
			} else {
				$this->session->set_flashdata('message', DELETE_ERROR_MSG);
			}
			redirect('sample_operation_bill', 'refresh');
		} else {
			$data['wrong_msg'] = "";
			$this->load->view('website/login_check', $data);
		}
	}


	
	
	public function reference_payment()
	{
		$data['title'] = "Reference Payment (R.F)";
		$data['page_title'] = "Reference Payment (R.F)";
		$data['info_header'] = "";
		$where = array() ;
		if (!admin()) {
			$where['sample_operation_details.show_hide'] = 'Show';
		}
		$data['bill_list'] = $this->Common_model->findAll("sample_operation_details", $where, "record_id", "desc");
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/sample_operation_bill/reference_payment', $data);
		$this->load->view('admin/layouts/footer');
	}
	public function update_reference_payment()
	{
		$input = $_POST;
		$invoice_id = $input['invoice_id'];
		unset($input['invoice_id']);
		$operation = $this->Common_model->findById('sample_operation_details', array('record_id' => $invoice_id));
		$this->Common_model->updateData('sample_operation_details', $input, array('record_id' => $invoice_id));
		$invoiceData = array(
			'reference_by_commission_percentage' => $input['reference_by_commission_percentage'],
			'reference_by_commission' => $input['reference_by_payment']
		);
		$this->Common_model->updateData('create_bill', $invoiceData, array('record_id' => $operation->invoice_id));
		$this->session->set_flashdata('message', UPDATE_MSG);
		redirect('operation_bill/reference_payment');
	}
	public function get_operation_bill()
	{
		$invoice_id = $this->input->post('invoice_id');
		/*$operation = $this->Common_model->findById('sample_operation_details', array('invoice_id' => $invoice_id));
		echo json_encode($operation);
		exit;*/

		$where = array('sample_operation_details.record_id' => $invoice_id);
		$options = array(
			'joins' => array(
				array(
					'table' => 'admission_fee_invoice',
					'condition' => 'admission_fee_invoice.record_id = sample_operation_details.admission_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'patient',
					'condition' => 'patient.record_id = sample_operation_details.patient_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'reference_by',
					'condition' => 'reference_by.record_id = sample_operation_details.reference_by',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor sergeon',
					'condition' => 'sergeon.record_id = sample_operation_details.doctor_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor reference',
					'condition' => 'reference.record_id = sample_operation_details.reference_by',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor anesthesia',
					'condition' => 'anesthesia.record_id = sample_operation_details.anesthesia_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation sergeon_designation',
					'condition' => 'sergeon_designation.record_id = sergeon.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation anesthesia_designation',
					'condition' => 'anesthesia_designation.record_id = anesthesia.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_category',
					'condition' => 'operation_category.record_id = sample_operation_details.category_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_name',
					'condition' => 'operation_name.record_id = sample_operation_details.operation_id',
					'jointype' => 'LEFT'
				), array(
					'table' => 'beds',
					'condition' => 'beds.record_id = sample_operation_details.bed_id',
					'jointype' => 'LEFT'
				),
			),
			'select' => 'sample_operation_details.*,sample_operation_details.created_by as user_by,sample_operation_details.created_at as op_created_at,sample_operation_details.record_id as sample_operation_details_id,sample_operation_details.advance_amount as adv_amount,patient.*,patient.record_id as patient_id,sergeon.record_id as sergeon_id,sergeon.name as sergeon_name,sergeon_designation.designation as sergeon_designation,anesthesia.record_id as anesthesia_id,anesthesia.name as anesthesia_name,anesthesia_designation.designation as anesthesia_designation,operation_category.record_id as operation_category_id,operation_category.category_name,operation_name.record_id as operation_name_id,operation_name.operation_name,beds.*,patient.name as patient_name,admission_no,reference_prefix,reference_no,reference_name,reference.doctor_no,reference.doctor_prefix,reference.name as doctor_name, sample_operation_details.advance_amount as total_advance',
			'where' => $where,
			'order' => array(
				'sample_operation_details.record_id' => 'desc',
			),
		);
		$data = $this->Common_model->commonJoinsRow("sample_operation_details", $options);
		// ddd($data);
		$data->operation_patient = $data->patient_name . "[$data->patient_id]";
		$reference_name = "";
		if ($data->discount_type == 1 or $data->discount_type == 4) {
			$reference_name = $data->reference_prefix . $data->reference_no . " - " . $data->reference_name;
		} elseif ($data->discount_type == 2 or $data->discount_type == 5) {
			$reference_name = $data->doctor_prefix . $data->doctor_no . " - " . $data->doctor_name;
		} elseif ($data->discount_type == 3) {
			$reference_name = "Hospital";
		}
		$data->operation_reference = $reference_name;
		//$data->invoice_amount = $data->payable_amount + $data->adv_amount;
		$data->invoice_amount = $data->paid_amount;
		$data->sub_total = $data->paid_amount + $data->total_advance;
		echo json_encode($data);
		exit;
	}

	function checkReference($admissionId){

		$refExists = $this->db->select('reference_by')->from('operation_invoice')->where('admission_id', $admissionId)->get()->row();

		if(!empty($refExists)){
			echo $refExists->reference_by;
			return;
		}

		echo 0;

	}
}
