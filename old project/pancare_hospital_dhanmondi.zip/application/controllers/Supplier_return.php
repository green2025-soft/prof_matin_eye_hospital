<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Supplier_return extends CI_Controller {

  public function __construct() {
    parent::__construct();
    $this->load->model('Common_model');
    $this->load->library('user_agent');
  }
  public function index() {
    $user_type = $this->session->ses_user_type;
    if ($user_type == "admin" || $user_type == "staff") {
      $data['title'] = 'Return List';
      $data['page_title'] = 'Return List';
      $data['info_header'] = 'Return List';

      $where = [
        "status != "=>"Delete"
      ];

      $from_date  = $this->input->get('from_date')??date('Y-m-d');
		  $to_date    = $this->input->get('to_date')??date('Y-m-d');
      $data['from_date'] = $from_date;
		  $data['to_date'] = $to_date;
      
      $where['return_date >= '] = $from_date;
			$where['return_date <= '] = $to_date;


      $data['values'] = $this->Common_model->findAll("return_manages",$where,"return_id","desc");
      $this->load->view('admin/layouts/header');
      $this->load->view('admin/supplier_return/index', $data);
      $this->load->view('admin/layouts/footer');
    } else {
      $data['wrong_msg'] = "";
      $this->load->view('website/login_check', $data);
    }
  }
  // public function create() {
  //   $user_type = $this->session->ses_user_type;
  //   if ($user_type == "admin" || $user_type == "staff") {
  //     $data['title'] = 'Supplier Return';
  //     $data['page_title'] = 'Supplier Return';
  //     $data['info_header'] = '';
  //     $data['values'] = $this->Common_model->findAll('suppliers',array(),'record_id','desc') ;
  //     $this->load->view('admin/layouts/header');
  //     $this->load->view('admin/supplier_return/create', $data);
  //     $this->load->view('admin/layouts/footer');
  //   } else {
  //     $data['wrong_msg'] = "";
  //     $this->load->view('website/login_check', $data);
  //   }
  // }

  public function create()
	{
		   $user_type = $this->session->ses_user_type;
    if ($user_type == "admin" || $user_type == "staff") {
    $data['title'] = 'Supplier Return';
    $data['page_title'] = 'Supplier Return';
    $data['info_header'] = '';
    
		$this->load->view('admin/layouts/header');
    $this->load->view('admin/supplier_return/create', $data);
    $this->load->view('admin/layouts/footer');
  } else {
        $data['wrong_msg'] = "";
        $this->load->view('website/login_check', $data);
      }
	}

  public function saveOrUpdate() {
    $user_type = $this->session->ses_user_type;
    if ($user_type == "admin" || $user_type == "staff") {
      $data = $_POST;
      $update_id = $data['update_id'];
      $supplier_id = $data['supplier_id'];
      $return_type = $data['return_type'];
      $return_date = $data['return_date'];
      $product_ids = $data['product_id'];
      $item_return_types = $data['item_return_type'];
      $purchase_prices = $data['purchase_price'];
      $return_prices = $data['sales_price'];
      $order_qtys = $data['order_qty'];
      $return_qtys = isset($data['return_qty']) ? $data['return_qty'] : 0;
      $unit_ids = $data['unit_id'];
      $unit_names = $data['unit_name'];
      $return_details_id = $data['return_details_id'];
      //$sub_totals = $data['sub_total'];
      $net_totals = $data['net_total'];
      $return_amounts = $data['net_total'];
      $total_order_qty = array_sum($order_qtys) ;
      unset($data['update_id']);
      unset($data['return_details_id']);
       
      
      unset($data['product_id']);
      unset($data['purchase_price']);
      unset($data['sales_price']);
      unset($data['return_price']);
      unset($data['order_qty']);
      unset($data['return_qty']);
      unset($data['item_return_type']);
     
      unset($data['unit_id']);
      unset($data['unit_name']);
      unset($data['sub_total']);
      unset($data['net_total']);
      unset($data['return_amount']);
      $data['total_order_qty'] = $total_order_qty ;
      $data['grand_return_amount'] = $data['grand_net_total'] ;
      if($update_id == 0){
        $prefix = str_replace('-', '', $return_date);
        $maxPurschaseOrder = $this->Common_model->findMax('return_manages',array('prefix'=>$prefix),'return_no');
        $data['prefix'] = $prefix ;
        $return_no = isset($maxPurschaseOrder)?$maxPurschaseOrder->return_no + 1 : 1 ;
        $data['return_no'] = $return_no ;
        $insert = $this->Common_model->saveData('return_manages',$data);
        $update_id = $insert ;
        if($insert){
          foreach ($product_ids as $key => $value) {
            $returnDetails = array(
              'return_id'=>$insert,
			  'return_date'=>$return_date,
              'product_id'=>$product_ids[$key],
              'return_type'=>$item_return_types[$key],
              'unit_id'=>$unit_ids[$key],
              'unit_name'=>$unit_names[$key],
              'purchase_price'=>$purchase_prices[$key],
              'return_price'=>$return_prices[$key],
              //'order_qty'=>$order_qtys[$key],
              'return_qty'=>$order_qtys[$key],
              //'sub_total'=>$sub_totals[$key],
              //'net_total'=>$net_totals[$key],
              'return_amount'=>$return_amounts[$key],
            );
           $detailsId = $this->Common_model->saveData('return_details',$returnDetails);

          // $stock_info = $this->Common_model->findById('drug_medicine', array('record_id' => $product_ids[$key]));
					// $new_stock = $stock_info->product_stock-$order_qtys[$key];
					// $this->Common_model->updateData('drug_medicine', array( 'product_stock' => $new_stock), array('record_id' => $product_ids[$key]));

             $this->updateStock($product_ids[$key],$detailsId, $order_qtys[$key], $return_date, $purchase_prices[$key],0);

					// $stock_history = $this->Common_model->findById('product_stock_history', array('product_id' => $product_ids[$key], 'stock_date' =>$return_date));
					
					// if(!empty($stock_history)){
					// 	$history = array(
					// 		'stock_qty' => $new_stock,
					// 		'purchase_return_qty' => $stock_history->purchase_return_qty+$order_qtys[$key]
					// 	);
					// 	$this->Common_model->updateData('product_stock_history', $history, array('record_id' => $stock_history->record_id));

					// }else{
					// 	$history = array(
					// 		'stock_date' => $return_date,
					// 		'product_id' => $product_ids[$key],
					// 		'stock_qty' => $new_stock,
					// 		'purchase_return_qty' => $order_qtys[$key],
					// 	);
					// 	$this->Common_model->saveData('product_stock_history', $history);
					// }

            $this->session->set_userdata('alertMsg',INSERT_MSG);
          }
        }else{
          $this->session->set_userdata('alertMsg',INSERT_ERROR_MSG);
        }
      }else{
          $this->deleteStock($update_id);
        $purchase = $this->Common_model->findById('return_manages',array('return_id'=>$update_id));
        $prefix = str_replace('-', '', $return_date);
        $maxPurschaseOrder = $this->Common_model->findMax('return_manages',array('prefix'=>$prefix),'return_no');
        $data['prefix'] = $prefix ;
        $return_no = isset($maxPurschaseOrder)?$maxPurschaseOrder->return_no + 1 : 1 ;
        if($purchase->return_date == $return_date){
          $data['return_no'] = $purchase->return_no ;
        }else{
          $data['return_no'] = $return_no ;
        }
        $update = $this->Common_model->updateData('return_manages',$data,array('return_id'=>$update_id));
        
        $this->Common_model->delete_info('return_id', $update_id, 'return_details');
       

        if($update){
          foreach ($product_ids as $key => $value) {
            $returnDetails = array(
              'return_id'=>$update_id,
              'return_type'=>$return_type,
              'return_type'=>$item_return_types[$key],
              'product_id'=>$product_ids[$key],
              'unit_id'=>$unit_ids[$key],
              'unit_name'=>$unit_names[$key],
              'purchase_price'=>$purchase_prices[$key],
              'return_price'=>$return_prices[$key],
              //'order_qty'=>$order_qtys[$key],
              'return_qty'=>$order_qtys[$key],
              //'sub_total'=>$sub_totals[$key],
              //'net_total'=>$net_totals[$key],
              'return_amount'=>$return_amounts[$key],
            );
            $return_details_id = $detailsId = $return_details_ids[$key];
            if($return_details_id){
              $this->Common_model->updateData('return_details',$returnDetails,array('return_details_id'=>$return_details_id));
            }else{
             $detailsId =  $this->Common_model->saveData('return_details',$returnDetails);
            }
          $this->updateStock($product_ids[$key],$detailsId, $order_qtys[$key], $return_date, $purchase_prices[$key],0);

          //   $stock_info = $this->Common_model->findById('product_stock', array('product_id' => $product_ids[$key]));
					// $new_stock = $stock_info->stock_qty-$order_qtys[$key];
					// $this->Common_model->updateData('product_stock', array('stock_qty' => $new_stock), array('product_id' => $product_ids[$key]));

          }
          if($update){
            $this->session->set_userdata('alertMsg',UPDATE_MSG);
          }else{
            $this->session->set_userdata('alertMsg',UPDATE_ERROR_MSG);
          }
        }
      }

      redirect('supplier_return', 'refresh');
    } else {
      $data['wrong_msg'] = "";
      $this->load->view('website/login_check', $data);
    }
  }
  // public function saveOrUpdate() {
  //   $user_type = $this->session->ses_user_type;
  //   if ($user_type == "admin" || $user_type == "staff") {
  //     $data = $_POST;
  //     $update_id = $data['update_id'];
  //     $return_type = $data['return_type'];
  //     $purchase_order_ids = $data['purchase_order_id'];
  //     $purchase_order_details_ids = $data['purchase_order_details_id'];
  //     $return_date = $data['return_date'];
  //     $product_ids = $data['product_id'];
  //     $purchase_prices = $data['purchase_price'];
  //     $return_prices = $data['return_price'];
  //     $order_qtys = $data['order_qty'];
  //     $return_qtys = $data['return_qty'];
  //     $vat_amounts = $data['vat_amount'];
  //     $discount_amounts = $data['discount_amount'];
  //     $discount_per_products = $data['discount_per_product'];
  //     $unit_ids = $data['unit_id'];
  //     $unit_names = $data['unit_name'];
  //     $sub_totals = $data['sub_total'];
  //     $net_totals = $data['net_total'];
  //     $return_amounts = $data['return_amount'];
  //     $total_order_qty = array_sum($order_qtys) ;
  //     unset($data['update_id']);
  //     unset($data['purchase_order_id']);
  //     unset($data['purchase_order_details_id']);
  //     unset($data['product_id']);
  //     unset($data['purchase_price']);
  //     unset($data['return_price']);
  //     unset($data['order_qty']);
  //     unset($data['return_qty']);
  //     unset($data['vat_amount']);
  //     unset($data['discount_amount']);
  //     unset($data['discount_per_product']);
  //     unset($data['unit_id']);
  //     unset($data['unit_name']);
  //     unset($data['sub_total']);
  //     unset($data['net_total']);
  //     unset($data['return_amount']);
  //     $data['total_order_qty'] = $total_order_qty ;
  //     if($update_id == 0){
  //       $prefix = str_replace('-', '', $return_date);
  //       $maxPurschaseOrder = $this->Common_model->findMax('return_manages',array('prefix'=>$prefix),'return_no');
  //       $data['prefix'] = $prefix ;
  //       $return_no = isset($maxPurschaseOrder)?$maxPurschaseOrder->return_no + 1 : 1 ;
  //       $data['return_no'] = $return_no ;
  //       $insert = $this->Common_model->saveData('return_manages',$data);
  //       $update_id = $insert ;
  //       if($insert){
  //         foreach ($product_ids as $key => $value) {
  //           $returnDetails = array(
  //             'return_id'=>$insert,
  //             'purchase_order_id'=>$purchase_order_ids[$key],
  //             'purchase_order_details_id'=>$purchase_order_details_ids[$key],
  //             'return_type'=>$return_type,
  //             'product_id'=>$product_ids[$key],
  //             'unit_id'=>$unit_ids[$key],
  //             'unit_name'=>$unit_names[$key],
  //             'purchase_price'=>$purchase_prices[$key],
  //             'return_price'=>$return_prices[$key],
  //             'order_qty'=>$order_qtys[$key],
  //             'return_qty'=>$return_qtys[$key],
  //             'vat_amount'=>$vat_amounts[$key],
  //             'discount_per_product'=>$discount_per_products[$key],
  //             'discount_amount'=>$discount_amounts[$key],
  //             'sub_total'=>$sub_totals[$key],
  //             'net_total'=>$net_totals[$key],
  //             'return_amount'=>$return_amounts[$key],
  //           );
  //           $this->Common_model->saveData('return_details',$returnDetails);
  //           $this->session->set_userdata('alertMsg',INSERT_MSG);
  //         }
  //       }else{
  //         $this->session->set_userdata('alertMsg',INSERT_ERROR_MSG);
  //       }
  //     }else{
  //       $purchase = $this->Common_model->findById('return_manages',array('purchase_id'=>$update_id));
  //       $prefix = str_replace('-', '', $return_date);
  //       $maxPurschaseOrder = $this->Common_model->findMax('return_manages',array('prefix'=>$prefix),'return_no');
  //       $data['prefix'] = $prefix ;
  //       $return_no = isset($maxPurschaseOrder)?$maxPurschaseOrder->return_no + 1 : 1 ;
  //       if($purchase->return_date == $return_date){
  //         $data['return_no'] = $purchase->return_no ;
  //       }else{
  //         $data['return_no'] = $return_no ;
  //       }
  //       $update = $this->Common_model->updateData('return_manages',$data,array('purchase_id'=>$update_id));
  //       if($update){
  //         foreach ($product_ids as $key => $value) {
  //           $returnDetails = array(
  //             'return_id'=>$update_id,
  //             'purchase_order_id'=>$purchase_order_ids[$key],
  //             'purchase_order_details_id'=>$purchase_order_details_ids[$key],
  //             'return_type'=>$return_type,
  //             'product_id'=>$product_ids[$key],
  //             'unit_id'=>$unit_ids[$key],
  //             'unit_name'=>$unit_names[$key],
  //             'purchase_price'=>$purchase_prices[$key],
  //             'return_price'=>$return_prices[$key],
  //             'order_qty'=>$order_qtys[$key],
  //             'return_qty'=>$return_qtys[$key],
  //             'vat_amount'=>$vat_amounts[$key],
  //             'discount_per_product'=>$discount_per_products[$key],
  //             'discount_amount'=>$discount_amounts[$key],
  //             'sub_total'=>$sub_totals[$key],
  //             'net_total'=>$net_totals[$key],
  //             'return_amount'=>$return_amounts[$key],
  //           );
  //           $return_details_id = $return_details_ids[$key];
  //           if($return_details_id){
  //             $this->Common_model->updateData('return_details',$returnDetails,array('return_details_id'=>$return_details_id));
  //           }else{
  //             $this->Common_model->saveData('return_details',$returnDetails);
  //           }

  //         }
  //         if($update){
  //           $this->session->set_userdata('alertMsg',UPDATE_MSG);
  //         }else{
  //           $this->session->set_userdata('alertMsg',UPDATE_ERROR_MSG);
  //         }
  //       }
  //     }

  //     redirect('supplier_return', 'refresh');
  //   } else {
  //     $data['wrong_msg'] = "";
  //     $this->load->view('website/login_check', $data);
  //   }
  // }

  public function load_invoice_products(){
    $purchase_id = $this->input->post('purchase_id');
    
    $data['value'] = $this->Common_model->findById('purchase_orders',array('purchase_id'=>$purchase_id));
    $data['supplier'] = $this->Common_model->findById('suppliers',array('record_id'=>$data['value']->supplier_id));

    $where = array('purchase_order_details.purchase_order_id '=>$purchase_id);
    $options = array(
      'joins' => array(
        array(
          'table' => 'product_name',
          'condition' => 'product_name.record_id = purchase_order_details.product_id',
          'jointype' => 'LEFT'
        ),
        array(
          'table' => 'generic_names',
          'condition' => 'generic_names.record_id = product_name.product_category_generic_name_id',
          'jointype' => 'LEFT'
        ),
        array(
          'table' => 'units',
          'condition' => 'units.record_id = purchase_order_details.unit_id',
          'jointype' => 'LEFT'
        ),

      ),
      'select' => 'purchase_order_details.*,product_name.product_name,product_name.product_category,units.unit_short_name,generic_names.generic_name',
      'where' => $where,
      'order' => array(
        'purchase_order_details.purchase_order_details_id' => 'asc',
      ),
    );
    $data['values'] = $this->Common_model->commonJoins("purchase_order_details", $options);

    $this->load->view('admin/supplier_return/product_list',$data);
  }

  public function delete($id) {
    $user_type = $this->session->ses_user_type;
    if ($user_type == "admin"  || $user_type == "staff") {
      // $this->delete_purchase_return_stock($id);
      $this->deleteStock($id);
      if($this->Common_model->delete_info('return_id', $id, 'return_manages')){
        $this->Common_model->delete_info('return_id', $id, 'return_details');
        $this->session->set_flashdata('message',DELETE_MSG);
      }else{
        $this->session->set_flashdata('message',DELETE_ERROR_MSG);
      }
           // redirect("crud/previousPage");
      redirect('supplier_return', 'refresh');
    } else {
      $data['wrong_msg'] = "";
      $this->load->view('website/login_check', $data);
    }
  }


  public function view($return_id)
  {
    $data['title'] = "View Return";
    $data['page_title'] = "View Return";
    $data['info_header'] = "";
    $data['signatureType'] = 'Staff';
    $data['redirect'] = base_url('supplier_return/create');
    $data['value'] = $this->Common_model->findById('return_manages',array('return_id'=>$return_id));
    $supplier = $this->Common_model->findById('suppliers', array( 'record_id' => $data['value']->supplier_id));
			$manufacturer = $this->Common_model->findById('drug_manufacturer', array('record_id' => $data['value']->supplier_id));
			$data['supplier'] = $manufacturer->manufacturer_name.'['.$manufacturer->record_id.']';
			$data['supplier_contact'] = $manufacturer->contact_no;
    $data['purchase'] = $this->Common_model->findById('purchase_orders',array('purchase_id'=>$data['value']->purchase_id));

    $where = array('return_details.return_id '=>$return_id);
    $options = array(
      'joins' => array(
        array(
          'table' => 'product_name',
          'condition' => 'product_name.record_id = return_details.product_id',
          'jointype' => 'LEFT'
        ),
        array(
          'table' => 'generic_names',
          'condition' => 'generic_names.record_id = product_name.product_category_generic_name_id',
          'jointype' => 'LEFT'
        ),
        array(
          'table' => 'units',
          'condition' => 'units.record_id = return_details.unit_id',
          'jointype' => 'LEFT'
        ),

      ),
      'select' => 'return_details.*,product_name.product_name,product_name.product_category,units.unit_short_name,generic_names.generic_name',
      'where' => $where,
      'order' => array(
        'return_details.return_details_id' => 'asc',
      ),
    );
    $data['values'] = $this->Common_model->commonJoins("return_details", $options);
    $this->load->view('admin/layouts/header');
    $this->load->view('admin/supplier_return/view', $data);
    $this->load->view('admin/layouts/footer');
  }

  public function delete_purchase_return_stock($id)
	{
	$return_details = $this->Common_model->findAll('return_details',array('return_id'=>$id),'return_details_id','asc');
			foreach($return_details as $detail){
				$stock_info = $this->Common_model->findById('drug_medicine', array('record_id' => $detail->product_id));
				$new_stock = $stock_info->product_stock+$detail->return_qty;
				$this->Common_model->updateData('drug_medicine', array('product_stock' => $new_stock), array('record_id' => $stock_info->record_id));

				$stock_history = $this->Common_model->findById('product_stock_history', array('product_id' => $stock_info->record_id, 'stock_date' =>$detail->return_date));
					$history = array(
						'stock_qty' => $new_stock,
						'purchase_return_qty' => $stock_history->purchase_return_qty-$detail->return_qty
					);
					$this->Common_model->updateData('product_stock_history', $history, array('record_id' => $stock_history->record_id));

			}
			//exit;
	}

    private function updateStock($productId,$detailsId, $qty, $date, $price=0,$salePrice=0){
	
		updateStock($productId,$detailsId, $qty, $date, 'purchase_return', $price,$salePrice,);
	}

	private function deleteStock($id){
		$order_details = $this->Common_model->findAll('return_details',['return_id'=>$id],'return_details_id','asc');
		foreach($order_details as $detail){
			deleteStock($detail->return_details_id, $detail->product_id, 'purchase_return');
		}
	}

}
