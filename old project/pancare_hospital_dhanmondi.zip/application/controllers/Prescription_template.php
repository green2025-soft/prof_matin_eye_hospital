<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Prescription_template extends MY_Controller {

     protected $title = 'Prescription Template';
     protected $bUrl = 'prescription_template';

    protected $isAdminStaff = false;

    public function __construct() {
        parent::__construct();
        $this->loadModel('PrescriptionTemplate_model');
          $this->load->model([
            'PrescriptionTemplateItem_model'    => 'ptiModel',
        ]);
    }

    protected function laoute($pageName) {
        $this->render('prescription_template/'.$pageName);
    }



    public function index() {
        $salesQuery = $this->model->orderDesc();
        $allData = $salesQuery->get();
        	$this->data = [
			 'title'     		=> $this->title.' List',
			 'values'			=> $allData
		];
		
		$this->laoute('index');
    }
    public function create() {
        $data['test_names'] = $this->Common_model->findAll('test_name',array(),'record_id','asc');
            $where = array('type'=>'Medicine');
        $options = array(
            'joins' => array(
                array(
                    'table' => 'units',
                    'condition' => 'units.record_id = product_name.unit_id',
                    'jointype' => 'LEFT'
                ),
                array(
                    'table' => 'generic_names',
                    'condition' => 'generic_names.record_id = product_name.product_category_generic_name_id',
                    'jointype' => 'LEFT'
                ),
            ),
            'select' => 'product_name.*,units.unit_short_name,generic_names.generic_name',
            'where' => $where,
            'order' => array(
                'product_name.record_id' => 'asc',
            ),
        );
        $data['products'] = $this->Common_model->commonJoins("product_name", $options);

        $data['medicines'] = $this->getMedicine();
        // dd($data['medicines']);

        $this->data =  $data;
        
        $this->laoute('create'); 
    }

    public function edit($record_id) {
            $data['test_names'] = $this->Common_model->findAll('test_name',array(),'record_id','asc');
            
            $data['value'] = $this->model->find($record_id);

            $items = $this->ptiModel->where('prescription_id', $record_id)->get();
            $this->ptiModel->belongsTo($items, 'meal_type_id','meal_types','record_id', 'meal_types');
        $this->ptiModel->belongsTo($items, 'medicine_type_id','types_of_medicine','record_id', 'medicine_type');
        $this->ptiModel->belongsTo($items, 'medicine_id','drug_medicine','record_id', 'medicine');
        $this->ptiModel->withSingle($items, 'medicine','dosage_id','drug_dosage','record_id', 'dosage');

         $data['values'] = $items;
            
            
            $data['medicines'] = $this->getMedicine();
            $this->data =  $data;
        
        $this->laoute('create'); 
    }

    
    public function saveOrUpdate() {
            $input = $_POST;
            
            $update_id = $input['update_id'] ;
            unset($input['update_id']);
            $date = date('Y-m-d');
            $prescription_details_ids = $input['prescription_details_id'];
            $test_ids = $input['test_id'];
            if(is_array($test_ids)) $test_ids = implode(',', $test_ids);
            $input['test_ids'] = $test_ids ;
            $medicine_ids = $input['medicine_id'];
            $medicine_type_ids = $input['medicine_type_id'];
            $doses = $input['dose'];
            $meal_type_ids = $input['meal_type_id'];
            $dayses = $input['days'];

            unset($input['prescription_details_id']);
            unset($input['test_id']);
            unset($input['medicine_id']);
            unset($input['medicine_type_id']);
            unset($input['dose']);
            unset($input['meal_type_id']);
            unset($input['days']);
            unset($input['test_name']);

           

            if($update_id == 0 || empty($update_id)){       
                $insert = $this->model->create($input);
                foreach ($medicine_ids as $key => $value) {
                    $data = array(
                        'prescription_id'=>$insert,
                        'medicine_id' => $medicine_ids[$key],
                        'medicine_type_id' => $medicine_type_ids[$key],
                        'dose' => $doses[$key],
                        'meal_type_id' => $meal_type_ids[$key],
                        'days' => $dayses[$key],
                    );
                    $this->Common_model->saveData('prescription_template_items', $data);
                }
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
                $update_id = $insert ;
            }else{

                $update = $this->model->update($update_id, $input,'record_id');
                foreach ($medicine_ids as $key => $value) {
                    $prescription_detail_id = $prescription_details_ids[$key];
                    $data = array(
                        'prescription_id'=>$update_id,
                        'medicine_id' => $medicine_ids[$key],
                        'medicine_type_id' => $medicine_type_ids[$key],
                        'dose' => $doses[$key],
                        'meal_type_id' => $meal_type_ids[$key],
                        'days' => $dayses[$key],
                    );
                    if($prescription_detail_id){
                        $this->Common_model->updateData('prescription_template_items', $data,array('record_id'=>$prescription_detail_id));
                    }else{
                        $this->Common_model->saveData('prescription_template_items', $data);
                    }                    
                }
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
        
            }
           // var_dump("Called");die;
            redirect($this->bUrl, 'refresh');
    }
    public function view($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff" || $user_type == "doctor") {
            $data['title'] = 'View Prescription';
            $data['page_title'] = 'View Prescription';
            $data['info_header'] = '';
            $data['signatureType'] = '';
            $data['redirect'] = base_url('prescription/create');
            $data['value'] = $this->Common_model->findById('prescription',array('record_id'=>$record_id));
            $data['values'] = $this->Common_model->findAll('prescription_details',array('prescription_id'=>$record_id),'record_id','asc');
            if(isset($data['value'])){
                $data['patient'] = $this->Common_model->findById('patient',array('record_id'=>$data['value']->patient_id));
                $data['doctor'] = $this->Common_model->findById('doctor',array('record_id'=>$data['value']->doctor_id));
                $designation = $this->Common_model->findById('designation',array('record_id'=>$data['doctor']->designation_id));
                $designation_name = isset($designation)?$designation->designation:"" ;
                $data['doctor']->designation = $designation_name ;
            }
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/prescription/view', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
 

    public function delete($id) {
        if($this->model->delete($id, 'record_id')){
            $this->Common_model->delete_info('prescription_id', $id, 'prescription_template_items');
            $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
            redirect('prescription', 'refresh');
    }

    private function getMedicine(){
       return $this->Common_model->getAllProduct();
    }
}
