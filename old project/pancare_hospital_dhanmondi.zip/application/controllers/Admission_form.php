<?php

/**
 * 
 */
class Admission_form extends CI_Controller
{
	
	public function __construct()
	{
		parent::__construct();
	}

	public function index(){
		$data['title'] = 'Admission List';
        $data['page_title'] = 'Admission List';
        $data['info_header'] = '';

		$from_date = $this->input->get('from_date');
		$to_date = $this->input->get('to_date');
		$sergeon_id = $this->input->get('sergeon_id');
		$admission_id = $this->input->get('admission_id');
		$patient_status = !empty($this->input->get('patient_status')) ? $this->input->get('patient_status') : "" ;
		$reference_by = $this->input->get('reference_by');

		// if (!isset($from_date) && !isset($to_date) && !isset($sergeon_id) && !isset($admission_id)) {
		if (!isset($from_date) && !isset($to_date)) {
			$from_date = $to_date = date('Y-m-d');
		}

		$where = array();
		if (!admin()) {
			$where['operation_invoice.show_hide'] = 'Show';
		}
		if($sergeon_id) $where['sergeon_id'] = $sergeon_id ;
		
		if($admission_id) $where['admission_id'] = $admission_id ;
		if (!empty($from_date) && !empty($to_date)) {
			$where['operation_invoice.admission_date >= '] = $from_date;
			$where['operation_invoice.admission_date <= '] = $to_date;
		} elseif (!empty($from_date) && empty($to_date)) {
			$where['operation_invoice.admission_date'] = $from_date;
		} elseif (empty($from_date) && !empty($to_date)) {
			$where['operation_invoice.admission_date'] = $to_date;
		}
		if(!empty($reference_by)){
			$where['operation_invoice.reference_by'] = $reference_by;
		}

		$options = array(
			'joins' => array(
				array(
					'table' => 'patient',
					'condition' => 'patient.record_id = operation_invoice.patient_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor sergeon',
					'condition' => 'sergeon.record_id = operation_invoice.sergeon_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor anesthesia',
					'condition' => 'anesthesia.record_id = operation_invoice.anesthesia_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation sergeon_designation',
					'condition' => 'sergeon_designation.record_id = sergeon.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation anesthesia_designation',
					'condition' => 'anesthesia_designation.record_id = anesthesia.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_category',
					'condition' => 'operation_category.record_id = operation_invoice.operation_category_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_name',
					'condition' => 'operation_name.record_id = operation_invoice.operation_name_id',
					'jointype' => 'LEFT'
				),array(
					'table' => 'beds',
					'condition' => 'beds.record_id = operation_invoice.bed_id',
					'jointype' => 'LEFT'
				),array(
					'table' => 'reference_by',
					'condition' => 'reference_by.record_id = operation_invoice.reference_by',
					'jointype' => 'LEFT'
				),
			),
			'select' => 'operation_invoice.*,operation_invoice.created_by as operation_invoice_created_by ,operation_invoice.record_id as operation_invoice_record_id,patient.*,patient.record_id as patient_id,sergeon.name as sergeon_name,sergeon_designation.designation as sergeon_designation,anesthesia.name as anesthesia_name,anesthesia_designation.designation as anesthesia_designation,operation_category.category_name,operation_name.operation_name,beds.*,reference_by.reference_name,reference_by.record_id as reference_id, reference_by.reference_prefix, reference_by.reference_no',
			'where' => $where,
			'order' => array(
				'operation_invoice.record_id' => 'desc',
			),
		);
		$data['from_date'] = $from_date ;
		$data['to_date'] = $to_date ;
		$data['sergeon_id'] = $sergeon_id ;
		$data['admission_id'] = $admission_id ;
		$data['patient_status'] = $patient_status ;
		$data['reference_by'] = $reference_by ;
		$data['values'] = $this->Common_model->commonJoins("operation_invoice", $options);
		// ddd($reference_by);
		$data['references'] = $this->db->get_where('reference_by')->result();

		$where = array() ;
		$data['admissionInvoice'] = $this->Common_model->findAll("admission_fee_invoice",$where,"record_id","desc");

		$this->load->view('admin/layouts/header');
		$this->load->view('admin/admission_form/index',$data);
		$this->load->view('admin/layouts/footer');			
	}
	public function create(){
		$data['title'] = 'IPD Admission Form';
        $data['page_title'] = 'IPD Admission Form';
        $data['info_header'] = '';
		$admission_date = date('Y-m-d') ;
		$prefix  = str_replace('-', '', $admission_date);
		$max_operation_invoice = $this->Common_model->findMax('operation_invoice',array('prefix'=>$prefix),'serial_no');
		$serial_no = isset($max_operation_invoice)?$max_operation_invoice->serial_no + 1 : 1 ;

		$registration_no = $prefix."-$serial_no";

        $patient_ids = array() ;
        $admission_invoices = $this->Common_model->findAll('admission_fee_invoice',array('patient_status'=>'Admitted'),'record_id','asc');
        foreach ($admission_invoices as $key1 => $value1) {
        	$patient_ids[] = $value1->patient_id ;
        }
        $data['patient_list'] = $this->Common_model->findAllWhereIn('patient',array(),$patient_ids,'record_id','record_id','asc') ;
        $max = $this->Common_model->findMax('operation_invoice',array(),'admission_no') ;
        $admission_no = isset($max)?$max->admission_no + 1 : 1;
        $data['admission_no'] = str_pad($admission_no,4,0,STR_PAD_LEFT );
		$data['registration_no'] = $registration_no ;
		$where = array() ;
		$where['patient_status'] = 'New' ;
		$data['admissionInvoice'] = $this->Common_model->findAll("admission_fee_invoice",$where,"record_id","desc");
		//var_dump($data['admissionInvoice'] ); die ;
		$data['references'] = $this->db->get_where('reference_by')->result();

		
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/admission_form/create',$data);
		$this->load->view('admin/layouts/footer');			
	}
	public function edit($record_id){
		$data['title'] = 'IPD Admission Form';
        $data['page_title'] = 'IPD Admission Form';
        $data['info_header'] = '';
        $data['value'] = $this->Common_model->findById('operation_invoice',array('record_id'=>$record_id));
        $patient_ids = array() ;
        $admission_invoices = $this->Common_model->findAll('admission_fee_invoice',array('patient_status'=>'Admitted'),'record_id','asc');
        foreach ($admission_invoices as $key1 => $value1) {
        	$patient_ids[] = $value1->patient_id ;
        }
        $data['patient_list'] = $this->Common_model->findAllWhereIn('patient',array(),$patient_ids,'record_id','record_id','asc') ;

        $data['operation_names'] = $this->Common_model->findAll('operation_name',array('category_id'=>$data['value']->operation_category_id),'operation_name','asc');
        $data['beds'] = $this->Common_model->findAll('beds',array('opd_cabin_ward'=>$data['value']->opd_cabin_ward),'bed_no','asc');
        $data['bed'] = $this->Common_model->findById('beds',array('record_id'=>$data['value']->bed_id));
        $data['patient'] = $this->Common_model->findById('patient',array('record_id'=>$data['value']->patient_id));
		$where = array() ;
		$where['record_id'] = $data['value']->admission_id ;
		$data['admissionInvoice'] = $this->Common_model->findAll("admission_fee_invoice",$where,"record_id","desc");
		$data['references'] = $this->db->get_where('reference_by')->result();
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/admission_form/create',$data);
		$this->load->view('admin/layouts/footer');			
	}
	public function saveOrUpdate(){
		$input = $_POST ;
		$update_id = $input['update_id'] ; 
		$admission_id = $input['admission_id'];
		$admission_date = $input['admission_date'];
		unset($input['update_id']);	

		// ddd($_POST);
		
		$prefix  = str_replace('-', '', $admission_date);
		$max_operation_invoice = $this->Common_model->findMax('operation_invoice',array('prefix'=>$prefix),'serial_no');
		$serial_no = isset($max_operation_invoice)?$max_operation_invoice->serial_no + 1 : 1 ;

		$input['prefix'] = $prefix ;
		$input['serial_no'] = $serial_no ;

		if($update_id == 0 || empty($update_id)){     
                $insert = $this->Common_model->saveData('operation_invoice', $input);
                $this->Common_model->updateData('admission_fee_invoice', array('patient_status'=>'Admitted'),array('record_id'=>$admission_id));
                $update_id = $insert;
				$this->Common_model->updateData('beds', array('bed_status'=>'Booked'), array('record_id'=>$input['bed_id']));

                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
                redirect("admission_form/view/$update_id");
            }else{
				$info = $this->Common_model->findById('operation_invoice',array('record_id'=>$update_id)) ;
				if($info->admission_date == $admission_date){
					$input['serial_no'] = $info->serial_no ;
				}
				$this->Common_model->updateData('beds', array('bed_status'=>'Vacant'), array('record_id'=>$info->bed_id));
				$this->Common_model->updateData('beds', array('bed_status'=>'Booked'), array('record_id'=>$input['bed_id']));
                $update = $this->Common_model->updateData('operation_invoice', $input,array('record_id'=>$update_id));
                $this->Common_model->updateData('admission_fee_invoice', array('patient_status'=>'Admitted'),array('record_id'=>$admission_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
                //redirect("admission_form/view2/$update_id");
                redirect("admission_form");
            }
		$this->session->set_flashdata('message',INSERT_MSG);
		
	}

	public function view($record_id){
		$data['title'] = 'View Patient Admission';
        $data['page_title'] = 'View Patient Admission';
        $data['info_header'] = '';
        $data['redirect'] =  base_url('admission_form/create');

        $where = array('operation_invoice.record_id'=>$record_id);
		$options = array(
			'joins' => array(
				array(
					'table' => 'patient',
					'condition' => 'patient.record_id = operation_invoice.patient_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor sergeon',
					'condition' => 'sergeon.record_id = operation_invoice.sergeon_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor anesthesia',
					'condition' => 'anesthesia.record_id = operation_invoice.anesthesia_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation sergeon_designation',
					'condition' => 'sergeon_designation.record_id = sergeon.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation anesthesia_designation',
					'condition' => 'anesthesia_designation.record_id = anesthesia.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_category',
					'condition' => 'operation_category.record_id = operation_invoice.operation_category_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_name',
					'condition' => 'operation_name.record_id = operation_invoice.operation_name_id',
					'jointype' => 'LEFT'
				),array(
					'table' => 'beds',
					'condition' => 'beds.record_id = operation_invoice.bed_id',
					'jointype' => 'LEFT'
				),
			),
			'select' => 'operation_invoice.*,operation_invoice.created_by as operation_invoice_created_by,operation_invoice.record_id as operation_invoice_record_id,patient.name as patient_name,patient.record_id as patient_id,patient.age as patient_age,patient.gender as patient_gender,patient.mobile as patient_mobile, patient.patient_father_name, patient.patient_mother_name, patient.patient_blood_group, patient.patient_spouse_name, patient.address, patient.village, patient.post_office, patient.thana, patient.district, operation_invoice.address as re_address,sergeon.name as sergeon_name,sergeon_designation.designation as sergeon_designation,anesthesia.name as anesthesia_name,anesthesia_designation.designation as anesthesia_designation,operation_category.category_name,operation_name.operation_name,beds.*,operation_invoice.created_at as admission_created_at, patient.patient_occupation',
			'where' => $where,
			'order' => array(
				'operation_invoice.record_id' => 'asc',
			),
		);
		$data['value'] = $this->Common_model->commonJoinsRow("operation_invoice", $options);
		$data['value']->created_by = $data['value']->operation_invoice_created_by;

		$this->load->view('admin/layouts/header');
		if($data['value']->form_type == 'ICU'){
			$this->load->view('admin/admission_form/view_icu',$data);
		}else{
		$this->load->view('admin/admission_form/view',$data);
		}
		$this->load->view('admin/layouts/footer');			
	}
	public function view2($record_id){
		$data['title'] = 'View Patient Admission';
        $data['page_title'] = 'View Patient Admission';
        $data['info_header'] = '';
        $data['redirect'] =  base_url('admission_form');

        $where = array('operation_invoice.record_id'=>$record_id);
		$options = array(
			'joins' => array(
				array(
					'table' => 'patient',
					'condition' => 'patient.record_id = operation_invoice.patient_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor referring_sergeon',
					'condition' => 'referring_sergeon.record_id = operation_invoice.referring_physician',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor sergeon',
					'condition' => 'sergeon.record_id = operation_invoice.sergeon_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor anesthesia',
					'condition' => 'anesthesia.record_id = operation_invoice.anesthesia_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation referring_sergeon_designation',
					'condition' => 'referring_sergeon_designation.record_id = referring_sergeon.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation sergeon_designation',
					'condition' => 'sergeon_designation.record_id = sergeon.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation anesthesia_designation',
					'condition' => 'anesthesia_designation.record_id = anesthesia.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_category',
					'condition' => 'operation_category.record_id = operation_invoice.operation_category_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_name',
					'condition' => 'operation_name.record_id = operation_invoice.operation_name_id',
					'jointype' => 'LEFT'
				),array(
					'table' => 'beds',
					'condition' => 'beds.record_id = operation_invoice.bed_id',
					'jointype' => 'LEFT'
				),
			),
			'select' => 'operation_invoice.*,operation_invoice.created_by as operation_invoice_created_by,operation_invoice.record_id as operation_invoice_record_id,patient.name as patient_name,patient.record_id as patient_id,patient.age as patient_age,patient.gender as patient_gender,patient.mobile as patient_mobile, patient.patient_father_name, patient.patient_mother_name, patient.patient_blood_group, patient.patient_spouse_name, patient.address, patient.village, patient.post_office, patient.thana, patient.district, operation_invoice.address as re_address,sergeon.name as sergeon_name,sergeon_designation.designation as sergeon_designation,anesthesia.name as anesthesia_name,anesthesia_designation.designation as anesthesia_designation,operation_category.category_name,operation_name.operation_name,beds.*,operation_invoice.created_at as admission_created_at',
			'where' => $where,
			'order' => array(
				'operation_invoice.record_id' => 'asc',
			),
		);
		$data['value'] = $this->Common_model->commonJoinsRow("operation_invoice", $options);
		$data['value']->created_by = $data['value']->operation_invoice_created_by;

	//	var_dump($data['value']);die;

		$this->load->view('admin/layouts/header');
		$this->load->view('admin/admission_form/view',$data);
		$this->load->view('admin/layouts/footer');			
	}

	public function dr_visit_chart($record_id){
		$data['title'] = 'View Patient Admission';
        $data['page_title'] = 'View Patient Admission';
        $data['info_header'] = '';
        $data['redirect'] =  base_url('admission_form');

        $where = array('operation_invoice.record_id'=>$record_id);
		$options = array(
			'joins' => array(
				array(
					'table' => 'patient',
					'condition' => 'patient.record_id = operation_invoice.patient_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor referring_sergeon',
					'condition' => 'referring_sergeon.record_id = operation_invoice.referring_physician',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor sergeon',
					'condition' => 'sergeon.record_id = operation_invoice.sergeon_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor anesthesia',
					'condition' => 'anesthesia.record_id = operation_invoice.anesthesia_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation referring_sergeon_designation',
					'condition' => 'referring_sergeon_designation.record_id = referring_sergeon.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation sergeon_designation',
					'condition' => 'sergeon_designation.record_id = sergeon.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation anesthesia_designation',
					'condition' => 'anesthesia_designation.record_id = anesthesia.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_category',
					'condition' => 'operation_category.record_id = operation_invoice.operation_category_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_name',
					'condition' => 'operation_name.record_id = operation_invoice.operation_name_id',
					'jointype' => 'LEFT'
				),array(
					'table' => 'beds',
					'condition' => 'beds.record_id = operation_invoice.bed_id',
					'jointype' => 'LEFT'
				),
			),
			'select' => 'operation_invoice.*,operation_invoice.created_by as operation_invoice_created_by,operation_invoice.record_id as operation_invoice_record_id,patient.name as patient_name,patient.record_id as patient_id,patient.age as patient_age,patient.address as patient_address,patient.gender as patient_gender,patient.patient_father_name as patient_father_name,patient.patient_mother_name as patient_mother_name,patient.patient_spouse_name as patient_spouse_name,patient.patient_blood_group as patient_blood_group,patient.patient_occupation as patient_occupation,patient.mobile as patient_mobile,operation_invoice.address as re_address,referring_sergeon.name as referring_sergeon_name,referring_sergeon_designation.designation as referring_sergeon_designation,sergeon.name as sergeon_name,sergeon_designation.designation as sergeon_designation,anesthesia.name as anesthesia_name,anesthesia_designation.designation as anesthesia_designation,operation_category.category_name,operation_name.operation_name,beds.*,operation_invoice.created_at as admission_created_at',
			'where' => $where,
			'order' => array(
				'operation_invoice.record_id' => 'asc',
			),
		);
		$data['value'] = $this->Common_model->commonJoinsRow("operation_invoice", $options);
		$data['value']->created_by = $data['value']->operation_invoice_created_by;

	//	var_dump($data['value']);die;

		$this->load->view('admin/layouts/header');
		$this->load->view('admin/admission_form/dr_visit_chart',$data);
		$this->load->view('admin/layouts/footer');			
	}
	
	public function intack_output_chart($record_id){
		$data['title'] = 'View Patient Admission';
        $data['page_title'] = 'View Patient Admission';
        $data['info_header'] = '';
        $data['redirect'] =  base_url('admission_form');

        $where = array('operation_invoice.record_id'=>$record_id);
		$options = array(
			'joins' => array(
				array(
					'table' => 'patient',
					'condition' => 'patient.record_id = operation_invoice.patient_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor referring_sergeon',
					'condition' => 'referring_sergeon.record_id = operation_invoice.referring_physician',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor sergeon',
					'condition' => 'sergeon.record_id = operation_invoice.sergeon_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor anesthesia',
					'condition' => 'anesthesia.record_id = operation_invoice.anesthesia_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation referring_sergeon_designation',
					'condition' => 'referring_sergeon_designation.record_id = referring_sergeon.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation sergeon_designation',
					'condition' => 'sergeon_designation.record_id = sergeon.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation anesthesia_designation',
					'condition' => 'anesthesia_designation.record_id = anesthesia.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_category',
					'condition' => 'operation_category.record_id = operation_invoice.operation_category_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_name',
					'condition' => 'operation_name.record_id = operation_invoice.operation_name_id',
					'jointype' => 'LEFT'
				),array(
					'table' => 'beds',
					'condition' => 'beds.record_id = operation_invoice.bed_id',
					'jointype' => 'LEFT'
				),
			),
			'select' => 'operation_invoice.*,operation_invoice.created_by as operation_invoice_created_by,operation_invoice.record_id as operation_invoice_record_id,patient.name as patient_name,patient.record_id as patient_id,patient.age as patient_age,patient.address as patient_address,patient.gender as patient_gender,patient.patient_father_name as patient_father_name,patient.patient_mother_name as patient_mother_name,patient.patient_spouse_name as patient_spouse_name,patient.patient_blood_group as patient_blood_group,patient.patient_occupation as patient_occupation,patient.mobile as patient_mobile,operation_invoice.address as re_address,referring_sergeon.name as referring_sergeon_name,referring_sergeon_designation.designation as referring_sergeon_designation,sergeon.name as sergeon_name,sergeon_designation.designation as sergeon_designation,anesthesia.name as anesthesia_name,anesthesia_designation.designation as anesthesia_designation,operation_category.category_name,operation_name.operation_name,beds.*,operation_invoice.created_at as admission_created_at',
			'where' => $where,
			'order' => array(
				'operation_invoice.record_id' => 'asc',
			),
		);
		$data['value'] = $this->Common_model->commonJoinsRow("operation_invoice", $options);
		$data['value']->created_by = $data['value']->operation_invoice_created_by;

	//	var_dump($data['value']);die;

		$this->load->view('admin/layouts/header');
		$this->load->view('admin/admission_form/intack_output_chart',$data);
		$this->load->view('admin/layouts/footer');			
	}
	
	public function discharge_certificate($record_id){
		$data['title'] = 'View Patient Admission';
        $data['page_title'] = 'View Patient Admission';
        $data['info_header'] = '';
        $data['redirect'] =  base_url('admission_form');

        $where = array('operation_invoice.record_id'=>$record_id);
		$options = array(
			'joins' => array(
				array(
					'table' => 'patient',
					'condition' => 'patient.record_id = operation_invoice.patient_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor referring_sergeon',
					'condition' => 'referring_sergeon.record_id = operation_invoice.referring_physician',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor sergeon',
					'condition' => 'sergeon.record_id = operation_invoice.sergeon_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor anesthesia',
					'condition' => 'anesthesia.record_id = operation_invoice.anesthesia_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation referring_sergeon_designation',
					'condition' => 'referring_sergeon_designation.record_id = referring_sergeon.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation sergeon_designation',
					'condition' => 'sergeon_designation.record_id = sergeon.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation anesthesia_designation',
					'condition' => 'anesthesia_designation.record_id = anesthesia.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_category',
					'condition' => 'operation_category.record_id = operation_invoice.operation_category_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_name',
					'condition' => 'operation_name.record_id = operation_invoice.operation_name_id',
					'jointype' => 'LEFT'
				),array(
					'table' => 'beds',
					'condition' => 'beds.record_id = operation_invoice.bed_id',
					'jointype' => 'LEFT'
				),
			),
			'select' => 'operation_invoice.*,operation_invoice.created_by as operation_invoice_created_by,operation_invoice.record_id as operation_invoice_record_id,patient.name as patient_name,patient.record_id as patient_id,patient.age as patient_age,patient.address as patient_address,patient.gender as patient_gender,patient.patient_father_name as patient_father_name,patient.patient_mother_name as patient_mother_name,patient.patient_spouse_name as patient_spouse_name,patient.patient_blood_group as patient_blood_group,patient.patient_occupation as patient_occupation,patient.mobile as patient_mobile,operation_invoice.address as re_address,referring_sergeon.name as referring_sergeon_name,referring_sergeon_designation.designation as referring_sergeon_designation,sergeon.name as sergeon_name,sergeon_designation.designation as sergeon_designation,anesthesia.name as anesthesia_name,anesthesia_designation.designation as anesthesia_designation,operation_category.category_name,operation_name.operation_name,beds.*,operation_invoice.created_at as admission_created_at, patient.village, patient.post_office, patient.thana, patient.district',
			'where' => $where,
			'order' => array(
				'operation_invoice.record_id' => 'asc',
			),
		);
		$data['value'] = $this->Common_model->commonJoinsRow("operation_invoice", $options);
		$data['value']->created_by = $data['value']->operation_invoice_created_by;

		$prescription = $this->db->get_where('prescription', ['prescription_operation_invoice_id' => $record_id])->row();

		// ddd($prescription);

		if($prescription){
			$data['prescription'] = $prescription;
			$data['prescribed_medicines'] = $this->db->select('product_name.product_name, generic_names.generic_name, meal_types.meal_type_name, prescription_details.days, prescription_details.dose')
			->from('prescription_details')
			->join('product_name', 'product_name.record_id = prescription_details.medicine_id')
			->join('generic_names', 'generic_names.record_id = product_name.product_category_generic_name_id', 'left')->join('types_of_medicine', 'types_of_medicine.record_id = prescription_details.medicine_type_id', 'left')
			->join('meal_types', 'meal_types.record_id = prescription_details.meal_type_id', 'left')
			->where('prescription_details.prescription_id', $prescription->record_id)
			->get()->result();

			// ddd($this->db->last_query());
			// ddd($data['prescribed_medicines']);
		}

		// ddd($data['prescribed_medicines']);
		
		$data['values'] = $this->Common_model->findAll('prescription_details',array('prescription_id'=>$record_id),'record_id','asc');

	//	var_dump($data['value']);die;

		$this->load->view('admin/layouts/header');
		if($data['value']->form_type == 'ICU'){
			$this->load->view('admin/admission_form/discharge_certificate_icu',$data);
		}else{
		$this->load->view('admin/admission_form/discharge_certificate',$data);
		}
		$this->load->view('admin/layouts/footer');			
	}
	
	public function make_prescription($record_id){
		$data['title'] = 'Discharge Treatment';
        $data['page_title'] = 'Discharge Treatment';
        $data['info_header'] = '';
        $data['redirect'] =  base_url('admission_form');

        $where = array('operation_invoice.record_id'=>$record_id);
		$options = array(
			'joins' => array(
				array(
					'table' => 'patient',
					'condition' => 'patient.record_id = operation_invoice.patient_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor referring_sergeon',
					'condition' => 'referring_sergeon.record_id = operation_invoice.referring_physician',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor sergeon',
					'condition' => 'sergeon.record_id = operation_invoice.sergeon_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor anesthesia',
					'condition' => 'anesthesia.record_id = operation_invoice.anesthesia_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation referring_sergeon_designation',
					'condition' => 'referring_sergeon_designation.record_id = referring_sergeon.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation sergeon_designation',
					'condition' => 'sergeon_designation.record_id = sergeon.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation anesthesia_designation',
					'condition' => 'anesthesia_designation.record_id = anesthesia.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_category',
					'condition' => 'operation_category.record_id = operation_invoice.operation_category_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_name',
					'condition' => 'operation_name.record_id = operation_invoice.operation_name_id',
					'jointype' => 'LEFT'
				),array(
					'table' => 'beds',
					'condition' => 'beds.record_id = operation_invoice.bed_id',
					'jointype' => 'LEFT'
				),
			),
			'select' => 'operation_invoice.*,operation_invoice.created_by as operation_invoice_created_by,operation_invoice.record_id as operation_invoice_record_id,patient.name as patient_name,patient.record_id as patient_id,patient.age as patient_age,patient.address as patient_address,patient.gender as patient_gender,patient.patient_father_name as patient_father_name,patient.patient_mother_name as patient_mother_name,patient.patient_spouse_name as patient_spouse_name,patient.patient_blood_group as patient_blood_group,patient.patient_occupation as patient_occupation,patient.mobile as patient_mobile,operation_invoice.address as re_address,referring_sergeon.name as referring_sergeon_name,referring_sergeon_designation.designation as referring_sergeon_designation,sergeon.name as sergeon_name,sergeon_designation.designation as sergeon_designation,anesthesia.name as anesthesia_name,anesthesia_designation.designation as anesthesia_designation,operation_category.category_name,operation_name.operation_name,beds.*,operation_invoice.created_at as admission_created_at',
			'where' => $where,
			'order' => array(
				'operation_invoice.record_id' => 'asc',
			),
		);
		$data['value'] = $this->Common_model->commonJoinsRow("operation_invoice", $options);
		$data['value']->created_by = $data['value']->operation_invoice_created_by;

		$data['prescription_data'] = $this->Common_model->getDCPresctioptionData($record_id);

// 		ddd($data['value']);

		$this->load->view('admin/layouts/header');
		$this->load->view('admin/admission_form/make_prescription',$data);
		$this->load->view('admin/layouts/footer');			
	}

	public function prescription_saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff" || $user_type == "doctor") {
            $input = $_POST ;
			// ddd($_POST);
            $update_id = $input['update_id'] ;
            $operation_invoice_record_id = $input['operation_invoice_record_id'] ;
            unset($input['update_id']);
            $date = date('Y-m-d');
            $prescription_details_ids = $input['prescription_details_id'];
            $test_ids = $input['test_id'];
            if(is_array($test_ids)) $test_ids = implode(',', $test_ids);
            $input['test_ids'] = $test_ids ;
            $medicine_ids = $input['medicine_id'];
            $medicine_type_ids = $input['medicine_type_id'];
            $doses = $input['dose'];
            $meal_type_ids = $input['meal_type_id'];
            $dayses = $input['days'];

            unset($input['prescription_details_id']);
            unset($input['test_id']);
            unset($input['medicine_id']);
            unset($input['medicine_type_id']);
            unset($input['dose']);
            unset($input['meal_type_id']);
            unset($input['days']);
            unset($input['test_name']);

            $prefix = date("Ymd",strtotime($date));
            $maxPrescription = $this->Common_model->findMax('prescription',array('prefix'=>$prefix),'prescription_no');
            $prescription_no = isset($maxPrescription)?$maxPrescription->prescription_no + 1 : 1 ;

            $input['prefix'] = $prefix ;
            $input['prescription_no'] = $prescription_no ;
            $input['date'] = $date ;

            // ddd($input);
            if($update_id == 0 || empty($update_id)){       
                $insert = $this->Common_model->saveData('prescription', $input);
                foreach ($medicine_ids as $key => $value) {
                    $data = array(
                        'prescription_id'=>$insert,
                        'medicine_id' => $medicine_ids[$key],
                        'medicine_type_id' => $medicine_type_ids[$key],
                        'dose' => $doses[$key],
                        'meal_type_id' => $meal_type_ids[$key],
                        'days' => $dayses[$key],
                    );
                    $this->Common_model->saveData('prescription_details', $data);
                }
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
                $update_id = $insert ;
            } else {

                $prescription = $this->Common_model->findById('prescription',array('record_id'=>$update_id));
                if(isset($prescription)){
                    if($prescription->date == $date){
                        $input['prescription_no'] = $prescription->prescription_no ;
                    }
                }
                $update = $this->Common_model->updateData('prescription', $input,array('record_id'=>$update_id));

				$this->db->update('prescription_details', ['deleted_at'=> date("Y-m-d")], ['prescription_id' => $update_id]);

                foreach ($medicine_ids as $key => $value) {
                    $prescription_detail_id = $prescription_details_ids[$key];
                    $data = array(
                        'prescription_id'=>$update_id,
                        'medicine_id' => $value,
                        'medicine_type_id' => $medicine_type_ids[$key],
                        'dose' => $doses[$key],
                        'meal_type_id' => $meal_type_ids[$key],
                        'days' => $dayses[$key],
                        'deleted_at' => NULL,
                    );
                    if($prescription_detail_id){
                        $this->Common_model->updateData('prescription_details', $data, array('record_id'=>$prescription_detail_id));
                    }else{
                        $this->Common_model->saveData('prescription_details', $data);
                    }                   
					// ddd($this->db->last_query());
                }
				
				$this->db->delete('prescription_details', ['deleted_at IS NOT NULL' => NULL, 'prescription_id' => $update_id]); 

                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
                // redirect("prescription/view2/$update_id", 'refresh');
				
            }
            redirect("admission_form/discharge_certificate/".$input['prescription_operation_invoice_id'], 'refresh');
           // var_dump("Called");die;
		   
		   $pres_data = array(
				'prescription_data' => $this->Common_model->findById('prescription',['prescription_operation_invoice_id' => $input['prescription_operation_invoice_id']],'record_id ','asc'),
				
				'prescription_details_data' => $this->Common_model->findAll('prescription_details',['prescription_id' => $update_id],'record_id ','asc'),
		   );
		   redirect("prescription/view2/$update_id", 'refresh');
            //redirect("admission_form/discharge_certificate/$operation_invoice_record_id", $pres_data);
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
		
    }

	public function investigation($record_id){
		$data['title'] = 'View Patient Admission';
        $data['page_title'] = 'View Patient Admission';
        $data['info_header'] = '';
        $data['redirect'] =  base_url('admission_form');

        $where = array('operation_invoice.record_id'=>$record_id);
		$options = array(
			'joins' => array(
				array(
					'table' => 'patient',
					'condition' => 'patient.record_id = operation_invoice.patient_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor sergeon',
					'condition' => 'sergeon.record_id = operation_invoice.sergeon_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor anesthesia',
					'condition' => 'anesthesia.record_id = operation_invoice.anesthesia_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_category',
					'condition' => 'operation_category.record_id = operation_invoice.operation_category_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_name',
					'condition' => 'operation_name.record_id = operation_invoice.operation_name_id',
					'jointype' => 'LEFT'
				),array(
					'table' => 'beds',
					'condition' => 'beds.record_id = operation_invoice.bed_id',
					'jointype' => 'LEFT'
				),
			),
			'select' => 'operation_invoice.*,operation_invoice.record_id as operation_invoice_record_id,patient.name as patient_name,patient.age as patient_age,patient.gender as patient_gender,patient.mobile as patient_mobile,operation_invoice.address as re_address,sergeon.name as sergeon_name,sergeon.designation as sergeon_designation,anesthesia.name as anesthesia_name,anesthesia.designation as anesthesia_designation,operation_category.category_name,operation_name.operation_name,beds.*',
			'where' => $where,
			'order' => array(
				'operation_invoice.record_id' => 'asc',
			),
		);
		$data['value'] = $this->Common_model->commonJoinsRow("operation_invoice", $options);

		$this->load->view('admin/layouts/header');
		$this->load->view('admin/admission_form/investigation',$data);
		$this->load->view('admin/layouts/footer');			
	}

	public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
			$operationInvoice = $this->Common_model->findById('operation_invoice',array('record_id'=>$id)) ;
            if($this->Common_model->delete_info('record_id', $id, 'operation_invoice')){
				$this->db->update('admission_fee_invoice', array('patient_status'=>'New'), array('record_id'=>$operationInvoice->admission_id));
				$this->Common_model->updateData('beds', array('bed_status'=>'Vacant'), array('record_id'=>$operationInvoice->bed_id));

                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
            redirect('admission_form', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

	public function get_operation_name(){
		$operation_category_id = $this->input->post('operation_category_id');
		$names = $this->Common_model->findAll('operation_name',['category_id' => $operation_category_id],'operation_name','asc');
        $option = "<option value=''>-- Select --</option>";
      	foreach($names as $name){
      		$option .= "<option value='$name->record_id' data-operation_price='$name->rate'>$name->operation_name</option>";	
      	}                              
		echo $option;
		exit ;
	}

	public function get_bed_info(){
		$opd_cabin_ward = $this->input->post('opd_cabin_ward');
		$bedId = $this->input->post('bedId')??null;
		$names = $this->Common_model->findAll('beds',['opd_cabin_ward' => $opd_cabin_ward],'bed_no','asc');
        $option = "<option value=''>-- Select --</option>";
      	foreach($names as $name){
			$selected = !empty($bedId) && $bedId == $name->record_id?'selected':'';
      		$option .= "<option value='$name->record_id' $selected  data-bed_no='$name->bed_no'  data-bed_type='$name->bed_type'  data-floor_no='$name->floor_no'  data-room_no='$name->room_no' data-charge='$name->charge'> $name->bed_no - $name->bed_type - $name->room_no - $name->floor_no </option>";	
      	}                              
		echo $option;
		exit ;
	}
	
    public function generate_barcode_image($code_no) {
        $number = str_pad($code_no, 6, '0', STR_PAD_LEFT);
        $this->zend->load('Zend/Barcode');
        Zend_Barcode::render('code128', 'image', array('text'=>$number, 'drawText' => false, 'barHeight' => 30, 'withQuietZones' => false), array());
    }
}
