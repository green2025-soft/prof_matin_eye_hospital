<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Operation_name extends CI_Controller {

    static $helper   = array('utility');
    public function __construct() {
        parent::__construct();
        $this->load->model('Common_model');
        $this->load->helper(self::$helper);
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'IPD Service Name';
            $data['page_title'] = 'IPD Service Name';
            $data['info_header'] = 'All IPD Service Name Info.';
            $data['values'] = $this->Common_model->findAll('operation_name',array(),'record_id','desc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/operation_name/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            unset($input['update_id']);
            $operation_name = $input['operation_name'];
            $category_id = $input['category_id'];
            if($update_id == 0 || empty($update_id)){       
                $getRow = $this->Common_model->findById('operation_name',array('category_id'=>$category_id,'operation_name'=>$operation_name));
                if(isset($getRow)){
                    $this->session->set_flashdata('message', EXIST_MSG);
                    redirect('operation_name', 'refresh');
                }
                $insert = $this->Common_model->saveData('operation_name', $input);
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $update = $this->Common_model->updateData('operation_name', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            redirect('operation_name', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $id, 'operation_name')){
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
            redirect('operation_name', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
