<?php

defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Login extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('upload');
        $this->load->model('Common_model');
    }

    public function index()
    {
        if ($this->session->userdata('ses_logged') == "YES") {
            $data['title'] = 'Dashboard';
            $today = date('Y-m-d');
            $data['response'] = $this->monthly_balance();
            $data['daily_sum'] = $this->daily_balance($today);
            $data['chart'] = $this->chart($today);
            $this->load->view('admin/layouts/headerdb');
            $this->load->view('admin/layouts/dashboard', $data);
            $this->load->view('admin/layouts/footerdb');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login', $data);
        }
    }

    public function block_msg()
    {
        $data['wrong_msg'] = "Sorry! Your ID is inactive now<br>Please Contact with Help Care";
        $this->load->view('website/login', $data);
    }

    public function login()
    {
		$bill = 'https://greensoftwarebd.com/api/check_payment_status/160';
		 $response = file_get_contents($bill);
		$payment = json_decode($response,true);
		
		
			
			if($payment['code'] == 200 && $payment['data']['expire'] < date('Y-m-d')){
				redirect('login');
			
		}else{
				
		
        $this->form_validation->set_rules('user_id', 'User ID', 'trim|required');
        $this->form_validation->set_rules('password', 'Password', 'trim|required');
        //$this->form_validation->set_rules('user_type', 'User Type', 'trim|required');

        if ($this->form_validation->run() == FALSE) {
            $data['wrong_msg'] = "";
            $this->load->view('website/login', $data);
        } else {
            $user_id = $this->input->post('user_id');
            $password = $this->input->post('password');
            // $user_type = $this->input->post('user_type');
            $block_status = 0;
            $has_user = 0;
            $checking_array = array("name" => $user_id, "password" => $password);
            $result = $this->Common_model->check_value_get_data('admin', $checking_array);
            if ($result) {
                $has_user = 1;
                foreach ($result as $result_info) {
                    $record_id = $result_info->record_id;
                    $unique_id = $result_info->admin_unique_id;
                    $password = $result_info->password;
                    $mobile = $result_info->mobile;
                    $username = $result_info->name;
                    $discount_limit = $result_info->discount_limit;
                }
                $user_type = 'admin';
            }
            $checking_array = array("username" => $user_id, "password" => $password);
            $result = $this->Common_model->check_value_get_data('staff', $checking_array);
            if ($result) {
                $menu_ids = $result[0]->menu_ids;
                if (empty($menu_ids)) {
                    redirect("/");
                }
                $has_user = 1;
                $user_type = 'staff';
                foreach ($result as $result_info) {
                    $block_status = $result_info->block_status;
                    $record_id = $result_info->record_id;
                    $unique_id = $result_info->username;
                    $password = $result_info->password;
                    $mobile = $result_info->mobile;
                    $username = $result_info->name;
                    $hr_access = $result_info->hr_access;
                    $inventory_access = $result_info->inventory_access;
                    $billing_access = $result_info->billing_access;
                    $accounting_access = $result_info->accounting_access;
                    $sales_access = $result_info->sales_access;
                    $createOption_access = $result_info->createOption_access;
                    $laboratory_access = $result_info->laboratory_access;
                    $information_access = $result_info->information_access;
                    $webpart_access = $result_info->webpart_access;
                    $discount_limit = $result_info->discount_limit;
                }
                $ses_data_permission = array(
                    'ses_hr_access' => $hr_access,
                    'ses_inventory_access' => $inventory_access,
                    'ses_billing_access' => $billing_access,
                    'ses_accounting_access' => $accounting_access,
                    'ses_sales_access' => $sales_access,
                    'ses_createOption_access' => $createOption_access,
                    'ses_laboratory_access' => $laboratory_access,
                    'ses_information_access' => $information_access,
                    'ses_webpart_access' => $webpart_access,
                    'discount_limit' => $discount_limit
                    
                );
                $this->session->set_userdata($ses_data_permission);
            }
            $where = array();
            $where['username'] = $user_id;
            $where['password'] = $password;
            $doctor = $this->Common_model->findById('doctor', $where);
            if (isset($doctor)) {
                $has_user = 1;
                $record_id = $doctor->record_id;
                $unique_id = $doctor->username;
                $password = $doctor->password;
                $mobile = $doctor->mobile;
                $username = $doctor->username;
                $user_type = 'doctor';
            }


            if ($block_status == 1) {
                redirect('Log_in_out/block_msg', 'refresh');
            } elseif ($has_user == 1) {
                $sesdata = array(
                    'ses_record_id' => $record_id,
                    'ses_username' => $username,
                    'ses_mobile' => $mobile,
                    'ses_unique_id' => $unique_id,
                    'ses_password' => $password,
                    'ses_user_type' => $user_type,
                    'ses_logged' => "YES",
                    'discount_limit' => $discount_limit
                );
                $this->session->set_userdata($sesdata);

                $data['title'] = 'Dashboard';

                redirect('login');
                /* $this->load->view('admin/layouts/header');
                $this->load->view('admin/layouts/dashboard', $data);
                $this->load->view('admin/layouts/footer'); */
            } else {
                redirect('login');
                //$data['wrong_msg'] = "Wrong Name/Password";
                // $this->load->view('website/login', $data);
            }
        }
		}
    }

    public function logout()
    {
        $user_type = $this->session->ses_user_type;
        if ($this->session->userdata('ses_logged') == "YES") {
            if ($user_type == "staff") {
                $logout_array = array(
                    'ses_record_id', 'ses_unique_id', 'ses_password', 'ses_user_type', 'ses_logged',
                    'ses_hr_access', 'ses_inventory_access', 'ses_pharmacy_access', 'ses_billing_access',
                    'ses_management_access', 'ses_accounting_access', 'ses_others_access', 'ses_purchase_access',
                    'ses_sales_access', 'ses_product_in_out_access', 'ses_income_access', 'ses_expense_access',
                    'ses_prescription_access'
                );
            } else {
                $logout_array = array('ses_record_id', 'ses_unique_id', 'ses_username', 'ses_password', 'ses_mobile', 'ses_user_type', 'ses_logged');
            }
            $this->session->unset_userdata($logout_array);
            redirect('/', 'refresh');
        }
    }


    public function user_profile()
    {
        $record_id = $this->session->userdata('ses_record_id');
        $msg = '';
        $ses_user_type = $this->session->userdata('ses_user_type');
        if ($ses_user_type == "admin" || $ses_user_type == "staff" || $ses_user_type == "doctor") {
            $data['designations'] = $this->Common_model->findAll('designation', array(), 'designation', 'asc');
            $data['msg'] = $msg;
            if ($ses_user_type == 'admin') {
                $data['admin'] = $this->Common_model->findById('admin', array('record_id' => $record_id));
                $page = 'admin/profile/admin_profile';
            } elseif ($ses_user_type == 'staff') {
                $data['staff'] = $this->Common_model->findById('staff', array('record_id' => $record_id));
                $page = 'admin/profile/user_profile';
            } elseif ($ses_user_type == 'doctor') {
                $data['doctor'] = $this->Common_model->findById('doctor', array('record_id' => $record_id));
                $page = 'admin/profile/doctor_profile';
            }
            $this->load->view('admin/layouts/header');
            $this->load->view($page, $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login', $data);
        }
    }
    public function update_admin_profile()
    {
        $record_id = $this->session->userdata('ses_record_id');
        $msg = '';
        $ses_user_type = $this->session->userdata('ses_user_type');
        if ($ses_user_type == "admin") {

            $data['designations'] = $this->Common_model->findAll('designation', array(), 'designation', 'asc');
            $data['msg'] = $msg;

            $data['staff'] = $this->Common_model->findById('admin', array('record_id' => $record_id));
            $page = 'admin/profile/admin_profile_update';

            $this->load->view('admin/layouts/header');
            $this->load->view($page, $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login', $data);
        }
    }

    public function update_doctor_profile()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff" || $user_type == "doctor") {
            $input = $_POST;
            $popup = $this->input->post('popup');
            $specialists = $this->input->post('specialists');
            // var_dump($specialists);die;
            if (isset($specialists)) {
                $input['specialists'] = implode(',', $specialists);
            }
            $update_id = $input['update_id'];
            $name = $input['name'];
            $designation_id = $input['designation_id'];
            $mobile = $input['mobile'];
            unset($input['update_id']);


            $config['upload_path']      = 'assets/img/doctors/';
            $config['allowed_types']    = '*';
            $config['max_size']         = '0';
            //$config['file_name']      = time(); 
            $file_field                 = "photo";
            $this->upload->initialize($config);


            if ($update_id == 0 || empty($update_id)) {
                $getRow = $this->Common_model->findById('doctor', array('name' => $name, 'designation_id' => $designation_id, 'mobile' => $mobile));
                if (isset($getRow)) {
                    $this->session->set_flashdata('message', EXIST_MSG);
                    if (isset($popup)) {
                        echo "This doctor has been already been taken!";
                        exit(0);
                    }
                    redirect('doctor', 'refresh');
                }
                if (isset($popup)) {
                    unset($input['popup']);
                }
                if (!empty($_FILES[$file_field]["name"])) {
                    if ($this->upload->do_upload($file_field)) {
                        $uploadData = $this->upload->data();
                        $input['photo'] =   $config['upload_path'] . $uploadData['file_name'];
                    }
                }
                $insert = $this->Common_model->saveData('doctor', $input);
                if ($insert) {
                    $this->session->set_flashdata('message', INSERT_MSG);
                } else {
                    $this->session->set_flashdata('message', INSERT_ERROR_MSG);
                }
                if (isset($popup)) {
                    $doctor = $this->Common_model->findById('doctor', array('record_id' => $insert));
                    echo json_encode($doctor);
                    exit(0);
                }
            } else {
                $info = $this->Common_model->findById('doctor', array('record_id' => $update_id));
                if (!empty($_FILES[$file_field]["name"])) {
                    if (file_exists($info->photo) && !empty($info->photo)) {
                        unlink('./' . $info->photo);
                    }
                    if ($this->upload->do_upload($file_field)) {
                        $uploadData = $this->upload->data();
                        $input['photo'] =   $config['upload_path'] . $uploadData['file_name'];
                    }
                }

                $update = $this->Common_model->updateData('doctor', $input, array('record_id' => $update_id));
                if ($update) {
                    $this->session->set_flashdata('message', UPDATE_MSG);
                } else {
                    $this->session->set_flashdata('message', UPDATE_ERROR_MSG);
                }
            }
            redirect('user/profile', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    private function monthly_balance($month = '')
    {
        $reference_commission = 0;
        $pathologyWhere = array();
        if (!empty($month)) $pathologyWhere['date like '] = '%' . $month . '%';
        $pathologyWhere['type'] = 'Test Invoice';
        if (!empty($month)) $operationWhere['date like '] = '%' . $month . '%';

        if (!empty($month)) $operationInvoiceWhere['date like '] = '%' . $month . '%';
        $operationInvoiceWhere['type'] = 'Admission';
        $operationWhere['type'] = 'Operation';

        $operationDetailsWhere = array();
        if (!empty($month)) $operationDetailsWhere['operation_date'] = '%' . $month . '%';

        $generalIncomeWhere = array();
        if (!empty($month)) $generalIncomeWhere['date like '] = '%' . $month . '%';

        $consultancyWhere = array();
        $consultancyWhere['type'] = 'Appointment';
        $consultancyWhere['doctor_visit_payment_status'] = 'Paid';
        if (!empty($month)) $consultancyWhere['date like '] = '%' . $month . '%';

        $commission_patholgyWhere = array();
        $commission_patholgyWhere['type'] = 'Test Invoice';
        if (!empty($month)) $commission_patholgyWhere['date like '] = '%' . $month . '%';



        $operation_commissionWhere = array();
        if (!empty($month)) $operation_commissionWhere['operation_date'] = '%' . $month . '%';

        $sonologistExpenseWhere = array();
        if (!empty($month)) $sonologistExpenseWhere['date like '] = '%' . $month . '%';

        $generalExpenseWhere = array();
        if (!empty($month)) $generalExpenseWhere['date like '] = '%' . $month . '%';
        $staffSalaryWhere = array();
        $staffSalaryWhere['status'] = 'Paid';
        if (!empty($month)) $staffSalaryWhere['date like '] = '%' . $month . '%';

        $dueCollectionWhere = array();
        if (!empty($month)) $dueCollectionWhere['mr_date'] = '%' . $month . '%';


        $salesWhere = array();
        $salesWhere['sales_from'] = 'Direct';
        if (!empty($month)) $salesWhere['sales_date'] = '%' . $month . '%';

        $mrWhere = array();
        if (!empty($month)) $mrWhere['mr_date'] = '%' . $month . '%';

        $emergencyWhere = array();

        $emergencyWhere['type'] = 'Emergency';
        if (!empty($month)) $emergencyWhere['date like '] = '%' . $month . '%';

        $ambulanceWhere = array();

        $ambulanceWhere['type'] = 'Ambulance';
        if (!empty($month)) $ambulanceWhere['date like '] = '%' . $month . '%';

        $doctorServiceWhere = array();

        $doctorServiceWhere['type'] = 'Doctor Service';
        $doctorServiceWhere['date like '] = '%' . $month . '%';

        $donorWhere = array();

        $donorWhere['type'] = 'Donor';
        if (!empty($month)) $donorWhere['date like '] = '%' . $month . '%';

        $dressingWhere = array();

        $dressingWhere['type'] = 'Dressing';
        if (!empty($month)) $dressingWhere['date like '] = '%' . $month . '%';

        $supplier_paymentsWhere = array();
        if (!empty($month)) $supplier_paymentsWhere['payment_date'] = '%' . $month . '%';

        $incomeWhere = array();
        $incomeWhere['income_type != '] = 'Pharmacy';
        if (!empty($month)) $incomeWhere['income_date like '] = '%' . $month . '%';
        $expenseWhere = array();
        //  $expenseWhere['approval'] = 'Approved' ;
        $expenseWhere['expense_type != '] = 'Pharmacy';
        if (!empty($month)) $expenseWhere['expense_date like'] = '%' . $month . '%';

        $labInWhere = array();
        if (!empty($month)) $labInWhere['in_date like'] = '%' . $month . '%';

        $dressingWhere = array();

        $dressingWhere['type'] = 'Dressing';
        if (!empty($month)) $dressingWhere['date like '] = '%' . $month . '%';

        $pathology = $this->Common_model->calculateSumMultiple('create_bill', $pathologyWhere, array('amount', 'discount', 'sub_total', 'paid', 'due', 'doctor_commission', 'reference_by_commission'));

        $data['pathology_amount'] = isset($pathology) ? $pathology->amount : 0;
        $data['pathology_paid'] = isset($pathology) ? $pathology->paid : 0;
        $data['pathology_discount'] = isset($pathology) ? $pathology->discount : 0;
        $data['pathology_sub_total'] = isset($pathology) ? $pathology->sub_total : 0;
        $data['pathology_due'] = isset($pathology) ? $pathology->due : 0;
        $doctor_commission = isset($pathology) ? $pathology->doctor_commission : 0;
        $reference_by_commission = isset($pathology) ? $pathology->reference_by_commission : 0;
        $reference_commission += $reference_by_commission;
        $data['patholgy_commission'] = $doctor_commission + $reference_by_commission;

        $operation = $this->Common_model->calculateSumMultiple('create_bill', $operationWhere, array('amount', 'discount', 'sub_total', 'due'));
        $data['operation_amount'] = isset($operation) ? $operation->amount : 0;
        $data['operation_paid'] = isset($operation) ? $operation->paid : 0;
        $data['operation_discount'] = isset($operation) ? $operation->discount : 0;
        $data['operation_sub_total'] = isset($operation) ? $operation->sub_total : 0;
        $data['operation_due'] = isset($operation) ? $operation->due : 0;

        $operationInvoice = $this->Common_model->calculateSumMultiple('create_bill', $operationInvoiceWhere, array('sub_total', 'advance'));
        $data['operationInvoice'] = $operationInvoice->sub_total + $operationInvoice->advance;


        $consultancy = $this->Common_model->calculateSumMultiple('create_bill', $consultancyWhere, array('amount', 'discount', 'sub_total', 'paid', 'due', 'doctor_commission'));
        $data['consultancy_amount'] = isset($consultancy) ?  $consultancy->amount : 0;
        $data['consultancy_discount'] = isset($consultancy) ?  $consultancy->discount : 0;
        $data['consultancy_sub_total'] = isset($consultancy) ?  $consultancy->sub_total : 0;
        $data['consultancy_paid'] = isset($consultancy) ?  $consultancy->paid : 0;
        $data['consultancy_due'] = isset($consultancy) ?  $consultancy->due : 0;
        $data['consultancy_commission'] = isset($consultancy) ?  $consultancy->doctor_commission : 0;

        $operation_commission =  $this->Common_model->calculateSumMultiple('operation_details', $operationDetailsWhere, array('surgeon_commission', 'surgeon_assistant_commission', 'surgeon_team_commission', 'anesthesia_commission', 'medicine_cost', 'service_fee', 'reference_by_payment'));
        $surgeon_commission = isset($operation_commission) ? $operation_commission->surgeon_commission : 0;
        $anesthesia_commission = isset($operation_commission) ? $operation_commission->anesthesia_commission : 0;
        $medicine_cost = isset($operation_commission) ? $operation_commission->medicine_cost : 0;
        $surgeon_assistant_commission = isset($operation_commission) ? $operation_commission->surgeon_assistant_commission : 0;
        $surgeon_team_commission = isset($operation_commission) ? $operation_commission->surgeon_team_commission : 0;
        $service_fee = isset($operation_commission) ? $operation_commission->service_fee : 0;
        $reference_by_payment = isset($operation_commission) ? $operation_commission->reference_by_payment : 0;
        $reference_commission += $reference_by_payment;
        $data['operation_commission'] =  $surgeon_commission + $anesthesia_commission + $medicine_cost + $surgeon_assistant_commission + $surgeon_team_commission + $service_fee + $reference_by_payment;

        $data['sonologistExpense'] = $this->Common_model->calCulateSum('sonologist', $sonologistExpenseWhere, 'amount');
        $data['staffSalary'] = $this->Common_model->calCulateSum('create_salary_sheet', $staffSalaryWhere, 'net_salary');
        $data['dueCollection'] = $this->Common_model->calCulateSum('due_collections', $dueCollectionWhere, 'mr_amount');

        $sales_orders = $this->Common_model->calculateSumMultiple('sales_orders', $salesWhere, array('grand_net_total', 'paid_amount', 'due_amount'));
        $data['sales_amount'] = $sales_orders->grand_net_total;
        $data['sales_paid_amount'] = $sales_orders->paid_amount;
        $data['sales_due_amount'] = $sales_orders->due_amount;
        $data['pharmacy_collection'] = $this->Common_model->calCulateSum('mr', $mrWhere, 'mr_amount');

        $data['supplier_payments'] = $this->Common_model->calCulateSum('supplier_payments', $supplier_paymentsWhere, 'payment_amount');



        $emergency = $this->Common_model->calculateSumMultiple('create_bill', $emergencyWhere, array('amount', 'discount', 'sub_total', 'paid', 'doctor_commission', 'others_cost'));
        $data['emergency_amount'] = isset($emergency) ? $emergency->amount : 0;
        $data['emergency_discount'] = isset($emergency) ? $emergency->discount : 0;
        $data['emergency_sub_total'] = isset($emergency) ? $emergency->sub_total : 0;
        $data['emergency_paid'] = isset($emergency) ? $emergency->paid : 0;
        $emergency_commission = isset($emergency) ? $emergency->doctor_commission : 0;
        $emergency_others_cost = isset($emergency) ? $emergency->others_cost : 0;
        $data['emergency_commission'] = $emergency_commission + $emergency_others_cost;

        $ambulance = $this->Common_model->calculateSumMultiple('create_bill', $ambulanceWhere, array('amount', 'discount', 'sub_total', 'paid', 'fuel_cost', 'road_cost', 'service_maintanance_cost'));
        $data['ambulance_amount'] = isset($ambulance) ? $ambulance->amount : 0;
        $data['ambulance_discount'] = isset($ambulance) ? $ambulance->discount : 0;
        $data['ambulance_sub_total'] = isset($ambulance) ? $ambulance->sub_total : 0;
        $data['ambulance_paid'] = isset($ambulance) ? $ambulance->paid : 0;
        $data['ambulance_due'] = isset($ambulance) ? $ambulance->due : 0;
        $ambulance_fuel_cost = isset($ambulance) ? $ambulance->fuel_cost : 0;
        $ambulance_road_cost = isset($ambulance) ? $ambulance->road_cost : 0;
        $ambulance_service_maintanance_cost = isset($ambulance) ? $ambulance->service_maintanance_cost : 0;
        $data['ambulance_commission'] = $ambulance_fuel_cost + $ambulance_road_cost + $ambulance_service_maintanance_cost;


        $doctor_service = $this->Common_model->calculateSumMultiple('create_bill', $doctorServiceWhere, array('amount', 'discount', 'sub_total', 'paid', 'due', 'doctor_commission', 'reference_by_commission'));
        $data['doctor_service_amount'] = isset($doctor_service) ? $doctor_service->amount : 0;
        $data['doctor_service_discount'] = isset($doctor_service) ? $doctor_service->discount : 0;
        $data['doctor_service_sub_total'] = isset($doctor_service) ? $doctor_service->sub_total : 0;
        $data['doctor_service_paid'] = isset($doctor_service) ? $doctor_service->paid : 0;
        $data['doctor_service_due'] = isset($doctor_service) ? $doctor_service->due : 0;
        $doctor_service_reference_by_commission = isset($doctor_service) ? $doctor_service->reference_by_commission : 0;
        $doctor_service_commission = isset($doctor_service) ? $doctor_service->doctor_commission : 0;
        $data['doctor_service_commission'] = $doctor_service_reference_by_commission + $doctor_service_commission;

        $donor = $this->Common_model->calculateSumMultiple('create_bill', $donorWhere, array('amount', 'discount', 'sub_total', 'paid', 'due'));
        $data['donor_amount'] = isset($donor) ? $donor->amount : 0;
        $data['donor_discount'] = isset($donor) ? $donor->discount : 0;
        $data['donor_sub_total'] = isset($donor) ? $donor->sub_total : 0;
        $data['donor_paid'] = isset($donor) ? $donor->paid : 0;
        $data['donor_due'] = isset($donor) ? $donor->due : 0;

        $dressing = $this->Common_model->calculateSumMultiple('create_bill', $dressingWhere, array('amount', 'discount', 'sub_total', 'paid', 'doctor_commission', 'due'));
        $data['dressing_amount'] = isset($dressing) ? $dressing->amount : 0;
        $data['dressing_discount'] = isset($dressing) ? $dressing->discount : 0;
        $data['dressing_sub_total'] = isset($dressing) ? $dressing->sub_total : 0;
        $data['dressing_paid'] = isset($dressing) ? $dressing->paid : 0;
        $data['dressing_due'] = isset($dressing) ? $dressing->due : 0;
        $data['dressing_commission'] = isset($dressing) ? $dressing->doctor_commission : 0;

        $data['general_income'] = $this->Common_model->calCulateSum('incomes', $incomeWhere, 'voucher_amount');
        $data['general_expense'] = $this->Common_model->calCulateSum('expenses', $expenseWhere, 'voucher_amount');
        $data['lab_product'] = $this->Common_model->calCulateSum('lab_product_in', $labInWhere, 'grand_total_price');

        $data['total_amount'] = $data['pathology_amount'] +  $data['operation_amount'] + $data['operationInvoice'] +  $data['consultancy_amount'] + $data['emergency_amount']  + $data['ambulance_amount'] + $data['doctor_service_amount'] + $data['donor_amount'] + $data['dressing_amount']; // + $data['general_income'] ; // + $data['sales_paid_amount'] + $data['pharmacy_collection'] ;

        $data['total_discount_amount'] = $data['pathology_discount'] +  $data['operation_discount'] +  $data['consultancy_discount'] + $data['emergency_discount']  + $data['ambulance_discount'] + $data['doctor_service_discount'] + $data['donor_discount'] + $data['dressing_discount'];

        $data['total_sub_total'] = $data['pathology_sub_total'] +  $data['operation_sub_total'] +  $data['consultancy_sub_total'] + $data['emergency_sub_total']  + $data['ambulance_sub_total'] + $data['doctor_service_sub_total'] + $data['donor_sub_total'] + $data['dressing_sub_total'];

        $data['total_paid_amount'] = $data['pathology_paid'] +  $data['operation_paid'] +  $data['consultancy_paid'] + $data['emergency_paid']  + $data['ambulance_paid'] + $data['doctor_service_paid'] + $data['donor_paid'] + $data['dressing_paid'] + $data['dueCollection'] + $data['general_income'];

        $data['total_due_amount'] = $data['pathology_due'] +  $data['operation_due'] +  $data['consultancy_due'] + $data['emergency_due']  + $data['ambulance_due'] + $data['doctor_service_due'] + $data['donor_due'] + $data['dressing_due'] - $data['dueCollection'];

        $data['total_commission_amount'] = $data['patholgy_commission'] + $data['consultancy_commission']  + $data['operation_commission'] + $data['sonologistExpense'] + $data['staffSalary'] + $data['emergency_commission'] + $data['ambulance_commission']  + $data['doctor_service_commission'] + $data['general_expense'] + $data['lab_product'] + $data['dressing_commission'];

        $data['reference_commission'] = $reference_commission;

        return (object)$data;
    }

    public function daily_balance($date)
    {
        $reference_commission = 0;
        $pathologyWhere = array();
        $operationWhere = array();
        $operationadvWhere = array();
        if (!empty($date)) $pathologyWhere['date'] = $date;
        // $pathologyWhere['type'] = 'Test Invoice';

        $pathologyrefWhere = array();
        if (!empty($date)) $pathologyrefWhere['date like '] = $date;
        // $pathologyrefWhere['type'] = 'Test Invoice';
        $pathologyrefWhere['test_invoice_payment_status'] = 'Paid';
        $pathologyrefWhere['reference_by_commission >'] = 0;

        if (!empty($date)) $operationWhere['date like '] = $date;

        if (!empty($date)) $operationInvoiceWhere['date like '] = $date;
        $operationInvoiceWhere['type'] = 'Admission';
        $operationWhere['type'] = 'Operation';

        if (!empty($date)) $operationadvWhere['date like '] = $date;
        $operationadvWhere['type'] = 'AdmissionAdvance';
        

        $operationDetailsWhere = array();
        if (!empty($date)) $operationDetailsWhere['ref_comm_payment_date'] = $date;
        $operationDetailsWhere['ref_comm_payment_status'] = 'Paid';
        
        $operationExpenseWhere = array();
        if (!empty($date)) $operationExpenseWhere['payment_date'] = $date;
        $operationExpenseWhere['payment_status'] = 'Paid';

        $generalIncomeWhere = array();
        if (!empty($date)) $generalIncomeWhere['date like '] = $date;

        $consultancyWhere = array();
        $consultancyWhere['type'] = 'Appointment';
        if (!empty($date)) $consultancyWhere['date like '] = $date;

        $consultancyCommWhere = array();
        $consultancyCommWhere['type'] = 'Appointment';
        $consultancyCommWhere['doctor_visit_payment_status'] = 'Paid';
        if (!empty($date)) $consultancyCommWhere['doctor_visit_payment_date like '] = $date;

        $commission_patholgyWhere = array();
        $commission_patholgyWhere['type'] = 'Test Invoice';
        if (!empty($date)) $commission_patholgyWhere['date like '] = $date;



        $operation_commissionWhere = array();
        if (!empty($date)) $operation_commissionWhere['operation_date'] = $date;

        $sonologistExpenseWhere = array();
        if (!empty($date)) $sonologistExpenseWhere['date like '] = $date;

        $generalExpenseWhere = array();
        if (!empty($date)) $generalExpenseWhere['date like '] = $date;
        $staffSalaryWhere = array();
        $staffSalaryWhere['status'] = 'Paid';
        if (!empty($date)) $staffSalaryWhere['date like '] = $date;

        $staffSalaryAdvWhere = array();
        if (!empty($date)) $staffSalaryAdvWhere['date like '] = $date;

        $dueCollectionWhere = array();
        if (!empty($date)) $dueCollectionWhere['mr_date'] = $date;


        $salesWhere = array();
        $salesWhere['sales_from'] = 'Direct';
        if (!empty($date)) $salesWhere['sales_date'] = $date;

        $mrWhere = array();
        if (!empty($date)) $mrWhere['mr_date'] = $date;

        $emergencyWhere = array();

        $emergencyWhere['type'] = 'Emergency';
        if (!empty($date)) $emergencyWhere['date like '] = $date;

        $ambulanceWhere = array();

        $ambulanceWhere['type'] = 'Ambulance';
        if (!empty($date)) $ambulanceWhere['date like '] = $date;

        $doctorServiceWhere = array();

        $doctorServiceWhere['type'] = 'Doctor Service';
        $doctorServiceWhere['date like '] = $date;

        $donorWhere = array();

        $donorWhere['type'] = 'Donor';
        if (!empty($date)) $donorWhere['date like '] = $date;

        $dressingWhere = array();

        $dressingWhere['type'] = 'Dressing';
        if (!empty($date)) $dressingWhere['date like '] = $date;

        $supplier_paymentsWhere = array();
        if (!empty($date)) $supplier_paymentsWhere['payment_date'] = $date;

        $incomeWhere = array();
        $incomeWhere['income_type != '] = 'Pharmacy';
        if (!empty($date)) $incomeWhere['income_date like '] = $date;
        $expenseWhere = array();
        //  $expenseWhere['approval'] = 'Approved' ;
        $expenseWhere['expense_type != '] = 'Pharmacy';
        if (!empty($date)) $expenseWhere['expense_date like'] = $date;

        $labInWhere = array();
        if (!empty($date)) $labInWhere['in_date like'] = $date;

        $dressingWhere = array();

        $dressingWhere['type'] = 'Dressing';
        if (!empty($date)) $dressingWhere['date like '] = $date;

      
        $admissionWhere = array();
        if (!empty($date)) $admissionWhere['admission_date like '] = $date;

        $pathologyWhereIn = ['Test Invoice', 'IVF Test Invoice'];

        $pathology = $this->Common_model->calculateSumMultiple('create_bill', $pathologyWhere, array('amount', 'discount', 'sub_total', 'paid', 'due', 'doctor_commission', 'reference_by_commission'),$pathologyWhereIn, 'type');
        

        

        $pathology_ref = $this->Common_model->calculateSumMultiple('create_bill', $pathologyrefWhere, array('amount', 'discount', 'sub_total', 'paid', 'due', 'doctor_commission', 'reference_by_commission'), $pathologyWhereIn, 'type');

        $data['pathology_amount'] = isset($pathology) ? $pathology->amount : 0;
        $data['pathology_paid'] = isset($pathology) ? $pathology->paid : 0;
        $data['pathology_discount'] = isset($pathology) ? $pathology->discount : 0;
        $data['pathology_sub_total'] = isset($pathology) ? $pathology->sub_total : 0;
        $data['pathology_due'] = isset($pathology) ? $pathology->due : 0;
        $doctor_commission = isset($pathology) ? $pathology->doctor_commission : 0;
        //$reference_by_commission = isset($pathology) ? $pathology->reference_by_commission : 0;
        $reference_by_commission = isset($pathology_ref) ? $pathology_ref->reference_by_commission : 0;
        if($reference_by_commission >0){
            $ref_comm_dis = $reference_by_commission-$pathology_ref->discount;
        }else{
            $ref_comm_dis = $reference_by_commission;
        }
        $reference_commission = $ref_comm_dis;
        $data['patholgy_commission'] = $doctor_commission + $reference_commission;

        $operation = $this->Common_model->calculateSumMultiple('create_bill', $operationWhere, array('amount', 'discount', 'sub_total', 'due', 'paid'));
        $data['operation_amount'] = isset($operation) ? $operation->amount : 0;
        $data['operation_paid'] = isset($operation) ? $operation->paid : 0;
        
        $data['operation_discount'] = isset($operation) ? $operation->discount : 0;
        $data['operation_sub_total'] = isset($operation) ? $operation->sub_total : 0;
        $data['operation_due'] = isset($operation) ? $operation->due : 0;

        $operationInvoice = $this->Common_model->calculateSumMultiple('create_bill', $operationInvoiceWhere, array('sub_total', 'advance'));
        $data['operationInvoice'] = $operationInvoice->sub_total + $operationInvoice->advance;

        $data['operation_advance'] = $this->Common_model->calCulateSum('create_bill', $operationadvWhere, 'amount');
        

        $consultancy = $this->Common_model->calculateSumMultiple('create_bill', $consultancyWhere, array('amount', 'discount', 'sub_total', 'paid', 'due', 'doctor_commission'));
        $consultancy_commission = $this->Common_model->calculateSumMultiple('create_bill', $consultancyCommWhere, array('amount', 'discount', 'sub_total', 'paid', 'due', 'doctor_commission'));
        $data['consultancy_amount'] = isset($consultancy) ?  $consultancy->amount : 0;
        $data['consultancy_discount'] = isset($consultancy) ?  $consultancy->discount : 0;
        $data['consultancy_sub_total'] = isset($consultancy) ?  $consultancy->sub_total : 0;
        $data['consultancy_paid'] = isset($consultancy) ?  $consultancy->paid : 0;
        $data['consultancy_due'] = isset($consultancy) ?  $consultancy->due : 0;
        $data['consultancy_commission'] = isset($consultancy_commission) ?  $consultancy_commission->doctor_commission : 0;

        $operation_commission =  $this->Common_model->calculateSumMultiple('operation_details', $operationDetailsWhere, array('reference_by_commission'));
        $operation_expense =  $this->Common_model->calculateSumMultiple('operation_expense', $operationExpenseWhere, array('surgeon_commission', 'surgeon_assistant_commission', 'surgeon_team_commission', 'anesthesia_commission', 'medicine_cost', 'service_fee'));
        $surgeon_commission = isset($operation_expense) ? $operation_expense->surgeon_commission : 0;
        $anesthesia_commission = isset($operation_expense) ? $operation_expense->anesthesia_commission : 0;
        $medicine_cost = isset($operation_expense) ? $operation_expense->medicine_cost : 0;
        $surgeon_assistant_commission = isset($operation_expense) ? $operation_expense->surgeon_assistant_commission : 0;
        $surgeon_team_commission = isset($operation_expense) ? $operation_expense->surgeon_team_commission : 0;
        $service_fee = isset($operation_expense) ? $operation_expense->service_fee : 0;
        $reference_by_payment = isset($operation_commission) ? $operation_commission->reference_by_commission : 0;
        $reference_commission += $reference_by_payment;
        $data['operation_commission'] =  $surgeon_commission + $anesthesia_commission + $medicine_cost + $surgeon_assistant_commission + $surgeon_team_commission + $service_fee + $reference_by_payment;

        $data['sonologistExpense'] = $this->Common_model->calCulateSum('sonologist', $sonologistExpenseWhere, 'amount');
        $data['staffSalary'] = $this->Common_model->calCulateSum('create_salary_sheet', $staffSalaryWhere, 'net_salary');
        $data['staffSalaryAdv'] = $this->Common_model->calCulateSum('create_salary_sheet_advanced', $staffSalaryAdvWhere, 'advanced_amount');
        $data['dueCollection'] = $this->Common_model->calCulateSum('due_collections', $dueCollectionWhere, 'mr_amount');

        $sales_orders = $this->Common_model->calculateSumMultiple('sales_orders', $salesWhere, array('grand_net_total', 'paid_amount', 'due_amount'));
        $data['sales_amount'] = $sales_orders->grand_net_total;
        $data['sales_paid_amount'] = $sales_orders->paid_amount;
        $data['sales_due_amount'] = $sales_orders->due_amount;
        $data['pharmacy_collection'] = $this->Common_model->calCulateSum('mr', $mrWhere, 'mr_amount');

        $data['supplier_payments'] = $this->Common_model->calCulateSum('supplier_payments', $supplier_paymentsWhere, 'payment_amount');



        $emergency = $this->Common_model->calculateSumMultiple('create_bill', $emergencyWhere, array('amount', 'discount', 'sub_total', 'paid', 'doctor_commission', 'others_cost'));
        $data['emergency_amount'] = isset($emergency) ? $emergency->amount : 0;
        $data['emergency_discount'] = isset($emergency) ? $emergency->discount : 0;
        $data['emergency_sub_total'] = isset($emergency) ? $emergency->sub_total : 0;
        $data['emergency_paid'] = isset($emergency) ? $emergency->paid : 0;
        $emergency_commission = isset($emergency) ? $emergency->doctor_commission : 0;
        $emergency_others_cost = isset($emergency) ? $emergency->others_cost : 0;
        $data['emergency_commission'] = $emergency_commission + $emergency_others_cost;

        $ambulance = $this->Common_model->calculateSumMultiple('create_bill', $ambulanceWhere, array('amount', 'discount', 'sub_total', 'paid', 'fuel_cost', 'road_cost', 'service_maintanance_cost'));
        $data['ambulance_amount'] = isset($ambulance) ? $ambulance->amount : 0;
        $data['ambulance_discount'] = isset($ambulance) ? $ambulance->discount : 0;
        $data['ambulance_sub_total'] = isset($ambulance) ? $ambulance->sub_total : 0;
        $data['ambulance_paid'] = isset($ambulance) ? $ambulance->paid : 0;
        $data['ambulance_due'] = isset($ambulance) ? $ambulance->due : 0;
        $ambulance_fuel_cost = isset($ambulance) ? $ambulance->fuel_cost : 0;
        $ambulance_road_cost = isset($ambulance) ? $ambulance->road_cost : 0;
        $ambulance_service_maintanance_cost = isset($ambulance) ? $ambulance->service_maintanance_cost : 0;
        $data['ambulance_commission'] = $ambulance_fuel_cost + $ambulance_road_cost + $ambulance_service_maintanance_cost;


        $doctor_service = $this->Common_model->calculateSumMultiple('create_bill', $doctorServiceWhere, array('amount', 'discount', 'sub_total', 'paid', 'due', 'doctor_commission', 'reference_by_commission'));
        $data['doctor_service_amount'] = isset($doctor_service) ? $doctor_service->amount : 0;
        $data['doctor_service_discount'] = isset($doctor_service) ? $doctor_service->discount : 0;
        $data['doctor_service_sub_total'] = isset($doctor_service) ? $doctor_service->sub_total : 0;
        $data['doctor_service_paid'] = isset($doctor_service) ? $doctor_service->paid : 0;
        $data['doctor_service_due'] = isset($doctor_service) ? $doctor_service->due : 0;
        $doctor_service_reference_by_commission = isset($doctor_service) ? $doctor_service->reference_by_commission : 0;
        $doctor_service_commission = isset($doctor_service) ? $doctor_service->doctor_commission : 0;
        $data['doctor_service_commission'] = $doctor_service_reference_by_commission + $doctor_service_commission;

        $donor = $this->Common_model->calculateSumMultiple('create_bill', $donorWhere, array('amount', 'discount', 'sub_total', 'paid', 'due'));
        $data['donor_amount'] = isset($donor) ? $donor->amount : 0;
        $data['donor_discount'] = isset($donor) ? $donor->discount : 0;
        $data['donor_sub_total'] = isset($donor) ? $donor->sub_total : 0;
        $data['donor_paid'] = isset($donor) ? $donor->paid : 0;
        $data['donor_due'] = isset($donor) ? $donor->due : 0;

        $dressing = $this->Common_model->calculateSumMultiple('create_bill', $dressingWhere, array('amount', 'discount', 'sub_total', 'paid', 'doctor_commission', 'due'));
        $data['dressing_amount'] = isset($dressing) ? $dressing->amount : 0;
        $data['dressing_discount'] = isset($dressing) ? $dressing->discount : 0;
        $data['dressing_sub_total'] = isset($dressing) ? $dressing->sub_total : 0;
        $data['dressing_paid'] = isset($dressing) ? $dressing->paid : 0;
        $data['dressing_due'] = isset($dressing) ? $dressing->due : 0;
        $data['dressing_commission'] = isset($dressing) ? $dressing->doctor_commission : 0;

        $admission = $this->Common_model->calculateSumMultiple('admission_fee_invoice', $admissionWhere, array('admission_fee', 'advance_amount'));
        $data['admission_fee'] = isset($admission) ? $admission->admission_fee+$admission->advance_amount : 0;

        $data['general_income'] = $this->Common_model->calCulateSum('incomes', $incomeWhere, 'voucher_amount');
        $data['general_expense'] = $this->Common_model->calCulateSum('expenses', $expenseWhere, 'voucher_amount');
        $data['lab_product'] = $this->Common_model->calCulateSum('lab_product_in', $labInWhere, 'grand_total_price');

        $data['total_amount'] = $data['pathology_amount'] +  $data['operation_amount'] + $data['operationInvoice']  +  $data['consultancy_amount'] + $data['emergency_amount']  + $data['ambulance_amount'] + $data['doctor_service_amount'] + $data['donor_amount'] + $data['dressing_amount']; // + $data['general_income'] ; // + $data['sales_paid_amount'] + $data['pharmacy_collection'] ;

        $data['total_discount_amount'] = $data['pathology_discount'] +  $data['operation_discount'] +  $data['consultancy_discount'] + $data['emergency_discount']  + $data['ambulance_discount'] + $data['doctor_service_discount'] + $data['donor_discount'] + $data['dressing_discount'];

        $data['total_sub_total'] = $data['pathology_sub_total'] +  $data['operation_sub_total'] +  $data['consultancy_sub_total'] + $data['emergency_sub_total']  + $data['ambulance_sub_total'] + $data['doctor_service_sub_total'] + $data['donor_sub_total'] + $data['dressing_sub_total'];
        //today
        $data['total_paid_amount'] = $data['pathology_paid'] +  $data['operation_paid'] 
        +  $data['consultancy_paid'] 
        + $data['emergency_paid']  + $data['ambulance_paid'] + $data['doctor_service_paid'] + $data['donor_paid'] + $data['dressing_paid'] + $data['dueCollection'] + $data['general_income']+$data['admission_fee']+$data['operation_advance'];

        $data['total_due_amount'] = $data['pathology_due'] +  $data['operation_due'] +  $data['consultancy_due'] + $data['emergency_due']  + $data['ambulance_due'] + $data['doctor_service_due'] + $data['donor_due'] + $data['dressing_due'] - $data['dueCollection'];

        $data['total_commission_amount'] = $data['patholgy_commission'] + $data['consultancy_commission'] + $data['operation_commission'] + $data['sonologistExpense'] + $data['staffSalary']+ $data['staffSalaryAdv'] + $data['emergency_commission'] + $data['ambulance_commission']  + $data['doctor_service_commission'] + $data['general_expense'] + $data['lab_product'] + $data['dressing_commission'];

        // $data['total_commission_amount'] = $data['patholgy_commission'] + $data['consultancy_commission']  + $data['sonologistExpense'] + $data['staffSalary']+ $data['staffSalaryAdv']  + $data['general_expense'] + $data['lab_product'];

        $shortageWhere = [
            'reorder_level >' => 0
        ];

        $data['total_shortage']     =  $this->Common_model->countAll('drug_medicine',  $shortageWhere, [],'', '', 'product_stock < reorder_level');
        $expiredWhere = [
            'expired_date !='   => '0000-00-00', 
            'expired_date <='   => date('Y-m-d')
        ];


        $data['total_expired']  =  $this->Common_model->countAll('purchase_order_details',  $expiredWhere);

        $data['reference_commission'] = $reference_commission;

        return (object)$data;
    }

      //chart
      public function chart($date)
      {
          $previous_seventh_day = date("Y-m-d", strtotime(' -6 day', strtotime($date)));
          $statement = array();
          $statement['statement_title_one'] = 'Collection And Expense of Last 7 Days ('.date("d/m/Y", strtotime($previous_seventh_day)).' to '.date("d/m/Y", strtotime($date));
          $statement['statement_title_balance'] = 'Balance of Last 7 Days ('.date("d/m/Y", strtotime($previous_seventh_day)).' to '.date("d/m/Y", strtotime($date));
          
  
          for($i=0; $i<=6; $i++)
          {
              $repeat = strtotime("+$i day",strtotime($previous_seventh_day));
              $statement['visit_label'][] = date('d/m',$repeat);
              $revenue_date =  date('Y-m-d',$repeat);
              $daily_balance = $this->daily_balance($revenue_date);
              $statement['sales_total'][] = $daily_balance->total_paid_amount;
              $statement['purchase_total'][] = $daily_balance->total_commission_amount;
              $statement['balance_total'][] = $daily_balance->total_paid_amount-$daily_balance->total_commission_amount;
          }
  
          $fdata = json_encode($statement);
          return $fdata;
      }
}
