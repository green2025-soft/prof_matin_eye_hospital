<?php

defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Lab_product_out extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
    }
    public function index()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'All Product Out';
            $data['page_title'] = 'Product Out';
            $data['info_header'] = 'All Product Out';
            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            if (!isset($from_date) && !isset($to_date)) {
                $from_date = $to_date = date('Y-m-d');
            }
            $where = array();
            if (!admin()) {
                $where['show_hide'] = 'Show';
            }
            if (!empty($from_date) && !empty($to_date)) {
                $where['out_date >= '] = $from_date;
                $where['out_date <= '] = $to_date;
            } elseif (!empty($from_date) && empty($to_date)) {
                $where['out_date'] = $from_date;
            } elseif (empty($from_date) && !empty($to_date)) {
                $where['out_date'] = $to_date;
            }
            $data['values'] = $this->Common_model->findAll("lab_product_out", $where, "record_id", "desc");
            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/lab_product_out/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function lab_product_out_details()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Product Details';
            $data['page_title'] = 'Product Out Details';
            $data['info_header'] = 'Product Out Details';
            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $product_id = $this->input->get('product_id');
            if (!isset($from_date) && !isset($to_date) && !isset($product_id)) {
                $from_date = $to_date = date('Y-m-d');
            }
            $where = array();
            if (!admin()) {
                $where['lab_product_out.show_hide'] = 'Show';
            }
            if ($product_id) $where['lab_product_out_details.product_id'] = $product_id;
            if (!empty($from_date) && !empty($to_date)) {
                $where['lab_product_out.out_date >= '] = $from_date;
                $where['lab_product_out.out_date <= '] = $to_date;
            } elseif (!empty($from_date) && empty($to_date)) {
                $where['lab_product_out.out_date'] = $from_date;
            } elseif (empty($from_date) && !empty($to_date)) {
                $where['lab_product_out.out_date'] = $to_date;
            }
            
            $options = array(
                'joins' => array(
                    array(
                        'table' => 'lab_product_out',
                        'condition' => 'lab_product_out_details.lab_product_out_id = lab_product_out.record_id',
                        'jointype' => 'LEFT'
                    ),
                ),
                'select' => 'lab_product_out_details.*,lab_product_out.out_date',
                'where' => $where,
                'order' => array(
                    'lab_product_out_details.record_id' => 'asc',
                ),
            );
            $data['values'] = $this->Common_model->commonJoins("lab_product_out_details", $options);

           // $data['values'] = $this->Common_model->findAll("lab_product_out_details", $where, "record_id", "desc");



            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;
            $data['product_id'] = $product_id;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/lab_product_out/lab_product_out_details', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function create()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Product Out';
            $data['page_title'] = 'Product Out';
            $data['info_header'] = 'All Product Out';
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/lab_product_out/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function edit($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Product Out';
            $data['page_title'] = 'Product Out';
            $data['info_header'] = 'All Product Out';
            $data['value'] = $this->Common_model->findById('lab_product_out', array('record_id' => $record_id));
            // $data['values'] = $this->Common_model->findAll('lab_product_out_details', array('lab_product_out_id' => $record_id), 'record_id', 'asc');
            $data['values'] = $this->Common_model->getLabOutProducts($record_id);
            // ddd($data['values']);
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/lab_product_out/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function view($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Product Out';
            $data['page_title'] = 'Product Out';
            $data['info_header'] = 'All Product Out';
            $data['redirect'] = base_url('lab_product_out/create');
            $data['signatureType'] = "Staff";
            $data['value'] = $this->Common_model->findById('lab_product_out', array('record_id' => $record_id));
            $data['values'] = $this->Common_model->findAll('lab_product_out_details', array('lab_product_out_id' => $record_id), 'record_id', 'asc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/lab_product_out/invoice', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function view2($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Product Out';
            $data['page_title'] = 'Product Out';
            $data['info_header'] = 'All Product Out';
            $data['redirect'] = base_url('lab_product_out');
            $data['signatureType'] = "Staff";
            $data['value'] = $this->Common_model->findById('lab_product_out', array('record_id' => $record_id));
            $data['values'] = $this->Common_model->findAll('lab_product_out_details', array('lab_product_out_id' => $record_id), 'record_id', 'asc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/lab_product_out/invoice', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST;
            $update_id = $input['update_id'];
            $record_ids = $input['record_id'];
            $product_ids = $input['product_id'];
            $quantitys = $input['quantity'];
            $unit_prices = $input['unit_price'];
            $total_prices = $input['total_price'];
            $product_category = $input['product_category'];
            $category_id = $input['category_id'];

            unset($input['update_id']);
            unset($input['record_id']);
            unset($input['product_id']);
            unset($input['quantity']);
            unset($input['unit_price']);
            unset($input['total_price']);
            unset($input['product_category']);
            unset($input['category_id']);

            $out_date = $input['out_date'];

            $prefix = str_replace('-', '', $out_date);

            $max = $this->Common_model->findMax('lab_product_out', array('prefix' => $prefix), 'out_no');
            $out_no = isset($max) ? $max->out_no + 1 : 1;

            $input['prefix'] = $prefix;
            $input['out_no'] = $out_no;

            if ($update_id == 0 || empty($update_id)) {
                $insert = $this->Common_model->saveData('lab_product_out', $input);
                if ($insert) {
                    foreach ($record_ids as $key => $value) {
                        $data = array(
                            'lab_product_out_id' => $insert,
                            'out_date' => $out_date,
                            'product_id' => $product_ids[$key],
                            'category_id' => $category_id[$key],
                            'quantity' => $quantitys[$key],
                            'unit_price' => $unit_prices[$key],
                            'total_price' => $total_prices[$key]
                        );
                        $this->Common_model->saveData('lab_product_out_details', $data);
                    }
                    $this->session->set_flashdata('message', INSERT_MSG);
                } else {
                    $this->session->set_flashdata('message', INSERT_ERROR_MSG);
                }
            } else {
                $info = $this->Common_model->findById('lab_product_out', array('record_id' => $update_id));
                if ($info->out_date == $out_date) {
                    $input['out_no'] = $info->out_no;
                }
                $update = $this->Common_model->updateData('lab_product_out', $input, array('record_id' => $update_id));
                if ($update) {
                    foreach ($record_ids as $key => $value) {
                        $data = array(
                            'lab_product_out_id' => $update_id,
                            'out_date' => $out_date,
                            'product_id' => $product_ids[$key],
                            'category_id' => $category_id[$key],
                            'quantity' => $quantitys[$key],
                            'unit_price' => $unit_prices[$key],
                            'total_price' => $total_prices[$key]
                        );
                        if ($value) {
                            $this->Common_model->updateData('lab_product_out_details', $data, array('record_id' => $value));
                        } else {
                            $this->Common_model->saveData('lab_product_out_details', $data);
                        }
                    }

                    $this->session->set_flashdata('message', UPDATE_MSG);
                } else {
                    $this->session->set_flashdata('message', UPDATE_ERROR_MSG);
                }
            }
            redirect('lab_product_out', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function lab_product_balance()
    {
        $product_id = $this->input->post('product_id');
        $in_quantity = $this->Common_model->calCulateSum('lab_product_in_details', array('product_id' => $product_id), 'quantity');
        $out_quantity = $this->Common_model->calCulateSum('lab_product_out_details', array('product_id' => $product_id), 'quantity');
        $balance = $in_quantity - $out_quantity;
        echo $balance;
        exit;
    }

    public function delete($id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if ($this->Common_model->delete_info('record_id', $id, 'lab_product_out')) {
                $this->Common_model->delete_info('lab_product_out_id', $id, 'lab_product_out_details');
                $this->session->set_flashdata('message', DELETE_MSG);
            } else {
                $this->session->set_flashdata('message', DELETE_ERROR_MSG);
            }
            redirect('lab_product_out', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function lab_product_balance_tr(){
        $product_id = $this->input->post('product_id');
        $staff_id = $this->input->post('staff_id');
        $in_quantity = $this->Common_model->calCulateSum('re_agent_in_details',array('product_id'=>$product_id, 'staff_id'=>$staff_id),'quantity');
        $out_quantity = $this->Common_model->calCulateSum('re_agent_out_details',array('product_id'=>$product_id, 'staff_id'=>$staff_id),'quantity');
        $balance = $in_quantity - $out_quantity ;
        
        // if($reagent_out_quantity){
        // $balance = $reagent_out_quantity;
        // }else{
        //     $balance = 0;
        // }
        echo $balance ;
        exit;
    }
}
