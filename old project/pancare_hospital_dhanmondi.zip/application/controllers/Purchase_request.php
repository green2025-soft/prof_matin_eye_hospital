<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Purchase_request extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'All Purchase Request';
            $data['page_title'] = 'Purchase Request';
            $data['info_header'] = 'All Purchase Request';
            $where = array() ;
            if(!admin()){
                $where['show_hide'] = "Show" ;
            }
            $data['values'] = $this->Common_model->findAll('purchase_request',$where,'record_id','desc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/purchase_request/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function create() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Purchase Request';
            $data['page_title'] = 'Purchase Request';
            $data['info_header'] = 'All Purchase Request';
            $data['in_values'] = $this->Common_model->findAll('purchase_request',array(),'record_id','desc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/purchase_request/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function edit($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Purchase Request';
            $data['page_title'] = 'Purchase Request';
            $data['info_header'] = 'All Purchase Request';
            $data['value'] = $this->Common_model->findById('purchase_request',array('record_id'=>$record_id)) ;
            $data['supplier'] = $this->Common_model->findById('suppliers',array('record_id'=>$data['value']->supplier_id)) ;
            $data['values'] = $this->Common_model->findAll('purchase_request_details',array('purchase_request_id'=>$record_id),'record_id','asc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/purchase_request/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function view($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Purchase Request';
            $data['page_title'] = 'Purchase Request';
            $data['info_header'] = 'All Purchase Request';
            $data['redirect'] = base_url('purchase_request/create');
            $data['signatureType'] = "Staff";
            $data['value'] = $this->Common_model->findById('purchase_request',array('record_id'=>$record_id)) ;
            $data['supplier'] = $this->Common_model->findById('suppliers',array('record_id'=>$data['value']->supplier_id)) ;
            $data['values'] = $this->Common_model->findAll('purchase_request_details',array('purchase_request_id'=>$record_id),'record_id','asc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/purchase_request/invoice', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }    
    public function view2($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Purchase Request';
            $data['page_title'] = 'Purchase Request';
            $data['info_header'] = 'All Purchase Request';
            $data['redirect'] = base_url('purchase_request');
            $data['signatureType'] = "Staff";
            $data['value'] = $this->Common_model->findById('purchase_request',array('record_id'=>$record_id)) ;
            $data['supplier'] = $this->Common_model->findById('suppliers',array('record_id'=>$data['value']->supplier_id)) ;
            $data['values'] = $this->Common_model->findAll('purchase_request_details',array('purchase_request_id'=>$record_id),'record_id','asc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/purchase_request/invoice', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            $record_ids = $input['record_id'] ;
            $product_ids = $input['product_id'] ;
            $quantitys = $input['quantity'] ;
            $unit_prices = $input['unit_price'] ;
            $total_prices = $input['total_price'] ;
           
            unset($input['update_id']);
            unset($input['record_id']);
            unset($input['product_id']);
            unset($input['quantity']);
            unset($input['unit_price']);
            unset($input['total_price']);

            $request_date = $input['request_date'] ; 

            $prefix = str_replace('-', '', $request_date);

            $max = $this->Common_model->findMax('purchase_request',array('prefix'=>$prefix),'request_no');
            $request_no = isset($max)?$max->request_no + 1 : 1 ;

            $input['prefix'] = $prefix ;
            $input['request_no'] = $request_no ;

            if($update_id == 0 || empty($update_id)){       
                $insert = $this->Common_model->saveData('purchase_request', $input);
                if($insert){
                    foreach ($record_ids as $key => $value) {
                        $data = array(
                            'purchase_request_id'=>$insert,
                            'request_date'=>$request_date,
                            'product_id'=>$product_ids[$key],
                            'quantity'=>$quantitys[$key],
                            'unit_price'=>$unit_prices[$key],
                            'total_price'=>$total_prices[$key]
                        );
                        $this->Common_model->saveData('purchase_request_details',$data);
                    }
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $info = $this->Common_model->findById('purchase_request',array('record_id'=>$update_id));
                if($info->request_date == $request_date){
                    $input['request_no'] = $info->request_no;
                }
                $update = $this->Common_model->updateData('purchase_request', $input,array('record_id'=>$update_id));
                if($update){
                    foreach ($record_ids as $key => $value) {
                        $data = array(
                            'purchase_request_id'=>$update_id,
                            'request_date'=>$request_date,
                            'product_id'=>$product_ids[$key],
                            'quantity'=>$quantitys[$key],
                            'unit_price'=>$unit_prices[$key],
                            'total_price'=>$total_prices[$key]
                        );
                        if($value){
                            $this->Common_model->updateData('purchase_request_details',$data,array('record_id'=>$value));
                        }else{
                            $this->Common_model->saveData('purchase_request_details',$data);
                        }
                    }

                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            redirect('purchase_request', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function in_out() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Purchase Request/Out';
            $data['page_title'] = 'Purchase Request/Out';
            $data['info_header'] = 'All Purchase Request/Out';

            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $product_id = $this->input->get('product_id');
            $transaction_type = $this->input->get('transaction_type');

            $where = array() ;

            if(! isset($from_date) && !isset($to_date) && !isset($product_id) && !isset($transaction_type)){
                $where['date'] = date('Y-m-d') ;
            }

            if($product_id) $where['record_id'] = $product_id ;

            if(!empty($from_date) && !empty($to_date)){
                $where['date >= '] = $from_date ;
                $where['date <= '] = $to_date ;
            }elseif(!empty($from_date) && empty($to_date)){
                $where['date'] = $from_date ;
            }elseif(empty($from_date) && !empty($to_date)){
                $where['date'] = $to_date ;
            }

            $data['values'] = $this->Common_model->findAllGroupBySum('lab_product_use_in',$where,'product_id','qty') ;
            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;
            $data['product_id'] = $product_id;
            $data['transaction_type'] = $transaction_type;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/lab_product/in_out', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $id, 'purchase_request')){
                $this->Common_model->delete_info('purchase_request_id', $id, 'purchase_request_details');
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
            redirect('purchase_request', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function approved($record_id)
    {
        $bill = $this->Common_model->findById('purchase_request', array('record_id' => $record_id));
        if (isset($bill)) {
            $status = '';
            if ($bill->status == 'Pending') {
                $status = 'Approved';
            } else {
                $status = 'Pending';
            }
            $this->Common_model->updateData('purchase_request', array('status' => $status), array('record_id' => $record_id));
            $this->Common_model->updateData('purchase_request_details', array('status' => $status), array('purchase_request_id' => $record_id));
            $this->session->set_flashdata('message', UPDATE_MSG);
        } else {
            $this->session->set_flashdata('message', UPDATE_ERROR_MSG);
        }
        // redirect('test_honorarium/appointment', 'refresh');
        redirect($_SERVER['HTTP_REFERER']);
    }
}
