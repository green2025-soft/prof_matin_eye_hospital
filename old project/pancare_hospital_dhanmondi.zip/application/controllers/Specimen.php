<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Specimen extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Sample Collection';
            $data['page_title'] = 'Sample Collection';
            $data['info_header'] = 'All Sample Collection';
            $from_date  = $this->input->get('from_date')??date('Y-m-d');
            $to_date    = $this->input->get('to_date')??date('Y-m-d');

            $samples = $this->getSamplesData($from_date,  $to_date);
            
            // $data['values'] = $this->Common_model->findAll('specimens',array(),'record_id','desc') ;
            $data['values'] =   $samples ;
            // dd($data['values']);
            $data['from_date']  =  $from_date;
            $data['to_date']    =  $to_date;
            $data['invoices']   = $this->getInvoiceData(3000);
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/specimen/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

  private function getSamplesData($from_date, $to_date)
{
    // Parent records
    $samples = $this->db
        ->select('
            s.invoice_id,
            s.entry_date,
            s.test_category_id,
            s.specimen,
            s.status,
            s.created_by,
            s.patient_id,
            p.name
        ')
        ->from('specimens s')
        ->join('patient p', 'p.record_id = s.patient_id', 'left')
        ->where('s.entry_date >=', $from_date)
        ->where('s.entry_date <=', $to_date)
        ->group_by([
            's.invoice_id',
            's.patient_id',
            's.test_category_id'
        ])
        ->order_by('s.record_id', 'DESC')
        ->get()
        ->result();

    // Fetch all test samples in ONE query
    $allTests = $this->db
        ->select('
            s.record_id,
            s.invoice_id,
            s.patient_id,
            s.test_category_id,
            s.sales_test_id,
            st.test_name
        ')
        ->from('specimens s')
        ->join(
            'sales_test st',
            'st.test_id = s.sales_test_id AND st.invoice_no = s.invoice_id',
            'left'
        )
        ->where('s.entry_date >=', $from_date)
        ->where('s.entry_date <=', $to_date)
        ->order_by('s.record_id', 'DESC')
        ->get()
        ->result();

    // Group test samples by invoice + patient + category
    $testMap = [];

    foreach ($allTests as $test) {
        $key = $test->invoice_id . '_' .
               $test->patient_id . '_' .
               $test->test_category_id;

        $testMap[$key][] = $test;
    }

    // Attach grouped test samples to parent records
    foreach ($samples as &$sample) {
        $key = $sample->invoice_id . '_' .
               $sample->patient_id . '_' .
               $sample->test_category_id;

        $sample->testSamples = $testMap[$key] ?? [];
    }

    return $samples;
}

    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            $categoryIds = $input['sales_category_id'];
            // dd($categoryIds);
            $salesTest = $this->db->where_in('test_category_id', $categoryIds)
            ->where(['invoice_no'=> $input['invoice_id'],'patient_id'=>$input['patient_id']])
            ->get('sales_test')->result();
            // $sales_test_id = $input['sales_test_id'] ;
            // dd($salesTest);
            unset($input['update_id']);
            if($update_id == 0 || empty($update_id)){       
               // $insert = $this->Common_model->saveData('specimens', $input);
               if(isset($salesTest)){
                $testList = array() ;
                foreach ($salesTest as  $value1) {
               
                    
                    $data = array(
                        'invoice_id'=> $input['invoice_id'],
                        'patient_id'=> $input['patient_id'],
                        'sales_test_id'=>  $value1->test_id,
                        'test_category_id'=> $value1->test_category_id,
                        'specimen'=> $input['specimen'],
                        'status'=> $input['status'],
                        'entry_date'=> $input['entry_date'],
                    );
                    $testList[] = $data ;
                } 
                $this->Common_model->save_batch('specimens',$testList) ;
            }
                //if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                //}else{
                    // $this->session->set_flashdata('message',INSERT_ERROR_MSG);
               // }
            }else{
                $update = $this->Common_model->updateData('specimens', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            redirect('specimen', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($catId, $invoiceId, $patientId) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            $this->db->where(['test_category_id'=>$catId, 'invoice_id'=>$invoiceId, 'patient_id'=>$patientId])->delete('specimens');
            $this->session->set_flashdata('message',DELETE_MSG);
           // redirect("crud/previousPage");
            redirect('specimen', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function load_invoice_tests()
    {
        $invoice_id = $this->input->post('invoice_id')??11 ;
        $where = array();
        //$where['type'] = 'Test';
        $where['invoice_no'] = $invoice_id ;
        $sales_test = $this->db->select('test_category_id, test_category' )->from('sales_test')
        ->where('invoice_no', $invoice_id)
        ->group_by(['test_category_id', 'invoice_no', 'patient_id']) 
        ->order_by('record_id')->get()->result();
        //$str = '<option value="">--Select--</option>';
        
        $str = '';
        foreach ($sales_test as $key => $value) {
            // $str .= '<option value="'.$value->record_id.'">'.$value->test_name.'</option>';
            $check = $this->Common_model->findById('specimens',['test_category_id'=>$value->test_category_id, 'invoice_id'=> $invoice_id]);
            if(!$check){
            $str .= '<input type="checkbox" name="sales_category_id[]" value="'.$value->test_category_id.'"> ' .$value->test_category.'<br>';
            }
        }
        echo $str ;
        exit ;
    }

    private function getInvoiceData($limit=0){

        $this->db->select('create_bill.record_id, create_bill.patient_id, patient.name as patient_name')
                 ->from('create_bill')->join('patient', 'patient.record_id = create_bill.patient_id')
                 ->where('create_bill.type', 'Test Invoice')
                 ->order_by('create_bill.record_id', 'desc');
        if ($limit >0){
            $this->db->limit($limit);
        }

        $invoiceData = $this->db->get()->result();

        $invoiceOptions = '<option value="">Select Invoice</option>';

        foreach($invoiceData as $row){
            $invoiceOptions.="<option value='$row->record_id' data-patient_id='$row->patient_id'>$row->record_id - $row->patient_name</option>";
        }

        return $invoiceOptions;

    }

    public function test_barcode($catId, $invoiceId, $patientId) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['values'] = $this->Common_model->findAll('specimens',['test_category_id'=>$catId, 'invoice_id'=>$invoiceId, 'patient_id'=>$patientId], 'record_id', 'DESC');
            // dd($data['values']);
            $data['invoiceId'] = $invoiceId;
            $data['patientId'] = $patientId;
            $this->load->view('admin/specimen/test_barcode', $data);
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
        
    }
}
