<?php

defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Ivf_balance_sheet extends MY_Controller
{

    protected $title = 'IVF Balance Sheet';
    protected $bUrl = 'ivf_balance_sheet';
    public function __construct()
    {
        parent::__construct();
    }

    protected function laoute($pageName) {
        $this->render('ivf/'.$pageName);
    }

    public function index(){
        $request        = $this->input->get();
        $from_date      = $request['from_date'];
        $to_date        = $request['to_date'];
        $created_by     = $request['created_by'];

         
         $baseWhere = admin() ? [] : ['show_hide' => 'Show'];
         $type = 'IVF Test Invoice';

        $physioServiceWhere = ['type' => $type] + $baseWhere;
        $expenseWhere       = ['expense_type' => 'IVF'] + $baseWhere;
        $collectionWhere    = ['invoice_type' => $type] + $baseWhere;
        $incomeWhere        = ['income_type' => 'IVF'] + $baseWhere;

        $today =date('Y-m-d');
        if (!isset($created_by) && !isset($from_date) && !isset($to_date)) {
            $from_date = $to_date = $today ;
        }

       // Handle created_by filter
        if (!empty($created_by)) {
            $createByWhere      = ['created_by' => $created_by];
            $physioServiceWhere += $createByWhere;
            $expenseWhere       += $createByWhere;
            $collectionWhere    += $createByWhere;
            $incomeWhere        += $createByWhere;
        }


        // Apply date filters
        if (!empty($from_date) && !empty($to_date)) {
            // Range filter
            $physioServiceWhere += ['date >=' => $from_date, 'date <=' => $to_date];
            $expenseWhere       += ['expense_date >=' => $from_date, 'expense_date <=' => $to_date];
            $collectionWhere    += ['mr_date >=' => $from_date, 'mr_date <=' => $to_date];
            $incomeWhere        += ['income_date >=' => $from_date, 'income_date <=' => $to_date];
        } else {
            // Single date filter
            $dateToUse = $from_date ?? $to_date ?? $today;
            $physioServiceWhere['date']         = $dateToUse;
            $expenseWhere['expense_date']       = $dateToUse;
            $collectionWhere['mr_date']         = $dateToUse;
            $incomeWhere['income_date']         = $dateToUse;
        }

        $physioServices     = $this->Common_model->findAll('create_bill', $physioServiceWhere, 'record_id', 'desc');

        $physioExpenses      = $this->Common_model->findAll('expenses', $expenseWhere, 'expense_id', 'desc');

        $dueCollections      = $this->Common_model->findAll('due_collection_details', $collectionWhere, 'mr_details_id', 'desc');

           ;

        $generalIncomes =  $this->Common_model->findAll('incomes', $incomeWhere, 'income_id', 'desc');
        
         $this->data = [
            'title'             => $this->title,
            'physioServices'    => $physioServices,
            'physioExpenses'    => $physioExpenses,
            'dueCollections'    => $dueCollections,
            'from_date'         => $from_date,
            'to_date'           => $to_date,
            'created_by'        => $created_by,
            'generalIncomes'    => $generalIncomes
        ];
    

        $this->laoute('balance_sheet');
    }
}
