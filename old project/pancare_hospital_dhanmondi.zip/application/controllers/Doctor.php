<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Doctor extends CI_Controller {

    static $helper   = array('utility');
    static $library   = array('upload');
    public function __construct() {
        parent::__construct();
        $this->load->library(self::$library);
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff" || $user_type == "doctor") {
            $data['title'] = 'Doctor Information';
            $data['page_title'] = 'Doctor Information';
            $data['values'] = $this->Common_model->findAll('doctor',array(),'record_id','asc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/doctor/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function create() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Insert Doctor Information';
            $data['page_title'] = 'Insert Doctor Information';
            $data['specialists'] = $this->Common_model->findAll('specialists',array(),'specialists','asc');
           // var_dump($data['specialists']);die;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/doctor/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function edit($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Edit Doctor Information';
            $data['page_title'] = 'Edit Doctor Information';
            $data['specialists'] = $this->Common_model->findAll('specialists',array(),'specialists','asc');
            $data['value'] = $this->Common_model->findById('doctor',array('record_id'=>$record_id)) ;
            /*$specialistsArr = array() ;
            if(isset($data['value'])){
                if(!empty($data['value']->specialists)){
                    $specialistsArr = explode(',', $data['value']->specialists);
                }
            }
            var_dump($specialistsArr);die;*/
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/doctor/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff" || $user_type == "doctor") {
            $input = $_POST ;
            $input['website_show'] = isset($input['website_show'])?1:0;
            
            $popup = $this->input->post('popup');
            $specialists = $this->input->post('specialists');
           // var_dump($specialists);die;
            if(isset($specialists)){
                $input['specialists'] = implode(',', $specialists);
            }
            $update_id = $input['update_id'] ;
            $name = $input['name'] ;
            $designation_id = $input['designation_id'] ;
            $mobile = $input['mobile'] ;
            unset($input['update_id']);


            $config['upload_path']      = 'assets/img/doctors/';
            $config['allowed_types']    = '*';
            $config['max_size']         = '0';
            //$config['file_name']      = time(); 
            $file_field                 = "photo";
            $this->upload->initialize($config);

            if($update_id == 0 || empty($update_id)){       
                $getRow = $this->Common_model->findById('doctor',array('name'=>$name,'designation_id'=>$designation_id,'mobile'=>$mobile));
                if(isset($getRow)){
                    $this->session->set_flashdata('message', EXIST_MSG);
                    if(isset($popup)){
                        echo "This doctor has been already been taken!";
                        exit(0);
                    }
                    redirect('doctor', 'refresh');
                }
                if(isset($popup)){
                    unset($input['popup']);
                }
                if(!empty($_FILES[$file_field]["name"])){
                    if($this->upload->do_upload($file_field)) {
                        $uploadData = $this->upload->data();
                        $input['photo'] =   $config['upload_path'] . $uploadData['file_name'];
                    }
                }
                $max = $this->Common_model->findMax("doctor",array(),"doctor_no");
                $doctor_no = isset($max)?$max->doctor_no + 1 : 1 ;
                $input['doctor_no'] = $doctor_no ;

                $insert = $this->Common_model->saveData('doctor', $input);
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
                if(isset($popup)){
                    $doctor = $this->Common_model->findById('doctor',array('record_id'=>$insert));
                    echo json_encode($doctor);
                    exit(0);
                }
            }else{
                $info = $this->Common_model->findById('doctor',array('record_id'=>$update_id));
                if(!empty($_FILES[$file_field]["name"])){
                    if(file_exists($info->photo) && !empty($info->photo)) {
                        unlink('./'.$info->photo);
                    }
                    if($this->upload->do_upload($file_field)) {
                            $uploadData = $this->upload->data();
                            $input['photo'] =   $config['upload_path'] . $uploadData['file_name'];
                    }
                }

                $update = $this->Common_model->updateData('doctor', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            redirect('doctor', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $id, 'doctor')){
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
           // redirect("crud/previousPage");
            redirect('doctor', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
