<?php 
if ( ! function_exists('options')){
    function options($table,$where,$columns,$valueColumn,$displayColumn,$order,$serialize,$selectedText = '',$selectedValue = 0, $dataColumns = array()){
        if(!empty($selectedText)){
            $response = '<option value="">'.$selectedText.'</option>' ;
        }else{
            $response = '' ;
        }
        $_CI = &get_instance();
        $info = $_CI->Common_model->findAll($table,$where,$order,$serialize);
        $selected = '' ;
        foreach ($info as $key => $value) { 
            $merge = '' ;
            $data = '' ;
            $selected = $selectedValue == $value->$valueColumn ? 'selected' : '' ;
            if(empty($displayColumn)){

                foreach ($columns as $k => $v) {
                    $merge .= $value->$v.' - ';
                }
                $merge = rtrim($merge,' - ');
            }
            if(count($dataColumns)){
                foreach ($dataColumns as $k1 => $v1) {
                  //  $data .= "data-$v1=".$value->$v1 .' ';
                    $val = urlencode($value->$v1) ;
                    $data .= "data-$v1= $val ";
                }
            }
            if(empty($displayColumn)){
                $display = $merge;
            }else{
                $display = $value->$displayColumn;
            }
            $response .='<option '.$selected.' value="'.$value->$valueColumn.'"'.$data.'>'.$display.'</option>';
        }
        return $response;
    }
}
if(! function_exists("numberTowords")){
    function numberTowords($num)
    { 
        $ones = array( 
            '' => "",
            0 => "zero",
            1 => "one", 
            2 => "two", 
            3 => "three", 
            4 => "four", 
            5 => "five", 
            6 => "six", 
            7 => "seven", 
            8 => "eight", 
            9 => "nine", 
            10 => "ten", 
            11 => "eleven", 
            12 => "twelve", 
            13 => "thirteen", 
            14 => "fourteen", 
            15 => "fifteen", 
            16 => "sixteen", 
            17 => "seventeen", 
            18 => "eighteen", 
            19 => "nineteen" 
        ); 
        $tens = array( 
            '' => "",
            0 => "zero",
            1 => "ten",
            2 => "twenty", 
            3 => "thirty", 
            4 => "forty", 
            5 => "fifty", 
            6 => "sixty", 
            7 => "seventy", 
            8 => "eighty", 
            9 => "ninety" 
        ); 
        $hundreds = array( 
            "hundred", 
            "thousand", 
            "million", 
            "billion", 
            "trillion", 
            "quadrillion" 
); //limit t quadrillion 
        $num = number_format($num,2,".",","); 
        $num_arr = explode(".",$num); 
        $wholenum = $num_arr[0]; 
        $decnum = $num_arr[1]; 
        $whole_arr = array_reverse(explode(",",$wholenum)); 
        krsort($whole_arr); 
        $rettxt = ""; 
        foreach($whole_arr as $key => $i){ 
            while(substr($i,0,1)=="0")
        $i=substr($i,1,5);
            if($i < 20){ 
                $rettxt .= $ones[$i]; 
            }elseif($i < 100){ 
                $rettxt .= $tens[substr($i,0,1)]; 
                $rettxt .= " ".$ones[substr($i,1,1)]; 
            }else{ 
                $rettxt .= $ones[substr($i,0,1)]." ".$hundreds[0]; 
                $rettxt .= " ".$tens[substr($i,1,1)]; 
                $rettxt .= " ".$ones[substr($i,2,1)]; 
            } 
            if($key > 0){ 
                $rettxt .= " ".$hundreds[$key]." "; 
            } 
        } 
        if($decnum > 0){ 
            $rettxt .= " and "; 
            if($decnum < 20){ 
                $rettxt .= $ones[$decnum]; 
            }elseif($decnum < 100){ 
                $rettxt .= $tens[substr($decnum,0,1)]; 
                $rettxt .= " ".$ones[substr($decnum,1,1)]; 
            } 
        } 
        return $rettxt; 
    } 
}
if(! function_exists("numberToSpeeling")){
    function numberToSpeeling($num)
    {

        $ones = array(
            0 =>"ZERO",
            1 => "ONE",
            2 => "TWO",
            3 => "THREE",
            4 => "FOUR",
            5 => "FIVE",
            6 => "SIX",
            7 => "SEVEN",
            8 => "EIGHT",
            9 => "NINE",
            10 => "TEN",
            11 => "ELEVEN",
            12 => "TWELVE",
            13 => "THIRTEEN",
            14 => "FOURTEEN",
            15 => "FIFTEEN",
            16 => "SIXTEEN",
            17 => "SEVENTEEN",
            18 => "EIGHTEEN",
            19 => "NINETEEN",
            "014" => "FOURTEEN"
        );
        $tens = array( 
            0 => "ZERO",
            1 => "TEN",
            2 => "TWENTY",
            3 => "THIRTY", 
            4 => "FORTY", 
            5 => "FIFTY", 
            6 => "SIXTY", 
            7 => "SEVENTY", 
            8 => "EIGHTY", 
            9 => "NINETY" 
        ); 
        $hundreds = array( 
            "HUNDRED", 
            "THOUSAND", 
            "MILLION", 
            "BILLION", 
            "TRILLION", 
            "QUARDRILLION" 
        ); /*limit t quadrillion */
        $num = number_format($num,2,".",","); 
        $num_arr = explode(".",$num); 
        $wholenum = $num_arr[0]; 
        $decnum = $num_arr[1]; 
        $whole_arr = array_reverse(explode(",",$wholenum)); 
        krsort($whole_arr,1); 
        $rettxt = ""; 
        foreach($whole_arr as $key => $i){

            while(substr($i,0,1)=="0")
                $i=substr($i,1,5);
            if($i < 20){ 
                /* echo "getting:".$i; */
                $rettxt .= $ones[$i]; 
            }elseif($i < 100){ 
                if(substr($i,0,1)!="0")  $rettxt .= $tens[substr($i,0,1)]; 
                if(substr($i,1,1)!="0") $rettxt .= " ".$ones[substr($i,1,1)]; 
            }else{ 
                if(substr($i,0,1)!="0") $rettxt .= $ones[substr($i,0,1)]." ".$hundreds[0]; 
                if(substr($i,1,1)!="0")$rettxt .= " ".$tens[substr($i,1,1)]; 
                if(substr($i,2,1)!="0")$rettxt .= " ".$ones[substr($i,2,1)]; 
            } 
            if($key > 0){ 
                $rettxt .= " ".$hundreds[$key]." "; 
            }
        } 
        if($decnum > 0){
            $rettxt .= " and ";
            if($decnum < 20){
                $rettxt .= $ones[$decnum];
            }elseif($decnum < 100){
                $rettxt .= $tens[substr($decnum,0,1)];
                $rettxt .= " ".$ones[substr($decnum,1,1)];
            }
        }
        return $rettxt;
    }
}

if(!file_exists("replace")){
    function replace($from_text,$to_text,$original_text){
        return str_replace($from_text, $to_text, $original_text);
    }
}
if(!file_exists("creator")){
    function creator($createdBy){
        $_CI = &get_instance();
        $user_name = '' ;
        if($createdBy == 1){
            $user = $_CI->Common_model->findById('admin',array('record_id'=>$createdBy));
            $user_name = isset($user)?$user->name:'';
        }elseif($createdBy > 1){
            $user = $_CI->Common_model->findById('staff',array('record_id'=>$createdBy));
            $user_name = isset($user)?$user->name:'';
        }
        return $user_name ;
    }
}
if(!file_exists("closing_date")){
    function closing_date($currnt_date){
        $_CI = &get_instance();
        $where = array() ;
        $where['closing_date'] = $currnt_date ;
        $info = $_CI->Common_model->findById('closing_date',$where);
        if(isset($info)){
            $currnt_date = date("Y-m-d", strtotime("+1 day", strtotime($currnt_date)));
        }
        return $currnt_date;
    }
}
if(!file_exists("converted_date")){
    function converted_date($date,$format = ''){
        if(empty($format)){
            $format = 'd-m-Y';
        }
        $date = date($format,strtotime($date)) ;
        return $date;
    }
}

if(!file_exists("gender")){
    function gender($type){
        $active_selected = "" ;
        $inactive_selected = "" ;
        if($type == 'Male'){
            $male_selected = 'selected';
            $female_selected = "" ;
            $others_selected = "" ;
        }elseif($type == 'Female'){
            $male_selected = '';
            $female_selected = "selected" ;
            $others_selected = "" ;
        }elseif($type == 'Others'){
            $male_selected = "";
            $female_selected = "" ;
            $others_selected = "selected" ;
        }
        $response = '<option value="">Select Gender</option>';
        $response .= '<option value="Male" '. $male_selected.'>Male</option>';
        $response .= '<option value="Female" '. $female_selected.'>Female</option>';
        $response .= '<option value="Others" '. $others_selected.'>Others</option>';
        return $response ;
    }
}

if(!file_exists('techno_bulk_sms')){
    function techno_bulk_sms($mobile_no, $message) {
        $url = 'https://24smsbd.com/api/bulkSmsApi';
        $apiKey = "Z3JlZW5zb2Z0OmdyZWVuOTU2";
        $sender_id = 348;
        $data = array('sender_id' => $sender_id,
           'apiKey' => $apiKey,
           'mobileNo' => $mobile_no,
           'message' =>$message   
       );
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);     
        $output = curl_exec($curl);
        curl_close($curl);
        echo '';
    }
}

if(!file_exists("month")){
    function month(){
        $monthArray = array(
            "01"=>"January",
            "02"=>"February", 
            "03"=>"March", 
            "04"=>"April",
            "05"=>"May", 
            "06"=>"June", 
            "07"=>"July", 
            "08"=> "August", 
            "09"=> "September",
            "10"=>"October", 
            "11"=>"November", 
            "12"=>"December",
        );
        return $monthArray ;
    }
}

if (!function_exists("getDatesFromRange")) {
    // Function to get all the dates in given range 
    function getDatesFromRange($start, $end, $format = 'Y-m-d')
    {
        $array = array();
        // Variable that store the date interval 
        // of period 1 day 
        $interval = new DateInterval('P1D');

        $realEnd = new DateTime($end);
        $realEnd->add($interval);

        $period = new DatePeriod(new DateTime($start), $interval, $realEnd);
        foreach ($period as $date) {
            $array[] = $date->format($format);
        }
        return $array;
    }
}

if (!file_exists('generate_invoice_no')) {
    function generate_invoice_no($object)
    {
      //  $invoice_no = isset($object)?$object->prefix.'-'.$object->invoice_no:'' ;
      //  return $invoice_no ;
      $invoice_no = isset($object)?$object->record_id:'' ;
        return $invoice_no ;
    }
}
if (!file_exists('discountTypes')) {
    function discountTypes()
    {
        $discountTypes = array(
            '1'=>'Reference(R.F)',
            // '2'=>'Doctor(Dr.)',
            '3'=>'Hospital',
            // '4'=>'Hospital + Reference(R.F)',
            // '5'=>'Hospital + Doctor(Dr.)',
        );
        return $discountTypes ;
    }
}
if (!function_exists('do_upload')) {
    function do_upload($table, $update = array() ,$path, $file, $overwrite = FALSE, $allowed_types = 'gif|jpg|jpeg|png', $size = '', $width = '', $height = '')
    {
        reset($update) ;
        $key = key($update);
        $value = $update[$key] ;
        $_CI = &get_instance();
        $_CI->load->library('upload');
        $config['upload_path'] = './' . $path;
        $config['allowed_types'] = $allowed_types;
        if (!empty($size)) $config['max_size'] = $size;
        if (!empty($width)) $config['max_width']  = $width;
        if (!empty($height)) $config['max_height']  = $height;
        $config['overwrite'] = $overwrite;
        $config['encrypt_name'] = FALSE;
        $config['remove_spaces'] = TRUE;
        if (!is_dir($config['upload_path'])) die("THE UPLOAD DIRECTORY DOES NOT EXIST");
        $_CI->upload->initialize($config);
        $upload_data = array() ;
        if (!empty($_FILES[$file]["name"])) {
            if($value != 0){
                $info = $_CI->Common_model->findById($table,array($key =>$value));
               // var_dump($info);die;
                if(isset($info)){
                    if(file_exists($info->$file)){
                        unlink('./'.$info->$file);
                    }
                }
            }
            if (!$_CI->upload->do_upload($file)) {
                return $upload_data;
            } else {
                $upload_data = $_CI->upload->data();
                return $upload_data ;
            }
        }else{
            return $upload_data ;
        }
    }
}
if (!function_exists('dayDuration')) {
    function dayDuration($startDate, $endDate)
    {
        $start_date = strtotime($startDate);
        $end_date = strtotime($endDate);
        $days =  ($end_date - $start_date) / 60 / 60 / 24;
        return ($days + 1);
    }
}
if (!file_exists('admin')) {
    function admin()
    {
        $flag = 0 ;
        $_CI = &get_instance();
        $user_type = $_CI->session->userdata("ses_user_type") ;
        if($user_type == "admin"){
            $flag = 1 ;
        }else{
            $flag = 0 ;
        }
        return $flag ;
    }
}

if (!function_exists("view")) {
    function view($url)
    {
        $url = base_url($url);
        $view = "<a href='$url' target='_blank'><i class='fa fa-eye'></i></a>";
        return $view;
    }
}


if (!function_exists("ddd")) {
    function ddd($data)
    {
        echo "<pre>";
        var_dump($data);
        exit;
    }
}

if (!function_exists("labProductBalance")) {
    function labProductBalance($labProductId)
    {   
        $_CI = &get_instance();
        return $_CI->Common_model->item_balance_lab($labProductId);
    }
}

if (!function_exists("itemBalance")) {
    function itemBalance($product_id)
    {
        $_CI = &get_instance();
        return $_CI->Common_model->item_balance($product_id);
    }
}

if (!function_exists("reOrderArr")) {
    function reOrderArr($dataArr, $keyName)
    {
       $reorderedArr = [];

       if(sizeof($dataArr) > 0){
        foreach($dataArr as $value){
            $reorderedArr[] = $value->$keyName;
        }
       }

       return $reorderedArr;
    }
}

if (!function_exists("serializeArr")) {
    function serializeArr($dataArr, $keyName)
    {
       $reorderedArr = [];

       if(sizeof($dataArr) > 0){
        foreach($dataArr as $value){
            $reorderedArr[$value->$keyName] = $value;
        }
       }

       return $reorderedArr;
    }

    
}

if ( ! function_exists('drug_options')){
        function drug_options($table,$where,$columns,$valueColumn,$displayColumn,$order,$serialize,$selectedText = '',$selectedValue = 0, $dataColumns = array()){
            if(!empty($selectedText)){
                $response = '<option value="">'.$selectedText.'</option>' ;
            }else{
                $response = '' ;
            }
            $_CI = &get_instance();
            $_CI->load->model('drug_model');
            $info = $_CI->drug_model->findAll($table,$where,$order,$serialize);
            //$info = $_CI->drug_model->getAllMedicines_list($where);
            $selected = '' ;
            foreach ($info as $key => $value) { 
                $merge = '' ;
                $data = '' ;
                $selected = $selectedValue == $value->$valueColumn ? 'selected' : '' ;
                if(empty($displayColumn)){
    
                    foreach ($columns as $k => $v) {
                        $merge .= $value->$v.' - ';
                    }
                    $merge = rtrim($merge,' - ');
                }
                if(count($dataColumns)){
                    foreach ($dataColumns as $k1 => $v1) {
                      //  $data .= "data-$v1=".$value->$v1 .' ';
                        $val = urlencode($value->$v1) ;
                        $data .= "data-$v1= $val ";
                    }
                }
                $data .= "data-type= Medicine";
                if(empty($displayColumn)){
                    $display = $merge;
                }else{
                    $display = $value->$displayColumn;
                }
                $response .='<option '.$selected.' value="'.$value->$valueColumn.'"'.$data.'>'.$display.'</option>';
            }
            return $response;
        }
    }



    
if (!function_exists('updateStock')) {
    function updateStock($productId,$detailsId, $qty, $date, $type = 'purchase', $price=0,$salePrice=0, $logMovement = true){
        
        $_CI = &get_instance();
              
        if (!$logMovement || $type== 'sales_return' || $type =='purchase_return'){
             $where = ['record_id'=>$productId];
        $productData = $_CI->db->select('unit_price, product_stock, unit_mrp')->where($where)->get('drug_medicine')->row();
        
        if (!$productData) {
            return false; // product not found
        }
        
        $newQty = $productData->product_stock;
        if ($type == 'purchase' || $type == 'sales_return'){
            $newQty += $qty;
        }else{
            $newQty -= $qty;
        }

        $_CI->db->where($where)->update('drug_medicine',['product_stock'=>$newQty]); 
        }

     
        if ($logMovement){

            $stockData = [
                'product_id'        => $productId,
                'details_id'        => $detailsId,
                'type'              => $type,
                'quantity'          => $qty,
                'price'             => $price,
                'sale_price'        => $salePrice,
                'date'              => $date,
       
            ];
            

            $_CI->Common_model->saveData('product_stocks',$stockData);
        }
       
        return true;
    }

}


if (!function_exists('deleteStock')) {
    function deleteStock($detailsId, $productId, $type = 'purchase'){
        $_CI = &get_instance();
        $where = ['product_id'=>$productId, 'details_id'=>$detailsId, 'type'=>$type];
        $old  = $_CI->db->get_where('product_stocks', $where)->row();
        if (!$old) return false;

        $reverseType = ($type == 'purchase' || $type == 'sales_return') ? 'sales' : 'purchase';
        updateStock($productId, $detailsId, $old->quantity, $old->date, $reverseType,0,0, false);
        
        $_CI->db->where('id', $old->id)->delete('product_stocks');
        return true;
    }
}

if (!function_exists('currency')) {
    function currency($amount=0, $symbol = '') {
        return $symbol . ' ' . number_format((float)$amount, 2, '.', ',');
    }
}


if (!function_exists('medicineOptions')) {
    function medicineOptions($selectedValue=''){
         $_CI = &get_instance();
         $_CI->load->model('drug_model');
         $medicines = $_CI->drug_model->getAllMedicines();
         $option = "<option value=''>Select Medicine</option>";
         foreach($medicines as $medicine){
            $strength       = !empty($medicine->strength) ? ' - ' . $medicine->strength : '';
            $dose           = !empty($medicine->dosage_name) ? ' - ' . $medicine->dosage_name : '';
            $generic_name   = !empty($medicine->generic_name) ? ' - ' . $medicine->generic_name : '';

            $displayName    = $medicine->brand_name.$strength.$dose.' - '.$medicine->record_id;
            $selected       = ($selectedValue && $selectedValue == $medicine->record_id)? 'selected' : '' ;

            $option         .="<option
            $selected 
             data-unit_id='1' data-unit_name='Pcs'
             data-unit_price='$medicine->unit_price'
             data-unit_mrp='$medicine->unit_mrp'
             data-product_name='displayName'
             value='$medicine->record_id'>$displayName</option>";
        }

        return $option;
    }

}


if ( ! function_exists('uploadImage')){
        function uploadImage($field_name, $path = 'uploads/',  $allowed_types= '*')
        {
            $CI =& get_instance();
      
            if (
                !isset($_FILES[$field_name]) ||
                $_FILES[$field_name]['error'] !== UPLOAD_ERR_OK
            ) {
                return false;
            }

            if (!is_dir($path)) {
                mkdir($path, 0755, true);
            }

            $config = [
                'upload_path'   => $path,
                'allowed_types' => $allowed_types,
                'encrypt_name'  => true,
                'detect_mime'   => true,
                'max_size'      => 2048,
            ];

            // dd($config);
            $CI->load->library('upload', $config);
            $CI->upload->initialize($config);
            if (!$CI->upload->do_upload($field_name)) {
                return false;
            }
            $data = $CI->upload->data();
            return $path . $data['file_name'];
        }
}





if(!function_exists('hasEditDeletePermission')){
    function hasEditDeletePermission($isEdit=false, $isDelete=false){
         $_CI           = &get_instance();
         $user          = (object) $_CI->session->userdata;
         
         $userType      = $user->ses_user_type;
         if($userType == "admin") return true;
    
         if($userType == "staff"){
            $userId =  $user->ses_record_id;
            $where = ['record_id'=>$userId];
            $mainUser =  $_CI->db->where($where)->get('staff')->row();
            $editAction     = $mainUser->edit_action;
            if($isEdit && $editAction) return true;
            $deleteAction   = $mainUser->delete_action;
            if($isDelete && $deleteAction) return true;
            return redirect('forbidden');
         }
        return redirect('/');
        //  return false;
    }
}

if(!function_exists('hasEditPermission')){
    function hasEditPermission(){
        return hasEditDeletePermission(true);
    }
}

if(!function_exists('hasDeletePermission')){
    function hasDeletePermission(){
        return hasEditDeletePermission(false, true);
    }
}


function getDeuCollectionTypes($key){
    $types = [
        'ivf'       => ['IVF Test Invoice'],
        'outdoor'   => ['Test Invoice', 'Appointment'],
        'indoor'    => ['Operation', 'Collection', 'Admission', 'Ambulance', 'Emergency'],
    ];
    return $types[$key]??[];
}

if (!function_exists('dd')) { 
    function dd($data){
        echo '<pre style="background-color:#000; color:#7aff00;padding:50px; margin:-20px">';
        print_r($data);
        echo '</pre>';
        exit();
    }
}

