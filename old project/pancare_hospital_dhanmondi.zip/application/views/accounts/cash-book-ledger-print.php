<style>
@page {
	   size: 10.5in 7in;
	   margin: 5px;
	}
</style>
<?php 
	$campus = $this->db->select("*") ->from('campus') ->where('campus_status', 1) ->order_by('campus_id', 'ASC') ->get() ->result();
	foreach ($campus as $campus_row) 
	{
		$campus_name			= $campus_row->campus_name; 
		$campus_address			= $campus_row->campus_address;
		$campus_phone			= $campus_row->campus_phone; 
		$campus_fax				= $campus_row->campus_fax;
		$campus_email			= $campus_row->campus_email;
		$campus_website			= $campus_row->campus_website; 
		$currency				= $campus_row->campus_currency; 
		$campus_logo			= $campus_row->campus_logo;
	}
?> 
<body onload="window.print();">
	<div class="col-md-12 mg-t-5">
		<div class="tx-center">
			<!-- <img src="<?= base_url("$campus_logo");?>" alt="" width="90"><br/> -->
			
			<h5 class="tx-uppercase"><?= $campus_name;?></h5>
			<p class="tx-uppercase"><?= $campus_address;?></p>
			
			<h6 class="tx-uppercase tx-underlinetx-bold"><?= $page_name;?></h6>
			
			<p class="tx-uppercase "><?= $this->lang->line('from_the_date_of');?> <?= date('d/m/Y', strtotime($from_date));?> <?= $this->lang->line('to');?> <?= date('d/m/Y', strtotime($to_date));?><br/><?= $this->lang->line('print_date');?> <?= date('d/m/Y h:i A');?></p>
		</div><br/>
		<table class="table table-striped table-bordered table-hover">
			<thead class="tx-uppercase">
				<tr>  
					<th class="tx-center" rowspan="2"><?= $this->lang->line('sl');?></th> 
					<th class="tx-center" rowspan="2"><?= $this->lang->line('control_group');?></th>
					<th class="tx-center" colspan="2"><?= $this->lang->line('ledger');?></th>
					<th class="tx-center" rowspan="2"><?= $this->lang->line('voucher');?></th>
					<th class="tx-center" colspan="4"><?= $this->lang->line('amount');?></th>
				</tr>
				
				<tr>  
					<th class="tx-center"><?= $this->lang->line('general');?></th>
					<th class="tx-center"><?= $this->lang->line('subsidiary');?></th>
					
					<th class="tx-center"><?= $this->lang->line('debit');?></th>
					<th class="tx-center"><?= $this->lang->line('credit');?></th> 
					<th class="tx-center"><?= $this->lang->line('balance');?></th>
				</tr>
			</thead>
			<tbody id="cash_book_ledger_info">
				<!-- <?= $this->accounts_model->cash_book_ledger($project, $from_date, $to_date);?> -->
				<?= $this->accounts_model->cash_book_ledger($from_date, $to_date);?>
			</tbody>
		</table>
		
		<br/><br/><br/>
		
		<table class="" width="100%" align="center">  
			<tr class="tx-uppercase">
				<th width="30%" class="text-center bd-top"><?= $this->lang->line('prepared_by');?></th>
				<th width="5%"></th>
				<th width="30%" class="text-center bd-top"><?= $this->lang->line('checked_by');?></th>
				<th width="5%"></th>
				<th width="30%" class="text-center bd-top"><?= $this->lang->line('authorised');?></th>
			</tr>
		</table>
	</div>
</body>