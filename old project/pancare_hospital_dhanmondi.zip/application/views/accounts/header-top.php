<!DOCTYPE html>
<html lang="en">
	<head>
		<!-- Meta -->
		<meta charset="utf-8">
		<meta http-equiv="x-ua-compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="<?= $system_name;?>">
		<meta name="keyword" content="<?= $system_name;?>">
		<meta name="author"  content="<?= $system_name;?>">

		<!-- Title -->
		<title> <?= $page_title;?> | <?= $system_title;?></title>
		
		<!-- Icon -->
		<link rel="icon" href="<?= base_url("$system_logo");?>" type="image/png">
		
		<!-- CSS -->
		<link type="text/css" rel="stylesheet" href="<?= base_url('assets/assets/plugins/daterangepicker/daterangepicker.css');?>">
		<link type="text/css" rel="stylesheet" href="<?= base_url('assets/assets/plugins/chartist/chartist.css');?>">
		<link type="text/css" rel="stylesheet" href="<?= base_url('assets/assets/plugins/jqvmap/jquery-jvectormap-2.0.2.css');?>">
		<link type="text/css" rel="stylesheet" href="<?= base_url('assets/assets/css/style.css');?>">
		
		<link type="text/css" rel="stylesheet" href="<?= base_url('assets/assets/plugins/select2/css/select2.min.css');?>"/>
		<link type="text/css" rel="stylesheet" href="<?= base_url('assets/assets/plugins/prism/prism-vs.css');?>"/> 
		<link rel="stylesheet" href="<?= base_url('assets/assets/plugins/jstree/themes/default/style.min.css');?>">
		<!-- <link rel="stylesheet" href="<?= base_url('assets/assets/plugins/summernote/summernote.css');?>"> -->
		<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
		<!-- <script src="<?= base_url('assets/assets/js/jquery-1.11.3.min.js');?>"></script> -->
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
		

		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn"t work if you view the page via file:// -->
		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->
	<style>
		body {
			background-color: #ffebeb !important;
		}
		.breadcrumb-item.active {
			color: #0088fc !important;
		}
		</style>	
	</head>