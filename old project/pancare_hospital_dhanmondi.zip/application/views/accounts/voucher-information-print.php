<style>
@page {
	   size: 7in 10.5in;
	   margin: 5px;
	}
</style>
<?php 
	$campus = $this->db->select("*") ->from('campus') ->where('campus_status', 1) ->order_by('campus_id', 'ASC') ->get() ->result();
	foreach ($campus as $campus_row) 
	{
		$campus_name			= $campus_row->campus_name;
		$campus_address			= $campus_row->campus_address;
		$campus_phone			= $campus_row->campus_phone; 
		$campus_fax				= $campus_row->campus_fax;
		$campus_email			= $campus_row->campus_email;
		$campus_website			= $campus_row->campus_website; 
		$currency				= $campus_row->campus_currency;
		$campus_logo			= $campus_row->campus_logo;
	}
?> 
<body onload="window.print();">
	<div class="col-md-12 mg-t-5">
		
		<div class="tx-center">
			<img src="<?= base_url("$campus_logo");?>" alt="" width="90"><br/>
			
			<h5 class="tx-uppercase"><?= $campus_name;?></h5>
			<p class="tx-uppercase"><?= $campus_address;?></p>
			
			<h6 class="tx-uppercase tx-underline tx-bold"><?= $page_name;?></h6>
			<p class="tx-uppercase"><?= $this->lang->line('from_the_date_of');?> <?= date('d/m/Y', strtotime($posting_from_date));?> <?= $this->lang->line('to');?> <?= date('d/m/Y', strtotime($posting_to_date));?><br/>
			<?= $this->lang->line('print');?> <?= $this->lang->line('date');?>: <?= date('d/m/Y h:i A');?>
			</p>
		</div>
		
		<table class="table table-striped table-bordered table-hover">
			<thead class="tx-10 tx-uppercase">
				<tr> 
					<th class="tx-center"><?= $this->lang->line('sl_no');?></th>
					<th class="tx-center"><?= $this->lang->line('posting_date');?></th>
					<th class="tx-center"><?= $this->lang->line('voucher_type');?></th>
					<th class="tx-center"><?= $this->lang->line('voucher_number');?></th>
					<th class="tx-center"><?= $this->lang->line('narration');?></th>
					<th class="tx-center"><?= $this->lang->line('debit');?></th>
					<th class="tx-center"><?= $this->lang->line('credit');?></th>
				</tr>
			</thead>
			<tbody>
				<?php echo $this->accounts_model->voucher_information_print($voucher_type, $posting_from_date, $posting_to_date);?>
			</tbody>
		</table>
		</div><br/><br/><br/>
		
		<table class="tx-11" width="100%" align="center">  
			<tr class="tx-uppercase">
				<th width="15%" class="text-center bd-top"><?= $this->lang->line('prepared_by');?></th>
				<th width="20%"></th>
				<th width="15%" class="text-center bd-top"><?= $this->lang->line('checked_by');?></th>
				<th width="20%"></th>
				<th width="15%" class="text-center bd-top"><?= $this->lang->line('authorized');?></th>
			</tr>
		</table> 
	</div>
</body>