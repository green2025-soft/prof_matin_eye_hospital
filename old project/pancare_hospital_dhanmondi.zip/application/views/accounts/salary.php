<!-- Page Inner Start --> 
<div class="page-inner">
	<!-- Main Wrapper -->
	<div id="main-wrapper"> 
	  <!-- Breadcrumb Start --> 
		<div class="pageheader pd-t-10 pd-b-10">
			<div class="d-flex justify-content-between">
				<div class="clearfix tx-uppercase">
					<div class="pd-t-5 pd-b-5">
					  <h1 class="pd-0 mg-0 tx-20 tx-dark"><?= $page_name;?></h1>
					</div>
					<div class="breadcrumb pd-0 mg-0">
						<a class="breadcrumb-item" href="<?= base_url('./login');?>"><i class="fa fa-dashboard"></i> <?= $this->lang->line('dashboard');?></a>
						<a class="breadcrumb-item" href="javascript:void(0);"><?= $this->lang->line('accounts');?></a>
						<span class="breadcrumb-item active"><?= $page_name;?></span>
					</div>
				</div>
				<div class="d-flex align-items-center tx-uppercase"> 
					<button type="button" class="btn btn-outline-success rounded-pill mr-2 d-lg-block pd-t-6-force pd-b-5-force tx-uppercase" onclick="window.location.href='<?= base_url('./login');?>'"> <i class="fa fa-home"></i> <?= $this->lang->line('dashboard');?></button>
				</div>
			</div>
		</div>
		<!--/ Breadcrumb End -->
	  
		<!-- Articles Start -->
		<div class="card mg-b-30"> 
			<!------------- Flash Massage Start ------------->
			<?php if ($this->session->flashdata('success') != null) {  ?>
			<div class="alert alert-success">
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				<center><?php echo $this->session->flashdata('success'); ?></center>
			</div> 
			<?php } ?>
			
			<?php if ($this->session->flashdata('update') != null) {  ?>
			<div class="alert alert-info">
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				<center><?php echo $this->session->flashdata('update'); ?></center>
			</div> 
			<?php } ?>
			
			<?php if ($this->session->flashdata('error') != null) {  ?>
			<div class="alert alert-danger">
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				<center><?php echo $this->session->flashdata('error'); ?></center>
			</div>
			<?php } ?>
			<!------------- Flash Massage End ------------->
			
			<form method="post" action="<?= base_url('accounts/salary_create');?>">
				<div class="col-md-12">
					<div class="form-row mg-t-10">
						<div class="col-md-4 col-sm-12">
							<label for="label"><?= $this->lang->line('month');?> *</label> 
							<input type="month" class="form-control form-control-sm bd-danger" id="salary_month" name="salary_month" value="<?= date('Y-m');?>"required>
						</div>
						<div class="col-md-4 col-sm-12">
							<label for="label"><?= $this->lang->line('date');?> *</label> 
							<input type="date" class="form-control form-control-sm bd-danger" id="salary_date" name="salary_date" value="<?= date('Y-m-d');?>"required>
						</div>
						<div class="col-md-4 col-sm-12">
							<label for="label"> &nbsp;  </label>  
							<button type="button" class="btn btn-brand btn-block tx-uppercase" id="process"><?= $this->lang->line('process');?></button>
						</div>
					</div> 
				</div><br/>  
				<div class="col-md-12">
					<div class="table-responsive">
						<table class="table table-striped table-bordered table-hover" style="font-size:10px;">
							<thead class="tx-uppercase">
								<tr> 
									<th class="tx-center" rowspan="2"><?= $this->lang->line('sl');?></th>
									<th class="tx-center" colspan="2"><?= $this->lang->line('employee_information');?></th>
									<th class="tx-center" colspan="6"><?= $this->lang->line('salary');?></th>
									<th class="tx-center" colspan="4"><?= $this->lang->line('deduction');?></th>
									
									<th class="tx-center" rowspan="2"><?= $this->lang->line('payable');?><br/><?= $this->lang->line('amount');?></th>
									<th class="tx-center" rowspan="2"><?= $this->lang->line('paid');?><br/><?= $this->lang->line('amount');?></th>
								</tr> 
								<tr> 
									<th class="tx-center"><?= $this->lang->line('employee_name');?></th>
									<th class="tx-center"><?= $this->lang->line('designation');?></th>
									
									<th class="tx-center"><?= $this->lang->line('basic_salary');?></th>
									<th class="tx-center"><?= $this->lang->line('house_rent');?></th>
									<th class="tx-center"><?= $this->lang->line('medical');?></th>
									<th class="tx-center"><?= $this->lang->line('conveyance');?></th>
									<th class="tx-center"><?= $this->lang->line('others');?></th>
									<th class="tx-center"><?= $this->lang->line('gross');?></th>
									
									<th class="tx-center"><?= $this->lang->line('stamp');?></th>
									<th class="tx-center"><?= $this->lang->line('tax');?></th>
									<th class="tx-center"><?= $this->lang->line('vat');?></th>
									<th class="tx-center"><?= $this->lang->line('others');?></th>
								</tr> 
							</thead>
							<tbody id="salary_info">
								
							</tbody>
						</table>
					</div>
					<script>
					$(document).ready(function(){
						$('#process').click(function(){  
						  var salary_month = $('#salary_month').val();
						  var salary_date = $('#salary_date').val();
						  if(salary_date != '')
						  {
						   $.ajax({
							url:"<?= base_url('accounts/get_salary_process_info'); ?>",
							beforeSend: function() {
							$('#salary_info').html('<tr class="tx-center tx-uppercase"><th colspan="15"><img src="<?= base_url("assets/images/loading/loader.gif");?>"/><h6 class="tx-center tx-uppercase tx-13 tx-bold"><?= $this->lang->line("loading");?></h6></th></tr>');
							},
							method:"POST",
							data:{salary_month:salary_month, salary_date:salary_date},
							success:function(data)
							{
							 $('#salary_info').html(data);
							}
						   });
						  }
						  else
						  {
						   $('#salary_info').html('<tr class="tx-center tx-uppercase tx-danger"><th colspan="15"><?= $this->lang->line("data_searching_error");?></th></tr>');
						  }
						});
					}); 
					</script>
				</div>	
			</form>
		</div>
		<!--/ Articles End -->				  
   </div>
   <!--/ Main Wrapper End -->
</div>
<!--/ Page Inner End -->