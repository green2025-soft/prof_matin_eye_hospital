<style>
@page {
	   size: 7in 10.5in;
	   margin: 5px;
	}
</style>
<?php 
	$campus = $this->db->select("*") ->from('campus') ->where('campus_status', 1) ->order_by('campus_id', 'ASC') ->get() ->result();
	foreach ($campus as $campus_row) 
	{
		$campus_name			= $campus_row->campus_name; 
		$campus_address			= $campus_row->campus_address;
		$campus_phone			= $campus_row->campus_phone; 
		$campus_fax				= $campus_row->campus_fax;
		$campus_email			= $campus_row->campus_email;
		$campus_website			= $campus_row->campus_website; 
		$currency				= $campus_row->campus_currency; 
		$campus_logo			= $campus_row->campus_logo;
	}
?> 
<body onload="window.print();">
	<div class="col-md-12 mg-t-5">
		<div class="tx-center">
			<img src="<?= base_url("$campus_logo");?>" alt="" width="50"><br/>
			
			<h5 class="tx-uppercase"><?= $campus_name;?></h5>
			<p class="tx-uppercase"><?= $campus_address;?></p>
			
			<h6 class="tx-uppercase tx-underlinetx-bold"><?= $page_name;?></h6>
			
			<p class="tx-uppercase "><?= $this->lang->line('as_on');?> <?= date('t F, Y', strtotime($closing_month));?><br/><?= $this->lang->line('print_date');?> <?= date('d/m/Y h:i A');?></p>
		</div><br/>
		<?= $this->accounts_model->cash_flow_statement($closing_month);?>
	</div>
</body>