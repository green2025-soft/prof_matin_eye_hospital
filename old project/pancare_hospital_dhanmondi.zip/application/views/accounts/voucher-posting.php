<!-- Page Inner Start -->
<div class="page-inner" style="margin-bottom:80px;">
	<!-- Main Wrapper -->
	<div id="main-wrapper">
		
		<!-- Breadcrumb Start -->
		<div class="pageheader pd-t-10 pd-b-10">
			<div class="d-flex justify-content-between">
				<div class="clearfix tx-uppercase">
					<div class="pd-t-5 pd-b-5">
						<h1 class="pd-0 mg-0 tx-20 tx-dark"><?= $page_name; ?></h1>
					</div>
					<div class="breadcrumb pd-0 mg-0">
						<a class="breadcrumb-item" href="<?= base_url('./login'); ?>"><i class="fa fa-dashboard"></i> <?= $this->lang->line('dashboard'); ?></a>
						<span class="breadcrumb-item active"><?= $page_name; ?></span>
					</div>
				</div>
				<div class="d-flex align-items-center tx-uppercase">
					<button type="button" class="btn btn-outline-success rounded-pill mr-2 d-lg-block pd-t-6-force pd-b-5-force tx-uppercase" onclick="window.location.href='<?= base_url('/accounts/voucher_information'); ?>'"> <i class="fa fa-list"></i> <?= $this->lang->line('voucher_information'); ?></button>
				</div>
			</div>
		</div>
		<!--/ Breadcrumb End -->

		<!-- Articles Start -->
		<div class="card mg-b-30">
			<!------------- Flash Massage Start ------------->
			<?php if ($this->session->flashdata('success') != null) {  ?>
				<div class="alert alert-success">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
					<center><?php echo $this->session->flashdata('success'); ?></center>
				</div>
			<?php } ?>

			<?php if ($this->session->flashdata('update') != null) {  ?>
				<div class="alert alert-info">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
					<center><?php echo $this->session->flashdata('update'); ?></center>
				</div>
			<?php } ?>

			<?php if ($this->session->flashdata('error') != null) {  ?>
				<div class="alert alert-danger">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
					<center><?php echo $this->session->flashdata('error'); ?></center>
				</div>
			<?php } ?>
			<!------------- Flash Massage End ------------->

			<form method="post" action="<?= base_url('accounts/voucher_posting_create'); ?>">
				<div class="col-md-12">
					<div class="form-row mg-t-10">
						<div class="col-md-4 col-sm-12">
							<label for="label"><?= $this->lang->line('posting_date'); ?> *</label>
							<input type="hidden" class="form-control form-control-sm bd-danger" id="accounts_project" name="accounts_project" value="0" required>
							<input type="date" class="form-control form-control-sm bd-danger" id="accounts_voucher_posting_date" name="accounts_voucher_posting_date" value="<?= date('Y-m-d'); ?>" required>
						</div>
						<div class="col-md-4 col-sm-12">
							<label for="label"><?= $this->lang->line('voucher_type'); ?> *</label>
							<select class="form-control form-control-sm bd-danger selectpicker" id="accounts_voucher_type" name="accounts_voucher_type" data-live-search="true" required>
								<option value=""> --- <?= $this->lang->line('select'); ?> ---</option>
								<?php
								foreach ($voucher_type as $voucher_type_row) { ?>
									<option value="<?= $voucher_type_row->voucher_type_id; ?>"><?= $voucher_type_row->voucher_type_name; ?></option>
								<?php } ?>
							</select>
						</div>
						<div class="col-md-4 col-sm-12">
							<label for="label"><?= $this->lang->line('reference_number'); ?></label>
							<input type="text" class="form-control form-control-sm bd-danger" id="accounts_reference_number" name="accounts_reference_number" value="">
						</div>
					</div>
				</div><br />

				<div class="col-md-12">
					<div class="form-row mg-t-10">
						<div class="col-md-3 col-sm-12" id="voucher_number_info">
							<label for="label"><?= $this->lang->line('voucher_number'); ?> *</label>
							<input type="text" class="form-control form-control-sm bd-danger" id="accounts_voucher_number" name="accounts_voucher_number" value="" readonly required>
						</div>
						<div class="col-md-6 col-sm-12">
							<label for="label"><?= $this->lang->line('narration'); ?></label>
							<input type="text" class="form-control form-control-sm bd-danger" id="accounts_narration" name="accounts_narration" value="">
						</div>
						<div class="col-md-3 col-sm-12">
							<label for="label"> &nbsp; </label>
							<button type="button" class="btn btn-brand btn-sm btn-info tx-uppercase pull-right" id="addSlotBtn" style="margin-top: 25px;">Add</button>
						</div>
					</div>
				</div><br />
				<div class="col-md-12" id="collection_info">
					<div class="table-responsive">
						<table class="table table-striped table-bordered table-hover">
							<thead class="tx-uppercase">
								<tr>
									<!--
									<th class="tx-center" width="10%"><?= $this->lang->line('accounts_type'); ?></th>
									<th class="tx-center" width="10%"><?= $this->lang->line('head_of_accounts'); ?></th>
									<th class="tx-center" width="14%"><?= $this->lang->line('control_group'); ?></th>-->
									<th class="tx-center" width="14%"><?= $this->lang->line('general_ledger'); ?></th>
									<th class="tx-center" width="14%"><?= $this->lang->line('subsidiary_ledger'); ?></th>
									<!--<th class="tx-center" width="7%"><?= $this->lang->line('debit'); ?> <?= $this->lang->line('qnty'); ?></th>
									<th class="tx-center" width="7%"><?= $this->lang->line('credit'); ?> <?= $this->lang->line('qnty'); ?></th>-->
									<th class="tx-center" width="12%"><?= $this->lang->line('debit'); ?> <?= $this->lang->line('amount'); ?></th>
									<th class="tx-center" width="12%"><?= $this->lang->line('credit'); ?> <?= $this->lang->line('amount'); ?></th>
								</tr>
							</thead>
							<tbody id="ledgerTbody">
							</tbody>
						</table>
					</div>
				</div>
				<div class="row ">
					<div class="col-md-12 col-sm-12" style="text-align: center;">
						<label for="label"> &nbsp; </label>
						<button type="submit" class="btn btn-brand col-md-3 btn-sm btn-success tx-uppercase" onclick="return confirm('<?= $this->lang->line("model_create_warning"); ?>')"><?= $this->lang->line('submit'); ?></button>
					</div>
				</div>
			</form>
		</div>
		<!--/ Articles End -->
	</div>
	<!--/ Main Wrapper End -->
</div>
<!--/ Page Inner End -->


<script>
	console.log('Reached Here');
	var counter = 0;

	function getLedgers() {
		return new Promise((res, rej) => {
			$.ajax({
				url: "<?= base_url('accounts/ledgerData'); ?>",
				method: "GET",
				success: function(data) {
					res(data);
				}
			}).fail(function(xhr, status, error) {
				rej(status);
			});
		});
	}

	function getSubLedger(accounts_category){

		return new Promise((res, rej) => {
			$.ajax({
				url: "<?= base_url('accounts/voucher_posting_accounts_category_info'); ?>",
				method: "POST",
				data:{accounts_category:accounts_category},
				success: function(data) {
					res(data);
				}
			}).fail(function(xhr, status, error) {
				rej(status);
			});
		});
	} 
	async function prepareTrHTML(totalFlag = false) {

		try{
			let ledgers = await getLedgers();

		let renderHtml = `
					<tr id="trSerial-${++counter}">
									<td class="tx-center">
										<input type="hidden" class="form-control form-control-sm" name="count" value="${counter}"required>
										<select class="form-control form-control-sm generalLedgerDD selectpicker" id="accounts_details_general_ledger_${counter}" data-id="${counter}" name="accounts_details_general_ledger[]" data-live-search="true" required>
										${ledgers}
										</select>
									</td> 
									<td class="tx-center">
										<select class="form-control form-control-sm" id="accounts_details_subsidiary_ledger_${counter}" name="accounts_details_subsidiary_ledger[]"required>
											<option value="0"></option>
										</select>
									</td> 
									<td class="tx-center">
										<input type="text" class="form-control form-control-sm tx-center debit" id="accounts_details_debit" name="accounts_details_debit[]" autocomplete="off">
									</td> 
									<td class="tx-center">
										<input type="text" class="form-control form-control-sm tx-center credit" id="accounts_details_credit" name="accounts_details_credit[]" autocomplete="off">
									</td> 
								</tr>`;
								if(totalFlag){
									renderHtml+=`
								<tr>
									<th class="tx-center tx-uppercase" colspan="2">Total</th>
									
									<th class="tx-center">
										<input type="text" class="form-control form-control-sm bd-danger tx-center total_debit" id="total_debit" name="accounts_total_debit"readonly>
									</th>
									<th class="tx-center"> 
										<input type="text" class="form-control form-control-sm bd-danger tx-center total_credit" id="total_credit" name="accounts_total_credit"readonly>
									</th>
								</tr>`;
								}

		return renderHtml;
		}catch(err){
			console.log('Err Block',err);
		}
	}

	async function loadTable() {
		let ledgerHtml = await prepareTrHTML(true);
		$('#ledgerTbody').html(ledgerHtml);
	}
	loadTable();

	$(document).ready(function() {

		$('#addSlotBtn').click(async function(){
			let ledgerHtml = await prepareTrHTML();
			console.log(counter);
			let prevSer =counter-1;
			$(ledgerHtml).insertAfter('#trSerial-'+prevSer);
		});

		$(document).on('change', '.generalLedgerDD', async function(){
			let serial = $(this).data('id');
			let ledgerCatId = parseInt($(this).val());
			if(ledgerCatId > 0){
				 let subledgerData = await getSubLedger(ledgerCatId);
				 $('#accounts_details_subsidiary_ledger_'+serial).html(subledgerData);

			}
			console.log(serial);
		});
		$('#accounts_voucher_posting_date, #accounts_voucher_type').change(function() {
			var accounts_voucher_posting_date = $('#accounts_voucher_posting_date').val();
			var accounts_voucher_type = $('#accounts_voucher_type').val();
			if (accounts_voucher_type != '') {
				$.ajax({
					url: "<?= base_url('accounts/get_voucher_number_info'); ?>",
					method: "POST",
					data: {
						accounts_voucher_type: accounts_voucher_type,
						accounts_voucher_posting_date: accounts_voucher_posting_date
					},
					success: function(data) {
						$('#voucher_number_info').html(data);
					}
				});
			} else {
				$('#voucher_number_info').html('<label for="label"><?= $this->lang->line('voucher_number'); ?> *</label> <input type="text" class="form-control form-control-sm bd-danger" id="accounts_voucher_number" name="accounts_voucher_number" value=""readonly required>');
			}
		});
	});

	$(document).ready(function() {
		$('.debit_quantity').keyup(function() {

			var sum = 0;
			$(".debit_quantity").each(function() {
				sum += +$(this).val();
			});

			$('#total_debit_quantity').val(sum);
		});
	});

	$(document).ready(function() {
		$('.credit_quantity').keyup(function() {

			var sum = 0;
			$(".credit_quantity").each(function() {
				sum += +$(this).val();
			});

			$('#total_credit_quantity').val(sum);
		});
	});

	$(document).ready(function() {
		$(document).on('keyup', '.debit', function(){
			var sum = 0;
			$(".debit").each(function() {
				sum += +$(this).val();
			});

			$('#total_debit').val(sum);
		});
		$(document).on('keyup', '.credit', function(){
			var sum = 0;
			$(".credit").each(function() {
				sum += +$(this).val();
			});

			$('#total_credit').val(sum);
		});
	});
</script>