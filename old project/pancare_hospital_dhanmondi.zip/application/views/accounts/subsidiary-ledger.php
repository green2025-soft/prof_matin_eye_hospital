<!-- Page Inner Start --> 
<div class="page-inner" style="margin-bottom:80px;">
	<!-- Main Wrapper -->
	<div id="main-wrapper"> 
	  <!-- Breadcrumb Start --> 
		<div class="pageheader pd-t-10 pd-b-10">
			<div class="d-flex justify-content-between">
				<div class="clearfix tx-uppercase">
					<div class="pd-t-5 pd-b-5">
					  <h1 class="pd-0 mg-0 tx-20 tx-dark"><?= $page_name;?></h1>
					</div>
					<div class="breadcrumb pd-0 mg-0">
						<a class="breadcrumb-item" href="<?= base_url('./login');?>"><i class="fa fa-dashboard"></i> <?= $this->lang->line('dashboard');?></a>
						<a class="breadcrumb-item" href="javascript:void(0);"><?= $this->lang->line('accounts');?></a>
						<span class="breadcrumb-item active"><?= $page_name;?></span>
					</div>
				</div>
				<div class="d-flex align-items-center tx-uppercase">
					<button type="button" class="btn btn-outline-success rounded-pill mr-2 d-lg-block pd-t-6-force pd-b-5-force tx-uppercase" onclick="history.back()"> <i class="fa fa-arrow-left"></i> <?= $this->lang->line('go_back'); ?></button>
				</div>
			</div>
		</div>
		<!--/ Breadcrumb End -->
	  
		<!-- Articles Start -->
		<div class="card mg-b-30"> 
			
			<div class="col-md-12">
			<form method="post" target="print_popup" action="<?= base_url('accounts/subsidiary_ledger_print');?>" onsubmit="window.open('about:blank','print_popup','width=800,height=700');">
					
				<div class="form-row mg-t-10 mg-b-10">
					<div class="col-md-3 col-sm-12">
						<label for="label"><?= $this->lang->line('starting_date');?> *</label> 
						<input type="date" class="form-control form-control-sm bd-danger" id="starting_date" name="starting_date" value="<?= date('Y-m-d');?>"required>
					</div>
					<div class="col-md-3 col-sm-12">
						<label for="label"><?= $this->lang->line('closing_date');?> *</label> 
						<input type="date" class="form-control form-control-sm bd-danger" id="closing_date" name="closing_date" value="<?= date('Y-m-d');?>"required>
					</div>
					<div class="col-md-3 col-sm-12">
						<label for="label"><?= $this->lang->line('accounts_type');?> *</label> 
						<select class="form-control form-control-sm bd-danger" id="accounts_type" name="accounts_type"required>
							<option value=""> --- <?= $this->lang->line('select');?> ---</option>
							<?php 
							$accounts_type =  $this->db->select("*")
							->from('accounts_type')
							->where('accounts_type_status', 1)
							->order_by('accounts_type_code', 'ASC')
							->get()
							->result();
							foreach($accounts_type as $accounts_type_row) {?>
							<option value="<?= $accounts_type_row->accounts_type_id;?>"><?= $accounts_type_row->accounts_type_code;?>-<?= $accounts_type_row->accounts_type_name;?></option>
							<?php }?>
						</select>
					</div>
					<div class="col-md-3 col-sm-12">
						<label for="label"><?= $this->lang->line('accounts_category');?> *</label> 
						<select class="form-control form-control-sm bd-danger" id="accounts_category" name="accounts_category"required> 
						</select>
					</div>
				</div>
				<div class="form-row mg-t-10">
					<div class="col-md-3 col-sm-12">
						<label for="label"><?= $this->lang->line('control_group');?> *</label> 
						<select class="form-control form-control-sm bd-danger" id="control_group" name="control_group"required> 
						</select>
					</div>
					<div class="col-md-3 col-sm-12">
						<label for="label"><?= $this->lang->line('general_ledger');?> *</label> 
						<select class="form-control form-control-sm bd-danger" id="general_ledger" name="general_ledger"required> 
						</select>
					</div>
					<div class="col-md-2 col-sm-12">
						<label for="label"><?= $this->lang->line('subsidiary_ledger');?> *</label> 
						<select class="form-control form-control-sm bd-danger" id="subsidiary_ledger" name="subsidiary_ledger"required> 
						</select>
					</div>
					<div class="col-md-2 col-sm-12">
						<label for="label">&nbsp;</label>
						<button type="button" id="search" class="btn btn-brand btn-success btn-block tx-uppercase"><i class="fa fa-search"></i> <?= $this->lang->line('search');?></button>
					</div>
					
					<div class="col-md-2 col-sm-12">
						<label for="label"> &nbsp; </label> 
						<button type="submit" class="btn btn-brand  btn-block tx-uppercase"><i class="fa fa-print"></i> <?= $this->lang->line('print');?></button>
					</div>
				</div>
			</form>
			</div><br/> 
			<div class="col-md-12" id="subsidiary_ledger_info">
				<div class="table-responsive">
					<table class="table table-bordered table-hover">
						<thead class="tx-10 tx-uppercase">
							<tr>  
								<th class="tx-center"><?= $this->lang->line('date');?></th>
								<th class="tx-center"><?= $this->lang->line('particulars');?></th>
								<th class="tx-center"><?= $this->lang->line('voucher');?></th>
								<th class="tx-center"><?= $this->lang->line('debit');?></th>
								<th class="tx-center"><?= $this->lang->line('credit');?></th>
								<th class="tx-center"><?= $this->lang->line('balance');?></th>
							</tr>
						</thead>
						<tbody>
						</tbody>
					</table>
				</div>
			</div>
			<script>
				$(document).ready(function(){
				$('#accounts_type').change(function(){
				var accounts_category = $('#accounts_type').val();
				if(accounts_category != '')
					{
						$.ajax(
						{
							url:"<?= base_url('accounts/voucher_posting_accounts_category_info');?>",
							method:"POST",
							data:{accounts_category:accounts_category},
							success:function(data)
							{
								$('#accounts_category').html(data);
							}
						});
					}
					else
						{
						
						}
					});
				});
				
				$(document).ready(function(){
				$('#accounts_category').change(function(){
				var accounts_category = $('#accounts_category').val();
				if(accounts_category != '')
					{
						$.ajax(
						{
							url:"<?= base_url('accounts/voucher_posting_accounts_category_info');?>",
							method:"POST",
							data:{accounts_category:accounts_category},
							success:function(data)
							{
								$('#control_group').html(data);
							}
						});
					}
					else
						{
						
						}
					});
				});
				
				$(document).ready(function(){
				$('#control_group').change(function(){
				var accounts_category = $('#control_group').val();
				if(accounts_category != '')
					{
						$.ajax(
						{
							url:"<?= base_url('accounts/voucher_posting_accounts_category_info');?>",
							method:"POST",
							data:{accounts_category:accounts_category},
							success:function(data)
							{
								$('#general_ledger').html(data);
							}
						});
					}
					else
						{
						
						}
					});
				});
				
				$(document).ready(function(){
				$('#general_ledger').change(function(){
				var accounts_category = $('#general_ledger').val();
				if(accounts_category != '')
					{
						$.ajax(
						{
							url:"<?= base_url('accounts/voucher_posting_accounts_category_info');?>",
							method:"POST",
							data:{accounts_category:accounts_category},
							success:function(data)
							{
								$('#subsidiary_ledger').html(data);
							}
						});
					}
					else
						{
						
						}
					});
				});
				
				$(document).ready(function(){
				$('#search').click(function(){
				var accounts_type = $('#accounts_type').val();
				var accounts_category = $('#accounts_category').val();
				var control_group = $('#control_group').val();
				var general_ledger = $('#general_ledger').val();
				var subsidiary_ledger = $('#subsidiary_ledger').val();
				var starting_date = $('#starting_date').val();
				var closing_date = $('#closing_date').val();
				if(subsidiary_ledger != '')
					{
						$.ajax(
						{
							url:"<?= base_url('accounts/get_subsidiary_ledger');?>",
							beforeSend: function() {
								$('#subsidiary_ledger_info').html('<div style="text-align:center; margin-top:20px;"><img src="<?php echo base_url("assets/images/loading/loader.gif");?>"/><h6 class="tx-center tx-uppercase tx-13 tx-bold"><?= $this->lang->line("loading");?></h6></div>');
							},
							method:"POST",
							data:{accounts_type:accounts_type, accounts_category:accounts_category, control_group:control_group, general_ledger:general_ledger, subsidiary_ledger:subsidiary_ledger, starting_date:starting_date, closing_date:closing_date},
							success:function(data)
							{
								$('#subsidiary_ledger_info').html(data);
							}
						});
					}
					else
						{
						
						}
					});
				});
			</script>
		</div>
		<!--/ Articles End -->				  
   </div>
   <!--/ Main Wrapper End -->
</div>
<!--/ Page Inner End -->

<script type="text/javascript">
	function action_view_model(url)
	{
		// SHOWING AJAX PRELOADER IMAGE
		jQuery('#modal_view_ajax .modal-body').html('<div style="text-align:center; margin-top:20px;"><img src="<?php echo base_url("assets/images/loading/loader.gif");?>" /></div>');
		
		// LOADING THE AJAX MODAL
		jQuery('#modal_view_ajax').modal('show', {backdrop: 'true'});
		
		// SHOW AJAX RESPONSE ON REQUEST SUCCESS
		$.ajax({
			url: url,
			success: function(response)
			{
				jQuery('#modal_view_ajax .modal-body').html(response);
			}
		});
	}
	
	function action_delete_modal(delete_url)
	{
		jQuery('#modal-delete').modal('show', {backdrop: 'static'});
		document.getElementById('delete_link').setAttribute('href' , delete_url);
	}
</script>


<!-- Add / Edit Modal Start-->
<div class="modal fade effect-scale" id="modal_view_ajax" role="dialog">
	<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header tx-uppercase">
				<h5 class="modal-title"><?= $this->lang->line('view');?> <?= $page_name;?></h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <i data-feather="x"></i> </button>
			</div>
			<div class="modal-body form pd-y-20">
				
			</div>
		</div>
	</div>
</div>
<!--/ Add / Edit Modal End-->

<!-- (Delete Modal)-->
<div class="modal fade" id="modal-delete">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header tx-uppercase">  
				<h5 class="modal-title"><?= $this->lang->line('model_delete_warning');?></h5>
			</div>
			<div class="modal-footer" style="margin:0px; border-top:0px; text-align:center;">
				<a href="javascript:void(0)" class="btn btn-outline-danger rounded-pill" id="delete_link" title="<?= $this->lang->line('yeas');?>"><i class="fa fa-check"></i></a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
				<button type="button" class="btn btn-outline-danger rounded-pill" data-dismiss="modal" title="<?= $this->lang->line('no');?>"><i class="fa fa-remove"></i></button>
			</div>
		</div>
	</div>
</div>
<!-- (Delete Modal)-->