<!-- Page Inner Start --> 
<div class="page-inner">
	<!-- Main Wrapper -->
	<div id="main-wrapper"> 
	  <!-- Breadcrumb Start --> 
		<div class="pageheader pd-t-10 pd-b-10">
			<div class="d-flex justify-content-between">
				<div class="clearfix tx-uppercase">
					<div class="pd-t-5 pd-b-5">
					  <h1 class="pd-0 mg-0 tx-20 tx-dark"><?= $page_name;?></h1>
					</div>
					<div class="breadcrumb pd-0 mg-0">
						<a class="breadcrumb-item" href="<?= base_url('./');?>"><i class="fa fa-dashboard"></i> <?= $this->lang->line('dashboard');?></a>
						<a class="breadcrumb-item" href="javascript:void(0);"><?= $this->lang->line('accounts');?></a>
						<span class="breadcrumb-item active"><?= $page_name;?></span>
					</div>
				</div>
				<div class="d-flex align-items-center tx-uppercase"> 
					<button type="button" class="btn btn-outline-success rounded-pill mr-2 d-lg-block pd-t-6-force pd-b-5-force tx-uppercase" onclick="window.location.href='<?= base_url('/login');?>'"> <i class="fa fa-home"></i> <?= $this->lang->line('dashboard');?></button>
				</div>
			</div>
		</div>
		<!--/ Breadcrumb End -->
	  
		<!-- Articles Start -->
		<div class="card mg-b-30"> 
			<!------------- Flash Massage Start ------------->
			<?php if ($this->session->flashdata('success') != null) {  ?>
			<div class="alert alert-success">
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				<center><?php echo $this->session->flashdata('success'); ?></center>
			</div> 
			<?php } ?>
			
			<?php if ($this->session->flashdata('update') != null) {  ?>
			<div class="alert alert-info">
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				<center><?php echo $this->session->flashdata('update'); ?></center>
			</div> 
			<?php } ?>
			
			<?php if ($this->session->flashdata('error') != null) {  ?>
			<div class="alert alert-danger">
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				<center><?php echo $this->session->flashdata('error'); ?></center>
			</div>
			<?php } ?>
			<!------------- Flash Massage End ------------->
			
			<form method="post" action="<?= base_url('accounts/voucher_posting_create');?>">
				<div class="col-md-12">
					<div class="form-row mg-t-10">
						<div class="col-md-4 col-sm-12">
							<label for="label"><?= $this->lang->line('posting_date');?> *</label> 
							<input type="hidden" class="form-control form-control-sm bd-danger" id="accounts_project" name="accounts_project" value="0"required>
							<input type="date" class="form-control form-control-sm bd-danger" id="accounts_voucher_posting_date" name="accounts_voucher_posting_date" value="<?= date('Y-m-d');?>"required>
						</div>
						<div class="col-md-4 col-sm-12">
							<label for="label"><?= $this->lang->line('voucher_type');?> *</label> 
							<select class="form-control form-control-sm bd-danger" id="accounts_voucher_type" name="accounts_voucher_type"required>
								<option value=""> --- <?= $this->lang->line('select');?> ---</option>
								<?php 
								foreach($voucher_type as $voucher_type_row) {?>
								<option value="<?= $voucher_type_row->voucher_type_id;?>"><?= $voucher_type_row->voucher_type_name;?></option>
								<?php }?>
							</select>
						</div>
						<div class="col-md-4 col-sm-12">
							<label for="label"><?= $this->lang->line('reference_number');?></label> 
							<input type="text" class="form-control form-control-sm bd-danger" id="accounts_reference_number" name="accounts_reference_number" value="">
						</div>
					</div> 
				</div><br/> 
				
				<div class="col-md-12">
					<div class="form-row mg-t-10">
						<div class="col-md-3 col-sm-12" id="voucher_number_info">
							<label for="label"><?= $this->lang->line('voucher_number');?> *</label> 
							<input type="text" class="form-control form-control-sm bd-danger" id="accounts_voucher_number" name="accounts_voucher_number" value=""readonly required>
						</div>
						<div class="col-md-6 col-sm-12">
							<label for="label"><?= $this->lang->line('narration');?></label> 
							<input type="text" class="form-control form-control-sm bd-danger" id="accounts_narration" name="accounts_narration" value="">
						</div>
						<div class="col-md-3 col-sm-12">
							<label for="label"> &nbsp;  </label> 
							<button type="submit" class="btn btn-brand btn-block btn-success tx-uppercase" onclick="return confirm('<?= $this->lang->line("model_create_warning");?>')"><?= $this->lang->line('submit');?></button>
						</div>
					</div> 
				</div><br/> 
				<div class="col-md-12" id="collection_info">
					<div class="table-responsive">
						<table class="table table-striped table-bordered table-hover">
							<thead class="tx-uppercase">
								<tr> 
									<th class="tx-center" width="10%"><?= $this->lang->line('accounts_type');?></th>
									<th class="tx-center" width="10%"><?= $this->lang->line('head_of_accounts');?></th>
									<th class="tx-center" width="14%"><?= $this->lang->line('control_group');?></th>
									<th class="tx-center" width="14%"><?= $this->lang->line('general_ledger');?></th>
									<th class="tx-center" width="14%"><?= $this->lang->line('subsidiary_ledger');?></th>
									<!--<th class="tx-center" width="7%"><?= $this->lang->line('debit');?> <?= $this->lang->line('qnty');?></th>
									<th class="tx-center" width="7%"><?= $this->lang->line('credit');?> <?= $this->lang->line('qnty');?></th>-->
									<th class="tx-center" width="12%"><?= $this->lang->line('debit');?> <?= $this->lang->line('amount');?></th>
									<th class="tx-center" width="12%"><?= $this->lang->line('credit');?> <?= $this->lang->line('amount');?></th>
								</tr> 
							</thead>
							<tbody>
								<?php 
								$serial = 0;
								
								$value_1 = 0;
								$value_2 = 0;
								$value_3 = 0;
								$value_4 = 0;
								$value_5 = 0;
								$value_6 = 0;
								$value_7 = 0;
								$value_8 = 0;
								$value_9 = 0;
								$value_10 = 0;
								$value_11 = 0;
								$value_12 = 0;
								$value_13 = 0;
								$value_14 = 0;
								$value_15 = 0;
								$value_16 = 0;
								$value_17 = 0;
								
								for($i=0; $i<15; $i++) {?>
								<tr>
									<td class="tx-center">
										<input type="hidden" class="form-control form-control-sm" name="count" value="<?= ++$serial;?>"required>
										<select class="form-control form-control-sm bd-success" id="accounts_details_accounts_type_<?= ++$value_17;?>" name="accounts_details_accounts_type[]"required>
											<option value="0"> --- <?= $this->lang->line('select');?> ---</option>
											<?php 
											$accounts_type =  $this->db->select("*")
											->from('accounts_type')
											->where('accounts_type_status', 1)
											->order_by('accounts_type_code', 'ASC')
											->get()
											->result();
											foreach($accounts_type as $accounts_type_row) {?>
											<option value="<?= $accounts_type_row->accounts_type_id;?>"><?= $accounts_type_row->accounts_type_code;?>-<?= $accounts_type_row->accounts_type_name;?></option>
											<?php }?>
										</select>
									</td>
									<td class="tx-center">
										<select class="form-control form-control-sm" id="accounts_details_accounts_category_<?= ++$value_1;?>" name="accounts_details_accounts_category[]"required>
											<option value="0"></option>
										</select>
									</td>
									<td class="tx-center">
										<select class="form-control form-control-sm" id="accounts_details_control_group_<?= ++$value_2;?>" name="accounts_details_control_group[]"required>
											<option value="0"></option>
										</select>
									</td> 
									<td class="tx-center">
										<select class="form-control form-control-sm" id="accounts_details_general_ledger_<?= ++$value_3;?>" name="accounts_details_general_ledger[]"required>
											<option value="0"></option>
										</select>
									</td> 
									<td class="tx-center">
										<select class="form-control form-control-sm" id="accounts_details_subsidiary_ledger_<?= ++$value_4;?>" name="accounts_details_subsidiary_ledger[]"required>
											<option value="0"></option>
										</select>
									</td> 
									<!--<td class="tx-center">
										<input type="text" class="form-control form-control-sm tx-center debit_quantity" id="accounts_details_debit_quantity" name="accounts_details_debit_quantity[]" autocomplete="off">
									</td> 
									<td class="tx-center">
										<input type="text" class="form-control form-control-sm tx-center credit_quantity" id="accounts_details_credit_quantity" name="accounts_details_credit_quantity[]" autocomplete="off">
									</td> -->
									<td class="tx-center">
										<input type="text" class="form-control form-control-sm tx-center debit" id="accounts_details_debit" name="accounts_details_debit[]" autocomplete="off">
									</td> 
									<td class="tx-center">
										<input type="text" class="form-control form-control-sm tx-center credit" id="accounts_details_credit" name="accounts_details_credit[]" autocomplete="off">
									</td> 
								</tr>
								<script>
									$(document).ready(function(){
									$('#accounts_details_accounts_type_<?= ++$value_14;?>').change(function(){
									var accounts_category = $('#accounts_details_accounts_type_<?= ++$value_15;?>').val();
									if(accounts_category != '')
										{
											$.ajax(
											{
												url:"<?= base_url('accounts/voucher_posting_accounts_category_info');?>",
												method:"POST",
												data:{accounts_category:accounts_category},
												success:function(data)
												{
													$('#accounts_details_accounts_category_<?= ++$value_16;?>').html(data);
												}
											});
										}
										else
											{
											
											}
										});
									});
									
									$(document).ready(function(){
									$('#accounts_details_accounts_category_<?= ++$value_5;?>').change(function(){
									var accounts_category = $('#accounts_details_accounts_category_<?= ++$value_6;?>').val();
									if(accounts_category != '')
										{
											$.ajax(
											{
												url:"<?= base_url('accounts/voucher_posting_accounts_category_info');?>",
												method:"POST",
												data:{accounts_category:accounts_category},
												success:function(data)
												{
													$('#accounts_details_control_group_<?= ++$value_7;?>').html(data);
												}
											});
										}
										else
											{
											
											}
										});
									});
									
									$(document).ready(function(){
									$('#accounts_details_control_group_<?= ++$value_8;?>').change(function(){
									var accounts_category = $('#accounts_details_control_group_<?= ++$value_9;?>').val();
									if(accounts_category != '')
										{
											$.ajax(
											{
												url:"<?= base_url('accounts/voucher_posting_accounts_category_info');?>",
												method:"POST",
												data:{accounts_category:accounts_category},
												success:function(data)
												{
													$('#accounts_details_general_ledger_<?= ++$value_10;?>').html(data);
												}
											});
										}
										else
											{
											
											}
										});
									});
									
									$(document).ready(function(){
									$('#accounts_details_general_ledger_<?= ++$value_11;?>').change(function(){
									var accounts_category = $('#accounts_details_general_ledger_<?= ++$value_12;?>').val();
									if(accounts_category != '')
										{
											$.ajax(
											{
												url:"<?= base_url('accounts/voucher_posting_accounts_category_info');?>",
												method:"POST",
												data:{accounts_category:accounts_category},
												success:function(data)
												{
													$('#accounts_details_subsidiary_ledger_<?= ++$value_13;?>').html(data);
												}
											});
										}
										else
											{
											
											}
										});
									});
								</script>
								<?php }?>
								<tr>
									<th class="tx-center tx-uppercase" colspan="5"><?= $this->lang->line('total');?></th>
									<!--<th class="tx-center">
										<input type="text" class="form-control form-control-sm bd-danger tx-center total_debit_quantity" id="total_debit_quantity" name="accounts_total_debit_quantity"readonly>
									</th>
									<th class="tx-center"> 
										<input type="text" class="form-control form-control-sm bd-danger tx-center total_credit_quantity" id="total_credit_quantity" name="accounts_total_credit_quantity"readonly>
									</th>-->
									
									<th class="tx-center">
										<input type="text" class="form-control form-control-sm bd-danger tx-center total_debit" id="total_debit" name="accounts_total_debit"readonly>
									</th>
									<th class="tx-center"> 
										<input type="text" class="form-control form-control-sm bd-danger tx-center total_credit" id="total_credit" name="accounts_total_credit"readonly>
									</th>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</form>
			<script>
				$(document).ready(function(){
					$('#accounts_voucher_posting_date, #accounts_voucher_type').change(function(){  
					  var accounts_voucher_posting_date = $('#accounts_voucher_posting_date').val();
					  var accounts_voucher_type = $('#accounts_voucher_type').val();
					  if(accounts_voucher_type != '')
					  {
					   $.ajax({
						url:"<?= base_url('accounts/get_voucher_number_info'); ?>",
						method:"POST",
						data:{accounts_voucher_type:accounts_voucher_type, accounts_voucher_posting_date:accounts_voucher_posting_date},
						success:function(data)
						{
						 $('#voucher_number_info').html(data);
						}
					   });
					  }
					  else
					  {
					   $('#voucher_number_info').html('<label for="label"><?= $this->lang->line('voucher_number');?> *</label> <input type="text" class="form-control form-control-sm bd-danger" id="accounts_voucher_number" name="accounts_voucher_number" value=""readonly required>');
					  }
					});
				}); 
				
				$(document).ready(function(){
					$('.debit_quantity').keyup(function(){ 
					
						var sum = 0;
						$(".debit_quantity").each(function() {
						sum += +$(this).val();
						});
					   
					   $('#total_debit_quantity').val(sum);
					});
				});
				
				$(document).ready(function(){
					$('.credit_quantity').keyup(function(){ 
					
						var sum = 0;
						$(".credit_quantity").each(function() {
						sum += +$(this).val();
						});
					   
					   $('#total_credit_quantity').val(sum);
					});
				});
				
				$(document).ready(function(){
					$('.debit').keyup(function(){ 
					
						var sum = 0;
						$(".debit").each(function() {
						sum += +$(this).val();
						});
					   
					   $('#total_debit').val(sum);
					});
				});
				
				$(document).ready(function(){
					$('.credit').keyup(function(){ 
					
						var sum = 0;
						$(".credit").each(function() {
						sum += +$(this).val();
						});
					   
					   $('#total_credit').val(sum);
					});
				});
			</script>
		</div>
		<!--/ Articles End -->				  
   </div>
   <!--/ Main Wrapper End -->
</div>
<!--/ Page Inner End -->