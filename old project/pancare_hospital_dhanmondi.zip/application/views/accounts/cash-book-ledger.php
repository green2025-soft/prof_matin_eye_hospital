<!-- Page Inner Start --> 
<div class="page-inner" style="margin-bottom:80px;">
	<!-- Main Wrapper -->
	<div id="main-wrapper"> 
	  <!-- Breadcrumb Start --> 
		<div class="pageheader pd-t-10 pd-b-10">
			<div class="d-flex justify-content-between">
				<div class="clearfix tx-uppercase">
					<div class="pd-t-5 pd-b-5">
					  <h1 class="pd-0 mg-0 tx-20 tx-dark"><?= $page_name;?></h1>
					</div>
					<div class="breadcrumb pd-0 mg-0">
						<a class="breadcrumb-item" href="<?= base_url('./login');?>"><i class="fa fa-dashboard"></i> <?= $this->lang->line('dashboard');?></a>
						<a class="breadcrumb-item" href="javascript:void(0);"><?= $this->lang->line('accounts');?></a>
						<span class="breadcrumb-item active"><?= $page_name;?></span>
					</div>
				</div>
				<div class="d-flex align-items-center tx-uppercase">
					<button type="button" class="btn btn-outline-success rounded-pill mr-2 d-lg-block pd-t-6-force pd-b-5-force tx-uppercase" onclick="history.back()"> <i class="fa fa-arrow-left"></i> <?= $this->lang->line('go_back'); ?></button>
				</div>
			</div>
		</div>
		<!--/ Breadcrumb End -->
	  
		<!-- Articles Start -->
		<div class="card mg-b-30"> 
			
			<div class="col-md-12">
			<form method="post" target="print_popup" action="<?= base_url('accounts/cash_book_ledger_print');?>" onsubmit="window.open('about:blank','print_popup','width=800,height=700');">
					
				<div class="form-row mg-t-10">
					<div class="col-md-3 col-sm-12">
						<label for="label"><?= $this->lang->line('starting_date');?></label> 
						<input type="date" class="form-control form-control-sm bd-danger tx-center" id="from_date" name="from_date" value="<?= date('Y-m-d');?>"required>
					</div>
					<div class="col-md-3 col-sm-12">
						<label for="label"><?= $this->lang->line('closing_date');?></label> 
						<input type="date" class="form-control form-control-sm bd-danger tx-center" id="to_date" name="to_date" value="<?= date('Y-m-d');?>"required>
					</div>
					<div class="col-md-3 col-sm-12">
						<label for="label">&nbsp;</label>
						<button type="button" id="search" class="btn btn-brand btn-success btn-block tx-uppercase"><i class="fa fa-search"></i> <?= $this->lang->line('search');?></button>
					</div>
					
					<div class="col-md-3 col-sm-12">
						<label for="label"> &nbsp; </label> 
						<button type="submit" class="btn btn-brand  btn-block tx-uppercase"><i class="fa fa-print"></i> <?= $this->lang->line('print');?></button>
					</div>
				</div>
			</form>
			</div><br/> 
			<div class="col-md-12">
				<div class="table-responsive">
					<table class="table table-striped table-bordered table-hover">
						<thead class="tx-uppercase">
							<tr>  
								<th class="tx-center" rowspan="2"><?= $this->lang->line('sl');?></th> 
								<th class="tx-center" rowspan="2"><?= $this->lang->line('control_group');?></th>
								<th class="tx-center" colspan="2"><?= $this->lang->line('ledger');?></th>
								<th class="tx-center" rowspan="2"><?= $this->lang->line('voucher');?></th>
								<th class="tx-center" colspan="4"><?= $this->lang->line('amount');?></th>
							</tr>
							
							<tr>  
								<th class="tx-center"><?= $this->lang->line('general');?></th>
								<th class="tx-center"><?= $this->lang->line('subsidiary');?></th>
								
								<th class="tx-center"><?= $this->lang->line('debit');?></th>
								<th class="tx-center"><?= $this->lang->line('credit');?></th> 
								<th class="tx-center"><?= $this->lang->line('balance');?></th>
							</tr>
						</thead>
						<tbody id="cash_book_ledger_info">
						</tbody>
					</table>
				</div>
			</div>
			<script>
				$(document).ready(function(){
					$('#search').click(function(){  
					  var from_date = $('#from_date').val(); 
					  var to_date = $('#to_date').val(); 
					  if(to_date != '') 
					  {
					   $.ajax({
						url:"<?= base_url('accounts/get_cash_book_ledger');?>",
						beforeSend: function() {
							$('#cash_book_ledger_info').html('<div style="text-align:center; margin-top:20px;"><img src="<?php echo base_url("assets/images/loading/loader.gif");?>"/><h6 class="tx-center tx-uppercase tx-13 tx-bold"><?= $this->lang->line("loading");?></h6></div>');
						},
						method:"POST",
						data:{from_date:from_date, to_date:to_date},
						success:function(data)
						{
						 $('#cash_book_ledger_info').html(data);
						}
					   });
					  }
					  else
					  {
					   $('#cash_book_ledger_info').html('<div><h6 class="tx-center tx-uppercase"><?= $this->lang->line("data_searching_error");?></h6></div>');
					  }
					});
				}); 
			</script>
		</div>
		<!--/ Articles End -->				  
   </div>
   <!--/ Main Wrapper End -->
</div>
<!--/ Page Inner End -->