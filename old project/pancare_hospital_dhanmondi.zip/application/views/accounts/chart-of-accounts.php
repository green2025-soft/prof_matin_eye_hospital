<aside>
  <section class="content">
    <div class="row">
      <section class="col-xs-12 connectedSortable"> 
        <div  class="box box-info no_print">
          <div class="box-header">
            <h3 class="box-title"><?=!empty($page_title)?$page_title:''?></h3>
          </div>
           <div class="card mg-b-30">
			<div class="table-responsive">
				<table class="table table-striped table-bordered table-hover">
					<thead class="tx-uppercase">
						<tr>
							<th class="tx-center" width="10%">Accounts Code</th>
							<th class="tx-center" width="50%">Head of Accounts</th>
							<th class="tx-center" width="10%">Links</th>
							<th class="tx-center" width="10%">Status</th>
							<th class="tx-center d-print-none" width="20%" colspan="2">Option</th>
						</tr>
					</thead>
					<tbody id="chart_of_accounts_info">
						<?= $this->accounts_model->chart_of_accounts_list();?>
					</tbody>
					<script>
						$(document).ready(function() {
							loadData('#chart_of_accounts_info');
						});

						var loadData = function() {
							$.ajax({ 
								type: "GET",
								url: "<?= base_url('accounts/chart_of_accounts_list');?>",             
								dataType: "html",                
								success: function(response){                    
									$("#chart_of_accounts_info").html(response);
									setTimeout(loadData, 3000); 
								}
							});
						};
					</script>
				</table>
			</div> 
		</div>
    </div>
  </section>
</div>
</section>
<!-- /.box-body -->
  <!-- <div class="box-footer">
    Footer
  </div> -->
  <!-- /.box-footer-->
</aside>
<div style="margin-top:50px"></div>

<script type="text/javascript">
	function action_add_model(url)
	{
		// SHOWING AJAX PRELOADER IMAGE
		jQuery('#modal_add_ajax .modal-body').html('<div style="text-align:center; margin-top:20px;"><img src="<?php echo base_url("assets/images/loading/loader.gif");?>" /></div>');
		
		// LOADING THE AJAX MODAL
		jQuery('#modal_add_ajax').modal('show', {backdrop: 'true'});
		
		// SHOW AJAX RESPONSE ON REQUEST SUCCESS
		$.ajax({
			url: url,
			success: function(response)
			{
				jQuery('#modal_add_ajax .modal-body').html(response);
			}
		});
	}
	
	function action_edit_model(url)
	{
		// SHOWING AJAX PRELOADER IMAGE
		jQuery('#modal_edit_ajax .modal-body').html('<div style="text-align:center; margin-top:20px;"><img src="<?php echo base_url("assets/images/loading/loader.gif");?>" /></div>');
		
		// LOADING THE AJAX MODAL
		jQuery('#modal_edit_ajax').modal('show', {backdrop: 'true'});
		
		// SHOW AJAX RESPONSE ON REQUEST SUCCESS
		$.ajax({
			url: url,
			success: function(response)
			{
				jQuery('#modal_edit_ajax .modal-body').html(response);
			}
		});
	}
	
	function action_delete_modal(delete_url)
	{
		jQuery('#modal-delete').modal('show', {backdrop: 'static'});
		document.getElementById('delete_link').setAttribute('href' , delete_url);
	}
</script>


<!-- Add / Edit Modal Start-->
<div class="modal fade effect-scale" id="modal_add_ajax" role="dialog">
	<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header tx-uppercase">
				<h5 class="modal-title"><?= $this->lang->line('create_new');?> <?= $page_name;?></h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <i data-feather="x"></i> </button>
			</div>
			<div class="modal-body form pd-y-20">
				
			</div>
		</div>
	</div>
</div>
<!--/ Add / Edit Modal End-->

<!-- Add / Edit Modal Start-->
<div class="modal fade effect-scale" id="modal_edit_ajax" role="dialog">
	<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header tx-uppercase">
				<h5 class="modal-title"><?= $this->lang->line('update');?> <?= $page_name;?></h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <i data-feather="x"></i> </button>
			</div>
			<div class="modal-body form pd-y-20">
				
			</div>
		</div>
	</div>
</div>
<!--/ Add / Edit Modal End-->

<!-- (Delete Modal)-->
<div class="modal fade" id="modal-delete">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header tx-uppercase">  
				<h5 class="modal-title"><?= $this->lang->line('model_delete_warning');?></h5>
			</div>
			<div class="modal-footer" style="margin:0px; border-top:0px; text-align:center;">
				<a href="javascript:void(0)" class="btn btn-outline-danger rounded-pill" id="delete_link" title="<?= $this->lang->line('yeas');?>"><i class="fa fa-check"></i></a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
				<button type="button" class="btn btn-outline-danger rounded-pill" data-dismiss="modal" title="<?= $this->lang->line('no');?>"><i class="fa fa-remove"></i></button>
			</div>
		</div>
	</div>
</div>
<!-- (Delete Modal)-->