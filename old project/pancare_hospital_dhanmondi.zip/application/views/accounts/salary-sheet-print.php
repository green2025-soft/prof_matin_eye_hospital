<style>
@page {
	   size: 13in 8in;
	   margin: 5px;
	}
</style>
<?php 
	$campus = $this->db->select("*") ->from('campus') ->where('campus_status', 1) ->order_by('campus_id', 'ASC') ->get() ->result();
	foreach ($campus as $campus_row) 
	{
		$campus_name			= $campus_row->campus_name; 
		$campus_address			= $campus_row->campus_address;
		$campus_phone			= $campus_row->campus_phone; 
		$campus_fax				= $campus_row->campus_fax;
		$campus_email			= $campus_row->campus_email;
		$campus_website			= $campus_row->campus_website; 
		$currency				= $campus_row->campus_currency; 
		$campus_logo			= $campus_row->campus_logo;
	}
?> 
<body onload="window.print();">
	<div class="col-md-12 mg-t-5">
		<div class="tx-center">
			<img src="<?= base_url("$campus_logo");?>" alt="" width="90"><br/>
			
			<h5 class="tx-uppercase"><?= $campus_name;?></h5>
			<p class="tx-uppercase"><?= $campus_address;?></p>
			
			<h6 class="tx-uppercase tx-underlinetx-bold"><?= $page_name;?></h6>
			
			<p class="tx-uppercase "><?= date('F-Y', strtotime($salary_month));?>, <?= $this->lang->line('print_date');?>: <?= date('d/m/Y h:i A');?></p>
		</div><br/>
		
		<table class="table table-striped table-bordered table-hover">
			<thead class="tx-uppercase">
				<tr> 
					<th class="tx-center" rowspan="2"><?= $this->lang->line('sl');?></th>
					<th class="tx-center" colspan="2"><?= $this->lang->line('employee_information');?></th>
					<th class="tx-center" colspan="7"><?= $this->lang->line('salary');?></th>
					<th class="tx-center" colspan="6"><?= $this->lang->line('deduction');?></th>
					
					<th class="tx-center" rowspan="2"><?= $this->lang->line('payable');?><br/><?= $this->lang->line('amount');?></th>
					<th class="tx-center" rowspan="2"><?= $this->lang->line('paid');?><br/><?= $this->lang->line('amount');?></th>
					<th class="tx-center" rowspan="2"><?= $this->lang->line('due');?><br/><?= $this->lang->line('amount');?></th>
				</tr> 
				<tr> 
					<th class="tx-center"><?= $this->lang->line('employee_name');?></th>
					<th class="tx-center"><?= $this->lang->line('designation');?></th>
					
					<th class="tx-center"><?= $this->lang->line('basic_salary');?></th>
					<th class="tx-center"><?= $this->lang->line('house_rent');?></th>
					<th class="tx-center"><?= $this->lang->line('medical');?></th>
					<th class="tx-center"><?= $this->lang->line('conveyance');?></th>
					<th class="tx-center"><?= $this->lang->line('others');?></th>
					<th class="tx-center"><?= $this->lang->line('gross');?></th>
					<th class="tx-center"><?= $this->lang->line('bonus');?></th>
					
					<th class="tx-center"><?= $this->lang->line('stamp');?></th>
					<th class="tx-center"><?= $this->lang->line('tax');?></th>
					<th class="tx-center"><?= $this->lang->line('vat');?></th>
					<th class="tx-center"><?= $this->lang->line('advance');?></th>
					<th class="tx-center"><?= $this->lang->line('loan');?></th>
					<th class="tx-center"><?= $this->lang->line('others');?></th>
				</tr> 
			</thead>
			<tbody>
				<?= $this->accounts_model->salary_sheet($salary_month);?>
			</tbody>
		</table>
		
		<br/><br/><br/><br/>
		
		<table class="" width="100%" align="center">  
			<tr class="tx-uppercase">
				<th width="30%" class="text-center bd-top"><?= $this->lang->line('prepared_by');?></th>
				<th width="5%"></th>
				<th width="30%" class="text-center bd-top"><?= $this->lang->line('checked_by');?></th>
				<th width="5%"></th>
				<th width="30%" class="text-center bd-top"><?= $this->lang->line('authorised');?></th>
			</tr>
		</table>
	</div>
</body>