<style>
@page {
	   size: 7in 10.5in;
	   margin: 5px;
	}
</style>
<?php 
	$campus = $this->db->select("*") ->from('campus') ->where('campus_status', 1) ->order_by('campus_id', 'ASC') ->get() ->result();
	foreach ($campus as $campus_row) 
	{
		$campus_name			= $campus_row->campus_name; 
		$campus_address			= $campus_row->campus_address;
		$campus_phone			= $campus_row->campus_phone; 
		$campus_fax				= $campus_row->campus_fax;
		$campus_email			= $campus_row->campus_email;
		$campus_website			= $campus_row->campus_website; 
		$currency				= $campus_row->campus_currency; 
		$campus_logo			= $campus_row->campus_logo;
	}
	
	if($user == 000) {
		$user_name = $this->lang->line('all').' '.$this->lang->line('user');
	} else if($user == 0) {
		$user_name = $this->lang->line('n_a');
	} else {
	$employee = $this->db->select("*") ->from('user') ->where('user_id', $user) ->order_by('user_id', 'ASC') ->get() ->result();
	
	foreach ($employee as $employee_row) 
	{
		$user_name	= $employee_row->user_name;
	} }	
?> 
<body onload="window.print();">
	<div class="col-md-12 mg-t-5">
		<div class="tx-center">
			<img src="<?= base_url("$campus_logo");?>" alt="" width="90"><br/>
			
			<h2 class="tx-uppercase"><?= $campus_name;?></h2>
			<p class="tx-uppercase"><?= $campus_address;?></p>
			
			<h6 class="tx-uppercase tx-underlinetx-bold"><?= $page_name;?></h6>
			
			<p class="tx-uppercase "><?= $this->lang->line('from_the_date_of');?> <?= date('d/m/Y', strtotime($from_date));?> <?= $this->lang->line('to');?> <?= date('d/m/Y', strtotime($to_date));?><br/><?= $this->lang->line('print_date');?> <?= date('d/m/Y h:i A');?></p>
			<p class="tx-uppercase "><?= $this->lang->line('user');?>: <?= $user_name;?></p>
		</div><br/>
		
		<table class="table table-striped table-bordered table-hover">
			<thead class="tx-uppercase">
				<tr>
					<th class="tx-center"><?= $this->lang->line('sl_no');?></th> 
					<th class="tx-center" colspan="2"><?= $this->lang->line('description');?></th>  
					<th class="tx-center"><?= $this->lang->line('collection');?><br/><?= $this->lang->line('amount');?></th> 
					<th class="tx-center"><?= $this->lang->line('rc');?><br/><?= $this->lang->line('amount');?></th>  
					<th class="tx-center"><?= $this->lang->line('doctor');?><br/><?= $this->lang->line('charge');?></th>
					<th class="tx-center"><?= $this->lang->line('medicine');?> / <?= $this->lang->line('others');?><br/><?= $this->lang->line('charge');?></th>
					<th class="tx-center"><?= $this->lang->line('balance');?></th>
				</tr>
			</thead>
			<tbody id="investigation_collection">
			<?= $this->accounts_model->collection_summary_report($from_date, $to_date, $user);?> 
			</tbody>
		</table>
		
		<br/><br/><br/><br/><br/>
		
		<table class="" width="100%" align="center">  
			<tr class="tx-uppercase">
				<th width="30%" class="text-center">&nbsp;</th>
				<th width="5%"></th>
				<th width="30%" class="text-center">&nbsp;</th>
				<th width="5%"></th>
				<th width="30%" class="text-center bd-top">
					<?= $this->lang->line('prepared_by');?> <br/> 
					<?php $user_name = $this->session->userdata('user_name');?> <?= $user_name;?>
				</th>
			</tr>
		</table>
	</div>
</body>