<?php foreach($accounts_type_edit as $row){?>
<div id="from_info">
	<form method="post" id="insert"> 
	<div class="form-row">
		<div class="col-md-6">
			<label for="label"><?= $this->lang->line('accounts_code');?> *</label>
			<input type="hidden" class="form-control form-control-sm bd-danger" id="accounts_type_id" name="accounts_type_id" value="<?= $row->accounts_type_id;?>"required>
			<input type="text" class="form-control form-control-sm bd-danger" id="accounts_type_code" name="accounts_type_code" value="<?= $row->accounts_type_code;?>"required>
		</div>
		<div class="col-md-6">
			<label for="label"><?= $this->lang->line('accounts_name');?> *</label>
			<input type="text" class="form-control form-control-sm bd-danger" id="accounts_type_name" name="accounts_type_name" value="<?= $row->accounts_type_name;?>"required>
		</div>
	</div><br/>

	<div class="form-row">
	</div><br/> 
	<div class="form-row">
		<div class="col-md-6">
			<label for="label"><?= $this->lang->line('status');?> *</label>
			<select class="form-control form-control-sm bd-danger" id="accounts_type_status" name="accounts_type_status"required>
				<?php 
				$status =  $this->db->select("*") ->from('status') ->order_by('status_id', 'DESC') ->get() ->result();
				foreach($status as $status_row) {?>
				<option value="<?= $status_row->status_id;?>"<?php if($status_row->status_id == "$row->accounts_type_status"){echo 'selected';}?>><?= $status_row->status_name;?></option>
				<?php }?>
			</select>
		</div>
		<!-- <div class="col-md-6">
			<label for="label"><?= $this->lang->line('inventory');?> *</label>
			<select class="form-control form-control-sm bd-danger" id="accounts_type_inventory" name="accounts_type_inventory"required>
				<?php 
				$inventory_status =  $this->db->select("*") ->from('status') ->order_by('status_id', 'DESC') ->get() ->result();
				foreach($inventory_status as $inventory_status_row) {?>
				<option value="<?= $inventory_status_row->status_id;?>"<?php if($inventory_status_row->status_id == "$row->accounts_type_inventory"){echo 'selected';}?>><?= $inventory_status_row->status_name;?></option>
				<?php }?>
			</select>
		</div> -->
	</div>

	<div class="modal-footer">
	  <button type="submit" class="btn btn-outline-info tx-uppercase"><?= $this->lang->line('update');?></button>
	  <button type="button" class="btn btn-outline-danger tx-uppercase" data-dismiss="modal"><?= $this->lang->line('closed');?></button>
	</div>
	</form>
</div>
<?php }?>

<script>
	$(document).ready(function(){
		$('#insert').submit(function(e){
		e.preventDefault(); 
			 $.ajax({
				url:"<?= base_url('accounts/accounts_type_update');?>",
				type:"post",
				data:new FormData(this),
				processData:false,
				contentType:false,
				cache:false,
				async:false,
				success: function(data)
				{
					$('#from_info').html(data);
				}
			 });
		}); 
	});
</script>