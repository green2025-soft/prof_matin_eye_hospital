<style>
@page {
	   size: 7in 10.5in;
	   margin: 5px;
	}
</style>
	<?php 
	$campus = $this->db->select("*") ->from('campus') ->where('campus_status', 1) ->order_by('campus_id', 'ASC') ->get() ->result();
	foreach ($campus as $campus_row) 
	{
		$campus_name			= $campus_row->campus_name; 
		$campus_address			= $campus_row->campus_address;
		$campus_phone			= $campus_row->campus_phone; 
		$campus_fax				= $campus_row->campus_fax;
		$campus_email			= $campus_row->campus_email;
		$campus_website			= $campus_row->campus_website; 
		$currency				= $campus_row->campus_currency; 
		$campus_logo			= $campus_row->campus_logo;
	}
	$starting_date = date('2015-07-01');
		
	// Current Month Date Calculation ..
	$current_month_start_date = date('Y-m-01', strtotime($closing_month));
	$current_month_end_date =  date('Y-m-t', strtotime($closing_month)); 
	
	$current_last_month_start_date = date('Y-m-01', strtotime($closing_month. "last month"));
	$current_last_month_end_date =  date('Y-m-t', strtotime($closing_month. "last month")); 
	
	$current_previous_month_start_date = date('Y-m-01', strtotime($closing_month. "last month". "last month"));
	$current_previous_month_end_date =  date('Y-m-t', strtotime($closing_month. "last month". "last month"));
	
	//$quarterly_start_date = date('Y-m-01', strtotime($closing_month. "last month". "last month"));
	//$quarterly_end_date =  date('Y-m-t', strtotime($closing_month)); 
	
	if(date('m-y', strtotime($closing_month)) <= 3) {
		$quarterly_start_date = date('Y-10-01', strtotime($closing_month. "last year"));
		$quarterly_end_date =  date('Y-12-31', strtotime($closing_month. "last year"));
	} else if(date('m-y', strtotime($closing_month)) <= 6) {
		$quarterly_start_date = date('Y-01-01', strtotime($closing_month));
		$quarterly_end_date =  date('Y-03-31', strtotime($closing_month));
	} else  if(date('m-y', strtotime($closing_month)) <= 9) {
		$quarterly_start_date = date('Y-04-01', strtotime($closing_month));
		$quarterly_end_date =  date('Y-06-30', strtotime($closing_month));
	} else  if(date('m-y', strtotime($closing_month)) <= 12) {
		$quarterly_start_date = date('Y-07-01', strtotime($closing_month));
		$quarterly_end_date =  date('Y-09-30', strtotime($closing_month));
	}
	
	// last Month Date Calculation ..
	if (date('m', strtotime($closing_month)) < '07') {
	$last_month_start_date	= date('Y-07-01', strtotime($closing_month. "last year"));
	} else {
	$last_month_start_date = date('Y-07-01', strtotime($closing_month));
	} 
	$last_month_end_date	= date('Y-m-t', strtotime($closing_month. "last month"));
	
	// previous Month Date Calculation ..
	if (date('m', strtotime($closing_month)) < '07') {
	$previous_month_start_date	= date('Y-07-01', strtotime($closing_month. "last year"));
	} else {
	$previous_month_start_date = date('Y-07-01', strtotime($closing_month));
	} 
	$previous_month_end_date	= date('Y-m-t', strtotime($closing_month. "last month". "last month"));
	
	// Current Year Date Calculation ..
	if (date('m', strtotime($closing_month)) < '07') {
	$current_year_start			= date('Y', strtotime($closing_month. "last year"));
	$current_year_end			= date('y', strtotime($closing_month));
	$current_year_start_date	= date('Y-07-01', strtotime($closing_month. "last year"));
	$current_year_end_date		= date('Y-m-t', strtotime($closing_month));
	} else {
	$current_year_start			= date('Y', strtotime($closing_month));
	$current_year_end			= date('y', strtotime($closing_month. "+1 year"));
	$current_year_start_date	= date('Y-07-01', strtotime($closing_month));
	$current_year_end_date		= date('Y-m-t', strtotime($closing_month. "+1 year"));
	} 
	
	// last Year Date Calculation ..
	if (date('m', strtotime($closing_month)) < '07') {
	$last_year_start_date	= date('Y-07-01', strtotime($closing_month. "last year". "last year"));
	$last_year_start		= date('Y', strtotime($closing_month. "last year". "last year"));
	$last_year_end			= date('y', strtotime($closing_month. "last year"));
	$last_year_end_date		= date('Y-06-31', strtotime($closing_month. "last year"));
	} else {
	$last_year_start_date	= date('Y-07-01', strtotime($closing_month. "last year"));
	$last_year_start		= date('Y', strtotime($closing_month. "last year"));
	$last_year_end			= date('y', strtotime($closing_month));
	$last_year_end_date		= date('Y-06-31', strtotime($closing_month));
	} 
	
	// previous Year Date Calculation ..
	if (date('m', strtotime($closing_month)) < '07') {
	$previous_year_start_date	= date('Y-07-01', strtotime($closing_month. "last year". "last year". "last year"));
	$previous_year_start		= date('Y', strtotime($closing_month. "last year". "last year". "last year"));
	$previous_year_end			= date('y', strtotime($closing_month. "last year". "last year"));
	$previous_year_end_date		= date('Y-06-31', strtotime($closing_month. "last year". "last year"));
	} else {
	$previous_year_start_date	= date('Y-07-01', strtotime($closing_month. "last year". "last year"));
	$previous_year_start		= date('Y', strtotime($closing_month. "last year". "last year"));
	$previous_year_end			= date('y', strtotime($closing_month. "last year"));
	$previous_year_end_date		= date('Y-06-31', strtotime($closing_month. "last year"));
	}
	?>
<body onload="window.print();">
	<div class="col-md-12 mg-t-5">
		<div class="tx-center">
			<img src="<?= base_url("$campus_logo");?>" alt="" width="80"><br/>
			
			<h2 class="tx-uppercase tx-bold"><?= $campus_name;?></h2>
			<p class="tx-uppercase tx-bold"><?= $campus_address;?></p>
			
			<h6 class="tx-uppercase tx-underline tx-bold"><?= $page_name;?></h6>
			
			<p class="tx-uppercase"><?= $this->lang->line('for_the_month_ended');?> <?= date('t F, Y', strtotime($closing_month));?></p>
		</div><br/>
		
		<table class="table-hover" width="100%" align="center">
			<thead class="tx-uppercase">
				<tr class="table-bordered">  
					<th class="tx-center" rowspan="2"><?= $this->lang->line('particulars');?></th> 
					<th class="tx-center" colspan="12"><?= $this->lang->line('amounts');?></th>
				</tr>
				<tr class="table-bordered">  
					<th class="tx-center" colspan="2">
						<?= $this->lang->line('current_month');?> <br/> <?= date('M-y', strtotime($closing_month));?>
					</th>
					<th class="tx-center" colspan="2">
						<?= $this->lang->line('last_month');?> <br/> <?= date('M-y', strtotime($closing_month. "last month"));?>
					</th>
					<th class="tx-center" colspan="2">
						<?= $this->lang->line('previous_month');?> <br/> <?= date('M-y', strtotime($closing_month. "last month". "last month"));?>
					</th>
					<th class="tx-center" colspan="2" width="15%"> 
						<!--<?= $this->lang->line('quarterly');?> <br/> <?= date('M-y', strtotime($closing_month. "last month". "last month"));?> <?= $this->lang->line('to');?> <?= date('M-y', strtotime($closing_month));?>-->
						<?php if(date('m-y', strtotime($closing_month)) <= 3) {?>
						<?= $this->lang->line('quarterly');?> <br/> Oct-<?= date('y', strtotime($closing_month. "last year"));?> <?= $this->lang->line('to');?> Dec-<?= date('y', strtotime($closing_month. "last year"));?>
						<?php } else if(date('m-y', strtotime($closing_month)) <= 6) {?>
						<?= $this->lang->line('quarterly');?> <br/> Jan-<?= date('y', strtotime($closing_month));?> <?= $this->lang->line('to');?> Mar-<?= date('y', strtotime($closing_month));?>
						<?php } else  if(date('m-y', strtotime($closing_month)) <= 9) {?>
						<?= $this->lang->line('quarterly');?> <br/> Apr-<?= date('y', strtotime($closing_month));?> <?= $this->lang->line('to');?> Jun-<?= date('y', strtotime($closing_month));?>
						<?php } else  if(date('m-y', strtotime($closing_month)) <= 12) {?>
						<?= $this->lang->line('quarterly');?> <br/> Jul-<?= date('y', strtotime($closing_month));?> <?= $this->lang->line('to');?> Sep-<?= date('y', strtotime($closing_month));?>
						<?php }?>
					</th>
					<th class="tx-center" colspan="2">
						<?= $this->lang->line('for_the_period');?> <br/> FY <?= $current_year_start;?>-<?= $current_year_end;?>
					</th>
					<th class="tx-center" colspan="2">
						<?= $this->lang->line('for_the_period');?> <br/> FY <?= $last_year_start;?>-<?= $last_year_end;?>
					</th> 
				</tr>
			</thead>
			<tbody>
			<?php if($type == 'Income') {
				// Income ....
				$serial = $note;
				$total_current_month_accounts_category_income = 0;
				$total_last_month_accounts_category_income = 0;
				$total_previous_month_accounts_category_income = 0;
				$total_current_year_accounts_category_income = 0;
				$total_last_year_accounts_category_income = 0;
				$total_previous_year_accounts_category_income = 0;
				
				$accounts_category_income = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_id', $coa) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
				foreach ($accounts_category_income as $accounts_category_income_row) 
				{?>
				<tr>
					<th class="tx-left" width="3%"><?= number_format(+$serial,2 . '');?></th>
					<th class="tx-left tx-uppercase" colspan="13"><?= $accounts_category_income_row->chart_of_accounts_code;?> - <?= $accounts_category_income_row->chart_of_accounts_name;?></th>
				</tr>
				<?php 
				$total_current_month_subsidiary_ledger_income = 0;
				$total_current_last_month_subsidiary_ledger_income = 0;
				$total_current_previous_month_subsidiary_ledger_income = 0;
				$total_quarterly_subsidiary_ledger_income = 0;
				$total_current_year_subsidiary_ledger_income = 0;
				$total_last_year_subsidiary_ledger_income = 0;
				$total_previous_year_subsidiary_ledger_income = 0;
				
				$subsidiary_ledger_income = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_id', $s_coa) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
				foreach ($subsidiary_ledger_income as $subsidiary_ledger_income_row) 
				{?> 
				<tr>
					<td class="tx-left"><?= $subsidiary_ledger_income_row->chart_of_accounts_code;?> - <?= $subsidiary_ledger_income_row->chart_of_accounts_name;?></th>
					<?php 
					$current_month_subsidiary_ledger_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_month_subsidiary_ledger_income_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
					->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_income_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($current_month_subsidiary_ledger_income as $current_month_subsidiary_ledger_income_row)
					{
					$current_month_subsidiary_ledger_income_balance = $current_month_subsidiary_ledger_income_row->current_month_subsidiary_ledger_income_balance;
					$total_current_month_subsidiary_ledger_income  += $current_month_subsidiary_ledger_income_balance;
					?>			
					<td class="tx-center" width="1%"></td>
					<td class="tx-right"><?php if ($current_month_subsidiary_ledger_income_balance >0) { echo' '.number_format($current_month_subsidiary_ledger_income_balance, 2 . '').' ';} else if($current_month_subsidiary_ledger_income_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_month_subsidiary_ledger_income_balance), 2 . '').') ';} ?></td>
					<?php }
					
					$current_last_month_subsidiary_ledger_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_last_month_subsidiary_ledger_income_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_last_month_start_date.'" and "'.$current_last_month_end_date.'"')
					->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_income_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($current_last_month_subsidiary_ledger_income as $current_last_month_subsidiary_ledger_income_row)
					{
					$current_last_month_subsidiary_ledger_income_balance = $current_last_month_subsidiary_ledger_income_row->current_last_month_subsidiary_ledger_income_balance;
					$total_current_last_month_subsidiary_ledger_income  += $current_last_month_subsidiary_ledger_income_balance;
					?>			
					<td class="tx-center" width="1%"></td>
					<td class="tx-right"><?php if ($current_last_month_subsidiary_ledger_income_balance >0) { echo' '.number_format($current_last_month_subsidiary_ledger_income_balance, 2 . '').' ';} else if($current_last_month_subsidiary_ledger_income_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_last_month_subsidiary_ledger_income_balance), 2 . '').') ';} ?></td>
					<?php }
					
					$current_previous_month_subsidiary_ledger_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_previous_month_subsidiary_ledger_income_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_previous_month_start_date.'" and "'.$current_previous_month_end_date.'"')
					->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_income_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($current_previous_month_subsidiary_ledger_income as $current_previous_month_subsidiary_ledger_income_row)
					{
					$current_previous_month_subsidiary_ledger_income_balance = $current_previous_month_subsidiary_ledger_income_row->current_previous_month_subsidiary_ledger_income_balance;
					$total_current_previous_month_subsidiary_ledger_income  += $current_previous_month_subsidiary_ledger_income_balance;
					?>			
					<td class="tx-center" width="1%"></td>
					<td class="tx-right"><?php if ($current_previous_month_subsidiary_ledger_income_balance >0) { echo' '.number_format($current_previous_month_subsidiary_ledger_income_balance, 2 . '').' ';} else if($current_previous_month_subsidiary_ledger_income_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_previous_subsidiary_ledger_income_balance), 2 . '').') ';} ?></td>
					<?php }
					
					$quarterly_subsidiary_ledger_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS quarterly_subsidiary_ledger_income_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$quarterly_start_date.'" and "'.$quarterly_end_date.'"')
					->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_income_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($quarterly_subsidiary_ledger_income as $quarterly_subsidiary_ledger_income_row)
					{
					$quarterly_subsidiary_ledger_income_balance = $quarterly_subsidiary_ledger_income_row->quarterly_subsidiary_ledger_income_balance;
					$total_quarterly_subsidiary_ledger_income  += $quarterly_subsidiary_ledger_income_balance;
					?>			
					<td class="tx-center" width="1%"></td>
					<td class="tx-right"><?php if ($quarterly_subsidiary_ledger_income_balance >0) { echo' '.number_format($quarterly_subsidiary_ledger_income_balance, 2 . '').' ';} else if($quarterly_subsidiary_ledger_income_balance ==0) {echo '-';} else { echo' ('.number_format(abs($quarterly_subsidiary_ledger_income_balance), 2 . '').') ';} ?></td>
					<?php }
					
					$current_year_subsidiary_ledger_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_year_subsidiary_ledger_income_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_year_start_date.'" and "'.$current_year_end_date.'"')
					->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_income_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($current_year_subsidiary_ledger_income as $current_year_subsidiary_ledger_income_row)
					{
					$current_year_subsidiary_ledger_income_balance = $current_year_subsidiary_ledger_income_row->current_year_subsidiary_ledger_income_balance;
					$total_current_year_subsidiary_ledger_income  += $current_year_subsidiary_ledger_income_balance;
					?>			
					<td class="tx-center" width="1%"></td>
					<td class="tx-right"><?php if ($current_year_subsidiary_ledger_income_balance >0) { echo' '.number_format($current_year_subsidiary_ledger_income_balance, 2 . '').' ';} else if($current_year_subsidiary_ledger_income_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_year_subsidiary_ledger_income_balance), 2 . '').') ';} ?></td>
					<?php }
					
					$last_year_subsidiary_ledger_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS last_year_subsidiary_ledger_income_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
					->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_income_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($last_year_subsidiary_ledger_income as $last_year_subsidiary_ledger_income_row)
					{
					$last_year_subsidiary_ledger_income_balance = $last_year_subsidiary_ledger_income_row->last_year_subsidiary_ledger_income_balance;
					$total_last_year_subsidiary_ledger_income  += $last_year_subsidiary_ledger_income_balance;
					?>			
					<td class="tx-center " width="1%"></td>
					<td class="tx-right "><?php if ($last_year_subsidiary_ledger_income_balance >0) { echo' '.number_format($last_year_subsidiary_ledger_income_balance, 2 . '').' ';} else if($last_year_subsidiary_ledger_income_balance ==0) {echo '-';} else { echo' ('.number_format(abs($last_year_subsidiary_ledger_income_balance), 2 . '').') ';} ?></td>
					<?php }?>
				</tr>
				<?php }?> 
				<?php }?>
				
			<?php } else  if($type == 'Expenditure') {
				// expenditure ....
				$serial = $note;
				$total_current_month_accounts_category_expenditure = 0;
				$total_last_month_accounts_category_expenditure = 0;
				$total_previous_month_accounts_category_expenditure = 0;
				$total_current_year_accounts_category_expenditure = 0;
				$total_last_year_accounts_category_expenditure = 0;
				$total_previous_year_accounts_category_expenditure = 0;
				
				$accounts_category_expenditure = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_id', $coa) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
				foreach ($accounts_category_expenditure as $accounts_category_expenditure_row) 
				{?>
				<tr>
					<th class="tx-left" width="3%"><?= number_format(+$serial,2 . '');?></th>
					<th class="tx-left tx-uppercase" colspan="13"><?= $accounts_category_expenditure_row->chart_of_accounts_code;?> - <?= $accounts_category_expenditure_row->chart_of_accounts_name;?></th>
				</tr>
				<?php 
				$total_current_month_subsidiary_ledger_expenditure = 0;
				$total_current_last_month_subsidiary_ledger_expenditure = 0;
				$total_current_previous_month_subsidiary_ledger_expenditure = 0;
				$total_quarterly_subsidiary_ledger_expenditure = 0;
				$total_current_year_subsidiary_ledger_expenditure = 0;
				$total_last_year_subsidiary_ledger_expenditure = 0;
				$total_previous_year_subsidiary_ledger_expenditure = 0;
				
				$subsidiary_ledger_expenditure = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_id', $s_coa) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
				foreach ($subsidiary_ledger_expenditure as $subsidiary_ledger_expenditure_row) 
				{?> 
				<tr>
					<td class="tx-left"><?= $subsidiary_ledger_expenditure_row->chart_of_accounts_code;?> - <?= $subsidiary_ledger_expenditure_row->chart_of_accounts_name;?></th>
					<?php 
					$current_month_subsidiary_ledger_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_month_subsidiary_ledger_expenditure_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
					->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_expenditure_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($current_month_subsidiary_ledger_expenditure as $current_month_subsidiary_ledger_expenditure_row)
					{
					$current_month_subsidiary_ledger_expenditure_balance = $current_month_subsidiary_ledger_expenditure_row->current_month_subsidiary_ledger_expenditure_balance;
					$total_current_month_subsidiary_ledger_expenditure  += $current_month_subsidiary_ledger_expenditure_balance;
					?>			
					<td class="tx-center" width="1%"></td>
					<td class="tx-right"><?php if ($current_month_subsidiary_ledger_expenditure_balance >0) { echo' '.number_format($current_month_subsidiary_ledger_expenditure_balance, 2 . '').' ';} else if($current_month_subsidiary_ledger_expenditure_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_month_subsidiary_ledger_expenditure_balance), 2 . '').') ';} ?></td>
					<?php }
					
					$current_last_month_subsidiary_ledger_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_last_month_subsidiary_ledger_expenditure_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_last_month_start_date.'" and "'.$current_last_month_end_date.'"')
					->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_expenditure_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($current_last_month_subsidiary_ledger_expenditure as $current_last_month_subsidiary_ledger_expenditure_row)
					{
					$current_last_month_subsidiary_ledger_expenditure_balance = $current_last_month_subsidiary_ledger_expenditure_row->current_last_month_subsidiary_ledger_expenditure_balance;
					$total_current_last_month_subsidiary_ledger_expenditure  += $current_last_month_subsidiary_ledger_expenditure_balance;
					?>			
					<td class="tx-center" width="1%"></td>
					<td class="tx-right"><?php if ($current_last_month_subsidiary_ledger_expenditure_balance >0) { echo' '.number_format($current_last_month_subsidiary_ledger_expenditure_balance, 2 . '').' ';} else if($current_last_month_subsidiary_ledger_expenditure_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_last_month_subsidiary_ledger_expenditure_balance), 2 . '').') ';} ?></td>
					<?php }
					
					$current_previous_month_subsidiary_ledger_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_previous_month_subsidiary_ledger_expenditure_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_previous_month_start_date.'" and "'.$current_previous_month_end_date.'"')
					->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_expenditure_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($current_previous_month_subsidiary_ledger_expenditure as $current_previous_month_subsidiary_ledger_expenditure_row)
					{
					$current_previous_month_subsidiary_ledger_expenditure_balance = $current_previous_month_subsidiary_ledger_expenditure_row->current_previous_month_subsidiary_ledger_expenditure_balance;
					$total_current_previous_month_subsidiary_ledger_expenditure  += $current_previous_month_subsidiary_ledger_expenditure_balance;
					?>			
					<td class="tx-center" width="1%"></td>
					<td class="tx-right"><?php if ($current_previous_month_subsidiary_ledger_expenditure_balance >0) { echo' '.number_format($current_previous_month_subsidiary_ledger_expenditure_balance, 2 . '').' ';} else if($current_previous_month_subsidiary_ledger_expenditure_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_previous_subsidiary_ledger_expenditure_balance), 2 . '').') ';} ?></td>
					<?php }
					
					$quarterly_subsidiary_ledger_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS quarterly_subsidiary_ledger_expenditure_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$quarterly_start_date.'" and "'.$quarterly_end_date.'"')
					->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_expenditure_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($quarterly_subsidiary_ledger_expenditure as $quarterly_subsidiary_ledger_expenditure_row)
					{
					$quarterly_subsidiary_ledger_expenditure_balance = $quarterly_subsidiary_ledger_expenditure_row->quarterly_subsidiary_ledger_expenditure_balance;
					$total_quarterly_subsidiary_ledger_expenditure  += $quarterly_subsidiary_ledger_expenditure_balance;
					?>			
					<td class="tx-center" width="1%"></td>
					<td class="tx-right"><?php if ($quarterly_subsidiary_ledger_expenditure_balance >0) { echo' '.number_format($quarterly_subsidiary_ledger_expenditure_balance, 2 . '').' ';} else if($quarterly_subsidiary_ledger_expenditure_balance ==0) {echo '-';} else { echo' ('.number_format(abs($quarterly_subsidiary_ledger_expenditure_balance), 2 . '').') ';} ?></td>
					<?php }
					
					$current_year_subsidiary_ledger_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_year_subsidiary_ledger_expenditure_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_year_start_date.'" and "'.$current_year_end_date.'"')
					->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_expenditure_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($current_year_subsidiary_ledger_expenditure as $current_year_subsidiary_ledger_expenditure_row)
					{
					$current_year_subsidiary_ledger_expenditure_balance = $current_year_subsidiary_ledger_expenditure_row->current_year_subsidiary_ledger_expenditure_balance;
					$total_current_year_subsidiary_ledger_expenditure  += $current_year_subsidiary_ledger_expenditure_balance;
					?>			
					<td class="tx-center" width="1%"></td>
					<td class="tx-right"><?php if ($current_year_subsidiary_ledger_expenditure_balance >0) { echo' '.number_format($current_year_subsidiary_ledger_expenditure_balance, 2 . '').' ';} else if($current_year_subsidiary_ledger_expenditure_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_year_subsidiary_ledger_expenditure_balance), 2 . '').') ';} ?></td>
					<?php }
					
					$last_year_subsidiary_ledger_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS last_year_subsidiary_ledger_expenditure_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
					->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_expenditure_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($last_year_subsidiary_ledger_expenditure as $last_year_subsidiary_ledger_expenditure_row)
					{
					$last_year_subsidiary_ledger_expenditure_balance = $last_year_subsidiary_ledger_expenditure_row->last_year_subsidiary_ledger_expenditure_balance;
					$total_last_year_subsidiary_ledger_expenditure  += $last_year_subsidiary_ledger_expenditure_balance;
					?>			
					<td class="tx-center " width="1%"></td>
					<td class="tx-right "><?php if ($last_year_subsidiary_ledger_expenditure_balance >0) { echo' '.number_format($last_year_subsidiary_ledger_expenditure_balance, 2 . '').' ';} else if($last_year_subsidiary_ledger_expenditure_balance ==0) {echo '-';} else { echo' ('.number_format(abs($last_year_subsidiary_ledger_expenditure_balance), 2 . '').') ';} ?></td>
					<?php }?>
				</tr>
				<?php }?> 
				<?php }?>
			<?php }?>
			</tbody>
		</table>
		
		<br/><br/><br/><br/>
		
		<table class="" width="100%" align="center">  
			<tr class="tx-uppercase">
				<th width="30%" class="text-center"></th>
				<th width="5%"></th>
				<th width="30%" class="text-center"></th>
				<th width="5%"></th>
				<th width="30%" class="text-center bd-top"><?= $this->lang->line('prepared_by');?></th>
			</tr>
		</table>
		
		
	</div>
</body>