<!-- Page Inner Start --> 
<div class="page-inner" style="margin-bottom:80px;">
	<!-- Main Wrapper -->
	<div id="main-wrapper"> 
		<!-- Breadcrumb Start --> 
		<div class="pageheader pd-t-10 pd-b-10">
			<div class="d-flex justify-content-between">
				<div class="clearfix tx-uppercase">
					<div class="pd-t-5 pd-b-5">
					  <h2 class="pd-0 mg-0 tx-18 tx-dark"><?= $page_name;?></h2>
					</div>
					<div class="breadcrumb pd-0 mg-0">
						<a class="breadcrumb-item" href="<?= base_url('./login');?>"><i class="fa fa-dashboard"></i> <?= $this->lang->line('dashboard');?></a> /
						<span class="breadcrumb-item active"><?= $page_name;?></span>
					</div>
				</div>
			</div>
		</div>
		<!--/ Breadcrumb End -->
	  
		<!-- Articles Start -->
		<div class="card mg-b-30"> 
			<div class="col-md-12" style="margin-bottom:10px;">
				<!------------- Flash Massage Start ------------->
				<?php if ($this->session->flashdata('success') != null) {  ?>
				<div class="alert alert-success">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
					<center><?php echo $this->session->flashdata('success'); ?></center>
				</div> 
				<?php } ?>
				
				<?php if ($this->session->flashdata('update') != null) {  ?>
				<div class="alert alert-info">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
					<center><?php echo $this->session->flashdata('update'); ?></center>
				</div> 
				<?php } ?>
				
				<?php if ($this->session->flashdata('error') != null) {  ?>
				<div class="alert alert-danger">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
					<center><?php echo $this->session->flashdata('error'); ?></center>
				</div>
				<?php } ?>
				<!------------- Flash Massage End ------------->
				<form method="post" target="print_popup" action="<?= base_url('accounts/voucher_information_print');?>" onsubmit="window.open('about:blank','print_popup','width=800,height=700');">
					<div class="form-row mg-t-10">
						<div class="col-md-3 col-sm-12">
							<label for="label"><?= $this->lang->line('date');?> <?= $this->lang->line('from');?> *</label> 
							<input type="date" class="form-control form-control-sm bd-danger search_datepicker " id="posting_from_date" name="posting_from_date" value="<?= date('Y-m-d');?>"required>
						</div>
						<div class="col-md-3 col-sm-12">
							<label for="label"><?= $this->lang->line('date');?> <?= $this->lang->line('to');?> *</label> 
							<input type="date" class="form-control form-control-sm bd-danger search_datepicker " id="posting_to_date" name="posting_to_date" value="<?= date('Y-m-d');?>"required>
						</div>
						<div class="col-md-3 col-sm-12">
							<label for="label"><?= $this->lang->line('voucher_type');?> *</label> 
							<select class="form-control form-control-sm bd-danger" id="voucher_type" name="voucher_type"required>
								<option value=""> --- <?= $this->lang->line('select');?> ---</option>
								<?php 
								$voucher_type =  $this->db->select("*") ->from('voucher_type') ->where('voucher_type_status', 1) ->order_by('voucher_type_id', 'ASC') ->get() ->result();
								foreach($voucher_type as $voucher_type_row) {?>
								<option value="<?= $voucher_type_row->voucher_type_id;?>"><?= $voucher_type_row->voucher_type_name;?></option>
								<?php }?>
							</select>
						</div>
						<div class="col-md-3 col-sm-12">
							<label for="label"> &nbsp; </label> 
							<button type="submit" class="btn btn-brand  btn-block tx-uppercase"><i class="fa fa-print"></i> <?= $this->lang->line('print');?></button>
						</div>
					</div>
				</form>
			</div>
			<div class="col-md-12">
				<div class="table-responsive">
					<table class="table table-striped table-bordered table-hover mt-5">
						<thead class="tx-10 tx-uppercase">
							<tr> 
								<th class="tx-center"><?= $this->lang->line('sl_no');?></th>
								<th class="tx-center"><?= $this->lang->line('posting_date');?></th>
								<th class="tx-center"><?= $this->lang->line('voucher_type');?></th>
								<th class="tx-center"><?= $this->lang->line('voucher_number');?></th>
								<th class="tx-center"><?= $this->lang->line('narration');?></th>
								<th class="tx-center"><?= $this->lang->line('debit');?></th>
								<th class="tx-center"><?= $this->lang->line('credit');?></th>
								<th class="tx-center d-print-none"><?= $this->lang->line('option');?></th>
							</tr>
						</thead>
						<tbody id="posting_info">
							
						</tbody>
					</table>
				</div>
			</div>
			<script>
				$(document).ready(function(){
					$('#voucher_type, #posting_from_date, #posting_to_date').change(function(){
					  var posting_from_date = $('#posting_from_date').val();
					  var posting_to_date = $('#posting_to_date').val();
					  var voucher_type = $('#voucher_type').val();
					  if(voucher_type != '') 
					  {
					   $.ajax({
						url:"<?= base_url('accounts/get_voucher_information');?>",
						beforeSend: function() {
							$('#posting_info').html('<tr class="tx-center tx-uppercase"><th colspan="8"><img src="<?= base_url("assets/images/loading/loader.gif");?>"/><h6 class="tx-center tx-uppercase tx-13 tx-bold"><?= $this->lang->line("loading");?></h6></th></tr>');
						},
						method:"POST",
						data:{voucher_type:voucher_type, posting_from_date:posting_from_date, posting_to_date:posting_to_date},
						success:function(data)
						{
						 $('#posting_info').html(data);
						}
					   });
					  }
					  else
					  {
					   $('#posting_info').html('<tr class="tx-center tx-uppercase"><th colspan="8"><?= $this->lang->line("data_searching_error");?></th></tr>');
					  }
					});
				}); 
			</script>
		</div>
		<!--/ Articles End -->				  
   </div>
   <!--/ Main Wrapper End -->
</div>
<!--/ Page Inner End -->

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"><?= $page_name;?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        ...
      </div>
      <!-- <div class="modal-footer">
        
		
       <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div> -->
    </div>
  </div>
</div>


<!-- Add / Edit Modal Start-->
<!-- <div class="modal fade effect-scale" id="modal_view_ajax" role="dialog">
	<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header tx-uppercase">
				<h5 class="modal-title"><?= $this->lang->line('view');?> <?= $page_name;?></h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <i data-feather="x"></i> </button>
			</div>
			<div class="modal-body form pd-y-20">
				
			</div>
		</div>
	</div>
</div>  -->
<div class="modal fade effect-scale" id="modal_view_ajax" role="dialog">
	<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header tx-uppercase">
				<h5 class="modal-title"><?= $this->lang->line('view');?> <?= $page_name;?></h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <i data-feather="x"></i> </button>
			</div>
			<div class="modal-body form pd-y-20">
				
			</div>
		</div>
	</div>
</div>
<!--/ Add / Edit Modal End-->

<!-- (Delete Modal)-->
<div class="modal fade" id="modal-delete">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header tx-uppercase">  
				<h5 class="modal-title"><?= $this->lang->line('model_delete_warning');?></h5>
			</div>
			<div class="modal-footer" style="margin:0px; border-top:0px; text-align:center;">
				<a href="javascript:void(0)" class="btn btn-outline-danger rounded-pill" id="delete_link" title="<?= $this->lang->line('yeas');?>"><i class="fa fa-check"></i></a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
				<button type="button" class="btn btn-outline-danger rounded-pill" data-dismiss="modal" title="<?= $this->lang->line('no');?>"><i class="fa fa-remove"></i></button>
			</div>
		</div>
	</div>
</div>
<!-- (Delete Modal)-->



<script type="text/javascript">
	// $(document).ready(function(){
	// 	console.log('Show');;
	// 	$('#exampleModal').modal('show');
	// })
	
	function action_view_model(url)
	{
		// SHOWING AJAX PRELOADER IMAGE
		 $('#exampleModal .modal-body').html('<div style="text-align:center; margin-top:20px;"><img src="<?php echo base_url("assets/images/loading/loader.gif");?>" /></div>');
		
		// LOADING THE AJAX MODAL
		 //$('#modal_view_ajax').modal('show', {backdrop: 'true'});
		
		// SHOW AJAX RESPONSE ON REQUEST SUCCESS
		$.ajax({
			url: url,
			success: function(response)
			{
				console.log('Here');
				$('#exampleModal .modal-body').html(response);
				$('#exampleModal').modal('show');
				//$('#modal_ajax').modal('show');
			}
		});
	}
	
	function action_delete_modal(delete_url)
	{
		$('#modal-delete').modal('show', {backdrop: 'static'});
		document.getElementById('delete_link').setAttribute('href' , delete_url);
	}
</script>