<!-- Page Inner Start --> 
<div class="page-inner" style="margin-bottom: 80px;">
	<!-- Main Wrapper -->
	<div id="main-wrapper"> 
		
		<!-- Breadcrumb Start -->
		<div class="pageheader pd-t-10 pd-b-10">
			<div class="d-flex justify-content-between">
				<div class="clearfix tx-uppercase">
					<div class="pd-t-5 pd-b-5">
						<h1 class="pd-0 mg-0 tx-20 tx-dark"><?= $page_name; ?></h1>
					</div>
					<div class="breadcrumb pd-0 mg-0">
						<a class="breadcrumb-item" href="<?= base_url('./login'); ?>"><i class="fa fa-dashboard"></i> <?= $this->lang->line('dashboard'); ?></a>
						<a class="breadcrumb-item" href="javascript:void(0);"><?= $this->lang->line('accounts'); ?></a>
						<span class="breadcrumb-item active"><?= $page_name; ?></span>
					</div>
				</div>
				<div class="d-flex align-items-center tx-uppercase">
					<button type="button" class="btn btn-outline-success rounded-pill mr-2 d-lg-block pd-t-6-force pd-b-5-force tx-uppercase" onclick="window.location.href='<?= base_url('/login'); ?>'"> <i class="fa fa-home"></i> <?= $this->lang->line('dashboard'); ?></button>
				</div>
			</div>
		</div>
		<!--/ Breadcrumb End -->

		<!-- Articles Start -->
		<div class="card mg-b-30"> 
			
			<div class="col-md-12">
				<h2 class="pd-0 mg-0 tx-20 tx-dark text-center"><?= $page_name;?></h2>	
				<div class="form-row mg-t-10 no_print">
					<div class="col-md-4 col-sm-12">
						<label for="label"><?= $this->lang->line('date');?></label>
						<input type="date" class="form-control form-control-sm bd-danger" id="to_date" name="to_date" value="<?= date('Y-m-d');?>"required>
					</div> 
					<div class="col-md-4 col-sm-12"> 
						<label for="label">&nbsp;</label>
						<button type="button" id="search" class="btn btn-brand btn-success btn-block tx-uppercase"><i class="fa fa-search"></i> <?= $this->lang->line('search');?></button>
					</div>
				</div>
			</div>	<br/>
			
			<div class="table-responsive"> 
				<form method="post" id="insert">
					<table class="table table-striped table-bordered">
						<thead class="tx-uppercase">
							<tr>
								<th class="tx-center"><?= $this->lang->line('sl_no');?></th> 
								<th class="tx-center" colspan="2"><?= $this->lang->line('description');?></th>
								<th class="tx-center"><?= $this->lang->line('type');?></th>
								<th class="tx-center"><?= $this->lang->line('amount');?></th> 
							</tr>
						</thead>
						<tbody id="day_close">
							
						</tbody>
					</table>
				</form>
				<script>
					$(document).ready(function(){
						$('#search').click(function(){
						  var project = $('#project').val();
						  var from_date = $('#from_date').val();
						  var to_date = $('#to_date').val();  
						  var user = $('#user').val();  
						  if(user != '') 
						  {
						   $.ajax({
							url:"<?= base_url('accounts/get_day_close');?>",
							beforeSend: function() {
								$('#day_close').html('<tr class="tx-center tx-uppercase"><th colspan="13"><img src="<?= base_url("assets/assets/images/loading/loader.gif");?>"/><h6 class="tx-center tx-uppercase tx-13 tx-bold"><?= $this->lang->line("loading");?></h6></th></tr>');
							},
							method:"POST",
							data:{project:project, from_date:from_date, to_date:to_date, user:user},
							success:function(data)
							{
							 $('#day_close').html(data);
							}
						   });
						  }
						  else
						  {
							$('#day_close').html('<tr class="tx-center tx-uppercase"><th colspan="13"><?= $this->lang->line("data_searching_error");?></th></tr>');
						  }
						});
					}); 
					
					function action_model(url)
					{
						// SHOWING AJAX PRELOADER IMAGE
						jQuery('#modal_ajax .modal-content').html('<div style="text-align:center; margin-top:20px;"><img src="<?php echo base_url("assets/images/loading/loader.gif");?>" /></div>');
						
						// LOADING THE AJAX MODAL
						jQuery('#modal_ajax').modal('show', {backdrop: 'true'});
						
						// SHOW AJAX RESPONSE ON REQUEST SUCCESS
						$.ajax({
							url: url,
							success: function(response)
							{
								jQuery('#modal_ajax .modal-content').html(response);
							}
						});
					}
				</script>
			</div> 
		</div>
		<!--/ Articles End -->				  
   </div>
   <!--/ Main Wrapper End -->
</div>
<!--/ Page Inner End -->


<div class="modal fade effect-scale" id="modal_ajax">
	<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header tx-uppercase"> 
			</div>
			<div class="modal-body">
				<div id="data_message">
				
				</div>
			</div>
		</div>
	</div>
</div>