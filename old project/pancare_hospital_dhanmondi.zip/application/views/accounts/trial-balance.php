<!-- Page Inner Start --> 
<div class="page-inner" style="margin-bottom:80px;">
	<!-- Main Wrapper -->
	<div id="main-wrapper"> 
	  <!-- Breadcrumb Start --> 
		<div class="pageheader pd-t-10 pd-b-10">
			<div class="d-flex justify-content-between">
				<div class="clearfix tx-uppercase">
					<div class="pd-t-5 pd-b-5">
					  <h1 class="pd-0 mg-0 tx-20 tx-dark"><?= $page_name;?></h1>
					</div>
					<div class="breadcrumb pd-0 mg-0">
						<a class="breadcrumb-item" href="<?= base_url('./login');?>"><i class="fa fa-dashboard"></i> <?= $this->lang->line('dashboard');?></a>
						<a class="breadcrumb-item" href="javascript:void(0);"><?= $this->lang->line('accounts');?></a>
						<span class="breadcrumb-item active"><?= $page_name;?></span>
					</div>
				</div>
				<div class="d-flex align-items-center tx-uppercase">
					<button type="button" class="btn btn-outline-success rounded-pill mr-2 d-lg-block pd-t-6-force pd-b-5-force tx-uppercase" onclick="history.back()"> <i class="fa fa-arrow-left"></i> <?= $this->lang->line('go_back'); ?></button>
				</div>
			</div>
		</div>
		<!--/ Breadcrumb End -->
	  
		<!-- Articles Start -->
		<div class="card mg-b-30"> 
			
			<div class="col-md-12">
			<form method="post" target="print_popup" action="<?= base_url('accounts/trial_balance_print');?>" onsubmit="window.open('about:blank','print_popup','width=800,height=700');">
					
				<div class="form-row mg-t-10">
					<div class="col-md-6 col-sm-12">
						<label for="label"><?= $this->lang->line('closing_date');?></label> 
						<input type="date" class="form-control form-control-sm bd-danger tx-center" id="posting_to_date" name="posting_to_date" value="<?= date('Y-m-d');?>"required>
					</div>
					<div class="col-md-3 col-sm-12">
						<label for="label">&nbsp;</label>
						<button type="button" id="search" class="btn btn-brand btn-success btn-block tx-uppercase"><i class="fa fa-search"></i> <?= $this->lang->line('search');?></button>
					</div>
					
					<div class="col-md-3 col-sm-12">
						<label for="label"> &nbsp; </label> 
						<button type="submit" class="btn btn-brand  btn-block tx-uppercase"><i class="fa fa-print"></i> <?= $this->lang->line('print');?></button>
					</div>
				</form>
			</div>
			</div><br/> 
			<div class="col-md-12">
				<div class="table-responsive">
					<table class="table table-striped table-bordered table-hover">
						<thead class="tx-uppercase">
							<tr>  
								<th class="tx-center"><?= $this->lang->line('accounts_code');?></th>
								<th class="tx-center"><?= $this->lang->line('head_of_accounts');?></th>
								<th class="tx-center"><?= $this->lang->line('debit');?></th>
								<th class="tx-center"><?= $this->lang->line('credit');?></th>
							</tr>
						</thead>
						<tbody id="trial_balance_info">
						</tbody>
					</table>
				</div>
			</div>
			<script>
				$(document).ready(function(){
					$('#search').click(function(){  
					  var posting_to_date = $('#posting_to_date').val(); 
					  if(posting_to_date != '') 
					  {
					   $.ajax({
						url:"<?= base_url('accounts/get_trial_balance');?>",
						beforeSend: function() {
							$('#trial_balance_info').html('<tr><th class="tx-center tx-uppercase" colspan="4"><img src="<?php echo base_url("assets/images/loading/loader.gif");?>"/><h6 class="tx-center tx-uppercase tx-13 tx-bold"><?= $this->lang->line("loading");?></h6></th></tr>');
						},
						method:"POST",
						data:{posting_to_date:posting_to_date},
						success:function(data)
						{
						 $('#trial_balance_info').html(data);
						}
					   });
					  }
					  else
					  {
					   $('#trial_balance_info').html('<tr><th class="tx-center tx-uppercase" colspan="4"><?= $this->lang->line("data_searching_error");?></th></tr>');
					  }
					});
				}); 
			</script>
		</div>
		<!--/ Articles End -->				  
   </div>
   <!--/ Main Wrapper End -->
</div>
<!--/ Page Inner End -->