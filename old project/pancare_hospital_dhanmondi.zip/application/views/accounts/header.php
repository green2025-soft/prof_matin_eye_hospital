<?php include 'header-top.php';?>
<body> 
	<div class="page-container"> 
	 
		<div class="page-sidebar">
			<div class="logo">
			   <a class="logo-img" href="<?= base_url('./login');?>" style="color:#fff;">		
				   <img class="desktop-logo" src="<?= base_url("$system_logo");?>" alt="Logo">
				   <img class="small-logo" src="<?= base_url("$system_logo");?>" alt="Logo">
			   </a>			
			   <a id="sidebar-toggle-button-close"><i class="wd-20" data-feather="x"></i> </a>
			</div>   
			
			<?php $user_group = $this->session->userdata('user_group');
			// Super Admin & System Admin Module ....
			if ($user_group == 1 || $user_group == 2) {
				require_once 'menu/super-admin-header.php';
			}  
			//  Managing Director Module ....
			else if ($user_group == 3) {
				require_once 'menu/super-admin-header.php';
			} 
			//  Office Manager Module ....
			else if ($user_group == 4) {
				require_once 'menu/office-manager-header.php';
			}
			//  Administrative ....
			else if ($user_group == 5) {
				require_once 'menu/administrative-header.php';
			}
			//  Accounts  Module ....
			else if ($user_group == 6) {
				require_once 'menu/accounts-header.php';
			} 
			//  OPD & IPD  Module ....
			else if ($user_group == 7) {
				require_once 'menu/opd-ipd-header.php';
			}
			//  OPD  Module ....
			else if ($user_group == 8) {
				require_once 'menu/opd-header.php';
			}
			//  IPD  Module ....
			else if ($user_group == 9) {
				require_once 'menu/ipd-header.php';
			}
			//  Laboratory  Module ....
			else if ($user_group == 10) {
				require_once 'menu/laboratory-header.php';
			} 
			//  Nurse  Module ....
			else if ($user_group == 11) {
				require_once 'menu/ipd-header.php';
			} 
			//  Doctor  Module ....
			else if ($user_group == 12) {
				require_once 'menu/opd-ipd-header.php';
			} 
			//  Reference  Module ....
			else if ($user_group == 13) {
				require_once 'menu/patient-header.php';
			} 
			else {
				require_once 'menu/patient-header.php';
			}?> 
			<!-- Sidebar Menu End -->
			<div class="sidebar-footer">						
			   <a class="pull-left" href="<?= base_url('user/my_account_setting');?>" data-toggle="tooltip" data-placement="top" data-original-title="<?= $this->lang->line('my_account_setting');?>"> <i data-feather="settings" class="wd-16"></i></a>
			   <a class="pull-left" href="<?= base_url('user/my_profile');?>" data-toggle="tooltip" data-placement="top" data-original-title="<?= $this->lang->line('my_profile');?>"> <i data-feather="user" class="wd-16"></i></a>									
			   <a class="pull-left" href="<?= base_url('logout');?>" data-toggle="tooltip" data-placement="top" data-original-title="<?= $this->lang->line('logout');?>"> <i data-feather="power" class="wd-16"></i></a>
			</div> 
		</div> 
		<div class="page-content"> 
		 
			<div class="page-header">
				<nav class="navbar navbar-default">  
					<div class="navbar-header">
						<div class="navbar-brand">
							<ul class="list-inline">
							   <!-- Mobile Toggle and Logo -->
							   <li class="list-inline-item"><a class="hidden-md hidden-lg" href="javascript:void(0);" id="sidebar-toggle-button"><i data-feather="menu" class="wd-20"></i></a></li>
							   
							   <!-- PC Toggle and Logo -->
							   <li class="list-inline-item"><a class=" hidden-xs hidden-sm" href="javascript:void(0);" id="collapsed-sidebar-toggle-button"><i data-feather="menu" class="wd-20"></i></a></li> 
							</ul>
						</div>
					</div> 
					<div class="header-right pull-right">
						<ul class="list-inline justify-content-end">  
							<li class="list-inline-item dropdown">
								<a href="javascript:voide(0);" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									<?php if($this->session->userdata('site_lang') == 'english'){?>
									<i class="flag-icon flag-icon-us"></i> EN
									<?php } else if($this->session->userdata('site_lang') == 'bangla'){?>
									<i class="flag-icon flag-icon-bd"> </i> BN
									<?php } else {?>
									<i class="flag-icon flag-icon-us"></i> EN
									<?php } ?>
								</a>
								<ul class="dropdown-menu languages-dropdown">
									<li>
										<a href="<?= base_url('multilanguageswitcher/tswitch/english');?>" ><i class="flag-icon flag-icon-us mr-2"></i><span>English</span></a>
									</li>
									<li>
										<a href="<?= base_url('multilanguageswitcher/tswitch/bangla');?>" ><i class="flag-icon flag-icon-bd mr-2"></i><span>বাংলা</span></a>
									</li>
									<!--
									<li>
										<a href="<?= base_url('multilanguageswitcher/tswitch/spanish');?>" ><i class="flag-icon flag-icon-es mr-2"></i><span>Spanish</span></a>
									</li>
									<li>
										<a href="<?= base_url('multilanguageswitcher/tswitch/french');?>" ><i class="flag-icon flag-icon-fr mr-2"></i><span>French</span></a>
									</li>
									<li>
										<a href="<?= base_url('multilanguageswitcher/tswitch/german');?>" ><i class="flag-icon flag-icon-de mr-2"></i><span>German</span></a>
									</li>
									<li>
										<a href="<?= base_url('multilanguageswitcher/tswitch/russian');?>" ><i class="flag-icon flag-icon-ru mr-2"></i><span>Russian</span></a>
									</li>-->
								</ul>
							</li> 
							<li class="list-inline-item dropdown">
								<a  href="javascript:void(0);" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									<img src="<?= base_url('');?>assets/images/user-icon.png" class="img-fluid wd-30 ht-30 rounded-circle" alt="">
								</a>
								<div class="dropdown-menu dropdown-menu-right dropdown-profile">
									<div class="user-profile-area">
										<div class="user-profile-heading">
											<div class="profile-thumbnail">
												<img src="<?= base_url('');?>assets/images/user-icon.png" class="img-fluid wd-35 ht-35 rounded-circle" alt="">
											</div>
											<div class="profile-text">
												<?php 
													$user_name 			= $this->session->userdata('user_name'); 
												?>
												<h6><?= $user_name;?></h6> 
											</div>
										</div>
										<a href="<?= base_url('user/my_profile');?>" class="dropdown-item"><i data-feather="user" class="wd-16 mr-2"></i> <?= $this->lang->line('my_profile');?></a>
										<a href="<?= base_url('user/my_account_setting');?>" class="dropdown-item"><i data-feather="settings" class="wd-16 mr-2"></i> <?= $this->lang->line('my_account_setting');?></a>
										<a href="<?= base_url('logout');?>" class="dropdown-item"><i data-feather="power" class="wd-16 mr-2"></i> <?= $this->lang->line('logout');?></a>
									</div>
								</div>
							</li> 
						</ul>
					</div> 
				</nav>
			</div> 