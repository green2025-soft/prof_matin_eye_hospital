<!-- Page Inner Start --> 
<div class="page-inner" style="margin-bottom:80px;">
	<!-- Main Wrapper -->
	<div id="main-wrapper"> 
	  <!-- Breadcrumb Start --> 
		<div class="pageheader pd-t-10 pd-b-10">
			<div class="d-flex justify-content-between">
				<div class="clearfix tx-uppercase">
					<div class="pd-t-5 pd-b-5">
					  <h1 class="pd-0 mg-0 tx-20 tx-dark"><?= $page_name;?></h1>
					</div>
					<div class="breadcrumb pd-0 mg-0">
						<a class="breadcrumb-item" href="<?= base_url('./login');?>"><i class="fa fa-dashboard"></i> <?= $this->lang->line('dashboard');?></a>
						<span class="breadcrumb-item active"><?= $page_name;?></span>
					</div>
				</div>
				<div class="d-flex align-items-center tx-uppercase">
					<button type="button" class="btn btn-outline-success rounded-pill mr-2 d-lg-block pd-t-6-force pd-b-5-force tx-uppercase" onclick="window.location.href='<?= base_url('/accounts/voucher_information'); ?>'"> <i class="fa fa-list"></i> <?= $this->lang->line('voucher_information'); ?></button>
				</div>
			</div>
		</div>
		<!--/ Breadcrumb End -->
	  
		<!-- Articles Start -->
		<div class="card mg-b-30"> 
			<!------------- Flash Massage Start ------------->
			<?php if ($this->session->flashdata('success') != null) {  ?>
			<div class="alert alert-success">
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				<center><?php echo $this->session->flashdata('success'); ?></center>
			</div> 
			<?php } ?>
			
			<?php if ($this->session->flashdata('update') != null) {  ?>
			<div class="alert alert-info">
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				<center><?php echo $this->session->flashdata('update'); ?></center>
			</div> 
			<?php } ?>
			
			<?php if ($this->session->flashdata('error') != null) {  ?>
			<div class="alert alert-danger">
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				<center><?php echo $this->session->flashdata('error'); ?></center>
			</div>
			<?php } ?>
			<!------------- Flash Massage End ------------->
			<?php foreach($voucher_edit as $row) {?>
			<form method="post" action="<?= base_url('accounts/voucher_update');?>">
				<div class="col-md-12">
					<div class="form-row mg-t-10">
						<div class="col-md-3 col-sm-12">
							<label for="label"><?= $this->lang->line('posting_date');?> *</label> 
							<input type="hidden" class="form-control form-control-sm" name="accounts_id" value="<?= $row->accounts_id;?>"required>
							<input type="date" class="form-control form-control-sm bd-danger" id="accounts_voucher_posting_date" name="accounts_voucher_posting_date" value="<?= $row->accounts_voucher_posting_date;?>"required>
						</div>
						<div class="col-md-2 col-sm-12">
							<label for="label"><?= $this->lang->line('voucher_type');?> *</label> 
							<select class="form-control form-control-sm bd-danger" id="accounts_voucher_type" name="accounts_voucher_type"readonly required>
								<?php 
								$voucher_type =  $this->db->select("*") ->from('voucher_type') ->where('voucher_type_status', 1) ->where('voucher_type_id',$row->accounts_voucher_type) ->order_by('voucher_type_id', 'ASC') ->get() ->result();
								foreach($voucher_type as $voucher_type_row) {?>
								<option value="<?= $voucher_type_row->voucher_type_id;?>"><?= $voucher_type_row->voucher_type_name;?></option>
								<?php }?>
							</select>
						</div>
						<div class="col-md-2 col-sm-12" id="voucher_number_info">
							<label for="label"><?= $this->lang->line('voucher_number');?> *</label> 
							<input type="text" class="form-control form-control-sm bd-danger tx-center" id="accounts_voucher_number" name="accounts_voucher_number" value="<?= $row->accounts_voucher_number;?>"readonly required>
						</div>
						<div class="col-md-3 col-sm-12">
							<label for="label"><?= $this->lang->line('narration');?></label> 
							<input type="text" class="form-control form-control-sm  bd-info" id="accounts_narration" name="accounts_narration" value="<?= $row->accounts_narration;?>">
						</div>
						<div class="col-md-2 col-sm-12">
							<label for="label"> &nbsp;  </label> 
							<button type="submit" class="btn btn-brand btn-block btn-info tx-uppercase" onclick="return confirm('<?= $this->lang->line("model_update_warning");?>')"><?= $this->lang->line('update');?></button>
						</div>
					</div> 
				</div><br/> 
				<div class="col-md-12" id="collection_info">
					<div class="table-responsive">
						<table class="table table-striped table-bordered table-hover">
							<thead class="tx-10 tx-uppercase">
								<tr> 
									<th class="tx-center" width="10%"><?= $this->lang->line('accounts_type');?></th>
									<th class="tx-center" width="10%"><?= $this->lang->line('head_of_accounts');?></th>
									<th class="tx-center" width="14%"><?= $this->lang->line('control_group');?></th>
									<th class="tx-center" width="14%"><?= $this->lang->line('general_ledger');?></th>
									<th class="tx-center" width="14%"><?= $this->lang->line('subsidiary_ledger');?></th>
									<th class="tx-center" width="7%"><?= $this->lang->line('debit');?> <?= $this->lang->line('qnty');?></th>
									<th class="tx-center" width="7%"><?= $this->lang->line('credit');?> <?= $this->lang->line('qnty');?></th>
									<th class="tx-center" width="12%"><?= $this->lang->line('debit');?> <?= $this->lang->line('amount');?></th>
									<th class="tx-center" width="12%"><?= $this->lang->line('credit');?> <?= $this->lang->line('amount');?></th>	
								</tr> 
							</thead>
							<tbody>
								<?php 
								$accounts_details =  $this->db->select("*")
								->from('accounts_details')
								->where('accounts_details_accounts_id', $row->accounts_id) 
								->order_by('accounts_details_id', 'ASC')
								->get()
								->result();
								
								$serial = 0; 
								$value_1 = 0;
								$value_2 = 0;
								$value_3 = 0;
								$value_4 = 0;
								$value_5 = 0;
								$value_6 = 0;
								$value_7 = 0;
								$value_8 = 0;
								$value_9 = 0;
								$value_10 = 0;
								$value_11 = 0;
								$value_12 = 0;
								$value_13 = 0;
								$value_14 = 0;
								$value_15 = 0;
								$value_16 = 0;
								$value_17 = 0;
								$value_18 = 0;
								$value_19 = 0;
								$value_20 = 0;
								foreach($accounts_details as $accounts_details_row) {?>
								<tr>
									<td class="tx-center"> 
										<input type="hidden" class="form-control form-control-sm" name="count" value="<?= ++$serial;?>"required>
										<input type="hidden" class="form-control form-control-sm" name="accounts_details_id[]" value="<?= $accounts_details_row->accounts_details_id;?>"required>
										<select class="form-control form-control-sm bd-success" id="accounts_details_accounts_type_<?= ++$value_1;?>" name="accounts_details_accounts_type[]"readonly required>
											<?php 
											$accounts_type =  $this->db->select("*") ->from('accounts_type')->where('accounts_type_status', 1)->order_by('accounts_type_code', 'ASC')->get()->result();
											foreach($accounts_type as $accounts_type_row) {?>
											<option value="<?= $accounts_type_row->accounts_type_id;?>"<?php if($accounts_type_row->accounts_type_id == "$accounts_details_row->accounts_details_accounts_type"){echo 'selected';}?>><?= $accounts_type_row->accounts_type_code;?>-<?= $accounts_type_row->accounts_type_name;?></option>
											<?php }?>
										</select>
									</td>
									<td class="tx-center">
										<select class="form-control form-control-sm bd-info" id="accounts_details_accounts_category_<?= ++$value_2;?>" name="accounts_details_accounts_category[]"required>
											<?php 
											$accounts_category =  $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_details_row->accounts_details_accounts_type) ->order_by('chart_of_accounts_code', 'ASC')->get()->result();
											foreach($accounts_category as $accounts_category_row) {?>
											<option value="<?= $accounts_category_row->chart_of_accounts_id;?>"<?php if($accounts_category_row->chart_of_accounts_id == "$accounts_details_row->accounts_details_accounts_category"){echo 'selected';}?>><?= $accounts_category_row->chart_of_accounts_code;?>-<?= $accounts_category_row->chart_of_accounts_name;?></option>
											<?php }?>
										</select>
									</td>
									<td class="tx-center">
										<select class="form-control form-control-sm bd-info" id="accounts_details_control_group_<?= ++$value_18;?>" name="accounts_details_control_group[]"required>
											<?php 
											$control_group =  $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_details_row->accounts_details_accounts_category) ->order_by('chart_of_accounts_code', 'ASC')->get()->result();
											foreach($control_group as $control_group_row) {?>
											<option value="<?= $control_group_row->chart_of_accounts_id;?>"<?php if($control_group_row->chart_of_accounts_id == "$accounts_details_row->accounts_details_control_group"){echo 'selected';}?>><?= $control_group_row->chart_of_accounts_code;?>-<?= $control_group_row->chart_of_accounts_name;?></option>
											<?php }?>
										</select>
									</td> 
									<td class="tx-center">
										<select class="form-control form-control-sm bd-info" id="accounts_details_general_ledger_<?= ++$value_19;?>" name="accounts_details_general_ledger[]"required>
											<?php 
											$general_ledger =  $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category	', $accounts_details_row->accounts_details_control_group) ->order_by('chart_of_accounts_code', 'ASC')->get()->result();
											foreach($general_ledger as $general_ledger_row) {?>
											<option value="<?= $general_ledger_row->chart_of_accounts_id;?>"<?php if($general_ledger_row->chart_of_accounts_id == "$accounts_details_row->accounts_details_general_ledger"){echo 'selected';}?>><?= $general_ledger_row->chart_of_accounts_code;?>-<?= $general_ledger_row->chart_of_accounts_name;?></option>
											<?php }?>
										</select>
									</td> 
									<td class="tx-center">
										<select class="form-control form-control-sm bd-info" id="accounts_details_subsidiary_ledger_<?= ++$value_20;?>" name="accounts_details_subsidiary_ledger[]"required>
											<?php 
											$subsidiary_ledger =  $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_details_row->accounts_details_general_ledger) ->order_by('chart_of_accounts_code', 'ASC')->get()->result();
											foreach($subsidiary_ledger as $subsidiary_ledger_row) {?>
											<option value="<?= $subsidiary_ledger_row->chart_of_accounts_id;?>"<?php if($subsidiary_ledger_row->chart_of_accounts_id == "$accounts_details_row->accounts_details_subsidiary_ledger"){echo 'selected';}?>><?= $subsidiary_ledger_row->chart_of_accounts_code;?>-<?= $subsidiary_ledger_row->chart_of_accounts_name;?></option>
											<?php }?>
										</select>
									</td> 
									<td class="tx-center">
										<input type="text" class="form-control form-control-sm bd-info tx-center debit_quantity" id="accounts_details_debit_quantity" name="accounts_details_debit_quantity[]" autocomplete="off" value="<?= $accounts_details_row->accounts_details_debit_quantity;?>">
									</td> 
									<td class="tx-center">
										<input type="text" class="form-control form-control-sm bd-info tx-center credit_quantity" id="accounts_details_credit_quantity" name="accounts_details_credit_quantity[]" autocomplete="off" value="<?= $accounts_details_row->accounts_details_credit_quantity;?>">
									</td> 
									<td class="tx-center">
										<input type="text" class="form-control form-control-sm bd-info tx-center debit" id="accounts_details_debit" name="accounts_details_debit[]" autocomplete="off" value="<?= $accounts_details_row->accounts_details_debit;?>">
									</td> 
									<td class="tx-center">
										<input type="text" class="form-control form-control-sm bd-info tx-center credit" id="accounts_details_credit" name="accounts_details_credit[]" autocomplete="off" value="<?= $accounts_details_row->accounts_details_credit;?>">
									</td> 
								</tr>
								<script>
									$(document).ready(function(){
									$('#accounts_details_accounts_type_<?= ++$value_14;?>').change(function(){
									var accounts_category = $('#accounts_details_accounts_type_<?= ++$value_15;?>').val();
									if(accounts_category != '')
										{
											$.ajax(
											{
												url:"<?= base_url('accounts/voucher_posting_accounts_category_info');?>",
												method:"POST",
												data:{accounts_category:accounts_category},
												success:function(data)
												{
													$('#accounts_details_accounts_category_<?= ++$value_16;?>').html(data);
												}
											});
										}
										else
											{
											
											}
										});
									});
									
									$(document).ready(function(){
									$('#accounts_details_accounts_category_<?= ++$value_5;?>').change(function(){
									var accounts_category = $('#accounts_details_accounts_category_<?= ++$value_6;?>').val();
									if(accounts_category != '')
										{
											$.ajax(
											{
												url:"<?= base_url('accounts/voucher_posting_accounts_category_info');?>",
												method:"POST",
												data:{accounts_category:accounts_category},
												success:function(data)
												{
													$('#accounts_details_control_group_<?= ++$value_7;?>').html(data);
												}
											});
										}
										else
											{
											
											}
										});
									});
									
									$(document).ready(function(){
									$('#accounts_details_control_group_<?= ++$value_8;?>').change(function(){
									var accounts_category = $('#accounts_details_control_group_<?= ++$value_9;?>').val();
									if(accounts_category != '')
										{
											$.ajax(
											{
												url:"<?= base_url('accounts/voucher_posting_accounts_category_info');?>",
												method:"POST",
												data:{accounts_category:accounts_category},
												success:function(data)
												{
													$('#accounts_details_general_ledger_<?= ++$value_10;?>').html(data);
												}
											});
										}
										else
											{
											
											}
										});
									});
									
									$(document).ready(function(){
									$('#accounts_details_general_ledger_<?= ++$value_11;?>').change(function(){
									var accounts_category = $('#accounts_details_general_ledger_<?= ++$value_12;?>').val();
									if(accounts_category != '')
										{
											$.ajax(
											{
												url:"<?= base_url('accounts/voucher_posting_accounts_category_info');?>",
												method:"POST",
												data:{accounts_category:accounts_category},
												success:function(data)
												{
													$('#accounts_details_subsidiary_ledger_<?= ++$value_13;?>').html(data);
												}
											});
										}
										else
											{
											
											}
										});
									});
								</script>
								<?php }?>
								<tr>
									<th class="tx-center tx-uppercase" colspan="5"><?= $this->lang->line('total');?></th>
									<th class="tx-center">
										<input type="text" class="form-control form-control-sm bd-danger tx-center" id="total_debit_quantity" name="accounts_total_debit_quantity" value="<?= $row->accounts_total_debit_quantity;?>"readonly>
									</th>
									<th class="tx-center"> 
										<input type="text" class="form-control form-control-sm bd-danger tx-center" id="total_credit_quantity" name="accounts_total_credit_quantity" value="<?= $row->accounts_total_credit_quantity;?>"readonly>
									</th>
									
									<th class="tx-center">
										<input type="text" class="form-control form-control-sm bd-danger tx-center" id="total_debit" name="accounts_total_debit" value="<?= $row->accounts_total_debit;?>"readonly>
									</th>
									<th class="tx-center"> 
										<input type="text" class="form-control form-control-sm bd-danger tx-center" id="total_credit" name="accounts_total_credit" value="<?= $row->accounts_total_credit;?>"readonly>
									</th>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</form>
			<?php }?>
			<script>
				$(document).ready(function(){
					$('.debit_quantity').keyup(function(){ 
					
						var sum = 0;
						$(".debit_quantity").each(function() {
						sum += +$(this).val();
						});
					   
					   $('#total_debit_quantity').val(sum);
					});
				});
				
				$(document).ready(function(){
					$('.credit_quantity').keyup(function(){ 
					
						var sum = 0;
						$(".credit_quantity").each(function() {
						sum += +$(this).val();
						});
					   
					   $('#total_credit_quantity').val(sum);
					});
				});
				
				$(document).ready(function(){
					$('.debit').keyup(function(){ 
					
						var sum = 0;
						$(".debit").each(function() {
						sum += +$(this).val();
						});
					   
					   $('#total_debit').val(sum);
					});
				});
				
				$(document).ready(function(){
					$('.credit').keyup(function(){ 
					
						var sum = 0;
						$(".credit").each(function() {
						sum += +$(this).val();
						});
					   
					   $('#total_credit').val(sum);
					});
				});
			</script>
		</div>
		<!--/ Articles End -->				  
   </div>
   <!--/ Main Wrapper End -->
</div>
<!--/ Page Inner End -->