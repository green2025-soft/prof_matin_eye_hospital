<!-- Page Inner Start --> 
<div class="page-inner" style="margin-bottom:80px;">
	<!-- Main Wrapper -->
	<div id="main-wrapper"> 
	  <!-- Breadcrumb Start --> 
		<div class="pageheader pd-t-10 pd-b-10">
			<div class="d-flex justify-content-between">
				<div class="clearfix tx-uppercase">
					<div class="pd-t-5 pd-b-5">
					  <h1 class="pd-0 mg-0 tx-20 tx-dark"><?= $page_name;?></h1>
					</div>
					<div class="breadcrumb pd-0 mg-0">
						<a class="breadcrumb-item" href="<?= base_url('./login');?>"><i class="fa fa-dashboard"></i> <?= $this->lang->line('dashboard');?></a>
						<a class="breadcrumb-item" href="javascript:void(0);"><?= $this->lang->line('accounts');?></a>
						<span class="breadcrumb-item active"><?= $page_name;?></span>
					</div>
				</div>
				<div class="d-flex align-items-center tx-uppercase">
					<button type="button" class="btn btn-outline-success rounded-pill mr-2 d-lg-block pd-t-6-force pd-b-5-force tx-uppercase" onclick="history.back()"> <i class="fa fa-arrow-left"></i> <?= $this->lang->line('go_back'); ?></button>
				</div>
			</div>
		</div>
		<!--/ Breadcrumb End -->
	  
		<!-- Articles Start -->
		<div class="card mg-b-30"> 
			
			<div class="col-md-12">
			<form method="post" target="print_popup" action="<?= base_url('accounts/receipt_payment_print');?>" onsubmit="window.open('about:blank','print_popup','width=800,height=700');">
					
				<div class="form-row mg-t-10">
					<div class="col-md-3 col-sm-12">
						<label for="label"><?= $this->lang->line('starting_date');?></label> 
						<input type="date" class="form-control form-control-sm bd-danger tx-center" id="starting_date" name="starting_date" value="<?= date('Y-m-d');?>"required>
					</div>
					<div class="col-md-3 col-sm-12">
						<label for="label"><?= $this->lang->line('closing_date');?></label> 
						<input type="date" class="form-control form-control-sm bd-danger tx-center" id="closing_date" name="closing_date" value="<?= date('Y-m-d');?>"required>
					</div>
					<div class="col-md-3 col-sm-12">
						<label for="label">&nbsp;</label>
						<button type="button" id="search" class="btn btn-brand btn-success btn-block tx-uppercase"><i class="fa fa-search"></i> <?= $this->lang->line('search');?></button>
					</div>
					
					<div class="col-md-3 col-sm-12">
						<label for="label"> &nbsp; </label> 
						<button type="submit" class="btn btn-brand  btn-block tx-uppercase"><i class="fa fa-print"></i> <?= $this->lang->line('print');?></button>
					</div>
				</div>
			</form>
			
			</div><br/> 
			<div class="col-md-12">
				<div class="table-responsive" id="receipt_payment_info">
					
				</div>
			</div>
			<script>
				$(document).ready(function(){
					$('#search').click(function(){  
					  var starting_date = $('#starting_date').val(); 
					  var closing_date = $('#closing_date').val(); 
					  if(closing_date != '') 
					  {
					   $.ajax({
						url:"<?= base_url('accounts/get_receipt_payment');?>",
						beforeSend: function() {
							$('#receipt_payment_info').html('<div style="text-align:center; margin-top:20px;"><img src="<?php echo base_url("assets/images/loading/loader.gif");?>"/><h6 class="tx-center tx-uppercase tx-13 tx-bold"><?= $this->lang->line("loading");?></h6></div>');
						},
						method:"POST",
						data:{starting_date:starting_date, closing_date:closing_date},
						success:function(data)
						{
						 $('#receipt_payment_info').html(data);
						}
					   });
					  }
					  else
					  {
					   $('#receipt_payment_info').html('<div><h6 class="tx-center tx-uppercase"><?= $this->lang->line("data_searching_error");?></h6></div>');
					  }
					});
				}); 
			</script>
		</div>
		<!--/ Articles End -->				  
   </div>
   <!--/ Main Wrapper End -->
</div>
<!--/ Page Inner End -->

<script type="text/javascript">
	function action_view_model(url)
	{
		// SHOWING AJAX PRELOADER IMAGE
		jQuery('#modal_view_ajax .modal-body').html('<div style="text-align:center; margin-top:20px;"><img src="<?php echo base_url("assets/images/loading/loader.gif");?>" /></div>');
		
		// LOADING THE AJAX MODAL
		jQuery('#modal_view_ajax').modal('show', {backdrop: 'true'});
		
		// SHOW AJAX RESPONSE ON REQUEST SUCCESS
		$.ajax({
			url: url,
			success: function(response)
			{
				jQuery('#modal_view_ajax .modal-body').html(response);
			}
		});
	}
</script>


<!-- View Modal Start-->
<div class="modal fade effect-scale" id="modal_view_ajax" role="dialog">
	<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header tx-uppercase">
				<h5 class="modal-title"><?= $this->lang->line('view');?> <?= $page_name;?> <?= $this->lang->line('notes');?></h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <i data-feather="x"></i> </button>
			</div>
			<div class="modal-body form pd-y-20">
				
			</div>
		</div>
	</div>
</div>
<!--/ View Modal End-->