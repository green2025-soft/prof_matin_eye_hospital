					
			</div>
			<!--/ Page Content End -->
		</div>
		<!--/ Page Container End -->
      
		<!-- Scroll To Top Start-->
		<!--================================-->	
		<a href="javascript:void(0);" data-click="scroll-top" class="btn-scroll-top fade"><i class="fa fa-arrow-up"></i></a>
		<!--/ Scroll To Top End -->

		<!-- Footer Script -->
		<!--================================-->
		<!-- <script src="<?= base_url('');?>assets/plugins/jquery/jquery.min.js"></script>
		<script src="<?= base_url('');?>assets/plugins/jquery-ui/jquery-ui.js"></script>
		<script src="<?= base_url('');?>assets/plugins/moment/moment.min.js"></script>
		<script src="<?= base_url('');?>assets/plugins/popper/popper.js"></script>
		<script src="<?= base_url('');?>assets/plugins/feather/feather.min.js"></script>
		<script src="<?= base_url('');?>assets/plugins/bootstrap/js/bootstrap.min.js"></script>
		<script src="<?= base_url('');?>assets/plugins/typeahead/typeahead.js"></script>
		<script src="<?= base_url('');?>assets/plugins/typeahead/typeahead-active.js"></script>
		<script src="<?= base_url('');?>assets/plugins/pace/pace.min.js"></script>
		<script src="<?= base_url('');?>assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>
		<script src="<?= base_url('');?>assets/plugins/highlight/highlight.min.js"></script>
		<script src="<?= base_url('');?>assets/plugins/prism/prism.js"></script>
		<script src="<?= base_url('');?>assets/plugins/select2/js/select2.min.js"></script> -->
		<script>
			$(function() {
				$('.select2-data').each(function() {
					$(this)
					.wrap('<div class="position-relative"></div>')
					.select2({
					placeholder: 'Select value',
					dropdownParent: $(this).parent()
					});
				})
			});
		</script><!-- Javascript -->
<!-- / Javascript -->
		<!-- <script src="<?= base_url('');?>assets/plugins/summernote/summernote.min.js"></script> -->
<script>
$('#textarea').summernote({
 placeholder: ' ',
 tabsize: 2,
 height: 150
});
</script>
		<!-- <script src="<?= base_url('');?>assets/plugins/jstree/jstree.min.js"></script> -->
		<!-- Dashboard Script -->
		<!-- <script src="<?= base_url('');?>assets/plugins/daterangepicker/daterangepicker.js"></script>
		<script src="<?= base_url('');?>assets/plugins/jqvmap/jquery-jvectormap-2.0.2.min.js"></script>	
		<script src="<?= base_url('');?>assets/plugins/jqvmap/gdp-data.js"></script>	
		<script src="<?= base_url('');?>assets/plugins/jqvmap/maps/jquery-jvectormap-world-mill-en.js"></script>	
		<script src="<?= base_url('');?>assets/plugins/chartist/chartist.js"></script>
		<script src="<?= base_url('');?>assets/plugins/apex-chart/apexcharts.min.js"></script>
		<script src="<?= base_url('');?>assets/plugins/apex-chart/irregular-data-series.js"></script>
		<script src="<?= base_url('');?>assets/plugins/flot/jquery.flot.js"></script>
		<script src="<?= base_url('');?>assets/plugins/flot/jquery.flot.pie.js"></script>
		<script src="<?= base_url('');?>assets/plugins/flot/jquery.flot.resize.js"></script>
		<script src="<?= base_url('');?>assets/plugins/flot/sampledata.js"></script> -->
		<script>
			! function (e) {
			"<?= $this->lang->line('payment_collection');?>";

			// Annual Report Chat
			var a = {
				chart: {
					height: 300,
					width: '100%',
					type: "line",
					stacked: false,
					fontFamily: "IBM Plex Sans, sans-serif",
					foreColor: "#6780B1",
				},
				stroke: {
					width: [1, 2, 3, 4],
					curve: "smooth"
				},
				plotOptions: {
					bar: {
						columnWidth: '25%'
					}
				},
				colors: ["#FF0000", "#0645AD", "#00CC00", "#DDE405"],
				series: [{
					name: "<?= $this->lang->line('receive_voucher');?>",
					type: "column",
					data: [50, 11, 22, 27, 13, 22, 37, 21, 44, 22, 30, 21]
				}, {
					name: "<?= $this->lang->line('payment_voucher');?>",
					type: "column",
					data: [20, 55, 41, 67, 22, 43, 21, 41, 56, 27, 43, 41]
				}, {
					name: "<?= $this->lang->line('journal_voucher');?>",
					type: "column",
					data: [30, 55, 41, 67, 22, 43, 21, 41, 56, 27, 43, 56]
				}, {
					name: "<?= $this->lang->line('contra_voucher');?>",
					type: "column",
					data: [20, 10, 30, 34, 28, 12, 14, 23, 10, 9, 19, 4]
				}],
				fill: {
					opacity: [0.85, 0.25, 1, 1],
					gradient: {
						inverseColors: false,
						shade: "light",
						type: "vertical",
						opacityFrom: 0.5,
						opacityTo: 0.1,
						stops: [0, 100, 100, 100]
					}
				},
				labels: [ 
				"January-<?= date('Y');?>", "February-<?= date('Y');?>", "March-<?= date('Y');?>", "April-<?= date('Y');?>", "May-<?= date('Y');?>", "June-<?= date('Y');?>", "Jly-<?= date('Y');?>", "August-<?= date('Y');?>",  "September-<?= date('Y');?>", "October-<?= date('Y');?>", "November-<?= date('Y');?>", "December-<?= date('Y');?>",
				],
				markers: {
					size: 0
				},
				xaxis: {
					type: "datetime"
				},
				yaxis: {
					min: 0
				},
				tooltip: {
					shared: true,
					intersect: false,
					y: {
						formatter: function (i) {
							if (typeof i !== "undefined") {
								return i.toFixed(0) + ""
							}
							return i
						}
					}
				},
				legend: {
					labels: {
						useSeriesColors: true
					},
				}
			};
			var e = new ApexCharts(document.querySelector("#payment_collection"), a);
			e.render();
			}(jQuery);
		</script>
		<!-- Required Script -->
		<!-- <script src="<?= base_url('');?>assets/js/app.js"></script>
		<script src="<?= base_url('');?>assets/js/avesta.js"></script>
		
		<script src="<?= base_url('');?>assets/js/avesta-customizer.js"></script> -->
	</body>
</html>