<style>
@page {
	   size: 7in 10.5in;
	   margin: 5px;
	}
</style>
<?php 
	$campus = $this->db->select("*") ->from('campus') ->where('campus_status', 1) ->order_by('campus_id', 'ASC') ->get() ->result();
	foreach ($campus as $campus_row) 
	{
		$campus_name			= $campus_row->campus_name; 
		$campus_address			= $campus_row->campus_address;
		$campus_phone			= $campus_row->campus_phone; 
		$campus_fax				= $campus_row->campus_fax;
		$campus_email			= $campus_row->campus_email;
		$campus_website			= $campus_row->campus_website; 
		$currency				= $campus_row->campus_currency; 
		$campus_logo			= $campus_row->campus_logo;
	}
	
	if($general_ledger > 0) {
	$general_ledger_query =  $this->db->select("*")
	->from('chart_of_accounts')
	->where('chart_of_accounts_id', $general_ledger)
	->order_by('chart_of_accounts_id', 'ASC') 
	->get()
	->result();
	} else {
	$general_ledger_query =  $this->db->select("*")
	->from('chart_of_accounts')
	->where('chart_of_accounts_id', $control_group)
	->order_by('chart_of_accounts_id', 'ASC') 
	->get()
	->result();	
	}
	foreach($general_ledger_query as $general_ledger_row)
	{
	$general_ledger_code = $general_ledger_row->chart_of_accounts_code;
	$general_ledger_name = $general_ledger_row->chart_of_accounts_name;
	}
?> 
<body onload="window.print();">
	<div class="col-md-12 mg-t-5">
		
		<div class="tx-center">
			<img src="<?= base_url("$campus_logo");?>" alt="" width="50"><br/>
			
			<h5 class="tx-uppercase"><?= $campus_name;?></h5>
			<p class="tx-uppercase "><?= $campus_address;?></p>
			
			<h6 class="tx-uppercase tx-underline  tx-bold"><?= $page_name;?></h6>
			<p class="tx-uppercase  d-print-none"><?= $general_ledger_name;?> (<?= $general_ledger_code;?>)</p>
			<p class="tx-uppercase "><?= $this->lang->line('from_the_date_of');?> <?= date('d/m/Y', strtotime($starting_date));?> <?= $this->lang->line('to');?> <?= date('d/m/Y', strtotime($closing_date));?><br/><?= $this->lang->line('print_date');?> <?= date('d/m/Y h:i A');?></p>
		</div>
		
		<?php echo $this->accounts_model->general_ledger_print($accounts_type, $accounts_category, $control_group, $general_ledger, $starting_date, $closing_date);?>
	</div>
</body>