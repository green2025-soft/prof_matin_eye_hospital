<?php foreach($chart_of_accounts_edit as $row){?>
<div id="from_info">
	<form method="post" id="insert">
	<div class="form-row">
		<div class="col-md-6">
			<label for="label"><?= $this->lang->line('accounts_code');?> *</label>
			<input type="hidden" class="form-control form-control-sm bd-danger" id="chart_of_accounts_id" name="chart_of_accounts_id" value="<?= $row->chart_of_accounts_id;?>"required>
			<input type="text" class="form-control form-control-sm bd-danger" id="chart_of_accounts_code" name="chart_of_accounts_code" value="<?= $row->chart_of_accounts_code;?>"required>
		</div>
		<div class="col-md-6">
			<label for="label"><?= $this->lang->line('accounts_name');?> *</label>
			<input type="text" class="form-control form-control-sm bd-danger" id="chart_of_accounts_name" name="chart_of_accounts_name" value="<?= $row->chart_of_accounts_name;?>"required>
		</div>
	</div><br/>

	<div class="form-row">
	</div><br/> 
	<div class="form-row">
		<div class="col-md-6">
			<label for="label"><?= $this->lang->line('status');?> *</label>
			<select class="form-control form-control-sm bd-danger" id="chart_of_accounts_status" name="chart_of_accounts_status"required>
				<?php 
				$status =  $this->db->select("*") ->from('status') ->order_by('status_id', 'DESC') ->get() ->result();
				foreach($status as $status_row) {?>
				<option value="<?= $status_row->status_id;?>"<?php if($status_row->status_id == "$row->chart_of_accounts_status"){echo 'selected';}?>><?= $status_row->status_name;?></option>
				<?php }?>
			</select>
		</div>
		
		<div class="col-md-6">
			<label for="label"><?= $this->lang->line('links');?></label>
			<select class="form-control form-control-sm bd-danger" id="chart_of_accounts_link" name="chart_of_accounts_link">
				<option value="">No Links</option>
				<?php 
				$accounts_link =  $this->db->select("*") ->from('accounts_link') ->order_by('accounts_link_name', 'ASC') ->get() ->result();
				foreach($accounts_link as $accounts_link_row) {?>
				<option value="<?= $accounts_link_row->accounts_link_id;?>"<?php if($accounts_link_row->accounts_link_id == "$row->chart_of_accounts_link"){echo 'selected';}?>><?= $accounts_link_row->accounts_link_name;?></option>
				<?php }?>
			</select>
		</div>
	</div>

	<div class="modal-footer">
	  <button type="submit" class="btn btn-outline-info tx-uppercase"><?= $this->lang->line('update');?></button>
	  <button type="button" class="btn btn-outline-danger tx-uppercase" data-dismiss="modal"><?= $this->lang->line('closed');?></button>
	</div>
	</form>
</div>
<?php }?>

<script>
	$(document).ready(function(){
		$('#insert').submit(function(e){
		e.preventDefault(); 
			 $.ajax({
				url:"<?= base_url('accounts/chart_of_accounts_update');?>",
				type:"post",
				data:new FormData(this),
				processData:false,
				contentType:false,
				cache:false,
				async:false,
				success: function(data)
				{
					$('#from_info').html(data);
				}
			 });
		}); 
	});
</script>