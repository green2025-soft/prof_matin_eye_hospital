<!-- Page Inner Start --> 
<div class="page-inner" style="margin-bottom:80px;">
	<!-- Main Wrapper -->
	<div id="main-wrapper"> 
		<!-- Breadcrumb Start --> 
		<div class="pageheader pd-t-10 pd-b-10">
			<div class="d-flex justify-content-between">
				<div class="clearfix tx-uppercase">
					<div class="pd-t-5 pd-b-5">
					  <h2 class="pd-0 mg-0 tx-18 tx-dark"><?= $page_name;?></h2>
					</div>
					<div class="breadcrumb pd-0 mg-0">
						<a class="breadcrumb-item" href="<?= base_url('./login');?>"><i class="fa fa-dashboard"></i> <?= $this->lang->line('dashboard');?></a> /
						<span class="breadcrumb-item active"><?= $page_name;?></span>
					</div>
				</div>
			</div>
		</div>
		<!--/ Breadcrumb End -->
	  
		<!-- Articles Start -->
		<div class="card mg-b-30"> 
			
			<div class="col-md-12">
				<div class="form-row mg-t-10">
					<div class="col-md-3 col-sm-12">
						<label for="label"><?= $this->lang->line('voucher_number');?></label>
						<input type="text" class="form-control form-control-sm bd-danger tx-center tx-uppercase" id="voucher_number" name="voucher_number" autofocus="on" placeholder="<?= $this->lang->line('enter_voucher_number');?>"required>
					</div>
					<div class="col-md-3 col-sm-12">
						<label for="label"><?= $this->lang->line('date');?> <?= $this->lang->line('from');?> *</label> 
						<input type="date" class="form-control form-control-sm bd-danger search_datepicker" id="posting_from_date" name="posting_from_date" value="<?= date('Y-m-d');?>" required>
					</div>
					<div class="col-md-3 col-sm-12">
						<label for="label"><?= $this->lang->line('date');?> <?= $this->lang->line('to');?> *</label> 
						<input type="date" class="form-control form-control-sm bd-danger search_datepicker" id="posting_to_date" name="posting_to_date" value="<?= date('Y-m-d');?>" required>
					</div>
					<div class="col-md-3 col-sm-12">
						<label for="label">&nbsp;</label>
						<button type="button" id="search" class="btn btn-brand  btn-block tx-uppercase"><i class="fa fa-search"></i> <?= $this->lang->line('search');?></button>
					</div>
				</div>
			</div>
			<div class="col-md-12">
				<div class="table-responsive">
					<table class="table table-bordered table-hover mt-5">
						<thead class="tx-10 tx-uppercase">
							<tr> 
								<th class="tx-center"><?= $this->lang->line('sl_no');?></th>
								<th class="tx-center"><?= $this->lang->line('posting_date');?></th>
								<th class="tx-center"><?= $this->lang->line('voucher_type');?></th>
								<th class="tx-center"><?= $this->lang->line('voucher_number');?></th>
								<th class="tx-center"><?= $this->lang->line('narration');?></th>
								<th class="tx-center"><?= $this->lang->line('debit');?></th>
								<th class="tx-center"><?= $this->lang->line('credit');?></th>
								<th class="tx-center d-print-none"><?= $this->lang->line('option');?></th>
							</tr>
						</thead>
						<tbody id="voucher_number_info">
						</tbody>
					</table>
				</div>
			</div>
			<script>
				$(document).ready(function(){
					$('#search').click(function(){
					  var voucher_number = $('#voucher_number').val();
					  var posting_from_date = $('#posting_from_date').val();
					  var posting_to_date = $('#posting_to_date').val(); 
					  if(voucher_number != '') 
					  {
					   $.ajax({
						url:"<?= base_url('accounts/get_voucher_number_search');?>",
						beforeSend: function() {
							$('#voucher_number_info').html('<tr class="tx-center tx-uppercase"><th colspan="8"><img src="<?= base_url("assets/images/loading/loader.gif");?>"/><h6 class="tx-center tx-uppercase tx-13 tx-bold"><?= $this->lang->line("loading");?></h6></th></tr>');
						},
						method:"POST",
						data:{voucher_number:voucher_number, posting_from_date:posting_from_date, posting_to_date:posting_to_date},
						success:function(data)
						{
						 $('#voucher_number_info').html(data);
						}
					   });
					  }
					  else
					  {
					   $('#voucher_number_info').html('<tr><th class="tx-center tx-uppercase" colspan="8"><?= $this->lang->line("data_searching_error");?></th></tr>');
					  }
					});
				}); 
			</script>
		</div>
		<!--/ Articles End -->				  
   </div>
   <!--/ Main Wrapper End -->
</div>
<!--/ Page Inner End -->

<script type="text/javascript">
	function action_view_model(url)
	{
		// SHOWING AJAX PRELOADER IMAGE
		//jQuery('#exampleModal .modal-body').html('<div style="text-align:center; margin-top:20px;"><img src="<?php echo base_url("assets/images/loading/loader.gif");?>" /></div>');
		
		// LOADING THE AJAX MODAL
		jQuery('#exampleModal').modal('show', {backdrop: 'true'});
		
		// SHOW AJAX RESPONSE ON REQUEST SUCCESS
		$.ajax({
			url: url,
			success: function(response)
			{
				jQuery('#exampleModal .modal-body').html(response);
			}
		});
	}
	
	function action_delete_modal(delete_url)
	{
		jQuery('#modal-delete').modal('show', {backdrop: 'static'});
		document.getElementById('delete_link').setAttribute('href' , delete_url);
	}
</script>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"><?= $page_name;?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        ...
      </div>
      <!-- <div class="modal-footer">
        
		
       <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div> -->
    </div>
  </div>
</div>

<!-- Add / Edit Modal Start-->
<div class="modal fade effect-scale" id="modal_view_ajax" role="dialog">
	<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header tx-uppercase">
				<h5 class="modal-title"><?= $this->lang->line('view');?> <?= $page_name;?></h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <i data-feather="x"></i> </button>
			</div>
			<div class="modal-body form pd-y-20">
				
			</div>
		</div>
	</div>
</div>
<!--/ Add / Edit Modal End-->

<!-- (Delete Modal)-->
<div class="modal fade" id="modal-delete">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header tx-uppercase">  
				<h5 class="modal-title"><?= $this->lang->line('model_delete_warning');?></h5>
			</div>
			<div class="modal-footer" style="margin:0px; border-top:0px; text-align:center;">
				<a href="javascript:void(0)" class="btn btn-outline-danger rounded-pill" id="delete_link" title="<?= $this->lang->line('yeas');?>"><i class="fa fa-check"></i></a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
				<button type="button" class="btn btn-outline-danger rounded-pill" data-dismiss="modal" title="<?= $this->lang->line('no');?>"><i class="fa fa-remove"></i></button>
			</div>
		</div>
	</div>
</div>
<!-- (Delete Modal)-->