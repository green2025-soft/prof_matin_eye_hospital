<style>
@page {
	   size: 7in 10.5in;
	   margin: 5px;
	}
</style>
<?php 
	$campus = $this->db->select("*") ->from('campus') ->where('campus_status', 1) ->order_by('campus_id', 'ASC') ->get() ->result();
	foreach ($campus as $campus_row) 
	{
		$campus_name			= $campus_row->campus_name; 
		$campus_address			= $campus_row->campus_address;
		$campus_phone			= $campus_row->campus_phone; 
		$campus_fax				= $campus_row->campus_fax;
		$campus_email			= $campus_row->campus_email;
		$campus_website			= $campus_row->campus_website; 
		$currency				= $campus_row->campus_currency; 
		$campus_logo					= $campus_row->campus_logo;
	}
?> 
<body onload="window.print();">
	<div class="col-md-12 mg-t-5">
		
		<div class="tx-center">
			<img src="<?= base_url("$campus_logo");?>" alt="" width="50"><br/>
			
			<h5 class="tx-uppercase"><?= $campus_name;?></h5>
			<p class="tx-uppercase "><?= $campus_address;?></p>
			
			<h6 class="tx-uppercase tx-underline tx-bold"><?= $page_name;?></h6>
			
			<p class="tx-uppercase"><?= $this->lang->line('at_the_end_of');?> <?= date('jS F, Y', strtotime($posting_to_date));?><br/><?= $this->lang->line('print_date');?> <?= date('d/m/Y h:i A');?></p>
		</div>
		<table class="table table-bordered table-hover">
			<thead class="tx-uppercase">
				<tr>
					<th class="tx-center"><?= $this->lang->line('accounts_code');?></th>
					<th class="tx-center"><?= $this->lang->line('head_of_accounts');?></th>
					<th class="tx-center"><?= $this->lang->line('debit');?></th>
					<th class="tx-center"><?= $this->lang->line('credit');?></th>
				</tr>
			</thead>
			<tbody>
				<?= $this->accounts_model->trial_balance($posting_to_date);?>
			</tbody>
		</table>
		
		
		
		<br/><br/><br/><br/><br/>
		
		<table class="" width="100%" align="center">  
			<tr class="tx-uppercase">
				<th width="30%" class="text-center bd-top"><?= $this->lang->line('prepared_by');?></th>
				<th width="5%"></th>
				<th width="30%" class="text-center bd-top"><?= $this->lang->line('checked_by');?></th>
				<th width="5%"></th>
				<th width="30%" class="text-center bd-top"><?= $this->lang->line('authorised');?></th>
			</tr>
		</table>
	</div>
</body>