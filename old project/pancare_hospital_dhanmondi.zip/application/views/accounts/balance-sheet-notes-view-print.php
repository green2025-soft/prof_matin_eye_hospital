<style>
@page {
	   size: 7in 10.5in;
	   margin: 5px;
	}
</style>
	<?php 
	$campus = $this->db->select("*") ->from('campus') ->where('campus_status', 1) ->order_by('campus_id', 'ASC') ->get() ->result();
	foreach ($campus as $campus_row) 
	{
		$campus_name			= $campus_row->campus_name; 
		$campus_address			= $campus_row->campus_address;
		$campus_phone			= $campus_row->campus_phone; 
		$campus_fax				= $campus_row->campus_fax;
		$campus_email			= $campus_row->campus_email;
		$campus_website			= $campus_row->campus_website; 
		$currency				= $campus_row->campus_currency; 
		$campus_logo			= $campus_row->campus_logo;
	}
	// Current Month Date Calculation ..
	$current_month_start_date = date('2015-01-01');
	$current_month_end_date =  date('Y-m-t', strtotime($closing_month));
	
	// Last Month Date Calculation .		
	$last_month_start_date	= date('2015-01-01');
	$last_month_end_date	= date('Y-m-t', strtotime($closing_month. "last month"));
	
	// Previous Month Date Calculation ..
	$previous_month_start_date	= date('2015-01-01');
	$previous_month_end_date	= date('Y-m-t', strtotime($closing_month. "last month". "last month"));
	
	// Current Year Date Calculation ..
	if (date('m', strtotime($closing_month)) < '07') {
	$current_year_start			= date('Y', strtotime($closing_month. "last year"));
	$current_year_end			= date('y', strtotime($closing_month));
	$current_year_start_date	= date('2015-01-01');
	$current_year_end_date		= date('Y-06-30', strtotime($closing_month));
	} else {
	$current_year_start			= date('Y', strtotime($closing_month));
	$current_year_end			= date('y', strtotime($closing_month. "+1 year"));
	$current_year_start_date	= date('2015-01-01');
	$current_year_end_date		= date('Y-06-30', strtotime($closing_month. "+1 year"));
	} 
	
	// last Year Date Calculation ..
	if (date('m', strtotime($closing_month)) < '07') { 
	$last_year_start		= date('Y', strtotime($closing_month. "last year". "last year"));
	$last_year_end			= date('y', strtotime($closing_month. "last year"));
	
	$last_year_start_date	= date('2015-01-01');
	$last_year_end_date		= date('Y-06-30', strtotime($closing_month. "last year"));
	} else { 
	$last_year_start		= date('Y', strtotime($closing_month. "last year"));
	$last_year_end			= date('y', strtotime($closing_month));
	
	$last_year_start_date	= date('2015-01-01');
	$last_year_end_date		= date('Y-06-30', strtotime($closing_month));
	}
	
	// Previous Year Date Calculation ..
	if (date('m', strtotime($closing_month)) < '07') { 
	$previous_year_start		= date('Y', strtotime($closing_month. "last year". "last year". "last year"));
	$previous_year_end			= date('y', strtotime($closing_month. "last year". "last year"));
	$previous_year_start_date	= date('2015-01-01');
	$previous_year_end_date		= date('Y-06-30', strtotime($closing_month. "last year". "last year"));
	} else { 
	$previous_year_start		= date('Y', strtotime($closing_month. "last year". "last year"));
	$previous_year_end			= date('y', strtotime($closing_month. "last year"));
	$previous_year_start_date	= date('2015-01-01');
	$previous_year_end_date		= date('Y-06-30', strtotime($closing_month. "last year"));
	}?>
<body onload="window.print();">
	<div class="col-md-12 mg-t-5">
		<div class="tx-center">
			<img src="<?= base_url("$campus_logo");?>" alt="" width="80"><br/>
			
			<h2 class="tx-uppercase tx-bold"><?= $campus_name;?></h2>
			<p class="tx-uppercase tx-bold"><?= $campus_address;?></p>
			
			<h6 class="tx-uppercase tx-underline tx-bold"><?= $page_name;?></h6>
			
			<p class="tx-uppercase "><?= $this->lang->line('as_on');?> <?= date('t F, Y', strtotime($closing_month));?></p>
		</div><br/>
		
		<table class="table-hover" width="100%" align="center">
			<thead class="tx-uppercase">
				<tr class="table-bordered">  
					<th class="tx-center" rowspan="2" width="31%" colspan="2"><?= $this->lang->line('particulars');?></th> 
					<th class="tx-center" colspan="8"><?= $this->lang->line('amounts');?></th>
				</tr>
				<tr class="table-bordered">  
					<th class="tx-center" colspan="2" width="11%">
						<?= date('M-y', strtotime($closing_month));?>
					</th>
					<th class="tx-center" colspan="2" width="11%">
						<?= date('M-y', strtotime($closing_month. "last month"));?>
					</th>
					<th class="tx-center" colspan="2" width="11%">
						Jun-<?= $last_year_end;?>
					</th>
					<th class="tx-center d-print-none" colspan="2" width="12%">
						Jun-<?= $previous_year_end;?>
					</th>
				</tr>
			</thead>
			<tbody>
			<?php if($type == 'assets') {?>
			<?php 
			$serial = $note;
			$control_group_aseets = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_id', $coa) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
			foreach ($control_group_aseets as $control_group_aseets_row) {?>
			<tr>
				<th class="tx-left" width="3%"><?= number_format(+$serial,2 . '');?></th>
				<th class="tx-left tx-uppercase" colspan="13"><?= $control_group_aseets_row->chart_of_accounts_code;?> - <?= $control_group_aseets_row->chart_of_accounts_name;?></th>
			</tr>
			<?php 
			$total_current_month_general_ledger_assets = 0.00;
			$total_last_month_general_ledger_assets = 0.00;
			$total_previous_month_general_ledger_assets = 0.00;
			$total_current_year_general_ledger_assets = 0.00;
			$total_last_year_general_ledger_assets = 0.00;
			$total_previous_year_general_ledger_assets = 0.00;
			
			$general_ledger_aseets = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $control_group_aseets_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
			foreach ($general_ledger_aseets as $general_ledger_aseets_row) {?>
			<tr>
				<td></td>
				<td class="tx-left"><?= $general_ledger_aseets_row->chart_of_accounts_code;?> - <?= $general_ledger_aseets_row->chart_of_accounts_name;?></th>
				<?php 
				$general_ledger_current_month_assets = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS general_ledger_current_month_assets_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
				->where('accounts_details_general_ledger', $general_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($general_ledger_current_month_assets as $general_ledger_current_month_assets_row)
				{
				$general_ledger_current_month_assets_balance = $general_ledger_current_month_assets_row->general_ledger_current_month_assets_balance;
				$total_current_month_general_ledger_assets	+= $general_ledger_current_month_assets_balance;
				?>			
				<td class="tx-center" width="1%"></td>
				<td class="tx-right"><?php if ($general_ledger_current_month_assets_balance >0) { echo' '.number_format($general_ledger_current_month_assets_balance, 2 . '').' ';} else if($general_ledger_current_month_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($general_ledger_current_month_assets_balance), 2 . '').') ';} ?></td>
				<?php }?>
				<?php 
				$general_ledger_last_month_assets = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS general_ledger_last_month_assets_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$last_month_start_date.'" and "'.$last_month_end_date.'"')
				->where('accounts_details_general_ledger', $general_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($general_ledger_last_month_assets as $general_ledger_last_month_assets_row)
				{
				$general_ledger_last_month_assets_balance = $general_ledger_last_month_assets_row->general_ledger_last_month_assets_balance;
				$total_last_month_general_ledger_assets	+= $general_ledger_last_month_assets_balance;
				?>			
				<td class="tx-center" width="1%"></td>
				<td class="tx-right"><?php if ($general_ledger_last_month_assets_balance >0) { echo' '.number_format($general_ledger_last_month_assets_balance, 2 . '').' ';} else if($general_ledger_last_month_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($general_ledger_last_month_assets_balance), 2 . '').') ';} ?></td>
				<?php }?>
				
				<?php 
				$general_ledger_last_year_assets = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS general_ledger_last_year_assets_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
				->where('accounts_details_general_ledger', $general_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($general_ledger_last_year_assets as $general_ledger_last_year_assets_row)
				{
				$general_ledger_last_year_assets_balance = $general_ledger_last_year_assets_row->general_ledger_last_year_assets_balance;
				$total_last_year_general_ledger_assets	+= $general_ledger_last_year_assets_balance;
				?>			
				<td class="tx-center" width="1%"></td>
				<td class="tx-right"><?php if ($general_ledger_last_year_assets_balance >0) { echo' '.number_format($general_ledger_last_year_assets_balance, 2 . '').' ';} else if($general_ledger_last_year_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($general_ledger_last_year_assets_balance), 2 . '').') ';} ?></td>
				<?php }?>
				<?php 
				$general_ledger_previous_year_assets = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS general_ledger_previous_year_assets_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_year_start_date.'" and "'.$previous_year_end_date.'"')
				->where('accounts_details_general_ledger', $general_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($general_ledger_previous_year_assets as $general_ledger_previous_year_assets_row)
				{
				$general_ledger_previous_year_assets_balance = $general_ledger_previous_year_assets_row->general_ledger_previous_year_assets_balance;
				$total_previous_year_general_ledger_assets	+= $general_ledger_previous_year_assets_balance;
				?>			
				<td class="tx-center " width="1%"></td>
				<td class="tx-right "><?php if ($general_ledger_previous_year_assets_balance >0) { echo' '.number_format($general_ledger_previous_year_assets_balance, 2 . '').' ';} else if($general_ledger_previous_year_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($general_ledger_previous_year_assets_balance), 2 . '').') ';} ?></td>
				<?php }?>
			</tr>
			<?php }?>
			<tr class="tx-uppercase">
				<th class="tx-right" colspan="2"><?= $this->lang->line('total');?></th>
				<th class="tx-center" width="1%"></th>
				<th class="tx-right bd-bottom-double bd-top"><?php if ($total_current_month_general_ledger_assets >0) { echo' '.number_format($total_current_month_general_ledger_assets, 2 . '').' ';} else if($total_current_month_general_ledger_assets ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_month_general_ledger_assets), 2 . '').') ';} ?></th>
				<th class="tx-center" width="1%"></th>
				<th class="tx-right bd-bottom-double bd-top"><?php if ($total_last_month_general_ledger_assets >0) { echo' '.number_format($total_last_month_general_ledger_assets, 2 . '').' ';} else if($total_last_month_general_ledger_assets ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_month_general_ledger_assets), 2 . '').') ';} ?></th>
				<th class="tx-center" width="1%"></th>
				<th class="tx-right bd-bottom-double bd-top"><?php if ($total_last_year_general_ledger_assets >0) { echo' '.number_format($total_last_year_general_ledger_assets, 2 . '').' ';} else if($total_last_year_general_ledger_assets ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_year_general_ledger_assets), 2 . '').') ';} ?></th>
				<th class="tx-center " width="1%"></th>
				<th class="tx-right  bd-bottom-double bd-top"><?php if ($total_previous_year_general_ledger_assets >0) { echo' '.number_format($total_previous_year_general_ledger_assets, 2 . '').' ';} else if($total_previous_year_general_ledger_assets ==0) {echo '-';} else { echo' ('.number_format(abs($total_previous_year_general_ledger_assets), 2 . '').') ';} ?></th>
			</tr>
			
			<tr>
				<th class="tx-center" width="3%">&nbsp;</th>
				<th class="tx-left tx-uppercase" colspan="13"></th>
			</tr>
			
			<?php  
			$serial_assets = 0; 
			$general_ledger_aseets = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $control_group_aseets_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
			foreach ($general_ledger_aseets as $general_ledger_aseets_row) {?>
			<tr>
				<th class="tx-left" width="3%"><?= number_format($serial,0 . '');?>.<?= number_format(++$serial_assets,1 . '');?></th>
				<th class="tx-left tx-uppercase" colspan="13"><?= $general_ledger_aseets_row->chart_of_accounts_code;?> - <?= $general_ledger_aseets_row->chart_of_accounts_name;?></th>
			</tr>
			<?php 
			
			$total_current_month_subsidiary_ledger_assets = 0.00;
			$total_last_month_subsidiary_ledger_assets = 0.00;
			$total_previous_month_subsidiary_ledger_assets = 0.00;
			$total_current_year_subsidiary_ledger_assets = 0.00;
			$total_last_year_subsidiary_ledger_assets = 0.00;
			$total_previous_year_subsidiary_ledger_assets = 0.00;
			$subsidiary_ledger_aseets = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $general_ledger_aseets_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
			foreach ($subsidiary_ledger_aseets as $subsidiary_ledger_aseets_row) {?>
			<tr>
				<td></td>
				<td class="tx-left"><?= $subsidiary_ledger_aseets_row->chart_of_accounts_code;?> - <?= $subsidiary_ledger_aseets_row->chart_of_accounts_name;?></th>
				<?php 
				$subsidiary_ledger_current_month_assets = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS subsidiary_ledger_current_month_assets_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
				->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($subsidiary_ledger_current_month_assets as $subsidiary_ledger_current_month_assets_row)
				{
				$subsidiary_ledger_current_month_assets_balance = $subsidiary_ledger_current_month_assets_row->subsidiary_ledger_current_month_assets_balance;
				$total_current_month_subsidiary_ledger_assets	+= $subsidiary_ledger_current_month_assets_balance;
				?>			
				<td class="tx-center" width="1%"></td>
				<td class="tx-right"><?php if ($subsidiary_ledger_current_month_assets_balance >0) { echo' '.number_format($subsidiary_ledger_current_month_assets_balance, 2 . '').' ';} else if($subsidiary_ledger_current_month_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($subsidiary_ledger_current_month_assets_balance), 2 . '').') ';} ?></td>
				<?php }?>

				<?php 
				$subsidiary_ledger_last_month_assets = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS subsidiary_ledger_last_month_assets_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$last_month_start_date.'" and "'.$last_month_end_date.'"')
				->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($subsidiary_ledger_last_month_assets as $subsidiary_ledger_last_month_assets_row)
				{
				$subsidiary_ledger_last_month_assets_balance = $subsidiary_ledger_last_month_assets_row->subsidiary_ledger_last_month_assets_balance;
				$total_last_month_subsidiary_ledger_assets	+= $subsidiary_ledger_last_month_assets_balance;
				?>			
				<td class="tx-center" width="1%"></td>
				<td class="tx-right"><?php if ($subsidiary_ledger_last_month_assets_balance >0) { echo' '.number_format($subsidiary_ledger_last_month_assets_balance, 2 . '').' ';} else if($subsidiary_ledger_last_month_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($subsidiary_ledger_last_month_assets_balance), 2 . '').') ';} ?></td>
				<?php }?>
				
				<?php 
				$subsidiary_ledger_last_year_assets = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS subsidiary_ledger_last_year_assets_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
				->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_aseets_row->chart_of_accounts_id)
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($subsidiary_ledger_last_year_assets as $subsidiary_ledger_last_year_assets_row)
				{
				$subsidiary_ledger_last_year_assets_balance = $subsidiary_ledger_last_year_assets_row->subsidiary_ledger_last_year_assets_balance;
				$total_last_year_subsidiary_ledger_assets	+= $subsidiary_ledger_last_year_assets_balance;
				?>			
				<td class="tx-center" width="1%"></td>
				<td class="tx-right"><?php if ($subsidiary_ledger_last_year_assets_balance >0) { echo' '.number_format($subsidiary_ledger_last_year_assets_balance, 2 . '').' ';} else if($subsidiary_ledger_last_year_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($subsidiary_ledger_last_year_assets_balance), 2 . '').') ';} ?></td>
				<?php }?>
				<?php 
				$subsidiary_ledger_previous_year_assets = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS subsidiary_ledger_previous_year_assets_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_year_start_date.'" and "'.$previous_year_end_date.'"')
				->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($subsidiary_ledger_previous_year_assets as $subsidiary_ledger_previous_year_assets_row)
				{
				$subsidiary_ledger_previous_year_assets_balance = $subsidiary_ledger_previous_year_assets_row->subsidiary_ledger_previous_year_assets_balance;
				$total_previous_year_subsidiary_ledger_assets	+= $subsidiary_ledger_previous_year_assets_balance;
				?>			
				<td class="tx-center " width="1%"></td>
				<td class="tx-right "><?php if ($subsidiary_ledger_previous_year_assets_balance >0) { echo' '.number_format($subsidiary_ledger_previous_year_assets_balance, 2 . '').' ';} else if($subsidiary_ledger_previous_year_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($subsidiary_ledger_previous_year_assets_balance), 2 . '').') ';} ?></td>
				<?php }?>
			<?php }?>
			</tr>
			<tr class="tx-uppercase">
				<th class="tx-right" colspan="2"><?= $this->lang->line('total');?></th>
				<th class="tx-center" width="1%"></th>
				<th class="tx-right bd-bottom-double bd-top"><?php if ($total_current_month_subsidiary_ledger_assets >0) { echo' '.number_format($total_current_month_subsidiary_ledger_assets, 2 . '').' ';} else if($total_current_month_subsidiary_ledger_assets ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_month_subsidiary_ledger_assets), 2 . '').') ';} ?></th>
				<th class="tx-center" width="1%"></th>
				<th class="tx-right bd-bottom-double bd-top"><?php if ($total_last_month_subsidiary_ledger_assets >0) { echo' '.number_format($total_last_month_subsidiary_ledger_assets, 2 . '').' ';} else if($total_last_month_subsidiary_ledger_assets ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_month_subsidiary_ledger_assets), 2 . '').') ';} ?></th>
				<th class="tx-center" width="1%"></th>
				<th class="tx-right bd-bottom-double bd-top"><?php if ($total_last_year_subsidiary_ledger_assets >0) { echo' '.number_format($total_last_year_subsidiary_ledger_assets, 2 . '').' ';} else if($total_last_year_subsidiary_ledger_assets ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_year_subsidiary_ledger_assets), 2 . '').') ';} ?></th>
				<th class="tx-center " width="1%"></th>
				<th class="tx-right  bd-bottom-double bd-top"><?php if ($total_previous_year_subsidiary_ledger_assets >0) { echo' '.number_format($total_previous_year_subsidiary_ledger_assets, 2 . '').' ';} else if($total_previous_year_subsidiary_ledger_assets ==0) {echo '-';} else { echo' ('.number_format(abs($total_previous_year_subsidiary_ledger_assets), 2 . '').') ';} ?></th>
			</tr>
			<?php } ?>
			<?php }?>
			
			<?php } else if($type == 'funds'){?>
			<?php 
			// Income .... 
			$accounts_type_income = $this->db->select("*") ->from('accounts_type') ->where('accounts_type_id', 300000) ->order_by('accounts_type_code', 'ASC') ->get()->result();
			foreach ($accounts_type_income as $accounts_type_income_row)
			{
				$total_current_month_income = 0.00;
				$total_last_month_income = 0.00;
				$total_previous_month_income = 0.00;
				$total_current_year_income = 0.00;
				$total_last_year_income = 0.00;
				$total_previous_year_income = 0.00;
				
				$accounts_category_income = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_type_income_row->accounts_type_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
				foreach ($accounts_category_income as $accounts_category_income_row) 
				{
					$current_month_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_month_income_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_income_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($current_month_income as $current_month_income_row)
					{
					$current_month_income_balance = $current_month_income_row->current_month_income_balance;
					$total_current_month_income  += $current_month_income_balance;
					}
					
					$last_month_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS last_month_income_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$last_month_start_date.'" and "'.$last_month_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_income_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($last_month_income as $last_month_income_row)
					{
					$last_month_income_balance = $last_month_income_row->last_month_income_balance;
					$total_last_month_income  += $last_month_income_balance;
					}
					
					$last_year_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS last_year_income_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_income_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($last_year_income as $last_year_income_row)
					{
					$last_year_income_balance = $last_year_income_row->last_year_income_balance;
					$total_last_year_income  += $last_year_income_balance;
					}
					
					$previous_year_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS previous_year_income_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_year_start_date.'" and "'.$previous_year_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_income_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($previous_year_income as $previous_year_income_row)
					{
					$previous_year_income_balance = $previous_year_income_row->previous_year_income_balance;
					$total_previous_year_income  += $previous_year_income_balance;
					}
				} 
			}
			
			// expenditure .. 
			$accounts_type_expenditure = $this->db->select("*") ->from('accounts_type') ->where('accounts_type_id', 400000) ->order_by('accounts_type_code', 'ASC') ->get()->result();
			foreach ($accounts_type_expenditure as $accounts_type_expenditure_row)
			{
				$total_current_month_expenditure = 0.00;
				$total_last_month_expenditure = 0.00;
				$total_previous_month_expenditure = 0.00;
				$total_current_year_expenditure = 0.00;
				$total_last_year_expenditure = 0.00;
				$total_previous_year_expenditure = 0.00;
				
				$accounts_category_expenditure = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_type_expenditure_row->accounts_type_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
				foreach ($accounts_category_expenditure as $accounts_category_expenditure_row)
				{
					$current_month_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_month_expenditure_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($current_month_expenditure as $current_month_expenditure_row)
					{
					$current_month_expenditure_balance = $current_month_expenditure_row->current_month_expenditure_balance;
					$total_current_month_expenditure  += $current_month_expenditure_balance;
					}
					
					$last_month_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS last_month_expenditure_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$last_month_start_date.'" and "'.$last_month_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($last_month_expenditure as $last_month_expenditure_row)
					{
					$last_month_expenditure_balance = $last_month_expenditure_row->last_month_expenditure_balance;
					$total_last_month_expenditure  += $last_month_expenditure_balance;
					}
					
					$last_year_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS last_year_expenditure_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($last_year_expenditure as $last_year_expenditure_row)
					{
					$last_year_expenditure_balance = $last_year_expenditure_row->last_year_expenditure_balance;
					$total_last_year_expenditure  += $last_year_expenditure_balance;
					}
					
					$previous_year_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS previous_year_expenditure_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_year_start_date.'" and "'.$previous_year_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($previous_year_expenditure as $previous_year_expenditure_row)
					{
					$previous_year_expenditure_balance = $previous_year_expenditure_row->previous_year_expenditure_balance;
					$total_previous_year_expenditure  += $previous_year_expenditure_balance;
					}  
				} 
			} 
			$total_current_month_general_ledger_surplus_deficit		= $total_current_month_income - $total_current_month_expenditure;
			$total_last_month_general_ledger_surplus_deficit		= $total_last_month_income - $total_last_month_expenditure;
			$total_last_year_general_ledger_surplus_deficit			= $total_last_year_income - $total_last_year_expenditure;
			$total_previous_year_general_ledger_surplus_deficit		= $total_previous_year_income - $total_previous_year_expenditure;
			
			$total_current_month_subsidiary_ledger_surplus_deficit	= $total_current_month_income - $total_current_month_expenditure;
			$total_last_month_subsidiary_ledger_surplus_deficit		= $total_last_month_income - $total_last_month_expenditure;
			$total_last_year_subsidiary_ledger_surplus_deficit		= $total_last_year_income - $total_last_year_expenditure;
			$total_previous_year_subsidiary_ledger_surplus_deficit	= $total_previous_year_income - $total_previous_year_expenditure;
			?>
			
			<?php 
			// Funds & Liabilities .......
			$serial = $note;
			$control_group_aseets = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_id', $coa) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
			foreach ($control_group_aseets as $control_group_aseets_row) {?>
			<tr>
				<th class="tx-left" width="3%"><?= number_format(+$serial,2 . '');?></th>
				<th class="tx-left tx-uppercase" colspan="13"><?= $control_group_aseets_row->chart_of_accounts_code;?> - <?= $control_group_aseets_row->chart_of_accounts_name;?></th>
			</tr>
			<?php 
			$total_current_month_general_ledger_fund_liabilities = 0.00;
			$total_last_month_general_ledger_fund_liabilities = 0.00;
			$total_previous_month_general_ledger_fund_liabilities = 0.00;
			$total_current_year_general_ledger_fund_liabilities = 0.00;
			$total_last_year_general_ledger_fund_liabilities = 0.00;
			$total_previous_year_general_ledger_fund_liabilities = 0.00;
			
			$general_ledger_aseets = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $control_group_aseets_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
			foreach ($general_ledger_aseets as $general_ledger_aseets_row) {?>
			<tr>
				<td></td>
				<td class="tx-left"><?= $general_ledger_aseets_row->chart_of_accounts_code;?> - <?= $general_ledger_aseets_row->chart_of_accounts_name;?></th>
				<?php 
				$general_ledger_current_month_fund_liabilities = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS general_ledger_current_month_fund_liabilities_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
				->where('accounts_details_general_ledger', $general_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($general_ledger_current_month_fund_liabilities as $general_ledger_current_month_fund_liabilities_row)
				{
				if ( $general_ledger_aseets_row->chart_of_accounts_general_ledger_balance_sheet_show == 1) {	
				$general_ledger_current_month_fund_liabilities_balance = $general_ledger_current_month_fund_liabilities_row->general_ledger_current_month_fund_liabilities_balance + $total_current_month_general_ledger_surplus_deficit;
				
				} else if ( $general_ledger_aseets_row->chart_of_accounts_general_ledger_balance_sheet_show == 0) {	
				$general_ledger_current_month_fund_liabilities_balance = $general_ledger_current_month_fund_liabilities_row->general_ledger_current_month_fund_liabilities_balance;
				} else { 
				$general_ledger_current_month_fund_liabilities_balance = 0.00;
				}
				$total_current_month_general_ledger_fund_liabilities	+= $general_ledger_current_month_fund_liabilities_balance;
				
				?>			
				<td class="tx-center" width="1%"></td>
				<td class="tx-right"><?php if ($general_ledger_current_month_fund_liabilities_balance >0) { echo' '.number_format($general_ledger_current_month_fund_liabilities_balance, 2 . '').' ';} else if($general_ledger_current_month_fund_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($general_ledger_current_month_fund_liabilities_balance), 2 . '').') ';} ?></td>
				<?php }?>
				<?php 
				$general_ledger_last_month_fund_liabilities = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS general_ledger_last_month_fund_liabilities_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$last_month_start_date.'" and "'.$last_month_end_date.'"')
				->where('accounts_details_general_ledger', $general_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($general_ledger_last_month_fund_liabilities as $general_ledger_last_month_fund_liabilities_row)
				{
				if ( $general_ledger_aseets_row->chart_of_accounts_general_ledger_balance_sheet_show == 1) {	
				$general_ledger_last_month_fund_liabilities_balance = $general_ledger_last_month_fund_liabilities_row->general_ledger_last_month_fund_liabilities_balance + $total_last_month_general_ledger_surplus_deficit;
				
				} else if ( $general_ledger_aseets_row->chart_of_accounts_general_ledger_balance_sheet_show == 0) {	
				$general_ledger_last_month_fund_liabilities_balance = $general_ledger_last_month_fund_liabilities_row->general_ledger_last_month_fund_liabilities_balance;
				} else { 
				$general_ledger_last_month_fund_liabilities_balance = 0.00;
				}
				$total_last_month_general_ledger_fund_liabilities	+= $general_ledger_last_month_fund_liabilities_balance;
				?>			
				<td class="tx-center" width="1%"></td>
				<td class="tx-right"><?php if ($general_ledger_last_month_fund_liabilities_balance >0) { echo' '.number_format($general_ledger_last_month_fund_liabilities_balance, 2 . '').' ';} else if($general_ledger_last_month_fund_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($general_ledger_last_month_fund_liabilities_balance), 2 . '').') ';} ?></td>
				<?php }?>
				
				<?php 
				$general_ledger_last_year_fund_liabilities = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS general_ledger_last_year_fund_liabilities_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
				->where('accounts_details_general_ledger', $general_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($general_ledger_last_year_fund_liabilities as $general_ledger_last_year_fund_liabilities_row)
				{
				if ( $general_ledger_aseets_row->chart_of_accounts_general_ledger_balance_sheet_show == 1) {	
				$general_ledger_last_year_fund_liabilities_balance = $general_ledger_last_year_fund_liabilities_row->general_ledger_last_year_fund_liabilities_balance + $total_last_year_general_ledger_surplus_deficit;
				
				} else if ( $general_ledger_aseets_row->chart_of_accounts_general_ledger_balance_sheet_show == 0) {	
				$general_ledger_last_year_fund_liabilities_balance = $general_ledger_last_year_fund_liabilities_row->general_ledger_last_year_fund_liabilities_balance;
				} else { 
				$general_ledger_last_year_fund_liabilities_balance = 0.00;
				}
				$total_last_year_general_ledger_fund_liabilities	+= $general_ledger_last_year_fund_liabilities_balance;
				?>			
				<td class="tx-center" width="1%"></td>
				<td class="tx-right"><?php if ($general_ledger_last_year_fund_liabilities_balance >0) { echo' '.number_format($general_ledger_last_year_fund_liabilities_balance, 2 . '').' ';} else if($general_ledger_last_year_fund_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($general_ledger_last_year_fund_liabilities_balance), 2 . '').') ';} ?></td>
				<?php }?>
				<?php 
				$general_ledger_previous_year_fund_liabilities = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS general_ledger_previous_year_fund_liabilities_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_year_start_date.'" and "'.$previous_year_end_date.'"')
				->where('accounts_details_general_ledger', $general_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($general_ledger_previous_year_fund_liabilities as $general_ledger_previous_year_fund_liabilities_row)
				{
				if ( $general_ledger_aseets_row->chart_of_accounts_general_ledger_balance_sheet_show == 1) {	
				$general_ledger_previous_year_fund_liabilities_balance = $general_ledger_previous_year_fund_liabilities_row->general_ledger_previous_year_fund_liabilities_balance + $total_previous_year_general_ledger_surplus_deficit;
				
				} else if ( $general_ledger_aseets_row->chart_of_accounts_general_ledger_balance_sheet_show == 0) {	
				$general_ledger_previous_year_fund_liabilities_balance = $general_ledger_previous_year_fund_liabilities_row->general_ledger_previous_year_fund_liabilities_balance;
				} else { 
				$general_ledger_previous_year_fund_liabilities_balance = 0.00;
				}
				$total_previous_year_general_ledger_fund_liabilities	+= $general_ledger_previous_year_fund_liabilities_balance;
				?>			
				<td class="tx-center " width="1%"></td>
				<td class="tx-right "><?php if ($general_ledger_previous_year_fund_liabilities_balance >0) { echo' '.number_format($general_ledger_previous_year_fund_liabilities_balance, 2 . '').' ';} else if($general_ledger_previous_year_fund_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($general_ledger_previous_year_fund_liabilities_balance), 2 . '').') ';} ?></td>
				<?php }?>
			</tr>
			<?php }?>
			<tr class="tx-uppercase">
				<th class="tx-right" colspan="2"><?= $this->lang->line('total');?></th>
				<th class="tx-center" width="1%"></th>
				<th class="tx-right bd-bottom-double bd-top"><?php if ($total_current_month_general_ledger_fund_liabilities >0) { echo' '.number_format($total_current_month_general_ledger_fund_liabilities, 2 . '').' ';} else if($total_current_month_general_ledger_fund_liabilities ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_month_general_ledger_fund_liabilities), 2 . '').') ';} ?></th>
				<th class="tx-center" width="1%"></th>
				<th class="tx-right bd-bottom-double bd-top"><?php if ($total_last_month_general_ledger_fund_liabilities >0) { echo' '.number_format($total_last_month_general_ledger_fund_liabilities, 2 . '').' ';} else if($total_last_month_general_ledger_fund_liabilities ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_month_general_ledger_fund_liabilities), 2 . '').') ';} ?></th>
				<th class="tx-center" width="1%"></th>
				<th class="tx-right bd-bottom-double bd-top"><?php if ($total_last_year_general_ledger_fund_liabilities >0) { echo' '.number_format($total_last_year_general_ledger_fund_liabilities, 2 . '').' ';} else if($total_last_year_general_ledger_fund_liabilities ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_year_general_ledger_fund_liabilities), 2 . '').') ';} ?></th>
				<th class="tx-center " width="1%"></th>
				<th class="tx-right  bd-bottom-double bd-top"><?php if ($total_previous_year_general_ledger_fund_liabilities >0) { echo' '.number_format($total_previous_year_general_ledger_fund_liabilities, 2 . '').' ';} else if($total_previous_year_general_ledger_fund_liabilities ==0) {echo '-';} else { echo' ('.number_format(abs($total_previous_year_general_ledger_fund_liabilities), 2 . '').') ';} ?></th>
			</tr>
			
			<tr>
				<th class="tx-center" width="3%">&nbsp;</th>
				<th class="tx-left tx-uppercase" colspan="13"></th>
			</tr>
			
			<?php  
			$serial_fund_liabilities = 0; 
			$general_ledger_aseets = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $control_group_aseets_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
			foreach ($general_ledger_aseets as $general_ledger_aseets_row) {?>
			<tr>
				<th class="tx-left" width="3%"><?= number_format($serial,0 . '');?>.<?= number_format(++$serial_fund_liabilities,1 . '');?></th>
				<th class="tx-left tx-uppercase" colspan="13"><?= $general_ledger_aseets_row->chart_of_accounts_code;?> - <?= $general_ledger_aseets_row->chart_of_accounts_name;?></th>
			</tr>
			<?php 
			
			$total_current_month_subsidiary_ledger_fund_liabilities = 0.00;
			$total_last_month_subsidiary_ledger_fund_liabilities = 0.00;
			$total_previous_month_subsidiary_ledger_fund_liabilities = 0.00;
			$total_current_year_subsidiary_ledger_fund_liabilities = 0.00;
			$total_last_year_subsidiary_ledger_fund_liabilities = 0.00;
			$total_previous_year_subsidiary_ledger_fund_liabilities = 0.00;
			$subsidiary_ledger_aseets = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $general_ledger_aseets_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
			foreach ($subsidiary_ledger_aseets as $subsidiary_ledger_aseets_row) {?>
			<tr>
				<td></td>
				<td class="tx-left"><?= $subsidiary_ledger_aseets_row->chart_of_accounts_code;?> - <?= $subsidiary_ledger_aseets_row->chart_of_accounts_name;?></th>
				<?php 
				$subsidiary_ledger_current_month_fund_liabilities = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS subsidiary_ledger_current_month_fund_liabilities_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
				->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($subsidiary_ledger_current_month_fund_liabilities as $subsidiary_ledger_current_month_fund_liabilities_row)
				{
				if ( $subsidiary_ledger_aseets_row->chart_of_accounts_subsidiary_ledger_balance_sheet_show == 1) {	
				$subsidiary_ledger_current_month_fund_liabilities_balance = $subsidiary_ledger_current_month_fund_liabilities_row->subsidiary_ledger_current_month_fund_liabilities_balance + $total_current_month_subsidiary_ledger_surplus_deficit;
				
				} else if ( $subsidiary_ledger_aseets_row->chart_of_accounts_subsidiary_ledger_balance_sheet_show == 0) {	
				$subsidiary_ledger_current_month_fund_liabilities_balance = $subsidiary_ledger_current_month_fund_liabilities_row->subsidiary_ledger_current_month_fund_liabilities_balance;
				} else { 
				$subsidiary_ledger_current_month_fund_liabilities_balance = 0.00;
				}
				$total_current_month_subsidiary_ledger_fund_liabilities	+= $subsidiary_ledger_current_month_fund_liabilities_balance;
				?>			
				<td class="tx-center" width="1%"></td>
				<td class="tx-right"><?php if ($subsidiary_ledger_current_month_fund_liabilities_balance >0) { echo' '.number_format($subsidiary_ledger_current_month_fund_liabilities_balance, 2 . '').' ';} else if($subsidiary_ledger_current_month_fund_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($subsidiary_ledger_current_month_fund_liabilities_balance), 2 . '').') ';} ?></td>
				<?php }?>
				<?php 
				$subsidiary_ledger_last_month_fund_liabilities = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS subsidiary_ledger_last_month_fund_liabilities_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$last_month_start_date.'" and "'.$last_month_end_date.'"')
				->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($subsidiary_ledger_last_month_fund_liabilities as $subsidiary_ledger_last_month_fund_liabilities_row)
				{
				if ( $subsidiary_ledger_aseets_row->chart_of_accounts_subsidiary_ledger_balance_sheet_show == 1) {	
				$subsidiary_ledger_last_month_fund_liabilities_balance = $subsidiary_ledger_last_month_fund_liabilities_row->subsidiary_ledger_last_month_fund_liabilities_balance + $total_last_month_subsidiary_ledger_surplus_deficit;
				
				} else if ( $subsidiary_ledger_aseets_row->chart_of_accounts_subsidiary_ledger_balance_sheet_show == 0) {	
				$subsidiary_ledger_last_month_fund_liabilities_balance = $subsidiary_ledger_last_month_fund_liabilities_row->subsidiary_ledger_last_month_fund_liabilities_balance;
				} else { 
				$subsidiary_ledger_last_month_fund_liabilities_balance = 0.00;
				}
				$total_last_month_subsidiary_ledger_fund_liabilities	+= $subsidiary_ledger_last_month_fund_liabilities_balance;
				?>			
				<td class="tx-center" width="1%"></td>
				<td class="tx-right"><?php if ($subsidiary_ledger_last_month_fund_liabilities_balance >0) { echo' '.number_format($subsidiary_ledger_last_month_fund_liabilities_balance, 2 . '').' ';} else if($subsidiary_ledger_last_month_fund_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($subsidiary_ledger_last_month_fund_liabilities_balance), 2 . '').') ';} ?></td>
				<?php }?>
				
				<?php 
				$subsidiary_ledger_last_year_fund_liabilities = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS subsidiary_ledger_last_year_fund_liabilities_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
				->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($subsidiary_ledger_last_year_fund_liabilities as $subsidiary_ledger_last_year_fund_liabilities_row)
				{
				if ( $subsidiary_ledger_aseets_row->chart_of_accounts_subsidiary_ledger_balance_sheet_show == 1) {	
				$subsidiary_ledger_last_year_fund_liabilities_balance = $subsidiary_ledger_last_year_fund_liabilities_row->subsidiary_ledger_last_year_fund_liabilities_balance + $total_last_year_subsidiary_ledger_surplus_deficit;
				
				} else if ( $subsidiary_ledger_aseets_row->chart_of_accounts_subsidiary_ledger_balance_sheet_show == 0) {	
				$subsidiary_ledger_last_year_fund_liabilities_balance = $subsidiary_ledger_last_year_fund_liabilities_row->subsidiary_ledger_last_year_fund_liabilities_balance;
				} else { 
				$subsidiary_ledger_last_year_fund_liabilities_balance = 0.00;
				}
				$total_last_year_subsidiary_ledger_fund_liabilities	+= $subsidiary_ledger_last_year_fund_liabilities_balance;
				?>			
				<td class="tx-center" width="1%"></td>
				<td class="tx-right"><?php if ($subsidiary_ledger_last_year_fund_liabilities_balance >0) { echo' '.number_format($subsidiary_ledger_last_year_fund_liabilities_balance, 2 . '').' ';} else if($subsidiary_ledger_last_year_fund_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($subsidiary_ledger_last_year_fund_liabilities_balance), 2 . '').') ';} ?></td>
				<?php }?>
				<?php 
				$subsidiary_ledger_previous_year_fund_liabilities = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS subsidiary_ledger_previous_year_fund_liabilities_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_year_start_date.'" and "'.$previous_year_end_date.'"')
				->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($subsidiary_ledger_previous_year_fund_liabilities as $subsidiary_ledger_previous_year_fund_liabilities_row)
				{
				if ( $subsidiary_ledger_aseets_row->chart_of_accounts_subsidiary_ledger_balance_sheet_show == 1) {	
				$subsidiary_ledger_previous_year_fund_liabilities_balance = $subsidiary_ledger_previous_year_fund_liabilities_row->subsidiary_ledger_previous_year_fund_liabilities_balance + $total_previous_year_subsidiary_ledger_surplus_deficit;
				
				} else if ( $subsidiary_ledger_aseets_row->chart_of_accounts_subsidiary_ledger_balance_sheet_show == 0) {	
				$subsidiary_ledger_previous_year_fund_liabilities_balance = $subsidiary_ledger_previous_year_fund_liabilities_row->subsidiary_ledger_previous_year_fund_liabilities_balance;
				} else { 
				$subsidiary_ledger_previous_year_fund_liabilities_balance = 0.00;
				}
				$total_previous_year_subsidiary_ledger_fund_liabilities	+= $subsidiary_ledger_previous_year_fund_liabilities_balance;
				?>			
				<td class="tx-center " width="1%"></td>
				<td class="tx-right "><?php if ($subsidiary_ledger_previous_year_fund_liabilities_balance >0) { echo' '.number_format($subsidiary_ledger_previous_year_fund_liabilities_balance, 2 . '').' ';} else if($subsidiary_ledger_previous_year_fund_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($subsidiary_ledger_previous_year_fund_liabilities_balance), 2 . '').') ';} ?></td>
				<?php }?>
			<?php }?>	
			</tr>
			<tr class="tx-uppercase">
				<th class="tx-right" colspan="2"><?= $this->lang->line('total');?></th>
				<th class="tx-center" width="1%"></th>
				<th class="tx-right bd-bottom-double bd-top"><?php if ($total_current_month_subsidiary_ledger_fund_liabilities >0) { echo' '.number_format($total_current_month_subsidiary_ledger_fund_liabilities, 2 . '').' ';} else if($total_current_month_subsidiary_ledger_fund_liabilities ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_month_subsidiary_ledger_fund_liabilities), 2 . '').') ';} ?></th>
				<th class="tx-center" width="1%"></th>
				<th class="tx-right bd-bottom-double bd-top"><?php if ($total_last_month_subsidiary_ledger_fund_liabilities >0) { echo' '.number_format($total_last_month_subsidiary_ledger_fund_liabilities, 2 . '').' ';} else if($total_last_month_subsidiary_ledger_fund_liabilities ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_month_subsidiary_ledger_fund_liabilities), 2 . '').') ';} ?></th>
				<th class="tx-center" width="1%"></th>
				<th class="tx-right bd-bottom-double bd-top"><?php if ($total_last_year_subsidiary_ledger_fund_liabilities >0) { echo' '.number_format($total_last_year_subsidiary_ledger_fund_liabilities, 2 . '').' ';} else if($total_last_year_subsidiary_ledger_fund_liabilities ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_year_subsidiary_ledger_fund_liabilities), 2 . '').') ';} ?></th>
				<th class="tx-center " width="1%"></th>
				<th class="tx-right  bd-bottom-double bd-top"><?php if ($total_previous_year_subsidiary_ledger_fund_liabilities >0) { echo' '.number_format($total_previous_year_subsidiary_ledger_fund_liabilities, 2 . '').' ';} else if($total_previous_year_subsidiary_ledger_fund_liabilities ==0) {echo '-';} else { echo' ('.number_format(abs($total_previous_year_subsidiary_ledger_fund_liabilities), 2 . '').') ';} ?></th>
			</tr>
			
			<tr>
				<th class="tx-center" width="3%">&nbsp;</th>
				<th class="tx-left tx-uppercase" colspan="13"></th>
			</tr>
			<?php } ?>
			<?php }?>
			
			<?php }?>
			</tbody>
		</table>
		
		<br/><br/><br/><br/>
		
		<table class="" width="100%" align="center">  
			<tr class="tx-uppercase">
				<th width="30%" class="text-center"></th>
				<th width="5%"></th>
				<th width="30%" class="text-center"></th>
				<th width="5%"></th>
				<th width="30%" class="text-center bd-top"><?= $this->lang->line('prepared_by');?></th>
			</tr>
		</table>
		
		
	</div>
</body>