<style>
@page {
	   size: 7in 10.5in;
	   margin: 5px;
	}
</style>
<?php 
	$campus = $this->db->select("*") ->from('campus') ->where('campus_status', 1) ->order_by('campus_id', 'ASC') ->get() ->result();
	foreach ($campus as $campus_row) 
	{
		$campus_name			= $campus_row->campus_name; 
		$campus_address			= $campus_row->campus_address;
		$campus_phone			= $campus_row->campus_phone; 
		$campus_fax				= $campus_row->campus_fax;
		$campus_email			= $campus_row->campus_email;
		$campus_website			= $campus_row->campus_website; 
		$currency				= $campus_row->campus_currency; 
		$campus_logo			= $campus_row->campus_logo;
	}
foreach($voucher_information as $row) {
		
	$project_info =  $this->db->select("*")
	->from('project')
	->join('project_department', 'project.project_department = project_department.project_department_id', 'LEFT')
	->where('project.project_id', $row->accounts_project)
	->order_by('project.project_id', 'ASC') 
	->get();
	
	if($project_info->num_rows() > 0) {
	foreach($project_info->result() as $project_row)
	{
	$project_code 				= $project_row->project_code;
	$project_name 				= $project_row->project_name;
	} } else { 
	$project_code 				= '';
	$project_name 				= $campus_name;	
	}?> 
<body onload="window.print();">
	<div class="col-md-12 mg-t-5">
		
		<div class="tx-center">
			<img src="<?= base_url("$campus_logo");?>" alt="" width="90"><br/>
			<h2 class="tx-uppercase"><?= $campus_name;?></h2>
			<p class="tx-uppercase"><?= $campus_address;?></p>
			
			<h5 class="tx-uppercase tx-underlinetx-bold"><?= $row->accounts_voucher_type_name;?></h5>
		</div> 
		<table class="" width="100%" align="center">
			<tr class="tx-uppercase">
				<th width="20%"><?= $this->lang->line('voucher_no');?></th> <th width="1%">:</th> <th width="44%"><?= $row->accounts_voucher_number;?> </th>
				
				<th class="tx-right" width="20%"><?= $this->lang->line('posting');?> <?= $this->lang->line('date');?></th> <th width="1%">:</th> <th class="tx-left" width="15%"><?= date('d/m/Y', strtotime($row->accounts_voucher_posting_date));?></th>
			</tr>
			<tr class="tx-uppercase">
				<th width="24%"><?= $this->lang->line('hospital');?> / <?= $this->lang->line('department');?></th> <th width="1%">:</th> <th width="44%"><?= $project_name;?> </th>
				
				<th class="tx-right" width="24%"><?= $this->lang->line('print');?> <?= $this->lang->line('date');?></th> <th width="1%">:</th> <th class="tx-left" width="15%"><?= date('d/m/Y h:i A');?></th>
			</tr>
		</table><br/><br/>
		
		<table class="" width="100%" align="center">
			<tr class="tx-uppercase">
				<td width="13%"><?= $this->lang->line('narration');?></td><td width="1%">:</td>
				<td width="85%"><?= $row->accounts_narration ;?></td>
			</tr>
		</table>
		<div class="table-responsive">
			<table class="  table table-striped table-bordered table-hover">
				<thead class="tx-uppercase">
					<tr> 
						<th class="tx-center"><?= $this->lang->line('head_of_accounts');?></th>
						<th class="tx-center"><?= $this->lang->line('particulars');?></th> 
						<th class="tx-center"><?= $this->lang->line('debit');?></th>
						<th class="tx-center"><?= $this->lang->line('credit');?></th>
					</tr>
				</thead>
				<tbody>
					<?php 
					$total_debit_amount = 0;
					$total_credit_amount = 0;
					$accounts_details = $this->db->select("*")
					->from('accounts_details')
					->where('accounts_details_accounts_id', $row->accounts_id)
					->order_by('accounts_details_id', 'ASC') 
					->get()
					->result();
					
					foreach($accounts_details as $accounts_row) {
						
					$total_debit_amount += $accounts_row->accounts_details_debit;
					$total_credit_amount += $accounts_row->accounts_details_credit;	
					?> 
					<tr>
						<?php 
						$accounts_category = $this->db->select("*") 
						->from ('chart_of_accounts') 
						->where('chart_of_accounts_id', $accounts_row->accounts_details_general_ledger) 
						->order_by('chart_of_accounts_id', 'ASC') 
						->get()
						->result();
						foreach($accounts_category as $accounts_cat_row){?> 
						<td class="tx-left">
							<?php if ($accounts_row->accounts_details_debit > $accounts_row->accounts_details_credit) {?>
							<?= $accounts_cat_row->chart_of_accounts_code;?> - <?= $accounts_cat_row->chart_of_accounts_name;?>
							<?php } else {?>
							&nbsp; &nbsp;<?= $accounts_cat_row->chart_of_accounts_code;?> - <?= $accounts_cat_row->chart_of_accounts_name;?>
							<?php }?>
						</td>
						<?php }?>
						
						<?php 
						$accounts_category_sub = $this->db->select("*") 
						->from ('chart_of_accounts') 
						->where('chart_of_accounts_id', $accounts_row->accounts_details_subsidiary_ledger) 
						->order_by('chart_of_accounts_id', 'ASC') 
						->get()
						->result();
						foreach($accounts_category_sub as $accounts_category_sub_row){?> 
						<td class="tx-left">
							<?php if ($accounts_row->accounts_details_debit > $accounts_row->accounts_details_credit) {?>
							<?= $accounts_category_sub_row->chart_of_accounts_code;?> - <?= $accounts_category_sub_row->chart_of_accounts_name;?>
							<?php } else {?>
							&nbsp; &nbsp;<?= $accounts_category_sub_row->chart_of_accounts_code;?> - <?= $accounts_category_sub_row->chart_of_accounts_name;?>
							<?php }?>
						</td>
						<?php }?>
						<td class="tx-right"><?= $accounts_row->accounts_details_debit > 0 ? number_format($accounts_row->accounts_details_debit,2 . '') : '-';?></td>
						<td class="tx-right"><?= $accounts_row->accounts_details_credit > 0 ? number_format($accounts_row->accounts_details_credit,2 . '') : '-';?></td> 
					</tr>
					<?php }?>
					
					<tr class="tx-uppercase"> 
						<th class="tx-center" colspan="2"><?= $this->lang->line('total_amount');?></th>
						<th class="tx-right"> <?= number_format($total_debit_amount,2 . '');?> </th>
						<th class="tx-right"> <?= number_format($total_credit_amount,2 . '');?> </th>
					</tr>
						
					<tr class="tx-uppercase">
						<th class="text-left" colspan="4"><?= $this->lang->line('in_word');?>: 
						<?php 
						$number = $total_debit_amount;
						$in_word_amount = $this->number_to_word_convert->convert_number($number);
						?>
						<?= $in_word_amount;?> <?= $this->lang->line('currency_only');?>.
						</th>
					</tr> 
				</tbody>
			</table>
		</div><br/><br/><br/>
		
		<table class="" width="100%" align="center">  
			<?php if($row->accounts_voucher_type == 1) {?>
			<tr class="tx-uppercase">
				<th width="20%" class="text-center bd-top"><?= $this->lang->line('depositor_by');?></th>
				<th width="20%"></th>
				<th width="20%" class="text-center bd-top"><?= $this->lang->line('accountant');?></th>
				<th width="20%"></th>
				<th width="20%" class="text-center bd-top"><?= $this->lang->line('authorized');?></th>
			</tr>
			<?php } else  if($row->accounts_voucher_type == 2) {?>
			<tr class="tx-uppercase">
				<th width="20%" class="text-center bd-top"><?= $this->lang->line('received_by');?></th>
				<th width="20%"></th>
				<th width="20%" class="text-center bd-top"><?= $this->lang->line('accountant');?></th>
				<th width="20%"></th>
				<th width="20%" class="text-center bd-top"><?= $this->lang->line('authorized');?></th>
			</tr>
			<?php } else {?>
			<tr class="tx-uppercase">
				<th width="20%" class="text-center bd-top"><?= $this->lang->line('prepared_by');?></th>
				<th width="20%"></th>
				<th width="20%" class="text-center bd-top"><?= $this->lang->line('checked_by');?></th>
				<th width="20%"></th>
				<th width="20%" class="text-center bd-top"><?= $this->lang->line('authorized');?></th>
			</tr>
			<?php }?>
		</table> 
	</div>
</body>
<?php }?>