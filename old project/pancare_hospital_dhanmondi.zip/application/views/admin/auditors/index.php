<section class="content">
  <div class="row">
    <section class="col-xs-12 connectedSortable"> 
      <div  class="box box-info ">
        <div class="box-header no_print">
          <h3 class="box-title"><?=isset($page_title)?$page_title:''?></h3>
          <form class="no_print">
            <div class="box-body">
              <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                      <label for="from_date">From Date</label>
                      <input type="text" class="form-control search_datepicker" id="from_date" placeholder="YYYY-MM-DD" name="from_date" value="<?= isset($from_date) && !empty($from_date) ? $from_date : date('Y-m-d') ?>" autocomplete="off">
                    </div>
                  </div>
                  <div class="col-md-2">
                    <div class="form-group">
                      <label for="to_date">To Date</label>
                      <input type="text" class="form-control search_datepicker" id="to_date" placeholder="YYYY-MM-DD" name="to_date" value="<?= isset($to_date) && !empty($to_date) ? $to_date : date('Y-m-d') ?>" autocomplete="off">
                    </div>
                  </div>
                  <div class="col-md-2">
                    <div class="form-group" style="margin-top: 25px;">
                      <button type="submit" class="pull-left btn btn-success">Search <i class="fa fa-search"></i></button>
                    </div>
                  </div>
              </div>
            </div>
          </form>
        </div>
        <div class="box-body table-responsive" style="width: 100%; overflow-x: scroll; color: black;">
          <div style="right: 10px;" class="no-print text-right">

              <button  id="export"  class="btn btn-info btn-sm">
                  <i class="fa fa-file-excel-o"></i>
              </button>

              <button  id="print" onclick="window.print()" class="btn btn-warning btn-sm">
                  <i class="fa fa-print"></i>
              </button>
          
              <br>
              <br>
          </div>
          <table id="example2" class="table table-bordered table-striped dataTable no-footer" role="grid">
            <thead>
              <tr role="row">
                <th class="text-center">Sl.</th>
                <th class="text-center">Top Menu</th>
                <th class="text-center" >Sub Menu</th>
                <th class="text-center" >Action</th>
                <th class="text-center" >Invoice No.</th>
                <th class="text-center">Previous Amount</th>
                <th class="text-center">Present Amount</th>
                <th class="text-center">Comments</th>

                <th class="text-center" >Date &amp; Time</th>
                <th class="text-center">User Name</th>
              </tr></thead>
              <tbody>

                <?php $i = 0 ; foreach ($values as $key => $value) {
                  ++$i;
                  $parent = $this->Common_model->findById('menu_list',array('menu_id'=>$value->parent_menu_id));
                  $sub = $this->Common_model->findById('menu_list',array('menu_id'=>$value->sub_menu_id));
                  $username = "";
                  if($value->action_by == 1){
                   $user = $this->Common_model->findById('admin',array('record_id'=>$value->action_by));
                   $username = $user->name ;
                 }else{
                  $user = $this->Common_model->findById('staff',array('record_id'=>$value->action_by));
                  $username = $user->name ;
                }
                ?>
                <tr>
                  <td><?=$i?></td>
                  <td><?=isset($parent)?$parent->menu_name:''?></td>
                  <td><?=isset($sub)?$sub->menu_name:''?></td>
                  <td><?=$value->action?></td>
                  <td><?=$value->invoice_no?></td>
                  <td><?=$value->previous_paid_amount?></td>
                  <td><?=$value->present_paid_amount?></td>
                  <td><?=$value->comments?></td>
                  <td><?=date('M d, Y  h:m:s A',strtotime($value->action_date_time))?></td>
                  <td><?=$username?></td>
                </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
      </div>
    </section>
  </div>
</section>
<script>
$('#export').click(function () {
  const headers = [
    "Sl.",
    "Top Menu",
    "Sub Menu",
    "Action",
    "Invoice No.",
    "Previous Amount",
    "Present Amount",
    "Comments",
    "Date & Time",
    "User Name"
];

let thead = "<thead><tr>";

headers.forEach(function (h) {
    thead += "<th>" + h + "</th>";
});

thead += "</tr></thead>";
    const tbody = $('#example2 tbody').prop('outerHTML');
    
    const html = `
    <html xmlns:o="urn:schemas-microsoft-com:office:office"
          xmlns:x="urn:schemas-microsoft-com:office:excel">
    <head>
        <meta charset="UTF-8">
        <style>
            table{
                border-collapse:collapse;
                width:100%;
            }
            th,td{
                border:1px solid #000;
                padding:5px;
                text-align:center;
            }
            th{
                font-weight:bold;
                background:#f2f2f2;
            }
        </style>
    </head>
    <body>

        <h2 style="text-align:center;">Auditors Report</h2>

        <table>
            ${thead}
            ${tbody}
        </table>

    </body>
    </html>`;

    const uri = 'data:application/vnd.ms-excel;charset=utf-8,' + encodeURIComponent(html);

    let link = document.createElement('a');
    link.href = uri;
    link.download = 'auditors-report.xls';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
});


</script>