<?php
$user_type = $this->session->ses_user_type;
$record_id = $this->session->ses_record_id;
$where = array();
$selected = '';
$selected_text = '--Select--';
if ($user_type == 'doctor') {
    $where['record_id'] = $record_id;
    $selected = $record_id;
    $selected_text = '';
}
if (isset($prescription_data['data']) && !empty($prescription_data['data'])) {
    $pres = $prescription_data['data'];
}
?>
<aside>
    <section class="content">
        <div class="row">
            <section class="col-xs-12 connectedSortable">
                <div class="box box-info no_print">
                    <div class="box-header">
                        <h3 class="box-title"><?= isset($page_title) ? $page_title : '' ?></h3>
                    </div>
                    <?php echo form_open_multipart('admission_form/prescription_saveOrUpdate'); ?>
                    <div class="box-body">
                        <input type="hidden" name="update_id" id="update_id" value="<?= isset($pres) ? $pres->record_id : 0 ?>">
                        <input type="hidden" name="prescription_admission_id" id="prescription_admission_id" value="<?= isset($value) ? $value->admission_id : 0 ?>">
                        <input type="hidden" name="prescription_operation_invoice_id" id="prescription_operation_invoice_id" value="<?= isset($value) ? $value->operation_invoice_record_id : 0 ?>">
                        <div class="row">
                            <div class="form-group col-sm-3 hide">
                                <label for="date">Visit Date </label>

                                <input type="hidden" class="form-control" id="date" placeholder="" name="date" value="<?= isset($value) ? $value->release_date : date('Y-m-d') ?>">
                            </div>
                            <div class="col-sm-3 hide">
                                <div class="form-group">
                                    <label for="doctor_id">Doctor</label>
                                    <select class="form-control selectpicker" data-live-search="true" id="doctor_id" name="doctor_id">
                                        <?= options(
                                            'doctor',
                                            $where,
                                            array('record_id', 'name'),
                                            'record_id',
                                            '',
                                            'record_id',
                                            'asc',
                                            $selected_text,
                                            isset($pres) ? $pres->doctor_id : 0,
                                            array('frees', 'doctors_time')
                                        )
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-3 hide">
                                <div class="form-group">
                                    <label for="patient_id">Patient</label>
                                    <div class="input-group">
                                        <select class="form-control selectpicker" data-live-search="true" id="patient_id" name="patient_id">
                                            <?= options(
                                                'patient',
                                                array(),
                                                array('record_id', 'name'),
                                                'record_id',
                                                '',
                                                'record_id',
                                                'desc',
                                                '--Select--',
                                                isset($pres) ? $pres->patient_id : 0
                                            )
                                            ?>
                                        </select>
                                        <span class="input-group-addon">
                                            <button type="button" id="c_plus" style="height: 20px;" class="btn btn-success fa fa-plus-square btn-sm" data-toggle="modal" data-target="#patientModal">
                                            </button>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3 hide">
                                <div class="form-group">
                                    <label for="chief_compliment">C/C:</label>
                                    <textarea type="text" name="chief_compliment" placeholder="Chief Complaint" class="form-control" id="chief_compliment" rows="1" cols="12"><?= isset($pres) ? $pres->chief_compliment : '' ?></textarea>
                                </div>
                            </div>

                            <div class="col-sm-2 hide">
                                <div class="form-group">
                                    <label for="con_bp">Temperature</label>
                                    <input type="text" name="blood_pressure" placeholder="Temperature" class="form-control" id="blood_pressure" value="<?= isset($pres) ? $pres->blood_pressure : '' ?>">
                                </div>
                            </div>


                            <div class="col-sm-1 hide">
                                <div class="form-group">
                                    <label for="con_pulse">Pulse</label>
                                    <input type="text" name="pulse" placeholder="Pulse" class="form-control" id="pulse" value="<?= isset($pres) ? $pres->pulse : '' ?>">
                                </div>
                            </div>


                            <div class="col-sm-1 hide">
                                <div class="form-group">
                                    <label for="con_weight">Weight</label>
                                    <input type="text" name="weight" placeholder="Weight" class="form-control" id="weight" value="<?= isset($pres) ? $pres->weight : '' ?>">
                                </div>
                            </div>

                            <div class="col-sm-4 hide">
                                <div class="form-group">
                                    <label for="test_id">Investigation</label>
                                    <?php $ex_test_ids = array();
                                    if (isset($value)) {
                                        $ex_test_ids = explode(',', $value->test_ids);
                                    } ?>
                                    <select name="test_id[]" id="test_id" class="form-control selectpicker" data-live-search="true" multiple="">
                                        <option value="">--Select--</option>
                                        <?php $selected = '';
                                        foreach ($test_names as $key2 => $value2) {
                                            $category = $this->Common_model->findById('test_category', array('record_id' => $value2->test_category_id));
                                            if (in_array($value2->record_id, $ex_test_ids)) {
                                                $selected = 'selected';
                                            } else {
                                                $selected = '';
                                            }
                                        ?>
                                            <option value="<?= $value2->record_id ?>" data-test_category_id="<?= $value2->test_category_id ?>" data-test_name="<?= $value2->test_name ?>" data-test_price="<?= $value2->test_price ?>" data-test_category="<?= isset($category) ? $category->test_category : '' ?>" <?= $selected ?>><?= $value2->record_id ?> - <?= $value2->test_name ?><?= isset($category) ? ' - ' . $category->test_category : '' ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-sm-3 hide">
                                <div class="form-group">
                                    <label for="medicine_id">Diagnosis</label>
                                    <textarea type="text" name="diagnosis" placeholder="Diagnosis" class="form-control" id="diagnosis" rows="1" cols="12"><?= isset($pres) ? $pres->diagnosis : '' ?></textarea>
                                </div>
                            </div>

                            <div class="clearfix"></div>

                            <div class="col-sm-2 hide">
                                <div class="form-group">
                                    <label for="findings">O/E:</label>
                                    <textarea type="text" name="findings" placeholder="Findings" class="form-control" id="findings" rows="1" cols="12"><?= isset($pres) ? $pres->findings : '' ?></textarea>
                                </div>
                            </div>

                            <div class="col-sm-2 hide">
                                <div class="form-group">
                                    <label for="visit_amount">Visit Amount</label>
                                    <input type="text" name="visit_amount" placeholder="Visit Amount" class="form-control text-right numeric" id="frees" value="<?= isset($pres) ? $pres->visit_amount : '' ?>">
                                </div>
                            </div>
                            <div class="col-sm-2 hide">
                                <div class="form-group">
                                    <label for="visiting_hour">Visiting Hour</label>
                                    <input type="text" class="form-control" name="visiting_hour" id="appointment_time" placeholder="Visiting Hour" value="<?= isset($pres) ? $pres->visiting_hour : '' ?>">
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div><br />

                        <div class="row">
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label for="medicine_id">Medicine Name</label>
                                    <div class="input-group">
                                        <select class="form-control selectpicker" data-live-search="true" id="medicine_id" name="medicine_id">
                                            <?= options(
                                                'product_name',
                                                array(),
                                                array('product_name', 'strength'),
                                                'record_id',
                                                '',
                                                'product_name',
                                                'asc',
                                                '--Select--',
                                                isset($value) ? $value->medicine_id : 0
                                            )
                                            ?>
                                        </select>
                                        <span class="input-group-addon">
                                            <button type="button" id="c_plus" style="height: 20px;" class="btn btn-success fa fa-plus-square btn-sm" data-toggle="modal" data-target="#medicineNameModal">
                                            </button>
                                        </span>
                                    </div>
                                </div>
                            </div>


                            <div class="col-sm-2 hide">
                                <div class="form-group">
                                    <label for="medicine_type">Dosage Type</label>
                                    <select name="medicine_type_id" id="medicine_type_id" class="form-control selectpicker" data-live-search="true">
                                        <?= options(
                                            'types_of_medicine',
                                            array(),
                                            array(),
                                            'record_id',
                                            'type_name',
                                            'type_name',
                                            'asc',
                                            'Select Dosages',
                                            isset($value) ? $value->medicine_type_id : 0
                                        )
                                        ?>
                                    </select>

                                </div>
                            </div>


                            <div class="col-sm-2 ">
                                <div class="form-group">
                                    <label for="dose">Per Day Dose</label><small class="req"> *</small>
                                    <div class="input-group">
                                        <select name="dose" id="dose" class="form-control">
                                            <?= options(
                                                'per_day_dosages',
                                                array(),
                                                array('name'),
                                                'name',
                                                '',
                                                'record_id',
                                                'desc',
                                                '--Select--',
                                                ''
                                            )
                                            ?>
                                        </select>
                                        <span class="input-group-addon">
                                            <button type="button" id="c_plus" style="height: 20px;" class="btn btn-success fa fa-plus-square btn-sm" data-toggle="modal" data-target="#perDayDoseModal">
                                            </button>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <div class="form-group">
                                    <label for="meal_type_id">Meal Type</label><small class="req"> *</small>
                                    <div class="input-group">
                                        <select name="meal_type_id" id="meal_type_id" class="form-control selectpicker" data-live-search="true">
                                            <?= options(
                                                'meal_types',
                                                array(),
                                                array('meal_type_name'),
                                                'record_id',
                                                '',
                                                'record_id',
                                                'desc',
                                                '--Select--',
                                                isset($value) ? $value->meal_type_id : 0
                                            )
                                            ?>
                                        </select>
                                        <span class="input-group-addon">
                                            <button type="button" id="c_plus" style="height: 20px;" class="btn btn-success fa fa-plus-square btn-sm" data-toggle="modal" data-target="#mealTypeModal">
                                            </button>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <div class="form-group">
                                    <label for="days">Number Of Days</label>
                                    <input type="text" name="days" placeholder="Number Of Days" class="form-control" id="days">
                                </div>
                            </div>
                            <div class="col-sm-1">
                                <div class="form-group pull-left m-t-22 m-l-15 ">
                                    <a href="javascript:void(0)" class="btn btn-primary mt-25" id="btnAdd"><i class="fa fa-plus"></i>Add</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-12">
                        <div class="form-group">
                            <label for="advice">Advice</label>
                            <textarea class="form-control summernote" name="advice" id="advice" cols="12" rows="4" placeholder="Advice" rows="1"><?= isset($pres) ? $pres->advice : '' ?></textarea>
                        </div>
                    </div>
                    
                    <div class="box-body table-responsive" style="width: 100%; color: black;">
                        <table id="draftbox" class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th style="text-align: center;width: 1%">#</th>
                                    <th style="text-align: center; color: red;">Medicine</th>
                                    <!-- <th style="text-align: center;width: 20%">Dosage</th> -->
                                    <th style="text-align: center; color: red;">Per_Day_Dose</th>
                                    <th style="text-align: center; color: red;">Meal_Type</th>
                                    <th style="text-align: center; color: red;">No_of_Day</th>
                                    <th style="text-align: center;">Action</th>
                                </tr>
                            </thead>
                            <!-- Add Multiple test name  -->
                            <tbody>
                                <?php $i = 0;
                                if (isset($prescription_data['details']) && count($prescription_data['details'])) {
                                    foreach ($prescription_data['details'] as $key1 => $value1) {
                                        ++$i;
                                        $medicine = $this->Common_model->findById('product_name', array('record_id' => $value1->medicine_id));
                                        $medicine_type = $this->Common_model->findById('types_of_medicine', array('record_id' => $value1->medicine_type_id));
                                        $meal_type = $this->Common_model->findById('meal_types', array('record_id' => $value1->meal_type_id));
                                ?>
                                        <tr>
                                            <td class="hide">
                                                <input type="hidden" name="prescription_details_id[]" value="<?= $value1->record_id ?>">
                                                <input type="hidden" name="medicine_id[]" value="<?= isset($value1) ? $value1->medicine_id : '' ?>">
                                                <input type="hidden" name="medicine_type_id[]" value="<?= isset($value1) ? $value1->medicine_type_id : '' ?>">
                                                <input type="hidden" name="dose[]" value="<?= isset($value1) ? $value1->dose : '' ?>">
                                                <input type="hidden" name="meal_type_id[]" value="<?= isset($value1) ? $value1->meal_type_id : '' ?>">
                                                <input type="hidden" name="days[]" value="<?= isset($value1) ? $value1->days : '' ?>">
                                            </td>
                                            <td class="serial"><?= $i ?></td>
                                            <td><?= isset($medicine) ? $medicine->record_id . ' - ' . $medicine->product_name : '' ?></td>
                                            <td><?= isset($medicine_type) ? $medicine_type->type_name : '' ?></td>
                                            <!-- <td><?= $value1->dose ?></td> -->
                                            <td><?= isset($meal_type) ? $meal_type->meal_type_name : '' ?></td>
                                            <td><?= $value1->days ?></td>
                                            <td style="width:10%;text-align:center;">
                                                <a href="javascript:void(0)" style="margin-right:5px;" class="btn btn-info editRow"><span class="fa fa-pencil"></span></a>
                                                <a href="javascript:void(0)" data-record_id="<?= $value1->record_id ?>" class="btn btn-danger deleteRow"><span class="fa fa-trash-o"></span></a>
                                            </td>
                                        </tr>
                                <?php }
                                } ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th colspan="7">
                                        <!-- <div class="box-footer clearfix submit" style="display: <?= (isset($values) && count($values)) ? 'block' : 'none' ?>"> -->
                                        <div class="box-footer clearfix submit">
                                            <button type="submit" class=" pull-right btn btn-success btn-sm">
                                                <?php if (!isset($pres)) { ?>
                                                    Submit
                                                <?php } else { ?>
                                                    Update
                                                <?php } ?>
                                                <i class="fa fa-arrow-circle-right"></i></button>
                                        </div>
                                    </th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    </form>
                </div>
            </section>
        </div>
    </section>
</aside>
<script type="text/javascript">
    var product_count = 0;
    var patient_name = '';
    var patient_id = 0;
    var doctor = '';
    var replaceRow = '';
    var prescription_details_id = 0;
    $(document).on("click", "#btnAdd", function(e) {
        var medicine_id, product_name, medicine_type_id, medicine_type, dose, meal_type, meal_type_id, days, medicine_option, dosage_type_option, dose_option, meal_type_option;
        medicine_option = $('#medicine_id option:selected');
        dosage_type_option = $('#medicine_type_id option:selected');
        dose_option = $('#dose option:selected');
        meal_type_option = $('#meal_type_id option:selected');

        medicine_id = medicine_option.val();
        product_name = medicine_option.text();
        medicine_type_id = dosage_type_option.val();
        medicine_type = dosage_type_option.text();
        dose = dose_option.val();
        //product_name = medicine_option.text();
        meal_type_id = meal_type_option.val();
        meal_type = meal_type_option.text();
        days = $('#days').val();

        html = '<input type="hidden" name="prescription_details_id[]" value="' + prescription_details_id + '">';
        html += '<input type="hidden" name="medicine_id[]" value="' + medicine_id + '">';
        html += '<input type="hidden" name="medicine_type_id[]" value="' + medicine_type_id + '">';
        html += '<input type="hidden" name="dose[]" value="' + dose + '">';
        html += '<input type="hidden" name="meal_type_id[]" value="' + meal_type_id + '">';
        html += '<input type="hidden" name="days[]" value="' + days + '">';

        var editRow = '<a  href="javascript:void(0)" style="margin-right:5px;" class="btn btn-info editRow"><span class="fa fa-pencil"></span></a>';
        var deleteRow = '<a href="javascript:void(0)" data-record_id="0" class="btn btn-danger deleteRow"><span class="fa fa-trash-o"></span></a>';

        tr = '<tr>' +
            '<td class="hide">' + html + '</td>' +
            '<td class="serial"></td>' +
            '<td>' + product_name + '</td>' +
            '<td>' + medicine_type + '</td>' +
            // '<td>' + dose + '</td>' +
            '<td >' + meal_type + '</td>' +
            '<td style="text-align:right;">' + days + '</td>' +
            '<td style="width:10%;text-align:center;">' + editRow + ' ' + deleteRow + '</td>' +
            '</tr>';

        if (replaceRow == '') {
            $('#draftbox tbody').append(tr);
        } else {
            replaceRow.replaceWith(tr);
            replaceRow = '';
        }

        $('.submit').show();
        $('#medicine_id').val('');
        $('#medicine_id').selectpicker('refresh');
        $('#medicine_type_id').val('');
        $('#medicine_type_id').selectpicker('refresh');
        $('#dose').val('');
        $('#dose').selectpicker('refresh');
        $('#meal_type_id').val('');
        $('#meal_type_id').selectpicker('refresh');
        $('#days').val('');
        setTimeout(function(e) {
            setSerial('draftbox', 'serial');
            calculation();
        }, 500);
        $('#draftbox-footer').show();
    });

    $(document).on('click', '.editRow', function(e) {
        var medicine_id, product_name, medicine_type_id, medicine_type, dose, meal_type, meal_type_id, days;
        tr = $(this).closest('tr');
        replaceRow = tr;
        prescription_details_id = tr.find('input[name="prescription_details_id[]"]').val();
        medicine_id = tr.find('input[name="medicine_id[]"]').val();
        medicine_type_id = tr.find('input[name="medicine_type_id[]"]').val();
        dose = tr.find('input[name="dose[]"]').val();
        meal_type_id = tr.find('input[name="meal_type_id[]"]').val();
        days = tr.find('input[name="days[]"]').val();
        $('#medicine_id').val(medicine_id);
        $('#medicine_id').selectpicker('refresh');
        $('#medicine_type_id').val(medicine_type_id);
        $('#medicine_type_id').selectpicker('refresh');
        $('#dose').val(dose);
        $('#dose').selectpicker('refresh');
        $('#meal_type_id').val(meal_type_id);
        $('#meal_type_id').selectpicker('refresh');
        $('#days').val(days);
    })


    $(document).on('click', '.deleteRow', function(e) {
        var row, record_id;
        row = $(this).closest('tr');
        record_id = $(this).data('record_id');
        //alert(record_id);return ;
        if (record_id) {
            if (confirm("Are you sure to delete this record?")) {
                var formData = {
                    record_id: record_id
                };
                var formURL = '<?= base_url('test_invoice/delete_sale_test') ?>';
                $.ajax({
                    type: "POST",
                    url: formURL,
                    data: formData,
                    success: function(data) {
                        if (data == 1) {
                            row.remove();
                        }
                    }
                });
            }
        } else {
            row.remove();
        }
        setTimeout(function(e) {
            setSerial('draftbox', 'serial');
            calculation();
        }, 500);
    })
    $("#paid").on("change paste keyup", function() {
        var paid, sub_total, due;
        paid = $(this).val();
        paid = +paid;
        sub_total = $('#sub_total').val();
        sub_total = +sub_total;
        if (paid > sub_total) {
            alert('Paid amount should be less than or equal sub total');
            paid = sub_total;
            $(this).val(sub_total);
        }
        due = sub_total - paid;
        $('#due').val(due);
    })

    $("#discount").on("change paste keyup", function() {
        var amount, discount_percentage, discount;
        $('#paid').val(0);
        amount = $('#amount').val();
        amount = +amount;
        discount = $('#discount').val();
        discount = +discount;
        discount_percentage = (100 * discount) / amount;
        $('#discount_percentage').val(discount_percentage.toFixed(2));
        calculation();
        $('#doctor_commission_percentage').val(0);
        $('#doctor_commission').val(0);
        $('#reference_by_commission_percentage').val(0);
        $('#reference_by_commission').val(0);
    });

    $(document).on('keyup', '#discount_percentage', function(e) {

        var amount, paid, discount, discount_percentage;
        $('#paid').val(0);
        amount = $('#amount').val();
        amount = +amount;
        discount_percentage = $('#discount_percentage').val();
        discount_percentage = +discount_percentage;
        discount = (amount * discount_percentage) / 100;
        $('#discount').val(discount);
        calculation();
        $('#doctor_commission_percentage').val(0);
        $('#doctor_commission').val(0);
        $('#reference_by_commission_percentage').val(0);
        $('#reference_by_commission').val(0);
    })





    function calculation() {
        var amount = 0,
            value = 0,
            discount = 0,
            sub_total = 0,
            paid = 0,
            due = 0;
        $('.test_price').each(function() {
            value = $(this).text();
            value = +value;
            amount += value;
        });
        $('#amount').val(amount);
        discount = $('#discount').val();
        discount = +discount;
        sub_total = amount - discount;
        $('#sub_total').val(sub_total);
        paid = $('#paid').val();
        paid = +paid;
        due = sub_total - paid;
        $('#due').val(due);


        var doctor_option, test_commission = 0,
            commission_amount = 0,
            total_test_commission = 0;
        doctor_option = $('#doctor_id option:selected');

        test_commission = doctor_option.data('test_commission');
        test_commission = +test_commission;

        commission_amount = (amount * test_commission) / 100;

        $('#doctor_commission').val(commission_amount);
        $('#doctor_commission_percentage').val(test_commission);

        var reference_by_commission_percentage, reference_by_commission;
        reference_by_commission_percentage = $('#reference_by_commission_percentage').val();
        reference_by_commission_percentage = +reference_by_commission_percentage;

        reference_by_commission = (sub_total * reference_by_commission_percentage) / 100;
        $('#reference_by_commission').val(reference_by_commission);


        /*if(discount > 0 ){
            $('#reference_by').show('fast');
        }else{
            $('#reference_by').hide('fast');
        }*/
    }
    $(document).on('keyup', '#doctor_commission_percentage', function(e) {
        var sub_total, paid, doctor_commission, doctor_commission_percentage;
        sub_total = $('#sub_total').val();
        sub_total = +sub_total;
        doctor_commission_percentage = $('#doctor_commission_percentage').val();
        doctor_commission = (sub_total * doctor_commission_percentage) / 100;
        $('#doctor_commission').val(doctor_commission);
    })
    $(document).on('keyup', '#doctor_commission', function(e) {
        var sub_total, paid, doctor_commission, doctor_commission_percentage;

        sub_total = $('#sub_total').val();
        sub_total = +sub_total;

        doctor_commission = $('#doctor_commission').val();
        doctor_commission_percentage = (100 * doctor_commission) / sub_total;
        $('#doctor_commission_percentage').val(doctor_commission_percentage.toFixed(2));
    })

    $(document).on('keyup', '#reference_by_commission_percentage', function(e) {
        var sub_total, paid, reference_by_commission, reference_by_commission_percentage, reference_by;
        reference_by = $('#reference_by').val();
        if (!reference_by) {
            alert("Please reference");
            $(this).val(0);
        }
        sub_total = $('#sub_total').val();
        sub_total = +sub_total;
        reference_by_commission_percentage = $('#reference_by_commission_percentage').val();
        reference_by_commission = (sub_total * reference_by_commission_percentage) / 100;
        $('#reference_by_commission').val(reference_by_commission);
    })
    $(document).on('keyup', '#reference_by_commission', function(e) {
        var sub_total, paid, reference_by_commission, reference_by_commission_percentage, reference_by;
        reference_by = $('#reference_by').val();
        if (!reference_by) {
            alert("Please reference");
            $(this).val(0);
        }

        sub_total = $('#sub_total').val();
        sub_total = +sub_total;

        reference_by_commission = $('#reference_by_commission').val();
        reference_by_commission_percentage = (100 * reference_by_commission) / sub_total;
        $('#reference_by_commission_percentage').val(reference_by_commission_percentage.toFixed(2));
    })

    $("#reference_by").on("change paste keyup", function() {
        var amount, paid, reference_by_commission, reference_by_commission_percentage, option;
        option = $('#reference_by option:selected');
        amount = $('#amount').val();
        amount = +amount;
        $('#reference_by_commission').val(0);
        $('#reference_by_commission_percentage').val(0);
        reference_by_commission_percentage = option.data('commission');
        if (!reference_by_commission_percentage) {
            reference_by_commission_percentage = 0;
        }
        $('#reference_by_commission_percentage').val(reference_by_commission_percentage);
        reference_by_commission = (amount * reference_by_commission_percentage) / 100;
        $('#reference_by_commission').val(reference_by_commission);
    })
</script>