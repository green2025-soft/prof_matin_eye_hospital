<section class="content">
    <div id="invoice">
        <div class="report_header">
        <?php $this->load->view('admin/common/report_header') ?>
        <?php //$this->load->view('admin/common/report_header_admission_form') ?>
        </div>
        
        <div class="container">
            <div class="row">
                <div class="form-group col-sm-12 col-xs-12">
                    <!-- <hr style="border: 1px solid #d4d9d8 !important; padding: 0px; margin: 3px;"> -->
                    <!-- <h4 style="text-align: center; font-weight: bolder; ">ADMISSION FORM</h4> -->
                    <?php $this->load->view('admin/common/admission_header_barcode'); ?>
					
					<table class="mt-5" border="0" width="100%" align="center">
						<tr>
                            <th class="text-left" width="19%">Admission No. <Noscript></Noscript></th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->admission_no;?></td>

                            <th class="text-right" width="19%">Admission Date</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= isset($value)?date('d-m-Y', strtotime($value->admission_date)):'';?> <?= date('h:i A', strtotime($value->admission_created_at));?></td>
                        </tr>
						<tr>
                            <th class="text-left" width="19%">Patient Name</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->patient_name;?></td>

                            <th class="text-right" width="19%">Age</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->patient_age;?> YRS</td>
                        </tr>
						<tr>
                            <th class="text-left" width="19%">Gender</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->patient_gender;?></td>

                            <th class="text-right" width="19%">Marital Status</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->marital_status;?></td>
                        </tr>
						<tr>
                            <th class="text-left" width="19%">Father's Name</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->patient_father_name;?></td>

                            <th class="text-right" width="19%">Spouse Name</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->patient_spouse_name;?></td>
                        </tr>
						<tr>
                            <th class="text-left" width="19%">Mother's Name</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->patient_mother_name;?></td>

                            <th class="text-right" width="19%">Blood Group</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->patient_blood_group;?></td>
                        </tr>
						<tr>
                            <th class="text-left" width="19%" rowspan="2">Address</th>
                            <th class="text-left" width="1%" rowspan="2">:</th>
                            <td class="text-left" width="30%" rowspan="2"><?= $value->village.', '.$value->post_office.', '.$value->thana.', '.$value->district;?></td>

                            <th class="text-right" width="19%">Mobile No</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->patient_mobile;?></td>
                        </tr>
						<tr>
                            <th class="text-right" width="19%">Occupation</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->patient_occupation;?></td>
                        </tr>
					</table>

                    <table class="mt-3" border="0" width="100%" align="center" style="border:1px dotted #111; border-radius: 25px;">
						<tr>
                            <th class="text-left" width="19%">&nbsp;Contact Person</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?=isset($value)?$value->full_name:''?></td>

                            <th class="text-right" width="19%">Relationship</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->relation_of_patient;?></td>
                        </tr>
						<tr>
                            <th class="text-left" width="19%">&nbsp;Address</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?=isset($value)?$value->re_address:''?></td>

                            <th class="text-right" width="19%">Mobile</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->guardian_phone;?></td>
                        </tr>
						<tr>
                            <th class="text-left" width="19%">&nbsp;National ID</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?=isset($value)?$value->guardian_nid:''?></td>
                        </tr>
                    </table>

                    <table class=mt-25" border="0" width="100%" align="center" style="border:1px dotted #111; border-radius: 25px;">
						<!-- <tr>
                            <th class="text-left" width="19%">&nbsp;Referring Physician</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?=isset($value)?$value->referring_sergeon_name:''?></td>
                        </tr> -->
						<tr>
                            <th class="text-left" width="19%">&nbsp;Assign Physician</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?=isset($value)?$value->sergeon_name.' - '.$value->sergeon_designation:''?></td>
                        </tr>
						<tr>
                            <th class="text-left" width="19%">&nbsp;Cabin/Word No</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%">
                                <!-- <?=isset($value)?$value->opd_cabin_ward:''?>-<?=isset($value)?$value->room_no:''?> (<?=isset($value)?$value->bed_type:''?>)<br> -->
                            <?php echo $value->opd_cabin_ward." - ". $value->bed_no ." - ". $value->bed_type ." - ". $value->room_no ." - ". $value->floor_no; ?>
                        </td>
                        </tr>
                        <tr>
                            <th class="text-left" width="19%">&nbsp;Admitted Under</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?=isset($value)?$value->admitted_under:''?></td>
                        </tr>
                    </table>

                    <h6 style="text-align: left; font-weight: bold; ">I ACKNOWLEDGE THAT</h6>
                    <table class="" border="0" width="100%" align="center" style="border:1px dotted #111; border-radius: 25px;">
                        <tr>
                            <td>
                                <!-- <div class="text-center" style="font-weight:bold; text-decoration:underline">অঙ্গীকার নামা</div> -->
                                <!-- <div style="text-align:justify; padding:5px;">
                                অমি আমার নিজের পিতার/মাতার স্ত্রী/পুত্রের/কন্যার <b><?= $value->patient_name ?></b> অস্ত্রোপচার সম্পন্ন করার জন্য ডাঃ <b><?= $value->sergeon_name ?></b> কে এবং তার নির্বাচিত সহকারীদের মনোনীত করছি। যদি অস্ত্রোপচার পক্রিয়ার মধ্যে নতুন পরিস্থিতি, জটিলতা ও উপসর্গ দেখা দেয় সেক্ষেত্রে বাস্তব পরিপ্রেক্ষিতে প্রয়োজনীয় সিদ্ধান্ত ও ব্যবস্থা গ্রহণের জন্য আমি  তার উপর আস্থা রাখছি।অস্ত্রোপাচার চলাকালীন সময়ে এনেস্থেসিয়ার দায়িত্ব আমার সম্মতিক্রমে ডাঃ <b><?= $value->anesthesia_name ?></b> কে দেওয়া হচ্ছে এবং তিনি এ ব্যাপারে প্রয়োজন মত পদক্ষেপ গ্রহণ করবেন। এই অস্ত্রোপাচার এবং এনেস্থেসিয়ার কারণে অস্ত্রোপাচার চলাকালীন অথবা পরবর্তী কোন অসুবিধা হইলে উক্ত চিকিৎসকগণ এবং হাসপাতাল কর্তৃপক্ষ দায়ী থাকিবে না। আমি এই নিশ্চয়তা দিচ্ছি যে, আমি এই সংক্রান্ত উপরক্ত সম্মতিপত্র  পুরোপুরি পাড়ছি এবং সংশ্লিষ্ট প্রয়োজনীয় বিষয়গুলো যথাযথ ভাবে আমাকে ব্যাখ্যা করা হয়েছে। শুন্য ঘরগুলো যথাযথ ভাবে পুণ্য করার পর আমি সম্মতি সাক্ষররছি উপরোক্ত করার  পর আমি সম্মতি স্বাক্ষর করা করছি
                                </div> -->
                                <div style="text-align:justify; padding:5px;">
                                <!-- অমি আমার নিজের পিতার/মাতার স্ত্রী/পুত্রের/কন্যার <b><?//= $value->patient_name ?></b> অস্ত্রোপচার সম্পন্ন করার জন্য ডাঃ <b><?//= $value->sergeon_name ?></b> কে এবং তার নির্বাচিত সহকারীদের মনোনীত করছি। যদি অস্ত্রোপচার প্রক্রিয়ার মধ্যে নতুন পরিস্থিতি, জটিলতা ও উপসর্গ দেখা দেয় সেক্ষেত্রে বাস্তব পরিপ্রেক্ষিতে প্রয়োজনীয় সিদ্ধান্ত ও ব্যবস্থা গ্রহণের জন্য আমি তার উপর আস্থা রাখছি। অস্ত্রোপাচার চলাকালীন সময়ে এনেস্থেসিয়ার দায়িত্ব আমার সম্মতিক্রমে ডাঃ <b><?= $value->anesthesia_name ?></b> কে দেওয়া হচ্ছে এবং তিনি এ ব্যাপারে প্রয়োজন মত পদক্ষেপ গ্রহণ করবেন। এই অস্ত্রোপাচার এবং এনেস্থেসিয়ার কারণে অস্ত্রোপাচার চলাকালীন অথবা পরবর্তী কোন অসুবিধা হইলে উক্ত চিকিৎসকগণ এবং হাসপাতাল কর্তৃপক্ষ দায়ী থাকিবে না। আমি এই নিশ্চয়তা দিচ্ছি যে, আমি এই সংক্রান্ত উপরক্ত সম্মতিপত্র পুরোপুরি পড়েছি এবং সংশ্লিষ্ট প্রয়োজনীয় বিষয়গুলো যথাযথ ভাবে আমাকে ব্যাখ্যা করা হয়েছে। আমি স্বজ্ঞানে স্বেচ্ছায় অঙ্গীকার নামাটি পড়েছি এবং সম্মতি স্বাক্ষর করছি। -->
                                 I/ We do hereby abide by the rules and regulation of the Hospital. The above information given by myself is true and if my information proves to be false. I shall be liable for that. 

                                </div>
                            </td>
                        </tr>
                    </table>
                    <h6 style="text-align: left; font-weight: bold; ">I AGREE THAT I HAVE READ AND UNDERSTOOD THE ABOVE STATEMENTS</h6>
                    <p style="margin-top: 40px;margin-bottom:10px;">
                    Patient's Guardian Signature
                    </p>
                    <table border="0" width="100%" align="center">
						<tr>
                            <th class="text-left" width="19%">Guardian Name </th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->full_name ?></td>
                        
                            <th class="text-center" width="50%" valign="bottom" colspan="3" rowspan="3">Authority Signature</th>
                        </tr>
						<tr>
                            <th class="text-left" width="19%">Relationship </th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->relation_of_patient ?></td>
                        </tr>
						<tr>
                            <th class="text-left" width="19%">Date</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= date("d/m/Y", strtotime($value->admission_date))?></td>
                        </tr>
                    </table>
                <?php //$this->load->view('admin/common/report_footer') ?>
            </div>
        </div>
    </section>

<!-- <style type="text/css">
    @media print{
        @page{
            size:A4;
            margin:30mm 0 0 0!important;
        }
    }
</style> -->