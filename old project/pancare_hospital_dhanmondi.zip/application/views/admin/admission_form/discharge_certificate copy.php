<section class="content">
    <div id="invoice">
        <div class="report_header">
        <?php $this->load->view('admin/common/report_header_admission_form') ?>
        </div>
        
        <div class="container">
            <div class="row">
                <div class="form-group col-sm-12 col-xs-12">
                    <h4 style="text-align: center; font-weight: bold;"><span style="border:2px solid #000; border-radius:10px; padding:5px;">DISCHARGE CERTIFICATE</span></h4><br/>
					<div style="border:2px solid #000;">
					<table class="" border="0" width="100%" align="center" style="margin:10px;">
						<tr>
                            <th class="text-left" width="19%">Registration No</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->registration_no;?></td>

                            <th class="text-right" width="19%">Admission Date</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= isset($value)?date('d-m-Y', strtotime($value->admission_date)):'';?> <?= date('h:i A', strtotime($value->admission_created_at));?></td>
                        </tr>
						<tr>
                            <th class="text-left" width="19%">Patient Name</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->patient_name;?></td>

                            <th class="text-right" width="19%">Discharge Date</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= date('d-m-Y h:i A');?></td>
                        </tr>
						<tr>
                            <th class="text-left" width="19%">Father's Name</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->patient_father_name;?></td>

                            <th class="text-right" width="19%">Spouse Name</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->patient_spouse_name;?></td>
                        </tr>
						<tr>
                            <th class="text-left" width="19%">Mother's Name</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->patient_mother_name;?></td>

                            <th class="text-right" width="19%">Blood Group</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->patient_blood_group;?></td>
                        </tr>
						<tr>
                            <th class="text-left" width="19%">Gender</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->patient_gender;?></td>

                            <th class="text-right" width="19%">Age</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->patient_age;?> YRS</td>
                        </tr>
						<tr>
                            <th class="text-left" width="19%" rowspan="2">Address</th>
                            <th class="text-left" width="1%" rowspan="2">:</th>
                            <td class="text-left" width="30%" rowspan="2"><?= $value->patient_address;?></td>

                            <th class="text-right" width="19%">Mobile No</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->patient_mobile;?></td>
                        </tr>
					</table>
					</div><br/>
					
					<table width="100%" border="0" align="center">
						<tbody>
							<tr class="text-uppercase">
								<th width="100%" colspan="3" class="text-center" valign="top">
									&nbsp;
								</th>
							</tr>
							
							<tr class="text-uppercase">
								<th width="50%" style="border:2px dashed #000;" class="bd-dashed text-16 text-center">OPERATION NOTE</th>
								<th width="50%" style="border:2px dashed #000;" class="bd-dashed text-16 text-center">TREATMENT ON DISCHARGE
								<a class="btn btn-info no_print" href="<?= base_url("admission_form/make_prescription/$value->operation_invoice_record_id");?>">Make Prescription</a>
								</th>
							</tr>
							
							<tr class="text-uppercase">
								<th width="50%" style="border-bottom:2px dashed #000; border-left:2px dashed #000; padding:3px;" valign="top">
									<h6 style="padding-top:0px;"> &nbsp; <i class="fa fa-circle-thin"></i> &nbsp; INDICATION	: <?= $value->indication;?></h6>
									<h6 style="padding-top:25px;"> &nbsp; <i class="fa fa-circle-thin"></i> &nbsp; OPERATION 	: <?= $value->operation_name;?></h6>
									<h6 style="padding-top:25px;"> &nbsp; <i class="fa fa-circle-thin"></i> &nbsp; SURGEON	: <?= isset($value)?$value->sergeon_name:'';?></h6>
									<h6 style="padding-top:25px;"> &nbsp; <i class="fa fa-circle-thin"></i> &nbsp; ANAESTHESIOLOGIST 	: <?= $value->anesthesia_name;?></h6>
									<h6 style="padding-top:25px;"> &nbsp; <i class="fa fa-circle-thin"></i> &nbsp; ANAESTHESIA  	: <?= $value->anesthersiologist;?></h6>
									<h6 style="padding-top:25px;"> &nbsp; <i class="fa fa-circle-thin"></i> &nbsp; AST. SURGEON   	:<?= $value->surgeon_assistant;?></h6>
									<h6 style="padding-top:25px;"> &nbsp; <i class="fa fa-circle-thin"></i> &nbsp; Do(1)-   	: <?= $value->assistant1;?></h6>
									<h6 style="padding-top:25px;"> &nbsp; <i class="fa fa-circle-thin"></i> &nbsp; Do(2)-   	: <?= $value->assistant2;?></h6>
									<h6 style="padding-top:25px;"> &nbsp; <i class="fa fa-circle-thin"></i> &nbsp; FINDING’S: <?= $value->findings;?></h6>
									<h6 style="padding-top:25px;"> &nbsp; <i class="fa fa-circle-thin"></i> &nbsp; BABY SEX 	: <?= $value->baby_sex;?></h6>
									<h6 style="padding-top:25px;"> &nbsp; <i class="fa fa-circle-thin"></i> &nbsp; BABY WEIGHT: <?= $value->baby_weight;?></h6>
									
									
								</th>
								<th width="50%" style="border-bottom:2px dashed #000; border-left:2px dashed #000; border-right:2px dashed #000;" valign="top">
									<?php 
										if(isset($prescribed_medicines) && sizeof($prescribed_medicines) > 0) { ?>

										
									<img src="<?php echo site_url('assets/img/rx-icon.png'); ?>" alt="RX" height="20" style="margin-bottom: 15px; margin-top: 10px;">
									
									<?php foreach($prescribed_medicines as $row){
												
									?>
									<table>
										<thead></thead>
										<tbody>
												<tr>
													<td style="width: 1%;"><?=++$i.'.'?></td>
													<td>
														<b>
														<?= $row->product_name ?><br>
														<?= isset($row->generic_name) ? $row->generic_name:''?>
													</b>
													</td>
													<td> <?=$row->dose?>
														<span style="font-size:14px;">(<?=$row->meal_type_name?>)</span><br>
														<?=$row->days?> Days
													</td>
												
												</tr>
										</tbody>
									</table>
										
									<?php 
											} 
										} 
									?>
									<!-- <span style="max-height:10000px; !important">&nbsp;</span> -->
								</th>
							</tr>
						</tbody>
					</table>
					
					<style>
					@media print {
						.instruction { 
							page-break-before: always;
						 }
					}
					</style>
					
					<table class="instruction" width="100%" border="0" align="center">
						<tbody>
							<tr class="text-uppercase">
								<th width="100%" colspan="3" class="text-center" valign="top">
									&nbsp;
								</th>
							</tr>
							
							<tr class="text-uppercase">
								<th style="border:2px dashed #000;" class="bd-dashed text-16 text-center" colspan="2">NOTE / INSTRUCTIONS</th>
							</tr>
							
							<tr class="text-uppercase">
								<th width="50%" style="border-bottom:2px dashed #000; border-left:2px dashed #000;" valign="top">
									<h6 class="mg-t-10"> &nbsp; <i class="fa fa-circle-thin"></i>  &nbsp;......দিন পর পর ড্রেসিং করাবেন  ।</h6>
									<h6> &nbsp; <i class="fa fa-circle-thin"></i> &nbsp;......দিন পর সেলাই কাটবেন  ।</h6>
									<h6> &nbsp; <i class="fa fa-circle-thin"></i> &nbsp;......মাস/সপ্তাহ/দিন পর দেখাবেন  ।</h6>
									<h6> &nbsp; <i class="fa fa-circle-thin"></i> &nbsp;......মাস/সপ্তাহ/দিন  বিশ্রামে থাকবেন  ।</h6>
									<h6> &nbsp; <i class="fa fa-circle-thin"></i> &nbsp;......মাস/সপ্তাহ/দিন  ভারী কাজ নিষেধ  ।</h6>
									<h6> &nbsp; <i class="fa fa-circle-thin"></i> &nbsp;......বৎসর পর বাচ্চা নিবেন ।</h6> 
									<h6> &nbsp; <i class="fa fa-circle-thin"></i> &nbsp;......দিন  পর প্লাস্টার খুলতে আসবেন ।</h6> 
									<h6> &nbsp; <i class="fa fa-circle-thin"></i> &nbsp;......দিন  পর্যন্ত শারীরিক মিলন নিষিদ্ধ  ।</h6>
								</th>
								<th width="50%" style="border-bottom:2px dashed #000; border-left:2px dashed #000; border-right:2px dashed #000;" valign="top">
									<h6 class="mg-t-5"> &nbsp; <i class="fa fa-circle-thin"></i> &nbsp;নিয়মিত ঔষধ খাবেন  ।</h6>
									<h6> &nbsp; <i class="fa fa-circle-thin"></i> &nbsp;বাচ্চাকে বুকের দুধ খাওয়াবেন  ।</h6>
									<h6> &nbsp; <i class="fa fa-circle-thin"></i> &nbsp;হাত/পায়ের আঙ্গুল নাড়াবেন ।</h6>
									<h6> &nbsp; <i class="fa fa-circle-thin"></i> &nbsp;প্লাস্টার ভিজাবেন না  ।</h6>
									<h6> &nbsp; <i class="fa fa-circle-thin"></i> &nbsp;কোন সমস্যা হলে যোগাযোগ করবেন ।</h6>
									<h6> &nbsp; <i class="fa fa-circle-thin"></i> &nbsp;বেশী বেশী পানি পান করবেন ।</h6>
									<h6> &nbsp; <i class="fa fa-circle-thin"></i> &nbsp;চর্বি  জাতীয়  খাবার কম খাবেন ।</h6>
									<h6> &nbsp; <i class="fa fa-circle-thin"></i> &nbsp;নিয়মিত টিকা দিবেন ।</h6>
								</th>
							</tr>
						</tbody>
					</table>
            </div>
        </div>
    </section>

<style type="text/css">
    @media print{
        @page{
            size:A4;
            margin:30mm 0 0 0!important;
        }
    }
</style>