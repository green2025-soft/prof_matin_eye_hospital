<section class="content">
    <div id="invoice">
        <div class="report_header">
        <?php $this->load->view('admin/common/report_header') ?>
        <?php //$this->load->view('admin/common/report_header_admission_form') ?>
        </div>
        
        <div class="container">
            <div class="row">
                <div class="form-group col-sm-12 col-xs-12">
                    <!-- <hr style="border: 1px solid #d4d9d8 !important; padding: 0px; margin: 3px;"> -->
                    <!-- <h4 style="text-align: center; font-weight: bolder; ">ADMISSION FORM</h4> -->
                    <?php $this->load->view('admin/common/dr_visit_chart_header_barcode'); ?>
					
					<table class="mt-5" border="0" width="100%" align="center" cellpadding="5">
					    <tr>
                            <th class="text-left" >Adm. No</th>
                            <td class="text-left" >: <?= $value->admission_no;?></td>
                            <td class="text-left"><b>Patient </b>: <?= $value->patient_name;?></td>
                            <td class="text-right"><b>Age</b>: <?= $value->patient_age;?> YRS</td>
                        </tr>	
                        <tr>
                            <th class="text-left" >Surgeon</th>
                            <td class="text-left"  colspan="3">: 
                                <?= $value->sergeon_name.' - '.$value->sergeon_designation;?>
                            </td>
                        </tr>
					</table>

                    <table class="mt-25 table table-bordered">
						<thead>
                            <tr>
                                <th style="text-align:center" width="20%" valign="middle"><p>VISIT NUMBER</p></th>
                                <th style="text-align:center" width="35%" valign="middle"><p>DATE</p></th>
                                <th style="text-align:center" width="20%" valign="middle"><p>TIME</p></th>
                                <th style="text-align:center" width="25%" valign="middle"><p>SIGNETURE</p></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php for($i = 0; $i < 18; $i++) {?>
                            <tr>
                                <td class="text-center"><p>&nbsp;</p></td>
                                <td class="text-center"><p>&nbsp;</p></td>
                                <td class="text-center"><p>&nbsp;</p></td>
                                <td class="text-center"><p>&nbsp;</p></td>
                            </tr>
                            <?php }?>
                        </tbody>
                    </table>
            </div>
        </div>
    </section>

<!-- <style type="text/css">
    @media print{
        @page{
            size:A4;
            margin:25mm 0 0 0!important;
        }
    }
</style> -->