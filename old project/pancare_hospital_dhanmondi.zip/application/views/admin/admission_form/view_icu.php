<section class="content">
    <div id="invoice">
        <div class="report_header">
        <?php $this->load->view('admin/common/report_header_admission_form') ?>
        </div>
        
        <div class="container">
            <div class="row">
                <div class="form-group col-sm-12 col-xs-12">
                    <!-- <hr style="border: 1px solid #d4d9d8 !important; padding: 0px; margin: 3px;"> -->
                    <!-- <h4 style="text-align: center; font-weight: bolder; ">ADMISSION FORM</h4> -->
                    <?php $this->load->view('admin/common/admission_header_barcode_icu'); ?>
					
					<table class="mt-5" border="0" width="100%" align="center">
						<tr>
                            <th class="text-left" width="19%">ভর্তি নং <Noscript></Noscript></th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->admission_no;?></td>

                            <th class="text-right" width="19%">ভর্তির তারিখ</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= isset($value)?date('d-m-Y', strtotime($value->admission_date)):'';?> <?= date('h:i A', strtotime($value->admission_created_at));?></td>
                        </tr>
						<tr>
                            <th class="text-left" width="19%">রোগীর নাম</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->patient_name;?></td>

                            <th class="text-right" width="19%">বয়স</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->patient_age;?> YRS</td>
                        </tr>
						<tr>
                            <th class="text-left" width="19%">লিঙ্গ</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->patient_gender;?></td>
                            <th class="text-right" width="19%">পিতা/ স্বামী</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->patient_father_name;?></td>
                        </tr>
                        <tr>
                            <th class="text-left" width="19%">আইডি নং</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"></td>
                            <th class="text-right" width="19%">আইপি নং</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"></td>
                        </tr>
						<tr>
                            <th class="text-left" width="19%">ঠিকানা</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->village.', '.$value->post_office.', '.$value->thana.', '.$value->district;?></td>

                            <th class="text-right" width="19%">ফোন/ মোবাইল</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->patient_mobile;?></td>
                        </tr>
                        <tr>
                            <th class="text-left" width="19%">বেড</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%" colspan="2"><?php echo $value->opd_cabin_ward." - ". $value->bed_no ." - ". $value->bed_type ." - ". $value->room_no ." - ". $value->floor_no; ?></td>
                        </tr>
                        <tr>
                            <!-- <th class="text-left" width="19%">চিকিৎসক</th>
                            <th class="text-left" width="1%" >:</th>
                            <td class="text-left" width="30%"><?=isset($value)?$value->sergeon_name.' - '.$value->sergeon_designation:''?></td> -->

                        </tr>
                        
					</table>

                    
                    <br>
                    <table class="" border="0" width="100%" align="center" >
                        <tr>
                            <td colspan="">
                                <div style="text-align:justify; padding:5px;">
                                <b>আমি :</b><?= $value->full_name ?><br>
                                <b>পিতা/ স্বামী :</b><br>
                                <b>ঠিকানা :</b><?= $value->re_address ?><br>
                                <b>ফোন/ মোবাইল :</b><?= $value->guardian_phone ?><br><br>

                                এই সম্মতিপত্রের মাধ্যমে আমাকে / আমার রোগী (রোগীর) নাম <b><?= $value->patient_name;?></b> সম্পর্ক <b><?= $value->relation_of_patient;?></b> আইসিইউ / এন আইসিইউ এর বিভিন্ন দিকসমূহ ও উহার ফলাফল সম্পর্কে কর্তব্যরত চিকিৎসক আমাকে অবগত করেছেন। আমাকে / আমার রোগীকে আইসিইউ / এন আইসিইউ বিভাগে চিকিৎসা চলাকালে প্রয়োজনীয় যে কোন বিকল্প ব্যবস্থা গ্রহণেরও অনুমতি প্রদান করিতেছি। আইসিইউ / এন আইসিইউ বিভাগে চিকিৎসা জনিত কোন দুর্ঘটনার জন্য হাসপাতাল কর্তৃপক্ষ দায়ী থাকিবে না।

                                </div>
                            </td>
                        </tr>
                    </table>
<br>
                    <table class="" border="0" width="100%" align="center"  cellpadding="5">
                        <tr>
                            <td>সাক্ষর </td>
                            <td width="30%" style="border-bottom:dotted 2px #000;"></td>
                            <td>তারিখ </td>
                            <td width="30%" style="border-bottom:dotted 2px #000;"></td>
                            <td>সময়</td>
                            <td width="30%" style="border-bottom:dotted 2px #000;"></td>
                            
                        </tr>
                    </table>
                   
                    <p style="margin-top: 40px;margin-bottom:10px;">
                    আমি রোগীকে / রোগীর আভিভাবককে আইসিইউ / এন আইসিইউ এর বিভিন্ন দিক ও তার ফলাফল সম্বন্ধে অবগত করিয়াছি।
                    </p>
                    <br>
                    <table border="0" cellpadding="10" width="40%">
						<tr>
                            <th class="text-left">ডাঃ সাক্ষর </th>
                            <td width="1%">:</td>
                            <td width="50%" style="border-bottom:dotted 2px #000;"></td>
                        </tr>
						<tr>
                            <th class="text-left">ডাঃ নাম </th>
                            <td>:</td>
                            <td style="border-bottom:dotted 2px #000;"></td>
                        </tr>
                        <tr>
                            <th class="text-left" >তারিখ </th>
                            <td class="text-left">:</td>
                            <td style="border-bottom:dotted 2px #000;"></td>
                        </tr>
						<tr>
                            <th class="text-left">সময়</th>
                            <td class="text-left">:</td>
                            <td style="border-bottom:dotted 2px #000;"></td>
                        </tr>
                    </table>
                <?php //$this->load->view('admin/common/report_footer') ?>
            </div>
        </div>
    </section>

<style type="text/css">
    @media print{
        @page{
            size:A4;
            margin:30mm 0 0 0!important;
        }
    }
</style>