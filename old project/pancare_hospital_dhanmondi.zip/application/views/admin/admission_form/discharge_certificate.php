<style>

body{
    font-family:Arial;
    font-size:16px;
}

.form{
    width:900px;
    margin:auto;
}

.title{
    text-align:center;
    font-size:24px;
    font-weight:bold;
    text-decoration:underline;
    margin-bottom:25px;
}

.line{
    display:inline-block;
    border-bottom:1px solid #444;
	height: 25px;
	font-weight: bold;
	text-align: center;
}

.long{
    width:480px;
}

.medium{
    min-width:220px;
}

.small{
    min-width:110px;
}

.xsmall{
    min-width:70px;
}



.weight-table td{
    padding:2px 5px;
}



.clear{
    clear:both;
}

.row-space{
    margin-top:18px;
}

.weight-left{
    border-left:2px solid #555;
    padding-left:12px;
}

.weight-table{
    float:right;
    border-collapse:collapse;
}
@page {
	size: A4 portrait; 
}
</style>

<section class="content">
	<div id="invoice">
		<div class="report_header">
		<?php $this->load->view('admin/common/report_header') ?>
			
		</div>
		<div class="container">
			<div class="form">
				<div class="title">DISCHARGE CERTIFICATE</div>
				<div class="row">
					<div class="col-xs-6">
						Regn. #
						<span class="line medium">&nbsp;<?= $value->admission_no; ?> </span>
						<br><br>
						Cabin/Ward 
						<span class="line medium">&nbsp;
							<!-- <?= $value->opd_cabin_ward." - ". $value->bed_no ." - ". $value->bed_type ." - ". $value->room_no ." - ". $value->floor_no;?> -->
						</span>
					</div>
					<div class="col-xs-6">
						<table class="weight-table">
							<tr>
								<td rowspan="2" style="font-size:18px;padding-right:10px;">
									WEIGHT
								</td>
								<td class="weight-left">
								On admission 
								<span class="line medium">&nbsp;<?= $value->weight_on_admission ?></span>
								</td>
							</tr>
							<tr>
								<td class="weight-left">On discharge :
									<span class="line medium">&nbsp;<?= $value->weight_on_discharge ?></span>
								</td>
							</tr>
						</table>
					</div>
				</div>
				<div class="clear"></div>
				<div class="row-space"></div>
				<div>
					Name
					<span class="line" style="min-width:560px;">&nbsp;<?= $value->patient_name; ?></span> &nbsp;&nbsp;
					Age
					<span class="line xsmall">&nbsp;<?= $value->patient_age; ?></span>&nbsp;
					Sex
					<span class="line small">&nbsp;<?= $value->patient_gender; ?></span>
				</div>
				<br>
				<div>
					Father's/Husband's name
					<span class="line" style="min-width:690px;">&nbsp;<?= $value->patient_father_name??$value->patient_spouse_name;?></span>
				</div>
				<br>
				<div>
					Mother's name
					<span class="line" style="min-width:770px;">&nbsp;<?= $value->patient_mother_name;?></span>
				</div>
				<br>
				<div>
					<?php 
					$address = $value->village;
					$address .= $value->post_office?', '.$value->post_office:'';
					$address .= $value->thana?', '.$value->thana:'';
					$address .= $value->district?', '.$value->district:'';
					?>
					Address with Phone #
					<span class="line" style="min-width:720px;">&nbsp;<?=$address?> <?= $value->patient_mobile?', '.$value->patient_mobile:'';?></span>
				</div>
				<br>
				<div>
					Was admitted into this Hospital from
					<span class="line" style="min-width:330px;">&nbsp;<?= $value->admission_date ?></span>
					to
					<span class="line" style="min-width:270px;">&nbsp;
						<!-- <?= $value->release_date ?> -->
				</span>
				</div>
				<br>
				<div>
					Under Prof./Dr.
					<span class="line" style="min-width:770px;">&nbsp; 
						<!-- <?= $value->admitted_under ?> -->
					</span>
				</div>
				<br>
				<div>
					He/She was suffering from
					<span class="line" style="min-width:690px;">&nbsp;<?= $value->findings ?></span>
				</div>
				<br>
				<div>
					Special instruction
					<span class="line" style="min-width:750px;">&nbsp;<?= $value->indication ?></span>
				</div>
				<br>
				<div>
					Nature of Discharge
					<span class="line" style="min-width:740px;">&nbsp;<?= $value->others_note ?></span>
				</div>
				<br><br><br>
				<div style="
text-align:center;
font-size:18px;
font-weight:bold;
text-decoration:underline;
">

CASE SUMMARY / OPERATION NOTE / REFERRAL NOTE

</div>
			
			</div>
	

			<div class="row hide">
				<div class="col-md-12 col-sm-12">
					<center>
						<table class="discharge">
							<tbody>
								<tr>
									<td></td>
									<td>Admission No : </td>
									<td> <?= $value->admission_no; ?> </td>
									<td></td>
								</tr>
								<tr>
									<td></td>
									<td>Patient Name : </td>
									<td><?= $value->patient_name; ?></td>
									<td></td>
								</tr>
								<tr>
									<td></td>
									<td>Father : </td>
									<td><?= $value->patient_father_name; ?></td>
									<td></td>
								</tr>
								<tr>
									<td></td>
									<td>Spouse : </td>
									<td><?= $value->patient_spouse_name; ?></td>
									<td></td>
								</tr>
								<tr>
									<td></td>
									<td>Address : </td>
									<td><?= $value->village.', '.$value->post_office.', '.$value->thana.', '.$value->district; ?></td>
									<td></td>
								</tr>
								<tr>
									<td></td>
									<td>Age : </td>
									<td><?= $value->patient_age; ?></td>
									<td></td>
								</tr>
								<!-- <tr>
								<td></td>
								<td>গ্রাম</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td></td>
								<td>থানা</td>
								<td></td>
								<td></td>
							</tr> -->
								<tr>
									<td></td>
									<td>Admission Date : </td>
									<td><?= isset($value) ? date('d-m-Y', strtotime($value->admission_date)) : ''; ?> <?= date('h:i A', strtotime($value->admission_created_at)); ?></td>
									<td></td>
								</tr>
								<tr>
									<td></td>
									<td>Operation Date : </td>
									<td><?= ($value->operation_date) ? $value->operation_date : "" ?></td>
									<td></td>
								</tr>
								<tr>
									<td></td>
									<td>Release Date : </td>
									<td><?= ($value->release_date) ? $value->release_date : "" ?></td>
									<td></td>
								</tr>
							</tbody>
						</table>
					</center>
				</div>
			</div>
			<style>
				@media print {
					.blank_page {
						page-break-before: always;
					}
				}
			</style>
			<!-- <div class="blank_page">

			</div> -->
			<style>
				@media print {
					.operation_note {
						page-break-before: always;
					}
				}
			</style>
			<div class="row operation_note hide" style="font-size: 25px;">
				<div class="col-md-12 col-sm-12 col-xs-12">
					<div class="row">
						<div class="col-md-4 col-sm-12"></div>
						<div class="col-md-4 col-sm-12">
							<h3 class="text-center">
								<span class="custom_border_style" style="border: 2px solid;padding: 5px;border-radius: 27%;">OPERATION NOTE</span>
							</h3>
						</div>
					</div>

					<p><b>INDICATION:</b> <?= $value->indication ?></p>
					<p><b>OPERATION:</b> <?= $value->operation_name ?></p>
					<p><b>SURGEON:</b> <?= $value->sergeon_name . " - " .$value->sergeon_designation?></p>
					<p><b>ANAESTHESIOLOGIST:</b> <?= $value->anesthesia_name. " - " .$value->anesthesia_designation ?></p>
					<p><b>ANAESTHESIA:</b> <?= $value->anesthersiologist ?></p>
					<p><b>ASSISTANT SURGEON:</b> <?= $value->surgeon_assistant ?></p>
					<p><b>Do(1)-:</b> <?= $value->assistant1 ?></p>
					<p><b>Do(2)-:</b> <?= $value->assistant2 ?></p>
					<p><b>Do(3)-:</b> <?= $value->assistant3 ?></p>
					<p><b>PROCEDURE & FINDING’S:</b> <?= $value->findings ?></p>
					<p><b>OTHER:</b> <?= $value->others_note ?></p>
				</div>
			</div>
			<style>
				@media print {
					.a4-page, .release_treatment {
						page-break-before: always;
					}
				}
			</style>
			<div class="row release_treatment hide">
				
			<div class="col-md-12 col-sm-12 col-xs-12 no_print">
					<a class="btn btn-info pull-right" href="<?= base_url("admission_form/make_prescription/$value->operation_invoice_record_id"); ?>">Discharge Treatment</a>
				</div>

				<div class="discharge_treatment col-md-12 col-sm-12 col-xs-12" style="font-size: 18px;">
					<h3 class="text-center">
						<span class="custom_border_style">বিদায়কালিন চিকিৎসাঃ</span>
					</h3>

					<?php
					if (isset($prescribed_medicines) && sizeof($prescribed_medicines) > 0) { ?>


						<img src="<?php echo site_url('assets/img/rx-icon.png'); ?>" alt="RX" height="20" style="margin-bottom: 15px; margin-top: 10px;">

						<table>
							<thead></thead>
							<tbody>
								<?php foreach ($prescribed_medicines as $row) {

								?>
									<tr>
										<td style="width: 1%;"><?= ++$i . '.' ?></td>
										<td>
											<b>
												<?= $row->product_name ?><br>
												<?= isset($row->generic_name) ? $row->generic_name : '' ?>
											</b>
										</td>
										<td> <?= $row->dose ?>
											<span style="font-size:14px;">(<?= $row->meal_type_name ?>)</span><br>
										</td>
										<td>
											<?= $row->days ?> Days/দিন
										</td>

									</tr>

								<?php
								} ?>
							</tbody>
						</table>
					<?php }
					?>
					<br>
					<hr>
					<p>
						<span style="font-weight:bold; font-size:25px">Advice</span> : <span style="font-size:25px"><?= isset($prescription) ? $prescription->advice : "" ?></span>
					</p>
				</div>
			</div>
			


			
			</th>
			</tr>
			</tbody>
			</table>

			
			<div class="a4-page">

				<!-- INVESTIGATIONS -->
				<div class="investigations">
					<h3 class="section-title">INVESTIGATIONS</h3>
				</div>

				<!-- Treatment Given During Admission -->
				<h3 class="section-title admission-title">
					TREATMENT GIVEN DURING ADMISSION
				</h3>

				<!-- Optional content area -->
				<div class="content-area admission-content">
					<!-- Add investigation/treatment details here -->
				</div>


				<!-- Treatment and Advice During Discharge -->
				<h3 class="section-title discharge-title">
					TREATMENT AND ADVICE DURING DISCHARGE
				</h3>

				<!-- Optional content area -->
				<div class="content-area discharge-content">
					<!-- Add discharge treatment/advice here -->
				</div>


				<!-- Follow Up -->
				<h3 class="section-title follow-up">
					FOLLOW UP
				</h3>

				<!-- Optional content area -->
				<div class="content-area follow-content">
					<!-- Add follow-up details here -->
				</div>


				<!-- Bottom signatures -->
				<div class="signature-area">

					<div class="signature-row">

						<div class="signature-column signature-left">
							<span class="signature-label">
								Chairman/Managing Director/Consultant
							</span>
						</div>

						<div class="signature-column signature-date">
							<span class="signature-label">
								Date :
							</span>
						</div>

						<div class="signature-column signature-right">
							<span class="signature-label">
								Medical Officer
							</span>
						</div>

					</div>

					<div class="footer-note"> Please preserve this certificate for future reference </div>

				</div>

			</div>
		</div>
	</div>
</section>

<!-- <style type="text/css">
	@media print {
		@page {
			size: A4;
			margin: 30mm 0 0 0 !important;
		}
	}
</style> -->

<style>
        @page {
            size: A4 portrait;
            
        }



        /* A4 paper */
        .a4-page {
            width: 210mm;
            margin: 10mm auto;
            padding: 12mm 9mm 10mm 9mm;
            background: #fff;
            position: relative;
            overflow: hidden;
        }

        /* Main headings */
        .section-title {
            text-align: center;
            /* font-size: 16px; */
            font-weight: bold;
            text-decoration: underline;
            margin: 0;
            line-height: 1.2;
        }

        .investigations {
            margin-top: 2mm;
        }

        .admission-title {
            margin-top: 11mm;
        }

        .discharge-title {
            margin-top: 100mm;
        }

        .follow-up {
            margin-top: 120mm;
			margin-bottom: 70mm;
        }



        .signature-row {
            display: table;
            width: 100%;
            table-layout: fixed;
        }

        .signature-column {
            display: table-cell;
            vertical-align: bottom;
        }

        .signature-left {
            width: 45%;
            text-align: left;
        }

        .signature-date {
            width: 25%;
            text-align: center;
        }

        .signature-right {
            width: 30%;
            text-align: right;
        }

        .signature-label {
            /* font-size: 15px; */
            font-weight: bold;
            font-style: italic;
            white-space: nowrap;
        }

        .footer-note {
            margin-top: 7mm;
            text-align: center;
            /* font-size: 15px; */
            font-weight: bold;
            font-style: italic;
        }

      

        @media print {
           
            .a4-page {
				    padding: initial;

            }

        }
    </style>