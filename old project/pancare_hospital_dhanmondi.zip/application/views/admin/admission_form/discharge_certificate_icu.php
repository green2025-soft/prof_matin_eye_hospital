<section class="content">
    <div id="invoice">
        <div class="report_header">
        <?php $this->load->view('admin/common/report_header_admission_form') ?>
        </div>
        
        <div class="container">
            <div class="row">
                <div class="form-group col-sm-12 col-xs-12">
                    <!-- <hr style="border: 1px solid #d4d9d8 !important; padding: 0px; margin: 3px;"> -->
                    <!-- <h4 style="text-align: center; font-weight: bolder; ">ADMISSION FORM</h4> -->
                    <?php $this->load->view('admin/common/admission_header_barcode_icu_discharge'); ?>
					
					<table class="mt-5" border="0" width="100%" align="center">
                    <tr>
                            <th class="text-left" width="19%">ভর্তি নং <Noscript></Noscript></th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->admission_no;?></td>

                            <!-- <th class="text-right" width="19%">ভর্তির তারিখ</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= isset($value)?date('d-m-Y', strtotime($value->admission_date)):'';?> <?= date('h:i A', strtotime($value->admission_created_at));?></td> -->
                        </tr>
                    <tr>
                        <th class="text-left" width="19%">রোগীর নাম</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->patient_name;?></td>

                            <th class="text-right" width="19%">বয়স</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"><?= $value->patient_age;?> YRS</td>
                        </tr>
						
                        <tr>
                            <th class="text-left" width="19%">আইডি নং</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"></td>
                            <th class="text-right" width="19%">আইপি নং</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%"></td>
                        </tr>
                        <tr>
                       
                        <th class="text-left" width="19%">বেড</th>
                            <th class="text-left" width="1%">:</th>
                            <td class="text-left" width="30%" colspan="2"><?php echo $value->opd_cabin_ward." - ". $value->bed_no ." - ". $value->bed_type ." - ". $value->room_no ." - ". $value->floor_no; ?></td>
                            
                        </tr>
					</table>

                    
                    <br>
                    <table class="" border="0" width="100%" align="center" >
                        <tr>
                            <td colspan="">
                                <div style="text-align:justify; padding:5px;">
                                আমি নিম্ন স্বাক্ষরকারী ....................................আইসিইউ বেড নং <b><?= $value->bed_no ?></b> তে ভর্তিকৃত আমার রোগী <b><?= $value->patient_name;?></b> এর বর্তমান অবস্থা সম্পর্কে সম্পূর্ণরূপে অবগত আছি। কর্তব্যরত ডাক্তার আমার রোগীর অবস্থা সম্পর্কে আমাকে এবং উপস্থিত সকলকে বিস্তারিত অবহিত করেছেন। রোগীর অবস্থা সংকটাপন্ন জানা সত্ত্বেও আমার রোগীকে আইসিইউ থেকে নিয়ে যেতে চাচ্ছি।<br><br>

                                রোগীকে রোগীকে আইসিইউ থেকে বের করে নিয়ে গেলে রোগীর শারীরিক অবস্থা আরও খারাপ হয়ে যেতে পারে, এমনকি রোগীর মৃত্যুও ঘটতে পারে; এ বিষয়ে সম্যক অবগত হয়ে আমি স্বেচ্ছায় আমার রোগীকে হাসপাতাল থেকে নিজ দায়িত্বে নিয়ে গেলাম। 
                                </div>
                            </td>
                        </tr>
                    </table>
<br>
                    <table class="" border="0" width="100%" align="center"  cellpadding="5" style="text-align: center;">
                        <tr>
                            <td width="5%">সাক্ষর</td>
                            <td colspan="2" width="45%" style="border-bottom:dotted 2px #000;"></td>
                            <td width="20%">সাক্ষর গ্রহণকারী </td>
                            <td colspan="2" width="30%" style="border-bottom:dotted 2px #000;"></td>
                        </tr>
                        <tr>
                            <td >নাম:</td>
                            <td colspan="5" style="border-bottom:dotted 2px #000;"></td>
                        </tr>
                        <tr>
                            <td>তারিখ:</td>
                            <td width="30%" style="border-bottom:dotted 2px #000;"></td>
                            <td>সময়: </td>
                            <td width="25% "style="border-bottom:dotted 2px #000;"></td>
                            <td>মোবাইল: </td>
                            <td width="35%"  style="border-bottom:dotted 2px #000;"></td>

                            
                        </tr>
                    </table>
                   
                    <p style="margin-top: 40px; background-color:#dfdfdf; padding:5px;">
                    * আমার রোগীর চিকিৎসার স্বার্থে রোগীর সাথে সংযুক্ত করা সকল CV Line / NG Tube / F. Catheter / IV Cannul খুলে দেয়া / সাথে না দেয়ার জন্য অনুরোধ করছি।
                    </p>
                    <p style="background-color:#dfdfdf; padding:5px;">
                    * আমার রোগীর জীবন রক্ষাথ দেয়া Endotracheal Tube খুলে দেয়ার জন্য অনুরোধ করছি। আমি এটি সম্পূর্ণরূপে অবগত আছি যে, এটি খুলে দেয়ার পরে আমার রোগী মারা যেতে পারে। 
                    </p>
                    <br>
                    <table class="" border="0" width="100%" align="center"  cellpadding="5" style="text-align: center;">
                        <tr>
                            <td width="5%">সাক্ষর</td>
                            <td colspan="2" width="45%" style="border-bottom:dotted 2px #000;"></td>
                            <td width="20%">সাক্ষর গ্রহণকারী </td>
                            <td colspan="2" width="30%" style="border-bottom:dotted 2px #000;"></td>
                        </tr>
                        <tr>
                            <td >নাম:</td>
                            <td colspan="5" style="border-bottom:dotted 2px #000;"></td>
                        </tr>
                        <tr>
                            <td>তারিখ:</td>
                            <td width="30%" style="border-bottom:dotted 2px #000;"></td>
                            <td>সময়: </td>
                            <td width="25% "style="border-bottom:dotted 2px #000;"></td>
                            <td>মোবাইল: </td>
                            <td width="35%"  style="border-bottom:dotted 2px #000;"></td>

                            
                        </tr>
                    </table>
                    
                <?php //$this->load->view('admin/common/report_footer') ?>
            </div>
        </div>
    </section>

<style type="text/css">
    @media print{
        @page{
            size:A4;
            margin:30mm 0 0 0!important;
        }
    }
</style>