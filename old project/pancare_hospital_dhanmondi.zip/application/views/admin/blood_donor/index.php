<aside >
    <section class="content">
        <div class="row">
            <section class="col-xs-12 connectedSortable"> 
                <div class="box box-info ">
                <div class="box-header">
            <h3 class="box-title"><?= isset($page_title) ? $page_title : '' ?></h3>
            <form class="no_print" action="<?= base_url('blood_donor') ?>" method="GET">
              <div class="box-body">
                <div class="row">
                  <div class="col-md-2">
                    <div class="form-group">
                      <label for="from_date">From Date</label>
                      <input type="text" class="form-control search_datepicker" id="from_date" placeholder="YYYY-MM-DD" name="from_date" value="<?= isset($from_date) && !empty($from_date) ? $from_date : date('Y-m-d') ?>" autocomplete="off">
                    </div>
                  </div>
                  <div class="col-md-2">
                    <div class="form-group">
                      <label for="to_date">To Date</label>
                      <input type="text" class="form-control search_datepicker" id="to_date" placeholder="YYYY-MM-DD" name="to_date" value="<?= isset($to_date) && !empty($to_date) ? $to_date : date('Y-m-d') ?>" autocomplete="off">
                    </div>
                  </div>
                  
                  <div class="col-md-2">
                    <div class="form-group" style="margin-top: 25px;">
                      <button type="submit" class="pull-left btn btn-success">Search <i class="fa fa-search"></i></button>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
                    <div class="box-body">
                        <?php $this->load->view('admin/common/report_header') ?>
                        <div class="table-responsive">
                        <table id="example2" class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th style="text-align: center;">SL</th>
                                    <th style="text-align: center;">Date</th>
                                    <th style="text-align: center;">Invoice</th>
                                    <th style="text-align: center;">Donor</th>
                                    <th style="text-align: center;">Age</th>
                                    <th style="text-align: center;">Patient</th>
                                    <th style="text-align: center;">Doctor</th>
                                    <th style="text-align: center;">B.Group</th>
                                    <th style="text-align: center;">T.Name</th>
                                    <th style="text-align: center;">Sub_Total</th>
                                    <th style="text-align: center;">Paid</th>
                                    <th style="text-align: center;">Due</th>
                                    <th style="text-align: center;"  class="no_print">Remarks</th>
                                    <th style="text-align: center;"  class="no_print">Created</th>
                                    <th style="text-align: center;"  class="no_print">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $count = 0;
                                $totalAmount        = 0;
                                $totalPaidAmount    = 0;
                                $totalDueAmount     = 0;

                                foreach ($values as $single_value) {
                                    $count++;
                                    $invoice = $this->Common_model->findById('create_bill',array('record_id'=>$single_value->invoice_id));
                                    $totalAmount        += $single_value->sub_total_amount ?? 0;
                                    $totalPaidAmount    += $single_value->paid_amount ?? 0;
                                    $totalDueAmount     += $single_value->due_amount ?? 0;
                                    ?>
                                    <tr>
                                        <td style="text-align: center;"><?php echo $count; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->date; ?></td>
                                        <td style="text-align: center;"><?=isset($invoice)?$invoice->prefix.$invoice->invoice_no:''?></td>
                                         <td style="text-align: center;"><?php echo $single_value->donor_name; ?></td>
                                         <td style="text-align: center;"><?php echo $single_value->donor_age?></td>
                                        <td style="text-align: center;"><?=isset($single_value)?$single_value->name.'['.$single_value->patient_id.']':''?></td>
                                        <td style="text-align: center;"><?php echo $single_value->doctor_name; ?></td>
                                        
                                        <td style="text-align: center;"><?php echo $single_value->group_name; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->test_name; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->sub_total_amount; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->paid_amount; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->due_amount; ?></td>
                                        <td style="text-align: center;"  class="no_print"><?php echo $single_value->comments; ?></td>
                                        <td style="text-align: center;"  class="no_print"><?=creator($single_value->created_by)?></td>
                                        <td style="text-align: center;" class="no_print">
                                            <a class="btn btn-primary"
                                               href="<?=base_url("blood_donor/view2/$single_value->blood_donor_id"); ?>"><i class="fa fa-eye"></i>
                                            </a>
                                            <a class="btn btn-info"
                                               href="<?=base_url("blood_donor/edit/$single_value->blood_donor_id"); ?>"><i class="fa fa-pencil"></i>
                                            </a>
                                            <a class="btn btn-danger"
                                               href="<?=base_url("blood_donor/delete/$single_value->blood_donor_id"); ?>" onclick="return confirm('Are you sure to delete this record?')"><i class="fa fa-trash-o"></i>
                                            </a>
                                            <?php $class = "btn-success";
                                                if (admin()) {
                                                    $button_text = $single_value->show_hide;
                                                    if ($button_text == "Show") {
                                                        $class = "btn-success";
                                                    } else {
                                                        $class = "btn-danger";
                                                    }
                                                ?>
                                                    <a class="btn <?= $class ?> btnShowHide" href="javascript:void(0)" data-url="<?= base_url("crud/show_hide/blood_donors/record_id/$single_value->blood_donor_id"); ?>"><?= $button_text ?></i>
                                                    </a>
                                                <?php } ?>
                                        </td>
                                    </tr>
                                <?php } ?>
                                <tr>
                                    <th colspan="9" class="text-right">Total</th>
                                    <th  class="text-center"><?= $totalAmount ?></th>
                                    <th  class="text-center"><?= $totalPaidAmount ?></th>
                                    <th  class="text-center"><?= $totalDueAmount ?></th>
                                    <th colspan="3"  class="no_print"></th>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    </div>
                </div>
            </section>
        </div>
    </section>
</aside>

<style>
   
    @media print {
        @page {
            size: A4 landscape;
        }
        .print_aria{
            margin-top: 0px !important;
            padding-top: 0px !important;
        }
    }
</style>