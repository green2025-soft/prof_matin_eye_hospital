<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class CreateBill_model extends MY_Model {

  protected $timestamp  = false; 
  protected $table      = 'create_bill';
  protected $primaryKey = 'record_id';

  public function getPandingTestResult($fromDate, $toDate){
    $allData = $this->orderDesc()
        ->select('record_id, prefix, invoice_no, date, patient_id, admission_id, doctor_id, amount, sub_total, paid, due, delivery_date, delivery_time, created_by')
        ->where('date >=',  $fromDate)
        ->where('date <=',  $toDate)
        ->where('type', 'Test Invoice')
        ->get();
        $this->belongsTo($allData, 'patient_id', 'patient', 'record_id');
        $this->belongsTo($allData, 'doctor_id', 'doctor', 'record_id');

        
        foreach($allData as &$valeu){
          $testReports = $this->db->select('record_id')->where('invoice_id', $valeu->record_id)->get('test_reports')->result_array()??[];
          $reportsIds = array_column($testReports, 'record_id');
          $resultsTestIds = [];
          if ($reportsIds){
            $testResults = $this->db->select('test_name_id')->where_in('test_report_id', $reportsIds)->get('test_report_names')->result_array()??[];
            $resultsTestIds = array_column($testResults, 'test_name_id');
          }

          
          $pandingQuery = $this->db->select('tn.test_name, tc.test_category')
          ->from('sales_test st')
          ->join('test_name tn', 'tn.record_id = st.test_id', 'left')
          ->join('test_category tc', 'tc.record_id = st.test_category_id', 'left')
          ->where_not_in('st.test_category_id', [11,12,13,19,20,21])
          ->where('st.invoice_no', $valeu->record_id);
          if($resultsTestIds){
            $this->db->where_not_in('st.test_id', $resultsTestIds);
          }
          
          $pandingTast = $pandingQuery->get()->result(); 

          $valeu->pandingTast = $pandingTast;

        }


        return $allData;

  }

}
?>