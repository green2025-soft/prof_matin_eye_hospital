<?php

defined('BASEPATH') or exit('No direct script access allowed');

class PrescriptionDetails_model extends MY_Model
{

    protected $table = 'prescription_details';
    protected $primaryKey = 'record_id'; 

    public function __construct()
    {
        parent::__construct();
      
    }


    

}
