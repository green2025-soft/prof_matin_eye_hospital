<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Drug_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
      
    }

    public function get_generic()
    {
        $this->db->select('record_id, generic_name');
        $this->db->from('drug_generic');
        $this->db->order_by('generic_name', 'asc');
        $query = $this->db->get();
        return $query->result();
    }

    public function countAll($table, $where, $where_in = array(), $where_in_column = '', $groupByColumn = '')
    {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($where);
        if (count($where_in) && !empty($where_in_column))
            $this->db->where_in($where_in_column, $where_in);
        if (!empty($groupByColumn))
            $this->db->group_by($groupByColumn);
        return $this->db->count_all_results();
    }

    function getAllPaginatedMedicines($genericNameId, $productId, $limit, $offset){

        $this->db->select('drug_generic.generic_name,
        drug_medicine.record_id,
        drug_dosage.dosage_name,
        drug_manufacturer.manufacturer_name,
        drug_medicine.brand_name,
        drug_medicine.strength')
                ->from('drug_medicine')
                ->join('drug_generic', 'drug_generic.record_id = drug_medicine.generic_id', 'left')
                ->join('drug_dosage', 'drug_dosage.record_id = drug_medicine.dosage_id', 'left')
                ->join('drug_manufacturer', 'drug_manufacturer.record_id = drug_medicine.manufacturer_id', 'left');

        if($genericNameId > 0){
            $this->db->where('generic_id', $genericNameId);
        }

        if($productId > 0){
            $this->db->where('drug_medicine.record_id', $productId);
        }

        $this->db->limit($limit, $offset);

        $this->db->order_by('drug_generic.generic_name', 'ASC')->group_by('drug_medicine.record_id');

        return $this->db->get()->result();
    }

    public function findAll($table, $where, $orderBy, $serialized)
    {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($where);

        if (is_array($orderBy)) {
            foreach ($orderBy as $key => $value) {
                $this->db->order_by($value, $serialized);
            }
        } else {
            $this->db->order_by($orderBy, $serialized);
        }
        $query = $this->db->get();
        return $query->result();
    }

    public function findById($where)
    {
        $this->db->select('drug_generic.generic_name,
        drug_medicine.record_id,
        drug_dosage.dosage_name,
        drug_manufacturer.manufacturer_name,
        drug_manufacturer.contact_no,
        drug_manufacturer.record_id as supplier_id,
        drug_medicine.brand_name,
        drug_medicine.dosage_id,
        drug_medicine.generic_id,
        drug_medicine.manufacturer_id,
        drug_medicine.strength')
        ->from('drug_medicine')
                ->join('drug_generic', 'drug_generic.record_id = drug_medicine.generic_id', 'left')
                ->join('drug_dosage', 'drug_dosage.record_id = drug_medicine.dosage_id', 'left')
                ->join('drug_manufacturer', 'drug_manufacturer.record_id = drug_medicine.manufacturer_id', 'left');
        $this->db->where($where);
        $query = $this->db->get();
        return $query->row();
    }

    public function drugfindById($table, $where)
    {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($where);
        $query = $this->db->get();
        return $query->row();
    }

    public function saveData($table, $data)
    {
        $this->db->insert($table, $data);
        $last_id = $this->db->insert_id();
        return $last_id;
    }

    function getAllMedicines()
    {
        $this->db->select('drug_generic.generic_name,
        drug_medicine.record_id,
        drug_dosage.dosage_name,
        drug_manufacturer.manufacturer_name,
        drug_medicine.brand_name,
        drug_medicine.strength')
                ->from('drug_medicine')
                ->join('drug_generic', 'drug_generic.record_id = drug_medicine.generic_id', 'left')
                ->join('drug_dosage', 'drug_dosage.record_id = drug_medicine.dosage_id', 'left')
                ->join('drug_manufacturer', 'drug_manufacturer.record_id = drug_medicine.manufacturer_id', 'left');
        $this->db->order_by('drug_generic.generic_name', 'ASC');
        return $this->db->get()->result();
    }

    function getAllMedicines_list($where)
    {
        $this->db->select('drug_generic.generic_name,
        drug_medicine.record_id,
        drug_dosage.dosage_name,
        drug_manufacturer.manufacturer_name,
        drug_medicine.brand_name,
        drug_medicine.strength')
                ->from('drug_medicine')
                ->join('drug_generic', 'drug_generic.record_id = drug_medicine.generic_id', 'left')
                ->join('drug_dosage', 'drug_dosage.record_id = drug_medicine.dosage_id', 'left')
                ->join('drug_manufacturer', 'drug_manufacturer.record_id = drug_medicine.manufacturer_id', 'left');
        $this->db->order_by('drug_generic.generic_name', 'ASC');
        $this->db->where($where);
        return $this->db->get()->result();
    }

    function getAllMedicines_by_supplier($supplier_id)
    {
        $this->db->select('drug_generic.generic_name,
        drug_medicine.record_id,
        drug_dosage.dosage_name,
        drug_manufacturer.manufacturer_name,
        drug_medicine.brand_name,
        drug_medicine.strength'
        )
                ->from('drug_medicine')
                ->join('drug_generic', 'drug_generic.record_id = drug_medicine.generic_id', 'left')
                ->join('drug_dosage', 'drug_dosage.record_id = drug_medicine.dosage_id', 'left')
                ->join('drug_manufacturer', 'drug_manufacturer.record_id = drug_medicine.manufacturer_id', 'left');
        $this->db->order_by('drug_generic.generic_name', 'ASC');
        //$this->db->where('drug_medicine.manufacturer_id', $supplier_id);
        //$this->db->limit(1000);
        return $this->db->get()->result();
    }
    

    

}
