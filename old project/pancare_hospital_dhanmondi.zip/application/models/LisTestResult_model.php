<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class LisTestResult_model extends MY_Model {

   protected $timestamp = false; 
  protected $table = 'test_result_lis';

}
?>