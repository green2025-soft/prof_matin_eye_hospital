<?php

defined('BASEPATH') or exit('No direct script access allowed');

class PrescriptionTemplateItem_model extends MY_Model
{

    protected $table = 'prescription_template_items';
    protected $primaryKey = 'record_id'; 

    public function __construct()
    {
        parent::__construct();
      
    }


    

}
