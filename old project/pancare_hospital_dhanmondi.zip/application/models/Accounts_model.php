<?php defined('BASEPATH') OR exit('No direct script access allowed');

/* ==========================================================
Method Name			: Accounts Model Information
Author Name			: Wadudur Rahman
Author E-mail		: info.wadud1014@gmail.com
Copyright			: 2019 Wadudur Rahman
=========================================================== */

class Accounts_model extends CI_Model 
{	
	
	/* ------------------------------------------------------
	Chart of Accounts List Model
	------------------------------------------------------- */
	function chart_of_accounts_list()
	{	
		$accounts_type =  $this->db->select("*")
		->from('accounts_type')
		->order_by('accounts_type_code', 'ASC')  
		->get()
		->result();
		
		$output = '';
		foreach($accounts_type as $accounts_type_row)
		{?> 
			<tr class="text-uppercase">
				<th class="text-left"><?= $accounts_type_row->accounts_type_code ;?></th>
				<th class="text-left"><?= $accounts_type_row->accounts_type_name ;?></th>
				
				<th class="text-center"></th>
				<th class="text-center"><?php if ($accounts_type_row->accounts_type_status ==1 ) {?> <span><?= $this->lang->line('active');?></span><?php } else {?> <span><?= $this->lang->line('inactive');?></span> <?php }?></th>
				
				<th class="text-center d-print-none" width="10%">
				<button class="btn-outline-info bg-info" data-toggle="modal" onclick="action_edit_model('<?= base_url("accounts/accounts_type_edit/$accounts_type_row->accounts_type_id");?>')" title="<?= $this->lang->line('edit');?>"><i class="fa fa-edit"></i></button>
				</th>
				<th class="text-left d-print-none">
					<!-- <button class="btn-outline-info" data-toggle="modal" onclick="action_add_model('<?= base_url("accounts/chart_of_accounts_add?accounts_category=$accounts_type_row->accounts_type_id");?>')" title="<?= $this->lang->line('add');?> <?= $this->lang->line('accounts');?>"><i class="fa fa-plus"></i></button> -->
				</th>
			</tr>
			<?php 
			$chart_of_accounts =  $this->db->select("*")
			->from('chart_of_accounts') 
			->join('accounts_link', 'chart_of_accounts.chart_of_accounts_link = accounts_link.accounts_link_id', 'LEFT')
			->where('chart_of_accounts_accounts_category', $accounts_type_row->accounts_type_id)
			->order_by('chart_of_accounts_code', 'ASC')
			->get()
			->result();
			
			foreach($chart_of_accounts as $chart_of_accounts_row)
			{?>
			<tr class="text-uppercase">
				<th class="text-left">&nbsp; &nbsp; <?= $chart_of_accounts_row->chart_of_accounts_code;?></th>
				<th class="text-left"><?= $chart_of_accounts_row->chart_of_accounts_name;?></th>
				
				<th class="text-center"><?= $chart_of_accounts_row->accounts_link_name;?></th>
				<th class="text-center"><?php if ($chart_of_accounts_row->chart_of_accounts_status ==1 ) {?> <span><?= $this->lang->line('active');?></span><?php } else {?> <span><?= $this->lang->line('inactive');?></span> <?php }?></th>
				
				<th class="text-center d-print-none" width="10%">
				<button class="btn-outline-warning bg-success" data-toggle="modal" onclick="action_edit_model('<?= base_url("accounts/chart_of_accounts_edit/$chart_of_accounts_row->chart_of_accounts_id");?>')" title="<?= $this->lang->line('edit');?>"><i class="fa fa-edit"></i></button>
				</th>
				<th class="text-left d-print-none">
					&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <button class="btn-outline-warning bg-success" data-toggle="modal" onclick="action_add_model('<?= base_url("accounts/chart_of_accounts_add?accounts_category=$chart_of_accounts_row->chart_of_accounts_id");?>')" title="<?= $this->lang->line('add');?> <?= $this->lang->line('control_group');?>"><i class="fa fa-plus"></i></button>
				</th>
			</tr>
			<?php 
			$c_o_a_control_group =  $this->db->select("*")
			->from('chart_of_accounts')  
			->join('accounts_link', 'chart_of_accounts.chart_of_accounts_link = accounts_link.accounts_link_id', 'LEFT')
			->where('chart_of_accounts_accounts_category', $chart_of_accounts_row->chart_of_accounts_id) 
			->order_by('chart_of_accounts_code', 'ASC')
			->get()
			->result();
			
			foreach($c_o_a_control_group as $c_o_a_control_group_row)
			{?>
			<tr class="text-uppercase">
				<td class="text-left">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<?= $c_o_a_control_group_row->chart_of_accounts_code;?></td>
				<td class="text-left"><?= $c_o_a_control_group_row->chart_of_accounts_name;?></td>
				
				<td class="text-center"><?= $c_o_a_control_group_row->accounts_link_name;?></td>
				<td class="text-center"><?php if ($c_o_a_control_group_row->chart_of_accounts_status ==1 ) {?> <span><?= $this->lang->line('active');?></span><?php } else {?> <span><?= $this->lang->line('inactive');?></span> <?php }?></td>
				
				<td class="text-center d-print-none" width="10%">
				<button class="btn-outline-success bg-warning" data-toggle="modal" onclick="action_edit_model('<?= base_url("accounts/chart_of_accounts_edit/$c_o_a_control_group_row->chart_of_accounts_id");?>')" title="<?= $this->lang->line('edit');?>"><i class="fa fa-edit"></i></button>
				</td>
				<td class="text-center d-print-none">
					<button class="btn-outline-success bg-warning" data-toggle="modal" onclick="action_add_model('<?= base_url("accounts/chart_of_accounts_add?accounts_category=$c_o_a_control_group_row->chart_of_accounts_id");?>')" title="<?= $this->lang->line('add');?> <?= $this->lang->line('general_ledger');?>"><i class="fa fa-plus"></i></button>
				</td>
			</tr>
			<?php 
			$c_o_a_general_ledger =  $this->db->select("*")
			->from('chart_of_accounts')  
			->join('accounts_link', 'chart_of_accounts.chart_of_accounts_link = accounts_link.accounts_link_id', 'LEFT')
			->where('chart_of_accounts_accounts_category', $c_o_a_control_group_row->chart_of_accounts_id) 
			->order_by('chart_of_accounts_code', 'ASC')
			->get()
			->result();
			
			foreach($c_o_a_general_ledger as $c_o_a_general_ledger_row)
			{?>
			<tr>
				<td class="text-center">&nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; <?= $c_o_a_general_ledger_row->chart_of_accounts_code;?></td>
				<td class="text-left"><?= $c_o_a_general_ledger_row->chart_of_accounts_name;?></td>
				
				<td class="text-center"><?= $c_o_a_general_ledger_row->accounts_link_name;?></td>
				<td class="text-center"><?php if ($c_o_a_general_ledger_row->chart_of_accounts_status ==1 ) {?> <span><?= $this->lang->line('active');?></span><?php } else {?> <span><?= $this->lang->line('inactive');?></span> <?php }?></td>
				
				<td class="text-center d-print-none" width="10%">
				<button class="btn-outline-danger " data-toggle="modal" onclick="action_edit_model('<?= base_url("accounts/chart_of_accounts_edit/$c_o_a_general_ledger_row->chart_of_accounts_id");?>')" title="<?= $this->lang->line('edit');?>"><i class="fa fa-edit"></i></button>
				</td>
				<td class="text-right d-print-none">
					<button class="btn-outline-danger " data-toggle="modal" onclick="action_add_model('<?= base_url("accounts/chart_of_accounts_add?accounts_category=$c_o_a_general_ledger_row->chart_of_accounts_id");?>')" title="<?= $this->lang->line('add');?> <?= $this->lang->line('subsidiary_ledger');?>"><i class="fa fa-plus"></i></button>
				</td>
			</tr>
			<?php 
			$c_o_a_subsidiary_ledger =  $this->db->select("*")
			->from('chart_of_accounts')
			->join('accounts_link', 'chart_of_accounts.chart_of_accounts_link = accounts_link.accounts_link_id', 'LEFT')
			->where('chart_of_accounts_accounts_category', $c_o_a_general_ledger_row->chart_of_accounts_id) 
			->order_by('chart_of_accounts_code', 'ASC')
			->get()
			->result();
			
			foreach($c_o_a_subsidiary_ledger as $c_o_a_subsidiary_ledger_row)
			{?>
			<tr>
				<td class="text-right"><?= $c_o_a_subsidiary_ledger_row->chart_of_accounts_code;?></td>
				<td class="text-left"><?= $c_o_a_subsidiary_ledger_row->chart_of_accounts_name;?></td>
				
				<td class="text-center"><?= $c_o_a_subsidiary_ledger_row->accounts_link_name;?></td>
				<td class="text-center"><?php if ($c_o_a_subsidiary_ledger_row->chart_of_accounts_status ==1 ) {?> <span><?= $this->lang->line('active');?></span><?php } else {?> <span><?= $this->lang->line('inactive');?></span> <?php }?></td>
				
				<td class="text-center d-print-none" width="10%">
				<button class="btn-outline-secondary bg-blue" data-toggle="modal" onclick="action_edit_model('<?= base_url("accounts/chart_of_accounts_edit/$c_o_a_subsidiary_ledger_row->chart_of_accounts_id");?>')" title="<?= $this->lang->line('edit');?>"><i class="fa fa-edit"></i></button>
				</td>
				<td class="text-center"></td>
			</tr>
		<?php } } } } }
		return $output;
	}
	
	
	/* ------------------------------------------------------
	Chart of Accounts Code Check Model
	------------------------------------------------------- */
	function chart_of_accounts_code_check($chart_of_accounts_code)
	{	
		$this->db->select('*');
		$this->db->from('chart_of_accounts');
		$this->db->where('chart_of_accounts_code', $chart_of_accounts_code);
		$query = $this->db->get();
		if($query->num_rows()>0){
		return false;
		}
		else
		{
		return true;
		}
	} 
	
	/* ------------------------------------------------------
	Chart of Accounts Create Model
	------------------------------------------------------- */
	function chart_of_accounts_create($data)
	{	
		$this->db->insert('chart_of_accounts',$data);
		return True;
	}
	
	/* ------------------------------------------------------
	Chart of Accounts Create Model
	------------------------------------------------------- */
	function chart_of_accounts_create_sh_khan($sh_khan_data)
	{	
		$this->db_shkhan = $this->load->database('db_shkhan', TRUE);
		
		$this->db_shkhan->insert('chart_of_accounts',$sh_khan_data);
		return True;
	}
	
	
	/* ------------------------------------------------------
	Accounts Type Edit Model
	------------------------------------------------------- */
	function accounts_type_edit($id)
	{	
		return $this->db->select('*')
		->from('accounts_type')
		->where('accounts_type_id', $id) 
		->order_by('accounts_type_id', 'ASC')
		->get()
		->result();
	} 
	
	
	/* ------------------------------------------------------
	Accounts Type Update Model
	------------------------------------------------------- */
	function accounts_type_update($data)
	{	
		$this->db->where('accounts_type_id',$data['accounts_type_id'])
		->update('accounts_type', $data);
		
		return True;
	}
	 
	/* ------------------------------------------------------
	Chart of Accounts Edit Model
	------------------------------------------------------- */
	function chart_of_accounts_edit($id)
	{	
		return $this->db->select('*')
		->from('chart_of_accounts')
		->where('chart_of_accounts_id', $id) 
		->order_by('chart_of_accounts_id', 'ASC')
		->get()
		->result();
	} 
	
	
	/* ------------------------------------------------------
	Chart of Accounts Update Model
	------------------------------------------------------- */
	function chart_of_accounts_update($data)
	{	
		$this->db->where('chart_of_accounts_id', $data['chart_of_accounts_id'])
		->update('chart_of_accounts', $data);
		
		return True;
	}
	
	/* ------------------------------------------------------
	Accounts Type Update Model
	------------------------------------------------------- */
	function chart_of_accounts_update_sh_khan($sh_khan_data)
	{	
		$this->db_shkhan = $this->load->database('db_shkhan', TRUE); 
		
		$this->db_shkhan->where('chart_of_accounts_software_module', $sh_khan_data['chart_of_accounts_software_module'])->where('chart_of_accounts_software_module_id', $sh_khan_data['chart_of_accounts_software_module_id'])
		->update('chart_of_accounts', $sh_khan_data);
		
		return True;
	}
	
	/* ------------------------------------------------------
	Chart of Accounts Print Model
	------------------------------------------------------- */
	function chart_of_accounts_print()
	{	
		$accounts_type =  $this->db->select("*")
		->from('accounts_type')
		->order_by('accounts_type_code', 'ASC')  
		->get()
		->result();
		
		$output = '';
		foreach($accounts_type as $accounts_type_row)
		{?> 
			<tr class="text-uppercase">
				<th class="text-left"><?= $accounts_type_row->accounts_type_code ;?></th>
				<th class="text-left"><?= $accounts_type_row->accounts_type_name ;?></th>
			</tr>
			<?php 
			$chart_of_accounts =  $this->db->select("*")
			->from('chart_of_accounts') 
			->where('chart_of_accounts_accounts_category', $accounts_type_row->accounts_type_id)
			->order_by('chart_of_accounts_code', 'ASC')
			->get()
			->result();
			
			foreach($chart_of_accounts as $chart_of_accounts_row)
			{?>
			<tr class="text-uppercase">
				<th class="text-left">&nbsp; &nbsp; <?= $chart_of_accounts_row->chart_of_accounts_code;?></th>
				<th class="text-left"><?= $chart_of_accounts_row->chart_of_accounts_name;?></th>
			</tr>
			<?php 
			$c_o_a_control_group =  $this->db->select("*")
			->from('chart_of_accounts')  
			->where('chart_of_accounts_accounts_category', $chart_of_accounts_row->chart_of_accounts_id) 
			->order_by('chart_of_accounts_code', 'ASC')
			->get()
			->result();
			
			foreach($c_o_a_control_group as $c_o_a_control_group_row)
			{?>
			<tr class="text-uppercase">
				<td class="text-left">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<?= $c_o_a_control_group_row->chart_of_accounts_code;?></td>
				<td class="text-left"><?= $c_o_a_control_group_row->chart_of_accounts_name;?></td>
			</tr>
			<?php 
			$c_o_a_general_ledger =  $this->db->select("*")
			->from('chart_of_accounts')  
			->where('chart_of_accounts_accounts_category', $c_o_a_control_group_row->chart_of_accounts_id) 
			->order_by('chart_of_accounts_code', 'ASC')
			->get()
			->result();
			
			foreach($c_o_a_general_ledger as $c_o_a_general_ledger_row)
			{?>
			<tr>
				<td class="text-center"><?= $c_o_a_general_ledger_row->chart_of_accounts_code;?></td>
				<td class="text-left"><?= $c_o_a_general_ledger_row->chart_of_accounts_name;?></td>
			</tr>
			<?php 
			$c_o_a_subsidiary_ledger =  $this->db->select("*")
			->from('chart_of_accounts')
			->where('chart_of_accounts_accounts_category', $c_o_a_general_ledger_row->chart_of_accounts_id) 
			->order_by('chart_of_accounts_code', 'ASC')
			->get()
			->result();
			
			foreach($c_o_a_subsidiary_ledger as $c_o_a_subsidiary_ledger_row)
			{?>
			<tr>
				<td class="text-right"><?= $c_o_a_subsidiary_ledger_row->chart_of_accounts_code;?></td>
				<td class="text-left"><?= $c_o_a_subsidiary_ledger_row->chart_of_accounts_name;?></td>
			</tr>
		<?php } } } } }
		return $output;
	}  
	
	/* ------------------------------------------------------
	Voucher Type List Model
	------------------------------------------------------- */
	function voucher_type_list_option()
	{	
		return $this->db->select("*")
		->from('voucher_type')
		->where('voucher_type_status', 1)
		->order_by('voucher_type_id', 'ASC')  
		->get()
		->result();
	}
	
	/* ------------------------------------------------------
	Voucher Type List Model
	------------------------------------------------------- */
	function voucher_type_receive_list_option()
	{	
		return $this->db->select("*")
		->from('voucher_type')
		->where('voucher_type_id', 1)
		->where('voucher_type_status', 1)
		->order_by('voucher_type_id', 'ASC')  
		->get()
		->result();
	}
	
	/* ------------------------------------------------------
	Get Voucher Number Info Model
	------------------------------------------------------- */
	function get_voucher_number_info($posting_date, $accounts_voucher_type)
	{	
		$output = ''; 
		if (date('m', strtotime($posting_date)) < '07') {
		$start_financial_year = date('Y-07-01', strtotime($posting_date. "last year"));
		} else {
		$start_financial_year = date('Y-07-01', strtotime($posting_date));
		}
		
		if (date('m', strtotime($posting_date)) < '07') {
		$end_financial_year = date('Y-m-t', strtotime($posting_date));
		} else {
		$end_financial_year = date('Y-06-t', strtotime($posting_date. "+1 year"));
		}
		
		
		$accounts =  $this->db->select("COUNT(accounts_id) as voucher_number")
		->from('accounts')
		->where('accounts_voucher_posting_date BETWEEN "'.$start_financial_year.'" and "'.$end_financial_year.'"')
		->where('accounts_voucher_type', $accounts_voucher_type) 
		->order_by('accounts_voucher_posting_date', 'ASC')  
		->get()
		->result();
		
		$voucher_type =  $this->db->select("")
		->from('voucher_type') 
		->where('voucher_type_id', $accounts_voucher_type)
		->order_by('voucher_type_id', 'ASC')  
		->get()
		->result();
		
		foreach($voucher_type as $voucher_type_row)
		{
			$voucher_type_code = $voucher_type_row->voucher_type_code;
			$accounts_voucher_type_code = $voucher_type_row->voucher_type_code;
			$accounts_voucher_type_name = $voucher_type_row->voucher_type_name;
		}
		
		foreach($accounts as $row)
		{
		$voucher_number = str_pad($row->voucher_number+1, 4, '0', STR_PAD_LEFT);	
		?> 
			<label for="label"><?= $this->lang->line('voucher_number');?> *</label> 
			<input type="hidden" class="" name="accounts_voucher_type_code" value="<?= $accounts_voucher_type_code;?>"readonly required>
			<input type="hidden" class="" name="accounts_voucher_type_name" value="<?= $accounts_voucher_type_name;?>"readonly required>
			<input type="text" class="form-control form-control-sm bd-danger text-center" id="accounts_voucher_number" name="accounts_voucher_number" value="<?= $voucher_type_code;?>-<?= $voucher_number;?>"readonly required>
		<?php } 
		return $output;
	}
	
	/* ------------------------------------------------------
	Voucher Posting Accounts Category Info Model
	------------------------------------------------------- */
	function voucher_posting_accounts_category_info($accounts_category)
	{	
		$query =  $this->db->select("*")
		->from('chart_of_accounts')
		->where('chart_of_accounts_accounts_category', $accounts_category)
		->where('chart_of_accounts_status', 1)
		->order_by('chart_of_accounts_id', 'ASC')
		->get()
		->result();
		
		$output = ''; 
		
		$output .= '<option value="0"> --- '.$this->lang->line('select').' --- </option>';
		foreach($query as $row)
		{ 
		$output .= '<option value="'.$row->chart_of_accounts_id.'">'.$row->chart_of_accounts_code.' - '.$row->chart_of_accounts_name.'</option>';
		}
		return $output;
	} 
	
	/* ------------------------------------------------------
	Voucher Posting Report Model
	------------------------------------------------------- */
	function voucher_information($voucher_type, $posting_from_date, $posting_to_date)
	{
		$output = '';
		
		$posting_report =  $this->db->select("*")
		->from('accounts')
		->where('accounts_voucher_posting_date BETWEEN "'.$posting_from_date.'" and "'.$posting_to_date.'"')
		->where('accounts_voucher_type', $voucher_type) 
		->order_by('accounts_voucher_posting_date', 'ASC') 
		->get();
		
		
		if($posting_report->num_rows() >0) {
			
		$serial = 0;
		$total_debit_amount = 0;
		$total_credit_amount = 0;
		foreach($posting_report->result() as $row)
		{
		$total_debit_amount += $row->accounts_total_debit;
		$total_credit_amount += $row->accounts_total_credit;
		?> 
			<tr>
				<td class="text-center"><?= str_pad(++$serial, 2, '0', STR_PAD_LEFT);?></td>
				<td class="text-center"><?= date('d/m/Y', strtotime($row->accounts_voucher_posting_date));?></td>
				<td class="text-center"><?= $row->accounts_voucher_type_name ;?></td>
				<td class="text-center"><?= $row->accounts_voucher_number ;?></td>
				<td class="text-left"><?= $row->accounts_narration ;?></td>
				<td class="text-right"><?= $row->accounts_total_debit ;?></td>
				<td class="text-right"><?= $row->accounts_total_credit ;?></td> 
				<?php $user_type = $this->session->ses_user_type;
				if ($user_type == "admin") {?>
				<td class="text-center d-print-none">  
					<a class="btn-outline-warning bg-success rounded-pill" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="action_view_model('<?= base_url("accounts/voucher_view/$row->accounts_id");?>')"><i class=" fa fa-eye"></i></a> &nbsp; 
					<a class="btn-outline-info rounded-pill" href="javascript:void(0);" title="<?= $this->lang->line('edit');?>" onclick="window.open('<?= base_url("accounts/voucher_edit/$row->accounts_id");?>')"><i class=" fa fa-pencil"></i></a> &nbsp; 
					<a class="btn-outline-danger  rounded-pill" href="javascript:void(0);" title="<?= $this->lang->line('delete');?>" onclick="action_delete_modal('<?= base_url("accounts/voucher_delete/$row->accounts_id");?>')"><i class=" fa fa-remove"></i></a>
				</td>
				<?php } else {?>
				<td class="text-center d-print-none">  
					<a class="btn-outline-warning bg-success rounded-pill" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="action_view_model('<?= base_url("accounts/voucher_view/$row->accounts_id");?>')"><i class=" fa fa-eye"></i></a> &nbsp;
					<a class="btn-outline-info rounded-pill" href="javascript:void(0);" title="<?= $this->lang->line('edit');?>" onclick="window.open('<?= base_url("accounts/voucher_edit/$row->accounts_id");?>')"><i class=" fa fa-pencil"></i></a>
				</td>
				<?php }?>
			</tr>
		<?php } ?>
			<tr class="text-uppercase">
				<th class="text-center" colspan="5" style="text-align:right;"><?= $this->lang->line('total');?></th>
				<th class="text-right"><?= number_format($total_debit_amount,2 . '');?></th>
				<th class="text-right"><?= number_format($total_credit_amount,2 . '');?></th>
				<th class="text-center"></th>
			</tr> 
			
			<tr class="text-uppercase">
				<th class="text-left" colspan="8"><?= $this->lang->line('in_word');?>: 
				<?php 
				$number = $total_debit_amount;
				$in_word_amount = $this->number_to_word_convert->convert_number($number);
				?>
				<?= $in_word_amount;?> <?= $this->lang->line('currency_only');?>.
				</th>
			</tr>
		<?php } else { ?>
			<tr class="text-center text-uppercase">
				<th colspan="8"><?= $this->lang->line("data_searching_error");?></th>
			</tr>
		<?php } 
		return $output;
	} 
	
	/* ------------------------------------------------------
	Voucher Posting Create Model
	------------------------------------------------------- */
	function voucher_posting_accounts_create($data)
	{
		$this->db->insert('accounts', $data);
		return True;
	}
	
	/* ------------------------------------------------------
	Voucher Posting Create Model
	------------------------------------------------------- */
	function voucher_posting_accounts_details_create($data_1)
	{
		$this->db->insert_batch('accounts_details', $data_1);
		
		$this->db->where('accounts_details_subsidiary_ledger', 0)
		->delete('accounts_details');
		return True;
	} 
	
	/* ------------------------------------------------------
	Voucher Update Model
	------------------------------------------------------- */
	function voucher_details_update($data_1)
	{	
		$this->db->update_batch('accounts_details', $data_1, 'accounts_details_id');
		return True;
	} 
	
	/* ------------------------------------------------------
	Voucher Delete Model
	------------------------------------------------------- */
	function voucher_delete($data)
	{	
		$this->db->where('accounts_id', $data)
		->delete('accounts');
		
		$this->db->where('accounts_details_accounts_id', $data)
		->delete('accounts_details');
		
		return TRUE;
	}
	
	/* ------------------------------------------------------
	Voucher Posting View Model
	------------------------------------------------------- */
	function voucher_view($id)
	{
		return $this->db->select("*")
		->from('accounts')
		->where('accounts_id', $id)
		->order_by('accounts_id', 'ASC') 
		->get()
		->result();
	}
	
	/* ------------------------------------------------------
	Voucher Posting Report Print Model
	------------------------------------------------------- */
	function voucher_information_print($voucher_type, $posting_from_date, $posting_to_date)
	{
		$output = '';
		
		$posting_report =  $this->db->select("*")
		->from('accounts')
		->where('accounts_voucher_posting_date BETWEEN "'.$posting_from_date.'" and "'.$posting_to_date.'"')
		->where('accounts_voucher_type', $voucher_type) 
		->order_by('accounts_voucher_posting_date', 'ASC') 
		->get();
		
		
		if($posting_report->num_rows() >0) {
			
		$serial = 0;
		$total_debit_amount = 0;
		$total_credit_amount = 0;
		foreach($posting_report->result() as $row)
		{
		$total_debit_amount += $row->accounts_total_debit;
		$total_credit_amount += $row->accounts_total_credit;
		?> 
			<tr>
				<td class="text-center"><?= str_pad(++$serial, 2, '0', STR_PAD_LEFT);?></td>
				<td class="text-center"><?= date('d/m/Y', strtotime($row->accounts_voucher_posting_date));?></td>
				<td class="text-center"><?= $row->accounts_voucher_type_name ;?></td>
				<td class="text-center"><?= $row->accounts_voucher_number ;?></td>
				<td class="text-left"><?= $row->accounts_narration ;?></td>
				<td class="text-right"><?= $row->accounts_total_debit ;?></td>
				<td class="text-right"><?= $row->accounts_total_credit ;?></td>
			</tr>
		<?php } ?>
			<tr class="text-uppercase">
				<th class="text-center" colspan="5"><?= $this->lang->line('total');?></th>
				<th class="text-right"><?= number_format($total_debit_amount,2 . '');?></th>
				<th class="text-right"><?= number_format($total_credit_amount,2 . '');?></th>
			</tr> 
			
			<tr class="text-uppercase">
				<th class="text-left" colspan="7"><?= $this->lang->line('in_word');?>: 
				<?php 
				$number = $total_debit_amount;
				$in_word_amount = $this->number_to_word_convert->convert_number($number);
				?>
				<?= $in_word_amount;?> <?= $this->lang->line('currency_only');?>.
				</th>
			</tr>
		<?php } else { ?>
			<tr class="text-center text-uppercase">
				<th colspan="7"><?= $this->lang->line("data_searching_error");?></th>
			</tr>
		<?php } 
		return $output;
	}
	
	/* ------------------------------------------------------
	Voucher Number Search Model
	------------------------------------------------------- */
	function voucher_number_search($voucher_number, $posting_from_date, $posting_to_date)
	{
		$posting_report =  $this->db->select("*")
		->from('accounts')
		->like('accounts_voucher_number', $voucher_number)
		->where('accounts_voucher_posting_date BETWEEN "'.$posting_from_date.'" and "'.$posting_to_date.'"')
		->order_by('accounts_voucher_posting_date', 'ASC') 
		->limit(10)
		->get()
		->result();
		
		$output = '';
		$serial = 0;
		$total_debit_amount = 0;
		$total_credit_amount = 0;
		foreach($posting_report as $row)
		{
		$total_debit_amount += $row->accounts_total_debit;
		$total_credit_amount += $row->accounts_total_credit;
		?> 
			<tr>
				<td class="text-center"><?= str_pad(++$serial, 2, '0', STR_PAD_LEFT);?></td>
				<td class="text-center"><?= date('d/m/Y', strtotime($row->accounts_voucher_posting_date));?></td>
				<td class="text-center"><?= $row->accounts_voucher_type_name;?></td>
				<td class="text-center"><?= $row->accounts_voucher_number;?></td>
				<td class="text-left"><?= $row->accounts_narration;?></td>
				<td class="text-right"><?= $row->accounts_total_debit;?></td>
				<td class="text-right"><?= $row->accounts_total_credit;?></td>
				<?php $user_type = $this->session->ses_user_type;
				if ($user_type == "admin") {?>
				<td class="text-center d-print-none">  
					<a class="btn-outline-warning bg-success rounded-pill" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="action_view_model('<?= base_url("accounts/voucher_view/$row->accounts_id");?>')"><i class=" fa fa-eye"></i></a> &nbsp; 
					<a class="btn-outline-info rounded-pill" href="javascript:void(0);" title="<?= $this->lang->line('edit');?>" onclick="window.open('<?= base_url("accounts/voucher_edit/$row->accounts_id");?>')"><i class=" fa fa-pencil"></i></a> &nbsp; 
					<a class="btn-outline-danger  rounded-pill" href="javascript:void(0);" title="<?= $this->lang->line('delete');?>" onclick="action_delete_modal('<?= base_url("accounts/voucher_delete/$row->accounts_id");?>')"><i class=" fa fa-remove"></i></a>
				</td>
				<?php } else {?>
				<td class="text-center d-print-none">  
					<a class="btn-outline-warning bg-success rounded-pill" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="action_view_model('<?= base_url("accounts/voucher_view/$row->accounts_id");?>')"><i class=" fa fa-eye"></i></a> &nbsp;
					<a class="btn-outline-info rounded-pill" href="javascript:void(0);" title="<?= $this->lang->line('edit');?>" onclick="window.open('<?= base_url("accounts/voucher_edit/$row->accounts_id");?>')"><i class=" fa fa-pencil"></i></a>
				</td>
				<?php }?>
			</tr>
		<?php } 
		return $output;
	}
	
	/* ------------------------------------------------------
	Voucher Update Model
	------------------------------------------------------- */
	function voucher_update($data)
	{	
		$this->db->where('accounts_id',$data['accounts_id'])
		->update('accounts', $data);
		
		return True;
	}
	
	/* ------------------------------------------------------
	General Ledger Model
	------------------------------------------------------- */
	function general_ledger($accounts_type, $accounts_category, $control_group, $general_ledger, $starting_date, $closing_date)
	{	
		$output = '';
		$opening_balance_starting_date = date('2015-01-01');
		$opening_balance_closing_date = date('Y-m-d', strtotime($starting_date. "last day"));
		
		$control_group_code ='';
		$control_group_name ='';
		$general_ledger_code ='';
		$general_ledger_name ='';
		
		$control_group_query =  $this->db->select("*")
		->from('chart_of_accounts')
		->where('chart_of_accounts_id', $control_group)
		->order_by('chart_of_accounts_id', 'ASC') 
		->get()
		->result();
		foreach($control_group_query as $control_group_row)
		{
		$control_group_code = $control_group_row->chart_of_accounts_code;
		$control_group_name = $control_group_row->chart_of_accounts_name;
		}
		
		if($general_ledger > 0) {
		$general_ledger_query =  $this->db->select("*")
		->from('chart_of_accounts')
		->where('chart_of_accounts_id', $general_ledger)
		->order_by('chart_of_accounts_id', 'ASC') 
		->get()
		->result();
		foreach($general_ledger_query as $general_ledger_row)
		{
		$general_ledger_code = $general_ledger_row->chart_of_accounts_code;
		$general_ledger_name = $general_ledger_row->chart_of_accounts_name;
		}
		} else {
			
		}
		?>
		<table class="text-uppercase" width="100%" align="center">
			<tr>
				<th class="text-left" width="19%"><?= $this->lang->line('control_group');?></th>
				<th class="text-center" width="1%">:</th>
				<th class="text-left" width="80%"><?= $control_group_name;?> (<?= $control_group_code;?>)</th>
			</tr>
			<tr>
				<th class="text-left" width="19%"><?= $this->lang->line('general_ledger');?></th>
				<th class="text-center" width="1%">:</th>
				<th class="text-left" width="80%"><?= $general_ledger_name;?> (<?= $general_ledger_code;?>)</th>
			</tr>
		</table>
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-hover">
				<thead class=" text-uppercase">
					<tr>  
						<th class="text-center"><?= $this->lang->line('date');?></th>
						<th class="text-center" colspan="2"><?= $this->lang->line('particulars');?></th>
						<th class="text-center"><?= $this->lang->line('voucher');?></th>
						<th class="text-center"><?= $this->lang->line('debit');?></th>
						<th class="text-center"><?= $this->lang->line('credit');?></th>
						<th class="text-center"><?= $this->lang->line('balance');?></th>
					</tr>
				</thead>
				<tbody>
					<?php
					$total_balance = 0;
					$opening_balance = 0; 
					
					if($general_ledger > 0) {
					$opening_balance_query =  $this->db->select("SUM(accounts_details_debit) as opening_debit_balance, SUM(accounts_details_credit) as opening_credit_balance, (SUM(accounts_details_debit) - SUM(accounts_details_credit)) as  opening_balance")
					->from('accounts_details') 
					->where('accounts_details_general_ledger', $general_ledger)
					->where('accounts_details_voucher_posting_date BETWEEN "'.$opening_balance_starting_date.'" and "'.$opening_balance_closing_date.'"')
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					} else {
					$opening_balance_query =  $this->db->select("SUM(accounts_details_debit) as opening_debit_balance, SUM(accounts_details_credit) as opening_credit_balance, (SUM(accounts_details_debit) - SUM(accounts_details_credit)) as  opening_balance")
					->from('accounts_details') 
					->where('accounts_details_control_group', $control_group)
					->where('accounts_details_voucher_posting_date BETWEEN "'.$opening_balance_starting_date.'" and "'.$opening_balance_closing_date.'"')
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					}
					foreach($opening_balance_query as $opening_balance_row)
					{
						$opening_debit_balance		= $opening_balance_row->opening_debit_balance;
						$opening_credit_balance		= $opening_balance_row->opening_credit_balance;
						$opening_balance			= $opening_balance_row->opening_balance;
					}?>
					<tr>
						<td class="text-center">-</td>
						<td class="text-left" colspan="2"><?= $this->lang->line('opening_balance');?></td>
						<td class="text-center">-</td>
						<td class="text-right"><?php if ($opening_debit_balance >0) { echo' '.number_format($opening_debit_balance, 2 . '').' ';} else if ($opening_debit_balance == 0) { echo'-';} else { echo' '.number_format(abs($opening_debit_balance),2 . '').' ';} ?></td>
						<td class="text-right"><?php if ($opening_credit_balance >0) { echo' '.number_format($opening_credit_balance, 2 . '').' ';} else if ($opening_credit_balance == 0) { echo'-';} else { echo' '.number_format(abs($opening_credit_balance),2 . '').' ';} ?></td>
						<td class="text-right"><?php if ($opening_balance >0) { echo' '.number_format($opening_balance, 2 . '').' ';} else if ($opening_balance == 0) { echo'-';} else { echo' '.number_format(abs($opening_balance),2 . '').' ';} ?></td>
					</tr>
					<?php
					$general_ledger_debit_balance = 0;
					$general_ledger_credit_balance = 0;
					
					$total_general_ledger_debit_balance = $opening_debit_balance;
					$total_general_ledger_credit_balance = $opening_credit_balance;
					$general_ledger_balance = $opening_balance;
					
					if($general_ledger > 0) {
					$general_ledger_balance_query =  $this->db->select("*")
					->from('accounts_details')
					->join('chart_of_accounts', 'accounts_details.accounts_details_subsidiary_ledger = chart_of_accounts.chart_of_accounts_id', 'LEFT')  
					->where('accounts_details.accounts_details_general_ledger', $general_ledger)
					->where('accounts_details.accounts_details_voucher_posting_date BETWEEN "'.$starting_date.'" and "'.$closing_date.'"')
					->order_by('accounts_details.accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					} else {
					$general_ledger_balance_query =  $this->db->select("*")
					->from('accounts_details')
					->join('chart_of_accounts', 'accounts_details.accounts_details_subsidiary_ledger = chart_of_accounts.chart_of_accounts_id', 'LEFT')  
					->where('accounts_details_control_group', $control_group)
					->where('accounts_details.accounts_details_voucher_posting_date BETWEEN "'.$starting_date.'" and "'.$closing_date.'"')
					->order_by('accounts_details.accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					}
					foreach($general_ledger_balance_query as $general_ledger_balance_query_row)
					{
						$debit_balance						= $general_ledger_balance_query_row->accounts_details_debit;
						$credit_balance						= $general_ledger_balance_query_row->accounts_details_credit;  
						
						$general_ledger_debit_balance		+= $debit_balance;
						$general_ledger_credit_balance		+= $credit_balance;
						
						$total_general_ledger_debit_balance		+= $debit_balance;
						$total_general_ledger_credit_balance		+= $credit_balance;
						$general_ledger_balance				+= $debit_balance - $credit_balance;
					?>
					<tr>
						<td class="text-center"><?= date('d/m/Y', strtotime($general_ledger_balance_query_row->accounts_details_voucher_posting_date));?></td>
						<td class="text-left"><?= $general_ledger_balance_query_row->chart_of_accounts_code;?> - <?= $general_ledger_balance_query_row->chart_of_accounts_name;?></td>
						<td class="text-left"><?= $general_ledger_balance_query_row->accounts_details_narration;?></td>
						<td class="text-center"><?= $general_ledger_balance_query_row->accounts_details_voucher_number;?></td> 
						<td class="text-right"><?php if ($debit_balance >0) { echo' '.number_format($debit_balance, 2 . '').' ';} else if ($debit_balance == 0) { echo'-';} else { echo' '.number_format(abs($debit_balance),2 . '').' ';} ?></td>
						<td class="text-right"><?php if ($credit_balance >0) { echo' '.number_format($credit_balance, 2 . '').' ';} else if ($credit_balance == 0) { echo'-';} else { echo' '.number_format(abs($credit_balance),2 . '').' ';} ?></td>
						<td class="text-right"><?php if ($general_ledger_balance >0) { echo' '.number_format($general_ledger_balance, 2 . '').' ';} else if ($general_ledger_balance == 0) { echo'-';} else { echo' '.number_format(abs($general_ledger_balance),2 . '').' ';} ?></td>
					</tr>
					<?php }
					
					$total_balance 			+= $general_ledger_balance;
					?>
					
					<tr class="text-uppercase">
						<th class="text-right" colspan="4"><?= $this->lang->line('sub_total');?></th> 
						<th class="text-right"><?php if ($general_ledger_debit_balance >0) { echo' '.number_format($general_ledger_debit_balance, 2 . '').' ';} else if ($general_ledger_debit_balance == 0) { echo'-';} else { echo' '.number_format(abs($general_ledger_debit_balance),2 . '').' ';} ?></th>
						<th class="text-right"><?php if ($general_ledger_credit_balance >0) { echo' '.number_format($general_ledger_credit_balance, 2 . '').' ';} else if ($general_ledger_credit_balance == 0) { echo'-';} else { echo' '.number_format(abs($general_ledger_credit_balance),2 . '').' ';} ?></th>
						<th class="text-right"><?php if ($general_ledger_debit_balance-$general_ledger_credit_balance >0) { echo' '.number_format($general_ledger_debit_balance-$general_ledger_credit_balance, 2 . '').' ';} else if ($general_ledger_debit_balance-$general_ledger_credit_balance == 0) { echo'-';} else { echo' '.number_format(abs($general_ledger_debit_balance-$general_ledger_credit_balance),2 . '').' ';} ?></th>
					</tr>
					
					<tr class="text-uppercase">
						<th class="text-right" colspan="4"><?= $this->lang->line('total_amount');?></th> 
						<th class="text-right"><?php if ($total_general_ledger_debit_balance >0) { echo' '.number_format($total_general_ledger_debit_balance, 2 . '').' ';} else if ($total_general_ledger_debit_balance == 0) { echo'-';} else { echo' '.number_format(abs($total_general_ledger_debit_balance),2 . '').' ';} ?></th>
						<th class="text-right"><?php if ($total_general_ledger_credit_balance >0) { echo' '.number_format($total_general_ledger_credit_balance, 2 . '').' ';} else if ($total_general_ledger_credit_balance == 0) { echo'-';} else { echo' '.number_format(abs($total_general_ledger_credit_balance),2 . '').' ';} ?></th>
						<th class="text-right"><?php if ($total_balance >0) { echo' '.number_format($total_balance, 2 . '').' ';} else if ($total_balance == 0) { echo'-';} else { echo' '.number_format(abs($total_balance),2 . '').' ';} ?></th>
					</tr>
					<tr class="text-uppercase">
						<th class="text-left" colspan="7"><?= $this->lang->line('in_word');?>: 
						<?php 
						$number = abs($total_balance);
						$in_word_amount = $this->number_to_word_convert->convert_number($number);
						?>
						<?= $in_word_amount;?> <?= $this->lang->line('currency_only');?>.
						</th>
					</tr>
				</tbody>
			</table>
		</div>
		<?php 
		return $output;
	}
	
	/* ------------------------------------------------------
	General Ledger Print Model
	------------------------------------------------------- */
	function general_ledger_print($accounts_type, $accounts_category, $control_group, $general_ledger, $starting_date, $closing_date)
	{	
		$output = '';
		$opening_balance_starting_date = date('2015-01-01');
		$opening_balance_closing_date = date('Y-m-d', strtotime($starting_date. "last day"));
		
		$control_group_code ='';
		$control_group_name ='';
		$general_ledger_code ='';
		$general_ledger_name ='';
		
		$control_group_query =  $this->db->select("*")
		->from('chart_of_accounts')
		->where('chart_of_accounts_id', $control_group)
		->order_by('chart_of_accounts_id', 'ASC') 
		->get()
		->result();
		foreach($control_group_query as $control_group_row)
		{
		$control_group_code = $control_group_row->chart_of_accounts_code;
		$control_group_name = $control_group_row->chart_of_accounts_name;
		}
		
		if($general_ledger > 0) {
		$general_ledger_query =  $this->db->select("*")
		->from('chart_of_accounts')
		->where('chart_of_accounts_id', $general_ledger)
		->order_by('chart_of_accounts_id', 'ASC') 
		->get()
		->result();
		foreach($general_ledger_query as $general_ledger_row)
		{
		$general_ledger_code = $general_ledger_row->chart_of_accounts_code;
		$general_ledger_name = $general_ledger_row->chart_of_accounts_name;
		}
		} else {
			
		}
		?>
		<table class="text-uppercase" width="100%" align="center">
			<tr>
				<th class="text-left" width="19%"><?= $this->lang->line('control_group');?></th>
				<th class="text-center" width="1%">:</th>
				<th class="text-left" width="80%"><?= $control_group_name;?> (<?= $control_group_code;?>)</th>
			</tr>
			<tr>
				<th class="text-left" width="19%"><?= $this->lang->line('general_ledger');?></th>
				<th class="text-center" width="1%">:</th>
				<th class="text-left" width="80%"><?= $general_ledger_name;?> (<?= $general_ledger_code;?>)</th>
			</tr>
		</table>
		<div class="">
			<table class="table table-striped table-bordered table-hover">
				<thead class="text-10 text-uppercase">
					<tr>  
						<th class="text-center"><?= $this->lang->line('date');?></th>
						<th class="text-center" colspan="2"><?= $this->lang->line('particulars');?></th>
						<th class="text-center"><?= $this->lang->line('voucher');?></th>
						<th class="text-center"><?= $this->lang->line('debit');?></th>
						<th class="text-center"><?= $this->lang->line('credit');?></th>
						<th class="text-center"><?= $this->lang->line('balance');?></th>
					</tr>
				</thead>
				<tbody>
					<?php
					$total_balance = 0;
					if($general_ledger > 0) {
					$opening_balance_query =  $this->db->select("SUM(accounts_details_debit) as opening_debit_balance, SUM(accounts_details_credit) as opening_credit_balance, (SUM(accounts_details_debit) - SUM(accounts_details_credit)) as  opening_balance")
					->from('accounts_details') 
					->where('accounts_details_general_ledger', $general_ledger)
					->where('accounts_details_voucher_posting_date BETWEEN "'.$opening_balance_starting_date.'" and "'.$opening_balance_closing_date.'"')
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					} else {
					$opening_balance_query =  $this->db->select("SUM(accounts_details_debit) as opening_debit_balance, SUM(accounts_details_credit) as opening_credit_balance, (SUM(accounts_details_debit) - SUM(accounts_details_credit)) as  opening_balance")
					->from('accounts_details') 
					->where('accounts_details_control_group', $control_group)
					->where('accounts_details_voucher_posting_date BETWEEN "'.$opening_balance_starting_date.'" and "'.$opening_balance_closing_date.'"')
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					}
					foreach($opening_balance_query as $opening_balance_row)
					{
						$opening_debit_balance		= $opening_balance_row->opening_debit_balance;
						$opening_credit_balance		= $opening_balance_row->opening_credit_balance;
						$opening_balance			= $opening_balance_row->opening_balance;
					}?>
					<tr>
						<td class="text-center">-</td>
						<td class="text-left" colspan="2"><?= $this->lang->line('opening_balance');?></td>
						<td class="text-center">-</td>
						<td class="text-right"><?php if ($opening_debit_balance >0) { echo' '.number_format($opening_debit_balance, 2 . '').' ';} else if ($opening_debit_balance == 0) { echo'-';} else { echo' '.number_format(abs($opening_debit_balance),2 . '').' ';} ?></td>
						<td class="text-right"><?php if ($opening_credit_balance >0) { echo' '.number_format($opening_credit_balance, 2 . '').' ';} else if ($opening_credit_balance == 0) { echo'-';} else { echo' '.number_format(abs($opening_credit_balance),2 . '').' ';} ?></td>
						<td class="text-right"><?php if ($opening_balance >0) { echo' '.number_format($opening_balance, 2 . '').' ';} else if ($opening_balance == 0) { echo'-';} else { echo' '.number_format(abs($opening_balance),2 . '').' ';} ?></td>
					</tr>
					<?php
					$general_ledger_debit_balance = 0;
					$general_ledger_credit_balance = 0;
					
					$total_general_ledger_debit_balance = $opening_debit_balance;
					$total_general_ledger_credit_balance = $opening_credit_balance;
					$general_ledger_balance = $opening_balance;
					
					if($general_ledger > 0) {
					$general_ledger_balance_query =  $this->db->select("*")
					->from('accounts_details')
					->join('chart_of_accounts', 'accounts_details.accounts_details_subsidiary_ledger = chart_of_accounts.chart_of_accounts_id', 'LEFT') 
					->where('accounts_details.accounts_details_general_ledger', $general_ledger)
					->where('accounts_details.accounts_details_voucher_posting_date BETWEEN "'.$starting_date.'" and "'.$closing_date.'"')
					->order_by('accounts_details.accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					} else {
					$general_ledger_balance_query =  $this->db->select("*")
					->from('accounts_details')
					->join('chart_of_accounts', 'accounts_details.accounts_details_subsidiary_ledger = chart_of_accounts.chart_of_accounts_id', 'LEFT')  
					->where('accounts_details_control_group', $control_group)
					->where('accounts_details.accounts_details_voucher_posting_date BETWEEN "'.$starting_date.'" and "'.$closing_date.'"')
					->order_by('accounts_details.accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					}
					foreach($general_ledger_balance_query as $general_ledger_balance_query_row)
					{
						$debit_balance						= $general_ledger_balance_query_row->accounts_details_debit;
						$credit_balance						= $general_ledger_balance_query_row->accounts_details_credit;  
						
						$general_ledger_debit_balance		+= $debit_balance;
						$general_ledger_credit_balance		+= $credit_balance;
						
						$total_general_ledger_debit_balance		+= $debit_balance;
						$total_general_ledger_credit_balance		+= $credit_balance;
						$general_ledger_balance				+= $debit_balance - $credit_balance;
					?>
					<tr>
						<td class="text-center"><?= date('d/m/Y', strtotime($general_ledger_balance_query_row->accounts_details_voucher_posting_date));?></td>
						<td class="text-left"><?= $general_ledger_balance_query_row->chart_of_accounts_code;?> - <?= $general_ledger_balance_query_row->chart_of_accounts_name;?></td>
						<td class="text-left"><?= $general_ledger_balance_query_row->accounts_details_narration;?></td>
						<td class="text-center"><?= $general_ledger_balance_query_row->accounts_details_voucher_number;?></td> 
						<td class="text-right"><?php if ($debit_balance >0) { echo' '.number_format($debit_balance, 2 . '').' ';} else if ($debit_balance == 0) { echo'-';} else { echo' '.number_format(abs($debit_balance),2 . '').' ';} ?></td>
						<td class="text-right"><?php if ($credit_balance >0) { echo' '.number_format($credit_balance, 2 . '').' ';} else if ($credit_balance == 0) { echo'-';} else { echo' '.number_format(abs($credit_balance),2 . '').' ';} ?></td>
						<td class="text-right"><?php if ($general_ledger_balance >0) { echo' '.number_format($general_ledger_balance, 2 . '').' ';} else if ($general_ledger_balance == 0) { echo'-';} else { echo' '.number_format(abs($general_ledger_balance),2 . '').' ';} ?></td>
					</tr>
					<?php }
					
					$total_balance 			+= $general_ledger_balance;
					?>
					
					<tr class="text-uppercase">
						<th class="text-right" colspan="4"><?= $this->lang->line('sub_total');?></th> 
						<th class="text-right"><?php if ($general_ledger_debit_balance >0) { echo' '.number_format($general_ledger_debit_balance, 2 . '').' ';} else if ($general_ledger_debit_balance == 0) { echo'-';} else { echo' '.number_format(abs($general_ledger_debit_balance),2 . '').' ';} ?></th>
						<th class="text-right"><?php if ($general_ledger_credit_balance >0) { echo' '.number_format($general_ledger_credit_balance, 2 . '').' ';} else if ($general_ledger_credit_balance == 0) { echo'-';} else { echo' '.number_format(abs($general_ledger_credit_balance),2 . '').' ';} ?></th>
						<th class="text-right"><?php if ($general_ledger_debit_balance-$general_ledger_credit_balance >0) { echo' '.number_format($general_ledger_debit_balance-$general_ledger_credit_balance, 2 . '').' ';} else if ($general_ledger_debit_balance-$general_ledger_credit_balance == 0) { echo'-';} else { echo' '.number_format(abs($general_ledger_debit_balance-$general_ledger_credit_balance),2 . '').' ';} ?></th>
					</tr>
					
					<tr class="text-uppercase">
						<th class="text-right" colspan="4"><?= $this->lang->line('total_amount');?></th> 
						<th class="text-right"><?php if ($total_general_ledger_debit_balance >0) { echo' '.number_format($total_general_ledger_debit_balance, 2 . '').' ';} else if ($total_general_ledger_debit_balance == 0) { echo'-';} else { echo' '.number_format(abs($total_general_ledger_debit_balance),2 . '').' ';} ?></th>
						<th class="text-right"><?php if ($total_general_ledger_credit_balance >0) { echo' '.number_format($total_general_ledger_credit_balance, 2 . '').' ';} else if ($total_general_ledger_credit_balance == 0) { echo'-';} else { echo' '.number_format(abs($total_general_ledger_credit_balance),2 . '').' ';} ?></th>
						<th class="text-right"><?php if ($total_balance >0) { echo' '.number_format($total_balance, 2 . '').' ';} else if ($total_balance == 0) { echo'-';} else { echo' '.number_format(abs($total_balance),2 . '').' ';} ?></th>
					</tr>
					<tr class="text-uppercase">
						<th class="text-left" colspan="7"><?= $this->lang->line('in_word');?>: 
						<?php 
						$number = abs($total_balance);
						$in_word_amount = $this->number_to_word_convert->convert_number($number);
						?>
						<?= $in_word_amount;?> <?= $this->lang->line('currency_only');?>.
						</th>
					</tr>
				</tbody>
			</table>
			
			
			
		
			<br/><br/><br/><br/>
			
			<table class="" width="100%" align="center">  
				<tr class="text-uppercase">
					<th width="30%" class="text-center bd-top"><?= $this->lang->line('prepared_by');?></th>
					<th width="5%"></th>
					<th width="30%" class="text-center bd-top"><?= $this->lang->line('checked_by');?></th>
					<th width="5%"></th>
					<th width="30%" class="text-center bd-top"><?= $this->lang->line('authorised');?></th>
				</tr>
			</table>
		</div>
		<?php 
		return $output;
	}
	
	/* ------------------------------------------------------
	Subsidiary Ledger Model
	------------------------------------------------------- */
	function subsidiary_ledger($accounts_type, $accounts_category, $control_group, $general_ledger, $subsidiary_ledger, $starting_date, $closing_date)
	{	
		$output = '';
		$opening_balance_starting_date = date('2015-01-01');
		$opening_balance_closing_date = date('Y-m-d', strtotime($starting_date. "last day"));
		
		$control_group_code ='';
		$control_group_name ='';
		$subsidiary_ledger_code ='';
		$subsidiary_ledger_name ='';
		
		$control_group_query =  $this->db->select("*")
		->from('chart_of_accounts')
		->where('chart_of_accounts_id', $control_group)
		->order_by('chart_of_accounts_id', 'ASC') 
		->get()
		->result();
		foreach($control_group_query as $control_group_row)
		{
		$control_group_code = $control_group_row->chart_of_accounts_code;
		$control_group_name = $control_group_row->chart_of_accounts_name;
		}
		
		$general_ledger_query =  $this->db->select("*")
		->from('chart_of_accounts')
		->where('chart_of_accounts_id', $general_ledger)
		->order_by('chart_of_accounts_id', 'ASC') 
		->get()
		->result();
		foreach($general_ledger_query as $general_ledger_row)
		{
		$general_ledger_code = $general_ledger_row->chart_of_accounts_code;
		$general_ledger_name = $general_ledger_row->chart_of_accounts_name;
		}
		
		$subsidiary_ledger_query =  $this->db->select("*")
		->from('chart_of_accounts')
		->where('chart_of_accounts_id', $subsidiary_ledger)
		->order_by('chart_of_accounts_id', 'ASC') 
		->get()
		->result();
		foreach($subsidiary_ledger_query as $subsidiary_ledger_row)
		{
		$subsidiary_ledger_code = $subsidiary_ledger_row->chart_of_accounts_code;
		$subsidiary_ledger_name = $subsidiary_ledger_row->chart_of_accounts_name;
		}
		?>
		<table class="text-uppercase" width="100%" align="center">
			<tr>
				<th class="text-left" width="19%"><?= $this->lang->line('control_group');?></th>
				<th class="text-center" width="1%">:</th>
				<th class="text-left" width="80%"><?= $control_group_name;?> (<?= $control_group_code;?>)</th>
			</tr>
			<tr>
				<th class="text-left" width="19%"><?= $this->lang->line('general_ledger');?></th>
				<th class="text-center" width="1%">:</th>
				<th class="text-left" width="80%"><?= $general_ledger_name;?> (<?= $general_ledger_code;?>)</th>
			</tr>
			<tr>
				<th class="text-left" width="19%"><?= $this->lang->line('subsidiary_ledger');?></th>
				<th class="text-center" width="1%">:</th>
				<th class="text-left" width="80%"><?= $subsidiary_ledger_name;?> (<?= $subsidiary_ledger_code;?>)</th>
			</tr>
		</table>
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-hover">
				<thead class="text-10 text-uppercase">
					<tr>  
						<th class="text-center"><?= $this->lang->line('date');?></th>
						<th class="text-center"><?= $this->lang->line('particulars');?></th>
						<th class="text-center"><?= $this->lang->line('voucher');?></th>
						<th class="text-center"><?= $this->lang->line('debit');?></th>
						<th class="text-center"><?= $this->lang->line('credit');?></th>
						<th class="text-center"><?= $this->lang->line('balance');?></th>
					</tr>
				</thead>
				<tbody>
					<?php
					$total_balance = 0; 
					$opening_balance = 0;
					$opening_balance_query =  $this->db->select("SUM(accounts_details_debit) as opening_debit_balance, SUM(accounts_details_credit) as opening_credit_balance, (SUM(accounts_details_debit) - SUM(accounts_details_credit)) as  opening_balance")
					->from('accounts_details')
					->where('accounts_details_subsidiary_ledger', $subsidiary_ledger)
					->where('accounts_details_voucher_posting_date BETWEEN "'.$opening_balance_starting_date.'" and "'.$opening_balance_closing_date.'"')
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($opening_balance_query as $opening_balance_row)
					{
						$opening_debit_balance		= $opening_balance_row->opening_debit_balance;
						$opening_credit_balance		= $opening_balance_row->opening_credit_balance;
						$opening_balance			= $opening_balance_row->opening_balance;
					}?>
					<tr>
						<td class="text-center">-</td>
						<td class="text-left"><?= $this->lang->line('opening_balance');?></td>
						<td class="text-center">-</td>
						<td class="text-right"><?php if ($opening_debit_balance >0) { echo' '.number_format($opening_debit_balance, 2 . '').' ';} else if ($opening_debit_balance == 0) { echo'-';} else { echo' '.number_format(abs($opening_debit_balance),2 . '').' ';} ?></td>
						<td class="text-right"><?php if ($opening_credit_balance >0) { echo' '.number_format($opening_credit_balance, 2 . '').' ';} else if ($opening_credit_balance == 0) { echo'-';} else { echo' '.number_format(abs($opening_credit_balance),2 . '').' ';} ?></td>
						<td class="text-right"><?php if ($opening_balance >0) { echo' '.number_format($opening_balance, 2 . '').' ';} else if ($opening_balance == 0) { echo'-';} else { echo' '.number_format(abs($opening_balance),2 . '').' ';} ?></td>
					</tr>
					<?php
					$subsidiary_ledger_debit_balance = 0;
					$subsidiary_ledger_credit_balance = 0;
					
					$total_subsidiary_ledger_debit_balance = $opening_debit_balance;
					$total_subsidiary_ledger_credit_balance = $opening_credit_balance;
					
					$subsidiary_ledger_balance = $opening_balance;
					
					$subsidiary_ledger_balance_query =  $this->db->select("*")
					->from('accounts_details')
					->join('chart_of_accounts', 'accounts_details.accounts_details_subsidiary_ledger = chart_of_accounts.chart_of_accounts_id', 'LEFT') 
					->where('accounts_details.accounts_details_subsidiary_ledger', $subsidiary_ledger)
					->where('accounts_details.accounts_details_voucher_posting_date BETWEEN "'.$starting_date.'" and "'.$closing_date.'"')
					->order_by('accounts_details.accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($subsidiary_ledger_balance_query as $subsidiary_ledger_balance_query_row)
					{
						$debit_balance						= $subsidiary_ledger_balance_query_row->accounts_details_debit;
						$credit_balance						= $subsidiary_ledger_balance_query_row->accounts_details_credit;  
						
						$subsidiary_ledger_debit_balance		+= $debit_balance;
						$subsidiary_ledger_credit_balance		+= $credit_balance;
						
						$total_subsidiary_ledger_debit_balance		+= $debit_balance;
						$total_subsidiary_ledger_credit_balance		+= $credit_balance;
						$subsidiary_ledger_balance				+= $debit_balance - $credit_balance;
					?>
					<tr>
						<td class="text-center"><?= date('d/m/Y', strtotime($subsidiary_ledger_balance_query_row->accounts_details_voucher_posting_date));?></td>
						<td class="text-left"><?= $subsidiary_ledger_balance_query_row->accounts_details_narration;?></td>
						<td class="text-center"><?= $subsidiary_ledger_balance_query_row->accounts_details_voucher_number;?></td> 
						<td class="text-right"><?php if ($debit_balance >0) { echo' '.number_format($debit_balance, 2 . '').' ';} else if ($debit_balance == 0) { echo'-';} else { echo' '.number_format(abs($debit_balance),2 . '').' ';} ?></td>
						<td class="text-right"><?php if ($credit_balance >0) { echo' '.number_format($credit_balance, 2 . '').' ';} else if ($credit_balance == 0) { echo'-';} else { echo' '.number_format(abs($credit_balance),2 . '').' ';} ?></td>
						<td class="text-right"><?php if ($subsidiary_ledger_balance >0) { echo' '.number_format($subsidiary_ledger_balance, 2 . '').' ';} else if ($subsidiary_ledger_balance == 0) { echo'-';} else { echo' '.number_format(abs($subsidiary_ledger_balance),2 . '').' ';} ?></td>
					</tr>
					<?php }
					
					$total_balance 			+= $subsidiary_ledger_balance; 
					?>
					
					<tr class="text-uppercase">
						<th class="text-right" colspan="3"><?= $this->lang->line('sub_total');?></th> 
						<th class="text-right"><?php if ($subsidiary_ledger_debit_balance >0) { echo' '.number_format($subsidiary_ledger_debit_balance, 2 . '').' ';} else if ($subsidiary_ledger_debit_balance == 0) { echo'-';} else { echo' '.number_format(abs($subsidiary_ledger_debit_balance),2 . '').' ';} ?></th>
						<th class="text-right"><?php if ($subsidiary_ledger_credit_balance >0) { echo' '.number_format($subsidiary_ledger_credit_balance, 2 . '').' ';} else if ($subsidiary_ledger_credit_balance == 0) { echo'-';} else { echo' '.number_format(abs($subsidiary_ledger_credit_balance),2 . '').' ';} ?></th>
						<th class="text-right"><?php if ($subsidiary_ledger_debit_balance-$subsidiary_ledger_credit_balance >0) { echo' '.number_format($subsidiary_ledger_debit_balance-$subsidiary_ledger_credit_balance, 2 . '').' ';} else if ($subsidiary_ledger_debit_balance-$subsidiary_ledger_credit_balance == 0) { echo'-';} else { echo' '.number_format(abs($subsidiary_ledger_debit_balance-$subsidiary_ledger_credit_balance),2 . '').' ';} ?></th>
					</tr>
					
					<tr class="text-uppercase">
						<th class="text-right" colspan="3"><?= $this->lang->line('total_amount');?></th> 
						<th class="text-right"><?php if ($total_subsidiary_ledger_debit_balance >0) { echo' '.number_format($total_subsidiary_ledger_debit_balance, 2 . '').' ';} else if ($total_subsidiary_ledger_debit_balance == 0) { echo'-';} else { echo' '.number_format(abs($total_subsidiary_ledger_debit_balance),2 . '').' ';} ?></th>
						<th class="text-right"><?php if ($total_subsidiary_ledger_credit_balance >0) { echo' '.number_format($total_subsidiary_ledger_credit_balance, 2 . '').' ';} else if ($total_subsidiary_ledger_credit_balance == 0) { echo'-';} else { echo' '.number_format(abs($total_subsidiary_ledger_credit_balance),2 . '').' ';} ?></th>
						<th class="text-right"><?php if ($total_balance >0) { echo' '.number_format($total_balance, 2 . '').' ';} else if ($total_balance == 0) { echo'-';} else { echo' '.number_format(abs($total_balance),2 . '').' ';} ?></th>
					</tr>
					<tr class="text-uppercase">
						<th class="text-left" colspan="7"><?= $this->lang->line('in_word');?>: 
						<?php 
						$number = abs($total_balance);
						$in_word_amount = $this->number_to_word_convert->convert_number($number);
						?>
						<?= $in_word_amount;?> <?= $this->lang->line('currency_only');?>.
						</th>
					</tr>
				</tbody>
			</table>
		</div>
		<?php 
		return $output;
	}
	
	/* ------------------------------------------------------
	Subsidiary Ledger Print Model
	------------------------------------------------------- */
	function subsidiary_ledger_print($accounts_type, $accounts_category, $control_group, $general_ledger, $subsidiary_ledger, $starting_date, $closing_date)
	{	
		$output = '';
		$opening_balance_starting_date = date('2015-01-01');
		$opening_balance_closing_date = date('Y-m-d', strtotime($starting_date. "last day"));
		
		$control_group_code ='';
		$control_group_name ='';
		$subsidiary_ledger_code ='';
		$subsidiary_ledger_name ='';
		
		$control_group_query =  $this->db->select("*")
		->from('chart_of_accounts')
		->where('chart_of_accounts_id', $control_group)
		->order_by('chart_of_accounts_id', 'ASC') 
		->get()
		->result();
		foreach($control_group_query as $control_group_row)
		{
		$control_group_code = $control_group_row->chart_of_accounts_code;
		$control_group_name = $control_group_row->chart_of_accounts_name;
		}
		
		$general_ledger_query =  $this->db->select("*")
		->from('chart_of_accounts')
		->where('chart_of_accounts_id', $general_ledger)
		->order_by('chart_of_accounts_id', 'ASC') 
		->get()
		->result();
		foreach($general_ledger_query as $general_ledger_row)
		{
		$general_ledger_code = $general_ledger_row->chart_of_accounts_code;
		$general_ledger_name = $general_ledger_row->chart_of_accounts_name;
		}
		
		$subsidiary_ledger_query =  $this->db->select("*")
		->from('chart_of_accounts')
		->where('chart_of_accounts_id', $subsidiary_ledger)
		->order_by('chart_of_accounts_id', 'ASC') 
		->get()
		->result();
		foreach($subsidiary_ledger_query as $subsidiary_ledger_row)
		{
		$subsidiary_ledger_code = $subsidiary_ledger_row->chart_of_accounts_code;
		$subsidiary_ledger_name = $subsidiary_ledger_row->chart_of_accounts_name;
		}
		?>
		<table class="text-uppercase" width="100%" align="center">
			<tr>
				<th class="text-left" width="19%"><?= $this->lang->line('control_group');?></th>
				<th class="text-center" width="1%">:</th>
				<th class="text-left" width="80%"><?= $control_group_name;?> (<?= $control_group_code;?>)</th>
			</tr>
			<tr>
				<th class="text-left" width="19%"><?= $this->lang->line('general_ledger');?></th>
				<th class="text-center" width="1%">:</th>
				<th class="text-left" width="80%"><?= $general_ledger_name;?> (<?= $general_ledger_code;?>)</th>
			</tr>
			<tr>
				<th class="text-left" width="9%"><?= $this->lang->line('subsidiary_ledger');?></th>
				<th class="text-center" width="1%">:</th>
				<th class="text-left" width="80%"><?= $subsidiary_ledger_name;?> (<?= $subsidiary_ledger_code;?>)</th>
			</tr>
		</table>
		<div class="">
			<table class="table table-striped table-bordered table-hover">
				<thead class="text-10 text-uppercase">
					<tr>  
						<th class="text-center"><?= $this->lang->line('date');?></th>
						<th class="text-center"><?= $this->lang->line('particulars');?></th>
						<th class="text-center"><?= $this->lang->line('voucher');?></th>
						<th class="text-center"><?= $this->lang->line('debit');?></th>
						<th class="text-center"><?= $this->lang->line('credit');?></th>
						<th class="text-center"><?= $this->lang->line('balance');?></th>
					</tr>
				</thead>
				<tbody>
					<?php
					$total_balance = 0; 
					$opening_balance = 0;
					$opening_balance_query =  $this->db->select("SUM(accounts_details_debit) as opening_debit_balance, SUM(accounts_details_credit) as opening_credit_balance, (SUM(accounts_details_debit) - SUM(accounts_details_credit)) as  opening_balance")
					->from('accounts_details')
					->where('accounts_details_subsidiary_ledger', $subsidiary_ledger)
					->where('accounts_details_voucher_posting_date BETWEEN "'.$opening_balance_starting_date.'" and "'.$opening_balance_closing_date.'"')
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($opening_balance_query as $opening_balance_row)
					{
						$opening_debit_balance		= $opening_balance_row->opening_debit_balance;
						$opening_credit_balance		= $opening_balance_row->opening_credit_balance;
						$opening_balance			= $opening_balance_row->opening_balance;
					}?>
					<tr>
						<td class="text-center">-</td>
						<td class="text-left"><?= $this->lang->line('opening_balance');?></td>
						<td class="text-center">-</td>
						<td class="text-right"><?php if ($opening_debit_balance >0) { echo' '.number_format($opening_debit_balance, 2 . '').' ';} else if ($opening_debit_balance == 0) { echo'-';} else { echo' '.number_format(abs($opening_debit_balance),2 . '').' ';} ?></td>
						<td class="text-right"><?php if ($opening_credit_balance >0) { echo' '.number_format($opening_credit_balance, 2 . '').' ';} else if ($opening_credit_balance == 0) { echo'-';} else { echo' '.number_format(abs($opening_credit_balance),2 . '').' ';} ?></td>
						<td class="text-right"><?php if ($opening_balance >0) { echo' '.number_format($opening_balance, 2 . '').' ';} else if ($opening_balance == 0) { echo'-';} else { echo' '.number_format(abs($opening_balance),2 . '').' ';} ?></td>
					</tr>
					<?php
					$subsidiary_ledger_debit_balance = 0;
					$subsidiary_ledger_credit_balance = 0;
					
					$total_subsidiary_ledger_debit_balance = $opening_debit_balance;
					$total_subsidiary_ledger_credit_balance = $opening_credit_balance;
					
					$subsidiary_ledger_balance = $opening_balance;
					
					$subsidiary_ledger_balance_query =  $this->db->select("*")
					->from('accounts_details')
					->join('chart_of_accounts', 'accounts_details.accounts_details_subsidiary_ledger = chart_of_accounts.chart_of_accounts_id', 'LEFT') 
					->where('accounts_details.accounts_details_subsidiary_ledger', $subsidiary_ledger)
					->where('accounts_details.accounts_details_voucher_posting_date BETWEEN "'.$starting_date.'" and "'.$closing_date.'"')
					->order_by('accounts_details.accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($subsidiary_ledger_balance_query as $subsidiary_ledger_balance_query_row)
					{
						$debit_balance						= $subsidiary_ledger_balance_query_row->accounts_details_debit;
						$credit_balance						= $subsidiary_ledger_balance_query_row->accounts_details_credit;  
						
						$subsidiary_ledger_debit_balance		+= $debit_balance;
						$subsidiary_ledger_credit_balance		+= $credit_balance;
						
						$total_subsidiary_ledger_debit_balance		+= $debit_balance;
						$total_subsidiary_ledger_credit_balance		+= $credit_balance;
						$subsidiary_ledger_balance				+= $debit_balance - $credit_balance;
					?>
					<tr>
						<td class="text-center"><?= date('d/m/Y', strtotime($subsidiary_ledger_balance_query_row->accounts_details_voucher_posting_date));?></td>
						<td class="text-left"><?= $subsidiary_ledger_balance_query_row->accounts_details_narration;?></td>
						<td class="text-center"><?= $subsidiary_ledger_balance_query_row->accounts_details_voucher_number;?></td> 
						<td class="text-right"><?php if ($debit_balance >0) { echo' '.number_format($debit_balance, 2 . '').' ';} else if ($debit_balance == 0) { echo'-';} else { echo' '.number_format(abs($debit_balance),2 . '').' ';} ?></td>
						<td class="text-right"><?php if ($credit_balance >0) { echo' '.number_format($credit_balance, 2 . '').' ';} else if ($credit_balance == 0) { echo'-';} else { echo' '.number_format(abs($credit_balance),2 . '').' ';} ?></td>
						<td class="text-right"><?php if ($subsidiary_ledger_balance >0) { echo' '.number_format($subsidiary_ledger_balance, 2 . '').' ';} else if ($subsidiary_ledger_balance == 0) { echo'-';} else { echo' '.number_format(abs($subsidiary_ledger_balance),2 . '').' ';} ?></td>
					</tr>
					<?php }
					
					$total_balance 			+= $subsidiary_ledger_balance; 
					?>
					
					<tr class="text-uppercase">
						<th class="text-right" colspan="3"><?= $this->lang->line('sub_total');?></th> 
						<th class="text-right"><?php if ($subsidiary_ledger_debit_balance >0) { echo' '.number_format($subsidiary_ledger_debit_balance, 2 . '').' ';} else if ($subsidiary_ledger_debit_balance == 0) { echo'-';} else { echo' '.number_format(abs($subsidiary_ledger_debit_balance),2 . '').' ';} ?></th>
						<th class="text-right"><?php if ($subsidiary_ledger_credit_balance >0) { echo' '.number_format($subsidiary_ledger_credit_balance, 2 . '').' ';} else if ($subsidiary_ledger_credit_balance == 0) { echo'-';} else { echo' '.number_format(abs($subsidiary_ledger_credit_balance),2 . '').' ';} ?></th>
						<th class="text-right"><?php if ($subsidiary_ledger_debit_balance-$subsidiary_ledger_credit_balance >0) { echo' '.number_format($subsidiary_ledger_debit_balance-$subsidiary_ledger_credit_balance, 2 . '').' ';} else if ($subsidiary_ledger_debit_balance-$subsidiary_ledger_credit_balance == 0) { echo'-';} else { echo' '.number_format(abs($subsidiary_ledger_debit_balance-$subsidiary_ledger_credit_balance),2 . '').' ';} ?></th>
					</tr>
					
					<tr class="text-uppercase">
						<th class="text-right" colspan="3"><?= $this->lang->line('total_amount');?></th> 
						<th class="text-right"><?php if ($total_subsidiary_ledger_debit_balance >0) { echo' '.number_format($total_subsidiary_ledger_debit_balance, 2 . '').' ';} else if ($total_subsidiary_ledger_debit_balance == 0) { echo'-';} else { echo' '.number_format(abs($total_subsidiary_ledger_debit_balance),2 . '').' ';} ?></th>
						<th class="text-right"><?php if ($total_subsidiary_ledger_credit_balance >0) { echo' '.number_format($total_subsidiary_ledger_credit_balance, 2 . '').' ';} else if ($total_subsidiary_ledger_credit_balance == 0) { echo'-';} else { echo' '.number_format(abs($total_subsidiary_ledger_credit_balance),2 . '').' ';} ?></th>
						<th class="text-right"><?php if ($total_balance >0) { echo' '.number_format($total_balance, 2 . '').' ';} else if ($total_balance == 0) { echo'-';} else { echo' '.number_format(abs($total_balance),2 . '').' ';} ?></th>
					</tr>
					<tr class="text-uppercase">
						<th class="text-left" colspan="7"><?= $this->lang->line('in_word');?>: 
						<?php 
						$number = abs($total_balance);
						$in_word_amount = $this->number_to_word_convert->convert_number($number);
						?>
						<?= $in_word_amount;?> <?= $this->lang->line('currency_only');?>.
						</th>
					</tr>
				</tbody>
			</table>
		
			<br/><br/><br/><br/>
			
			<table class="" width="100%" align="center">  
				<tr class="text-uppercase">
					<th width="30%" class="text-center bd-top"><?= $this->lang->line('prepared_by');?></th>
					<th width="5%"></th>
					<th width="30%" class="text-center bd-top"><?= $this->lang->line('checked_by');?></th>
					<th width="5%"></th>
					<th width="30%" class="text-center bd-top"><?= $this->lang->line('authorised');?></th>
				</tr>
			</table>
						
		</div>
		<?php 
		return $output;
	}
	
	/* ------------------------------------------------------
	Trial Balance Model
	------------------------------------------------------- */
	function trial_balance($posting_to_date)
	{	
		$posting_from_date = date('2015-01-01');
		$output = '';
		 
		$total_debit_amount = 0;
		$total_credit_amount = 0;
		
		$accounts_type =  $this->db->select("*") ->from('accounts_type') ->where('accounts_type_status', 1) ->order_by('accounts_type_code', 'ASC') ->get()->result();
		foreach($accounts_type as $accounts_type_row)
		{
		?> 
		<tr class="text-uppercase">
			<th class="text-center"><?= $accounts_type_row->accounts_type_code ;?></td>
			<th class="text-left"><?= $accounts_type_row->accounts_type_name ;?></td>
			<?php $accounts_type_amount =  $this->db->select(" SUM(accounts_details_debit) as accounts_type_debit_balance, SUM(accounts_details_credit) as accounts_type_credit_balance") ->from('accounts_details') ->where('accounts_details_voucher_type<>', 3) ->where('accounts_details_accounts_type', $accounts_type_row->accounts_type_id) ->where('accounts_details_voucher_posting_date BETWEEN "'.$posting_from_date.'" and "'.$posting_to_date.'"')  ->where('accounts_details_status', 1) ->order_by('accounts_details_voucher_posting_date', 'ASC') ->get()->result();
			foreach($accounts_type_amount as $accounts_type_amount_row)
			{
			$accounts_type_debit_balance_amount		= $accounts_type_amount_row->accounts_type_debit_balance;
			$accounts_type_credit_balance_amount	= $accounts_type_amount_row->accounts_type_credit_balance;
			
			if ($accounts_type_debit_balance_amount > $accounts_type_credit_balance_amount) 
			{
				$accounts_type_debit_balance	= $accounts_type_debit_balance_amount - $accounts_type_credit_balance_amount;
				$accounts_type_credit_balance	= 0.00;
			}
			else if($accounts_type_debit_balance_amount < $accounts_type_credit_balance_amount) 
			{ 
				$accounts_type_debit_balance	= 0.00;
				$accounts_type_credit_balance	= $accounts_type_credit_balance_amount - $accounts_type_debit_balance_amount;
			}
			else
			{
				$accounts_type_debit_balance	= 0.00;
				$accounts_type_credit_balance	= 0.00;
			}
			$total_debit_amount					+= $accounts_type_debit_balance;
			$total_credit_amount				+= $accounts_type_credit_balance;
			?>
			<th class="text-right"><?php if ($accounts_type_debit_balance >0) { echo' '.number_format($accounts_type_debit_balance, 2 . '').' ';} else { echo'-';} ?></th>
			<th class="text-right"><?php if ($accounts_type_credit_balance >0) { echo' '.number_format($accounts_type_credit_balance, 2 . '').' ';} else { echo'-';} ?></th>
			<?php }?>
		</tr>
		<?php $accounts_category =  $this->db->select("distinct(accounts_details_accounts_category) as chart_of_accounts_id, chart_of_accounts_code, chart_of_accounts_name") 
		->from('accounts_details') 
		->join('chart_of_accounts', 'accounts_details.accounts_details_accounts_category = chart_of_accounts.chart_of_accounts_id', 'LEFT')
		->where('chart_of_accounts.chart_of_accounts_accounts_category', $accounts_type_row->accounts_type_id) 
		->where('accounts_details_voucher_posting_date BETWEEN "'.$posting_from_date.'" and "'.$posting_to_date.'"')
		->group_by('chart_of_accounts.chart_of_accounts_code', 'ASC') 
		->get() 
		->result();
		foreach($accounts_category as $accounts_category_row)	
		{?>
		<tr class="text-uppercase">
			<th class="text-center"><?= $accounts_category_row->chart_of_accounts_code;?></th>
			<th class="text-left"><?= $accounts_category_row->chart_of_accounts_name;?></th>
			<?php $accounts_category_amount =  $this->db->select(" SUM(accounts_details_debit) as accounts_category_debit_balance, SUM(accounts_details_credit) as accounts_category_credit_balance") ->from('accounts_details') ->where('accounts_details_voucher_type<>', 3) ->where('accounts_details_accounts_category', $accounts_category_row->chart_of_accounts_id) ->where('accounts_details_voucher_posting_date BETWEEN "'.$posting_from_date.'" and "'.$posting_to_date.'"')   ->where('accounts_details_status', 1) ->order_by('accounts_details_voucher_posting_date', 'ASC') ->get()->result();
			foreach($accounts_category_amount as $accounts_category_amount_row)
			{
			$accounts_type_debit_balance_amount		= $accounts_category_amount_row->accounts_category_debit_balance;
			$accounts_type_credit_balance_amount	= $accounts_category_amount_row->accounts_category_credit_balance;
			
			if ($accounts_type_debit_balance_amount > $accounts_type_credit_balance_amount) 
			{
				$accounts_category_debit_balance	= $accounts_type_debit_balance_amount - $accounts_type_credit_balance_amount;
				$accounts_category_credit_balance	= 0.00;
			}
			else if($accounts_type_debit_balance_amount < $accounts_type_credit_balance_amount) 
			{ 
				$accounts_category_debit_balance	= 0.00;
				$accounts_category_credit_balance	= $accounts_type_credit_balance_amount - $accounts_type_debit_balance_amount;
			}
			else
			{
				$accounts_category_debit_balance	= 0.00;
				$accounts_category_credit_balance	= 0.00;
			}
			?>
			<th class="text-right"><?php if ($accounts_category_debit_balance >0) { echo' '.number_format($accounts_category_debit_balance, 2 . '').' ';} else { echo'-';} ?></th>
			<th class="text-right"><?php if ($accounts_category_credit_balance >0) { echo' '.number_format($accounts_category_credit_balance, 2 . '').' ';} else { echo'-';} ?></th>
			<?php }?>
		</tr> 
		<?php $control_group =  $this->db->select("distinct(accounts_details_control_group) as control_group, chart_of_accounts_code, chart_of_accounts_name") 
		->from('accounts_details') 
		->join('chart_of_accounts', 'accounts_details.accounts_details_control_group = chart_of_accounts.chart_of_accounts_id', 'LEFT')
		->where('chart_of_accounts.chart_of_accounts_accounts_category', $accounts_category_row->chart_of_accounts_id) 
		->where('accounts_details_voucher_posting_date BETWEEN "'.$posting_from_date.'" and "'.$posting_to_date.'"')
		->group_by('chart_of_accounts.chart_of_accounts_code', 'ASC') 
		->get() 
		->result();
		foreach($control_group as $control_group_row)
		{?>
		<tr class="">
			<th class="text-center"><?= $control_group_row->chart_of_accounts_code;?></th>
			<th class="text-left"><?= $control_group_row->chart_of_accounts_name;?></th>
			<?php $control_group_amount =  $this->db->select(" SUM(accounts_details_debit) as control_group_debit_balance, SUM(accounts_details_credit) as control_group_credit_balance") ->from('accounts_details') ->where('accounts_details_voucher_type<>', 3) ->where('accounts_details_control_group', $control_group_row->control_group) ->where('accounts_details_voucher_posting_date BETWEEN "'.$posting_from_date.'" and "'.$posting_to_date.'"')  ->where('accounts_details_status', 1) ->order_by('accounts_details_voucher_posting_date', 'ASC') ->get()->result();
			foreach($control_group_amount as $control_group_amount_row)
			{
			$accounts_type_debit_balance_amount		= $control_group_amount_row->control_group_debit_balance;
			$accounts_type_credit_balance_amount	= $control_group_amount_row->control_group_credit_balance;
			
			if ($accounts_type_debit_balance_amount > $accounts_type_credit_balance_amount) 
			{
				$control_group_debit_balance	= $accounts_type_debit_balance_amount - $accounts_type_credit_balance_amount;
				$control_group_credit_balance	= 0.00;
			}
			else if($accounts_type_debit_balance_amount < $accounts_type_credit_balance_amount) 
			{ 
				$control_group_debit_balance	= 0.00;
				$control_group_credit_balance	= $accounts_type_credit_balance_amount - $accounts_type_debit_balance_amount;
			}
			else
			{
				$control_group_debit_balance	= 0.00;
				$control_group_credit_balance	= 0.00;
			}
			?>
			<th class="text-right"><?php if ($control_group_debit_balance >0) { echo' '.number_format($control_group_debit_balance, 2 . '').' ';} else { echo'-';} ?></th>
			<th class="text-right"><?php if ($control_group_credit_balance >0) { echo' '.number_format($control_group_credit_balance, 2 . '').' ';} else { echo'-';} ?></th>
			<?php }?>
		</tr>
		<?php $general_ledger =  $this->db->select("distinct(accounts_details_general_ledger) as general_ledger, chart_of_accounts_code, chart_of_accounts_name") 
		->from('accounts_details') 
		->join('chart_of_accounts', 'accounts_details.accounts_details_general_ledger = chart_of_accounts.chart_of_accounts_id', 'LEFT')
		->where('chart_of_accounts.chart_of_accounts_accounts_category', $control_group_row->control_group) 
		->where('accounts_details_voucher_posting_date BETWEEN "'.$posting_from_date.'" and "'.$posting_to_date.'"')
		->group_by('chart_of_accounts.chart_of_accounts_code', 'ASC') 
		->get() 
		->result();
		foreach($general_ledger as $general_ledger_row)
		{?>
		<tr class="">
			<td class="text-center"><?= $general_ledger_row->chart_of_accounts_code;?></td>
			<td class="text-left text-uppercase"><?= $general_ledger_row->chart_of_accounts_name;?></td>
			<?php $general_ledger_amount =  $this->db->select(" SUM(accounts_details_debit) as general_ledger_debit_balance, SUM(accounts_details_credit) as general_ledger_credit_balance") ->from('accounts_details') ->where('accounts_details_voucher_type<>', 3) ->where('accounts_details_general_ledger', $general_ledger_row->general_ledger) ->where('accounts_details_voucher_posting_date BETWEEN "'.$posting_from_date.'" and "'.$posting_to_date.'"')  ->where('accounts_details_status', 1)->order_by('accounts_details_voucher_posting_date', 'ASC') ->get()->result();
			foreach($general_ledger_amount as $general_ledger_amount_row)
			{
			$accounts_type_debit_balance_amount		= $general_ledger_amount_row->general_ledger_debit_balance;
			$accounts_type_credit_balance_amount	= $general_ledger_amount_row->general_ledger_credit_balance;
			
			if ($accounts_type_debit_balance_amount > $accounts_type_credit_balance_amount) 
			{
				$general_ledger_debit_balance	= $accounts_type_debit_balance_amount - $accounts_type_credit_balance_amount;
				$general_ledger_credit_balance	= 0.00;
			}
			else if($accounts_type_debit_balance_amount < $accounts_type_credit_balance_amount) 
			{ 
				$general_ledger_debit_balance	= 0.00;
				$general_ledger_credit_balance	= $accounts_type_credit_balance_amount - $accounts_type_debit_balance_amount;
			}
			else
			{
				$general_ledger_debit_balance	= 0.00;
				$general_ledger_credit_balance	= 0.00;
			}
			?>
			<td class="text-right"><?php if ($general_ledger_debit_balance >0) { echo' '.number_format($general_ledger_debit_balance, 2 . '').' ';} else { echo'-';} ?></td>
			<td class="text-right"><?php if ($general_ledger_credit_balance >0) { echo' '.number_format($general_ledger_credit_balance, 2 . '').' ';} else { echo'-';} ?></td>
			<?php }?>
		</tr>
		
		<?php $subsidiary_ledger =  $this->db->select("distinct(accounts_details_subsidiary_ledger) as subsidiary_ledger, chart_of_accounts_code, chart_of_accounts_name") 
		->from('accounts_details') 
		->join('chart_of_accounts', 'accounts_details.accounts_details_subsidiary_ledger = chart_of_accounts.chart_of_accounts_id', 'LEFT')
		->where('chart_of_accounts.chart_of_accounts_accounts_category', $general_ledger_row->general_ledger)
		->where('accounts_details_voucher_posting_date BETWEEN "'.$posting_from_date.'" and "'.$posting_to_date.'"')
		->group_by('chart_of_accounts.chart_of_accounts_code', 'ASC')
		->get() 
		->result();
		foreach($subsidiary_ledger as $subsidiary_ledger_row)
		{?>
		<tr class="">
			<td class="text-center"><?= $subsidiary_ledger_row->chart_of_accounts_code;?></td>
			<td class="text-left"><?= $subsidiary_ledger_row->chart_of_accounts_name;?></td>
			<?php $subsidiary_ledger_amount =  $this->db->select(" SUM(accounts_details_debit) as subsidiary_ledger_debit_balance, SUM(accounts_details_credit) as subsidiary_ledger_credit_balance") ->from('accounts_details') ->where('accounts_details_voucher_type<>', 3) ->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_row->subsidiary_ledger) ->where('accounts_details_voucher_posting_date BETWEEN "'.$posting_from_date.'" and "'.$posting_to_date.'"') ->where('accounts_details_status', 1) ->order_by('accounts_details_voucher_posting_date', 'ASC') ->get()->result();
			foreach($subsidiary_ledger_amount as $subsidiary_ledger_amount_row)
			{
			$accounts_type_debit_balance_amount		= $subsidiary_ledger_amount_row->subsidiary_ledger_debit_balance;
			$accounts_type_credit_balance_amount	= $subsidiary_ledger_amount_row->subsidiary_ledger_credit_balance;
			
			if ($accounts_type_debit_balance_amount > $accounts_type_credit_balance_amount) 
			{
				$subsidiary_ledger_debit_balance	= $accounts_type_debit_balance_amount - $accounts_type_credit_balance_amount;
				$subsidiary_ledger_credit_balance	= 0.00;
			}
			else if($accounts_type_debit_balance_amount < $accounts_type_credit_balance_amount) 
			{ 
				$subsidiary_ledger_debit_balance	= 0.00;
				$subsidiary_ledger_credit_balance	= $accounts_type_credit_balance_amount - $accounts_type_debit_balance_amount;
			}
			else
			{
				$subsidiary_ledger_debit_balance	= 0.00;
				$subsidiary_ledger_credit_balance	= 0.00;
			}
			?>
			<td class="text-right"><?php if ($subsidiary_ledger_debit_balance >0) { echo' '.number_format($subsidiary_ledger_debit_balance, 2 . '').' ';} else { echo'-';} ?></td>
			<td class="text-right"><?php if ($subsidiary_ledger_credit_balance >0) { echo' '.number_format($subsidiary_ledger_credit_balance, 2 . '').' ';} else { echo'-';} ?></td>
			<?php }?>
		</tr>
		<?php } } } } }?>
		<tr class="text-uppercase">
			<th class="text-center" colspan="2"><?= $this->lang->line('total_amount');?></th>
			<th class="text-right"><?php if ($total_debit_amount >0) { echo' '.number_format($total_debit_amount, 2 . '').' ';} else { echo'-';} ?></th>
			<th class="text-right"><?php if ($total_credit_amount >0) { echo' '.number_format($total_credit_amount, 2 . '').' ';} else { echo'-';} ?></th>
		</tr>
		<?php 
		return $output;
	}
	
	/* ------------------------------------------------------
	Balance Sheet Model
	------------------------------------------------------- */
	function balance_sheet($closing_month)
	{	
		$output = '';
		
		// Current Month Date Calculation ..
		$current_month_start_date = date('2015-01-01');
		$current_month_end_date =  date('Y-m-t', strtotime($closing_month));
		
		// Last Month Date Calculation .		
		$last_month_start_date	= date('2015-01-01');
		$last_month_end_date	= date('Y-m-t', strtotime($closing_month. "last month"));
		
		// Previous Month Date Calculation ..
		$previous_month_start_date	= date('2015-01-01');
		$previous_month_end_date	= date('Y-m-t', strtotime($closing_month. "last month". "last month"));
		
		// Current Year Date Calculation ..
		if (date('m', strtotime($closing_month)) < '07') {
		$current_year_start			= date('Y', strtotime($closing_month. "last year"));
		$current_year_end			= date('y', strtotime($closing_month));
		$current_year_start_date	= date('2015-01-01');
		$current_year_end_date		= date('Y-06-t', strtotime($closing_month));
		} else {
		$current_year_start			= date('Y', strtotime($closing_month));
		$current_year_end			= date('y', strtotime($closing_month. "+1 year"));
		$current_year_start_date	= date('2015-01-01');
		$current_year_end_date		= date('Y-06-t', strtotime($closing_month. "+1 year"));
		} 
		
		// last Year Date Calculation ..
		if (date('m', strtotime($closing_month)) < '07') { 
		$last_year_start		= date('Y', strtotime($closing_month. "last year". "last year"));
		$last_year_end			= date('y', strtotime($closing_month. "last year"));
		$last_year_start_date	= date('2015-01-01');
		$last_year_end_date		= date('Y-06-30', strtotime($closing_month. "last year"));
		} else { 
		$last_year_start		= date('Y', strtotime($closing_month. "last year"));
		$last_year_end			= date('y', strtotime($closing_month));
		$last_year_start_date	= date('2015-01-01');
		$last_year_end_date		= date('Y-06-30', strtotime($closing_month));
		}
		
		// Previous Year Date Calculation ..
		if (date('m', strtotime($closing_month)) < '07') { 
		$previous_year_start		= date('Y', strtotime($closing_month. "last year". "last year". "last year"));
		$previous_year_end			= date('y', strtotime($closing_month. "last year". "last year"));
		$previous_year_start_date	= date('2015-01-01');
		$previous_year_end_date		= date('Y-06-30', strtotime($closing_month. "last year". "last year"));
		} else { 
		$previous_year_start		= date('Y', strtotime($closing_month. "last year". "last year"));
		$previous_year_end			= date('y', strtotime($closing_month. "last year"));
		$previous_year_start_date	= date('2015-01-01');
		$previous_year_end_date		= date('Y-06-30', strtotime($closing_month. "last year"));
		}
		
		// previous previous Year Date Calculation ..
		if (date('m', strtotime($closing_month)) < '07') { 
		$previous_previous_year_start		= date('Y', strtotime($closing_month. "last year". "last year". "last year". "last year"));
		$previous_previous_year_end			= date('y', strtotime($closing_month. "last year". "last year". "last year"));
		$previous_previous_year_start_date	= date('2015-01-01');
		$previous_previous_year_end_date		= date('Y-06-30', strtotime($closing_month. "last year". "last year". "last year"));
		} else { 
		$previous_previous_year_start		= date('Y', strtotime($closing_month. "last year". "last year". "last year"));
		$previous_previous_year_end			= date('y', strtotime($closing_month. "last year". "last year"));
		$previous_previous_year_start_date	= date('2015-01-01');
		$previous_previous_year_end_date		= date('Y-06-30', strtotime($closing_month. "last year". "last year"));
		}?>
		
		<table class="table-hover" width="100%" align="center">
			<thead class="text-uppercase">
				<tr class="table-bordered">  
					<th class="text-center" rowspan="2" width="28%"><?= $this->lang->line('particulars');?></th>
					<th class="text-center" rowspan="2" width="3%"><?= $this->lang->line('notes');?></th>
					<th class="text-center" colspan="6"><?= $this->lang->line('amount');?></th>
				</tr>
				<tr class="table-bordered">  
					<th class="text-center" colspan="2" width="11%">
						<?= date('M-y', strtotime($closing_month));?>
					</th>
					<th class="text-center" colspan="2" width="11%">
						<?= date('M-y', strtotime($closing_month. "last month"));?>
					</th>
					<th class="text-center" colspan="2" width="11%">
						June-<?= $last_year_end;?>
					</th>
					<th class="text-center d-none" colspan="2" width="12%">
						June-<?= $previous_year_end;?>
					</th> 
					<th class="text-center d-none" colspan="2" width="12%">
						June-<?= $previous_previous_year_end;?>
					</th>
				</tr>
			</thead>
			<tbody>
			<?php 
			$serial = 0;
			$serial_note = 0; 
			$serial_assets = $serial; 
			$serial_assets_view = $serial; 
			$accounts_type_assets = $this->db->select("*") ->from('accounts_type') ->where('accounts_type_id', 100000) ->order_by('accounts_type_code', 'ASC') ->get()->result();
			foreach ($accounts_type_assets as $accounts_type_assets_row)
			{?> 
			<tr class="text-uppercase">
				<th class="text-left" colspan="14"><?= $accounts_type_assets_row->accounts_type_name;?> (<?= $accounts_type_assets_row->accounts_type_code;?>)</th>
			</tr>
			<?php
			$total_current_month_assets = 0.00;
			$total_last_month_assets = 0.00;
			$total_previous_month_assets = 0.00;
			$total_current_year_assets = 0.00;
			$total_last_year_assets = 0.00;
			$total_previous_year_assets = 0.00;
			$total_previous_previous_year_assets = 0.00;
			
			$accounts_category_aseets = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_type_assets_row->accounts_type_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
			foreach ($accounts_category_aseets as $accounts_category_aseets_row) {?>
			<tr>
				<th class="text-left" colspan="2"><?= $accounts_category_aseets_row->chart_of_accounts_code;?> - <?= $accounts_category_aseets_row->chart_of_accounts_name;?></th>
				<?php 
				$accounts_category_current_month_assets = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_month_assets_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
				->where('accounts_details_accounts_category', $accounts_category_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($accounts_category_current_month_assets as $accounts_category_current_month_assets_row)
				{
				$accounts_category_current_month_assets_balance = $accounts_category_current_month_assets_row->current_month_assets_balance;
				$total_current_month_assets  += $accounts_category_current_month_assets_balance;
				?>			
				<th class="text-center" width="1%"></th>
				<th class="text-right bd-all"><?php if ($accounts_category_current_month_assets_balance >0) { echo' '.number_format($accounts_category_current_month_assets_balance, 2 . '').' ';} else if($accounts_category_current_month_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($accounts_category_current_month_assets_balance), 2 . '').') ';} ?></th>
				<?php }?>
				
				<?php 
				$accounts_category_last_month_assets = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS last_month_assets_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$last_month_start_date.'" and "'.$last_month_end_date.'"')
				->where('accounts_details_accounts_category', $accounts_category_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($accounts_category_last_month_assets as $accounts_category_last_month_assets_row)
				{
				$accounts_category_last_month_assets_balance = $accounts_category_last_month_assets_row->last_month_assets_balance;
				$total_last_month_assets  += $accounts_category_last_month_assets_balance;
				?>			
				<th class="text-center" width="1%"></th>
				<th class="text-right bd-all"><?php if ($accounts_category_last_month_assets_balance >0) { echo' '.number_format($accounts_category_last_month_assets_balance, 2 . '').' ';} else if($accounts_category_last_month_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($accounts_category_last_month_assets_balance), 2 . '').') ';} ?></th>
				<?php }?>
				 
				<?php 
				$accounts_category_last_year_assets = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS last_year_assets_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
				->where('accounts_details_accounts_category', $accounts_category_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($accounts_category_last_year_assets as $accounts_category_last_year_assets_row)
				{
				$accounts_category_last_year_assets_balance = $accounts_category_last_year_assets_row->last_year_assets_balance;
				$total_last_year_assets  += $accounts_category_last_year_assets_balance;
				?>			
				<th class="text-center" width="1%"></th>
				<th class="text-right bd-all"><?php if ($accounts_category_last_year_assets_balance >0) { echo' '.number_format($accounts_category_last_year_assets_balance, 2 . '').' ';} else if($accounts_category_last_year_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($accounts_category_last_year_assets_balance), 2 . '').') ';} ?></th>
				<?php }?>
				<?php 
				$accounts_category_previous_year_assets = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS previous_year_assets_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_year_start_date.'" and "'.$previous_year_end_date.'"')
				->where('accounts_details_accounts_category', $accounts_category_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($accounts_category_previous_year_assets as $accounts_category_previous_year_assets_row)
				{
				$accounts_category_previous_year_assets_balance = $accounts_category_previous_year_assets_row->previous_year_assets_balance;
				$total_previous_year_assets  += $accounts_category_previous_year_assets_balance;
				?>			
				<th class="text-center  d-none" width="1%"></th>
				<th class="text-right bd-all  d-none"><?php if ($accounts_category_previous_year_assets_balance >0) { echo' '.number_format($accounts_category_previous_year_assets_balance, 2 . '').' ';} else if($accounts_category_previous_year_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($accounts_category_previous_year_assets_balance), 2 . '').') ';} ?></th>
				<?php }?>
				
				<?php 
				$accounts_category_previous_previous_year_assets = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS previous_previous_year_assets_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_previous_year_start_date.'" and "'.$previous_previous_year_end_date.'"')
				->where('accounts_details_accounts_category', $accounts_category_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($accounts_category_previous_previous_year_assets as $accounts_category_previous_previous_year_assets_row)
				{
				$accounts_category_previous_previous_year_assets_balance = $accounts_category_previous_previous_year_assets_row->previous_previous_year_assets_balance;
				$total_previous_previous_year_assets  += $accounts_category_previous_previous_year_assets_balance;
				?>			
				<th class="text-center  d-none" width="1%"></th>
				<th class="text-right bd-all  d-none"><?php if ($accounts_category_previous_previous_year_assets_balance >0) { echo' '.number_format($accounts_category_previous_previous_year_assets_balance, 2 . '').' ';} else if($accounts_category_previous_previous_year_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($accounts_category_previous_previous_year_assets_balance), 2 . '').') ';} ?></th>
				<?php }?>
			</tr>
			<?php 
			$control_group_aseets = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_category_aseets_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
			foreach ($control_group_aseets as $control_group_aseets_row) {
			$s_note = ++$serial_note;?>
			<tr>
				<td class="text-left">&nbsp; <?= $control_group_aseets_row->chart_of_accounts_code;?> - <?= $control_group_aseets_row->chart_of_accounts_name;?></td>
				<td class="text-center">
					<a class="btn-outline-danger  rounded-pill" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="action_view_model('<?= base_url("accounts/balance_sheet_notes_view/?type=assets&note=$s_note&coa=$control_group_aseets_row->chart_of_accounts_id&closing_month=$closing_month");?>')"><?= str_pad(++$serial, 2, '0', STR_PAD_LEFT);?></a>
				</td>
				<?php 
				$control_group_current_month_assets = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS control_group_current_month_assets_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
				->where('accounts_details_control_group', $control_group_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($control_group_current_month_assets as $control_group_current_month_assets_row)
				{
				$control_group_current_month_assets_balance = $control_group_current_month_assets_row->control_group_current_month_assets_balance;
				?>			
				<td class="text-center" width="1%"></td>
				<td class="text-right"><?php if ($control_group_current_month_assets_balance >0) { echo' '.number_format($control_group_current_month_assets_balance, 2 . '').' ';} else if($control_group_current_month_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($control_group_current_month_assets_balance), 2 . '').') ';} ?></td>
				<?php }?>
				<?php 
				$control_group_last_month_assets = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS control_group_last_month_assets_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$last_month_start_date.'" and "'.$last_month_end_date.'"')
				->where('accounts_details_control_group', $control_group_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($control_group_last_month_assets as $control_group_last_month_assets_row)
				{
				$control_group_last_month_assets_balance = $control_group_last_month_assets_row->control_group_last_month_assets_balance;
				?>			
				<td class="text-center" width="1%"></td>
				<td class="text-right"><?php if ($control_group_last_month_assets_balance >0) { echo' '.number_format($control_group_last_month_assets_balance, 2 . '').' ';} else if($control_group_last_month_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($control_group_last_month_assets_balance), 2 . '').') ';} ?></td>
				<?php }?>
				
				<?php 
				$control_group_last_year_assets = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS control_group_last_year_assets_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
				->where('accounts_details_control_group', $control_group_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($control_group_last_year_assets as $control_group_last_year_assets_row)
				{
				$control_group_last_year_assets_balance = $control_group_last_year_assets_row->control_group_last_year_assets_balance;
				?>			
				<td class="text-center" width="1%"></td>
				<td class="text-right"><?php if ($control_group_last_year_assets_balance >0) { echo' '.number_format($control_group_last_year_assets_balance, 2 . '').' ';} else if($control_group_last_year_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($control_group_last_year_assets_balance), 2 . '').') ';} ?></td>
				<?php }?>
				<?php 
				$control_group_previous_year_assets = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS control_group_previous_year_assets_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_year_start_date.'" and "'.$previous_year_end_date.'"')
				->where('accounts_details_control_group', $control_group_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($control_group_previous_year_assets as $control_group_previous_year_assets_row)
				{
				$control_group_previous_year_assets_balance = $control_group_previous_year_assets_row->control_group_previous_year_assets_balance;
				?>			
				<td class="text-center d-none" width="1%"></td>
				<td class="text-right d-none"><?php if ($control_group_previous_year_assets_balance >0) { echo' '.number_format($control_group_previous_year_assets_balance, 2 . '').' ';} else if($control_group_previous_year_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($control_group_previous_year_assets_balance), 2 . '').') ';} ?></td>
				<?php }?>
				
				<?php 
				$control_group_previous_previous_year_assets = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS control_group_previous_previous_year_assets_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_previous_year_start_date.'" and "'.$previous_previous_year_end_date.'"')
				->where('accounts_details_control_group', $control_group_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($control_group_previous_previous_year_assets as $control_group_previous_previous_year_assets_row)
				{
				$control_group_previous_previous_year_assets_balance = $control_group_previous_previous_year_assets_row->control_group_previous_previous_year_assets_balance;
				?>			
				<td class="text-center d-none" width="1%"></td>
				<td class="text-right d-none"><?php if ($control_group_previous_previous_year_assets_balance >0) { echo' '.number_format($control_group_previous_previous_year_assets_balance, 2 . '').' ';} else if($control_group_previous_previous_year_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($control_group_previous_previous_year_assets_balance), 2 . '').') ';} ?></td>
				<?php }?>
			</tr>
			<?php } }?>
			<tr class="text-uppercase">
				<th class="text-center" colspan="2"><?= $this->lang->line('total');?> <?= $accounts_type_assets_row->accounts_type_name;?></th>
				<th class="text-center" width="1%"></th>
				<th class="text-right bd-bottom-double"><?php if ($total_current_month_assets >0) { echo' '.number_format($total_current_month_assets, 2 . '').' ';} else if($total_current_month_assets ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_month_assets), 2 . '').') ';} ?></th>
				<th class="text-center" width="1%"></th>
				<th class="text-right bd-bottom-double"><?php if ($total_last_month_assets >0) { echo' '.number_format($total_last_month_assets, 2 . '').' ';} else if($total_last_month_assets ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_month_assets), 2 . '').') ';} ?></th>
				<th class="text-center" width="1%"></th>
				<th class="text-right bd-bottom-double"><?php if ($total_last_year_assets >0) { echo' '.number_format($total_last_year_assets, 2 . '').' ';} else if($total_last_year_assets ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_year_assets), 2 . '').') ';} ?></th>
				<th class="text-center d-none" width="1%"></th>
				<th class="text-right d-none bd-bottom-double"><?php if ($total_previous_year_assets >0) { echo' '.number_format($total_previous_year_assets, 2 . '').' ';} else if($total_previous_year_assets ==0) {echo '-';} else { echo' ('.number_format(abs($total_previous_year_assets), 2 . '').') ';} ?></th>
				<th class="text-center d-none" width="1%"></th>
				<th class="text-right d-none bd-bottom-double"><?php if ($total_previous_previous_year_assets >0) { echo' '.number_format($total_previous_previous_year_assets, 2 . '').' ';} else if($total_previous_previous_year_assets ==0) {echo '-';} else { echo' ('.number_format(abs($total_previous_previous_year_assets), 2 . '').') ';} ?></th>
			</tr>
			<?php }?>
			
			<?php 
			// Income ....
			$serial = $serial;
			$serial_income = $serial; 
			$serial_income_view = $serial; 
			$accounts_type_income = $this->db->select("*") ->from('accounts_type') ->where('accounts_type_id', 300000) ->order_by('accounts_type_code', 'ASC') ->get()->result();
			foreach ($accounts_type_income as $accounts_type_income_row)
			{
				$total_current_month_income = 0.00;
				$total_last_month_income = 0.00;
				$total_previous_month_income = 0.00;
				$total_current_year_income = 0.00;
				$total_last_year_income = 0.00;
				$total_previous_year_income = 0.00;
				$total_previous_previous_year_income = 0.00;
				
				$accounts_category_income = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_type_income_row->accounts_type_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
				foreach ($accounts_category_income as $accounts_category_income_row) 
				{
					$current_month_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_month_income_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_income_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($current_month_income as $current_month_income_row)
					{
					$current_month_income_balance = $current_month_income_row->current_month_income_balance;
					$total_current_month_income  += $current_month_income_balance;
					}
					
					$last_month_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS last_month_income_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$last_month_start_date.'" and "'.$last_month_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_income_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($last_month_income as $last_month_income_row)
					{
					$last_month_income_balance = $last_month_income_row->last_month_income_balance;
					$total_last_month_income  += $last_month_income_balance;
					}
					
					$last_year_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS last_year_income_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_income_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($last_year_income as $last_year_income_row)
					{
					$last_year_income_balance = $last_year_income_row->last_year_income_balance;
					$total_last_year_income  += $last_year_income_balance;
					}
					
					$previous_year_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS previous_year_income_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_year_start_date.'" and "'.$previous_year_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_income_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($previous_year_income as $previous_year_income_row)
					{
					$previous_year_income_balance = $previous_year_income_row->previous_year_income_balance;
					$total_previous_year_income  += $previous_year_income_balance;
					}
					
					$previous_previous_year_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS previous_previous_year_income_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_previous_year_start_date.'" and "'.$previous_previous_year_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_income_row->chart_of_accounts_id)
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($previous_previous_year_income as $previous_previous_year_income_row)
					{
					$previous_previous_year_income_balance = $previous_previous_year_income_row->previous_previous_year_income_balance;
					$total_previous_previous_year_income  += $previous_previous_year_income_balance;
					}
				} 
			}
			
			// expenditure ..
			$serial = $serial;
			$serial_expenditure = $serial; 
			$serial_expenditure_view = $serial; 
			$accounts_type_expenditure = $this->db->select("*") ->from('accounts_type') ->where('accounts_type_id', 400000) ->order_by('accounts_type_code', 'ASC') ->get()->result();
			foreach ($accounts_type_expenditure as $accounts_type_expenditure_row)
			{
				$total_current_month_expenditure = 0.00;
				$total_last_month_expenditure = 0.00;
				$total_previous_month_expenditure = 0.00;
				$total_current_year_expenditure = 0.00;
				$total_last_year_expenditure = 0.00;
				$total_previous_year_expenditure = 0.00;
				$total_previous_previous_year_expenditure = 0.00;
				
				$accounts_category_expenditure = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_type_expenditure_row->accounts_type_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
				foreach ($accounts_category_expenditure as $accounts_category_expenditure_row)
				{
					$current_month_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_month_expenditure_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($current_month_expenditure as $current_month_expenditure_row)
					{
					$current_month_expenditure_balance = $current_month_expenditure_row->current_month_expenditure_balance;
					$total_current_month_expenditure  += $current_month_expenditure_balance;
					}
					
					$last_month_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS last_month_expenditure_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$last_month_start_date.'" and "'.$last_month_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($last_month_expenditure as $last_month_expenditure_row)
					{
					$last_month_expenditure_balance = $last_month_expenditure_row->last_month_expenditure_balance;
					$total_last_month_expenditure  += $last_month_expenditure_balance;
					}
					
					$last_year_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS last_year_expenditure_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($last_year_expenditure as $last_year_expenditure_row)
					{
					$last_year_expenditure_balance = $last_year_expenditure_row->last_year_expenditure_balance;
					$total_last_year_expenditure  += $last_year_expenditure_balance;
					}
					
					$previous_year_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS previous_year_expenditure_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_year_start_date.'" and "'.$previous_year_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($previous_year_expenditure as $previous_year_expenditure_row)
					{
					$previous_year_expenditure_balance = $previous_year_expenditure_row->previous_year_expenditure_balance;
					$total_previous_year_expenditure  += $previous_year_expenditure_balance;
					}  
					
					$previous_previous_year_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS previous_previous_year_expenditure_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_previous_year_start_date.'" and "'.$previous_previous_year_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($previous_previous_year_expenditure as $previous_previous_year_expenditure_row)
					{
					$previous_previous_year_expenditure_balance = $previous_previous_year_expenditure_row->previous_previous_year_expenditure_balance;
					$total_previous_previous_year_expenditure  += $previous_previous_year_expenditure_balance;
					}  
				} 
			} 
			$total_current_month_surplus_deficit	= $total_current_month_income - $total_current_month_expenditure;
			$total_last_month_surplus_deficit		= $total_last_month_income - $total_last_month_expenditure;
			$total_last_year_surplus_deficit		= $total_last_year_income - $total_last_year_expenditure;
			$total_previous_year_surplus_deficit	= $total_previous_year_income - $total_previous_year_expenditure;
			$total_previous_previous_year_surplus_deficit	= $total_previous_previous_year_income - $total_previous_previous_year_expenditure;
			?>
			
			
			<?php 
			// fund_liabilities ... 
			$serial_funds = $serial;
			$serial = $serial;
			
			$serial_fund_liabilities = $serial; 
			$serial_fund_liabilities_view = $serial; 
			$accounts_type_fund_liabilities = $this->db->select("*") ->from('accounts_type') ->where('accounts_type_id', 200000) ->order_by('accounts_type_code', 'ASC') ->get()->result();
			foreach ($accounts_type_fund_liabilities as $accounts_type_fund_liabilities_row)
			{?> 
			<tr class="text-uppercase">
				<th class="text-left" colspan="14"><?= $accounts_type_fund_liabilities_row->accounts_type_name;?> (<?= $accounts_type_fund_liabilities_row->accounts_type_code;?>)</th>
			</tr>
			<?php
			$total_current_month_fund_liabilities = 0.00;
			$total_last_month_fund_liabilities = 0.00;
			$total_previous_month_fund_liabilities = 0.00;
			$total_current_year_fund_liabilities = 0.00;
			$total_last_year_fund_liabilities = 0.00;
			$total_previous_year_fund_liabilities = 0.00;
			$total_previous_previous_year_fund_liabilities = 0.00;
			
			$accounts_category_fund_liabilities = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_type_fund_liabilities_row->accounts_type_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
			foreach ($accounts_category_fund_liabilities as $accounts_category_fund_liabilities_row) {?>
			<tr>
				<th class="text-left" colspan="2"><?= $accounts_category_fund_liabilities_row->chart_of_accounts_code;?> - <?= $accounts_category_fund_liabilities_row->chart_of_accounts_name;?></th>
				<?php 
				$accounts_category_current_month_fund_liabilities = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_month_fund_liabilities_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
				->where('accounts_details_accounts_category', $accounts_category_fund_liabilities_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($accounts_category_current_month_fund_liabilities as $accounts_category_current_month_fund_liabilities_row)
				{
				if ( $accounts_category_fund_liabilities_row->chart_of_accounts_accounts_category_balance_sheet_show == 1) {	
				$accounts_category_current_month_fund_liabilities_balance = $accounts_category_current_month_fund_liabilities_row->current_month_fund_liabilities_balance + $total_current_month_surplus_deficit;	
				} else if ( $accounts_category_fund_liabilities_row->chart_of_accounts_accounts_category_balance_sheet_show == 0) {	
				$accounts_category_current_month_fund_liabilities_balance =$accounts_category_current_month_fund_liabilities_row->current_month_fund_liabilities_balance;	
				} else { 
				$accounts_category_current_month_fund_liabilities_balance = 0.00;
				}
				
				$total_current_month_fund_liabilities  += $accounts_category_current_month_fund_liabilities_balance;
				?>			
				<th class="text-center" width="1%"></th>
				<th class="text-right bd-all"><?php if ($accounts_category_current_month_fund_liabilities_balance >0) { echo' '.number_format($accounts_category_current_month_fund_liabilities_balance, 2 . '').' ';} else if($accounts_category_current_month_fund_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($accounts_category_current_month_fund_liabilities_balance), 2 . '').') ';} ?></th>
				<?php }?>
				
				<?php 
				$accounts_category_last_month_fund_liabilities = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS last_month_fund_liabilities_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$last_month_start_date.'" and "'.$last_month_end_date.'"')
				->where('accounts_details_accounts_category', $accounts_category_fund_liabilities_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($accounts_category_last_month_fund_liabilities as $accounts_category_last_month_fund_liabilities_row)
				{
				if ( $accounts_category_fund_liabilities_row->chart_of_accounts_accounts_category_balance_sheet_show == 1) {	
				$accounts_category_last_month_fund_liabilities_balance = $accounts_category_last_month_fund_liabilities_row->last_month_fund_liabilities_balance + $total_last_month_surplus_deficit;	
				} else if ( $accounts_category_fund_liabilities_row->chart_of_accounts_accounts_category_balance_sheet_show == 0) {	
				$accounts_category_last_month_fund_liabilities_balance =$accounts_category_last_month_fund_liabilities_row->last_month_fund_liabilities_balance;	
				} else { 
				$accounts_category_last_month_fund_liabilities_balance = 0.00;
				}
				
				$total_last_month_fund_liabilities  += $accounts_category_last_month_fund_liabilities_balance;
				?>			
				<th class="text-center" width="1%"></th>
				<th class="text-right bd-all"><?php if ($accounts_category_last_month_fund_liabilities_balance >0) { echo' '.number_format($accounts_category_last_month_fund_liabilities_balance, 2 . '').' ';} else if($accounts_category_last_month_fund_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($accounts_category_last_month_fund_liabilities_balance), 2 . '').') ';} ?></th>
				<?php }?>
				
				<?php 
				$accounts_category_last_year_fund_liabilities = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS last_year_fund_liabilities_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
				->where('accounts_details_accounts_category', $accounts_category_fund_liabilities_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($accounts_category_last_year_fund_liabilities as $accounts_category_last_year_fund_liabilities_row)
				{
				if ( $accounts_category_fund_liabilities_row->chart_of_accounts_accounts_category_balance_sheet_show == 1) {	
				$accounts_category_last_year_fund_liabilities_balance = $accounts_category_last_year_fund_liabilities_row->last_year_fund_liabilities_balance + $total_last_year_surplus_deficit;	
				} else if ( $accounts_category_fund_liabilities_row->chart_of_accounts_accounts_category_balance_sheet_show == 0) {	
				$accounts_category_last_year_fund_liabilities_balance =$accounts_category_last_year_fund_liabilities_row->last_year_fund_liabilities_balance;	
				} else { 
				$accounts_category_last_year_fund_liabilities_balance = 0.00;
				}
				
				$total_last_year_fund_liabilities  += $accounts_category_last_year_fund_liabilities_balance;
				?>			
				<th class="text-center" width="1%"></th>
				<th class="text-right bd-all"><?php if ($accounts_category_last_year_fund_liabilities_balance >0) { echo' '.number_format($accounts_category_last_year_fund_liabilities_balance, 2 . '').' ';} else if($accounts_category_last_year_fund_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($accounts_category_last_year_fund_liabilities_balance), 2 . '').') ';} ?></th>
				<?php }?>
				<?php 
				$accounts_category_previous_year_fund_liabilities = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS previous_year_fund_liabilities_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_year_start_date.'" and "'.$previous_year_end_date.'"')
				->where('accounts_details_accounts_category', $accounts_category_fund_liabilities_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($accounts_category_previous_year_fund_liabilities as $accounts_category_previous_year_fund_liabilities_row)
				{
				if ( $accounts_category_fund_liabilities_row->chart_of_accounts_accounts_category_balance_sheet_show == 1) {	
				$accounts_category_previous_year_fund_liabilities_balance = $accounts_category_previous_year_fund_liabilities_row->previous_year_fund_liabilities_balance + $total_previous_year_surplus_deficit;	
				} else if ( $accounts_category_fund_liabilities_row->chart_of_accounts_accounts_category_balance_sheet_show == 0) {	
				$accounts_category_previous_year_fund_liabilities_balance =$accounts_category_previous_year_fund_liabilities_row->previous_year_fund_liabilities_balance;	
				} else { 
				$accounts_category_previous_year_fund_liabilities_balance = 0.00;
				}
				
				$total_previous_year_fund_liabilities  += $accounts_category_previous_year_fund_liabilities_balance;
				?>			
				<th class="text-center d-none" width="1%"></th>
				<th class="text-right d-none bd-all"><?php if ($accounts_category_previous_year_fund_liabilities_balance >0) { echo' '.number_format($accounts_category_previous_year_fund_liabilities_balance, 2 . '').' ';} else if($accounts_category_previous_year_fund_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($accounts_category_previous_year_fund_liabilities_balance), 2 . '').') ';} ?></th>
				<?php }?>
				
				
				<?php 
				$accounts_category_previous_previous_year_fund_liabilities = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS previous_previous_year_fund_liabilities_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_previous_year_start_date.'" and "'.$previous_previous_year_end_date.'"')
				->where('accounts_details_accounts_category', $accounts_category_fund_liabilities_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($accounts_category_previous_previous_year_fund_liabilities as $accounts_category_previous_previous_year_fund_liabilities_row)
				{
				if ( $accounts_category_fund_liabilities_row->chart_of_accounts_accounts_category_balance_sheet_show == 1) {	
				$accounts_category_previous_previous_year_fund_liabilities_balance = $accounts_category_previous_previous_year_fund_liabilities_row->previous_previous_year_fund_liabilities_balance + $total_previous_previous_year_surplus_deficit;	
				} else if ( $accounts_category_fund_liabilities_row->chart_of_accounts_accounts_category_balance_sheet_show == 0) {	
				$accounts_category_previous_previous_year_fund_liabilities_balance =$accounts_category_previous_previous_year_fund_liabilities_row->previous_previous_year_fund_liabilities_balance;	
				} else { 
				$accounts_category_previous_previous_year_fund_liabilities_balance = 0.00;
				}
				$total_previous_previous_year_fund_liabilities  += $accounts_category_previous_previous_year_fund_liabilities_balance;
				?>			
				<th class="text-center d-none" width="1%"></th>
				<th class="text-right d-none bd-all"><?php if ($accounts_category_previous_previous_year_fund_liabilities_balance >0) { echo' '.number_format($accounts_category_previous_previous_year_fund_liabilities_balance, 2 . '').' ';} else if($accounts_category_previous_previous_year_fund_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($accounts_category_previous_previous_year_fund_liabilities_balance), 2 . '').') ';} ?></th>
				<?php }?>
			</tr>
			<?php 
			$control_group_fund_liabilities = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_category_fund_liabilities_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
			foreach ($control_group_fund_liabilities as $control_group_fund_liabilities_row) {
			$f_note = ++$serial_funds;?>
			<tr>
				<td class="text-left">&nbsp; <?= $control_group_fund_liabilities_row->chart_of_accounts_code;?> - <?= $control_group_fund_liabilities_row->chart_of_accounts_name;?></td>
				<td class="text-center">
					<a class="btn-outline-danger  rounded-pill" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="action_view_model('<?= base_url("accounts/balance_sheet_notes_view/?type=funds&note=$f_note&coa=$control_group_fund_liabilities_row->chart_of_accounts_id&closing_month=$closing_month");?>')"><?= str_pad(++$serial, 2, '0', STR_PAD_LEFT);?></a>
				</td>
				<?php 
				$control_group_current_month_fund_liabilities = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS control_group_current_month_fund_liabilities_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
				->where('accounts_details_control_group', $control_group_fund_liabilities_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($control_group_current_month_fund_liabilities as $control_group_current_month_fund_liabilities_row)
				{
				if ( $control_group_fund_liabilities_row->chart_of_accounts_control_group_balance_sheet_show == 1) {	
				$control_group_current_month_fund_liabilities_balance = $control_group_current_month_fund_liabilities_row->control_group_current_month_fund_liabilities_balance + $total_current_month_surplus_deficit;	
				} else if ( $control_group_fund_liabilities_row->chart_of_accounts_control_group_balance_sheet_show == 0) {	
				$control_group_current_month_fund_liabilities_balance = $control_group_current_month_fund_liabilities_row->control_group_current_month_fund_liabilities_balance;	
				} else { 
				$control_group_current_month_fund_liabilities_balance = 0.00;
				}
				?>			
				<td class="text-center" width="1%"></td>
				<td class="text-right"><?php if ($control_group_current_month_fund_liabilities_balance >0) { echo' '.number_format($control_group_current_month_fund_liabilities_balance, 2 . '').' ';} else if($control_group_current_month_fund_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($control_group_current_month_fund_liabilities_balance), 2 . '').') ';} ?></td>
				<?php }?>
				<?php 
				$control_group_last_month_fund_liabilities = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS control_group_last_month_fund_liabilities_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$last_month_start_date.'" and "'.$last_month_end_date.'"')
				->where('accounts_details_control_group', $control_group_fund_liabilities_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($control_group_last_month_fund_liabilities as $control_group_last_month_fund_liabilities_row)
				{
				if ( $control_group_fund_liabilities_row->chart_of_accounts_control_group_balance_sheet_show == 1) {	
				$control_group_last_month_fund_liabilities_balance = $control_group_last_month_fund_liabilities_row->control_group_last_month_fund_liabilities_balance + $total_last_month_surplus_deficit;	
				} else if ( $control_group_fund_liabilities_row->chart_of_accounts_control_group_balance_sheet_show == 0) {	
				$control_group_last_month_fund_liabilities_balance = $control_group_last_month_fund_liabilities_row->control_group_last_month_fund_liabilities_balance;	
				} else { 
				$control_group_last_month_fund_liabilities_balance = 0.00;
				}
				?>			
				<td class="text-center" width="1%"></td>
				<td class="text-right"><?php if ($control_group_last_month_fund_liabilities_balance >0) { echo' '.number_format($control_group_last_month_fund_liabilities_balance, 2 . '').' ';} else if($control_group_last_month_fund_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($control_group_last_month_fund_liabilities_balance), 2 . '').') ';} ?></td>
				<?php }?>
				
				<?php 
				$control_group_last_year_fund_liabilities = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS control_group_last_year_fund_liabilities_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
				->where('accounts_details_control_group', $control_group_fund_liabilities_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($control_group_last_year_fund_liabilities as $control_group_last_year_fund_liabilities_row)
				{
				if ( $control_group_fund_liabilities_row->chart_of_accounts_control_group_balance_sheet_show == 1) {	
				$control_group_last_year_fund_liabilities_balance = $control_group_last_year_fund_liabilities_row->control_group_last_year_fund_liabilities_balance + $total_last_year_surplus_deficit;	
				} else if ( $control_group_fund_liabilities_row->chart_of_accounts_control_group_balance_sheet_show == 0) {	
				$control_group_last_year_fund_liabilities_balance = $control_group_last_year_fund_liabilities_row->control_group_last_year_fund_liabilities_balance;	
				} else { 
				$control_group_last_year_fund_liabilities_balance = 0.00;
				}
				?>			
				<td class="text-center" width="1%"></td>
				<td class="text-right"><?php if ($control_group_last_year_fund_liabilities_balance >0) { echo' '.number_format($control_group_last_year_fund_liabilities_balance, 2 . '').' ';} else if($control_group_last_year_fund_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($control_group_last_year_fund_liabilities_balance), 2 . '').') ';} ?></td>
				<?php }?>
				<?php 
				$control_group_previous_year_fund_liabilities = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS control_group_previous_year_fund_liabilities_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_year_start_date.'" and "'.$previous_year_end_date.'"')
				->where('accounts_details_control_group', $control_group_fund_liabilities_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($control_group_previous_year_fund_liabilities as $control_group_previous_year_fund_liabilities_row)
				{
				if ( $control_group_fund_liabilities_row->chart_of_accounts_control_group_balance_sheet_show == 1) {	
				$control_group_previous_year_fund_liabilities_balance = $control_group_previous_year_fund_liabilities_row->control_group_previous_year_fund_liabilities_balance + $total_previous_year_surplus_deficit;	
				} else if ( $control_group_fund_liabilities_row->chart_of_accounts_control_group_balance_sheet_show == 0) {	
				$control_group_previous_year_fund_liabilities_balance = $control_group_previous_year_fund_liabilities_row->control_group_previous_year_fund_liabilities_balance;	
				} else { 
				$control_group_previous_year_fund_liabilities_balance = 0.00;
				}
				?>			
				<td class="text-center d-none" width="1%"></td>
				<td class="text-right d-none"><?php if ($control_group_previous_year_fund_liabilities_balance >0) { echo' '.number_format($control_group_previous_year_fund_liabilities_balance, 2 . '').' ';} else if($control_group_previous_year_fund_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($control_group_previous_year_fund_liabilities_balance), 2 . '').') ';} ?></td>
				<?php }?>
				
				
				<?php 
				$control_group_previous_previous_year_fund_liabilities = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS control_group_previous_previous_year_fund_liabilities_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_previous_year_start_date.'" and "'.$previous_previous_year_end_date.'"')
				->where('accounts_details_control_group', $control_group_fund_liabilities_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($control_group_previous_previous_year_fund_liabilities as $control_group_previous_previous_year_fund_liabilities_row)
				{
				if ( $control_group_fund_liabilities_row->chart_of_accounts_control_group_balance_sheet_show == 1) {	
				$control_group_previous_previous_year_fund_liabilities_balance = $control_group_previous_previous_year_fund_liabilities_row->control_group_previous_previous_year_fund_liabilities_balance + $total_previous_previous_year_surplus_deficit;	
				} else if ( $control_group_fund_liabilities_row->chart_of_accounts_control_group_balance_sheet_show == 0) {	
				$control_group_previous_previous_year_fund_liabilities_balance = $control_group_previous_previous_year_fund_liabilities_row->control_group_previous_previous_year_fund_liabilities_balance;	
				} else { 
				$control_group_previous_previous_year_fund_liabilities_balance = 0.00;
				}
				?>			
				<td class="text-center d-none" width="1%"></td>
				<td class="text-right d-none"><?php if ($control_group_previous_previous_year_fund_liabilities_balance >0) { echo' '.number_format($control_group_previous_previous_year_fund_liabilities_balance, 2 . '').' ';} else if($control_group_previous_previous_year_fund_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($control_group_previous_previous_year_fund_liabilities_balance), 2 . '').') ';} ?></td>
				<?php }?>
			</tr>
			<?php } }?>
			<tr class="text-uppercase">
				<th class="text-center" colspan="2"><?= $this->lang->line('total');?> <?= $accounts_type_fund_liabilities_row->accounts_type_name;?></th>
				<th class="text-center" width="1%"></th>
				<th class="text-right bd-bottom-double"><?php if ($total_current_month_fund_liabilities >0) { echo' '.number_format($total_current_month_fund_liabilities, 2 . '').' ';} else if($total_current_month_fund_liabilities ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_month_fund_liabilities), 2 . '').') ';} ?></th>
				<th class="text-center" width="1%"></th>
				<th class="text-right bd-bottom-double"><?php if ($total_last_month_fund_liabilities >0) { echo' '.number_format($total_last_month_fund_liabilities, 2 . '').' ';} else if($total_last_month_fund_liabilities ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_month_fund_liabilities), 2 . '').') ';} ?></th>
				<th class="text-center" width="1%"></th>
				<th class="text-right bd-bottom-double"><?php if ($total_last_year_fund_liabilities >0) { echo' '.number_format($total_last_year_fund_liabilities, 2 . '').' ';} else if($total_last_year_fund_liabilities ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_year_fund_liabilities), 2 . '').') ';} ?></th>
				<th class="text-center d-none" width="1%"></th>
				<th class="text-right d-none bd-bottom-double"><?php if ($total_previous_year_fund_liabilities >0) { echo' '.number_format($total_previous_year_fund_liabilities, 2 . '').' ';} else if($total_previous_year_fund_liabilities ==0) {echo '-';} else { echo' ('.number_format(abs($total_previous_year_fund_liabilities), 2 . '').') ';} ?></th>
				<th class="text-center d-none" width="1%"></th>
				<th class="text-right d-none bd-bottom-double"><?php if ($total_previous_previous_year_fund_liabilities >0) { echo' '.number_format($total_previous_previous_year_fund_liabilities, 2 . '').' ';} else if($total_previous_previous_year_fund_liabilities ==0) {echo '-';} else { echo' ('.number_format(abs($total_previous_previous_year_fund_liabilities), 2 . '').') ';} ?></th>
			</tr>
			<?php }?>
			</tbody>
		</table>
		
		<br/><br/><br/><br/><br/>
		
		<table class="" width="100%" align="center">  
			<tr class="text-uppercase">
				<th width="30%" class="text-center bd-top"><?= $this->lang->line('prepared_by');?>/Accountant</th>
				<th width="5%"></th>
				<th width="30%" class="text-center bd-top"><?= $this->lang->line('checked_by');?></th>
				<th width="5%"></th>
				<th width="30%" class="text-center bd-top"><?= $this->lang->line('authorised');?></th>
			</tr>
		</table>
		<?php 
		return $output;
	}
	
	/* ------------------------------------------------------
	Income & Expenditure Statement Model
	------------------------------------------------------- */
	function income_expenditure_statement($closing_month)
	{	
		$output = '';
		$starting_date = date('2015-07-01');
		
		// Current Month Date Calculation ..
		$current_month_start_date = date('Y-m-01', strtotime($closing_month));
		$current_month_end_date =  date('Y-m-t', strtotime($closing_month)); 
		
		$current_last_month_start_date = date('Y-m-01', strtotime($closing_month. "last month"));
		$current_last_month_end_date =  date('Y-m-t', strtotime($closing_month. "last month")); 
		
		$current_previous_month_start_date = date('Y-m-01', strtotime($closing_month. "last month". "last month"));
		$current_previous_month_end_date =  date('Y-m-t', strtotime($closing_month. "last month". "last month"));
		
		//$quarterly_start_date = date('Y-m-01', strtotime($closing_month. "last month". "last month"));
		//$quarterly_end_date =  date('Y-m-t', strtotime($closing_month)); 
		
		if(date('m-y', strtotime($closing_month)) <= 3) {
			$quarterly_start_date = date('Y-10-01', strtotime($closing_month. "last year"));
			$quarterly_end_date =  date('Y-12-31', strtotime($closing_month. "last year"));
		} else if(date('m-y', strtotime($closing_month)) <= 6) {
			$quarterly_start_date = date('Y-01-01', strtotime($closing_month));
			$quarterly_end_date =  date('Y-03-31', strtotime($closing_month));
		} else  if(date('m-y', strtotime($closing_month)) <= 9) {
			$quarterly_start_date = date('Y-04-01', strtotime($closing_month));
			$quarterly_end_date =  date('Y-06-30', strtotime($closing_month));
		} else  if(date('m-y', strtotime($closing_month)) <= 12) {
			$quarterly_start_date = date('Y-07-01', strtotime($closing_month));
			$quarterly_end_date =  date('Y-09-30', strtotime($closing_month));
		}
		
		// last Month Date Calculation ..
		if (date('m', strtotime($closing_month)) < '07') {
		$last_month_start_date	= date('Y-07-01', strtotime($closing_month. "last year"));
		} else {
		$last_month_start_date = date('Y-07-01', strtotime($closing_month));
		} 
		$last_month_end_date	= date('Y-m-t', strtotime($closing_month. "last month"));
		
		// previous Month Date Calculation ..
		if (date('m', strtotime($closing_month)) < '07') {
		$previous_month_start_date	= date('Y-07-01', strtotime($closing_month. "last year"));
		} else {
		$previous_month_start_date = date('Y-07-01', strtotime($closing_month));
		} 
		$previous_month_end_date	= date('Y-m-t', strtotime($closing_month. "last month". "last month"));
		
		// Current Year Date Calculation ..
		if (date('m', strtotime($closing_month)) < '07') {
		$current_year_start			= date('Y', strtotime($closing_month. "last year"));
		$current_year_end			= date('y', strtotime($closing_month));
		$current_year_start_date	= date('Y-07-01', strtotime($closing_month. "last year"));
		$current_year_end_date		= date('Y-m-t', strtotime($closing_month));
		} else {
		$current_year_start			= date('Y', strtotime($closing_month));
		$current_year_end			= date('y', strtotime($closing_month. "+1 year"));
		$current_year_start_date	= date('Y-07-01', strtotime($closing_month));
		$current_year_end_date		= date('Y-m-t', strtotime($closing_month. "+1 year"));
		} 
		
		// last Year Date Calculation ..
		if (date('m', strtotime($closing_month)) < '07') {
		$last_year_start_date	= date('Y-07-01', strtotime($closing_month. "last year". "last year"));
		$last_year_start		= date('Y', strtotime($closing_month. "last year". "last year"));
		$last_year_end			= date('y', strtotime($closing_month. "last year"));
		$last_year_end_date		= date('Y-06-31', strtotime($closing_month. "last year"));
		} else {
		$last_year_start_date	= date('Y-07-01', strtotime($closing_month. "last year"));
		$last_year_start		= date('Y', strtotime($closing_month. "last year"));
		$last_year_end			= date('y', strtotime($closing_month));
		$last_year_end_date		= date('Y-06-31', strtotime($closing_month));
		} 
		
		// previous Year Date Calculation ..
		if (date('m', strtotime($closing_month)) < '07') {
		$previous_year_start_date	= date('Y-07-01', strtotime($closing_month. "last year". "last year". "last year"));
		$previous_year_start		= date('Y', strtotime($closing_month. "last year". "last year". "last year"));
		$previous_year_end			= date('y', strtotime($closing_month. "last year". "last year"));
		$previous_year_end_date		= date('Y-06-31', strtotime($closing_month. "last year". "last year"));
		} else {
		$previous_year_start_date	= date('Y-07-01', strtotime($closing_month. "last year". "last year"));
		$previous_year_start		= date('Y', strtotime($closing_month. "last year". "last year"));
		$previous_year_end			= date('y', strtotime($closing_month. "last year"));
		$previous_year_end_date		= date('Y-06-31', strtotime($closing_month. "last year"));
		} ?>
		
		<table class="table-hover" width="100%" align="center">
			<thead class="text-uppercase">
				<tr class="table-bordered">  
					<th class="text-center" rowspan="2"><?= $this->lang->line('particulars');?></th>
					<th class="text-center" rowspan="2"><?= $this->lang->line('notes');?></th>
					<th class="text-center" colspan="12"><?= $this->lang->line('amounts');?></th>
				</tr>
				<tr class="table-bordered">  
					<th class="text-center" colspan="2">
						<?= $this->lang->line('current_month');?> <br/> <?= date('M-y', strtotime($closing_month));?>
					</th>
					<th class="text-center" colspan="2">
						<?= $this->lang->line('last_month');?> <br/> <?= date('M-y', strtotime($closing_month. "last month"));?>
					</th>
					<th class="text-center" colspan="2">
						<?= $this->lang->line('previous_month');?> <br/> <?= date('M-y', strtotime($closing_month. "last month". "last month"));?>
					</th>
					<th class="text-center" colspan="2" width="15%"> 
						<!--<?= $this->lang->line('quarterly');?> <br/> <?= date('M-y', strtotime($closing_month. "last month". "last month"));?> <?= $this->lang->line('to');?> <?= date('M-y', strtotime($closing_month));?>-->
						<?php if(date('m-y', strtotime($closing_month)) <= 3) {?>
						<?= $this->lang->line('quarterly');?> <br/> Oct-<?= date('y', strtotime($closing_month. "last year"));?> <?= $this->lang->line('to');?> Dec-<?= date('y', strtotime($closing_month. "last year"));?>
						<?php } else if(date('m-y', strtotime($closing_month)) <= 6) {?>
						<?= $this->lang->line('quarterly');?> <br/> Jan-<?= date('y', strtotime($closing_month));?> <?= $this->lang->line('to');?> Mar-<?= date('y', strtotime($closing_month));?>
						<?php } else  if(date('m-y', strtotime($closing_month)) <= 9) {?>
						<?= $this->lang->line('quarterly');?> <br/> Apr-<?= date('y', strtotime($closing_month));?> <?= $this->lang->line('to');?> Jun-<?= date('y', strtotime($closing_month));?>
						<?php } else  if(date('m-y', strtotime($closing_month)) <= 12) {?>
						<?= $this->lang->line('quarterly');?> <br/> Jul-<?= date('y', strtotime($closing_month));?> <?= $this->lang->line('to');?> Sep-<?= date('y', strtotime($closing_month));?>
						<?php }?>
					</th>
					<th class="text-center" colspan="2">
						<?= $this->lang->line('for_the_period');?> <br/> FY <?= $current_year_start;?>-<?= $current_year_end;?>
					</th>
					<th class="text-center" colspan="2">
						<?= $this->lang->line('for_the_period');?> <br/> FY <?= $last_year_start;?>-<?= $last_year_end;?>
					</th> 
				</tr>
			</thead>
			<tbody>
				<?php
				// assets balance sheet notes count ...
				$serial = 0; 
				$serial_2 = 0; 
				$accounts_type_assets_balance_sheet_note = $this->db->select("*") ->from('accounts_type') ->where('accounts_type_id', 100000) ->order_by('accounts_type_code', 'ASC') ->get()->result();
				foreach ($accounts_type_assets_balance_sheet_note as $accounts_type_balance_sheet_note_row) {
				
				$accounts_category_assets_balance_sheet_note = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_type_balance_sheet_note_row->accounts_type_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
				foreach ($accounts_category_assets_balance_sheet_note as $accounts_category_balance_sheet_note_row) {
				
				$control_group_assets_balance_sheet_note = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_category_balance_sheet_note_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
				foreach ($control_group_assets_balance_sheet_note as $control_group_balance_sheet_note_row) {?>
				
				<?php } } }
				
				// fund & liabilities balance sheet notes count ...
				$serial = $serial;  
				$accounts_type_balance_sheet_note = $this->db->select("*") ->from('accounts_type') ->where('accounts_type_id', 200000) ->order_by('accounts_type_code', 'ASC') ->get()->result();
				foreach ($accounts_type_balance_sheet_note as $accounts_type_balance_sheet_note_row) {
				
				$accounts_category_balance_sheet_note = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_type_balance_sheet_note_row->accounts_type_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
				foreach ($accounts_category_balance_sheet_note as $accounts_category_balance_sheet_note_row) {
				
				$control_group_balance_sheet_note = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_category_balance_sheet_note_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
				foreach ($control_group_balance_sheet_note as $control_group_balance_sheet_note_row) {?>
				
				<?php } } }?>
				
				<?php 
				$serial = $serial;
				$serial_note = $serial; 
				
				$serial_income = $serial; 
				$serial_income_view = $serial; 
				$accounts_type_income = $this->db->select("*") ->from('accounts_type') ->where('accounts_type_id', 300000) ->order_by('accounts_type_code', 'ASC') ->get()->result();
				foreach ($accounts_type_income as $accounts_type_income_row)
				{?> 
				<tr class="text-uppercase">
					<th class="text-left" colspan="14"><?= $this->lang->line('a');?>. <?= $accounts_type_income_row->accounts_type_name;?> (<?= $accounts_type_income_row->accounts_type_code;?>)</th>
				</tr>
				<?php
				$total_current_month_income 			= 0.00;
				$total_current_last_month_income		= 0.00;
				$total_current_previous_month_income	= 0.00;
				$total_quarterly_income					= 0.00;
				$total_last_month_income 				= 0.00;
				$total_previous_month_income 			= 0.00;
				$total_current_year_income 				= 0.00;
				$total_last_year_income 				= 0.00;
				$total_previous_year_income 			= 0.00;
				
				$accounts_category_income = $this->db->select("DISTINCT(accounts_details_accounts_category) as chart_of_accounts_id, chart_of_accounts_code, chart_of_accounts_name")
				->from('accounts_details') 
				->join('chart_of_accounts', 'accounts_details.accounts_details_accounts_category = chart_of_accounts.chart_of_accounts_id', 'LEFT')
				->where('chart_of_accounts.chart_of_accounts_accounts_category', $accounts_type_income_row->accounts_type_id)
				
				->where('accounts_details.accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$current_month_end_date.'"')
				->group_by('chart_of_accounts.chart_of_accounts_code', 'ASC')
				->get()
				->result();
				foreach ($accounts_category_income as $accounts_category_income_row) {?>
				<tr class="">
					<th class="text-left" colspan="14"><?= $accounts_category_income_row->chart_of_accounts_code;?> - <?= $accounts_category_income_row->chart_of_accounts_name;?></th>
				</tr>	
				<?php 
					
				$accounts_control_group_income = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_category_income_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
				foreach ($accounts_control_group_income as $accounts_control_group_income_row) {
					
				$accounts_general_ledger_income = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_control_group_income_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
				foreach ($accounts_general_ledger_income as $accounts_general_ledger_income_row) {
					
				$accounts_sub_ledger_income = $this->db->select("DISTINCT(accounts_details_subsidiary_ledger) as chart_of_accounts_id, chart_of_accounts_code, chart_of_accounts_name")
				->from('accounts_details') 
				->join('chart_of_accounts', 'accounts_details.accounts_details_subsidiary_ledger = chart_of_accounts.chart_of_accounts_id', 'LEFT')
				->where('chart_of_accounts.chart_of_accounts_accounts_category', $accounts_general_ledger_income_row->chart_of_accounts_id)
				 
				->where('accounts_details.accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$current_month_end_date.'"')
				->group_by('chart_of_accounts.chart_of_accounts_code', 'ASC')
				->get()
				->result();
				foreach ($accounts_sub_ledger_income as $accounts_sub_ledger_income_row) {
				$s_note = ++$serial_note;
				?>
				<tr>
					<td class="text-left"><?= $accounts_sub_ledger_income_row->chart_of_accounts_code;?> - <?= $accounts_sub_ledger_income_row->chart_of_accounts_name;?></td>
					<td class="text-center">
						<a class="btn-outline-danger  rounded-pill" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="action_view_model('<?= base_url("accounts/income_expenditure_notes_view/?type=Income&note=$s_note&s_coa=$accounts_sub_ledger_income_row->chart_of_accounts_id&coa=$accounts_general_ledger_income_row->chart_of_accounts_id&closing_month=$closing_month");?>')"><?= str_pad(++$serial, 2, '0', STR_PAD_LEFT);?></a>
					</td> 
					<?php 
					$current_month_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_month_income_balance") 
					->from('accounts_details')
					 
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
					->where('accounts_details_subsidiary_ledger', $accounts_sub_ledger_income_row->chart_of_accounts_id)  
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($current_month_income as $current_month_income_row)
					{
					$current_month_income_balance = $current_month_income_row->current_month_income_balance;
					$total_current_month_income  += $current_month_income_balance;
					?>			
					<th class="text-center" width="1%"></th>
					<td class="text-right"><?php if ($current_month_income_balance >0) { echo' '.number_format($current_month_income_balance, 2 . '').' ';} else { echo'-';} ?></td>
					<?php }?> 
					<?php 
					$current_last_month_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_last_month_income_balance") 
					->from('accounts_details')
					 
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_last_month_start_date.'" and "'.$current_last_month_end_date.'"')
					->where('accounts_details_subsidiary_ledger', $accounts_sub_ledger_income_row->chart_of_accounts_id)  
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($current_last_month_income as $current_last_month_income_row)
					{
					$current_last_month_income_balance = $current_last_month_income_row->current_last_month_income_balance;
					$total_current_last_month_income  += $current_last_month_income_balance;
					?>			
					<th class="text-center" width="1%"></th>
					<td class="text-right"><?php if ($current_last_month_income_balance >0) { echo' '.number_format($current_last_month_income_balance, 2 . '').' ';} else { echo'-';} ?></td>
					<?php }?>
					<?php 
					$current_previous_month_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_previous_month_income_balance") 
					->from('accounts_details')
					 
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_previous_month_start_date.'" and "'.$current_previous_month_end_date.'"')
					->where('accounts_details_subsidiary_ledger', $accounts_sub_ledger_income_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($current_previous_month_income as $current_previous_month_income_row)
					{
					$current_previous_month_income_balance = $current_previous_month_income_row->current_previous_month_income_balance;
					$total_current_previous_month_income  += $current_previous_month_income_balance;
					?>			
					<th class="text-center" width="1%"></th>
					<td class="text-right"><?php if ($current_previous_month_income_balance >0) { echo' '.number_format($current_previous_month_income_balance, 2 . '').' ';} else { echo'-';} ?></td>
					<?php }?>
					<?php 
					$quarterly_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS quarterly_income_balance") 
					->from('accounts_details')
					 
					->where('accounts_details_voucher_posting_date BETWEEN "'.$quarterly_start_date.'" and "'.$quarterly_end_date.'"')
					->where('accounts_details_subsidiary_ledger', $accounts_sub_ledger_income_row->chart_of_accounts_id)  
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($quarterly_income as $quarterly_income_row)
					{
					$quarterly_income_balance = $quarterly_income_row->quarterly_income_balance;
					$total_quarterly_income  += $quarterly_income_balance;
					?>			
					<th class="text-center" width="1%"></th>
					<td class="text-right"><?php if ($quarterly_income_balance >0) { echo' '.number_format($quarterly_income_balance, 2 . '').' ';} else { echo'-';} ?></td>
					<?php }?>
					
					<?php 
					$current_year_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_year_income_balance") 
					->from('accounts_details')
					 
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_year_start_date.'" and "'.$current_year_end_date.'"')
					->where('accounts_details_subsidiary_ledger', $accounts_sub_ledger_income_row->chart_of_accounts_id)  
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($current_year_income as $current_year_income_row)
					{
					$current_year_income_balance = $current_year_income_row->current_year_income_balance;
					$total_current_year_income  += $current_year_income_balance;
					?>			
					<th class="text-center" width="1%"></th>
					<td class="text-right"><?php if ($current_year_income_balance >0) { echo' '.number_format($current_year_income_balance, 2 . '').' ';} else { echo'-';} ?></td>
					<?php }?>
					<?php 
					$last_year_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS last_year_income_balance") 
					->from('accounts_details')
					 
					->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
					->where('accounts_details_subsidiary_ledger', $accounts_sub_ledger_income_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($last_year_income as $last_year_income_row)
					{
					$last_year_income_balance = $last_year_income_row->last_year_income_balance;
					$total_last_year_income  += $last_year_income_balance;
					?>			
					<th class="text-center" width="1%"></th>
					<td class="text-right"><?php if ($last_year_income_balance >0) { echo' '.number_format($last_year_income_balance, 2 . '').' ';} else { echo'-';} ?></td>
					<?php }?>
				</tr>
				<?php } } } }?>
				<tr class="text-uppercase">
					<th class="text-center" colspan="2"><?= $this->lang->line('total');?> <?= $accounts_type_income_row->accounts_type_name;?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_month_income >0) { echo' '.number_format($total_current_month_income, 2 . '').' ';} else { echo'-';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_last_month_income >0) { echo' '.number_format($total_current_last_month_income, 2 . '').' ';} else { echo'-';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_previous_month_income >0) { echo' '.number_format($total_current_previous_month_income, 2 . '').' ';} else { echo'-';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-bottom-double bd-top"><?php if ($total_quarterly_income >0) { echo' '.number_format($total_quarterly_income, 2 . '').' ';} else { echo'-';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_year_income >0) { echo' '.number_format($total_current_year_income, 2 . '').' ';} else { echo'-';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-bottom-double bd-top"><?php if ($total_last_year_income >0) { echo' '.number_format($total_last_year_income, 2 . '').' ';} else { echo'-';} ?></th>
				</tr>
				<?php } ?>
				
				<?php 
				// expenditure ..
				
				$serial = $serial;
				$serial_expense = $serial;
				
				$serial_expenditure = $serial; 
				$serial_expenditure_view = $serial; 
				$accounts_type_expenditure = $this->db->select("*") ->from('accounts_type') ->where('accounts_type_id', 400000) ->order_by('accounts_type_code', 'ASC') ->get()->result();
				foreach ($accounts_type_expenditure as $accounts_type_expenditure_row)
				{?> 
				<tr class="text-uppercase">
					<th class="text-left" colspan="14"><?= $this->lang->line('b');?>. <?= $accounts_type_expenditure_row->accounts_type_name;?> (<?= $accounts_type_expenditure_row->accounts_type_code;?>)</th>
				</tr>
				<?php
				$total_current_month_expenditure 			= 0.00;
				$total_current_last_month_expenditure 		= 0.00;
				$total_current_previous_month_expenditure 	= 0.00; 
				$total_quarterly_expenditure 				= 0.00;
				$total_last_month_expenditure 				= 0.00;
				$total_previous_month_expenditure 			= 0.00;
				$total_current_year_expenditure 			= 0.00;
				$total_last_year_expenditure 				= 0.00;
				$total_previous_year_expenditure 			= 0.00;
				
				$accounts_category_expenditure = $this->db->select("DISTINCT(accounts_details_accounts_category) as chart_of_accounts_id, chart_of_accounts_code, chart_of_accounts_name")
				->from('accounts_details') 
				->join('chart_of_accounts', 'accounts_details.accounts_details_accounts_category = chart_of_accounts.chart_of_accounts_id', 'LEFT')
				->where('chart_of_accounts.chart_of_accounts_accounts_category', $accounts_type_expenditure_row->accounts_type_id)
				
				->where('accounts_details.accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$current_month_end_date.'"')
				->group_by('chart_of_accounts.chart_of_accounts_code', 'ASC')
				->get()
				->result();
				foreach ($accounts_category_expenditure as $accounts_category_expenditure_row) {?>
				<tr class="">
					<th class="text-left" colspan="14"><?= $accounts_category_expenditure_row->chart_of_accounts_code;?> - <?= $accounts_category_expenditure_row->chart_of_accounts_name;?></th>
				</tr>	
				<?php 
				$accounts_control_group_expenditure = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
				foreach ($accounts_control_group_expenditure as $accounts_control_group_expenditure_row) {
					
				$accounts_general_ledger_expenditure = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_control_group_expenditure_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
				foreach ($accounts_general_ledger_expenditure as $accounts_general_ledger_expenditure_row) {
					
				$accounts_sub_ledger_expenditure = $this->db->select("DISTINCT(accounts_details_subsidiary_ledger) as chart_of_accounts_id, chart_of_accounts_code, chart_of_accounts_name")
				->from('accounts_details') 
				->join('chart_of_accounts', 'accounts_details.accounts_details_subsidiary_ledger = chart_of_accounts.chart_of_accounts_id', 'LEFT')
				->where('chart_of_accounts.chart_of_accounts_accounts_category', $accounts_general_ledger_expenditure_row->chart_of_accounts_id)
				
				->where('accounts_details.accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$current_month_end_date.'"')
				->group_by('chart_of_accounts.chart_of_accounts_code', 'ASC')
				->get()
				->result();
				foreach ($accounts_sub_ledger_expenditure as $accounts_sub_ledger_expenditure_row) {
				$s_note = ++$serial_expense;?>
				<tr>
					<td class="text-left"><?= $accounts_sub_ledger_expenditure_row->chart_of_accounts_code;?> - <?= $accounts_sub_ledger_expenditure_row->chart_of_accounts_name;?></td>
					<td class="text-center">
						<a class="btn-outline-danger  rounded-pill" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="action_view_model('<?= base_url("accounts/income_expenditure_notes_view/?type=Expenditure&note=$s_note&s_coa=$accounts_sub_ledger_expenditure_row->chart_of_accounts_id&coa=$accounts_general_ledger_expenditure_row->chart_of_accounts_id&closing_month=$closing_month");?>')"><?= str_pad(++$serial, 2, '0', STR_PAD_LEFT);?></a>
					</td> 
					<?php 
					$current_month_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_month_expenditure_balance") 
					->from('accounts_details')
					 
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
					->where('accounts_details_subsidiary_ledger', $accounts_sub_ledger_expenditure_row->chart_of_accounts_id)
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($current_month_expenditure as $current_month_expenditure_row)
					{
					$current_month_expenditure_balance = $current_month_expenditure_row->current_month_expenditure_balance;
					$total_current_month_expenditure  += $current_month_expenditure_balance;
					?>			
					<th class="text-center" width="1%"></th>
					<td class="text-right"><?php if ($current_month_expenditure_balance >0) { echo' '.number_format($current_month_expenditure_balance, 2 . '').' ';} else { echo'-';} ?></td>
					<?php }?> 
					<?php 
					$current_last_month_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_last_month_expenditure_balance") 
					->from('accounts_details')
					 
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_last_month_start_date.'" and "'.$current_last_month_end_date.'"')
					->where('accounts_details_subsidiary_ledger', $accounts_sub_ledger_expenditure_row->chart_of_accounts_id)  
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($current_last_month_expenditure as $current_last_month_expenditure_row)
					{
					$current_last_month_expenditure_balance = $current_last_month_expenditure_row->current_last_month_expenditure_balance;
					$total_current_last_month_expenditure  += $current_last_month_expenditure_balance;
					?>			
					<th class="text-center" width="1%"></th>
					<td class="text-right"><?php if ($current_last_month_expenditure_balance >0) { echo' '.number_format($current_last_month_expenditure_balance, 2 . '').' ';} else { echo'-';} ?></td>
					<?php }?>
					<?php 
					$current_previous_month_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_previous_month_expenditure_balance") 
					->from('accounts_details')
					 
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_previous_month_start_date.'" and "'.$current_previous_month_end_date.'"')
					->where('accounts_details_subsidiary_ledger', $accounts_sub_ledger_expenditure_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($current_previous_month_expenditure as $current_previous_month_expenditure_row)
					{
					$current_previous_month_expenditure_balance = $current_previous_month_expenditure_row->current_previous_month_expenditure_balance;
					$total_current_previous_month_expenditure  += $current_previous_month_expenditure_balance;
					?>			
					<th class="text-center" width="1%"></th>
					<td class="text-right"><?php if ($current_previous_month_expenditure_balance >0) { echo' '.number_format($current_previous_month_expenditure_balance, 2 . '').' ';} else { echo'-';} ?></td>
					<?php }?>
					<?php 
					$quarterly_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS quarterly_expenditure_balance") 
					->from('accounts_details')
					 
					->where('accounts_details_voucher_posting_date BETWEEN "'.$quarterly_start_date.'" and "'.$quarterly_end_date.'"')
					->where('accounts_details_subsidiary_ledger', $accounts_sub_ledger_expenditure_row->chart_of_accounts_id)  
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($quarterly_expenditure as $quarterly_expenditure_row)
					{
					$quarterly_expenditure_balance = $quarterly_expenditure_row->quarterly_expenditure_balance;
					$total_quarterly_expenditure  += $quarterly_expenditure_balance;
					?>			
					<th class="text-center" width="1%"></th>
					<td class="text-right"><?php if ($quarterly_expenditure_balance >0) { echo' '.number_format($quarterly_expenditure_balance, 2 . '').' ';} else { echo'-';} ?></td>
					<?php }?>
					
					<?php 
					$current_year_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_year_expenditure_balance") 
					->from('accounts_details')
					 
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_year_start_date.'" and "'.$current_year_end_date.'"')
					->where('accounts_details_subsidiary_ledger', $accounts_sub_ledger_expenditure_row->chart_of_accounts_id)  
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($current_year_expenditure as $current_year_expenditure_row)
					{
					$current_year_expenditure_balance = $current_year_expenditure_row->current_year_expenditure_balance;
					$total_current_year_expenditure  += $current_year_expenditure_balance;
					?>			
					<th class="text-center" width="1%"></th>
					<td class="text-right"><?php if ($current_year_expenditure_balance >0) { echo' '.number_format($current_year_expenditure_balance, 2 . '').' ';} else { echo'-';} ?></td>
					<?php }?>
					<?php 
					$last_year_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS last_year_expenditure_balance") 
					->from('accounts_details')
					 
					->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
					->where('accounts_details_subsidiary_ledger', $accounts_sub_ledger_expenditure_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($last_year_expenditure as $last_year_expenditure_row)
					{
					$last_year_expenditure_balance = $last_year_expenditure_row->last_year_expenditure_balance;
					$total_last_year_expenditure  += $last_year_expenditure_balance;
					?>			
					<th class="text-center" width="1%"></th>
					<td class="text-right"><?php if ($last_year_expenditure_balance >0) { echo' '.number_format($last_year_expenditure_balance, 2 . '').' ';} else { echo'-';} ?></td>
					<?php }?>
				</tr>
				<?php } } } }?>
				<tr class="text-uppercase">
					<th class="text-center" colspan="2"><?= $this->lang->line('total');?> <?= $accounts_type_expenditure_row->accounts_type_name;?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_month_expenditure >0) { echo' '.number_format($total_current_month_expenditure, 2 . '').' ';} else { echo'-';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_last_month_expenditure >0) { echo' '.number_format($total_current_last_month_expenditure, 2 . '').' ';} else { echo'-';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_previous_month_expenditure >0) { echo' '.number_format($total_current_previous_month_expenditure, 2 . '').' ';} else { echo'-';} ?></th>
					<th class="text-center" width="1%"></th> 
					<th class="text-right bd-bottom-double bd-top"><?php if ($total_quarterly_expenditure >0) { echo' '.number_format($total_quarterly_expenditure, 2 . '').' ';} else { echo'-';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_year_expenditure >0) { echo' '.number_format($total_current_year_expenditure, 2 . '').' ';} else { echo'-';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-bottom-double bd-top"><?php if ($total_last_year_expenditure >0) { echo' '.number_format($total_last_year_expenditure, 2 . '').' ';} else { echo'-';} ?></th>
				</tr>
				<?php }?>
				<tr>
					<th class="text-center" colspan="10">&nbsp;</th>
				</tr>
				<tr class="text-uppercase"> 
					<?php 
					$total_current_month_surplus_deficit			= $total_current_month_income - $total_current_month_expenditure;
					$total_current_last_month_surplus_deficit		= $total_current_last_month_income - $total_current_last_month_expenditure;
					$total_current_previous_month_surplus_deficit	= $total_current_previous_month_income - $total_current_previous_month_expenditure;
					$total_quarterly_surplus_deficit 				= $total_quarterly_income - $total_quarterly_expenditure;
					$total_last_month_surplus_deficit 				= $total_last_month_income - $total_last_month_expenditure;
					$total_current_year_surplus_deficit 			= $total_current_year_income - $total_current_year_expenditure;
					$total_last_year_surplus_deficit 				= $total_last_year_income - $total_last_year_expenditure;
					$total_previous_year_surplus_deficit 			= $total_previous_year_income - $total_previous_year_expenditure;
					?>
					<th class="text-center" colspan="2"><?= $this->lang->line('surplus_deficit');?> (<?= $this->lang->line('a');?>-<?= $this->lang->line('b');?>)</th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_month_surplus_deficit >0) { echo' '.number_format($total_current_month_surplus_deficit, 2 . '').' ';} else if ($total_current_month_surplus_deficit == 0) { echo'-';} else { echo' ('.number_format(abs($total_current_month_surplus_deficit),2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_last_month_surplus_deficit >0) { echo' '.number_format($total_current_last_month_surplus_deficit, 2 . '').' ';} else if ($total_current_last_month_surplus_deficit == 0) { echo'-';} else { echo' ('.number_format(abs($total_current_last_month_surplus_deficit),2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_previous_month_surplus_deficit >0) { echo' '.number_format($total_current_previous_month_surplus_deficit, 2 . '').' ';} else if ($total_current_previous_month_surplus_deficit == 0) { echo'-';} else { echo' ('.number_format(abs($total_current_previous_month_surplus_deficit),2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-bottom-double bd-top"><?php if ($total_quarterly_surplus_deficit >0) { echo' '.number_format($total_quarterly_surplus_deficit, 2 . '').' ';} else if ($total_quarterly_surplus_deficit == 0) { echo'-';} else { echo' ('.number_format(abs($total_quarterly_surplus_deficit),2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_year_surplus_deficit >0) { echo' '.number_format($total_current_year_surplus_deficit, 2 . '').' ';} else if ($total_current_year_surplus_deficit == 0) { echo'-';} else { echo' ('.number_format(abs($total_current_year_surplus_deficit),2 . '').') ';} ?></th>
					
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-bottom-double bd-top"><?php if ($total_last_year_surplus_deficit >0) { echo' '.number_format($total_last_year_surplus_deficit, 2 . '').' ';} else if ($total_last_year_surplus_deficit == 0) { echo'-';} else { echo' ('.number_format(abs($total_last_year_surplus_deficit),2 . '').') ';} ?></th>
				</tr>
				
				
				<tr>
					<th class="text-center" colspan="14">&nbsp;</th>
				</tr>
				<tr>
					<th class="text-center" colspan="14">&nbsp;</th>
				</tr>
				<?php 
				$total_income 			= $total_current_year_income + $total_last_year_income;
				$total_expenditure 		= $total_current_year_expenditure + $total_last_year_expenditure;
				$total_surplus_deficit 	= $total_income - $total_expenditure;
				?>
				<tr class="text-uppercase"> 
					<th class="text-right" colspan="12"><?= $this->lang->line('total');?> <?= $this->lang->line('financial_year');?> <?= $this->lang->line('income');?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-bottom-double bd-top"><?php if ($total_income >0) { echo' '.number_format($total_income, 2 . '').' ';} else if ($total_income == 0) { echo'-';} else { echo' ('.number_format(abs($total_income),2 . '').') ';} ?></th>
				</tr>
				<tr class="text-uppercase"> 
					<th class="text-right" colspan="12"><?= $this->lang->line('total');?> <?= $this->lang->line('financial_year');?> <?= $this->lang->line('expenditure');?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-bottom-double bd-top"><?php if ($total_expenditure >0) { echo' '.number_format($total_expenditure, 2 . '').' ';} else if ($total_expenditure == 0) { echo'-';} else { echo' ('.number_format(abs($total_expenditure),2 . '').') ';} ?></th>
				</tr>
				<tr class="text-uppercase"> 
					<th class="text-right" colspan="12"><?= $this->lang->line('total');?> <?= $this->lang->line('financial_year');?> <?= $this->lang->line('surplus_deficit');?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-bottom-double bd-top"><?php if ($total_surplus_deficit >0) { echo' '.number_format($total_surplus_deficit, 2 . '').' ';} else if ($total_surplus_deficit == 0) { echo'-';} else { echo' ('.number_format(abs($total_surplus_deficit),2 . '').') ';} ?></th>
				</tr>
				
				<tr>
					<th class="text-center" colspan="14">&nbsp;</th>
				</tr>
				<tr>
					<th class="text-center" colspan="14">&nbsp;</th>
				</tr>  
				<?php 
				$grand_total_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS grand_total_income") 
				->from('accounts_details')
				
				->where('accounts_details_accounts_type', 300000) 
				->where('accounts_details_voucher_posting_date BETWEEN "'.$starting_date.'" and "'.$current_year_end_date.'"') 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($grand_total_income as $grand_total_income_row)
				{
				$grand_total_income_balance = $grand_total_income_row->grand_total_income; 
				}
				
				$grand_total_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS grand_total_expenditure") 
				->from('accounts_details')
				 
				->where('accounts_details_accounts_type', 400000) 
				->where('accounts_details_voucher_posting_date BETWEEN "'.$starting_date.'" and "'.$current_year_end_date.'"') 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($grand_total_expenditure as $grand_total_expenditure_row)
				{
				$grand_total_expenditure_balance = $grand_total_expenditure_row->grand_total_expenditure;  
				}	
				
				$grand_total_surplus_deficit 	= $grand_total_income_balance - $grand_total_expenditure_balance;
				?>
				<tr class="text-uppercase"> 
					<th class="text-right" colspan="12"><?= $this->lang->line('grand_total');?> <?= $this->lang->line('income');?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-bottom-double bd-top"><?php if ($grand_total_income_balance >0) { echo' '.number_format($grand_total_income_balance, 2 . '').' ';} else if ($grand_total_income_balance == 0) { echo'-';} else { echo' ('.number_format(abs($grand_total_income_balance),2 . '').') ';} ?></th>
				</tr>
				<tr class="text-uppercase"> 
					<th class="text-right" colspan="12"><?= $this->lang->line('grand_total');?> <?= $this->lang->line('expenditure');?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-bottom-double bd-top"><?php if ($grand_total_expenditure_balance >0) { echo' '.number_format($grand_total_expenditure_balance, 2 . '').' ';} else if ($grand_total_expenditure_balance == 0) { echo'-';} else { echo' ('.number_format(abs($grand_total_expenditure_balance),2 . '').') ';} ?></th>
				</tr>
				<tr class="text-uppercase"> 
					<th class="text-right" colspan="12"><?= $this->lang->line('grand_total');?> <?= $this->lang->line('surplus_deficit');?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-bottom-double bd-top"><?php if ($grand_total_surplus_deficit >0) { echo' '.number_format($grand_total_surplus_deficit, 2 . '').' ';} else if ($grand_total_surplus_deficit == 0) { echo'-';} else { echo' ('.number_format(abs($grand_total_surplus_deficit),2 . '').') ';} ?></th>
				</tr>
			</tbody>
		</table>
		
		<br/><br/><br/><br/><br/>
		
		<table class="" width="100%" align="center">  
			<tr class="text-uppercase">
				<th width="30%" class="text-center bd-top"><?= $this->lang->line('prepared_by');?></th>
				<th width="5%"></th>
				<th width="30%" class="text-center bd-top"><?= $this->lang->line('checked_by');?></th>
				<th width="5%"></th>
				<th width="30%" class="text-center bd-top"><?= $this->lang->line('authorised');?></th>
			</tr>
		</table>
		<?php 
		return $output;
	}
	
	/* ------------------------------------------------------
	Balance Sheet Note Model
	------------------------------------------------------- */
	function balance_sheet_note($closing_month)
	{	
		$output = '';
		
		// Current Month Date Calculation ..
		$current_month_start_date = date('2015-01-01');
		$current_month_end_date =  date('Y-m-t', strtotime($closing_month));
		
		// Last Month Date Calculation .		
		$last_month_start_date	= date('2015-01-01');
		$last_month_end_date	= date('Y-m-t', strtotime($closing_month. "last month"));
		
		// Previous Month Date Calculation ..
		$previous_month_start_date	= date('2015-01-01');
		$previous_month_end_date	= date('Y-m-t', strtotime($closing_month. "last month". "last month"));
		
		// Current Year Date Calculation ..
		if (date('m', strtotime($closing_month)) < '07') {
		$current_year_start			= date('Y', strtotime($closing_month. "last year"));
		$current_year_end			= date('y', strtotime($closing_month));
		$current_year_start_date	= date('2015-01-01');
		$current_year_end_date		= date('Y-06-t', strtotime($closing_month));
		} else {
		$current_year_start			= date('Y', strtotime($closing_month));
		$current_year_end			= date('y', strtotime($closing_month. "+1 year"));
		$current_year_start_date	= date('2015-01-01');
		$current_year_end_date		= date('Y-06-t', strtotime($closing_month. "+1 year"));
		} 
		
		// last Year Date Calculation ..
		if (date('m', strtotime($closing_month)) < '07') { 
		$last_year_start		= date('Y', strtotime($closing_month. "last year". "last year"));
		$last_year_end			= date('y', strtotime($closing_month. "last year"));
		
		$last_year_start_date	= date('2015-01-01');
		$last_year_end_date		= date('Y-06-t', strtotime($closing_month. "last year"));
		} else { 
		$last_year_start		= date('Y', strtotime($closing_month. "last year"));
		$last_year_end			= date('y', strtotime($closing_month));
		
		$last_year_start_date	= date('2015-01-01');
		$last_year_end_date		= date('Y-06-t', strtotime($closing_month));
		}
		
		// Previous Year Date Calculation ..
		if (date('m', strtotime($closing_month)) < '07') { 
		$previous_year_start		= date('Y', strtotime($closing_month. "last year". "last year". "last year"));
		$previous_year_end			= date('y', strtotime($closing_month. "last year". "last year"));
		$previous_year_start_date	= date('2015-01-01');
		$previous_year_end_date		= date('Y-06-t', strtotime($closing_month. "last year". "last year"));
		} else { 
		$previous_year_start		= date('Y', strtotime($closing_month. "last year". "last year"));
		$previous_year_end			= date('y', strtotime($closing_month. "last year"));
		$previous_year_start_date	= date('2015-01-01');
		$previous_year_end_date		= date('Y-06-t', strtotime($closing_month. "last year"));
		}?> 
		<table class="table-hover" width="100%" align="center">
			<thead class="text-uppercase">
				<tr class="table-bordered">  
					<th class="text-center" rowspan="2" width="31%" colspan="2"><?= $this->lang->line('particulars');?></th> 
					<th class="text-center" colspan="8"><?= $this->lang->line('amounts');?></th>
				</tr>
				<tr class="table-bordered">  
					<th class="text-center" colspan="2" width="11%">
						<?= date('M-y', strtotime($closing_month));?>
					</th>
					<th class="text-center" colspan="2" width="11%">
						<?= date('M-y', strtotime($closing_month. "last month"));?>
					</th>
					<th class="text-center" colspan="2" width="11%">
						Jun-<?= $last_year_end;?>
					</th>
					<th class="text-center " colspan="2" width="12%">
						Jun-<?= $previous_year_end;?>
					</th>
				</tr>
			</thead>
			<tbody>
			<?php 
			
			$serial = 0;
			$accounts_type_assets = $this->db->select("*") ->from('accounts_type') ->where('accounts_type_id', 100000) ->order_by('accounts_type_code', 'ASC') ->get()->result();
			foreach ($accounts_type_assets as $accounts_type_assets_row)
			{?>  
			<?php 
			$accounts_category_aseets = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_type_assets_row->accounts_type_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
			foreach ($accounts_category_aseets as $accounts_category_aseets_row) {
				
			$control_group_aseets = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_category_aseets_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
			foreach ($control_group_aseets as $control_group_aseets_row) {?>
			<tr>
				<th class="text-left" width="3%">
					<a class="btn-outline-danger  rounded-pill" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="action_view_model('<?= base_url("accounts/balance_sheet_note_view");?>')"><?= number_format(++$serial,2 . '');?></a>
				</th>
				<th class="text-left text-uppercase" colspan="13"><?= $control_group_aseets_row->chart_of_accounts_code;?> - <?= $control_group_aseets_row->chart_of_accounts_name;?></th>
			</tr>
			<?php 
			$total_current_month_general_ledger_assets = 0.00;
			$total_last_month_general_ledger_assets = 0.00;
			$total_previous_month_general_ledger_assets = 0.00;
			$total_current_year_general_ledger_assets = 0.00;
			$total_last_year_general_ledger_assets = 0.00;
			$total_previous_year_general_ledger_assets = 0.00;
			
			$general_ledger_aseets = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $control_group_aseets_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
			foreach ($general_ledger_aseets as $general_ledger_aseets_row) {?>
			<tr>
				<td></td>
				<td class="text-left"><?= $general_ledger_aseets_row->chart_of_accounts_code;?> - <?= $general_ledger_aseets_row->chart_of_accounts_name;?></th>
				<?php 
				$general_ledger_current_month_assets = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS general_ledger_current_month_assets_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
				->where('accounts_details_general_ledger', $general_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($general_ledger_current_month_assets as $general_ledger_current_month_assets_row)
				{
				$general_ledger_current_month_assets_balance = $general_ledger_current_month_assets_row->general_ledger_current_month_assets_balance;
				$total_current_month_general_ledger_assets	+= $general_ledger_current_month_assets_balance;
				?>			
				<td class="text-center" width="1%"></td>
				<td class="text-right"><?php if ($general_ledger_current_month_assets_balance >0) { echo' '.number_format($general_ledger_current_month_assets_balance, 2 . '').' ';} else if($general_ledger_current_month_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($general_ledger_current_month_assets_balance), 2 . '').') ';} ?></td>
				<?php }?>
				<?php 
				$general_ledger_last_month_assets = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS general_ledger_last_month_assets_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$last_month_start_date.'" and "'.$last_month_end_date.'"')
				->where('accounts_details_general_ledger', $general_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($general_ledger_last_month_assets as $general_ledger_last_month_assets_row)
				{
				$general_ledger_last_month_assets_balance = $general_ledger_last_month_assets_row->general_ledger_last_month_assets_balance;
				$total_last_month_general_ledger_assets	+= $general_ledger_last_month_assets_balance;
				?>			
				<td class="text-center" width="1%"></td>
				<td class="text-right"><?php if ($general_ledger_last_month_assets_balance >0) { echo' '.number_format($general_ledger_last_month_assets_balance, 2 . '').' ';} else if($general_ledger_last_month_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($general_ledger_last_month_assets_balance), 2 . '').') ';} ?></td>
				<?php }?>
				
				<?php 
				$general_ledger_last_year_assets = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS general_ledger_last_year_assets_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
				->where('accounts_details_general_ledger', $general_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($general_ledger_last_year_assets as $general_ledger_last_year_assets_row)
				{
				$general_ledger_last_year_assets_balance = $general_ledger_last_year_assets_row->general_ledger_last_year_assets_balance;
				$total_last_year_general_ledger_assets	+= $general_ledger_last_year_assets_balance;
				?>			
				<td class="text-center" width="1%"></td>
				<td class="text-right"><?php if ($general_ledger_last_year_assets_balance >0) { echo' '.number_format($general_ledger_last_year_assets_balance, 2 . '').' ';} else if($general_ledger_last_year_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($general_ledger_last_year_assets_balance), 2 . '').') ';} ?></td>
				<?php }?>
				<?php 
				$general_ledger_previous_year_assets = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS general_ledger_previous_year_assets_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_year_start_date.'" and "'.$previous_year_end_date.'"')
				->where('accounts_details_general_ledger', $general_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($general_ledger_previous_year_assets as $general_ledger_previous_year_assets_row)
				{
				$general_ledger_previous_year_assets_balance = $general_ledger_previous_year_assets_row->general_ledger_previous_year_assets_balance;
				$total_previous_year_general_ledger_assets	+= $general_ledger_previous_year_assets_balance;
				?>			
				<td class="text-center " width="1%"></td>
				<td class="text-right "><?php if ($general_ledger_previous_year_assets_balance >0) { echo' '.number_format($general_ledger_previous_year_assets_balance, 2 . '').' ';} else if($general_ledger_previous_year_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($general_ledger_previous_year_assets_balance), 2 . '').') ';} ?></td>
				<?php }?>
			</tr>
			<?php }?>
			<tr class="text-uppercase">
				<th class="text-center" colspan="2"><?= $this->lang->line('total');?></th>
				<th class="text-center" width="1%"></th>
				<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_month_general_ledger_assets >0) { echo' '.number_format($total_current_month_general_ledger_assets, 2 . '').' ';} else if($total_current_month_general_ledger_assets ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_month_general_ledger_assets), 2 . '').') ';} ?></th>
				<th class="text-center" width="1%"></th>
				<th class="text-right bd-bottom-double bd-top"><?php if ($total_last_month_general_ledger_assets >0) { echo' '.number_format($total_last_month_general_ledger_assets, 2 . '').' ';} else if($total_last_month_general_ledger_assets ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_month_general_ledger_assets), 2 . '').') ';} ?></th>
				<th class="text-center" width="1%"></th>
				<th class="text-right bd-bottom-double bd-top"><?php if ($total_last_year_general_ledger_assets >0) { echo' '.number_format($total_last_year_general_ledger_assets, 2 . '').' ';} else if($total_last_year_general_ledger_assets ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_year_general_ledger_assets), 2 . '').') ';} ?></th>
				<th class="text-center " width="1%"></th>
				<th class="text-right  bd-bottom-double bd-top"><?php if ($total_previous_year_general_ledger_assets >0) { echo' '.number_format($total_previous_year_general_ledger_assets, 2 . '').' ';} else if($total_previous_year_general_ledger_assets ==0) {echo '-';} else { echo' ('.number_format(abs($total_previous_year_general_ledger_assets), 2 . '').') ';} ?></th>
			</tr>
			
			<tr>
				<th class="text-center" width="3%">&nbsp;</th>
				<th class="text-left text-uppercase" colspan="13"></th>
			</tr>
			
			<?php  
			$serial_assets = 0; 
			$general_ledger_aseets = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $control_group_aseets_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
			foreach ($general_ledger_aseets as $general_ledger_aseets_row) {?>
			<tr>
				<th class="text-left" width="3%">
					<a class="btn-outline-danger  rounded-pill" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="action_view_model('<?= base_url("accounts/balance_sheet_note_view");?>')"><?= number_format($serial,0 . '');?>.<?= number_format(++$serial_assets,1 . '');?></a>
				</th>
				<th class="text-left text-uppercase" colspan="13"><?= $general_ledger_aseets_row->chart_of_accounts_code;?> - <?= $general_ledger_aseets_row->chart_of_accounts_name;?></th>
			</tr>
			<?php 
			
			$total_current_month_subsidiary_ledger_assets = 0.00;
			$total_last_month_subsidiary_ledger_assets = 0.00;
			$total_previous_month_subsidiary_ledger_assets = 0.00;
			$total_current_year_subsidiary_ledger_assets = 0.00;
			$total_last_year_subsidiary_ledger_assets = 0.00;
			$total_previous_year_subsidiary_ledger_assets = 0.00;
			$subsidiary_ledger_aseets = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $general_ledger_aseets_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
			foreach ($subsidiary_ledger_aseets as $subsidiary_ledger_aseets_row) {?>
			<tr>
				<td></td>
				<td class="text-left"><?= $subsidiary_ledger_aseets_row->chart_of_accounts_code;?> - <?= $subsidiary_ledger_aseets_row->chart_of_accounts_name;?></th>
				<?php 
				$subsidiary_ledger_current_month_assets = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS subsidiary_ledger_current_month_assets_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
				->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($subsidiary_ledger_current_month_assets as $subsidiary_ledger_current_month_assets_row)
				{
				$subsidiary_ledger_current_month_assets_balance = $subsidiary_ledger_current_month_assets_row->subsidiary_ledger_current_month_assets_balance;
				$total_current_month_subsidiary_ledger_assets	+= $subsidiary_ledger_current_month_assets_balance;
				?>			
				<td class="text-center" width="1%"></td>
				<td class="text-right"><?php if ($subsidiary_ledger_current_month_assets_balance >0) { echo' '.number_format($subsidiary_ledger_current_month_assets_balance, 2 . '').' ';} else if($subsidiary_ledger_current_month_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($subsidiary_ledger_current_month_assets_balance), 2 . '').') ';} ?></td>
				<?php }?>
				<?php 
				$subsidiary_ledger_last_month_assets = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS subsidiary_ledger_last_month_assets_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$last_month_start_date.'" and "'.$last_month_end_date.'"')
				->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($subsidiary_ledger_last_month_assets as $subsidiary_ledger_last_month_assets_row)
				{
				$subsidiary_ledger_last_month_assets_balance = $subsidiary_ledger_last_month_assets_row->subsidiary_ledger_last_month_assets_balance;
				$total_last_month_subsidiary_ledger_assets	+= $subsidiary_ledger_last_month_assets_balance;
				?>			
				<td class="text-center" width="1%"></td>
				<td class="text-right"><?php if ($subsidiary_ledger_last_month_assets_balance >0) { echo' '.number_format($subsidiary_ledger_last_month_assets_balance, 2 . '').' ';} else if($subsidiary_ledger_last_month_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($subsidiary_ledger_last_month_assets_balance), 2 . '').') ';} ?></td>
				<?php }?>
				
				<?php 
				$subsidiary_ledger_last_year_assets = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS subsidiary_ledger_last_year_assets_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
				->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($subsidiary_ledger_last_year_assets as $subsidiary_ledger_last_year_assets_row)
				{
				$subsidiary_ledger_last_year_assets_balance = $subsidiary_ledger_last_year_assets_row->subsidiary_ledger_last_year_assets_balance;
				$total_last_year_subsidiary_ledger_assets	+= $subsidiary_ledger_last_year_assets_balance;
				?>			
				<td class="text-center" width="1%"></td>
				<td class="text-right"><?php if ($subsidiary_ledger_last_year_assets_balance >0) { echo' '.number_format($subsidiary_ledger_last_year_assets_balance, 2 . '').' ';} else if($subsidiary_ledger_last_year_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($subsidiary_ledger_last_year_assets_balance), 2 . '').') ';} ?></td>
				<?php }?>
				<?php 
				$subsidiary_ledger_previous_year_assets = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS subsidiary_ledger_previous_year_assets_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_year_start_date.'" and "'.$previous_year_end_date.'"')
				->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($subsidiary_ledger_previous_year_assets as $subsidiary_ledger_previous_year_assets_row)
				{
				$subsidiary_ledger_previous_year_assets_balance = $subsidiary_ledger_previous_year_assets_row->subsidiary_ledger_previous_year_assets_balance;
				$total_previous_year_subsidiary_ledger_assets	+= $subsidiary_ledger_previous_year_assets_balance;
				?>			
				<td class="text-center " width="1%"></td>
				<td class="text-right "><?php if ($subsidiary_ledger_previous_year_assets_balance >0) { echo' '.number_format($subsidiary_ledger_previous_year_assets_balance, 2 . '').' ';} else if($subsidiary_ledger_previous_year_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($subsidiary_ledger_previous_year_assets_balance), 2 . '').') ';} ?></td>
				<?php }?>
			<?php }?>
			</tr>
			<tr class="text-uppercase">
				<th class="text-center" colspan="2"><?= $this->lang->line('total');?></th>
				<th class="text-center" width="1%"></th>
				<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_month_subsidiary_ledger_assets >0) { echo' '.number_format($total_current_month_subsidiary_ledger_assets, 2 . '').' ';} else if($total_current_month_subsidiary_ledger_assets ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_month_subsidiary_ledger_assets), 2 . '').') ';} ?></th>
				<th class="text-center" width="1%"></th>
				<th class="text-right bd-bottom-double bd-top"><?php if ($total_last_month_subsidiary_ledger_assets >0) { echo' '.number_format($total_last_month_subsidiary_ledger_assets, 2 . '').' ';} else if($total_last_month_subsidiary_ledger_assets ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_month_subsidiary_ledger_assets), 2 . '').') ';} ?></th>
				<th class="text-center" width="1%"></th>
				<th class="text-right bd-bottom-double bd-top"><?php if ($total_last_year_subsidiary_ledger_assets >0) { echo' '.number_format($total_last_year_subsidiary_ledger_assets, 2 . '').' ';} else if($total_last_year_subsidiary_ledger_assets ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_year_subsidiary_ledger_assets), 2 . '').') ';} ?></th>
				<th class="text-center " width="1%"></th>
				<th class="text-right  bd-bottom-double bd-top"><?php if ($total_previous_year_subsidiary_ledger_assets >0) { echo' '.number_format($total_previous_year_subsidiary_ledger_assets, 2 . '').' ';} else if($total_previous_year_subsidiary_ledger_assets ==0) {echo '-';} else { echo' ('.number_format(abs($total_previous_year_subsidiary_ledger_assets), 2 . '').') ';} ?></th>
			</tr>
			
			<tr>
				<th class="text-center" width="3%">&nbsp;</th>
				<th class="text-left text-uppercase" colspan="13"></th>
			</tr>
			<?php } ?>
			<?php } } }?>
			
			
			
			<?php 
			// Income ....
			$serial = $serial;
			$serial_income = $serial; 
			$serial_income_view = $serial; 
			$accounts_type_income = $this->db->select("*") ->from('accounts_type') ->where('accounts_type_id', 300000) ->order_by('accounts_type_code', 'ASC') ->get()->result();
			foreach ($accounts_type_income as $accounts_type_income_row)
			{
				$total_current_month_income = 0.00;
				$total_last_month_income = 0.00;
				$total_previous_month_income = 0.00;
				$total_current_year_income = 0.00;
				$total_last_year_income = 0.00;
				$total_previous_year_income = 0.00;
				
				$accounts_category_income = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_type_income_row->accounts_type_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
				foreach ($accounts_category_income as $accounts_category_income_row) 
				{
					$current_month_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_month_income_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_income_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($current_month_income as $current_month_income_row)
					{
					$current_month_income_balance = $current_month_income_row->current_month_income_balance;
					$total_current_month_income  += $current_month_income_balance;
					}
					
					$last_month_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS last_month_income_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$last_month_start_date.'" and "'.$last_month_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_income_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($last_month_income as $last_month_income_row)
					{
					$last_month_income_balance = $last_month_income_row->last_month_income_balance;
					$total_last_month_income  += $last_month_income_balance;
					}
					
					$last_year_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS last_year_income_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_income_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($last_year_income as $last_year_income_row)
					{
					$last_year_income_balance = $last_year_income_row->last_year_income_balance;
					$total_last_year_income  += $last_year_income_balance;
					}
					
					$previous_year_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS previous_year_income_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_year_start_date.'" and "'.$previous_year_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_income_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($previous_year_income as $previous_year_income_row)
					{
					$previous_year_income_balance = $previous_year_income_row->previous_year_income_balance;
					$total_previous_year_income  += $previous_year_income_balance;
					}
				} 
			}
			
			// expenditure ..
			$serial = $serial;
			$serial_expenditure = $serial; 
			$serial_expenditure_view = $serial; 
			$accounts_type_expenditure = $this->db->select("*") ->from('accounts_type') ->where('accounts_type_id', 400000) ->order_by('accounts_type_code', 'ASC') ->get()->result();
			foreach ($accounts_type_expenditure as $accounts_type_expenditure_row)
			{
				$total_current_month_expenditure = 0.00;
				$total_last_month_expenditure = 0.00;
				$total_previous_month_expenditure = 0.00;
				$total_current_year_expenditure = 0.00;
				$total_last_year_expenditure = 0.00;
				$total_previous_year_expenditure = 0.00;
				
				$accounts_category_expenditure = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_type_expenditure_row->accounts_type_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
				foreach ($accounts_category_expenditure as $accounts_category_expenditure_row)
				{
					$current_month_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_month_expenditure_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($current_month_expenditure as $current_month_expenditure_row)
					{
					$current_month_expenditure_balance = $current_month_expenditure_row->current_month_expenditure_balance;
					$total_current_month_expenditure  += $current_month_expenditure_balance;
					}
					
					$last_month_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS last_month_expenditure_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$last_month_start_date.'" and "'.$last_month_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($last_month_expenditure as $last_month_expenditure_row)
					{
					$last_month_expenditure_balance = $last_month_expenditure_row->last_month_expenditure_balance;
					$total_last_month_expenditure  += $last_month_expenditure_balance;
					}
					
					$last_year_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS last_year_expenditure_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($last_year_expenditure as $last_year_expenditure_row)
					{
					$last_year_expenditure_balance = $last_year_expenditure_row->last_year_expenditure_balance;
					$total_last_year_expenditure  += $last_year_expenditure_balance;
					}
					
					$previous_year_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS previous_year_expenditure_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_year_start_date.'" and "'.$previous_year_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($previous_year_expenditure as $previous_year_expenditure_row)
					{
					$previous_year_expenditure_balance = $previous_year_expenditure_row->previous_year_expenditure_balance;
					$total_previous_year_expenditure  += $previous_year_expenditure_balance;
					}  
				} 
			} 
			$total_current_month_general_ledger_surplus_deficit		= $total_current_month_income - $total_current_month_expenditure;
			$total_last_month_general_ledger_surplus_deficit		= $total_last_month_income - $total_last_month_expenditure;
			$total_last_year_general_ledger_surplus_deficit			= $total_last_year_income - $total_last_year_expenditure;
			$total_previous_year_general_ledger_surplus_deficit		= $total_previous_year_income - $total_previous_year_expenditure;
			
			$total_current_month_subsidiary_ledger_surplus_deficit	= $total_current_month_income - $total_current_month_expenditure;
			$total_last_month_subsidiary_ledger_surplus_deficit		= $total_last_month_income - $total_last_month_expenditure;
			$total_last_year_subsidiary_ledger_surplus_deficit		= $total_last_year_income - $total_last_year_expenditure;
			$total_previous_year_subsidiary_ledger_surplus_deficit	= $total_previous_year_income - $total_previous_year_expenditure;
			?>
			
			<?php 
			// Funds & Liabilities .......
			$serial = $serial;
			$accounts_type_fund_liabilities = $this->db->select("*") ->from('accounts_type') ->where('accounts_type_id', 200000) ->order_by('accounts_type_code', 'ASC') ->get()->result();
			foreach ($accounts_type_fund_liabilities as $accounts_type_fund_liabilities_row)
			{?>  
			<?php 
			$accounts_category_aseets = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_type_fund_liabilities_row->accounts_type_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
			foreach ($accounts_category_aseets as $accounts_category_aseets_row) {
				
			$control_group_aseets = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_category_aseets_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
			foreach ($control_group_aseets as $control_group_aseets_row) {?>
			<tr>
				<th class="text-left" width="3%">
					<a class="btn-outline-danger  rounded-pill" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="action_view_model('<?= base_url("accounts/balance_sheet_note_view");?>')"><?= number_format(++$serial,2 . '');?></a>
				</th>
				<th class="text-left text-uppercase" colspan="13"><?= $control_group_aseets_row->chart_of_accounts_code;?> - <?= $control_group_aseets_row->chart_of_accounts_name;?></th>
			</tr>
			<?php 
			$total_current_month_general_ledger_fund_liabilities = 0.00;
			$total_last_month_general_ledger_fund_liabilities = 0.00;
			$total_previous_month_general_ledger_fund_liabilities = 0.00;
			$total_current_year_general_ledger_fund_liabilities = 0.00;
			$total_last_year_general_ledger_fund_liabilities = 0.00;
			$total_previous_year_general_ledger_fund_liabilities = 0.00;
			
			$general_ledger_aseets = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $control_group_aseets_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
			foreach ($general_ledger_aseets as $general_ledger_aseets_row) {?>
			<tr>
				<td></td>
				<td class="text-left"><?= $general_ledger_aseets_row->chart_of_accounts_code;?> - <?= $general_ledger_aseets_row->chart_of_accounts_name;?></th>
				<?php 
				$general_ledger_current_month_fund_liabilities = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS general_ledger_current_month_fund_liabilities_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
				->where('accounts_details_general_ledger', $general_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($general_ledger_current_month_fund_liabilities as $general_ledger_current_month_fund_liabilities_row)
				{
				if ( $general_ledger_aseets_row->chart_of_accounts_general_ledger_balance_sheet_show == 1) {	
				$general_ledger_current_month_fund_liabilities_balance = $general_ledger_current_month_fund_liabilities_row->general_ledger_current_month_fund_liabilities_balance + $total_current_month_general_ledger_surplus_deficit;
				
				} else if ( $general_ledger_aseets_row->chart_of_accounts_general_ledger_balance_sheet_show == 0) {	
				$general_ledger_current_month_fund_liabilities_balance = $general_ledger_current_month_fund_liabilities_row->general_ledger_current_month_fund_liabilities_balance;
				} else { 
				$general_ledger_current_month_fund_liabilities_balance = 0.00;
				}
				$total_current_month_general_ledger_fund_liabilities	+= $general_ledger_current_month_fund_liabilities_balance;
				
				?>			
				<td class="text-center" width="1%"></td>
				<td class="text-right"><?php if ($general_ledger_current_month_fund_liabilities_balance >0) { echo' '.number_format($general_ledger_current_month_fund_liabilities_balance, 2 . '').' ';} else if($general_ledger_current_month_fund_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($general_ledger_current_month_fund_liabilities_balance), 2 . '').') ';} ?></td>
				<?php }?>
				<?php 
				$general_ledger_last_month_fund_liabilities = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS general_ledger_last_month_fund_liabilities_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$last_month_start_date.'" and "'.$last_month_end_date.'"')
				->where('accounts_details_general_ledger', $general_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($general_ledger_last_month_fund_liabilities as $general_ledger_last_month_fund_liabilities_row)
				{
				if ( $general_ledger_aseets_row->chart_of_accounts_general_ledger_balance_sheet_show == 1) {	
				$general_ledger_last_month_fund_liabilities_balance = $general_ledger_last_month_fund_liabilities_row->general_ledger_last_month_fund_liabilities_balance + $total_last_month_general_ledger_surplus_deficit;
				
				} else if ( $general_ledger_aseets_row->chart_of_accounts_general_ledger_balance_sheet_show == 0) {	
				$general_ledger_last_month_fund_liabilities_balance = $general_ledger_last_month_fund_liabilities_row->general_ledger_last_month_fund_liabilities_balance;
				} else { 
				$general_ledger_last_month_fund_liabilities_balance = 0.00;
				}
				$total_last_month_general_ledger_fund_liabilities	+= $general_ledger_last_month_fund_liabilities_balance;
				?>			
				<td class="text-center" width="1%"></td>
				<td class="text-right"><?php if ($general_ledger_last_month_fund_liabilities_balance >0) { echo' '.number_format($general_ledger_last_month_fund_liabilities_balance, 2 . '').' ';} else if($general_ledger_last_month_fund_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($general_ledger_last_month_fund_liabilities_balance), 2 . '').') ';} ?></td>
				<?php }?>
				
				<?php 
				$general_ledger_last_year_fund_liabilities = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS general_ledger_last_year_fund_liabilities_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
				->where('accounts_details_general_ledger', $general_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($general_ledger_last_year_fund_liabilities as $general_ledger_last_year_fund_liabilities_row)
				{
				if ( $general_ledger_aseets_row->chart_of_accounts_general_ledger_balance_sheet_show == 1) {	
				$general_ledger_last_year_fund_liabilities_balance = $general_ledger_last_year_fund_liabilities_row->general_ledger_last_year_fund_liabilities_balance + $total_last_year_general_ledger_surplus_deficit;
				
				} else if ( $general_ledger_aseets_row->chart_of_accounts_general_ledger_balance_sheet_show == 0) {	
				$general_ledger_last_year_fund_liabilities_balance = $general_ledger_last_year_fund_liabilities_row->general_ledger_last_year_fund_liabilities_balance;
				} else { 
				$general_ledger_last_year_fund_liabilities_balance = 0.00;
				}
				$total_last_year_general_ledger_fund_liabilities	+= $general_ledger_last_year_fund_liabilities_balance;
				?>			
				<td class="text-center" width="1%"></td>
				<td class="text-right"><?php if ($general_ledger_last_year_fund_liabilities_balance >0) { echo' '.number_format($general_ledger_last_year_fund_liabilities_balance, 2 . '').' ';} else if($general_ledger_last_year_fund_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($general_ledger_last_year_fund_liabilities_balance), 2 . '').') ';} ?></td>
				<?php }?>
				<?php 
				$general_ledger_previous_year_fund_liabilities = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS general_ledger_previous_year_fund_liabilities_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_year_start_date.'" and "'.$previous_year_end_date.'"')
				->where('accounts_details_general_ledger', $general_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($general_ledger_previous_year_fund_liabilities as $general_ledger_previous_year_fund_liabilities_row)
				{
				if ( $general_ledger_aseets_row->chart_of_accounts_general_ledger_balance_sheet_show == 1) {	
				$general_ledger_previous_year_fund_liabilities_balance = $general_ledger_previous_year_fund_liabilities_row->general_ledger_previous_year_fund_liabilities_balance + $total_previous_year_general_ledger_surplus_deficit;
				
				} else if ( $general_ledger_aseets_row->chart_of_accounts_general_ledger_balance_sheet_show == 0) {	
				$general_ledger_previous_year_fund_liabilities_balance = $general_ledger_previous_year_fund_liabilities_row->general_ledger_previous_year_fund_liabilities_balance;
				} else { 
				$general_ledger_previous_year_fund_liabilities_balance = 0.00;
				}
				$total_previous_year_general_ledger_fund_liabilities	+= $general_ledger_previous_year_fund_liabilities_balance;
				?>			
				<td class="text-center " width="1%"></td>
				<td class="text-right "><?php if ($general_ledger_previous_year_fund_liabilities_balance >0) { echo' '.number_format($general_ledger_previous_year_fund_liabilities_balance, 2 . '').' ';} else if($general_ledger_previous_year_fund_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($general_ledger_previous_year_fund_liabilities_balance), 2 . '').') ';} ?></td>
				<?php }?>
			</tr>
			<?php }?>
			<tr class="text-uppercase">
				<th class="text-center" colspan="2"><?= $this->lang->line('total');?></th>
				<th class="text-center" width="1%"></th>
				<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_month_general_ledger_fund_liabilities >0) { echo' '.number_format($total_current_month_general_ledger_fund_liabilities, 2 . '').' ';} else if($total_current_month_general_ledger_fund_liabilities ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_month_general_ledger_fund_liabilities), 2 . '').') ';} ?></th>
				<th class="text-center" width="1%"></th>
				<th class="text-right bd-bottom-double bd-top"><?php if ($total_last_month_general_ledger_fund_liabilities >0) { echo' '.number_format($total_last_month_general_ledger_fund_liabilities, 2 . '').' ';} else if($total_last_month_general_ledger_fund_liabilities ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_month_general_ledger_fund_liabilities), 2 . '').') ';} ?></th>
				<th class="text-center" width="1%"></th>
				<th class="text-right bd-bottom-double bd-top"><?php if ($total_last_year_general_ledger_fund_liabilities >0) { echo' '.number_format($total_last_year_general_ledger_fund_liabilities, 2 . '').' ';} else if($total_last_year_general_ledger_fund_liabilities ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_year_general_ledger_fund_liabilities), 2 . '').') ';} ?></th>
				<th class="text-center " width="1%"></th>
				<th class="text-right  bd-bottom-double bd-top"><?php if ($total_previous_year_general_ledger_fund_liabilities >0) { echo' '.number_format($total_previous_year_general_ledger_fund_liabilities, 2 . '').' ';} else if($total_previous_year_general_ledger_fund_liabilities ==0) {echo '-';} else { echo' ('.number_format(abs($total_previous_year_general_ledger_fund_liabilities), 2 . '').') ';} ?></th>
			</tr>
			
			<tr>
				<th class="text-center" width="3%">&nbsp;</th>
				<th class="text-left text-uppercase" colspan="13"></th>
			</tr>
			
			<?php  
			$serial_fund_liabilities = 0; 
			$general_ledger_aseets = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $control_group_aseets_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
			foreach ($general_ledger_aseets as $general_ledger_aseets_row) {?>
			<tr>
				<th class="text-left" width="3%">
					<a class="btn-outline-danger  rounded-pill" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="action_view_model('<?= base_url("accounts/balance_sheet_note_view");?>')"><?= number_format($serial,0 . '');?>.<?= number_format(++$serial_fund_liabilities,1 . '');?></a>
				</th>
				<th class="text-left text-uppercase" colspan="13"><?= $general_ledger_aseets_row->chart_of_accounts_code;?> - <?= $general_ledger_aseets_row->chart_of_accounts_name;?></th>
			</tr>
			<?php 
			
			$total_current_month_subsidiary_ledger_fund_liabilities = 0.00;
			$total_last_month_subsidiary_ledger_fund_liabilities = 0.00;
			$total_previous_month_subsidiary_ledger_fund_liabilities = 0.00;
			$total_current_year_subsidiary_ledger_fund_liabilities = 0.00;
			$total_last_year_subsidiary_ledger_fund_liabilities = 0.00;
			$total_previous_year_subsidiary_ledger_fund_liabilities = 0.00;
			$subsidiary_ledger_aseets = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $general_ledger_aseets_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
			foreach ($subsidiary_ledger_aseets as $subsidiary_ledger_aseets_row) {?>
			<tr>
				<td></td>
				<td class="text-left"><?= $subsidiary_ledger_aseets_row->chart_of_accounts_code;?> - <?= $subsidiary_ledger_aseets_row->chart_of_accounts_name;?></th>
				<?php 
				$subsidiary_ledger_current_month_fund_liabilities = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS subsidiary_ledger_current_month_fund_liabilities_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
				->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($subsidiary_ledger_current_month_fund_liabilities as $subsidiary_ledger_current_month_fund_liabilities_row)
				{
				if ( $subsidiary_ledger_aseets_row->chart_of_accounts_subsidiary_ledger_balance_sheet_show == 1) {	
				$subsidiary_ledger_current_month_fund_liabilities_balance = $subsidiary_ledger_current_month_fund_liabilities_row->subsidiary_ledger_current_month_fund_liabilities_balance + $total_current_month_subsidiary_ledger_surplus_deficit;
				
				} else if ( $subsidiary_ledger_aseets_row->chart_of_accounts_subsidiary_ledger_balance_sheet_show == 0) {	
				$subsidiary_ledger_current_month_fund_liabilities_balance = $subsidiary_ledger_current_month_fund_liabilities_row->subsidiary_ledger_current_month_fund_liabilities_balance;
				} else { 
				$subsidiary_ledger_current_month_fund_liabilities_balance = 0.00;
				}
				$total_current_month_subsidiary_ledger_fund_liabilities	+= $subsidiary_ledger_current_month_fund_liabilities_balance;
				?>			
				<td class="text-center" width="1%"></td>
				<td class="text-right"><?php if ($subsidiary_ledger_current_month_fund_liabilities_balance >0) { echo' '.number_format($subsidiary_ledger_current_month_fund_liabilities_balance, 2 . '').' ';} else if($subsidiary_ledger_current_month_fund_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($subsidiary_ledger_current_month_fund_liabilities_balance), 2 . '').') ';} ?></td>
				<?php }?>
				<?php 
				$subsidiary_ledger_last_month_fund_liabilities = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS subsidiary_ledger_last_month_fund_liabilities_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$last_month_start_date.'" and "'.$last_month_end_date.'"')
				->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($subsidiary_ledger_last_month_fund_liabilities as $subsidiary_ledger_last_month_fund_liabilities_row)
				{
				if ( $subsidiary_ledger_aseets_row->chart_of_accounts_subsidiary_ledger_balance_sheet_show == 1) {	
				$subsidiary_ledger_last_month_fund_liabilities_balance = $subsidiary_ledger_last_month_fund_liabilities_row->subsidiary_ledger_last_month_fund_liabilities_balance + $total_last_month_subsidiary_ledger_surplus_deficit;
				
				} else if ( $subsidiary_ledger_aseets_row->chart_of_accounts_subsidiary_ledger_balance_sheet_show == 0) {	
				$subsidiary_ledger_last_month_fund_liabilities_balance = $subsidiary_ledger_last_month_fund_liabilities_row->subsidiary_ledger_last_month_fund_liabilities_balance;
				} else { 
				$subsidiary_ledger_last_month_fund_liabilities_balance = 0.00;
				}
				$total_last_month_subsidiary_ledger_fund_liabilities	+= $subsidiary_ledger_last_month_fund_liabilities_balance;
				?>			
				<td class="text-center" width="1%"></td>
				<td class="text-right"><?php if ($subsidiary_ledger_last_month_fund_liabilities_balance >0) { echo' '.number_format($subsidiary_ledger_last_month_fund_liabilities_balance, 2 . '').' ';} else if($subsidiary_ledger_last_month_fund_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($subsidiary_ledger_last_month_fund_liabilities_balance), 2 . '').') ';} ?></td>
				<?php }?>
				
				<?php 
				$subsidiary_ledger_last_year_fund_liabilities = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS subsidiary_ledger_last_year_fund_liabilities_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
				->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($subsidiary_ledger_last_year_fund_liabilities as $subsidiary_ledger_last_year_fund_liabilities_row)
				{
				if ( $subsidiary_ledger_aseets_row->chart_of_accounts_subsidiary_ledger_balance_sheet_show == 1) {	
				$subsidiary_ledger_last_year_fund_liabilities_balance = $subsidiary_ledger_last_year_fund_liabilities_row->subsidiary_ledger_last_year_fund_liabilities_balance + $total_last_year_subsidiary_ledger_surplus_deficit;
				
				} else if ( $subsidiary_ledger_aseets_row->chart_of_accounts_subsidiary_ledger_balance_sheet_show == 0) {	
				$subsidiary_ledger_last_year_fund_liabilities_balance = $subsidiary_ledger_last_year_fund_liabilities_row->subsidiary_ledger_last_year_fund_liabilities_balance;
				} else { 
				$subsidiary_ledger_last_year_fund_liabilities_balance = 0.00;
				}
				$total_last_year_subsidiary_ledger_fund_liabilities	+= $subsidiary_ledger_last_year_fund_liabilities_balance;
				?>			
				<td class="text-center" width="1%"></td>
				<td class="text-right"><?php if ($subsidiary_ledger_last_year_fund_liabilities_balance >0) { echo' '.number_format($subsidiary_ledger_last_year_fund_liabilities_balance, 2 . '').' ';} else if($subsidiary_ledger_last_year_fund_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($subsidiary_ledger_last_year_fund_liabilities_balance), 2 . '').') ';} ?></td>
				<?php }?>
				<?php 
				$subsidiary_ledger_previous_year_fund_liabilities = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS subsidiary_ledger_previous_year_fund_liabilities_balance") 
				->from('accounts_details')
				->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_year_start_date.'" and "'.$previous_year_end_date.'"')
				->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_aseets_row->chart_of_accounts_id) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				
				foreach($subsidiary_ledger_previous_year_fund_liabilities as $subsidiary_ledger_previous_year_fund_liabilities_row)
				{
				if ( $subsidiary_ledger_aseets_row->chart_of_accounts_subsidiary_ledger_balance_sheet_show == 1) {	
				$subsidiary_ledger_previous_year_fund_liabilities_balance = $subsidiary_ledger_previous_year_fund_liabilities_row->subsidiary_ledger_previous_year_fund_liabilities_balance + $total_previous_year_subsidiary_ledger_surplus_deficit;
				
				} else if ( $subsidiary_ledger_aseets_row->chart_of_accounts_subsidiary_ledger_balance_sheet_show == 0) {	
				$subsidiary_ledger_previous_year_fund_liabilities_balance = $subsidiary_ledger_previous_year_fund_liabilities_row->subsidiary_ledger_previous_year_fund_liabilities_balance;
				} else { 
				$subsidiary_ledger_previous_year_fund_liabilities_balance = 0.00;
				}
				$total_previous_year_subsidiary_ledger_fund_liabilities	+= $subsidiary_ledger_previous_year_fund_liabilities_balance;
				?>			
				<td class="text-center " width="1%"></td>
				<td class="text-right "><?php if ($subsidiary_ledger_previous_year_fund_liabilities_balance >0) { echo' '.number_format($subsidiary_ledger_previous_year_fund_liabilities_balance, 2 . '').' ';} else if($subsidiary_ledger_previous_year_fund_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($subsidiary_ledger_previous_year_fund_liabilities_balance), 2 . '').') ';} ?></td>
				<?php }?>
			<?php }?>	
			</tr>
			<tr class="text-uppercase">
				<th class="text-center" colspan="2"><?= $this->lang->line('total');?></th>
				<th class="text-center" width="1%"></th>
				<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_month_subsidiary_ledger_fund_liabilities >0) { echo' '.number_format($total_current_month_subsidiary_ledger_fund_liabilities, 2 . '').' ';} else if($total_current_month_subsidiary_ledger_fund_liabilities ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_month_subsidiary_ledger_fund_liabilities), 2 . '').') ';} ?></th>
				<th class="text-center" width="1%"></th>
				<th class="text-right bd-bottom-double bd-top"><?php if ($total_last_month_subsidiary_ledger_fund_liabilities >0) { echo' '.number_format($total_last_month_subsidiary_ledger_fund_liabilities, 2 . '').' ';} else if($total_last_month_subsidiary_ledger_fund_liabilities ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_month_subsidiary_ledger_fund_liabilities), 2 . '').') ';} ?></th>
				<th class="text-center" width="1%"></th>
				<th class="text-right bd-bottom-double bd-top"><?php if ($total_last_year_subsidiary_ledger_fund_liabilities >0) { echo' '.number_format($total_last_year_subsidiary_ledger_fund_liabilities, 2 . '').' ';} else if($total_last_year_subsidiary_ledger_fund_liabilities ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_year_subsidiary_ledger_fund_liabilities), 2 . '').') ';} ?></th>
				<th class="text-center " width="1%"></th>
				<th class="text-right  bd-bottom-double bd-top"><?php if ($total_previous_year_subsidiary_ledger_fund_liabilities >0) { echo' '.number_format($total_previous_year_subsidiary_ledger_fund_liabilities, 2 . '').' ';} else if($total_previous_year_subsidiary_ledger_fund_liabilities ==0) {echo '-';} else { echo' ('.number_format(abs($total_previous_year_subsidiary_ledger_fund_liabilities), 2 . '').') ';} ?></th>
			</tr>
			
			<tr>
				<th class="text-center" width="3%">&nbsp;</th>
				<th class="text-left text-uppercase" colspan="13"></th>
			</tr>
			<?php } ?>
			<?php } } }?>
			</tbody>
		</table>
		
		<br/><br/><br/>
		
		<table class="" width="100%" align="center">  
			<tr class="text-uppercase">
				<th width="19%" class="text-center bd-top"><?= $this->lang->line('prepared_by');?></th>
				<th width="8%"></th>
				<th width="19%" class="text-center bd-top"><?= $this->lang->line('checked_by');?></th>
				<th width="8%"></th>
				<th width="19%" class="text-center bd-top"><?= $this->lang->line('director_finance');?></th>
				<th width="8%"></th>
				<th width="19%" class="text-center bd-top"><?= $this->lang->line('treasurer');?></th>
			</tr>
		</table>
		<?php 
		return $output;
	}
	
	/* ------------------------------------------------------
	Income & Expenditure Note Model
	------------------------------------------------------- */
	function income_expenditure_note($closing_month)
	{	
		$output = '';
		
		// Current Month Date Calculation ..
		$current_month_start_date = date('Y-m-01', strtotime($closing_month));
		$current_month_end_date =  date('Y-m-t', strtotime($closing_month)); 
		
		$current_last_month_start_date = date('Y-m-01', strtotime($closing_month. "last month"));
		$current_last_month_end_date =  date('Y-m-t', strtotime($closing_month. "last month")); 
		
		$current_previous_month_start_date = date('Y-m-01', strtotime($closing_month. "last month". "last month"));
		$current_previous_month_end_date =  date('Y-m-t', strtotime($closing_month. "last month". "last month"));
		
		$quarterly_start_date = date('Y-m-01', strtotime($closing_month. "last month". "last month"));
		$quarterly_end_date =  date('Y-m-t', strtotime($closing_month)); 
		
		// last Month Date Calculation ..
		if (date('m', strtotime($closing_month)) < '07') {
		$last_month_start_date	= date('Y-07-01', strtotime($closing_month. "last year"));
		} else {
		$last_month_start_date = date('Y-07-01', strtotime($closing_month));
		} 
		$last_month_end_date	= date('Y-m-t', strtotime($closing_month. "last month"));
		
		// previous Month Date Calculation ..
		if (date('m', strtotime($closing_month)) < '07') {
		$previous_month_start_date	= date('Y-07-01', strtotime($closing_month. "last year"));
		} else {
		$previous_month_start_date = date('Y-07-01', strtotime($closing_month));
		} 
		$previous_month_end_date	= date('Y-m-t', strtotime($closing_month. "last month". "last month"));
		
		// Current Year Date Calculation ..
		if (date('m', strtotime($closing_month)) < '07') {
		$current_year_start			= date('Y', strtotime($closing_month. "last year"));
		$current_year_end			= date('y', strtotime($closing_month));
		$current_year_start_date	= date('Y-07-01', strtotime($closing_month. "last year"));
		$current_year_end_date		= date('Y-m-t', strtotime($closing_month));
		} else {
		$current_year_start			= date('Y', strtotime($closing_month));
		$current_year_end			= date('y', strtotime($closing_month. "+1 year"));
		$current_year_start_date	= date('Y-07-01', strtotime($closing_month));
		$current_year_end_date		= date('Y-m-t', strtotime($closing_month));
		} 
		
		// last Year Date Calculation ..
		if (date('m', strtotime($closing_month)) < '07') {
		$last_year_start_date	= date('Y-07-01', strtotime($closing_month. "last year". "last year"));
		$last_year_start		= date('Y', strtotime($closing_month. "last year". "last year"));
		$last_year_end			= date('y', strtotime($closing_month. "last year"));
		$last_year_end_date		= date('Y-06-31', strtotime($closing_month. "last year"));
		} else {
		$last_year_start_date	= date('Y-07-01', strtotime($closing_month. "last year"));
		$last_year_start		= date('Y', strtotime($closing_month. "last year"));
		$last_year_end			= date('y', strtotime($closing_month));
		$last_year_end_date		= date('Y-06-31', strtotime($closing_month));
		} 
		
		// previous Year Date Calculation ..
		if (date('m', strtotime($closing_month)) < '07') {
		$previous_year_start_date	= date('Y-07-01', strtotime($closing_month. "last year". "last year". "last year"));
		$previous_year_start		= date('Y', strtotime($closing_month. "last year". "last year". "last year"));
		$previous_year_end			= date('y', strtotime($closing_month. "last year". "last year"));
		$previous_year_end_date		= date('Y-06-31', strtotime($closing_month. "last year". "last year"));
		} else {
		$previous_year_start_date	= date('Y-07-01', strtotime($closing_month. "last year". "last year"));
		$previous_year_start		= date('Y', strtotime($closing_month. "last year". "last year"));
		$previous_year_end			= date('y', strtotime($closing_month. "last year"));
		$previous_year_end_date		= date('Y-06-31', strtotime($closing_month. "last year"));
		} ?>
		
		<table class="table-hover" width="100%" align="center">
			<thead class="text-uppercase">
				<tr class="table-bordered">  
					<th class="text-center" rowspan="2"><?= $this->lang->line('particulars');?></th>
					<th class="text-center" rowspan="2"><?= $this->lang->line('notes');?></th>
					<th class="text-center" colspan="12"><?= $this->lang->line('amounts');?></th>
				</tr>
				<tr class="table-bordered">  
					<th class="text-center" colspan="2">
						<?= $this->lang->line('current_month');?> <br/> <?= date('M-y', strtotime($closing_month));?>
					</th>
					<th class="text-center" colspan="2">
						<?= $this->lang->line('last_month');?> <br/> <?= date('M-y', strtotime($closing_month. "last month"));?>
					</th>
					<th class="text-center" colspan="2">
						<?= $this->lang->line('previous_month');?> <br/> <?= date('M-y', strtotime($closing_month. "last month". "last month"));?>
					</th>
					<th class="text-center" colspan="2" width="15%">
						<?= $this->lang->line('quarterly');?> <br/> <?= date('M-y', strtotime($closing_month. "last month". "last month"));?> <?= $this->lang->line('to');?> <?= date('M-y', strtotime($closing_month));?>
					</th>
					<th class="text-center" colspan="2">
						<?= $this->lang->line('for_the_period');?> <br/> FY <?= $current_year_start;?>-<?= $current_year_end;?>
					</th>
					<th class="text-center" colspan="2">
						<?= $this->lang->line('for_the_period');?> <br/> FY <?= $last_year_start;?>-<?= $last_year_end;?>
					</th> 
				</tr>
			</thead>
			<tbody>
			
			<?php
			// assets balance sheet notes count ...
			$serial = 0; 
			$accounts_type_assets_balance_sheet_note = $this->db->select("*") ->from('accounts_type') ->where('accounts_type_id', 100000) ->order_by('accounts_type_code', 'ASC') ->get()->result();
			foreach ($accounts_type_assets_balance_sheet_note as $accounts_type_balance_sheet_note_row) {
			
			$accounts_category_assets_balance_sheet_note = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_type_balance_sheet_note_row->accounts_type_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
			foreach ($accounts_category_assets_balance_sheet_note as $accounts_category_balance_sheet_note_row) {
			
			$control_group_assets_balance_sheet_note = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_category_balance_sheet_note_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
			foreach ($control_group_assets_balance_sheet_note as $control_group_balance_sheet_note_row) {?>
			<span class="d-none"><?= number_format(++$serial, 2 . '');?></span>
			<?php } } }
			
			// fund & liabilities balance sheet notes count ...
			$serial = $serial;  
			$accounts_type_balance_sheet_note = $this->db->select("*") ->from('accounts_type') ->where('accounts_type_id', 200000) ->order_by('accounts_type_code', 'ASC') ->get()->result();
			foreach ($accounts_type_balance_sheet_note as $accounts_type_balance_sheet_note_row) {
			
			$accounts_category_balance_sheet_note = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_type_balance_sheet_note_row->accounts_type_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
			foreach ($accounts_category_balance_sheet_note as $accounts_category_balance_sheet_note_row) {
			
			$control_group_balance_sheet_note = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_category_balance_sheet_note_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
			foreach ($control_group_balance_sheet_note as $control_group_balance_sheet_note_row) {?>
			<span class="d-none"><?= number_format(++$serial, 2 . '');?></span>
			<?php } } }?>
			
			<?php 
			// Income ....
			$serial = $serial;
			$accounts_type_income = $this->db->select("*") ->from('accounts_type') ->where('accounts_type_id', 300000) ->order_by('accounts_type_code', 'ASC') ->get()->result();
			foreach ($accounts_type_income as $accounts_type_income_row)
			{
				$total_current_month_accounts_category_income 			= 0;
				$total_current_last_month_accounts_category_income 		= 0;
				$total_current_previous_month_accounts_category_income 	= 0;
				$total_quarterly_accounts_category_income 				= 0;
				$total_last_month_accounts_category_income 				= 0;
				$total_previous_month_accounts_category_income 			= 0;
				$total_current_year_accounts_category_income 			= 0;
				$total_last_year_accounts_category_income 				= 0;
				$total_previous_year_accounts_category_income 			= 0;
				
				$accounts_category_income = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_type_income_row->accounts_type_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
				foreach ($accounts_category_income as $accounts_category_income_row) 
				{?>
				<tr>
					<th class="text-left" width="3%">
						<a class="btn-outline-danger  rounded-pill" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="action_view_model('<?= base_url("accounts/income_expenditure_note_view");?>')"><?= number_format(++$serial,2 . '');?></a>
					</th>
					<th class="text-left text-uppercase" colspan="13"><?= $accounts_category_income_row->chart_of_accounts_code;?> - <?= $accounts_category_income_row->chart_of_accounts_name;?></th>
				</tr>
				<?php 
					$current_month_accounts_category_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_month_accounts_category_income_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_income_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($current_month_accounts_category_income as $current_month_accounts_category_income_row)
					{
					$current_month_accounts_category_income_balance = $current_month_accounts_category_income_row->current_month_accounts_category_income_balance;
					$total_current_month_accounts_category_income  += $current_month_accounts_category_income_balance;
					}
					$current_last_month_accounts_category_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_last_month_accounts_category_income_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_last_month_start_date.'" and "'.$current_last_month_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_income_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($current_last_month_accounts_category_income as $current_last_month_accounts_category_income_row)
					{
					$current_last_month_accounts_category_income_balance = $current_last_month_accounts_category_income_row->current_last_month_accounts_category_income_balance;
					$total_current_last_month_accounts_category_income  += $current_last_month_accounts_category_income_balance;
					}
					$current_previous_month_accounts_category_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_previous_month_accounts_category_income_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_previous_month_start_date.'" and "'.$current_previous_month_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_income_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($current_previous_month_accounts_category_income as $current_previous_month_accounts_category_income_row)
					{
					$current_previous_month_accounts_category_income_balance = $current_previous_month_accounts_category_income_row->current_previous_month_accounts_category_income_balance;
					$total_current_previous_month_accounts_category_income  += $current_previous_month_accounts_category_income_balance;
					}
					$quarterly_accounts_category_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS quarterly_accounts_category_income_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$quarterly_start_date.'" and "'.$quarterly_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_income_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($quarterly_accounts_category_income as $quarterly_accounts_category_income_row)
					{
					$quarterly_accounts_category_income_balance = $quarterly_accounts_category_income_row->quarterly_accounts_category_income_balance;
					$total_quarterly_accounts_category_income  += $quarterly_accounts_category_income_balance;
					}
					
					$last_month_accounts_category_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS last_month_accounts_category_income_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$last_month_start_date.'" and "'.$last_month_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_income_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($last_month_accounts_category_income as $last_month_accounts_category_income_row)
					{
					$last_month_accounts_category_income_balance = $last_month_accounts_category_income_row->last_month_accounts_category_income_balance;
					$total_last_month_accounts_category_income  += $last_month_accounts_category_income_balance;
					}
					
					
					$current_year_accounts_category_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_year_accounts_category_income_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_year_start_date.'" and "'.$current_year_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_income_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($current_year_accounts_category_income as $current_year_accounts_category_income_row)
					{
					$current_year_accounts_category_income_balance = $current_year_accounts_category_income_row->current_year_accounts_category_income_balance;
					$total_current_year_accounts_category_income  += $current_year_accounts_category_income_balance;
					}
					
					$last_year_accounts_category_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS last_year_accounts_category_income_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_income_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($last_year_accounts_category_income as $last_year_accounts_category_income_row)
					{
					$last_year_accounts_category_income_balance = $last_year_accounts_category_income_row->last_year_accounts_category_income_balance;
					$total_last_year_accounts_category_income  += $last_year_accounts_category_income_balance;
					}
					
					$total_current_month_control_group_income = 0;
					$total_current_last_month_control_group_income = 0;
					$total_current_previous_month_control_group_income = 0;
					$total_quarterly_control_group_income = 0; 
					$total_last_month_control_group_income = 0;
					$total_previous_month_control_group_income = 0;
					$total_current_year_control_group_income = 0;
					$total_last_year_control_group_income = 0;
					$total_previous_year_control_group_income = 0;
				
					$control_group_income = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_category_income_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
					foreach ($control_group_income as $control_group_income_row) 
					{?> 
					<tr>
						<td></td>
						<td class="text-left"><?= $control_group_income_row->chart_of_accounts_code;?> - <?= $control_group_income_row->chart_of_accounts_name;?></th>
					<?php 
						$current_month_control_group_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_month_control_group_income_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
						->where('accounts_details_control_group', $control_group_income_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($current_month_control_group_income as $current_month_control_group_income_row)
						{
						$current_month_control_group_income_balance = $current_month_control_group_income_row->current_month_control_group_income_balance;
						$total_current_month_control_group_income  += $current_month_control_group_income_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($current_month_control_group_income_balance >0) { echo' '.number_format($current_month_control_group_income_balance, 2 . '').' ';} else if($current_month_control_group_income_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_month_control_group_income_balance), 2 . '').') ';} ?></td>
						<?php }
						$current_last_month_control_group_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_last_month_control_group_income_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_last_month_start_date.'" and "'.$current_last_month_end_date.'"')
						->where('accounts_details_control_group', $control_group_income_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($current_last_month_control_group_income as $current_last_month_control_group_income_row)
						{
						$current_last_month_control_group_income_balance = $current_last_month_control_group_income_row->current_last_month_control_group_income_balance;
						$total_current_last_month_control_group_income  += $current_last_month_control_group_income_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($current_last_month_control_group_income_balance >0) { echo' '.number_format($current_last_month_control_group_income_balance, 2 . '').' ';} else if($current_last_month_control_group_income_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_last_month_control_group_income_balance), 2 . '').') ';} ?></td>
						<?php }
						$current_previous_month_control_group_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_previous_month_control_group_income_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_previous_month_start_date.'" and "'.$current_previous_month_end_date.'"')
						->where('accounts_details_control_group', $control_group_income_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($current_previous_month_control_group_income as $current_previous_month_control_group_income_row)
						{
						$current_previous_month_control_group_income_balance = $current_previous_month_control_group_income_row->current_previous_month_control_group_income_balance;
						$total_current_previous_month_control_group_income  += $current_previous_month_control_group_income_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($current_previous_month_control_group_income_balance >0) { echo' '.number_format($current_previous_month_control_group_income_balance, 2 . '').' ';} else if($current_previous_month_control_group_income_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_previous_month_control_group_income_balance), 2 . '').') ';} ?></td>
						<?php }
						$quarterly_control_group_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS quarterly_control_group_income_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$quarterly_start_date.'" and "'.$quarterly_end_date.'"')
						->where('accounts_details_control_group', $control_group_income_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($quarterly_control_group_income as $quarterly_control_group_income_row)
						{
						$quarterly_control_group_income_balance = $quarterly_control_group_income_row->quarterly_control_group_income_balance;
						$total_quarterly_control_group_income  += $quarterly_control_group_income_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($quarterly_control_group_income_balance >0) { echo' '.number_format($quarterly_control_group_income_balance, 2 . '').' ';} else if($quarterly_control_group_income_balance ==0) {echo '-';} else { echo' ('.number_format(abs($quarterly_control_group_income_balance), 2 . '').') ';} ?></td>
						<?php } 
						
						$current_year_control_group_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_year_control_group_income_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_year_start_date.'" and "'.$current_year_end_date.'"')
						->where('accounts_details_control_group', $control_group_income_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($current_year_control_group_income as $current_year_control_group_income_row)
						{
						$current_year_control_group_income_balance = $current_year_control_group_income_row->current_year_control_group_income_balance;
						$total_current_year_control_group_income  += $current_year_control_group_income_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($current_year_control_group_income_balance >0) { echo' '.number_format($current_year_control_group_income_balance, 2 . '').' ';} else if($current_year_control_group_income_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_year_control_group_income_balance), 2 . '').') ';} ?></td>
						<?php }
						
						$last_year_control_group_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS last_year_control_group_income_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
						->where('accounts_details_control_group', $control_group_income_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($last_year_control_group_income as $last_year_control_group_income_row)
						{
						$last_year_control_group_income_balance = $last_year_control_group_income_row->last_year_control_group_income_balance;
						$total_last_year_control_group_income  += $last_year_control_group_income_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($last_year_control_group_income_balance >0) { echo' '.number_format($last_year_control_group_income_balance, 2 . '').' ';} else if($last_year_control_group_income_balance ==0) {echo '-';} else { echo' ('.number_format(abs($last_year_control_group_income_balance), 2 . '').') ';} ?></td>
						<?php }?>
					</tr>
					<?php }?>
					<tr class="text-uppercase">
						<th class="text-center" colspan="2"><?= $this->lang->line('total');?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_month_control_group_income >0) { echo' '.number_format($total_current_month_control_group_income, 2 . '').' ';} else if($total_current_month_control_group_income ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_month_control_group_income), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_last_month_control_group_income >0) { echo' '.number_format($total_current_last_month_control_group_income, 2 . '').' ';} else if($total_current_last_month_control_group_income ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_last_month_control_group_income), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_previous_month_control_group_income >0) { echo' '.number_format($total_current_previous_month_control_group_income, 2 . '').' ';} else if($total_current_previous_month_control_group_income ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_previous_month_control_group_income), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_quarterly_control_group_income >0) { echo' '.number_format($total_quarterly_control_group_income, 2 . '').' ';} else if($total_quarterly_control_group_income ==0) {echo '-';} else { echo' ('.number_format(abs($total_quarterly_control_group_income), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th> 
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_year_control_group_income >0) { echo' '.number_format($total_current_year_control_group_income, 2 . '').' ';} else if($total_current_year_control_group_income ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_year_control_group_income), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_last_year_control_group_income >0) { echo' '.number_format($total_last_year_control_group_income, 2 . '').' ';} else if($total_last_year_control_group_income ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_year_control_group_income), 2 . '').') ';} ?></th>
					</tr>
					
					<tr>
						<th class="text-center" width="3%">&nbsp;</th>
						<th class="text-left text-uppercase" colspan="13"></th>
					</tr>
					<?php 
					
					$serial_income = 0;
					$control_group_income = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_category_income_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
					foreach ($control_group_income as $control_group_income_row) 
					{?>
					<tr>
						<th class="text-left" width="3%">
							<a class="btn-outline-danger  rounded-pill" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="action_view_model('<?= base_url("accounts/income_expenditure_note_view");?>')"><?= number_format($serial,0 . '');?>.<?= number_format(++$serial_income,1 . '');?></a>
						</th>
						<th class="text-left text-uppercase" colspan="13"><?= $control_group_income_row->chart_of_accounts_code;?> - <?= $control_group_income_row->chart_of_accounts_name;?></th>
					</tr>
					<?php 	
						
					$total_current_month_general_ledger_income = 0;
					$total_current_last_month_general_ledger_income = 0;
					$total_current_previous_month_general_ledger_income = 0;
					$total_quarterly_general_ledger_income = 0;
					$total_last_month_general_ledger_income = 0;
					$total_previous_month_general_ledger_income = 0;
					$total_current_year_general_ledger_income = 0;
					$total_last_year_general_ledger_income = 0;
					$total_previous_year_general_ledger_income = 0;
					
					$general_ledger_income = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $control_group_income_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
					foreach ($general_ledger_income as $general_ledger_income_row) 
					{?>
					<tr>
						<td></td>
						<td class="text-left"><?= $general_ledger_income_row->chart_of_accounts_code;?> - <?= $general_ledger_income_row->chart_of_accounts_name;?></th>
						<?php 
						$current_month_general_ledger_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_month_general_ledger_income_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
						->where('accounts_details_general_ledger', $general_ledger_income_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($current_month_general_ledger_income as $current_month_general_ledger_income_row)
						{
						$current_month_general_ledger_income_balance = $current_month_general_ledger_income_row->current_month_general_ledger_income_balance;
						$total_current_month_general_ledger_income  += $current_month_general_ledger_income_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($current_month_general_ledger_income_balance >0) { echo' '.number_format($current_month_general_ledger_income_balance, 2 . '').' ';} else if($current_month_general_ledger_income_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_month_general_ledger_income_balance), 2 . '').') ';} ?></td>
						<?php }
						
						$current_last_month_general_ledger_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_last_month_general_ledger_income_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_last_month_start_date.'" and "'.$current_last_month_end_date.'"')
						->where('accounts_details_general_ledger', $general_ledger_income_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($current_last_month_general_ledger_income as $current_last_month_general_ledger_income_row)
						{
						$current_last_month_general_ledger_income_balance = $current_last_month_general_ledger_income_row->current_last_month_general_ledger_income_balance;
						$total_current_last_month_general_ledger_income  += $current_last_month_general_ledger_income_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($current_last_month_general_ledger_income_balance >0) { echo' '.number_format($current_last_month_general_ledger_income_balance, 2 . '').' ';} else if($current_last_month_general_ledger_income_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_last_month_general_ledger_income_balance), 2 . '').') ';} ?></td>
						<?php }
						
						$current_previous_month_general_ledger_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_previous_month_general_ledger_income_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_previous_month_start_date.'" and "'.$current_previous_month_end_date.'"')
						->where('accounts_details_general_ledger', $general_ledger_income_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($current_previous_month_general_ledger_income as $current_previous_month_general_ledger_income_row)
						{
						$current_previous_month_general_ledger_income_balance = $current_previous_month_general_ledger_income_row->current_previous_month_general_ledger_income_balance;
						$total_current_previous_month_general_ledger_income  += $current_previous_month_general_ledger_income_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($current_previous_month_general_ledger_income_balance >0) { echo' '.number_format($current_previous_month_general_ledger_income_balance, 2 . '').' ';} else if($current_previous_month_general_ledger_income_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_previous_month_general_ledger_income_balance), 2 . '').') ';} ?></td>
						<?php }
						
						$quarterly_general_ledger_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS quarterly_general_ledger_income_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$quarterly_start_date.'" and "'.$quarterly_end_date.'"')
						->where('accounts_details_general_ledger', $general_ledger_income_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($quarterly_general_ledger_income as $quarterly_general_ledger_income_row)
						{
						$quarterly_general_ledger_income_balance = $quarterly_general_ledger_income_row->quarterly_general_ledger_income_balance;
						$total_quarterly_general_ledger_income  += $quarterly_general_ledger_income_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($quarterly_general_ledger_income_balance >0) { echo' '.number_format($quarterly_general_ledger_income_balance, 2 . '').' ';} else if($quarterly_general_ledger_income_balance ==0) {echo '-';} else { echo' ('.number_format(abs($quarterly_general_ledger_income_balance), 2 . '').') ';} ?></td>
						<?php }
						
						$current_year_general_ledger_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_year_general_ledger_income_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_year_start_date.'" and "'.$current_year_end_date.'"')
						->where('accounts_details_general_ledger', $general_ledger_income_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($current_year_general_ledger_income as $current_year_general_ledger_income_row)
						{
						$current_year_general_ledger_income_balance = $current_year_general_ledger_income_row->current_year_general_ledger_income_balance;
						$total_current_year_general_ledger_income  += $current_year_general_ledger_income_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($current_year_general_ledger_income_balance >0) { echo' '.number_format($current_year_general_ledger_income_balance, 2 . '').' ';} else if($current_year_general_ledger_income_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_year_general_ledger_income_balance), 2 . '').') ';} ?></td>
						<?php }
						
						$last_year_general_ledger_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS last_year_general_ledger_income_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
						->where('accounts_details_general_ledger', $general_ledger_income_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($last_year_general_ledger_income as $last_year_general_ledger_income_row)
						{
						$last_year_general_ledger_income_balance = $last_year_general_ledger_income_row->last_year_general_ledger_income_balance;
						$total_last_year_general_ledger_income  += $last_year_general_ledger_income_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($last_year_general_ledger_income_balance >0) { echo' '.number_format($last_year_general_ledger_income_balance, 2 . '').' ';} else if($last_year_general_ledger_income_balance ==0) {echo '-';} else { echo' ('.number_format(abs($last_year_general_ledger_income_balance), 2 . '').') ';} ?></td>
						<?php }?>
					</tr>
					<?php }?>
					
					<tr class="text-uppercase">
						<th class="text-center" colspan="2"><?= $this->lang->line('total');?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_month_general_ledger_income >0) { echo' '.number_format($total_current_month_general_ledger_income, 2 . '').' ';} else if($total_current_month_general_ledger_income ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_month_general_ledger_income), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_last_month_general_ledger_income >0) { echo' '.number_format($total_current_last_month_general_ledger_income, 2 . '').' ';} else if($total_current_last_month_general_ledger_income ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_last_month_general_ledger_income), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_previous_month_general_ledger_income >0) { echo' '.number_format($total_current_previous_month_general_ledger_income, 2 . '').' ';} else if($total_current_previous_month_general_ledger_income ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_previous_month_general_ledger_income), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_quarterly_general_ledger_income >0) { echo' '.number_format($total_quarterly_general_ledger_income, 2 . '').' ';} else if($total_quarterly_general_ledger_income ==0) {echo '-';} else { echo' ('.number_format(abs($total_quarterly_general_ledger_income), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_year_general_ledger_income >0) { echo' '.number_format($total_current_year_general_ledger_income, 2 . '').' ';} else if($total_current_year_general_ledger_income ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_year_general_ledger_income), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_last_year_general_ledger_income >0) { echo' '.number_format($total_last_year_general_ledger_income, 2 . '').' ';} else if($total_last_year_general_ledger_income ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_year_general_ledger_income), 2 . '').') ';} ?></th>
					</tr>
					
					<tr>
						<th class="text-center" width="3%">&nbsp;</th>
						<th class="text-left text-uppercase" colspan="13"></th>
					</tr>
					<?php
					$serial_income_general_ledger = 0;
					$general_ledger_income = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $control_group_income_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
					foreach ($general_ledger_income as $general_ledger_income_row) 
					{?>
					<tr>
						<th class="text-left" width="3%">
							<a class="btn-outline-danger  rounded-pill" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="action_view_model('<?= base_url("accounts/income_expenditure_note_view");?>')"><?= number_format($serial,0 . '');?>.<?= number_format($serial_income,0 . '');?>.<?= ++$serial_income_general_ledger;?></a>
						</th>
						<th class="text-left text-uppercase" colspan="13"><?= $general_ledger_income_row->chart_of_accounts_code;?> - <?= $general_ledger_income_row->chart_of_accounts_name;?></th>
					</tr>
					<?php
					$total_current_month_subsidiary_ledger_income = 0;
					$total_current_last_month_subsidiary_ledger_income = 0;
					$total_current_previous_month_subsidiary_ledger_income = 0;
					$total_quarterly_subsidiary_ledger_income = 0;
					$total_last_month_subsidiary_ledger_income = 0;
					$total_previous_month_subsidiary_ledger_income = 0;
					$total_current_year_subsidiary_ledger_income = 0;
					$total_last_year_subsidiary_ledger_income = 0;
					$total_previous_year_subsidiary_ledger_income = 0;
					
					$subsidiary_ledger_income = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $general_ledger_income_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
					foreach ($subsidiary_ledger_income as $subsidiary_ledger_income_row) 
					{?>
					<tr>
						<td></td>
						<td class="text-left"><?= $subsidiary_ledger_income_row->chart_of_accounts_code;?> - <?= $subsidiary_ledger_income_row->chart_of_accounts_name;?></th>
						<?php
						$current_month_subsidiary_ledger_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_month_subsidiary_ledger_income_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
						->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_income_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($current_month_subsidiary_ledger_income as $current_month_subsidiary_ledger_income_row)
						{
						$current_month_subsidiary_ledger_income_balance = $current_month_subsidiary_ledger_income_row->current_month_subsidiary_ledger_income_balance;
						$total_current_month_subsidiary_ledger_income  += $current_month_subsidiary_ledger_income_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($current_month_subsidiary_ledger_income_balance >0) { echo' '.number_format($current_month_subsidiary_ledger_income_balance, 2 . '').' ';} else if($current_month_subsidiary_ledger_income_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_month_subsidiary_ledger_income_balance), 2 . '').') ';} ?></td>
						<?php }
						$current_last_month_subsidiary_ledger_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_last_month_subsidiary_ledger_income_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_last_month_start_date.'" and "'.$current_last_month_end_date.'"')
						->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_income_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($current_last_month_subsidiary_ledger_income as $current_last_month_subsidiary_ledger_income_row)
						{
						$current_last_month_subsidiary_ledger_income_balance = $current_last_month_subsidiary_ledger_income_row->current_last_month_subsidiary_ledger_income_balance;
						$total_current_last_month_subsidiary_ledger_income  += $current_last_month_subsidiary_ledger_income_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($current_last_month_subsidiary_ledger_income_balance >0) { echo' '.number_format($current_last_month_subsidiary_ledger_income_balance, 2 . '').' ';} else if($current_last_month_subsidiary_ledger_income_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_last_month_subsidiary_ledger_income_balance), 2 . '').') ';} ?></td>
						<?php }
						$current_previous_month_subsidiary_ledger_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_previous_month_subsidiary_ledger_income_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_previous_month_start_date.'" and "'.$current_previous_month_end_date.'"')
						->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_income_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($current_previous_month_subsidiary_ledger_income as $current_previous_month_subsidiary_ledger_income_row)
						{
						$current_previous_month_subsidiary_ledger_income_balance = $current_previous_month_subsidiary_ledger_income_row->current_previous_month_subsidiary_ledger_income_balance;
						$total_current_previous_month_subsidiary_ledger_income  += $current_previous_month_subsidiary_ledger_income_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($current_previous_month_subsidiary_ledger_income_balance >0) { echo' '.number_format($current_previous_month_subsidiary_ledger_income_balance, 2 . '').' ';} else if($current_previous_month_subsidiary_ledger_income_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_previous_month_subsidiary_ledger_income_balance), 2 . '').') ';} ?></td>
						<?php }
						$quarterly_subsidiary_ledger_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS quarterly_subsidiary_ledger_income_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$quarterly_start_date.'" and "'.$quarterly_end_date.'"')
						->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_income_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($quarterly_subsidiary_ledger_income as $quarterly_subsidiary_ledger_income_row)
						{
						$quarterly_subsidiary_ledger_income_balance = $quarterly_subsidiary_ledger_income_row->quarterly_subsidiary_ledger_income_balance;
						$total_quarterly_subsidiary_ledger_income  += $quarterly_subsidiary_ledger_income_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($quarterly_subsidiary_ledger_income_balance >0) { echo' '.number_format($quarterly_subsidiary_ledger_income_balance, 2 . '').' ';} else if($quarterly_subsidiary_ledger_income_balance ==0) {echo '-';} else { echo' ('.number_format(abs($quarterly_subsidiary_ledger_income_balance), 2 . '').') ';} ?></td>
						<?php }
						
						$current_year_subsidiary_ledger_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_year_subsidiary_ledger_income_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_year_start_date.'" and "'.$current_year_end_date.'"')
						->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_income_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($current_year_subsidiary_ledger_income as $current_year_subsidiary_ledger_income_row)
						{
						$current_year_subsidiary_ledger_income_balance = $current_year_subsidiary_ledger_income_row->current_year_subsidiary_ledger_income_balance;
						$total_current_year_subsidiary_ledger_income  += $current_year_subsidiary_ledger_income_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($current_year_subsidiary_ledger_income_balance >0) { echo' '.number_format($current_year_subsidiary_ledger_income_balance, 2 . '').' ';} else if($current_year_subsidiary_ledger_income_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_year_subsidiary_ledger_income_balance), 2 . '').') ';} ?></td>
						<?php }
						
						$last_year_subsidiary_ledger_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS last_year_subsidiary_ledger_income_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
						->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_income_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($last_year_subsidiary_ledger_income as $last_year_subsidiary_ledger_income_row)
						{
						$last_year_subsidiary_ledger_income_balance = $last_year_subsidiary_ledger_income_row->last_year_subsidiary_ledger_income_balance;
						$total_last_year_subsidiary_ledger_income  += $last_year_subsidiary_ledger_income_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($last_year_subsidiary_ledger_income_balance >0) { echo' '.number_format($last_year_subsidiary_ledger_income_balance, 2 . '').' ';} else if($last_year_subsidiary_ledger_income_balance ==0) {echo '-';} else { echo' ('.number_format(abs($last_year_subsidiary_ledger_income_balance), 2 . '').') ';} ?></td>
						<?php }?>
					</tr>	
					<?php  }?>
					<tr class="text-uppercase">
						<th class="text-center" colspan="2"><?= $this->lang->line('total');?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_month_subsidiary_ledger_income >0) { echo' '.number_format($total_current_month_subsidiary_ledger_income, 2 . '').' ';} else if($total_current_month_subsidiary_ledger_income ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_month_subsidiary_ledger_income), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_last_month_subsidiary_ledger_income >0) { echo' '.number_format($total_current_last_month_subsidiary_ledger_income, 2 . '').' ';} else if($total_current_last_month_subsidiary_ledger_income ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_last_month_subsidiary_ledger_income), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_previous_month_subsidiary_ledger_income >0) { echo' '.number_format($total_current_previous_month_subsidiary_ledger_income, 2 . '').' ';} else if($total_current_previous_month_subsidiary_ledger_income ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_previous_month_subsidiary_ledger_income), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_quarterly_subsidiary_ledger_income >0) { echo' '.number_format($total_quarterly_subsidiary_ledger_income, 2 . '').' ';} else if($total_quarterly_subsidiary_ledger_income ==0) {echo '-';} else { echo' ('.number_format(abs($total_quarterly_subsidiary_ledger_income), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th> 
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_year_subsidiary_ledger_income >0) { echo' '.number_format($total_current_year_subsidiary_ledger_income, 2 . '').' ';} else if($total_current_year_subsidiary_ledger_income ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_year_subsidiary_ledger_income), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_last_year_subsidiary_ledger_income >0) { echo' '.number_format($total_last_year_subsidiary_ledger_income, 2 . '').' ';} else if($total_last_year_subsidiary_ledger_income ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_year_subsidiary_ledger_income), 2 . '').') ';} ?></th>
					</tr>
					
					<tr>
						<th class="text-center" width="3%">&nbsp;</th>
						<th class="text-left text-uppercase" colspan="13"></th>
					</tr> 
					<?php }
					} 
				} 
			}
			
			
			// Expenditure ....
			$serial = $serial;
			$accounts_type_expenditure = $this->db->select("*") ->from('accounts_type') ->where('accounts_type_id', 400000) ->order_by('accounts_type_code', 'ASC') ->get()->result();
			foreach ($accounts_type_expenditure as $accounts_type_expenditure_row)
			{
				  
					$total_current_month_accounts_category_expenditure 			= 0;
				$total_current_last_month_accounts_category_expenditure 		= 0;
				$total_current_previous_month_accounts_category_expenditure 	= 0;
				$total_quarterly_accounts_category_expenditure 				= 0;
				$total_last_month_accounts_category_expenditure 				= 0;
				$total_previous_month_accounts_category_expenditure 			= 0;
				$total_current_year_accounts_category_expenditure 			= 0;
				$total_last_year_accounts_category_expenditure 				= 0;
				$total_previous_year_accounts_category_expenditure 			= 0;
				
				$accounts_category_expenditure = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_type_expenditure_row->accounts_type_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
				foreach ($accounts_category_expenditure as $accounts_category_expenditure_row) 
				{?>
				<tr>
					<th class="text-left" width="3%">
						<a class="btn-outline-danger  rounded-pill" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="action_view_model('<?= base_url("accounts/expenditure_expenditure_note_view");?>')"><?= number_format(++$serial,2 . '');?></a>
					</th>
					<th class="text-left text-uppercase" colspan="13"><?= $accounts_category_expenditure_row->chart_of_accounts_code;?> - <?= $accounts_category_expenditure_row->chart_of_accounts_name;?></th>
				</tr>
				<?php 
					$current_month_accounts_category_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_month_accounts_category_expenditure_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($current_month_accounts_category_expenditure as $current_month_accounts_category_expenditure_row)
					{
					$current_month_accounts_category_expenditure_balance = $current_month_accounts_category_expenditure_row->current_month_accounts_category_expenditure_balance;
					$total_current_month_accounts_category_expenditure  += $current_month_accounts_category_expenditure_balance;
					}
					$current_last_month_accounts_category_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_last_month_accounts_category_expenditure_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_last_month_start_date.'" and "'.$current_last_month_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($current_last_month_accounts_category_expenditure as $current_last_month_accounts_category_expenditure_row)
					{
					$current_last_month_accounts_category_expenditure_balance = $current_last_month_accounts_category_expenditure_row->current_last_month_accounts_category_expenditure_balance;
					$total_current_last_month_accounts_category_expenditure  += $current_last_month_accounts_category_expenditure_balance;
					}
					$current_previous_month_accounts_category_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_previous_month_accounts_category_expenditure_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_previous_month_start_date.'" and "'.$current_previous_month_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($current_previous_month_accounts_category_expenditure as $current_previous_month_accounts_category_expenditure_row)
					{
					$current_previous_month_accounts_category_expenditure_balance = $current_previous_month_accounts_category_expenditure_row->current_previous_month_accounts_category_expenditure_balance;
					$total_current_previous_month_accounts_category_expenditure  += $current_previous_month_accounts_category_expenditure_balance;
					}
					$quarterly_accounts_category_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS quarterly_accounts_category_expenditure_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$quarterly_start_date.'" and "'.$quarterly_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($quarterly_accounts_category_expenditure as $quarterly_accounts_category_expenditure_row)
					{
					$quarterly_accounts_category_expenditure_balance = $quarterly_accounts_category_expenditure_row->quarterly_accounts_category_expenditure_balance;
					$total_quarterly_accounts_category_expenditure  += $quarterly_accounts_category_expenditure_balance;
					}
					
					$last_month_accounts_category_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS last_month_accounts_category_expenditure_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$last_month_start_date.'" and "'.$last_month_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($last_month_accounts_category_expenditure as $last_month_accounts_category_expenditure_row)
					{
					$last_month_accounts_category_expenditure_balance = $last_month_accounts_category_expenditure_row->last_month_accounts_category_expenditure_balance;
					$total_last_month_accounts_category_expenditure  += $last_month_accounts_category_expenditure_balance;
					}
					
					
					$current_year_accounts_category_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_year_accounts_category_expenditure_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_year_start_date.'" and "'.$current_year_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($current_year_accounts_category_expenditure as $current_year_accounts_category_expenditure_row)
					{
					$current_year_accounts_category_expenditure_balance = $current_year_accounts_category_expenditure_row->current_year_accounts_category_expenditure_balance;
					$total_current_year_accounts_category_expenditure  += $current_year_accounts_category_expenditure_balance;
					}
					
					$last_year_accounts_category_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS last_year_accounts_category_expenditure_balance") 
					->from('accounts_details')
					->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
					->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($last_year_accounts_category_expenditure as $last_year_accounts_category_expenditure_row)
					{
					$last_year_accounts_category_expenditure_balance = $last_year_accounts_category_expenditure_row->last_year_accounts_category_expenditure_balance;
					$total_last_year_accounts_category_expenditure  += $last_year_accounts_category_expenditure_balance;
					}
					
					$total_current_month_control_group_expenditure = 0;
					$total_current_last_month_control_group_expenditure = 0;
					$total_current_previous_month_control_group_expenditure = 0;
					$total_quarterly_control_group_expenditure = 0; 
					$total_last_month_control_group_expenditure = 0;
					$total_previous_month_control_group_expenditure = 0;
					$total_current_year_control_group_expenditure = 0;
					$total_last_year_control_group_expenditure = 0;
					$total_previous_year_control_group_expenditure = 0;
				
					$control_group_expenditure = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
					foreach ($control_group_expenditure as $control_group_expenditure_row) 
					{?> 
					<tr>
						<td></td>
						<td class="text-left"><?= $control_group_expenditure_row->chart_of_accounts_code;?> - <?= $control_group_expenditure_row->chart_of_accounts_name;?></th>
					<?php 
						$current_month_control_group_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_month_control_group_expenditure_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
						->where('accounts_details_control_group', $control_group_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($current_month_control_group_expenditure as $current_month_control_group_expenditure_row)
						{
						$current_month_control_group_expenditure_balance = $current_month_control_group_expenditure_row->current_month_control_group_expenditure_balance;
						$total_current_month_control_group_expenditure  += $current_month_control_group_expenditure_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($current_month_control_group_expenditure_balance >0) { echo' '.number_format($current_month_control_group_expenditure_balance, 2 . '').' ';} else if($current_month_control_group_expenditure_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_month_control_group_expenditure_balance), 2 . '').') ';} ?></td>
						<?php }
						$current_last_month_control_group_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_last_month_control_group_expenditure_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_last_month_start_date.'" and "'.$current_last_month_end_date.'"')
						->where('accounts_details_control_group', $control_group_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($current_last_month_control_group_expenditure as $current_last_month_control_group_expenditure_row)
						{
						$current_last_month_control_group_expenditure_balance = $current_last_month_control_group_expenditure_row->current_last_month_control_group_expenditure_balance;
						$total_current_last_month_control_group_expenditure  += $current_last_month_control_group_expenditure_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($current_last_month_control_group_expenditure_balance >0) { echo' '.number_format($current_last_month_control_group_expenditure_balance, 2 . '').' ';} else if($current_last_month_control_group_expenditure_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_last_month_control_group_expenditure_balance), 2 . '').') ';} ?></td>
						<?php }
						$current_previous_month_control_group_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_previous_month_control_group_expenditure_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_previous_month_start_date.'" and "'.$current_previous_month_end_date.'"')
						->where('accounts_details_control_group', $control_group_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($current_previous_month_control_group_expenditure as $current_previous_month_control_group_expenditure_row)
						{
						$current_previous_month_control_group_expenditure_balance = $current_previous_month_control_group_expenditure_row->current_previous_month_control_group_expenditure_balance;
						$total_current_previous_month_control_group_expenditure  += $current_previous_month_control_group_expenditure_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($current_previous_month_control_group_expenditure_balance >0) { echo' '.number_format($current_previous_month_control_group_expenditure_balance, 2 . '').' ';} else if($current_previous_month_control_group_expenditure_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_previous_month_control_group_expenditure_balance), 2 . '').') ';} ?></td>
						<?php }
						$quarterly_control_group_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS quarterly_control_group_expenditure_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$quarterly_start_date.'" and "'.$quarterly_end_date.'"')
						->where('accounts_details_control_group', $control_group_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($quarterly_control_group_expenditure as $quarterly_control_group_expenditure_row)
						{
						$quarterly_control_group_expenditure_balance = $quarterly_control_group_expenditure_row->quarterly_control_group_expenditure_balance;
						$total_quarterly_control_group_expenditure  += $quarterly_control_group_expenditure_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($quarterly_control_group_expenditure_balance >0) { echo' '.number_format($quarterly_control_group_expenditure_balance, 2 . '').' ';} else if($quarterly_control_group_expenditure_balance ==0) {echo '-';} else { echo' ('.number_format(abs($quarterly_control_group_expenditure_balance), 2 . '').') ';} ?></td>
						<?php } 
						
						$current_year_control_group_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_year_control_group_expenditure_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_year_start_date.'" and "'.$current_year_end_date.'"')
						->where('accounts_details_control_group', $control_group_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($current_year_control_group_expenditure as $current_year_control_group_expenditure_row)
						{
						$current_year_control_group_expenditure_balance = $current_year_control_group_expenditure_row->current_year_control_group_expenditure_balance;
						$total_current_year_control_group_expenditure  += $current_year_control_group_expenditure_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($current_year_control_group_expenditure_balance >0) { echo' '.number_format($current_year_control_group_expenditure_balance, 2 . '').' ';} else if($current_year_control_group_expenditure_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_year_control_group_expenditure_balance), 2 . '').') ';} ?></td>
						<?php }
						
						$last_year_control_group_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS last_year_control_group_expenditure_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
						->where('accounts_details_control_group', $control_group_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($last_year_control_group_expenditure as $last_year_control_group_expenditure_row)
						{
						$last_year_control_group_expenditure_balance = $last_year_control_group_expenditure_row->last_year_control_group_expenditure_balance;
						$total_last_year_control_group_expenditure  += $last_year_control_group_expenditure_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($last_year_control_group_expenditure_balance >0) { echo' '.number_format($last_year_control_group_expenditure_balance, 2 . '').' ';} else if($last_year_control_group_expenditure_balance ==0) {echo '-';} else { echo' ('.number_format(abs($last_year_control_group_expenditure_balance), 2 . '').') ';} ?></td>
						<?php }?>
					</tr>
					<?php }?>
					<tr class="text-uppercase">
						<th class="text-center" colspan="2"><?= $this->lang->line('total');?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_month_control_group_expenditure >0) { echo' '.number_format($total_current_month_control_group_expenditure, 2 . '').' ';} else if($total_current_month_control_group_expenditure ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_month_control_group_expenditure), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_last_month_control_group_expenditure >0) { echo' '.number_format($total_current_last_month_control_group_expenditure, 2 . '').' ';} else if($total_current_last_month_control_group_expenditure ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_last_month_control_group_expenditure), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_previous_month_control_group_expenditure >0) { echo' '.number_format($total_current_previous_month_control_group_expenditure, 2 . '').' ';} else if($total_current_previous_month_control_group_expenditure ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_previous_month_control_group_expenditure), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_quarterly_control_group_expenditure >0) { echo' '.number_format($total_quarterly_control_group_expenditure, 2 . '').' ';} else if($total_quarterly_control_group_expenditure ==0) {echo '-';} else { echo' ('.number_format(abs($total_quarterly_control_group_expenditure), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th> 
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_year_control_group_expenditure >0) { echo' '.number_format($total_current_year_control_group_expenditure, 2 . '').' ';} else if($total_current_year_control_group_expenditure ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_year_control_group_expenditure), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_last_year_control_group_expenditure >0) { echo' '.number_format($total_last_year_control_group_expenditure, 2 . '').' ';} else if($total_last_year_control_group_expenditure ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_year_control_group_expenditure), 2 . '').') ';} ?></th>
					</tr>
					
					<tr>
						<th class="text-center" width="3%">&nbsp;</th>
						<th class="text-left text-uppercase" colspan="13"></th>
					</tr>
					<?php 
					
					$serial_expenditure = 0;
					$control_group_expenditure = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
					foreach ($control_group_expenditure as $control_group_expenditure_row) 
					{?>
					<tr>
						<th class="text-left" width="3%">
							<a class="btn-outline-danger  rounded-pill" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="action_view_model('<?= base_url("accounts/expenditure_expenditure_note_view");?>')"><?= number_format($serial,0 . '');?>.<?= number_format(++$serial_expenditure,1 . '');?></a>
						</th>
						<th class="text-left text-uppercase" colspan="13"><?= $control_group_expenditure_row->chart_of_accounts_code;?> - <?= $control_group_expenditure_row->chart_of_accounts_name;?></th>
					</tr>
					<?php 	
						
					$total_current_month_general_ledger_expenditure = 0;
					$total_current_last_month_general_ledger_expenditure = 0;
					$total_current_previous_month_general_ledger_expenditure = 0;
					$total_quarterly_general_ledger_expenditure = 0;
					$total_last_month_general_ledger_expenditure = 0;
					$total_previous_month_general_ledger_expenditure = 0;
					$total_current_year_general_ledger_expenditure = 0;
					$total_last_year_general_ledger_expenditure = 0;
					$total_previous_year_general_ledger_expenditure = 0;
					
					$general_ledger_expenditure = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $control_group_expenditure_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
					foreach ($general_ledger_expenditure as $general_ledger_expenditure_row) 
					{?>
					<tr>
						<td></td>
						<td class="text-left"><?= $general_ledger_expenditure_row->chart_of_accounts_code;?> - <?= $general_ledger_expenditure_row->chart_of_accounts_name;?></th>
						<?php 
						$current_month_general_ledger_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_month_general_ledger_expenditure_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
						->where('accounts_details_general_ledger', $general_ledger_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($current_month_general_ledger_expenditure as $current_month_general_ledger_expenditure_row)
						{
						$current_month_general_ledger_expenditure_balance = $current_month_general_ledger_expenditure_row->current_month_general_ledger_expenditure_balance;
						$total_current_month_general_ledger_expenditure  += $current_month_general_ledger_expenditure_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($current_month_general_ledger_expenditure_balance >0) { echo' '.number_format($current_month_general_ledger_expenditure_balance, 2 . '').' ';} else if($current_month_general_ledger_expenditure_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_month_general_ledger_expenditure_balance), 2 . '').') ';} ?></td>
						<?php }
						
						$current_last_month_general_ledger_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_last_month_general_ledger_expenditure_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_last_month_start_date.'" and "'.$current_last_month_end_date.'"')
						->where('accounts_details_general_ledger', $general_ledger_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($current_last_month_general_ledger_expenditure as $current_last_month_general_ledger_expenditure_row)
						{
						$current_last_month_general_ledger_expenditure_balance = $current_last_month_general_ledger_expenditure_row->current_last_month_general_ledger_expenditure_balance;
						$total_current_last_month_general_ledger_expenditure  += $current_last_month_general_ledger_expenditure_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($current_last_month_general_ledger_expenditure_balance >0) { echo' '.number_format($current_last_month_general_ledger_expenditure_balance, 2 . '').' ';} else if($current_last_month_general_ledger_expenditure_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_last_month_general_ledger_expenditure_balance), 2 . '').') ';} ?></td>
						<?php }
						
						$current_previous_month_general_ledger_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_previous_month_general_ledger_expenditure_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_previous_month_start_date.'" and "'.$current_previous_month_end_date.'"')
						->where('accounts_details_general_ledger', $general_ledger_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($current_previous_month_general_ledger_expenditure as $current_previous_month_general_ledger_expenditure_row)
						{
						$current_previous_month_general_ledger_expenditure_balance = $current_previous_month_general_ledger_expenditure_row->current_previous_month_general_ledger_expenditure_balance;
						$total_current_previous_month_general_ledger_expenditure  += $current_previous_month_general_ledger_expenditure_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($current_previous_month_general_ledger_expenditure_balance >0) { echo' '.number_format($current_previous_month_general_ledger_expenditure_balance, 2 . '').' ';} else if($current_previous_month_general_ledger_expenditure_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_previous_month_general_ledger_expenditure_balance), 2 . '').') ';} ?></td>
						<?php }
						
						$quarterly_general_ledger_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS quarterly_general_ledger_expenditure_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$quarterly_start_date.'" and "'.$quarterly_end_date.'"')
						->where('accounts_details_general_ledger', $general_ledger_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($quarterly_general_ledger_expenditure as $quarterly_general_ledger_expenditure_row)
						{
						$quarterly_general_ledger_expenditure_balance = $quarterly_general_ledger_expenditure_row->quarterly_general_ledger_expenditure_balance;
						$total_quarterly_general_ledger_expenditure  += $quarterly_general_ledger_expenditure_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($quarterly_general_ledger_expenditure_balance >0) { echo' '.number_format($quarterly_general_ledger_expenditure_balance, 2 . '').' ';} else if($quarterly_general_ledger_expenditure_balance ==0) {echo '-';} else { echo' ('.number_format(abs($quarterly_general_ledger_expenditure_balance), 2 . '').') ';} ?></td>
						<?php }
						
						$current_year_general_ledger_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_year_general_ledger_expenditure_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_year_start_date.'" and "'.$current_year_end_date.'"')
						->where('accounts_details_general_ledger', $general_ledger_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($current_year_general_ledger_expenditure as $current_year_general_ledger_expenditure_row)
						{
						$current_year_general_ledger_expenditure_balance = $current_year_general_ledger_expenditure_row->current_year_general_ledger_expenditure_balance;
						$total_current_year_general_ledger_expenditure  += $current_year_general_ledger_expenditure_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($current_year_general_ledger_expenditure_balance >0) { echo' '.number_format($current_year_general_ledger_expenditure_balance, 2 . '').' ';} else if($current_year_general_ledger_expenditure_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_year_general_ledger_expenditure_balance), 2 . '').') ';} ?></td>
						<?php }
						
						$last_year_general_ledger_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS last_year_general_ledger_expenditure_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
						->where('accounts_details_general_ledger', $general_ledger_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($last_year_general_ledger_expenditure as $last_year_general_ledger_expenditure_row)
						{
						$last_year_general_ledger_expenditure_balance = $last_year_general_ledger_expenditure_row->last_year_general_ledger_expenditure_balance;
						$total_last_year_general_ledger_expenditure  += $last_year_general_ledger_expenditure_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($last_year_general_ledger_expenditure_balance >0) { echo' '.number_format($last_year_general_ledger_expenditure_balance, 2 . '').' ';} else if($last_year_general_ledger_expenditure_balance ==0) {echo '-';} else { echo' ('.number_format(abs($last_year_general_ledger_expenditure_balance), 2 . '').') ';} ?></td>
						<?php }?>
					</tr>
					<?php }?>
					
					<tr class="text-uppercase">
						<th class="text-center" colspan="2"><?= $this->lang->line('total');?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_month_general_ledger_expenditure >0) { echo' '.number_format($total_current_month_general_ledger_expenditure, 2 . '').' ';} else if($total_current_month_general_ledger_expenditure ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_month_general_ledger_expenditure), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_last_month_general_ledger_expenditure >0) { echo' '.number_format($total_current_last_month_general_ledger_expenditure, 2 . '').' ';} else if($total_current_last_month_general_ledger_expenditure ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_last_month_general_ledger_expenditure), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_previous_month_general_ledger_expenditure >0) { echo' '.number_format($total_current_previous_month_general_ledger_expenditure, 2 . '').' ';} else if($total_current_previous_month_general_ledger_expenditure ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_previous_month_general_ledger_expenditure), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_quarterly_general_ledger_expenditure >0) { echo' '.number_format($total_quarterly_general_ledger_expenditure, 2 . '').' ';} else if($total_quarterly_general_ledger_expenditure ==0) {echo '-';} else { echo' ('.number_format(abs($total_quarterly_general_ledger_expenditure), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_year_general_ledger_expenditure >0) { echo' '.number_format($total_current_year_general_ledger_expenditure, 2 . '').' ';} else if($total_current_year_general_ledger_expenditure ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_year_general_ledger_expenditure), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_last_year_general_ledger_expenditure >0) { echo' '.number_format($total_last_year_general_ledger_expenditure, 2 . '').' ';} else if($total_last_year_general_ledger_expenditure ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_year_general_ledger_expenditure), 2 . '').') ';} ?></th>
					</tr>
					
					<tr>
						<th class="text-center" width="3%">&nbsp;</th>
						<th class="text-left text-uppercase" colspan="13"></th>
					</tr>
					<?php
					$serial_expenditure_general_ledger = 0;
					$general_ledger_expenditure = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $control_group_expenditure_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
					foreach ($general_ledger_expenditure as $general_ledger_expenditure_row) 
					{?>
					<tr>
						<th class="text-left" width="3%">
							<a class="btn-outline-danger  rounded-pill" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="action_view_model('<?= base_url("accounts/expenditure_expenditure_note_view");?>')"><?= number_format($serial,0 . '');?>.<?= number_format($serial_expenditure,0 . '');?>.<?= ++$serial_expenditure_general_ledger;?></a>
						</th>
						<th class="text-left text-uppercase" colspan="13"><?= $general_ledger_expenditure_row->chart_of_accounts_code;?> - <?= $general_ledger_expenditure_row->chart_of_accounts_name;?></th>
					</tr>
					<?php
					$total_current_month_subsidiary_ledger_expenditure = 0;
					$total_current_last_month_subsidiary_ledger_expenditure = 0;
					$total_current_previous_month_subsidiary_ledger_expenditure = 0;
					$total_quarterly_subsidiary_ledger_expenditure = 0;
					$total_last_month_subsidiary_ledger_expenditure = 0;
					$total_previous_month_subsidiary_ledger_expenditure = 0;
					$total_current_year_subsidiary_ledger_expenditure = 0;
					$total_last_year_subsidiary_ledger_expenditure = 0;
					$total_previous_year_subsidiary_ledger_expenditure = 0;
					
					$subsidiary_ledger_expenditure = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $general_ledger_expenditure_row->chart_of_accounts_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
					foreach ($subsidiary_ledger_expenditure as $subsidiary_ledger_expenditure_row) 
					{?>
					<tr>
						<td></td>
						<td class="text-left"><?= $subsidiary_ledger_expenditure_row->chart_of_accounts_code;?> - <?= $subsidiary_ledger_expenditure_row->chart_of_accounts_name;?></th>
						<?php
						$current_month_subsidiary_ledger_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_month_subsidiary_ledger_expenditure_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
						->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($current_month_subsidiary_ledger_expenditure as $current_month_subsidiary_ledger_expenditure_row)
						{
						$current_month_subsidiary_ledger_expenditure_balance = $current_month_subsidiary_ledger_expenditure_row->current_month_subsidiary_ledger_expenditure_balance;
						$total_current_month_subsidiary_ledger_expenditure  += $current_month_subsidiary_ledger_expenditure_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($current_month_subsidiary_ledger_expenditure_balance >0) { echo' '.number_format($current_month_subsidiary_ledger_expenditure_balance, 2 . '').' ';} else if($current_month_subsidiary_ledger_expenditure_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_month_subsidiary_ledger_expenditure_balance), 2 . '').') ';} ?></td>
						<?php }
						$current_last_month_subsidiary_ledger_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_last_month_subsidiary_ledger_expenditure_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_last_month_start_date.'" and "'.$current_last_month_end_date.'"')
						->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($current_last_month_subsidiary_ledger_expenditure as $current_last_month_subsidiary_ledger_expenditure_row)
						{
						$current_last_month_subsidiary_ledger_expenditure_balance = $current_last_month_subsidiary_ledger_expenditure_row->current_last_month_subsidiary_ledger_expenditure_balance;
						$total_current_last_month_subsidiary_ledger_expenditure  += $current_last_month_subsidiary_ledger_expenditure_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($current_last_month_subsidiary_ledger_expenditure_balance >0) { echo' '.number_format($current_last_month_subsidiary_ledger_expenditure_balance, 2 . '').' ';} else if($current_last_month_subsidiary_ledger_expenditure_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_last_month_subsidiary_ledger_expenditure_balance), 2 . '').') ';} ?></td>
						<?php }
						$current_previous_month_subsidiary_ledger_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_previous_month_subsidiary_ledger_expenditure_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_previous_month_start_date.'" and "'.$current_previous_month_end_date.'"')
						->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($current_previous_month_subsidiary_ledger_expenditure as $current_previous_month_subsidiary_ledger_expenditure_row)
						{
						$current_previous_month_subsidiary_ledger_expenditure_balance = $current_previous_month_subsidiary_ledger_expenditure_row->current_previous_month_subsidiary_ledger_expenditure_balance;
						$total_current_previous_month_subsidiary_ledger_expenditure  += $current_previous_month_subsidiary_ledger_expenditure_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($current_previous_month_subsidiary_ledger_expenditure_balance >0) { echo' '.number_format($current_previous_month_subsidiary_ledger_expenditure_balance, 2 . '').' ';} else if($current_previous_month_subsidiary_ledger_expenditure_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_previous_month_subsidiary_ledger_expenditure_balance), 2 . '').') ';} ?></td>
						<?php }
						$quarterly_subsidiary_ledger_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS quarterly_subsidiary_ledger_expenditure_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$quarterly_start_date.'" and "'.$quarterly_end_date.'"')
						->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($quarterly_subsidiary_ledger_expenditure as $quarterly_subsidiary_ledger_expenditure_row)
						{
						$quarterly_subsidiary_ledger_expenditure_balance = $quarterly_subsidiary_ledger_expenditure_row->quarterly_subsidiary_ledger_expenditure_balance;
						$total_quarterly_subsidiary_ledger_expenditure  += $quarterly_subsidiary_ledger_expenditure_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($quarterly_subsidiary_ledger_expenditure_balance >0) { echo' '.number_format($quarterly_subsidiary_ledger_expenditure_balance, 2 . '').' ';} else if($quarterly_subsidiary_ledger_expenditure_balance ==0) {echo '-';} else { echo' ('.number_format(abs($quarterly_subsidiary_ledger_expenditure_balance), 2 . '').') ';} ?></td>
						<?php }
						
						$current_year_subsidiary_ledger_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_year_subsidiary_ledger_expenditure_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_year_start_date.'" and "'.$current_year_end_date.'"')
						->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($current_year_subsidiary_ledger_expenditure as $current_year_subsidiary_ledger_expenditure_row)
						{
						$current_year_subsidiary_ledger_expenditure_balance = $current_year_subsidiary_ledger_expenditure_row->current_year_subsidiary_ledger_expenditure_balance;
						$total_current_year_subsidiary_ledger_expenditure  += $current_year_subsidiary_ledger_expenditure_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($current_year_subsidiary_ledger_expenditure_balance >0) { echo' '.number_format($current_year_subsidiary_ledger_expenditure_balance, 2 . '').' ';} else if($current_year_subsidiary_ledger_expenditure_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_year_subsidiary_ledger_expenditure_balance), 2 . '').') ';} ?></td>
						<?php }
						
						$last_year_subsidiary_ledger_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS last_year_subsidiary_ledger_expenditure_balance") 
						->from('accounts_details')
						->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
						->where('accounts_details_subsidiary_ledger', $subsidiary_ledger_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($last_year_subsidiary_ledger_expenditure as $last_year_subsidiary_ledger_expenditure_row)
						{
						$last_year_subsidiary_ledger_expenditure_balance = $last_year_subsidiary_ledger_expenditure_row->last_year_subsidiary_ledger_expenditure_balance;
						$total_last_year_subsidiary_ledger_expenditure  += $last_year_subsidiary_ledger_expenditure_balance;
						?>			
						<td class="text-center" width="1%"></td>
						<td class="text-right"><?php if ($last_year_subsidiary_ledger_expenditure_balance >0) { echo' '.number_format($last_year_subsidiary_ledger_expenditure_balance, 2 . '').' ';} else if($last_year_subsidiary_ledger_expenditure_balance ==0) {echo '-';} else { echo' ('.number_format(abs($last_year_subsidiary_ledger_expenditure_balance), 2 . '').') ';} ?></td>
						<?php }?>
					</tr>	
					<?php  }?>
					<tr class="text-uppercase">
						<th class="text-center" colspan="2"><?= $this->lang->line('total');?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_month_subsidiary_ledger_expenditure >0) { echo' '.number_format($total_current_month_subsidiary_ledger_expenditure, 2 . '').' ';} else if($total_current_month_subsidiary_ledger_expenditure ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_month_subsidiary_ledger_expenditure), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_last_month_subsidiary_ledger_expenditure >0) { echo' '.number_format($total_current_last_month_subsidiary_ledger_expenditure, 2 . '').' ';} else if($total_current_last_month_subsidiary_ledger_expenditure ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_last_month_subsidiary_ledger_expenditure), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_previous_month_subsidiary_ledger_expenditure >0) { echo' '.number_format($total_current_previous_month_subsidiary_ledger_expenditure, 2 . '').' ';} else if($total_current_previous_month_subsidiary_ledger_expenditure ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_previous_month_subsidiary_ledger_expenditure), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_quarterly_subsidiary_ledger_expenditure >0) { echo' '.number_format($total_quarterly_subsidiary_ledger_expenditure, 2 . '').' ';} else if($total_quarterly_subsidiary_ledger_expenditure ==0) {echo '-';} else { echo' ('.number_format(abs($total_quarterly_subsidiary_ledger_expenditure), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th> 
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_current_year_subsidiary_ledger_expenditure >0) { echo' '.number_format($total_current_year_subsidiary_ledger_expenditure, 2 . '').' ';} else if($total_current_year_subsidiary_ledger_expenditure ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_year_subsidiary_ledger_expenditure), 2 . '').') ';} ?></th>
						<th class="text-center" width="1%"></th>
						<th class="text-right bd-bottom-double bd-top"><?php if ($total_last_year_subsidiary_ledger_expenditure >0) { echo' '.number_format($total_last_year_subsidiary_ledger_expenditure, 2 . '').' ';} else if($total_last_year_subsidiary_ledger_expenditure ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_year_subsidiary_ledger_expenditure), 2 . '').') ';} ?></th>
					</tr>
					
					<tr>
						<th class="text-center" width="3%">&nbsp;</th>
						<th class="text-left text-uppercase" colspan="13"></th>
					</tr> 
					<?php }
					}
					
				} 
			}
			?>
			</tbody>
		</table>
		
		<br/><br/><br/>
		
		<table class="" width="100%" align="center">  
			<tr class="text-uppercase">
				<th width="30%" class="text-center bd-top"><?= $this->lang->line('prepared_by');?></th>
				<th width="5%"></th>
				<th width="30%" class="text-center bd-top"><?= $this->lang->line('checked_by');?></th>
				<th width="5%"></th>
				<th width="30%" class="text-center bd-top"><?= $this->lang->line('authorised');?></th>
			</tr>
		</table>
		<?php 
		return $output;
	}
	
	/* ------------------------------------------------------
	Payment Month List Model
	------------------------------------------------------- */
	function payment_month_list_option()
	{	
		return $this->db->select("*")
		->from('payment_month')
		->where('payment_month_status', 1)
		->order_by('payment_month_id', 'ASC')  
		->get()
		->result();
	}
	
	/* ------------------------------------------------------
    Receipt & Payment Statement Model
    ------------------------------------------------------- */
function receipt_payment($closing_month)
{
    $output = '';
    $s_date = '2020-01-01'; // Fixed initialization

    $starting_date = date('Y-m-01', strtotime($closing_month));
    $closing_date  = date('Y-m-t', strtotime($closing_month));

    // Current Month Opening Balance
    $current_month_opening_balance_starting_date = date('Y-m-d', strtotime($s_date));
    $current_month_opening_balance_closing_date  = date('Y-m-t', strtotime($starting_date. " -1 day"));

    // Fiscal Year Opening Balance
    $closing_month_num = (int) date('m', strtotime($closing_date));

    $current_year_opening_balance_starting_date = $s_date;
    if ($closing_month_num < 7) {
        $current_year_opening_balance_closing_date = date('Y-06-30', strtotime($closing_date . " -1 year"));
    } else {
        $current_year_opening_balance_closing_date = date('Y-06-30', strtotime($closing_date));
    }

    // Current Month Period
    $current_month_starting_date = date('Y-m-01', strtotime($closing_date));
    $current_month_closing_date  = date('Y-m-t', strtotime($closing_date));

    // Fiscal Year Period
    if ($closing_month_num < 7) {
        $current_year_starting       = date('Y', strtotime($closing_date . "-1 year"));
        $current_year_closing        = date('y', strtotime($closing_date));
        $current_year_starting_date  = date('Y-07-01', strtotime($closing_date . "-1 year"));
        $current_year_closing_date   = date('Y-m-d', strtotime($closing_date));
    } else {
        $current_year_starting       = date('Y', strtotime($closing_date));
        $current_year_closing        = date('y', strtotime($closing_date . "+1 year"));
        $current_year_starting_date  = date('Y-07-01', strtotime($closing_date));
        $current_year_closing_date   = date('Y-06-30', strtotime($closing_date . "+1 year"));
    }

?>
    
    <table class="table-striped table-hover" border="0" width="100%">
        <tbody>
            <tr class="text-uppercase bd-all">  
                <th class="text-left" width="64%">&nbsp;<?= $this->lang->line('particulars');?></th>
                <th class="text-left" width="1%">&nbsp;</th>
                <th class="text-right" width="18%"><?= $this->lang->line('current_month');?><br/><?= date('M-Y', strtotime($closing_date));?>
                </th>
                <th class="text-left" width="1%">&nbsp;</th>
                <th class="text-right" width="18%"><?= $this->lang->line('for_the_period');?> &nbsp;<br/> FY <?= $current_year_starting;?>-<?= $current_year_closing;?> &nbsp;</th>
            </tr>
            <tr class="text-uppercase">  
                <th class="text-left" colspan="5">Receipts</th>
            </tr>
            <tr class="">  
                <th class="text-left" colspan="5"><?= $this->lang->line('opening_balance'); ?></th>
            </tr>

            <?php
            $grand_total_current_month_receipts_balance     = 0;
            $grand_total_current_year_receipts_balance      = 0;    
            
            // Initialize opening balance totals BEFORE the loop
            $total_current_month_opening_balance = 0;
            $total_current_year_opening_balance = 0;

            $opening_coa_list = $this->db->select('chart_of_accounts_id, chart_of_accounts_code, chart_of_accounts_name')
            ->from('chart_of_accounts')
            ->where_in('chart_of_accounts_general_ledger_receipt_payment_show', [1,2]) // 1 = Cash, 2 = Bank
            ->group_by('chart_of_accounts_code')
            ->order_by('chart_of_accounts_code', 'ASC')
            ->get()
            ->result();
            
            foreach ($opening_coa_list as $opening_coa) {
                // REMOVED: $total_current_month_opening_balance = 0; (this was resetting the total)
                // REMOVED: $total_current_year_opening_balance = 0; (this was resetting the total)
                
                $c_month_opening_balance_data = $this->db->select(" (SUM(accounts_details_debit)-SUM(accounts_details_credit)) AS opening_balance") 
                ->from('accounts_details')
                ->where('accounts_details_general_ledger', $opening_coa->chart_of_accounts_id)
                ->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_opening_balance_starting_date.'" and "'.$current_month_opening_balance_closing_date.'"')
                ->get() 
                ->row();
                
                $c_year_opening_balance_data = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS opening_balance") 
                ->from('accounts_details')
                ->where('accounts_details_general_ledger', $opening_coa->chart_of_accounts_id)
                ->where('accounts_details_voucher_posting_date BETWEEN "'.$current_year_opening_balance_starting_date.'" and "'.$current_year_opening_balance_closing_date.'"') 
                ->get() 
                ->row();

                $current_month_opening_balance = abs($c_month_opening_balance_data->opening_balance ?? 0);
                $current_year_opening_balance = abs($c_year_opening_balance_data->opening_balance ?? 0);
                
                $total_current_month_opening_balance += $current_month_opening_balance;
                $total_current_year_opening_balance += $current_year_opening_balance;
                ?>
                <tr>
                    <td class="text-left"><?= $opening_coa->chart_of_accounts_code; ?> - <?=  $opening_coa->chart_of_accounts_name; ?></td>
                    <td></td>
                    <td class="text-right"><?= $current_month_opening_balance > 0 ? number_format($current_month_opening_balance, 2) : '-'; ?></td>
                    <td></td>
                    <td class="text-right"><?= $current_year_opening_balance > 0 ? number_format($current_year_opening_balance, 2) : '-'; ?></td>
                </tr>
            <?php }?>
            <tr>
                <th class="text-right text-uppercase">
                    <?= $this->lang->line('total') . ' ' . $this->lang->line('opening_balance'); ?>
                </th>
                <th></th>
                <th class="text-right bd-bottom"><?= $total_current_month_opening_balance > 0 ? number_format($total_current_month_opening_balance, 2) : '-'; ?></th>
                <th></th>
                <th class="text-right bd-bottom"><?= $total_current_year_opening_balance > 0 ? number_format($total_current_year_opening_balance, 2) : '-'; ?></th>
            </tr>
            
            <?php 
                
            $receipts_coa = $this->db->select("chart_of_accounts.chart_of_accounts_id, chart_of_accounts.chart_of_accounts_code, chart_of_accounts.chart_of_accounts_name")
            ->from('accounts_details')
            ->join('chart_of_accounts', 'accounts_details.accounts_details_general_ledger = chart_of_accounts.chart_of_accounts_id', 'LEFT')
            ->where('accounts_details.accounts_details_voucher_posting_date >=', $current_year_starting_date)
            ->where('accounts_details.accounts_details_voucher_posting_date <=', $current_year_closing_date)
            ->where_not_in('chart_of_accounts.chart_of_accounts_general_ledger_receipt_payment_show', [1,2]) // 1 = Cash, 2 = Bank
            ->where('accounts_details.accounts_details_voucher_type', 1)
            ->group_by('chart_of_accounts.chart_of_accounts_id')
            ->group_by('accounts_details.accounts_details_general_ledger')
            ->order_by('chart_of_accounts.chart_of_accounts_code', 'ASC')
            ->get()
            ->result();

            foreach ($receipts_coa as $coa_row) {
            
            $total_current_month_receipts_balance   = 0;
            $total_current_year_receipts_balance    = 0;    
            ?>
            <tr>
                <th class="text-left" colspan="5"><?= $coa_row->chart_of_accounts_code;?> - <?= $coa_row->chart_of_accounts_name;?></th>
            </tr>

            <?php $receipts_scoa = $this->db->select("chart_of_accounts.chart_of_accounts_id, chart_of_accounts.chart_of_accounts_code, chart_of_accounts.chart_of_accounts_name")
            ->from('accounts_details')
            ->join('chart_of_accounts', 'accounts_details.accounts_details_subsidiary_ledger = chart_of_accounts.chart_of_accounts_id', 'LEFT')
            ->where('accounts_details.accounts_details_general_ledger', $coa_row->chart_of_accounts_id)
            ->where('accounts_details.accounts_details_voucher_posting_date >=', $current_year_starting_date)
            ->where('accounts_details.accounts_details_voucher_posting_date <=', $current_year_closing_date)
            ->where_not_in('chart_of_accounts.chart_of_accounts_general_ledger_receipt_payment_show', [1,2]) // 1 = Cash, 2 = Bank
            ->where('accounts_details.accounts_details_voucher_type', 1)
            // ->group_by('chart_of_accounts.chart_of_accounts_id')
            ->group_by('accounts_details.accounts_details_subsidiary_ledger')
            ->order_by('chart_of_accounts.chart_of_accounts_code', 'ASC')
            ->get()
            ->result();
            foreach ($receipts_scoa as $scoa_row) {
            $c_month_receipts_balance_data = $this->db->select(" (SUM(accounts_details_credit)-SUM(accounts_details_debit)) AS receipts_balance") ->from('accounts_details')
            ->where('accounts_details_subsidiary_ledger', $scoa_row->chart_of_accounts_id)
            ->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_starting_date.'" and "'.$current_month_closing_date.'"')
            ->where('accounts_details.accounts_details_voucher_type', 1)
            ->get() ->row();
            $c_year_receipts_balance_data = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS receipts_balance") ->from('accounts_details')
            ->where('accounts_details_subsidiary_ledger', $scoa_row->chart_of_accounts_id)
            ->where('accounts_details_voucher_posting_date BETWEEN "'.$current_year_starting_date.'" and "'.$current_year_closing_date.'"')
            ->where('accounts_details.accounts_details_voucher_type', 1) ->get() ->row();

            $current_month_receipts_balance         = (float) abs($c_month_receipts_balance_data->receipts_balance ?? 0);
            $current_year_receipts_balance          = (float) abs($c_year_receipts_balance_data->receipts_balance ?? 0);
            $total_current_month_receipts_balance   += (float) abs($current_month_receipts_balance);
            $total_current_year_receipts_balance    += (float) abs($current_year_receipts_balance);   
            $grand_total_current_month_receipts_balance  += (float) abs($current_month_receipts_balance);
            $grand_total_current_year_receipts_balance   += (float) abs($current_year_receipts_balance);    
            ?>
            <tr>
                <td class="text-left">&nbsp; <?= $scoa_row->chart_of_accounts_code;?> - <?= $scoa_row->chart_of_accounts_name;?></td>
                <td class="text-left" width="1%">&nbsp;</td>
                <td class="text-right"><?= $current_month_receipts_balance > 0 ? number_format($current_month_receipts_balance, 2) : '-';?></td>
                <td class="text-left" width="1%">&nbsp;</td>
                <td class="text-right"><?= $current_year_receipts_balance > 0 ? number_format($current_year_receipts_balance, 2) : '-';?></td>
            </tr>
            
            <?php }?>
            <tr>
                <th class="text-right text-uppercase"><?= $this->lang->line('total');?> <?= $coa_row->chart_of_accounts_code;?> - <?= $coa_row->chart_of_accounts_name;?></th>
                <th></th>
                <th class="text-right bd-bottom"><?= $total_current_month_receipts_balance > 0 ? number_format($total_current_month_receipts_balance, 2) : '-'; ?></th>
                <th></th>
                <th class="text-right bd-bottom"><?= $total_current_year_receipts_balance > 0 ? number_format($total_current_year_receipts_balance, 2) : '-'; ?></th>
            </tr>
            <?php }?>

            <tr>
                <th class="text-left" colspan="5">&nbsp;</th>
            </tr>
            
            <?php 
            $total_current_month_receipts_balance_receipts = $total_current_month_opening_balance + $grand_total_current_month_receipts_balance;
            $total_current_year_receipts_balance_receipts  = ($total_current_year_opening_balance + $grand_total_current_year_receipts_balance);
            ?>
            <tr>
                <th class="text-right text-uppercase"><?= $this->lang->line('total');?> Receipts</th>
                <td class="text-left" width="1%">&nbsp;</td>
                <th class="text-right bd-bottom-double"><?= $total_current_month_receipts_balance_receipts > 0 ? number_format($total_current_month_receipts_balance_receipts, 2) : '-';?></th>
                <td class="text-left" width="1%">&nbsp;</td>
                <th class="text-right bd-bottom-double"><?= $total_current_year_receipts_balance_receipts > 0 ? number_format($total_current_year_receipts_balance_receipts, 2) : '-';?></th>
            </tr>

            <tr class="text-uppercase">  
                <th class="text-left" colspan="5">Payments</th>
            </tr>
            <?php 
            $grand_total_current_month_payments_balance  = 0;
            $grand_total_current_year_payments_balance   = 0;    
                    
            $payments_coa = $this->db->select("chart_of_accounts.chart_of_accounts_id, chart_of_accounts.chart_of_accounts_code, chart_of_accounts.chart_of_accounts_name")
            ->from('accounts_details')
            ->join('chart_of_accounts', 'accounts_details.accounts_details_general_ledger = chart_of_accounts.chart_of_accounts_id', 'LEFT')
            ->where('accounts_details.accounts_details_voucher_posting_date >=', $current_year_starting_date)
            ->where('accounts_details.accounts_details_voucher_posting_date <=', $current_year_closing_date)
            ->where_not_in('chart_of_accounts.chart_of_accounts_general_ledger_receipt_payment_show', [1,2]) // 1 = Cash, 2 = Bank
            ->where('accounts_details.accounts_details_voucher_type', 2)
            ->group_by('chart_of_accounts.chart_of_accounts_id')
            ->group_by('accounts_details.accounts_details_general_ledger')
            ->order_by('chart_of_accounts.chart_of_accounts_code', 'ASC')
            ->get()
            ->result();

            foreach ($payments_coa as $p_coa_row) {
            
            $total_current_month_payments_balance   = 0;
            $total_current_year_payments_balance    = 0;    
            ?>
            <tr>
                <th class="text-left" colspan="5"><?= $p_coa_row->chart_of_accounts_code;?> - <?= $p_coa_row->chart_of_accounts_name;?></th>
            </tr>

            <?php $payments_scoa = $this->db->select("chart_of_accounts.chart_of_accounts_id, chart_of_accounts.chart_of_accounts_code, chart_of_accounts.chart_of_accounts_name")
            ->from('accounts_details')
            ->join('chart_of_accounts', 'accounts_details.accounts_details_subsidiary_ledger = chart_of_accounts.chart_of_accounts_id', 'LEFT')
            ->where('accounts_details.accounts_details_general_ledger', $p_coa_row->chart_of_accounts_id)
            ->where('accounts_details.accounts_details_voucher_posting_date >=', $current_year_starting_date)
            ->where('accounts_details.accounts_details_voucher_posting_date <=', $current_year_closing_date)
            ->where_not_in('chart_of_accounts.chart_of_accounts_general_ledger_receipt_payment_show', [1,2]) // 1 = Cash, 2 = Bank
            ->where('accounts_details.accounts_details_voucher_type', 2)
            // ->group_by('chart_of_accounts.chart_of_accounts_id')
            ->group_by('accounts_details.accounts_details_subsidiary_ledger')
            ->order_by('chart_of_accounts.chart_of_accounts_code', 'ASC')
            ->get()
            ->result();
            foreach ($payments_scoa as $p_scoa_row) {
            $c_month_payments_balance_data = $this->db->select(" (SUM(accounts_details_debit)-SUM(accounts_details_credit)) AS payments_balance") ->from('accounts_details')
            ->where('accounts_details_subsidiary_ledger', $p_scoa_row->chart_of_accounts_id)
            ->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_starting_date.'" and "'.$current_month_closing_date.'"')
            ->where('accounts_details.accounts_details_voucher_type', 2)
            ->get() ->row();
            $c_year_payments_balance_data = $this->db->select(" (SUM(accounts_details_debit)-SUM(accounts_details_credit)) AS  payments_balance") ->from('accounts_details')
            ->where('accounts_details_subsidiary_ledger', $p_scoa_row->chart_of_accounts_id)
            ->where('accounts_details_voucher_posting_date BETWEEN "'.$current_year_starting_date.'" and "'.$current_year_closing_date.'"')
            ->where('accounts_details.accounts_details_voucher_type', 2) ->get() ->row();

            $current_month_payments_balance         = (float) abs($c_month_payments_balance_data->payments_balance ?? 0);
            $current_year_payments_balance          = (float) abs($c_year_payments_balance_data->payments_balance ?? 0);
            $total_current_month_payments_balance   += (float) abs($current_month_payments_balance);
            $total_current_year_payments_balance    += (float) abs($current_year_payments_balance);    
            $grand_total_current_month_payments_balance  += (float) abs($current_month_payments_balance);
            $grand_total_current_year_payments_balance   += (float) abs($current_year_payments_balance);    
            ?>
            <tr>
                <td class="text-left">&nbsp; <?= $p_scoa_row->chart_of_accounts_code;?> - <?= $p_scoa_row->chart_of_accounts_name;?></td>
                <td class="text-left" width="1%">&nbsp;</td>
                <td class="text-right"><?= $current_month_payments_balance > 0 ? number_format($current_month_payments_balance, 2) : '-';?></td>
                <td class="text-left" width="1%">&nbsp;</td>
                <td class="text-right"><?= $current_year_payments_balance > 0 ? number_format($current_year_payments_balance, 2) : '-';?></td>
            </tr>
            
            <?php }?>
            <tr>
                <th class="text-right text-uppercase"><?= $this->lang->line('total');?> <?= $p_coa_row->chart_of_accounts_code;?> - <?= $p_coa_row->chart_of_accounts_name;?></th>
                <th></th>
                <th class="text-right bd-bottom"><?= $total_current_month_payments_balance > 0 ? number_format($total_current_month_payments_balance, 2) : '-'; ?></th>
                <th></th>
                <th class="text-right bd-bottom"><?= $total_current_year_payments_balance > 0 ? number_format($total_current_year_payments_balance, 2) : '-'; ?></th>
            </tr>
            <?php }?>
            
            <tr class="">  
                <th class="text-left" colspan="5"><?= $this->lang->line('closing_balance'); ?></th>
            </tr>
            <?php 
            // Initialize closing balance totals BEFORE the loop
            $total_current_month_closing_balance = 0;
            $total_current_year_closing_balance = 0;

            $closing_coa_list = $this->db->select('chart_of_accounts_id, chart_of_accounts_code, chart_of_accounts_name')
            ->from('chart_of_accounts')
            ->where_in('chart_of_accounts_general_ledger_receipt_payment_show', [1,2]) // 1 = Cash, 2 = Bank
            ->group_by('chart_of_accounts_code')
            ->order_by('chart_of_accounts_code', 'ASC')
            ->get()
            ->result();
            
            foreach ($closing_coa_list as $closing_coa) {
                // REMOVED: $total_current_month_closing_balance = 0; (this was resetting the total)
                // REMOVED: $total_current_year_closing_balance = 0; (this was resetting the total)
                
                $c_month_closing_balance_data = $this->db->select(" (SUM(accounts_details_debit)-SUM(accounts_details_credit)) AS closing_balance") 
                ->from('accounts_details')
                ->where('accounts_details_general_ledger', $closing_coa->chart_of_accounts_id)
                ->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_opening_balance_starting_date.'" and "'.$current_month_closing_date.'"')
                ->get() 
                ->row();
                
                $c_year_closing_balance_data = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS closing_balance") 
                ->from('accounts_details')
                ->where('accounts_details_general_ledger', $closing_coa->chart_of_accounts_id)
                ->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_opening_balance_starting_date.'" and "'.$current_year_closing_date.'"')
                ->get() 
                ->row();

                $current_month_closing_balance = abs($c_month_closing_balance_data->closing_balance ?? 0);
                $current_year_closing_balance = abs($c_year_closing_balance_data->closing_balance ?? 0);
                
                $total_current_month_closing_balance += $current_month_closing_balance;
                $total_current_year_closing_balance += $current_year_closing_balance;
                ?>
                <tr>
                    <td class="text-left"><?= $closing_coa->chart_of_accounts_code; ?> - <?=  $closing_coa->chart_of_accounts_name; ?></td>
                    <td></td>
                    <td class="text-right"><?= $current_month_closing_balance > 0 ? number_format($current_month_closing_balance, 2) : '-'; ?></td>
                    <td></td>
                    <td class="text-right"><?= $current_year_closing_balance > 0 ? number_format($current_year_closing_balance, 2) : '-'; ?></td>
                </tr>
            <?php }?>
            <tr>
                <th class="text-right text-uppercase">
                    <?= $this->lang->line('total') . ' ' . $this->lang->line('closing_balance'); ?>
                </th>
                <th></th>
                <th class="text-right bd-bottom"><?= $total_current_month_closing_balance > 0 ? number_format($total_current_month_closing_balance, 2) : '-'; ?></th>
                <th></th>
                <th class="text-right bd-bottom"><?= $total_current_year_closing_balance > 0 ? number_format($total_current_year_closing_balance, 2) : '-'; ?></th>
            </tr>

            <tr>
                <th class="text-left" colspan="5">&nbsp;</th>
            </tr>

            <!-- <?php 
            $total_current_month_payments_balance_payments = $grand_total_current_month_payments_balance;
            $total_current_year_payments_balance_payments  = $grand_total_current_year_payments_balance;
            ?>
            <tr>
                <th class="text-right text-uppercase"><?= $this->lang->line('total');?> payments</th>
                <td class="text-left" width="1%">&nbsp;</td>
                <th class="text-right bd-bottom-double"><?= $total_current_month_payments_balance_payments > 0 ? number_format($total_current_month_payments_balance_payments, 2) : '-';?></th>
                <td class="text-left" width="1%">&nbsp;</td>
                <th class="text-right bd-bottom-double"><?= $total_current_year_payments_balance_payments > 0 ? number_format($total_current_year_payments_balance_payments, 2) : '-';?></th>
            </tr> -->

			<?php 
            // TOTAL PAYMENTS = All Expenses + Closing Balance (to balance with Total Receipts)
            // This ensures: Total Receipts = Total Payments + Closing Balance
            $total_current_month_payments = $grand_total_current_month_payments_balance + $total_current_month_closing_balance;
            $total_current_year_payments = $grand_total_current_year_payments_balance + $total_current_year_closing_balance;
            ?>
            <tr>
                <th class="text-right text-uppercase"><?= $this->lang->line('total');?> PAYMENTS</th>
                <td class="text-left" width="1%">&nbsp;</td>
                <th class="text-right bd-bottom-double"><?= $total_current_month_payments != 0 ? number_format($total_current_month_payments, 2) : '-';?></th>
                <td class="text-left" width="1%">&nbsp;</td>
                <th class="text-right bd-bottom-double"><?= $total_current_year_payments != 0 ? number_format($total_current_year_payments, 2) : '-';?></th>
            </tr>

        </tbody>
    </table>
    
    <?php return $output;
}


	function receipt_payment_old($starting_date, $closing_date)
	{	
		$output = '';
		
		if($project == 'all') {?>
		<?php 
		$opening_balance_starting_date = date('2015-01-01');
		$opening_balance_closing_date = date('Y-m-d', strtotime($starting_date. "last day"));
		?>
		<table class="table table-striped table-bordered table-hover">
			<thead class=" text-uppercase">
				<tr>  
					<th class="text-center" width="64%"><?= $this->lang->line('particulars');?></th>
					<th class="text-center" width="18%"><?= $this->lang->line('debit');?></th>
					<th class="text-center" width="18%"><?= $this->lang->line('credit');?></th>
					<th class="text-center" width="18%"><?= $this->lang->line('balance');?></th>
				</tr>
			</thead>
			<tbody>
				<?php 
				$opening_balance = 0;
				$cash_opening =  $this->db->select("*")
				->from('chart_of_accounts')
				->where('chart_of_accounts_general_ledger_receipt_payment_show', 1)
				->order_by('chart_of_accounts_code', 'ASC') 
				->get()
				->result();
				foreach($cash_opening as $cash_opening_row)
				{
				$cash_opening_balance_query =  $this->db->select("SUM(accounts_details_debit) as opening_debit_balance, SUM(accounts_details_credit) as opening_credit_balance")
				->from('accounts_details')
				->where('accounts_details_general_ledger', $cash_opening_row->chart_of_accounts_id)
				
				->where('accounts_details_voucher_posting_date BETWEEN "'.$opening_balance_starting_date.'" and "'.$opening_balance_closing_date.'"')
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				foreach($cash_opening_balance_query as $cash_opening_balance_row)
				{
					
					$cash_opening_debit		= $cash_opening_balance_row->opening_debit_balance;
					$cash_opening_credit	= $cash_opening_balance_row->opening_credit_balance;
					$cash_opening_balance 	= abs($cash_opening_debit - $cash_opening_credit);
				}	
				
				$opening_balance = $cash_opening_balance;
				?>
				<tr>
					<td class="text-left"><?= $cash_opening_row->chart_of_accounts_code;?> - <?= $cash_opening_row->chart_of_accounts_name;?> <?= $this->lang->line('opening_balance');?></td>
					<td class="text-right">-</td>
					<td class="text-right"><?php if ($cash_opening_balance >0) { echo' '.number_format($cash_opening_balance, 2 . '').' ';} else if ($cash_opening_balance == 0) { echo'-';} else { echo' '.number_format(abs($cash_opening_balance),2 . '').' ';} ?></td>
					<td class="text-right"><?php if ($cash_opening_balance >0) { echo' '.number_format($cash_opening_balance, 2 . '').' ';} else if ($cash_opening_balance == 0) { echo'-';} else { echo' ('.number_format(abs($cash_opening_balance),2 . '').') ';} ?></td>
				</tr>
				<?php }?>
				
				<?php 
				$bank_opening =  $this->db->select("*")
				->from('chart_of_accounts')
				->where('chart_of_accounts_general_ledger_receipt_payment_show', 2)
				->order_by('chart_of_accounts_code', 'ASC') 
				->get()
				->result();
				foreach($bank_opening as $bank_opening_row)
				{
				$bank_opening_balance_query =  $this->db->select("SUM(accounts_details_debit) as opening_debit_balance, SUM(accounts_details_credit) as opening_credit_balance")
				->from('accounts_details')
				->where('accounts_details_general_ledger', $bank_opening_row->chart_of_accounts_id)
				 
				->where('accounts_details_voucher_posting_date BETWEEN "'.$opening_balance_starting_date.'" and "'.$opening_balance_closing_date.'"')
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				foreach($bank_opening_balance_query as $bank_opening_balance_row)
				{
					$bank_opening_debit		= $bank_opening_balance_row->opening_debit_balance;
					$bank_opening_credit	= $bank_opening_balance_row->opening_credit_balance;
					
					$bank_opening_balance 	= abs($bank_opening_debit - $bank_opening_credit);
				} 
				$opening_balance += $bank_opening_balance;
				?>
				<tr>
					<td class="text-left"><?= $bank_opening_row->chart_of_accounts_code;?> - <?= $bank_opening_row->chart_of_accounts_name;?> <?= $this->lang->line('opening_balance');?></td>
					<td class="text-right">-</td>
					<td class="text-right"><?php if ($bank_opening_balance >0) { echo' '.number_format($bank_opening_balance, 2 . '').' ';} else if ($bank_opening_balance == 0) { echo'-';} else { echo' '.number_format(abs($bank_opening_balance),2 . '').' ';} ?></td>
					<td class="text-right"><?php if ($opening_balance >0) { echo' '.number_format($opening_balance, 2 . '').' ';} else if ($opening_balance == 0) { echo'-';} else { echo' ('.number_format(abs($opening_balance),2 . '').' )';} ?></td>
				</tr>
				<?php }?>
				
				<?php 
				$total_debit_balance = 0;
				$total_credit_balance = 0;
				$balance = $opening_balance;
				$coa_info =  $this->db->select("DISTINCT(accounts_details_subsidiary_ledger), chart_of_accounts_code, chart_of_accounts_name")
				->from('accounts_details')
				->join('chart_of_accounts', 'accounts_details.accounts_details_subsidiary_ledger = chart_of_accounts.chart_of_accounts_id', 'LEFT')
				  
				->where('accounts_details.accounts_details_voucher_posting_date BETWEEN "'.$starting_date.'" and "'.$closing_date.'"')
				->where('accounts_details_control_group<>', 65)
				->where('accounts_details_voucher_type<>', 3)
				->order_by('chart_of_accounts.chart_of_accounts_code', 'ASC') 
				->get()
				->result();
				foreach($coa_info as $coa_row)
				{
				
				$debit_info =  $this->db->select("SUM(accounts_details_debit) as debit_balance")
				->from('accounts_details')  
				->where('accounts_details_subsidiary_ledger', $coa_row->accounts_details_subsidiary_ledger) 
				
				->where('accounts_details_voucher_posting_date BETWEEN "'.$starting_date.'" and "'.$closing_date.'"')
				->where('accounts_details_control_group<>', 65)
				->where('accounts_details_voucher_type<>', 3) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				foreach($debit_info as $debit_row)
				{
					$debit_balance			= $debit_row->debit_balance;
					$total_debit_balance	+= $debit_balance;
				}
				
				$debit_info =  $this->db->select("SUM(accounts_details_credit) as credit_balance")
				->from('accounts_details')  
				->where('accounts_details_subsidiary_ledger', $coa_row->accounts_details_subsidiary_ledger)
				
				->where('accounts_details_voucher_posting_date BETWEEN "'.$starting_date.'" and "'.$closing_date.'"')
				->where('accounts_details_control_group<>', 65)
				->where('accounts_details_voucher_type<>', 3) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				foreach($debit_info as $debit_row)
				{
					$credit_balance			= $debit_row->credit_balance;
					$total_credit_balance	+= $credit_balance;
				}
					$balance += $credit_balance-$debit_balance;
				?>
				<tr>
					<td class="text-left bd-bottom-double">&nbsp; <?= $coa_row->chart_of_accounts_code;?> - <?= $coa_row->chart_of_accounts_name;?></td>
					<td class="text-right"><?php if ($debit_balance >0) { echo' '.number_format($debit_balance, 2 . '').' ';} else if ($debit_balance == 0) { echo'-';} else { echo' '.number_format(abs($debit_balance),2 . '').' ';} ?></td>
					<td class="text-right"><?php if ($credit_balance >0) { echo' '.number_format($credit_balance, 2 . '').' ';} else if ($credit_balance == 0) { echo'-';} else { echo' '.number_format(abs($credit_balance),2 . '').' ';} ?></td>
					<td class="text-right"><?php if ($balance >0) { echo' '.number_format($balance, 2 . '').' ';} else if ($balance == 0) { echo'-';} else { echo' ('.number_format(abs($balance),2 . '').')';} ?></td>
				</tr>
				<?php }
				$total_debit_balance_amount		= $total_debit_balance;
				$total_credit_balance_amount	= $total_credit_balance + $opening_balance;
				?>
				<tr class="text-uppercase">
					<th class="text-center"><?= $this->lang->line('total');?></th> 
					<th class="text-right"><?php if ($total_debit_balance_amount >0) { echo' '.number_format($total_debit_balance_amount, 2 . '').' ';} else if ($total_debit_balance_amount == 0) { echo'-';} else { echo' '.number_format(abs($total_debit_balance_amount),2 . '').' ';} ?></th> 
					<th class="text-right"><?php if ($total_credit_balance_amount >0) { echo' '.number_format($total_credit_balance_amount, 2 . '').' ';} else if ($total_credit_balance_amount == 0) { echo'-';} else { echo' '.number_format(abs($total_credit_balance_amount),2 . '').' ';} ?></th> 
					<th class="text-right"><?php if ($balance >0) { echo' '.number_format($balance, 2 . '').' ';} else if ($balance == 0) { echo'-';} else { echo'('.number_format(abs($balance),2 . '').')';} ?></th> 
				</tr>
				
				<?php 
				// Cash & Bank Closing Balance Information
				$cash_closing =  $this->db->select("*")
				->from('chart_of_accounts')
				->where('chart_of_accounts_general_ledger_receipt_payment_show', 1)
				->order_by('chart_of_accounts_code', 'ASC') 
				->get()
				->result();
				foreach($cash_closing as $cash_closing_row)
				{
				$closing_balance_query_cash =  $this->db->select("SUM(accounts_details_debit) as closing_debit_balance, SUM(accounts_details_credit) as closing_credit_balance, (SUM(accounts_details_debit) - SUM(accounts_details_credit)) as  closing_balance")
				->from('accounts_details')
				->where('accounts_details_general_ledger', $cash_closing_row->chart_of_accounts_id)
				
				->where('accounts_details_voucher_posting_date BETWEEN "'.$opening_balance_starting_date.'" and "'.$closing_date.'"')
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				foreach($closing_balance_query_cash as $closing_balance_query_cash_row)
				{
					$closing_debit_balance_cash		= $closing_balance_query_cash_row->closing_debit_balance;
					$closing_credit_balance_cash	= $closing_balance_query_cash_row->closing_credit_balance;
					$cash_closing_balance			= $closing_balance_query_cash_row->closing_balance;
				}	
				?>
				<tr>
					<td class="text-left" colspan="3"><?= $cash_closing_row->chart_of_accounts_code;?> - <?= $cash_closing_row->chart_of_accounts_name;?> <?= $this->lang->line('closing_balance');?></td>
					<td class="text-right"><?php if ($cash_closing_balance >0) { echo' '.number_format($cash_closing_balance, 2 . '').' ';} else if ($cash_closing_balance == 0) { echo'-';} else { echo''.number_format(abs($cash_closing_balance),2 . '').'';} ?></td>
				</tr>
				<?php }?>
				
				<?php 
				// Cash & Bank Closing Balance Information
				$bank_closing =  $this->db->select("*")
				->from('chart_of_accounts')
				->where('chart_of_accounts_general_ledger_receipt_payment_show', 2)
				->order_by('chart_of_accounts_code', 'ASC') 
				->get()
				->result();
				foreach($bank_closing as $bank_closing_row)
				{
				$closing_balance_query_bank =  $this->db->select("SUM(accounts_details_debit) as closing_debit_balance, SUM(accounts_details_credit) as closing_credit_balance, (SUM(accounts_details_debit) - SUM(accounts_details_credit)) as  closing_balance")
				->from('accounts_details')
				->where('accounts_details_general_ledger', $bank_closing_row->chart_of_accounts_id)
				
				->where('accounts_details_voucher_posting_date BETWEEN "'.$opening_balance_starting_date.'" and "'.$closing_date.'"')
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				foreach($closing_balance_query_bank as $closing_balance_query_bank_row)
				{
					$closing_debit_balance_bank		= $closing_balance_query_bank_row->closing_debit_balance;
					$closing_credit_balance_bank	= $closing_balance_query_bank_row->closing_credit_balance;
					$bank_closing_balance			= $closing_balance_query_bank_row->closing_balance; 
				}	
				?>
				<tr>
					<td class="text-left" colspan="3"><?= $bank_closing_row->chart_of_accounts_code;?> - <?= $bank_closing_row->chart_of_accounts_name;?> <?= $this->lang->line('closing_balance');?></td>
					<td class="text-right"><?php if ($bank_closing_balance >0) { echo' '.number_format($bank_closing_balance, 2 . '').' ';} else if ($bank_closing_balance == 0) { echo'-';} else { echo' ('.number_format(abs($bank_closing_balance),2 . '').')';} ?></td>
				</tr>
				<?php }?>
			</tbody>
		</table>	
		<?php } else {?>
		<?php 
		$opening_balance_starting_date = date('2015-01-01');
		$opening_balance_closing_date = date('Y-m-d', strtotime($starting_date. "last day"));
		?>
		<table class="table table-striped table-bordered table-hover">
			<thead class=" text-uppercase">
				<tr>  
					<th class="text-center" width="64%"><?= $this->lang->line('particulars');?></th>
					<th class="text-center" width="18%"><?= $this->lang->line('debit');?></th>
					<th class="text-center" width="18%"><?= $this->lang->line('credit');?></th>
					<th class="text-center" width="18%"><?= $this->lang->line('balance');?></th>
				</tr>
			</thead>
			<tbody>
				<?php 
				$opening_balance = 0;
				$cash_opening =  $this->db->select("*")
				->from('chart_of_accounts')
				->where('chart_of_accounts_general_ledger_receipt_payment_show', 1)
				->order_by('chart_of_accounts_code', 'ASC') 
				->get()
				->result();
				foreach($cash_opening as $cash_opening_row)
				{
				$cash_opening_balance_query =  $this->db->select("SUM(accounts_details_debit) as opening_debit_balance, SUM(accounts_details_credit) as opening_credit_balance")
				->from('accounts_details')
				->where('accounts_details_general_ledger', $cash_opening_row->chart_of_accounts_id)
				
				->where('accounts_details_voucher_posting_date BETWEEN "'.$opening_balance_starting_date.'" and "'.$opening_balance_closing_date.'"')
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				foreach($cash_opening_balance_query as $cash_opening_balance_row)
				{
					
					$cash_opening_debit		= $cash_opening_balance_row->opening_debit_balance;
					$cash_opening_credit	= $cash_opening_balance_row->opening_credit_balance;
					$cash_opening_balance 	= abs($cash_opening_debit - $cash_opening_credit);
				}	
				
				$opening_balance = $cash_opening_balance;
				?>
				<tr>
					<td class="text-left"><?= $cash_opening_row->chart_of_accounts_code;?> - <?= $cash_opening_row->chart_of_accounts_name;?> <?= $this->lang->line('opening_balance');?></td>
					<td class="text-right">-</td>
					<td class="text-right"><?php if ($cash_opening_balance >0) { echo' '.number_format($cash_opening_balance, 2 . '').' ';} else if ($cash_opening_balance == 0) { echo'-';} else { echo' '.number_format(abs($cash_opening_balance),2 . '').' ';} ?></td>
					<td class="text-right"><?php if ($cash_opening_balance >0) { echo' '.number_format($cash_opening_balance, 2 . '').' ';} else if ($cash_opening_balance == 0) { echo'-';} else { echo' ('.number_format(abs($cash_opening_balance),2 . '').') ';} ?></td>
				</tr>
				<?php }?>
				
				<?php 
				$bank_opening =  $this->db->select("*")
				->from('chart_of_accounts')
				->where('chart_of_accounts_general_ledger_receipt_payment_show', 2)
				->order_by('chart_of_accounts_code', 'ASC') 
				->get()
				->result();
				foreach($bank_opening as $bank_opening_row)
				{
				$bank_opening_balance_query =  $this->db->select("SUM(accounts_details_debit) as opening_debit_balance, SUM(accounts_details_credit) as opening_credit_balance")
				->from('accounts_details')
				->where('accounts_details_general_ledger', $bank_opening_row->chart_of_accounts_id)
				 
				->where('accounts_details_voucher_posting_date BETWEEN "'.$opening_balance_starting_date.'" and "'.$opening_balance_closing_date.'"')
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				foreach($bank_opening_balance_query as $bank_opening_balance_row)
				{
					$bank_opening_debit		= $bank_opening_balance_row->opening_debit_balance;
					$bank_opening_credit	= $bank_opening_balance_row->opening_credit_balance;
					
					$bank_opening_balance 	= abs($bank_opening_debit - $bank_opening_credit);
				} 
				$opening_balance += $bank_opening_balance;
				?>
				<tr>
					<td class="text-left"><?= $bank_opening_row->chart_of_accounts_code;?> - <?= $bank_opening_row->chart_of_accounts_name;?> <?= $this->lang->line('opening_balance');?></td>
					<td class="text-right">-</td>
					<td class="text-right"><?php if ($bank_opening_balance >0) { echo' '.number_format($bank_opening_balance, 2 . '').' ';} else if ($bank_opening_balance == 0) { echo'-';} else { echo' '.number_format(abs($bank_opening_balance),2 . '').' ';} ?></td>
					<td class="text-right"><?php if ($opening_balance >0) { echo' '.number_format($opening_balance, 2 . '').' ';} else if ($opening_balance == 0) { echo'-';} else { echo' ('.number_format(abs($opening_balance),2 . '').' )';} ?></td>
				</tr>
				<?php }?>
				
				<?php 
				$total_debit_balance = 0;
				$total_credit_balance = 0;
				$balance = $opening_balance;
				$coa_info =  $this->db->select("*")
				->from('accounts_details')
				->join('chart_of_accounts', 'accounts_details.accounts_details_subsidiary_ledger = chart_of_accounts.chart_of_accounts_id', 'LEFT')
				  
				->where('accounts_details.accounts_details_voucher_posting_date BETWEEN "'.$starting_date.'" and "'.$closing_date.'"')
				->where('accounts_details_control_group<>', 65)
				->where('accounts_details_voucher_type<>', 3)
				->group_by('accounts_details_subsidiary_ledger', 'ASC') 
				->order_by('chart_of_accounts_code', 'ASC') 
				->get()
				->result();
				foreach($coa_info as $coa_row)
				{
				
				$debit_info =  $this->db->select("SUM(accounts_details_debit) as debit_balance")
				->from('accounts_details')  
				->where('accounts_details_subsidiary_ledger', $coa_row->accounts_details_subsidiary_ledger) 
				
				->where('accounts_details_voucher_posting_date BETWEEN "'.$starting_date.'" and "'.$closing_date.'"')
				->where('accounts_details_control_group<>', 65)
				->where('accounts_details_voucher_type<>', 3) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				foreach($debit_info as $debit_row)
				{
					$debit_balance			= $debit_row->debit_balance;
					$total_debit_balance	+= $debit_balance;
				}
				
				$debit_info =  $this->db->select("SUM(accounts_details_credit) as credit_balance")
				->from('accounts_details')  
				->where('accounts_details_subsidiary_ledger', $coa_row->accounts_details_subsidiary_ledger)
				
				->where('accounts_details_voucher_posting_date BETWEEN "'.$starting_date.'" and "'.$closing_date.'"')
				->where('accounts_details_control_group<>', 65)
				->where('accounts_details_voucher_type<>', 3) 
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				foreach($debit_info as $debit_row)
				{
					$credit_balance			= $debit_row->credit_balance;
					$total_credit_balance	+= $credit_balance;
				}
					$balance += $credit_balance-$debit_balance;
				?>
				<tr>
					<td class="text-left bd-bottom-double">&nbsp; <?= $coa_row->chart_of_accounts_code;?> - <?= $coa_row->chart_of_accounts_name;?></td>
					<td class="text-right"><?php if ($debit_balance >0) { echo' '.number_format($debit_balance, 2 . '').' ';} else if ($debit_balance == 0) { echo'-';} else { echo' '.number_format(abs($debit_balance),2 . '').' ';} ?></td>
					<td class="text-right"><?php if ($credit_balance >0) { echo' '.number_format($credit_balance, 2 . '').' ';} else if ($credit_balance == 0) { echo'-';} else { echo' '.number_format(abs($credit_balance),2 . '').' ';} ?></td>
					<td class="text-right"><?php if ($balance >0) { echo' '.number_format($balance, 2 . '').' ';} else if ($balance == 0) { echo'-';} else { echo' ('.number_format(abs($balance),2 . '').')';} ?></td>
				</tr>
				<?php }
				$total_debit_balance_amount		= $total_debit_balance;
				$total_credit_balance_amount	= $total_credit_balance + $opening_balance;
				?>
				<tr class="text-uppercase">
					<th class="text-center"><?= $this->lang->line('total');?></th> 
					<th class="text-right"><?php if ($total_debit_balance_amount >0) { echo' '.number_format($total_debit_balance_amount, 2 . '').' ';} else if ($total_debit_balance_amount == 0) { echo'-';} else { echo' '.number_format(abs($total_debit_balance_amount),2 . '').' ';} ?></th> 
					<th class="text-right"><?php if ($total_credit_balance_amount >0) { echo' '.number_format($total_credit_balance_amount, 2 . '').' ';} else if ($total_credit_balance_amount == 0) { echo'-';} else { echo' '.number_format(abs($total_credit_balance_amount),2 . '').' ';} ?></th> 
					<th class="text-right"><?php if ($balance >0) { echo' '.number_format($balance, 2 . '').' ';} else if ($balance == 0) { echo'-';} else { echo'('.number_format(abs($balance),2 . '').')';} ?></th> 
				</tr>
				
				<?php 
				// Cash & Bank Closing Balance Information
				$cash_closing =  $this->db->select("*")
				->from('chart_of_accounts')
				->where('chart_of_accounts_general_ledger_receipt_payment_show', 1)
				->order_by('chart_of_accounts_code', 'ASC') 
				->get()
				->result();
				foreach($cash_closing as $cash_closing_row)
				{
				$closing_balance_query_cash =  $this->db->select("SUM(accounts_details_debit) as closing_debit_balance, SUM(accounts_details_credit) as closing_credit_balance, (SUM(accounts_details_debit) - SUM(accounts_details_credit)) as  closing_balance")
				->from('accounts_details')
				->where('accounts_details_general_ledger', $cash_closing_row->chart_of_accounts_id)
				
				->where('accounts_details_voucher_posting_date BETWEEN "'.$opening_balance_starting_date.'" and "'.$closing_date.'"')
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				foreach($closing_balance_query_cash as $closing_balance_query_cash_row)
				{
					$closing_debit_balance_cash		= $closing_balance_query_cash_row->closing_debit_balance;
					$closing_credit_balance_cash	= $closing_balance_query_cash_row->closing_credit_balance;
					$cash_closing_balance			= $closing_balance_query_cash_row->closing_balance;
				}	
				?>
				<tr>
					<td class="text-left" colspan="3"><?= $cash_closing_row->chart_of_accounts_code;?> - <?= $cash_closing_row->chart_of_accounts_name;?> <?= $this->lang->line('closing_balance');?></td>
					<td class="text-right"><?php if ($cash_closing_balance >0) { echo' '.number_format($cash_closing_balance, 2 . '').' ';} else if ($cash_closing_balance == 0) { echo'-';} else { echo''.number_format(abs($cash_closing_balance),2 . '').'';} ?></td>
				</tr>
				<?php }?>
				
				<?php 
				// Cash & Bank Closing Balance Information
				$bank_closing =  $this->db->select("*")
				->from('chart_of_accounts')
				->where('chart_of_accounts_general_ledger_receipt_payment_show', 2)
				->order_by('chart_of_accounts_code', 'ASC') 
				->get()
				->result();
				foreach($bank_closing as $bank_closing_row)
				{
				$closing_balance_query_bank =  $this->db->select("SUM(accounts_details_debit) as closing_debit_balance, SUM(accounts_details_credit) as closing_credit_balance, (SUM(accounts_details_debit) - SUM(accounts_details_credit)) as  closing_balance")
				->from('accounts_details')
				->where('accounts_details_general_ledger', $bank_closing_row->chart_of_accounts_id)
				
				->where('accounts_details_voucher_posting_date BETWEEN "'.$opening_balance_starting_date.'" and "'.$closing_date.'"')
				->order_by('accounts_details_voucher_posting_date', 'ASC') 
				->get()
				->result();
				foreach($closing_balance_query_bank as $closing_balance_query_bank_row)
				{
					$closing_debit_balance_bank		= $closing_balance_query_bank_row->closing_debit_balance;
					$closing_credit_balance_bank	= $closing_balance_query_bank_row->closing_credit_balance;
					$bank_closing_balance			= $closing_balance_query_bank_row->closing_balance; 
				}	
				?>
				<tr>
					<td class="text-left" colspan="3"><?= $bank_closing_row->chart_of_accounts_code;?> - <?= $bank_closing_row->chart_of_accounts_name;?> <?= $this->lang->line('closing_balance');?></td>
					<td class="text-right"><?php if ($bank_closing_balance >0) { echo' '.number_format($bank_closing_balance, 2 . '').' ';} else if ($bank_closing_balance == 0) { echo'-';} else { echo' ('.number_format(abs($bank_closing_balance),2 . '').')';} ?></td>
				</tr>
				<?php }?>
			</tbody>
		</table>
		<?php }?>
		
		<?php 
		return $output;
	}
	
	/* ------------------------------------------------------
	Cash Book Ledger Model
	------------------------------------------------------- */
	function cash_book_ledger($from_date, $to_date)
	{
		$opening_balance_starting_date = date('2015-01-01');
		$opening_balance_closing_date = date('Y-m-d', strtotime($from_date. "last day"));
		
		$output = '';
		
		$serial = 0;
		$opening_balance = 0;
		
		$cash_opening =  $this->db->select("*")
		->from('chart_of_accounts')
		->where('chart_of_accounts_general_ledger_receipt_payment_show', 1)
		->order_by('chart_of_accounts_code', 'ASC') 
		->get()
		->result();
		foreach($cash_opening as $cash_opening_row)
		{
		$cash_opening_balance_query =  $this->db->select("SUM(accounts_details_debit) as opening_debit_balance, SUM(accounts_details_credit) as opening_credit_balance")
		->from('accounts_details')
		->where('accounts_details_general_ledger', $cash_opening_row->chart_of_accounts_id)
		
		->where('accounts_details_voucher_posting_date BETWEEN "'.$opening_balance_starting_date.'" and "'.$opening_balance_closing_date.'"')
		->order_by('accounts_details_voucher_posting_date', 'ASC')
		->get()
		->result();
		foreach($cash_opening_balance_query as $cash_opening_balance_row)
		{
			
			$cash_opening_debit		= $cash_opening_balance_row->opening_debit_balance;
			$cash_opening_credit	= $cash_opening_balance_row->opening_credit_balance;
			$cash_opening_balance 	= abs($cash_opening_credit- $cash_opening_debit);
		}	
		
		$opening_balance = $cash_opening_balance;
		?>
		<tr>
			<td class="text-center"><?= str_pad(++$serial, 2, '0', STR_PAD_LEFT);?></td> 
			<td class="text-left" colspan="4"><?= $cash_opening_row->chart_of_accounts_code;?> - <?= $cash_opening_row->chart_of_accounts_name;?> <?= $this->lang->line('opening_balance');?></td>
			<td class="text-right">-</td>
			<td class="text-right"><?php if ($cash_opening_balance >0) { echo' '.number_format($cash_opening_balance, 2 . '').' ';} else if ($cash_opening_balance == 0) { echo'-';} else { echo' '.number_format(abs($cash_opening_balance),2 . '').' ';} ?></td>
			<td class="text-right"><?php if ($cash_opening_balance >0) { echo' '.number_format($cash_opening_balance, 2 . '').' ';} else if ($cash_opening_balance == 0) { echo'-';} else { echo' '.number_format(abs($cash_opening_balance),2 . '').' ';} ?></td>
		</tr>
		<?php }?>
		
		<?php 
		$serial = $serial;
		$bank_opening =  $this->db->select("*")
		->from('chart_of_accounts')
		->where('chart_of_accounts_general_ledger_receipt_payment_show', 2)
		->order_by('chart_of_accounts_code', 'ASC') 
		->get()
		->result();
		foreach($bank_opening as $bank_opening_row)
		{
		$bank_opening_balance_query =  $this->db->select("SUM(accounts_details_debit) as opening_debit_balance, SUM(accounts_details_credit) as opening_credit_balance")
		->from('accounts_details')
		->where('accounts_details_general_ledger', $bank_opening_row->chart_of_accounts_id)
		
		->where('accounts_details_voucher_posting_date BETWEEN "'.$opening_balance_starting_date.'" and "'.$opening_balance_closing_date.'"')
		->order_by('accounts_details_voucher_posting_date', 'ASC') 
		->get()
		->result();
		foreach($bank_opening_balance_query as $bank_opening_balance_row)
		{
			$bank_opening_debit		= $bank_opening_balance_row->opening_debit_balance;
			$bank_opening_credit	= $bank_opening_balance_row->opening_credit_balance;
			
			$bank_opening_balance 	= abs($bank_opening_credit - $bank_opening_debit);
		} 
		$opening_balance += $bank_opening_balance;
		?>
		<tr>
			<td class="text-center"><?= str_pad(++$serial, 2, '0', STR_PAD_LEFT);?></td> 
			<td class="text-left" colspan="4"><?= $bank_opening_row->chart_of_accounts_code;?> - <?= $bank_opening_row->chart_of_accounts_name;?> <?= $this->lang->line('opening_balance');?></td> 
			<td class="text-right">-</td> 
			<td class="text-right"><?php if ($bank_opening_balance >0) { echo' '.number_format($bank_opening_balance, 2 . '').' ';} else if ($bank_opening_balance == 0) { echo'-';} else { echo' '.number_format(abs($bank_opening_balance),2 . '').' ';} ?></td>
			<td class="text-right"><?php if ($opening_balance >0) { echo' '.number_format($opening_balance, 2 . '').' ';} else if ($opening_balance == 0) { echo'-';} else { echo' '.number_format(abs($opening_balance),2 . '').' ';} ?></td>
		</tr>
		<?php }?>
		
		<?php 
		
		$serial = $serial;
		$accounts_details_debit = 0;
		$accounts_details_credit = $opening_balance; 
		$amount_balance = $opening_balance;
		
		$control_group =  $this->db->select("*")
		->from('accounts_details') 
		->join('chart_of_accounts', 'accounts_details.accounts_details_control_group = chart_of_accounts.chart_of_accounts_id', 'LEFT') 
		
		->where('accounts_details_general_ledger <>', 77)
		->where('accounts_details_general_ledger <>', 80) 
		->where('accounts_details_voucher_type <>', 3,4)
		->where('accounts_details_voucher_posting_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
		->order_by('chart_of_accounts_code', 'ASC')
		->group_by('accounts_details_control_group', 'ASC')
		->get()
		->result();
		
		foreach($control_group as $control_group_row)
		{ 
			$control_group_count =  $this->db->select("COUNT(DISTINCT accounts_details_id) AS control_group_number")
			->from('accounts_details')  
			
			->where('accounts_details.accounts_details_control_group', $control_group_row->accounts_details_control_group)
			->where('accounts_details_general_ledger <>', 77)
			->where('accounts_details_general_ledger <>', 80) 
			->where('accounts_details_voucher_type <>', 3,4)
			->where('accounts_details_voucher_posting_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
			->order_by('accounts_details_id', 'ASC')
			->get()
			->result();
			foreach($control_group_count as $control_group_count_row)
			{
				$control_group_number = $control_group_count_row->control_group_number;
			}
		?> 
		<tr>
			<td class="text-center" rowspan="<?= $control_group_number;?>"><?= str_pad(++$serial, 2, '0', STR_PAD_LEFT);?></td>
			<td class="text-left" rowspan="<?= $control_group_number;?>" title="<?= $control_group_row->accounts_details_id;?>"><?= $control_group_row->chart_of_accounts_code;?> - <?= $control_group_row->chart_of_accounts_name;?></td>
			
			<?php 
			$ledger_list =  $this->db->select("DISTINCT(chart_of_accounts_id), chart_of_accounts_code, chart_of_accounts_name")
			->from('accounts_details') 
			->join('chart_of_accounts', 'accounts_details.accounts_details_general_ledger = chart_of_accounts.chart_of_accounts_id', 'LEFT')
			
			->where('accounts_details.accounts_details_control_group', $control_group_row->accounts_details_control_group)  
			->where('accounts_details_general_ledger <>', 77)
			->where('accounts_details_general_ledger <>', 80) 
			->where('accounts_details_voucher_type <>', 3,4)
			->where('accounts_details.accounts_details_voucher_posting_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
			->order_by('accounts_details.accounts_details_voucher_posting_date', 'ASC')
			->order_by('chart_of_accounts.chart_of_accounts_code', 'ASC')
			->get()
			->result();
			
			$output = '';
			
			foreach($ledger_list as $ledger_row)
			{
				
			$ledger_count =  $this->db->select("COUNT(DISTINCT accounts_details_id) AS ledger_number")
			->from('accounts_details') 
			->where('accounts_details.accounts_details_general_ledger', $ledger_row->chart_of_accounts_id) 
			
			->where('accounts_details_general_ledger <>', 77)
			->where('accounts_details_general_ledger <>', 80) 
			->where('accounts_details_voucher_type <>', 3,4)
			->where('accounts_details.accounts_details_control_group', $control_group_row->accounts_details_control_group) 
			->where('accounts_details.accounts_details_voucher_posting_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
			->order_by('accounts_details.accounts_details_id', 'ASC')
			->get()
			->result();
			foreach($ledger_count as $ledger_row_count)
			{
				$ledger_number = $ledger_row_count->ledger_number;
			}?>
			<td class="text-left" rowspan="<?= $ledger_number;?>"><?= $ledger_row->chart_of_accounts_code;?> - <?= $ledger_row->chart_of_accounts_name;?></td>
			
			<?php $accounts_amount =  $this->db->select("*")
			->from('accounts_details') 
			->join('chart_of_accounts', 'accounts_details.accounts_details_subsidiary_ledger = chart_of_accounts.chart_of_accounts_id', 'LEFT')  
			->where('accounts_details.accounts_details_general_ledger', $ledger_row->chart_of_accounts_id)
			
			->where('accounts_details_general_ledger <>', 77)
			->where('accounts_details_general_ledger <>', 80) 
			->where('accounts_details_voucher_type <>', 3,4)
			->where('accounts_details.accounts_details_voucher_posting_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
			->order_by('accounts_details.accounts_details_voucher_posting_date', 'ASC')
			->order_by('accounts_details.accounts_details_id', 'ASC')
			->get()
			->result(); 
			
			foreach($accounts_amount as $accounts_amount_row)
			{
				$amount_balance_calculate = $accounts_amount_row->accounts_details_credit - $accounts_amount_row->accounts_details_debit;
				
				$accounts_details_debit 	+= $accounts_amount_row->accounts_details_debit;
				$accounts_details_credit 	+= $accounts_amount_row->accounts_details_credit;
				
				$amount_balance 			+= $amount_balance_calculate;
			?>  
			<td class="text-left"><?= $accounts_amount_row->chart_of_accounts_code;?> - <?= $accounts_amount_row->chart_of_accounts_name;?></td>
			<td class="text-center"><?= $accounts_amount_row->accounts_details_voucher_number;?></td>
			<td class="text-right"><?= number_format($accounts_amount_row->accounts_details_debit, 2 . '');?></td>
			<td class="text-right"><?= number_format($accounts_amount_row->accounts_details_credit, 2 . '');?></td> 
			<td class="text-right"><?php if ($amount_balance >0) { echo' '.number_format($amount_balance, 2 . '').' ';} else if ($amount_balance == 0) { echo'-';} else { echo' '.number_format(abs($amount_balance),2 . '').' ';} ?></td>
		</tr>
		<?php } } }
		?>
		
		<tr class="text-uppercase">
			<th class="text-center" colspan="5"><?= $this->lang->line('total');?></th> 
			<th class="text-right"><?php if ($accounts_details_debit >0) { echo' '.number_format($accounts_details_debit, 2 . '').' ';} else if ($accounts_details_debit == 0) { echo'-';} else { echo' '.number_format(abs($accounts_details_debit),2 . '').' ';} ?></th>
			<th class="text-right"><?php if ($accounts_details_credit >0) { echo' '.number_format($accounts_details_credit, 2 . '').' ';} else if ($accounts_details_credit == 0) { echo'-';} else { echo' '.number_format(abs($accounts_details_credit),2 . '').' ';} ?></th>
			<th class="text-right"><?php if ($amount_balance >0) { echo' '.number_format($amount_balance, 2 . '').' ';} else if ($amount_balance == 0) { echo'-';} else { echo' '.number_format(abs($amount_balance),2 . '').' ';} ?></th>
		</tr>
		<?php $cash_closing =  $this->db->select("*")
		->from('chart_of_accounts')
		->where('chart_of_accounts_general_ledger_receipt_payment_show', 1)
		->order_by('chart_of_accounts_code', 'ASC') 
		->get()
		->result();
		foreach($cash_closing as $cash_closing_row)
		{
		$cash_closing_balance_query =  $this->db->select("SUM(accounts_details_debit) as closing_debit_balance, SUM(accounts_details_credit) as closing_credit_balance")
		->from('accounts_details')
		
		->where('accounts_details_general_ledger', $cash_closing_row->chart_of_accounts_id)
		->where('accounts_details_voucher_posting_date BETWEEN "'.$opening_balance_starting_date.'" and "'.$to_date.'"')
		->order_by('accounts_details_voucher_posting_date', 'ASC') 
		->get()
		->result();
		foreach($cash_closing_balance_query as $cash_closing_balance_row)
		{
			
			$cash_closing_debit		= $cash_closing_balance_row->closing_debit_balance;
			$cash_closing_credit	= $cash_closing_balance_row->closing_credit_balance;
			$cash_closing_balance 	= abs($cash_closing_debit - $cash_closing_credit);
		}	
		
		?>
		<tr>
			<td class="text-center"><?= str_pad(++$serial, 2, '0', STR_PAD_LEFT);?></td> 
			<td class="text-left" colspan="6"><?= $cash_closing_row->chart_of_accounts_code;?> - <?= $cash_closing_row->chart_of_accounts_name;?> <?= $this->lang->line('closing_balance');?></td>
			<td class="text-right"><?php if ($cash_closing_balance >0) { echo' '.number_format($cash_closing_balance, 2 . '').' ';} else if ($cash_closing_balance == 0) { echo'-';} else { echo' '.number_format(abs($cash_closing_balance),2 . '').' ';} ?></td>
		</tr>
		<?php }?>
		
		<?php 
		$serial = $serial;
		$bank_closing =  $this->db->select("*")
		->from('chart_of_accounts')
		->where('chart_of_accounts_general_ledger_receipt_payment_show', 2)
		->order_by('chart_of_accounts_code', 'ASC') 
		->get()
		->result();
		foreach($bank_closing as $bank_closing_row)
		{
		$bank_closing_balance_query =  $this->db->select("SUM(accounts_details_debit) as closing_debit_balance, SUM(accounts_details_credit) as closing_credit_balance")
		->from('accounts_details')
		->where('accounts_details_general_ledger', $bank_closing_row->chart_of_accounts_id)
		
		->where('accounts_details_voucher_posting_date BETWEEN "'.$opening_balance_starting_date.'" and "'.$to_date.'"')
		->order_by('accounts_details_voucher_posting_date', 'ASC') 
		->get()
		->result();
		foreach($bank_closing_balance_query as $bank_closing_balance_row)
		{
			$bank_closing_debit		= $bank_closing_balance_row->closing_debit_balance;
			$bank_closing_credit	= $bank_closing_balance_row->closing_credit_balance;
			
			$bank_closing_balance 	= abs($bank_closing_debit - $bank_closing_credit);
		} 
		?>
		<tr>
			<td class="text-center"><?= str_pad(++$serial, 2, '0', STR_PAD_LEFT);?></td>
			<td class="text-left" colspan="6"><?= $bank_closing_row->chart_of_accounts_code;?> - <?= $bank_closing_row->chart_of_accounts_name;?> <?= $this->lang->line('closing_balance');?></td>
			<td class="text-right"><?php if ($bank_closing_balance >0) { echo' '.number_format($bank_closing_balance, 2 . '').' ';} else if ($bank_closing_balance == 0) { echo'-';} else { echo' '.number_format(abs($bank_closing_balance),2 . '').' ';} ?></td>
		</tr>
		<?php }?>
	<?php  
		return $output;
	}
	
	/* ------------------------------------------------------
	Cash Flow Statements Model
	------------------------------------------------------- */
	function cash_flow_statement($closing_month)
	{	
		$output = '';
		
		// Current Month Date Calculation ..
		$opening_balance_starting_date = date('2015-01-01');
		// Current Month Date Calculation ..
		$current_month_opening_balance_end_date = date('Y-m-t', strtotime($closing_month. "last day"));
		
		$current_month_start_date = date('Y-m-01', strtotime($closing_month));
		$current_month_end_date =  date('Y-m-t', strtotime($closing_month)); 
		
		$current_last_month_start_date = date('Y-m-01', strtotime($closing_month. "last month"));
		$current_last_month_end_date =  date('Y-m-t', strtotime($closing_month. "last month")); 
		$current_last_month_opening_balance_end_date =  date('Y-m-t', strtotime($closing_month. "last month". "last day"));
		
		$current_previous_month_start_date = date('Y-m-01', strtotime($closing_month. "last month". "last month"));
		$current_previous_month_end_date =  date('Y-m-t', strtotime($closing_month. "last month". "last month"));
		
		$quarterly_start_date = date('Y-m-01', strtotime($closing_month. "last month". "last month"));
		$quarterly_end_date =  date('Y-m-t', strtotime($closing_month)); 
		
		// last Month Date Calculation ..
		if (date('m', strtotime($closing_month)) < '07') {
		$last_month_start_date	= date('Y-07-01', strtotime($closing_month. "last year"));
		} else {
		$last_month_start_date = date('Y-07-01', strtotime($closing_month));
		} 
		$last_month_end_date	= date('Y-m-t', strtotime($closing_month. "last month"));
		
		// previous Month Date Calculation ..
		if (date('m', strtotime($closing_month)) < '07') {
		$previous_month_start_date	= date('Y-07-01', strtotime($closing_month. "last year"));
		} else {
		$previous_month_start_date = date('Y-07-01', strtotime($closing_month));
		} 
		$previous_month_end_date	= date('Y-m-t', strtotime($closing_month. "last month". "last month"));
		
		// Current Year Date Calculation ..
		if (date('m', strtotime($closing_month)) < '07') {
		$current_year_start			= date('Y', strtotime($closing_month. "last year"));
		$current_year_end			= date('y', strtotime($closing_month));
		
		$current_year_start_date	= date('Y-07-01', strtotime($closing_month. "last year"));
		$current_year_end_date		= date('Y-06-30', strtotime($closing_month));
		$current_year_opening_balance_end_date	= date('Y-06-30', strtotime($closing_month. "last year". "last day"));
		} else {
		$current_year_start			= date('Y', strtotime($closing_month));
		$current_year_end			= date('y', strtotime($closing_month. "+1 year"));
		
		$current_year_start_date	= date('Y-07-01', strtotime($closing_month));
		$current_year_end_date		= date('Y-06-30', strtotime($closing_month. "+1 year"));
		$current_year_opening_balance_end_date	= date('Y-06-30', strtotime($closing_month. "last day"));
		} 
		
		// last Year Date Calculation ..
		if (date('m', strtotime($closing_month)) < '07') {
		$last_year_start		= date('Y', strtotime($closing_month. "last year". "last year"));
		$last_year_end			= date('y', strtotime($closing_month. "last year"));
		$last_year_start_date	= date('Y-07-01', strtotime($closing_month. "last year". "last year"));
		$last_year_end_date		= date('Y-06-30', strtotime($closing_month. "last year"));
		$last_year_opening_balance_end_date	= date('Y-06-30', strtotime($closing_month. "last year". "last year". "last day"));
		} else {
		$last_year_start		= date('Y', strtotime($closing_month. "last year"));
		$last_year_end			= date('y', strtotime($closing_month));
		$last_year_start_date	= date('Y-07-01', strtotime($closing_month. "last year"));
		$last_year_end_date		= date('Y-06-30', strtotime($closing_month));
		$last_year_opening_balance_end_date	= date('Y-06-30', strtotime($closing_month. "last year". "last day"));
		} 
		
		// previous Year Date Calculation ..
		if (date('m', strtotime($closing_month)) < '07') {
		$previous_year_start		= date('Y', strtotime($closing_month. "last year". "last year". "last year"));
		$previous_year_end			= date('y', strtotime($closing_month. "last year". "last year"));
		$previous_year_start_date	= date('Y-07-01', strtotime($closing_month. "last year". "last year". "last year"));
		$previous_year_end_date		= date('Y-06-30', strtotime($closing_month. "last year". "last year"));
		$previous_year_opening_balance_end_date		= date('Y-06-30', strtotime($closing_month. "last year". "last year". "last year". "last day"));
		} else {
		$previous_year_start		= date('Y', strtotime($closing_month. "last year". "last year"));
		$previous_year_end			= date('y', strtotime($closing_month. "last year"));
		$previous_year_start_date	= date('Y-07-01', strtotime($closing_month. "last year". "last year"));
		$previous_year_end_date		= date('Y-06-30', strtotime($closing_month. "last year"));
		$previous_year_opening_balance_end_date		= date('Y-06-30', strtotime($closing_month. "last year". "last year". "last day"));
		}?>
		
		<table class="table-hover" width="100%" align="center">
			<thead class="text-uppercase">
				<tr class="table-bordered">  
					<th class="text-center" rowspan="2" width="28%"><?= $this->lang->line('particulars');?></th>
					<th class="text-center" colspan="8"><?= $this->lang->line('amount');?></th>
				</tr>
				<tr class="table-bordered">  
					<th class="text-center" colspan="2" width="11%">
						<?= date('M-y', strtotime($closing_month));?>
					</th>
					<th class="text-center" colspan="2" width="11%">
						<?= date('M-y', strtotime($closing_month. "last month"));?>
					</th>
					<th class="text-center" colspan="2" width="11%">
						FY <?= $current_year_start;?>-<?= $current_year_end;?>
					</th>
					<th class="text-center" colspan="2" width="12%">
						FY <?= $last_year_start;?>-<?= $last_year_end;?>
					</th>
				</tr>
			</thead>
			<tbody>
				<tr class="text-uppercase">
					<th class="text-left "colspan="9">A. Cash Flow from Operating Activities</th>
				</tr>
				<?php 
				// Income ....
				$accounts_type_income = $this->db->select("*") ->from('accounts_type') ->where('accounts_type_id', 300000) ->order_by('accounts_type_code', 'ASC') ->get()->result();
				foreach ($accounts_type_income as $accounts_type_income_row)
				{
					$total_current_month_income = 0.00;
					$total_last_month_income = 0.00;
					$total_previous_month_income = 0.00;
					$total_current_year_income = 0.00;
					$total_last_year_income = 0.00;
					$total_previous_year_income = 0.00;
					
					$accounts_category_income = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_type_income_row->accounts_type_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
					foreach ($accounts_category_income as $accounts_category_income_row) 
					{
						$current_month_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_month_income_balance") 
						->from('accounts_details')
						
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
						->where('accounts_details_accounts_category', $accounts_category_income_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($current_month_income as $current_month_income_row)
						{
						$current_month_income_balance = $current_month_income_row->current_month_income_balance;
						$total_current_month_income  += $current_month_income_balance;
						}
						
						$last_month_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS last_month_income_balance") 
						->from('accounts_details')
						
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_last_month_start_date.'" and "'.$current_last_month_end_date.'"')
						->where('accounts_details_accounts_category', $accounts_category_income_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($last_month_income as $last_month_income_row)
						{
						$last_month_income_balance = $last_month_income_row->last_month_income_balance;
						$total_last_month_income  += $last_month_income_balance;
						}
						
						$current_year_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_year_income_balance") 
						->from('accounts_details')
						
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_year_start_date.'" and "'.$current_year_end_date.'"')
						->where('accounts_details_accounts_category', $accounts_category_income_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($current_year_income as $current_year_income_row)
						{
						$current_year_income_balance = $current_year_income_row->current_year_income_balance;
						$total_current_year_income  += $current_year_income_balance;
						}
						
						$last_year_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS last_year_income_balance") 
						->from('accounts_details')
						
						->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
						->where('accounts_details_accounts_category', $accounts_category_income_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($last_year_income as $last_year_income_row)
						{
						$last_year_income_balance = $last_year_income_row->last_year_income_balance;
						$total_last_year_income  += $last_year_income_balance;
						}
						
						$previous_year_income = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS previous_year_income_balance") 
						->from('accounts_details')
						
						->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_year_start_date.'" and "'.$previous_year_end_date.'"')
						->where('accounts_details_accounts_category', $accounts_category_income_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($previous_year_income as $previous_year_income_row)
						{
						$previous_year_income_balance = $previous_year_income_row->previous_year_income_balance;
						$total_previous_year_income  += $previous_year_income_balance;
						}
					} 
				}
				
				// expenditure ..   
				$accounts_type_expenditure = $this->db->select("*") ->from('accounts_type') ->where('accounts_type_id', 400000) ->order_by('accounts_type_code', 'ASC') ->get()->result();
				foreach ($accounts_type_expenditure as $accounts_type_expenditure_row)
				{
					$total_current_month_expenditure = 0.00;
					$total_last_month_expenditure = 0.00;
					$total_previous_month_expenditure = 0.00;
					$total_current_year_expenditure = 0.00;
					$total_last_year_expenditure = 0.00;
					$total_previous_year_expenditure = 0.00;
					
					$accounts_category_expenditure = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_type_expenditure_row->accounts_type_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
					foreach ($accounts_category_expenditure as $accounts_category_expenditure_row)
					{
						$current_month_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_month_expenditure_balance") 
						->from('accounts_details')
						
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
						->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($current_month_expenditure as $current_month_expenditure_row)
						{
						$current_month_expenditure_balance = $current_month_expenditure_row->current_month_expenditure_balance;
						$total_current_month_expenditure  += $current_month_expenditure_balance;
						}
						
						$last_month_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS last_month_expenditure_balance") 
						->from('accounts_details')
						
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_last_month_start_date.'" and "'.$current_last_month_end_date.'"')
						->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($last_month_expenditure as $last_month_expenditure_row)
						{
						$last_month_expenditure_balance = $last_month_expenditure_row->last_month_expenditure_balance;
						$total_last_month_expenditure  += $last_month_expenditure_balance;
						}
						
						$current_year_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_year_expenditure_balance") 
						->from('accounts_details')
						
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_year_start_date.'" and "'.$current_year_end_date.'"')
						->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($current_year_expenditure as $current_year_expenditure_row)
						{
						$current_year_expenditure_balance = $current_year_expenditure_row->current_year_expenditure_balance;
						$total_current_year_expenditure  += $current_year_expenditure_balance;
						}
						
						$last_year_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS last_year_expenditure_balance") 
						->from('accounts_details')
						
						->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
						->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($last_year_expenditure as $last_year_expenditure_row)
						{
						$last_year_expenditure_balance = $last_year_expenditure_row->last_year_expenditure_balance;
						$total_last_year_expenditure  += $last_year_expenditure_balance;
						}
						
						$previous_year_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS previous_year_expenditure_balance") 
						->from('accounts_details')
						
						->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_year_start_date.'" and "'.$previous_year_end_date.'"')
						->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						foreach($previous_year_expenditure as $previous_year_expenditure_row)
						{
						$previous_year_expenditure_balance = $previous_year_expenditure_row->previous_year_expenditure_balance;
						$total_previous_year_expenditure  += $previous_year_expenditure_balance;
						}  
					} 
				} 
				$total_current_month_surplus_deficit	= $total_current_month_income - $total_current_month_expenditure;
				$total_last_month_surplus_deficit		= $total_last_month_income - $total_last_month_expenditure;
				$total_current_year_surplus_deficit		= $total_current_year_income - $total_current_year_expenditure;
				$total_last_year_surplus_deficit		= $total_last_year_income - $total_last_year_expenditure;
				$total_previous_year_surplus_deficit	= $total_previous_year_income - $total_previous_year_expenditure;
				?>
				<tr>
					<td class="text-left">&nbsp; Excess of Income over Expenditure</td>
					<td class="text-center" width="1%"></td>
					<td class="text-right"><?php if ($total_current_month_surplus_deficit >0) { echo' '.number_format($total_current_month_surplus_deficit, 2 . '').' ';} else if($total_current_month_surplus_deficit ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_month_surplus_deficit), 2 . '').') ';} ?></td>
					<td class="text-center" width="1%"></td>
					<td class="text-right"><?php if ($total_last_month_surplus_deficit >0) { echo' '.number_format($total_last_month_surplus_deficit, 2 . '').' ';} else if($total_last_month_surplus_deficit ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_month_surplus_deficit), 2 . '').') ';} ?></td>
					<td class="text-center" width="1%"></td>
					<td class="text-right"><?php if ($total_current_year_surplus_deficit >0) { echo' '.number_format($total_current_year_surplus_deficit, 2 . '').' ';} else if($total_current_year_surplus_deficit ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_year_surplus_deficit), 2 . '').') ';} ?></td>
					<td class="text-center" width="1%"></td>
					<td class="text-right"><?php if ($total_last_year_surplus_deficit >0) { echo' '.number_format($total_last_year_surplus_deficit, 2 . '').' ';} else if($total_last_year_surplus_deficit ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_year_surplus_deficit), 2 . '').') ';} ?></td>
					
				</tr>
				
				<?php 
				$current_month_depreciation_balance = 0;
				$last_month_depreciation_balance = 0;
				$current_year_depreciation_balance = 0;
				$last_year_depreciation_balance = 0;
				$previous_year_depreciation_balance = 0;
				$category_depreciation =  $this->db->select("*")
				->from('chart_of_accounts')  
				->or_where('chart_of_accounts_id', 288)
				->order_by('chart_of_accounts_code', 'ASC')
				->get()
				->result();
				foreach($category_depreciation as $category_depreciation_row)
				{
					$current_month_depreciation_query = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_month_depreciation_balance") 
					->from('accounts_details')
					
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
					->where('accounts_details_control_group', $category_depreciation_row->chart_of_accounts_id)
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($current_month_depreciation_query as $current_month_depreciation_query_row)
					{
						$current_month_depreciation_balance = $current_month_depreciation_query_row->current_month_depreciation_balance;
					}
					
					$last_month_depreciation_query = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS last_month_depreciation_balance") 
					->from('accounts_details')
					
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_last_month_start_date.'" and "'.$current_last_month_end_date.'"')
					->where('accounts_details_control_group', $category_depreciation_row->chart_of_accounts_id)
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($last_month_depreciation_query as $last_month_depreciation_query_row)
					{
						$last_month_depreciation_balance = $last_month_depreciation_query_row->last_month_depreciation_balance;
					}
					
					$current_year_depreciation_query = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_year_depreciation_balance") 
					->from('accounts_details')
					
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_year_start_date.'" and "'.$current_year_end_date.'"')
					->where('accounts_details_control_group', $category_depreciation_row->chart_of_accounts_id)
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($current_year_depreciation_query as $current_year_depreciation_query_row)
					{
						$current_year_depreciation_balance = $current_year_depreciation_query_row->current_year_depreciation_balance;
					}
					
					$last_year_depreciation_query = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS last_year_depreciation_balance") 
					->from('accounts_details')
					
					->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
					->where('accounts_details_control_group', $category_depreciation_row->chart_of_accounts_id)
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($last_year_depreciation_query as $last_year_depreciation_query_row)
					{
						$last_year_depreciation_balance = $last_year_depreciation_query_row->last_year_depreciation_balance;
					}
					
					$previous_year_depreciation_query = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS previous_year_depreciation_balance") 
					->from('accounts_details')
					
					->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_year_start_date.'" and "'.$previous_year_end_date.'"')
					->where('accounts_details_control_group', $category_depreciation_row->chart_of_accounts_id)
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($previous_year_depreciation_query as $previous_year_depreciation_query_row)
					{
						$previous_year_depreciation_balance = $previous_year_depreciation_query_row->previous_year_depreciation_balance;
					}
					?>	
				<tr>
					<td class="text-left">&nbsp; <?= $category_depreciation_row->chart_of_accounts_code;?> - <?= $category_depreciation_row->chart_of_accounts_name;?></td>
					<td class="text-center" width="1%"></td>
					<td class="text-right"><?php if ($current_month_depreciation_balance >0) { echo' '.number_format($current_month_depreciation_balance, 2 . '').' ';} else if($current_month_depreciation_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_month_depreciation_balance), 2 . '').') ';} ?></td>
					<td class="text-center" width="1%"></td>
					<td class="text-right"><?php if ($last_month_depreciation_balance >0) { echo' '.number_format($last_month_depreciation_balance, 2 . '').' ';} else if($last_month_depreciation_balance ==0) {echo '-';} else { echo' ('.number_format(abs($last_month_depreciation_balance), 2 . '').') ';} ?></td>
					<td class="text-center" width="1%"></td>
					<td class="text-right"><?php if ($current_year_depreciation_balance >0) { echo' '.number_format($current_year_depreciation_balance, 2 . '').' ';} else if($current_year_depreciation_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_year_depreciation_balance), 2 . '').') ';} ?></td>
					<td class="text-center" width="1%"></td>
					<td class="text-right"><?php if ($last_year_depreciation_balance >0) { echo' '.number_format($last_year_depreciation_balance, 2 . '').' ';} else if($last_year_depreciation_balance ==0) {echo '-';} else { echo' ('.number_format(abs($last_year_depreciation_balance), 2 . '').') ';} ?></td>
					
				</tr>
				<?php }
				 
				$total_current_month_operating_activities	= $total_current_month_surplus_deficit + $current_month_depreciation_balance;
				$total_last_month_operating_activities		= $total_last_month_surplus_deficit + $last_month_depreciation_balance;
				$total_current_year_operating_activities	= $total_current_year_surplus_deficit + $current_year_depreciation_balance;
				$total_last_year_operating_activities		= $total_last_year_surplus_deficit + $last_year_depreciation_balance;
				$total_previous_year_operating_activities	= $total_previous_year_surplus_deficit + $previous_year_depreciation_balance;
				?>
				<tr>
					<th class="text-left text-uppercase">&nbsp; Total Operating Activities</th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-all"><?php if ($total_current_month_operating_activities >0) { echo' '.number_format($total_current_month_operating_activities, 2 . '').' ';} else if($total_current_month_operating_activities ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_month_operating_activities), 2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-all"><?php if ($total_last_month_operating_activities >0) { echo' '.number_format($total_last_month_operating_activities, 2 . '').' ';} else if($total_last_month_operating_activities ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_month_operating_activities), 2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-all"><?php if ($total_current_year_operating_activities >0) { echo' '.number_format($total_current_year_operating_activities, 2 . '').' ';} else if($total_current_year_operating_activities ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_year_operating_activities), 2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-all"><?php if ($total_last_year_operating_activities >0) { echo' '.number_format($total_last_year_operating_activities, 2 . '').' ';} else if($total_last_year_operating_activities ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_year_operating_activities), 2 . '').') ';} ?></th>
				</tr>
				
				<tr class="text-uppercase">
					<th class="text-left "colspan="9">&nbsp;</th>
				</tr>
				
				<tr class="text-uppercase">
					<th class="text-left " colspan="9">&nbsp; Amount Considered as non cash items</th>
				</tr>
				<?php 
				$current_month_balance = 0;
				$last_month_balance = 0;
				$current_year_balance = 0;
				$last_year_balance = 0;
				$previous_year_balance = 0;
				$category =  $this->db->select("*")
				->from('chart_of_accounts') 
				->where('chart_of_accounts_id',23)
				->or_where('chart_of_accounts_id', 24)
				->order_by('chart_of_accounts_code', 'ASC')
				->get()
				->result();
				foreach($category as $category_row)
				{
					$current_month_query = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_month_balance") 
					->from('accounts_details')
					
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
					->where('accounts_details_control_group', $category_row->chart_of_accounts_id)
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($current_month_query as $current_month_query_row)
					{
						$current_month_balance = $current_month_query_row->current_month_balance;
					}
					
					$last_month_query = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS last_month_balance") 
					->from('accounts_details')
					
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_last_month_start_date.'" and "'.$current_last_month_end_date.'"')
					->where('accounts_details_control_group', $category_row->chart_of_accounts_id)
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($last_month_query as $last_month_query_row)
					{
						$last_month_balance = $last_month_query_row->last_month_balance;
					}
					
					$current_year_query = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_year_balance") 
					->from('accounts_details')
					
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_year_start_date.'" and "'.$current_year_end_date.'"')
					->where('accounts_details_control_group', $category_row->chart_of_accounts_id)
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($current_year_query as $current_year_query_row)
					{
						$current_year_balance = $current_year_query_row->current_year_balance;
					}
					
					$last_year_query = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS last_year_balance") 
					->from('accounts_details')
					
					->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
					->where('accounts_details_control_group', $category_row->chart_of_accounts_id)
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($last_year_query as $last_year_query_row)
					{
						$last_year_balance = $last_year_query_row->last_year_balance;
					}
					
					$previous_year_query = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS previous_year_balance") 
					->from('accounts_details')
					
					->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_year_start_date.'" and "'.$previous_year_end_date.'"')
					->where('accounts_details_control_group', $category_row->chart_of_accounts_id)
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($previous_year_query as $previous_year_query_row)
					{
						$previous_year_balance = $previous_year_query_row->previous_year_balance;
					}
					?>	
				<tr>
					<td class="text-left">&nbsp; <?= $category_row->chart_of_accounts_code;?> - <?= $category_row->chart_of_accounts_name;?></td>
					<td class="text-center" width="1%"></td>
					<td class="text-right"><?php if ($current_month_balance >0) { echo' '.number_format($current_month_balance, 2 . '').' ';} else if($current_month_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_month_balance), 2 . '').') ';} ?></td>
					<td class="text-center" width="1%"></td>
					<td class="text-right"><?php if ($last_month_balance >0) { echo' '.number_format($last_month_balance, 2 . '').' ';} else if($last_month_balance ==0) {echo '-';} else { echo' ('.number_format(abs($last_month_balance), 2 . '').') ';} ?></td>
					<td class="text-center" width="1%"></td>
					<td class="text-right"><?php if ($current_year_balance >0) { echo' '.number_format($current_year_balance, 2 . '').' ';} else if($current_year_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_year_balance), 2 . '').') ';} ?></td>
					<td class="text-center" width="1%"></td>
					<td class="text-right"><?php if ($last_year_balance >0) { echo' '.number_format($last_year_balance, 2 . '').' ';} else if($last_year_balance ==0) {echo '-';} else { echo' ('.number_format(abs($last_year_balance), 2 . '').') ';} ?></td>
					
				</tr>
				<?php }
				$current_month_non_cash_balance = $total_current_month_operating_activities + $current_month_balance;
				$last_month_non_cash_balance = $total_last_month_operating_activities + $last_month_balance;
				$current_year_non_cash_balance = $total_current_year_operating_activities + $current_year_balance;
				$last_year_non_cash_balance = $total_last_year_operating_activities + $last_year_balance;
				$previous_year_non_cash_balance = $total_previous_year_operating_activities + $previous_year_balance;
				?>
				
				<tr class="text-uppercase">
					<th class="text-left">&nbsp; Total Non Cash Items</th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-all"><?php if ($current_month_non_cash_balance >0) { echo' '.number_format($current_month_non_cash_balance, 2 . '').' ';} else if($current_month_non_cash_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_month_non_cash_balance), 2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-all"><?php if ($last_month_non_cash_balance >0) { echo' '.number_format($last_month_non_cash_balance, 2 . '').' ';} else if($last_month_non_cash_balance ==0) {echo '-';} else { echo' ('.number_format(abs($last_month_non_cash_balance), 2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-all"><?php if ($current_year_non_cash_balance >0) { echo' '.number_format($current_year_non_cash_balance, 2 . '').' ';} else if($current_year_non_cash_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_year_non_cash_balance), 2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-all"><?php if ($last_year_non_cash_balance >0) { echo' '.number_format($last_year_non_cash_balance, 2 . '').' ';} else if($last_year_non_cash_balance ==0) {echo '-';} else { echo' ('.number_format(abs($last_year_non_cash_balance), 2 . '').') ';} ?></th>
				</tr>
				
				<?php
				$total_current_month_cash_operating_balance	= $current_month_non_cash_balance;
				$total_last_month_cash_operating_balance	= $last_month_non_cash_balance;
				$total_current_year_cash_operating_balance	= $current_year_non_cash_balance;
				$total_last_year_cash_operating_balance		= $last_year_non_cash_balance;
				$total_previous_year_cash_operating_balance	= $previous_year_non_cash_balance;
				
				$current_assets_category =  $this->db->select("DISTINCT(chart_of_accounts_id), chart_of_accounts_code, chart_of_accounts_name, accounts_details_accounts_category, accounts_details_accounts_type")
				->from('accounts_details') 
				->join('chart_of_accounts', 'accounts_details.accounts_details_control_group = chart_of_accounts.chart_of_accounts_id', 'LEFT')
				 
				->where('accounts_details.accounts_details_accounts_category', 2)
				->where('accounts_details.accounts_details_control_group <>', 65)
				//->where('accounts_details.accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
				->order_by('accounts_details.accounts_details_voucher_posting_date', 'ASC')
				->order_by('accounts_details.accounts_details_id', 'ASC')
				->get()
				->result();
				foreach($current_assets_category as $current_assets_category_row)
				{
					$current_month_current_assets_query = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_month_balance") 
					->from('accounts_details')
					
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
					->where('accounts_details_control_group', $current_assets_category_row->chart_of_accounts_id)
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($current_month_current_assets_query as $current_month_current_assets_query_row)
					{
						$current_month_current_assets_balance = $current_month_current_assets_query_row->current_month_balance;
						$total_current_month_cash_operating_balance	+= $current_month_current_assets_balance;
					}
					
					$last_month_current_assets_query = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS last_month_balance") 
					->from('accounts_details')
					
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_last_month_start_date.'" and "'.$current_last_month_end_date.'"')
					->where('accounts_details_control_group', $current_assets_category_row->chart_of_accounts_id)
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($last_month_current_assets_query as $last_month_current_assets_query_row)
					{
						$last_month_current_assets_balance = $last_month_current_assets_query_row->last_month_balance;
						$total_last_month_cash_operating_balance	+= $last_month_current_assets_balance;
					}
					
					$current_year_current_assets_query = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_year_balance") 
					->from('accounts_details')
					
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_year_start_date.'" and "'.$current_year_end_date.'"')
					->where('accounts_details_control_group', $current_assets_category_row->chart_of_accounts_id)
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($current_year_current_assets_query as $current_year_current_assets_query_row)
					{
						$current_year_current_assets_balance = $current_year_current_assets_query_row->current_year_balance;
						$total_current_year_cash_operating_balance		+= $current_year_current_assets_balance;
					}
					
					$last_year_current_assets_query = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS last_year_balance") 
					->from('accounts_details')
					
					->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
					->where('accounts_details_control_group', $current_assets_category_row->chart_of_accounts_id)
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($last_year_current_assets_query as $last_year_current_assets_query_row)
					{
						$last_year_current_assets_balance = $last_year_current_assets_query_row->last_year_balance;
						$total_last_year_cash_operating_balance		+= $last_year_current_assets_balance;
					}
					
					$previous_year_current_assets_query = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS previous_year_balance") 
					->from('accounts_details')
					
					->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_year_start_date.'" and "'.$previous_year_end_date.'"')
					->where('accounts_details_control_group', $current_assets_category_row->chart_of_accounts_id)
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($previous_year_current_assets_query as $previous_year_current_assets_query_row)
					{
						$previous_year_current_assets_balance = $previous_year_current_assets_query_row->previous_year_balance;
						$total_previous_year_cash_operating_balance	+= $previous_year_current_assets_balance;
					}
				?>	
				<tr>
					<td class="text-left">&nbsp; <?= $current_assets_category_row->chart_of_accounts_code;?> - <?= $current_assets_category_row->chart_of_accounts_name;?></td>
					<td class="text-center" width="1%"></td>
					<td class="text-right"><?php if ($current_month_current_assets_balance >0) { echo' '.number_format($current_month_current_assets_balance, 2 . '').' ';} else if($current_month_current_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_month_current_assets_balance), 2 . '').') ';} ?></td>
					<td class="text-center" width="1%"></td>
					<td class="text-right"><?php if ($last_month_current_assets_balance >0) { echo' '.number_format($last_month_current_assets_balance, 2 . '').' ';} else if($last_month_current_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($last_month_current_assets_balance), 2 . '').') ';} ?></td>
					<td class="text-center" width="1%"></td>
					<td class="text-right"><?php if ($current_year_current_assets_balance >0) { echo' '.number_format($current_year_current_assets_balance, 2 . '').' ';} else if($current_year_current_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_year_current_assets_balance), 2 . '').') ';} ?></td>
					<td class="text-center" width="1%"></td>
					<td class="text-right"><?php if ($last_year_current_assets_balance >0) { echo' '.number_format($last_year_current_assets_balance, 2 . '').' ';} else if($last_year_current_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($last_year_current_assets_balance), 2 . '').') ';} ?></td>
				</tr>
				<?php }?>
				
				<tr class="text-uppercase">
					<th class="text-left">&nbsp; Net Cash used in Operating Activities</th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-all"><?php if ($total_current_month_cash_operating_balance >0) { echo' '.number_format($total_current_month_cash_operating_balance, 2 . '').' ';} else if($total_current_month_cash_operating_balance ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_month_cash_operating_balance), 2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-all"><?php if ($total_last_month_cash_operating_balance >0) { echo' '.number_format($total_last_month_cash_operating_balance, 2 . '').' ';} else if($total_last_month_cash_operating_balance ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_month_cash_operating_balance), 2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-all"><?php if ($total_current_year_cash_operating_balance >0) { echo' '.number_format($total_current_year_cash_operating_balance, 2 . '').' ';} else if($total_current_year_cash_operating_balance ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_year_cash_operating_balance), 2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-all"><?php if ($total_last_year_cash_operating_balance >0) { echo' '.number_format($total_last_year_cash_operating_balance, 2 . '').' ';} else if($total_last_year_cash_operating_balance ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_year_cash_operating_balance), 2 . '').') ';} ?></th>
				</tr>
				
				
				
				<tr class="text-uppercase">
					<th class="text-left "colspan="9">&nbsp;</th>
				</tr>
				<tr class="text-uppercase">
					<th class="text-left "colspan="9">B. Cash Flow from Investing Activities</th>
				</tr>
				
				<?php
				$total_current_month_cash_investing_balance	= 0;
				$total_last_month_cash_investing_balance	= 0;
				$total_current_year_cash_investing_balance	= 0;
				$total_last_year_cash_investing_balance		= 0;
				$total_previous_year_cash_investing_balance	= 0;
				
				$fixed_assets_category =  $this->db->select("DISTINCT(chart_of_accounts_id), chart_of_accounts_code, chart_of_accounts_name, accounts_details_accounts_category, accounts_details_accounts_type")
				->from('accounts_details') 
				->join('chart_of_accounts', 'accounts_details.accounts_details_control_group = chart_of_accounts.chart_of_accounts_id', 'LEFT')
				 
				->where('accounts_details.accounts_details_accounts_category', 1)
				//->where('accounts_details.accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
				->order_by('accounts_details.accounts_details_voucher_posting_date', 'ASC')
				->order_by('accounts_details.accounts_details_id', 'ASC')
				->get()
				->result();
				foreach($fixed_assets_category as $fixed_assets_category_row)
				{
					$current_month_fixed_assets_query = $this->db->select("(SUM(accounts_details_debit)) AS current_month_balance") 
					->from('accounts_details')
					
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
					->where('accounts_details_control_group', $fixed_assets_category_row->chart_of_accounts_id)
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($current_month_fixed_assets_query as $current_month_fixed_assets_query_row)
					{
						$current_month_fixed_assets_balance = -$current_month_fixed_assets_query_row->current_month_balance;
						$total_current_month_cash_investing_balance	+= $current_month_fixed_assets_balance;
					}
					
					$last_month_fixed_assets_query = $this->db->select("(SUM(accounts_details_debit)) AS last_month_balance") 
					->from('accounts_details')
					
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_last_month_start_date.'" and "'.$current_last_month_end_date.'"')
					->where('accounts_details_control_group', $fixed_assets_category_row->chart_of_accounts_id)
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($last_month_fixed_assets_query as $last_month_fixed_assets_query_row)
					{
						$last_month_fixed_assets_balance = -$last_month_fixed_assets_query_row->last_month_balance;
						$total_last_month_cash_investing_balance	+= $last_month_fixed_assets_balance;
					}
					
					$current_year_fixed_assets_query = $this->db->select("(SUM(accounts_details_debit)) AS current_year_balance") 
					->from('accounts_details')
					
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_year_start_date.'" and "'.$current_year_end_date.'"')
					->where('accounts_details_control_group', $fixed_assets_category_row->chart_of_accounts_id)
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($current_year_fixed_assets_query as $current_year_fixed_assets_query_row)
					{
						$current_year_fixed_assets_balance = -$current_year_fixed_assets_query_row->current_year_balance;
						$total_current_year_cash_investing_balance		+= $current_year_fixed_assets_balance;
					}
					
					$last_year_fixed_assets_query = $this->db->select("(SUM(accounts_details_debit)) AS last_year_balance") 
					->from('accounts_details')
					
					->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
					->where('accounts_details_control_group', $fixed_assets_category_row->chart_of_accounts_id)
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($last_year_fixed_assets_query as $last_year_fixed_assets_query_row)
					{
						$last_year_fixed_assets_balance = -$last_year_fixed_assets_query_row->last_year_balance;
						$total_last_year_cash_investing_balance		+= $last_year_fixed_assets_balance;
					}
					
					$previous_year_fixed_assets_query = $this->db->select("(SUM(accounts_details_debit)) AS previous_year_balance")
					->from('accounts_details')
					
					->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_year_start_date.'" and "'.$previous_year_end_date.'"')
					->where('accounts_details_control_group', $fixed_assets_category_row->chart_of_accounts_id)
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($previous_year_fixed_assets_query as $previous_year_fixed_assets_query_row)
					{
						$previous_year_fixed_assets_balance = -$previous_year_fixed_assets_query_row->previous_year_balance;
						$total_previous_year_cash_investing_balance	+= $previous_year_fixed_assets_balance;
					}
				?>	
				<tr>
					<td class="text-left">&nbsp; <?= $fixed_assets_category_row->chart_of_accounts_code;?> - <?= $fixed_assets_category_row->chart_of_accounts_name;?></td>
					<td class="text-center" width="1%"></td>
					<td class="text-right"><?php if ($current_month_fixed_assets_balance >0) { echo' '.number_format($current_month_fixed_assets_balance, 2 . '').' ';} else if($current_month_fixed_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_month_fixed_assets_balance), 2 . '').') ';} ?></td>
					<td class="text-center" width="1%"></td>
					<td class="text-right"><?php if ($last_month_fixed_assets_balance >0) { echo' '.number_format($last_month_fixed_assets_balance, 2 . '').' ';} else if($last_month_fixed_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($last_month_fixed_assets_balance), 2 . '').') ';} ?></td>
					<td class="text-center" width="1%"></td>
					<td class="text-right"><?php if ($current_year_fixed_assets_balance >0) { echo' '.number_format($current_year_fixed_assets_balance, 2 . '').' ';} else if($current_year_fixed_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_year_fixed_assets_balance), 2 . '').') ';} ?></td>
					<td class="text-center" width="1%"></td>
					<td class="text-right"><?php if ($last_year_fixed_assets_balance >0) { echo' '.number_format($last_year_fixed_assets_balance, 2 . '').' ';} else if($last_year_fixed_assets_balance ==0) {echo '-';} else { echo' ('.number_format(abs($last_year_fixed_assets_balance), 2 . '').') ';} ?></td>
					</tr>
				<?php }?>
				
				<tr class="text-uppercase">
					<th class="text-left">&nbsp; Net Cash Used in Investing Activities</th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-all"><?php if ($total_current_month_cash_investing_balance >0) { echo' '.number_format($total_current_month_cash_investing_balance, 2 . '').' ';} else if($total_current_month_cash_investing_balance ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_month_cash_investing_balance), 2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-all"><?php if ($total_last_month_cash_investing_balance >0) { echo' '.number_format($total_last_month_cash_investing_balance, 2 . '').' ';} else if($total_last_month_cash_investing_balance ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_month_cash_investing_balance), 2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-all"><?php if ($total_current_year_cash_investing_balance >0) { echo' '.number_format($total_current_year_cash_investing_balance, 2 . '').' ';} else if($total_current_year_cash_investing_balance ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_year_cash_investing_balance), 2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-all"><?php if ($total_last_year_cash_investing_balance >0) { echo' '.number_format($total_last_year_cash_investing_balance, 2 . '').' ';} else if($total_last_year_cash_investing_balance ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_year_cash_investing_balance), 2 . '').') ';} ?></th>
				</tr>
				
				
				<tr class="text-uppercase">
					<th class="text-left "colspan="9">&nbsp;</th>
				</tr>
				<tr class="text-uppercase">
					<th class="text-left "colspan="9">C. Cash Flow from Financing Activities</th>
				</tr>
				
				<?php
				$total_current_month_cash_financing_balance	= 0;
				$total_last_month_cash_financing_balance	= 0;
				$total_current_year_cash_financing_balance		= 0;
				$total_last_year_cash_financing_balance		= 0;
				$total_previous_year_cash_financing_balance	= 0;
				
				$liabilities_category =  $this->db->select("DISTINCT(chart_of_accounts_id), chart_of_accounts_code, chart_of_accounts_name, accounts_details_accounts_category, accounts_details_accounts_type")
				->from('accounts_details') 
				->join('chart_of_accounts', 'accounts_details.accounts_details_control_group = chart_of_accounts.chart_of_accounts_id', 'LEFT')
				 
				->where('accounts_details.accounts_details_control_group', 19) 
				->order_by('accounts_details.accounts_details_id', 'ASC')
				->get()
				->result();
				foreach($liabilities_category as $liabilities_category_row)
				{
					$current_month_liabilities_query = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_month_balance") 
					->from('accounts_details')
					
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
					->where('accounts_details_control_group', $liabilities_category_row->chart_of_accounts_id)
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($current_month_liabilities_query as $current_month_liabilities_query_row)
					{
						$current_month_liabilities_balance = $current_month_liabilities_query_row->current_month_balance;
						$total_current_month_cash_financing_balance	+= $current_month_liabilities_balance;
					}
					
					$last_month_liabilities_query = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS last_month_balance") 
					->from('accounts_details')
					
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_last_month_start_date.'" and "'.$current_last_month_end_date.'"')
					->where('accounts_details_control_group', $liabilities_category_row->chart_of_accounts_id)
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($last_month_liabilities_query as $last_month_liabilities_query_row)
					{
						$last_month_liabilities_balance = $last_month_liabilities_query_row->last_month_balance;
						$total_last_month_cash_financing_balance	+= $last_month_liabilities_balance;
					}
					
					$current_year_liabilities_query = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_year_balance") 
					->from('accounts_details')
					
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_year_start_date.'" and "'.$current_year_end_date.'"')
					->where('accounts_details_control_group', $liabilities_category_row->chart_of_accounts_id)
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($current_year_liabilities_query as $current_year_liabilities_query_row)
					{
						$current_year_liabilities_balance = $current_year_liabilities_query_row->current_year_balance;
						$total_current_year_cash_financing_balance		+= $current_year_liabilities_balance;
					}
					
					$last_year_liabilities_query = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS last_year_balance") 
					->from('accounts_details')
					
					->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
					->where('accounts_details_control_group', $liabilities_category_row->chart_of_accounts_id)
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($last_year_liabilities_query as $last_year_liabilities_query_row)
					{
						$last_year_liabilities_balance = $last_year_liabilities_query_row->last_year_balance;
						$total_last_year_cash_financing_balance		+= $last_year_liabilities_balance;
					}
					
					$previous_year_liabilities_query = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS previous_year_balance")
					->from('accounts_details')
					
					->where('accounts_details_voucher_posting_date BETWEEN "'.$previous_year_start_date.'" and "'.$previous_year_opening_balance_end_date.'"')
					->where('accounts_details_control_group', $liabilities_category_row->chart_of_accounts_id)
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					
					foreach($previous_year_liabilities_query as $previous_year_liabilities_query_row)
					{
						$previous_year_liabilities_balance = $previous_year_liabilities_query_row->previous_year_balance;
						$total_previous_year_cash_financing_balance	+= $previous_year_liabilities_balance;
					}
				?>	
				<tr>
					<td class="text-left">&nbsp; <?= $liabilities_category_row->chart_of_accounts_code;?> - <?= $liabilities_category_row->chart_of_accounts_name;?></td>
					<td class="text-center" width="1%"></td>
					<td class="text-right"><?php if ($current_month_liabilities_balance >0) { echo' '.number_format($current_month_liabilities_balance, 2 . '').' ';} else if($current_month_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_month_liabilities_balance), 2 . '').') ';} ?></td>
					<td class="text-center" width="1%"></td>
					<td class="text-right"><?php if ($last_month_liabilities_balance >0) { echo' '.number_format($last_month_liabilities_balance, 2 . '').' ';} else if($last_month_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($last_month_liabilities_balance), 2 . '').') ';} ?></td>
					<td class="text-center" width="1%"></td>
					<td class="text-right"><?php if ($current_year_liabilities_balance >0) { echo' '.number_format($current_year_liabilities_balance, 2 . '').' ';} else if($current_year_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_year_liabilities_balance), 2 . '').') ';} ?></td>
					<td class="text-center" width="1%"></td>
					<td class="text-right"><?php if ($last_year_liabilities_balance >0) { echo' '.number_format($last_year_liabilities_balance, 2 . '').' ';} else if($last_year_liabilities_balance ==0) {echo '-';} else { echo' ('.number_format(abs($last_year_liabilities_balance), 2 . '').') ';} ?></td>
				</tr>
				<?php }?>
				
				<tr class="text-uppercase">
					<th class="text-left">&nbsp; Net Cash Used in financing Activities</th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-all"><?php if ($total_current_month_cash_financing_balance >0) { echo' '.number_format($total_current_month_cash_financing_balance, 2 . '').' ';} else if($total_current_month_cash_financing_balance ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_month_cash_financing_balance), 2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-all"><?php if ($total_last_month_cash_financing_balance >0) { echo' '.number_format($total_last_month_cash_financing_balance, 2 . '').' ';} else if($total_last_month_cash_financing_balance ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_month_cash_financing_balance), 2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-all"><?php if ($total_current_year_cash_financing_balance >0) { echo' '.number_format($total_current_year_cash_financing_balance, 2 . '').' ';} else if($total_current_year_cash_financing_balance ==0) {echo '-';} else { echo' ('.number_format(abs($total_current_year_cash_financing_balance), 2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-all"><?php if ($total_last_year_cash_financing_balance >0) { echo' '.number_format($total_last_year_cash_financing_balance, 2 . '').' ';} else if($total_last_year_cash_financing_balance ==0) {echo '-';} else { echo' ('.number_format(abs($total_last_year_cash_financing_balance), 2 . '').') ';} ?></th>
				</tr>
				
				<tr class="text-uppercase">
					<th class="text-left "colspan="9">&nbsp;</th>
				</tr>
				
				<?php
				$current_month_increase_decrease	= $total_current_month_cash_operating_balance + $total_current_month_cash_investing_balance + $total_current_month_cash_financing_balance;
				$last_month_increase_decrease		= $total_last_month_cash_operating_balance + $total_last_month_cash_investing_balance + $total_last_month_cash_financing_balance;
				$current_year_increase_decrease		= $total_current_year_cash_operating_balance + $total_current_year_cash_investing_balance + $total_current_year_cash_financing_balance;
				$last_year_increase_decrease		= $total_last_year_cash_operating_balance + $total_last_year_cash_investing_balance + $total_last_year_cash_financing_balance;
				$previous_year_increase_decrease	= $total_previous_year_cash_operating_balance + $total_previous_year_cash_investing_balance + $total_previous_year_cash_financing_balance;
				?>
				
				<tr class="text-uppercase">
					<th class="text-left">D. Net Increase/Decrease (A+B+C)</th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-all"><?php if ($current_month_increase_decrease >0) { echo' '.number_format($current_month_increase_decrease, 2 . '').' ';} else if($current_month_increase_decrease ==0) {echo '-';} else { echo' ('.number_format(abs($current_month_increase_decrease), 2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-all"><?php if ($last_month_increase_decrease >0) { echo' '.number_format($last_month_increase_decrease, 2 . '').' ';} else if($last_month_increase_decrease ==0) {echo '-';} else { echo' ('.number_format(abs($last_month_increase_decrease), 2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-all"><?php if ($current_year_increase_decrease >0) { echo' '.number_format($current_year_increase_decrease, 2 . '').' ';} else if($current_year_increase_decrease ==0) {echo '-';} else { echo' ('.number_format(abs($current_year_increase_decrease), 2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-all"><?php if ($last_year_increase_decrease >0) { echo' '.number_format($last_year_increase_decrease, 2 . '').' ';} else if($last_year_increase_decrease ==0) {echo '-';} else { echo' ('.number_format(abs($last_year_increase_decrease), 2 . '').') ';} ?></th>
				</tr>
				
				<?php 
				$cash_opening =  $this->db->select("*")
				->from('chart_of_accounts')
				->where('chart_of_accounts_id', 65)
				->order_by('chart_of_accounts_code', 'ASC') 
				->get()
				->result();
				foreach($cash_opening as $cash_opening_row)
				{
					$cash_current_month_opening_balance_query =  $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) as cash_current_month_opening_balance")
					->from('accounts_details')
					->where('accounts_details_control_group', $cash_opening_row->chart_of_accounts_id)
					
					->where('accounts_details_voucher_posting_date BETWEEN "'.$opening_balance_starting_date.'" and "'.$current_month_opening_balance_end_date.'"')
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($cash_current_month_opening_balance_query as $cash_current_month_opening_balance_query_row)
					{
						$cash_current_month_opening_balance		= $cash_current_month_opening_balance_query_row->cash_current_month_opening_balance;
					}
					
					$cash_last_month_opening_balance_query =  $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) as cash_last_month_opening_balance")
					->from('accounts_details')
					->where('accounts_details_control_group', $cash_opening_row->chart_of_accounts_id)
					
					->where('accounts_details_voucher_posting_date BETWEEN "'.$opening_balance_starting_date.'" and "'.$current_last_month_opening_balance_end_date.'"')
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($cash_last_month_opening_balance_query as $cash_last_month_opening_balance_query_row)
					{
						$cash_last_month_opening_balance		= $cash_last_month_opening_balance_query_row->cash_last_month_opening_balance;
					}
					
					$cash_current_year_opening_balance_query =  $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) as cash_current_year_opening_balance")
					->from('accounts_details')
					->where('accounts_details_control_group', $cash_opening_row->chart_of_accounts_id)
					
					->where('accounts_details_voucher_posting_date BETWEEN "'.$opening_balance_starting_date.'" and "'.$current_year_opening_balance_end_date.'"')
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($cash_current_year_opening_balance_query as $cash_current_year_opening_balance_query_row)
					{
						$cash_current_year_opening_balance		= $cash_current_year_opening_balance_query_row->cash_current_year_opening_balance;
					}
					
					$cash_last_year_opening_balance_query =  $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) as cash_last_year_opening_balance")
					->from('accounts_details')
					->where('accounts_details_control_group', $cash_opening_row->chart_of_accounts_id)
					
					->where('accounts_details_voucher_posting_date BETWEEN "'.$opening_balance_starting_date.'" and "'.$last_year_opening_balance_end_date.'"')
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($cash_last_year_opening_balance_query as $cash_last_year_opening_balance_query_row)
					{
						$cash_last_year_opening_balance		= $cash_last_year_opening_balance_query_row->cash_last_year_opening_balance;
					}
					
					$cash_previous_year_opening_balance_query =  $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) as cash_previous_year_opening_balance")
					->from('accounts_details')
					->where('accounts_details_control_group', $cash_opening_row->chart_of_accounts_id)
					
					->where('accounts_details_voucher_posting_date BETWEEN "'.$opening_balance_starting_date.'" and "'.$previous_year_start_date.'"')
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($cash_previous_year_opening_balance_query as $cash_previous_year_opening_balance_query_row)
					{
						$cash_previous_year_opening_balance		= $cash_previous_year_opening_balance_query_row->cash_previous_year_opening_balance;
					}
				}
				?>
				
				<tr>
					<td class="text-left">&nbsp; Cash & Bank Opening Balance</td>
					<td class="text-center" width="1%"></td>
					<td class="text-right"><?php if ($cash_current_month_opening_balance >0) { echo' '.number_format($cash_current_month_opening_balance, 2 . '').' ';} else if($cash_current_month_opening_balance ==0) {echo '-';} else { echo' ('.number_format(abs($cash_current_month_opening_balance), 2 . '').') ';} ?></td>
					<td class="text-center" width="1%"></td>
					<td class="text-right"><?php if ($cash_last_month_opening_balance >0) { echo' '.number_format($cash_last_month_opening_balance, 2 . '').' ';} else if($cash_last_month_opening_balance ==0) {echo '-';} else { echo' ('.number_format(abs($cash_last_month_opening_balance), 2 . '').') ';} ?></td>
					<td class="text-center" width="1%"></td>
					<td class="text-right"><?php if ($cash_current_year_opening_balance >0) { echo' '.number_format($cash_current_year_opening_balance, 2 . '').' ';} else if($cash_current_year_opening_balance ==0) {echo '-';} else { echo' ('.number_format(abs($cash_current_year_opening_balance), 2 . '').') ';} ?></td>
					<td class="text-center" width="1%"></td>
					<td class="text-right"><?php if ($cash_last_year_opening_balance >0) { echo' '.number_format($cash_last_year_opening_balance, 2 . '').' ';} else if($cash_last_year_opening_balance ==0) {echo '-';} else { echo' ('.number_format(abs($cash_last_year_opening_balance), 2 . '').') ';} ?></td>
				</tr>
				<?php 
				$current_month_cash_bank_closing_balance = $current_month_increase_decrease+$cash_current_month_opening_balance;
				$last_month_cash_bank_closing_balance = $last_month_increase_decrease+$cash_last_month_opening_balance;
				$current_year_cash_bank_closing_balance = $current_year_increase_decrease+$cash_current_year_opening_balance;
				$last_year_cash_bank_closing_balance = $last_year_increase_decrease+$cash_last_year_opening_balance;
				$previous_year_cash_bank_closing_balance = $previous_year_increase_decrease+$cash_previous_year_opening_balance;
				?>
				
				<tr class="text-uppercase">
					<th class="text-left">E. Cash & Bank Closing Balance</th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-all"><?php if ($current_month_cash_bank_closing_balance >0) { echo' '.number_format($current_month_cash_bank_closing_balance, 2 . '').' ';} else if($current_month_cash_bank_closing_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_month_cash_bank_closing_balance), 2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-all"><?php if ($last_month_cash_bank_closing_balance >0) { echo' '.number_format($last_month_cash_bank_closing_balance, 2 . '').' ';} else if($last_month_cash_bank_closing_balance ==0) {echo '-';} else { echo' ('.number_format(abs($last_month_cash_bank_closing_balance), 2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-all"><?php if ($current_year_cash_bank_closing_balance >0) { echo' '.number_format($current_year_cash_bank_closing_balance, 2 . '').' ';} else if($current_year_cash_bank_closing_balance ==0) {echo '-';} else { echo' ('.number_format(abs($current_year_cash_bank_closing_balance), 2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-all"><?php if ($last_year_cash_bank_closing_balance >0) { echo' '.number_format($last_year_cash_bank_closing_balance, 2 . '').' ';} else if($last_year_cash_bank_closing_balance ==0) {echo '-';} else { echo' ('.number_format(abs($last_year_cash_bank_closing_balance), 2 . '').') ';} ?></th>
				</tr>
			</tbody>
		</table>
		
		<br/><br/><br/><br/><br/>
		
		<table class="" width="100%" align="center">  
			<tr class="text-uppercase">
				<th width="30%" class="text-center bd-top"><?= $this->lang->line('prepared_by');?></th>
				<th width="5%"></th>
				<th width="30%" class="text-center bd-top"><?= $this->lang->line('checked_by');?></th>
				<th width="5%"></th>
				<th width="30%" class="text-center bd-top"><?= $this->lang->line('authorised');?></th>
			</tr>
		</table>
		<?php 
		return $output;
	}
	
	/* ------------------------------------------------------
	Changes in Equity Model
	------------------------------------------------------- */
	function changes_in_equity($closing_month)
	{	
		$output = '';
		
		$starting_date = date('2015-01-01');
		
		
		$current_month_start_date			= date('Y-m-01', strtotime($closing_month)); 
		$current_month_opening_end_date		= date('Y-m-t', strtotime($closing_month. "last month"));
		$current_month_end_date				= date('Y-m-t', strtotime($closing_month)); 
		
		$current_last_month_start_date = date('Y-m-01', strtotime($closing_month. "last month"));
		$current_last_month_end_date =  date('Y-m-t', strtotime($closing_month. "last month")); 
		$current_last_month_opening_end_date =  date('Y-m-t', strtotime($closing_month. "last month". "last month")); 
		
		$current_previous_month_start_date = date('Y-m-01', strtotime($closing_month. "last month". "last month"));
		$current_previous_month_end_date =  date('Y-m-t', strtotime($closing_month. "last month". "last month"));
		
		$quarterly_start_date = date('Y-m-01', strtotime($closing_month. "last month". "last month"));
		$quarterly_end_date =  date('Y-m-t', strtotime($closing_month)); 
		
		
		// last Month Date Calculation ..
		if (date('m', strtotime($closing_month)) < '07') {
		$last_month_start_date			= date('Y-07-01', strtotime($closing_month. "last year")); 
		$last_month_opening_end_date	= date('Y-06-30', strtotime($closing_month. "last year"));
		} else {
		$last_month_start_date			= date('Y-07-01', strtotime($closing_month));
		$last_month_opening_end_date	= date('Y-m-t', strtotime($closing_month. "last month". "last month"));
		} 
		$last_month_end_date			= date('Y-m-t', strtotime($closing_month. "last month"));
		
		// previous Month Date Calculation ..
		if (date('m', strtotime($closing_month)) < '07') {
		$previous_month_start_date	= date('Y-07-01', strtotime($closing_month. "last year"));
		} else {
		$previous_month_start_date = date('Y-07-01', strtotime($closing_month));
		} 
		$previous_month_end_date	= date('Y-m-t', strtotime($closing_month. "last month". "last month"));
		
		// Current Year Date Calculation ..
		if (date('m', strtotime($closing_month)) < '07') {
		$current_year_start			= date('Y', strtotime($closing_month. "last year"));
		$current_year_end			= date('y', strtotime($closing_month));
		$current_year_start_date	= date('Y-07-01', strtotime($closing_month. "last year"));
		$current_year_opening_end_date	= date('Y-06-30', strtotime($closing_month. "last year"));
		$current_year_end_date		= date('Y-m-t', strtotime($closing_month));
		} else {
		$current_year_start			= date('Y', strtotime($closing_month));
		$current_year_end			= date('y', strtotime($closing_month. "+1 year"));
		$current_year_start_date	= date('Y-07-01', strtotime($closing_month));
		$current_year_opening_end_date	= date('Y-06-30', strtotime($closing_month));
		$current_year_end_date		= date('Y-m-t', strtotime($closing_month. "+1 year"));
		} 
		
		// last Year Date Calculation ..
		if (date('m', strtotime($closing_month)) < '07') {
		$last_year_start_date	= date('Y-07-01', strtotime($closing_month. "last year". "last year"));
		$last_year_start		= date('Y', strtotime($closing_month. "last year". "last year"));
		$last_year_end			= date('y', strtotime($closing_month. "last year"));
		$last_year_opening_end_date	= date('Y-06-30', strtotime($closing_month. "last year". "last year"));
		$last_year_end_date		= date('Y-06-31', strtotime($closing_month. "last year"));
		} else {
		$last_year_start_date	= date('Y-07-01', strtotime($closing_month. "last year"));
		$last_year_start		= date('Y', strtotime($closing_month. "last year"));
		$last_year_end			= date('y', strtotime($closing_month));
		$last_year_opening_end_date	= date('Y-06-30', strtotime($closing_month. "last year"));
		$last_year_end_date		= date('Y-06-31', strtotime($closing_month));
		} 
		
		// previous Year Date Calculation ..
		if (date('m', strtotime($closing_month)) < '07') {
		$previous_year_start_date	= date('Y-07-01', strtotime($closing_month. "last year". "last year". "last year"));
		$previous_year_start		= date('Y', strtotime($closing_month. "last year". "last year". "last year"));
		$previous_year_end			= date('y', strtotime($closing_month. "last year". "last year"));
		$previous_year_end_date		= date('Y-06-31', strtotime($closing_month. "last year". "last year"));
		} else {
		$previous_year_start_date	= date('Y-07-01', strtotime($closing_month. "last year". "last year"));
		$previous_year_start		= date('Y', strtotime($closing_month. "last year". "last year"));
		$previous_year_end			= date('y', strtotime($closing_month. "last year"));
		$previous_year_end_date		= date('Y-06-31', strtotime($closing_month. "last year"));
		}?>
		
		<table class="table-hover" width="100%" align="center">
			<thead class="text-uppercase">
				<tr class="table-bordered">  
					<th class="text-center" rowspan="2"><?= $this->lang->line('particulars');?></th>
					<th class="text-center" colspan="8"><?= $this->lang->line('amounts');?></th>
				</tr>
				<tr class="table-bordered">  
					<th class="text-center" colspan="2">
						<?= $this->lang->line('up_to');?> <br/> <?= date('M-y', strtotime($closing_month));?>
					</th>
					<th class="text-center" colspan="2">
						<?= $this->lang->line('up_to');?> <?= $this->lang->line('last_month');?>  <br/> <?= date('M-y', strtotime($closing_month. "last month"));?>
					</th>
					<th class="text-center" colspan="2">
						FY <?= $current_year_start;?>-<?= $current_year_end;?>
					</th>
					<th class="text-center" colspan="2">
						FY <?= $last_year_start;?>-<?= $last_year_end;?>
					</th>
				</tr>
			</thead>
			<tbody>
				<?php 
				$accounts_type_income_opening = $this->db->select("*") ->from('accounts_type') ->where('accounts_type_id', 300000) ->order_by('accounts_type_code', 'ASC') ->get()->result();
				foreach ($accounts_type_income_opening as $accounts_type_income_opening_row)
				{
					$total_current_month_income_opening = 0.00;
					$total_last_month_income_opening = 0.00;
					$total_previous_month_income_opening = 0.00;
					$total_current_year_income_opening = 0.00;
					$total_last_year_income_opening = 0.00;
					$total_previous_year_income_opening = 0.00;
				
					$accounts_category_income_opening = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_type_income_opening_row->accounts_type_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
					foreach ($accounts_category_income_opening as $accounts_category_income_opening_row) 
					{
						
						$current_month_income_opening = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_month_income_opening_balance") 
						->from('accounts_details')
						
						->where('accounts_details_voucher_posting_date BETWEEN "'.$starting_date.'" and "'.$current_month_opening_end_date.'"')
						->where('accounts_details_accounts_category', $accounts_category_income_opening_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						
						foreach($current_month_income_opening as $current_month_income_opening_row)
						{
						$current_month_income_opening_balance = $current_month_income_opening_row->current_month_income_opening_balance;
						$total_current_month_income_opening  += $current_month_income_opening_balance;
						
						}
						
						$last_month_income_opening = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS last_month_income_opening_balance") 
						->from('accounts_details')
						
						->where('accounts_details_voucher_posting_date BETWEEN "'.$starting_date.'" and "'.$last_month_opening_end_date.'"')
						->where('accounts_details_accounts_category', $accounts_category_income_opening_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						
						foreach($last_month_income_opening as $last_month_income_opening_row)
						{
						$last_month_income_opening_balance = $last_month_income_opening_row->last_month_income_opening_balance;
						$total_last_month_income_opening  += $last_month_income_opening_balance;
						}
						
						
						$current_year_income_opening = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_year_income_opening_balance") 
						->from('accounts_details')
						
						->where('accounts_details_voucher_posting_date BETWEEN "'.$starting_date.'" and "'.$current_year_opening_end_date.'"')
						->where('accounts_details_accounts_category', $accounts_category_income_opening_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						
						foreach($current_year_income_opening as $current_year_income_opening_row)
						{
						$current_year_income_opening_balance = $current_year_income_opening_row->current_year_income_opening_balance;
						$total_current_year_income_opening  += $current_year_income_opening_balance;
						}
						
						$last_year_income_opening = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS last_year_income_opening_balance") 
						->from('accounts_details')
						
						->where('accounts_details_voucher_posting_date BETWEEN "'.$starting_date.'" and "'.$last_year_opening_end_date.'"')
						->where('accounts_details_accounts_category', $accounts_category_income_opening_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						
						foreach($last_year_income_opening as $last_year_income_opening_row)
						{
						$last_year_income_opening_balance = $last_year_income_opening_row->last_year_income_opening_balance;
						$total_last_year_income_opening  += $last_year_income_opening_balance;
						}
					}
				}
				
				
				// expenditure ..
				$accounts_type_expenditure = $this->db->select("*") ->from('accounts_type') ->where('accounts_type_id', 400000) ->order_by('accounts_type_code', 'ASC') ->get()->result();
				foreach ($accounts_type_expenditure as $accounts_type_expenditure_row)
				{
				
					$total_current_month_expenditure = 0.00;
					$total_last_month_expenditure = 0.00;
					$total_previous_month_expenditure = 0.00;
					$total_current_year_expenditure = 0.00;
					$total_last_year_expenditure = 0.00;
					$total_previous_year_expenditure = 0.00;
				
					$accounts_category_expenditure = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_type_expenditure_row->accounts_type_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
					foreach ($accounts_category_expenditure as $accounts_category_expenditure_row)
					{
					
						$current_month_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_month_expenditure_balance") 
						->from('accounts_details')
						
						->where('accounts_details_voucher_posting_date BETWEEN "'.$starting_date.'" and "'.$current_month_opening_end_date.'"')
						->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						
						foreach($current_month_expenditure as $current_month_expenditure_row)
						{
						$current_month_expenditure_balance = $current_month_expenditure_row->current_month_expenditure_balance;
						$total_current_month_expenditure  += $current_month_expenditure_balance;
						}
						
						$last_month_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS last_month_expenditure_balance") 
						->from('accounts_details')
						
						->where('accounts_details_voucher_posting_date BETWEEN "'.$starting_date.'" and "'.$last_month_opening_end_date.'"')
						->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						
						foreach($last_month_expenditure as $last_month_expenditure_row)
						{
						$last_month_expenditure_balance = $last_month_expenditure_row->last_month_expenditure_balance;
						$total_last_month_expenditure  += $last_month_expenditure_balance;
						}
						
						$current_year_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_year_expenditure_balance") 
						->from('accounts_details')
						
						->where('accounts_details_voucher_posting_date BETWEEN "'.$starting_date.'" and "'.$current_year_opening_end_date.'"')
						->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						
						foreach($current_year_expenditure as $current_year_expenditure_row)
						{
						$current_year_expenditure_balance = $current_year_expenditure_row->current_year_expenditure_balance;
						$total_current_year_expenditure  += $current_year_expenditure_balance;
						}
						
						$last_year_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS last_year_expenditure_balance") 
						->from('accounts_details')
						
						->where('accounts_details_voucher_posting_date BETWEEN "'.$starting_date.'" and "'.$last_year_opening_end_date.'"')
						->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						
						foreach($last_year_expenditure as $last_year_expenditure_row)
						{
						$last_year_expenditure_balance = $last_year_expenditure_row->last_year_expenditure_balance;
						$total_last_year_expenditure  += $last_year_expenditure_balance;
						}
					}
				}
				
				$total_opening_current_month_surplus_deficit	= $total_current_month_income_opening - $total_current_month_expenditure;
				$total_opening_last_month_surplus_deficit		= $total_last_month_income_opening - $total_last_month_expenditure;
				$total_opening_current_year_surplus_deficit		= $total_current_year_income_opening - $total_current_year_expenditure;
				$total_opening_last_year_surplus_deficit		= $total_last_year_income_opening - $total_last_year_expenditure;
				?>
				<tr class="text-uppercase">
					<th class="text-left"><?= $this->lang->line('opening_balance');?></th>
					<th class="text-right bd-bottom-double"><?php if ($total_opening_current_month_surplus_deficit >0) { echo' '.number_format($total_opening_current_month_surplus_deficit, 2 . '').' ';} else if ($total_opening_current_month_surplus_deficit == 0) { echo'-';} else { echo' ('.number_format(abs($total_opening_current_month_surplus_deficit),2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-bottom-double"><?php if ($total_opening_last_month_surplus_deficit >0) { echo' '.number_format($total_opening_last_month_surplus_deficit, 2 . '').' ';} else if ($total_opening_last_month_surplus_deficit == 0) { echo'-';} else { echo' ('.number_format(abs($total_opening_last_month_surplus_deficit),2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-bottom-double"><?php if ($total_opening_current_year_surplus_deficit >0) { echo' '.number_format($total_opening_current_year_surplus_deficit, 2 . '').' ';} else if ($total_opening_current_year_surplus_deficit == 0) { echo'-';} else { echo' ('.number_format(abs($total_opening_current_year_surplus_deficit),2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-bottom-double"><?php if ($total_opening_last_year_surplus_deficit >0) { echo' '.number_format($total_opening_last_year_surplus_deficit, 2 . '').' ';} else if ($total_opening_last_year_surplus_deficit == 0) { echo'-';} else { echo' ('.number_format(abs($total_opening_last_year_surplus_deficit),2 . '').') ';} ?></th>
				</tr>
				
				<tr class="text-uppercase">
					<th class="text-left" colspan="9">&nbsp;</th>
				</tr>
				
				<?php 
				$accounts_type_income_opening = $this->db->select("*") ->from('accounts_type') ->where('accounts_type_id', 300000) ->order_by('accounts_type_code', 'ASC') ->get()->result();
				foreach ($accounts_type_income_opening as $accounts_type_income_row)
				{
					$total_current_month_income_opening = 0.00;
					$total_last_month_income_opening = 0.00;
					$total_previous_month_income_opening = 0.00;
					$total_current_year_income_opening = 0.00;
					$total_last_year_income_opening = 0.00;
					$total_previous_year_income_opening = 0.00;
				
					$accounts_category_income_opening = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_type_income_row->accounts_type_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
					foreach ($accounts_category_income_opening as $accounts_category_income_row) 
					{
						
						$current_month_income_opening = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_month_income_balance") 
						->from('accounts_details')
						
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
						->where('accounts_details_accounts_category', $accounts_category_income_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						
						foreach($current_month_income_opening as $current_month_income_row)
						{
						$current_month_income_balance = $current_month_income_row->current_month_income_balance;
						$total_current_month_income_opening  += $current_month_income_balance;
						
						}
						
						$last_month_income_opening = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS last_month_income_balance") 
						->from('accounts_details')
						
						->where('accounts_details_voucher_posting_date BETWEEN "'.$last_month_start_date.'" and "'.$last_month_end_date.'"')
						->where('accounts_details_accounts_category', $accounts_category_income_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						
						foreach($last_month_income_opening as $last_month_income_row)
						{
						$last_month_income_balance = $last_month_income_row->last_month_income_balance;
						$total_last_month_income_opening  += $last_month_income_balance;
						}
						
						
						$current_year_income_opening = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS current_year_income_balance") 
						->from('accounts_details')
						
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_year_start_date.'" and "'.$current_year_end_date.'"')
						->where('accounts_details_accounts_category', $accounts_category_income_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						
						foreach($current_year_income_opening as $current_year_income_row)
						{
						$current_year_income_balance = $current_year_income_row->current_year_income_balance;
						$total_current_year_income_opening  += $current_year_income_balance;
						}
						
						$last_year_income_opening = $this->db->select("(SUM(accounts_details_credit) - SUM(accounts_details_debit)) AS last_year_income_balance") 
						->from('accounts_details')
						
						->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
						->where('accounts_details_accounts_category', $accounts_category_income_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						
						foreach($last_year_income_opening as $last_year_income_row)
						{
						$last_year_income_balance = $last_year_income_row->last_year_income_balance;
						$total_last_year_income_opening  += $last_year_income_balance;
						}
					}
				}
				
				
				// expenditure ..
				$accounts_type_expenditure = $this->db->select("*") ->from('accounts_type') ->where('accounts_type_id', 400000) ->order_by('accounts_type_code', 'ASC') ->get()->result();
				foreach ($accounts_type_expenditure as $accounts_type_expenditure_row)
				{
				
					$total_current_month_expenditure = 0.00;
					$total_last_month_expenditure = 0.00;
					$total_previous_month_expenditure = 0.00;
					$total_current_year_expenditure = 0.00;
					$total_last_year_expenditure = 0.00;
					$total_previous_year_expenditure = 0.00;
				
					$accounts_category_expenditure = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', $accounts_type_expenditure_row->accounts_type_id) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
					foreach ($accounts_category_expenditure as $accounts_category_expenditure_row)
					{
					
						$current_month_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_month_expenditure_balance") 
						->from('accounts_details')
						
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
						->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						
						foreach($current_month_expenditure as $current_month_expenditure_row)
						{
						$current_month_expenditure_balance = $current_month_expenditure_row->current_month_expenditure_balance;
						$total_current_month_expenditure  += $current_month_expenditure_balance;
						}
						
						$last_month_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS last_month_expenditure_balance") 
						->from('accounts_details')
						
						->where('accounts_details_voucher_posting_date BETWEEN "'.$last_month_start_date.'" and "'.$last_month_end_date.'"')
						->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						
						foreach($last_month_expenditure as $last_month_expenditure_row)
						{
						$last_month_expenditure_balance = $last_month_expenditure_row->last_month_expenditure_balance;
						$total_last_month_expenditure  += $last_month_expenditure_balance;
						}
						
						$current_year_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS current_year_expenditure_balance") 
						->from('accounts_details')
						
						->where('accounts_details_voucher_posting_date BETWEEN "'.$current_year_start_date.'" and "'.$current_year_end_date.'"')
						->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						
						foreach($current_year_expenditure as $current_year_expenditure_row)
						{
						$current_year_expenditure_balance = $current_year_expenditure_row->current_year_expenditure_balance;
						$total_current_year_expenditure  += $current_year_expenditure_balance;
						}
						
						$last_year_expenditure = $this->db->select("(SUM(accounts_details_debit) - SUM(accounts_details_credit)) AS last_year_expenditure_balance") 
						->from('accounts_details')
						
						->where('accounts_details_voucher_posting_date BETWEEN "'.$last_year_start_date.'" and "'.$last_year_end_date.'"')
						->where('accounts_details_accounts_category', $accounts_category_expenditure_row->chart_of_accounts_id) 
						->order_by('accounts_details_voucher_posting_date', 'ASC') 
						->get()
						->result();
						
						foreach($last_year_expenditure as $last_year_expenditure_row)
						{
						$last_year_expenditure_balance = $last_year_expenditure_row->last_year_expenditure_balance;
						$total_last_year_expenditure  += $last_year_expenditure_balance;
						}
					}
				}
				
				$total_current_month_surplus_deficit	= $total_current_month_income_opening - $total_current_month_expenditure;
				$total_last_month_surplus_deficit		= $total_last_month_income_opening - $total_last_month_expenditure;
				$total_current_year_surplus_deficit		= $total_current_year_income_opening - $total_current_year_expenditure;
				$total_last_year_surplus_deficit		= $total_last_year_income_opening - $total_last_year_expenditure;
				?>
				<tr class="text-uppercase">
					<th class="text-left"><?= $this->lang->line('surplus_deficit');?></th>
					<th class="text-right"><?php if ($total_current_month_surplus_deficit >0) { echo' '.number_format($total_current_month_surplus_deficit, 2 . '').' ';} else if ($total_current_month_surplus_deficit == 0) { echo'-';} else { echo' ('.number_format(abs($total_current_month_surplus_deficit),2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right"><?php if ($total_last_month_surplus_deficit >0) { echo' '.number_format($total_last_month_surplus_deficit, 2 . '').' ';} else if ($total_last_month_surplus_deficit == 0) { echo'-';} else { echo' ('.number_format(abs($total_last_month_surplus_deficit),2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right"><?php if ($total_current_year_surplus_deficit >0) { echo' '.number_format($total_current_year_surplus_deficit, 2 . '').' ';} else if ($total_current_year_surplus_deficit == 0) { echo'-';} else { echo' ('.number_format(abs($total_current_year_surplus_deficit),2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right"><?php if ($total_last_year_surplus_deficit >0) { echo' '.number_format($total_last_year_surplus_deficit, 2 . '').' ';} else if ($total_last_year_surplus_deficit == 0) { echo'-';} else { echo' ('.number_format(abs($total_last_year_surplus_deficit),2 . '').') ';} ?></th>
				</tr>
				
				<tr class="text-uppercase">
					<th class="text-left" colspan="9">&nbsp;</th>
				</tr>
				<?php 
				$net_total_current_month_surplus_deficit	= $total_opening_current_month_surplus_deficit+$total_current_month_surplus_deficit;
				$net_total_last_month_surplus_deficit		= $total_opening_last_month_surplus_deficit+$total_last_month_surplus_deficit;
				$net_total_current_year_surplus_deficit		= $total_opening_current_year_surplus_deficit+$total_current_year_surplus_deficit;
				$net_total_last_year_surplus_deficit		= $total_opening_last_year_surplus_deficit+$total_last_year_surplus_deficit;
				?>
				<tr class="text-uppercase">
					<th class="text-left"><?= $this->lang->line('total');?> <?= $this->lang->line('balance');?></th>
					<th class="text-right bd-bottom-double bd-top"><?php if ($net_total_current_month_surplus_deficit >0) { echo' '.number_format($net_total_current_month_surplus_deficit, 2 . '').' ';} else if ($net_total_current_month_surplus_deficit == 0) { echo'-';} else { echo' ('.number_format(abs($net_total_current_month_surplus_deficit),2 . '').') ';} ?></th>
					<th class="text-cente" width="1%"></th>
					<th class="text-right bd-bottom-double bd-top"><?php if ($net_total_last_month_surplus_deficit >0) { echo' '.number_format($net_total_last_month_surplus_deficit, 2 . '').' ';} else if ($net_total_last_month_surplus_deficit == 0) { echo'-';} else { echo' ('.number_format(abs($net_total_last_month_surplus_deficit),2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-bottom-double bd-top"><?php if ($net_total_current_year_surplus_deficit >0) { echo' '.number_format($net_total_current_year_surplus_deficit, 2 . '').' ';} else if ($net_total_current_year_surplus_deficit == 0) { echo'-';} else { echo' ('.number_format(abs($net_total_current_year_surplus_deficit),2 . '').') ';} ?></th>
					<th class="text-center" width="1%"></th>
					<th class="text-right bd-bottom-double bd-top"><?php if ($net_total_last_year_surplus_deficit >0) { echo' '.number_format($net_total_last_year_surplus_deficit, 2 . '').' ';} else if ($net_total_last_year_surplus_deficit == 0) { echo'-';} else { echo' ('.number_format(abs($net_total_last_year_surplus_deficit),2 . '').') ';} ?></th>
				</tr>
			</tbody>
		</table>
		
		<br/><br/><br/><br/><br/>
		
		<table class="" width="100%" align="center">  
			<tr class="text-uppercase">
				<th width="30%" class="text-center bd-top"><?= $this->lang->line('prepared_by');?></th>
				<th width="5%"></th>
				<th width="30%" class="text-center bd-top"><?= $this->lang->line('checked_by');?></th>
				<th width="5%"></th>
				<th width="30%" class="text-center bd-top"><?= $this->lang->line('authorised');?></th>
			</tr>
		</table>
		<?php 
		return $output;
	}
	
	
	/* ------------------------------------------------------
	Fixed Assets Schedule Model
	------------------------------------------------------- */
	function fixed_assets_schedule($closing_year)
	{	
		$output = '';
		
		// Current Month Date Calculation ..
		$current_month_start_date = date('2015-01-01');
		$current_month_end_date =  date('Y-m-t', strtotime($closing_year. "last year"));
		
		// Current Year Date Calculation ..
		if (date('m', strtotime($closing_year)) < '07') {
		$current_year_start			= date('Y', strtotime($closing_year. "last year"));
		$current_year_end			= date('y', strtotime($closing_year));
		$current_year_start_date	= date('Y-07-01', strtotime($closing_year. "last year"));
		$current_year_end_date		= date('Y-m-t', strtotime($closing_year));
		} else {
		$current_year_start			= date('Y', strtotime($closing_year));
		$current_year_end			= date('y', strtotime($closing_year. "+1 year"));
		$current_year_start_date	= date('Y-07-01', strtotime($closing_year));
		$current_year_end_date		= date('Y-m-t', strtotime($closing_year. "+1 year"));
		}
		
		?>
		
		<table class="table table-bordered table-hover">
			<thead class="text-uppercase">
				<tr class="table-bordered">  
					<th class="text-center" rowspan="2" width="5%"><?= $this->lang->line('sl');?></th>
					<th class="text-center" rowspan="2" width="17%"><?= $this->lang->line('particulars');?></th>
					<th class="text-center" colspan="4"><?= $this->lang->line('cost');?></th>
					<th class="text-center" colspan="4"><?= $this->lang->line('depreciation');?></th>
					<th class="text-center" rowspan="2" width="10%">Written Down Value<br/> As At 30 June <?= date('Y', strtotime($closing_year));?></th>
				</tr>
				<tr class="table-bordered">  
					<th class="text-center" width="9%">
						As at<br/>
						30 June <?= date('Y', strtotime($closing_year. "last year"));?>
					</th> 
					<th class="text-center" width="9%">
						Addition<br/>
						FY <?= date('Y', strtotime($closing_year. "last year"));?> - <?= date('Y', strtotime($closing_year));?>
					</th>
					<th class="text-center" width="7%">
						<?= $this->lang->line('disposal');?>
					</th>
					<th class="text-center" width="9%">
						Total Value<br/>
						As At 30 June <?= date('Y', strtotime($closing_year));?>
					</th>
					
					<th class="text-center" width="9%">
						As at<br/>
						30 June <?= date('Y', strtotime($closing_year. "last year"));?>
					</th> 
					<th class="text-center" width="9%">
						Charge<br/>
						FY <?= date('Y', strtotime($closing_year. "last year"));?> - <?= date('Y', strtotime($closing_year));?>
					</th>
					<th class="text-center" width="7%">
						<?= $this->lang->line('disposal');?>
					</th>
					<th class="text-center" width="9%">
						Total Value<br/>
						As At 30 June <?= date('Y', strtotime($closing_year));?>
					</th>
				</tr>
			</thead>
			<tbody>
				<?php 
				$serial = 0;
				$total_current_month_balance = 0;
				$total_current_year_balance = 0;
				$total_current_month_disposal_balance = 0;
				$total_current_month_total_value = 0;
				
				$total_current_month_depreciation_balance = 0;
				$total_current_year_depreciation_balance = 0;
				$total_current_month_disposal_depreciation_balance = 0;
				$total_current_month_depreciation_total_value = 0;
				$total_written_down_value = 0;
				$fixed_assets = $this->db->select("*") ->from('chart_of_accounts') ->where('chart_of_accounts_accounts_category', 1) ->order_by('chart_of_accounts_code', 'ASC') ->get()->result();
				foreach ($fixed_assets as $fixed_assets_row)
				{?>
				<tr> 
					<td class="text-center"><?= str_pad(++$serial, 2, '0', STR_PAD_LEFT);?></td>
					<td class="text-left"><?= $fixed_assets_row->chart_of_accounts_name;?></td>
					
					<?php $current_month_balance_query = $this->db->select("SUM(accounts_details_debit) AS current_month_balance") 
					->from('accounts_details')
					 
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
					->where('accounts_details_control_group', $fixed_assets_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($current_month_balance_query as $current_month_balance_query_row)
					{
					$current_month_balance 			= $current_month_balance_query_row->current_month_balance;	
					$total_current_month_balance	+= $current_month_balance;	
					?>
					<td class="text-right"><?php if ($current_month_balance >0) { echo' '.number_format($current_month_balance, 2 . '').' ';} else if($current_month_balance ==0) {echo '-';} else { echo'('.number_format(abs($current_month_balance), 2 . '').')';} ?></td>
					<?php }?> 
					
					<?php $current_year_balance_query = $this->db->select("SUM(accounts_details_debit) AS current_year_balance") 
					->from('accounts_details')
					 
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_year_start_date.'" and "'.$current_year_end_date.'"')
					->where('accounts_details_control_group', $fixed_assets_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($current_year_balance_query as $current_year_balance_query_row)
					{
					$current_year_balance 			= $current_year_balance_query_row->current_year_balance;	
					$total_current_year_balance		+= $current_year_balance;	
					?>
					<td class="text-right"><?php if ($current_year_balance >0) { echo' '.number_format($current_year_balance, 2 . '').' ';} else if($current_year_balance ==0) {echo '-';} else { echo'('.number_format(abs($current_year_balance), 2 . '').')';} ?></td>
					<?php }?>
					
					<?php $current_month_disposal_balance_query = $this->db->select("SUM(accounts_details_debit) AS current_month_disposal_balance") 
					->from('accounts_details')
					 
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
					->where('accounts_details_control_group', $fixed_assets_row->chart_of_accounts_id) 
					->where('accounts_details_voucher_type', 3) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($current_month_disposal_balance_query as $current_month_disposal_balance_query_row)
					{
					$current_month_disposal_balance 		= $current_month_disposal_balance_query_row->current_month_disposal_balance;	
					$total_current_month_disposal_balance	+= $current_month_disposal_balance;	
					
					$current_month_total_value = $current_month_balance + $current_year_balance + $current_month_disposal_balance;
					$total_current_month_total_value += $current_month_total_value;
					?>
					<td class="text-right"><?php if ($current_month_disposal_balance >0) { echo' '.number_format($current_month_disposal_balance, 2 . '').' ';} else if($current_month_disposal_balance ==0) {echo '-';} else { echo'('.number_format(abs($current_month_disposal_balance), 2 . '').')';} ?></td>
					<?php }?> 
					<td class="text-right"><?php if ($current_month_total_value >0) { echo' '.number_format($current_month_total_value, 2 . '').' ';} else if($current_month_total_value ==0) {echo '-';} else { echo'('.number_format(abs($current_month_total_value), 2 . '').')';} ?></td>
					
					
					<?php $current_month_depreciation_balance_query = $this->db->select("SUM(accounts_details_debit) AS current_month_depreciation_balance") 
					->from('accounts_details')
					 
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
					->where('accounts_details_control_group', $fixed_assets_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($current_month_depreciation_balance_query as $current_month_depreciation_balance_query_row)
					{
					$current_month_depreciation_balance 		= $current_month_depreciation_balance_query_row->current_month_depreciation_balance - $current_month_depreciation_balance_query_row->current_month_depreciation_balance*10/100;	
					$total_current_month_depreciation_balance	+= $current_month_depreciation_balance;	
					?>
					<td class="text-right"><?php if ($current_month_depreciation_balance >0) { echo' '.number_format($current_month_depreciation_balance, 2 . '').' ';} else if($current_month_depreciation_balance ==0) {echo '-';} else { echo'('.number_format(abs($current_month_depreciation_balance), 2 . '').')';} ?></td>
					<?php }?>  
					
					<?php $current_year_depreciation_balance_query = $this->db->select("SUM(accounts_details_debit) AS current_year_depreciation_balance") 
					->from('accounts_details')
					 
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_year_start_date.'" and "'.$current_year_end_date.'"')
					->where('accounts_details_control_group', $fixed_assets_row->chart_of_accounts_id) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($current_year_depreciation_balance_query as $current_year_depreciation_balance_query_row)
					{
					$current_year_depreciation_balance 			= $current_year_depreciation_balance_query_row->current_year_depreciation_balance*10/100;	
					$total_current_year_depreciation_balance	+= $current_year_depreciation_balance;	
					?>
					<td class="text-right"><?php if ($current_year_depreciation_balance >0) { echo' '.number_format($current_year_depreciation_balance, 2 . '').' ';} else if($current_year_depreciation_balance ==0) {echo '-';} else { echo'('.number_format(abs($current_year_depreciation_balance), 2 . '').')';} ?></td>
					<?php }?>
					
					
					<?php $current_month_disposal_depreciation_balance_query = $this->db->select("SUM(accounts_details_debit)  AS current_month_disposal_depreciation_balance") 
					->from('accounts_details')
					 
					->where('accounts_details_voucher_posting_date BETWEEN "'.$current_month_start_date.'" and "'.$current_month_end_date.'"')
					->where('accounts_details_control_group', $fixed_assets_row->chart_of_accounts_id) 
					->where('accounts_details_voucher_type', 3) 
					->order_by('accounts_details_voucher_posting_date', 'ASC') 
					->get()
					->result();
					foreach($current_month_disposal_depreciation_balance_query as $current_month_disposal_depreciation_balance_query_row)
					{
					$current_month_disposal_depreciation_balance 		= $current_month_disposal_depreciation_balance_query_row->current_month_disposal_depreciation_balance - $current_month_disposal_depreciation_balance_query_row->current_month_disposal_depreciation_balance*10/100;	
					$total_current_month_disposal_depreciation_balance	+= $current_month_disposal_depreciation_balance;	
					
					$current_month_depreciation_total_value = $current_month_depreciation_balance + $current_year_depreciation_balance + $current_month_disposal_depreciation_balance;
					$total_current_month_depreciation_total_value += $current_month_depreciation_total_value;
					
					$written_down_value = ($current_month_total_value - $current_month_depreciation_total_value);
					$total_written_down_value += $written_down_value;
					?>
					<td class="text-right"><?php if ($current_month_disposal_depreciation_balance >0) { echo' '.number_format($current_month_disposal_depreciation_balance, 2 . '').' ';} else if($current_month_disposal_depreciation_balance ==0) {echo '-';} else { echo'('.number_format(abs($current_month_disposal_depreciation_balance), 2 . '').')';} ?></td>
					<?php }?> 
					<td class="text-right"><?php if ($current_month_depreciation_total_value >0) { echo' '.number_format($current_month_depreciation_total_value, 2 . '').' ';} else if($current_month_depreciation_total_value ==0) {echo '-';} else { echo'('.number_format(abs($current_month_depreciation_total_value), 2 . '').')';} ?></td>
					<td class="text-right"><?php if ($written_down_value >0) { echo' '.number_format($written_down_value, 2 . '').' ';} else if($written_down_value ==0) {echo '-';} else { echo'('.number_format(abs($written_down_value), 2 . '').')';} ?></td>
				</tr>
				<?php }?>
				<tr> 
					<th class="text-center text-uppercase" colspan="2"><?= $this->lang->line('total');?></th>
					<th class="text-right"><?php if ($total_current_month_balance >0) { echo' '.number_format($total_current_month_balance, 2 . '').' ';} else if($total_current_month_balance ==0) {echo '-';} else { echo'('.number_format(abs($total_current_month_balance), 2 . '').')';} ?></th>
					<th class="text-right"><?php if ($total_current_year_balance >0) { echo' '.number_format($total_current_year_balance, 2 . '').' ';} else if($total_current_year_balance ==0) {echo '-';} else { echo'('.number_format(abs($total_current_year_balance), 2 . '').')';} ?></th>
					<th class="text-right"><?php if ($total_current_month_disposal_balance >0) { echo' '.number_format($total_current_month_disposal_balance, 2 . '').' ';} else if($total_current_month_disposal_balance ==0) {echo '-';} else { echo'('.number_format(abs($total_current_month_disposal_balance), 2 . '').')';} ?></th>
					<th class="text-right"><?php if ($total_current_month_total_value >0) { echo' '.number_format($total_current_month_total_value, 2 . '').' ';} else if($total_current_month_total_value ==0) {echo '-';} else { echo'('.number_format(abs($total_current_month_total_value), 2 . '').')';} ?></th>
					
					<th class="text-right"><?php if ($total_current_month_depreciation_balance >0) { echo' '.number_format($total_current_month_depreciation_balance, 2 . '').' ';} else if($total_current_month_depreciation_balance ==0) {echo '-';} else { echo'('.number_format(abs($total_current_month_depreciation_balance), 2 . '').')';} ?></th>
					<th class="text-right"><?php if ($total_current_year_depreciation_balance >0) { echo' '.number_format($total_current_year_depreciation_balance, 2 . '').' ';} else if($total_current_year_depreciation_balance ==0) {echo '-';} else { echo'('.number_format(abs($total_current_year_depreciation_balance), 2 . '').')';} ?></th>
					<th class="text-right"><?php if ($total_current_month_disposal_depreciation_balance >0) { echo' '.number_format($total_current_month_disposal_depreciation_balance, 2 . '').' ';} else if($total_current_month_disposal_depreciation_balance ==0) {echo '-';} else { echo'('.number_format(abs($total_current_month_disposal_depreciation_balance), 2 . '').')';} ?></th>
					<th class="text-right"><?php if ($total_current_month_depreciation_total_value >0) { echo' '.number_format($total_current_month_depreciation_total_value, 2 . '').' ';} else if($total_current_month_depreciation_total_value ==0) {echo '-';} else { echo'('.number_format(abs($total_current_month_depreciation_total_value), 2 . '').')';} ?></th>
					<th class="text-right"><?php if ($total_written_down_value >0) { echo' '.number_format($total_written_down_value, 2 . '').' ';} else if($total_written_down_value ==0) {echo '-';} else { echo'('.number_format(abs($total_written_down_value), 2 . '').')';} ?></th>
				</tr>
			</tbody>
		</table>
		
		<br/><br/><br/><br/><br/>
		
		<table class="" width="100%" align="center">  
			<tr class="text-uppercase">
				<th width="30%" class="text-center bd-top"><?= $this->lang->line('prepared_by');?></th>
				<th width="5%"></th>
				<th width="30%" class="text-center bd-top"><?= $this->lang->line('checked_by');?></th>
				<th width="5%"></th>
				<th width="30%" class="text-center bd-top"><?= $this->lang->line('authorised');?></th>
			</tr>
		</table>
		<?php 
		return $output;
	}
	
	/* ------------------------------------------------------
	Get Salary Process Info Model
	------------------------------------------------------- */
	function get_salary_process_info($salary_month, $salary_date)
	{	
		$payroll =  $this->db->select("*")
		->from('payroll')
		->join('designation', 'payroll.payroll_employee_designation = designation.designation_id', 'LEFT')
		->join('department', 'payroll.payroll_employee_department = department.department_id', 'LEFT')
		->where('payroll.payroll_status', 1)
		->where('payroll.payroll_employee_status', 1)
		->order_by('designation.designation_id', 'ASC') 
		->order_by('designation.designation_grade', 'ASC')  
		->order_by('payroll.payroll_employee_id_number', 'ASC') 
		->get()
		->result();
		
		$output = '';
		$serial = 0;
		$serial_cpount = 0;
		foreach($payroll as $row)
		{
		$salary_payable_amount = $row->payroll_gross_salary-10;
		$salary_paid_amount = $row->payroll_gross_salary-10;
		?>
		<tr>
			<td class="text-center">
				<?= str_pad(++$serial, 2, '0', STR_PAD_LEFT);?>
				<input type="hidden" class="text-center bd-danger" name="count" value="<?= ++$serial_cpount;?>"readonly>
				<input type="hidden" class="text-center bd-danger" name="salary_employee[]" value="<?= $row->payroll_employee;?>"readonly>
				<input type="hidden" class="text-center bd-danger" name="salary_employee_id_number[]" value="<?= $row->payroll_employee_id_number;?>"readonly>
				<input type="hidden" class="text-center bd-danger" name="salary_employee_name[]" value="<?= $row->payroll_employee_name;?>"readonly>
				<input type="hidden" class="text-center bd-danger" name="salary_employee_designation[]" value="<?= $row->payroll_employee_designation;?>"readonly>
				<input type="hidden" class="text-center bd-danger" name="salary_employee_department[]" value="<?= $row->payroll_employee_department;?>"readonly>
				<input type="hidden" class="text-center bd-danger" name="salary_employee_grade[]" value="<?= $row->payroll_employee_grade;?>"readonly>
			</td>
			<td class="text-left"><?= $row->payroll_employee_name;?></td>
			<td class="text-left"><?= $row->designation_name;?></td>
			<td class="text-center"><input type="text" class="text-center bd-danger" id="salary_basic_salary_<?= $row->payroll_id;?>" name="salary_basic_salary[]" value="<?= $row->payroll_basic_salary;?>"readonly></td>
			<td class="text-center"><input type="text" class="text-center bd-danger" id="salary_house_rent_salary_<?= $row->payroll_id;?>" name="salary_house_rent_salary[]" value="<?= $row->payroll_house_rent_salary;?>"readonly></td>
			<td class="text-center"><input type="text" class="text-center bd-danger" id="salary_medical_allowance_<?= $row->payroll_id;?>" name="salary_medical_allowance[]" value="<?= $row->payroll_house_rent_salary;?>"readonly></td>
			<td class="text-center"><input type="text" class="text-center bd-danger" id="salary_conveyance_allowance_<?= $row->payroll_id;?>" name="salary_conveyance_allowance[]" value="<?= $row->payroll_conveyance_allowance;?>"readonly></td>
			<td class="text-center"><input type="text" class="text-center bd-info" id="salary_others_allowance_<?= $row->payroll_id;?>" name="salary_others_allowance[]" value="<?= $row->payroll_others_allowance;?>"></td>
			<td class="text-center"><input type="text" class="text-center bd-danger" id="salary_gross_salary_<?= $row->payroll_id;?>" name="salary_gross_salary[]" value="<?= $row->payroll_gross_salary;?>"readonly></td>
			<td class="text-center"><input type="text" class="text-center bd-info" id="salary_deduction_stamp_<?= $row->payroll_id;?>" name="salary_deduction_stamp[]" value="10.00"></td>
			<td class="text-center"><input type="text" class="text-center bd-info" id="salary_deduction_tax_<?= $row->payroll_id;?>" name="salary_deduction_tax[]" value=""></td>
			<td class="text-center"><input type="text" class="text-center bd-info" id="salary_deduction_vat_<?= $row->payroll_id;?>" name="salary_deduction_vat[]" value=""></td>
			<td class="text-center"><input type="text" class="text-center bd-info" id="salary_deduction_others_<?= $row->payroll_id;?>" name="salary_deduction_others[]" value=""></td>
			<td class="text-center"><input type="text" class="text-center bd-danger" id="salary_payable_amount_<?= $row->payroll_id;?>" name="salary_payable_amount[]" value="<?= $salary_payable_amount;?>"readonly></td>
			<td class="text-center"><input type="text" class="text-center bd-info" id="salary_paid_amount_<?= $row->payroll_id;?>" name="salary_paid_amount[]" value="<?= $salary_paid_amount;?>"></td>
		</tr>
		<script> 
			$(document).ready(function(){
				$('#salary_others_allowance_<?= $row->payroll_id;?>').keyup(function(){ 
				   var basic_salary				= Number($('#salary_basic_salary_<?= $row->payroll_id;?>').val());
				   var house_rent				= Number($('#salary_house_rent_salary_<?= $row->payroll_id;?>').val());
				   var medical_allowance		= Number($('#salary_medical_allowance_<?= $row->payroll_id;?>').val());
				   var conveyance_allowance		= Number($('#salary_conveyance_allowance_<?= $row->payroll_id;?>').val());
				   var others_allowance			= Number($('#salary_others_allowance_<?= $row->payroll_id;?>').val());
				   var salary_gross_salary		= basic_salary+house_rent+medical_allowance+conveyance_allowance+others_allowance;
				   
				   $('#salary_gross_salary_<?= $row->payroll_id;?>').val(salary_gross_salary.toFixed(2));
				});
			});  
			
			$(document).ready(function(){
				$('#salary_others_allowance_<?= $row->payroll_id;?>, #salary_deduction_stamp_<?= $row->payroll_id;?>, #salary_deduction_tax_<?= $row->payroll_id;?>, #salary_deduction_vat_<?= $row->payroll_id;?>, #salary_deduction_others_<?= $row->payroll_id;?>').keyup(function(){ 
				   var deduction_stamp		= Number($('#salary_deduction_stamp_<?= $row->payroll_id;?>').val());
				   var deduction_tax		= Number($('#salary_deduction_tax_<?= $row->payroll_id;?>').val());
				   var deduction_vat		= Number($('#salary_deduction_vat_<?= $row->payroll_id;?>').val());
				   var deduction_others		= Number($('#salary_deduction_others_<?= $row->payroll_id;?>').val()); 
				   var gross_salary			= Number($('#salary_gross_salary_<?= $row->payroll_id;?>').val()); 
				   var deduction			= deduction_stamp+deduction_tax+deduction_vat+deduction_others;
				   var payable				= gross_salary-deduction;
				   var paid_amount			= gross_salary-deduction;
				   
				   $('#salary_payable_amount_<?= $row->payroll_id;?>').val(payable.toFixed(2)); 
				   $('#salary_paid_amount_<?= $row->payroll_id;?>').val(paid_amount.toFixed(2));
				});
			});   
		</script>
		<?php }?>
		<tr>
			<td colspan="15">
				&nbsp;
			</td>
		</tr>
		<tr>
			<td colspan="15">
				<button type="submit" class="btn btn-brand btn-block btn-success text-uppercase"  onclick="return confirm('<?= $this->lang->line("model_create_warning");?>')"><?= $this->lang->line('submit');?></button>
			</td>
		</tr>
		<?php 
		return $output;
	}
	
	/* ------------------------------------------------------
	Salary Create Model
	------------------------------------------------------- */
	function salary_create($data)
	{
		$this->db->insert_batch('salary', $data);
		return True;
	} 
	
	
	/* ------------------------------------------------------
	Salary Sheet Info Model
	------------------------------------------------------- */
	function salary_sheet($salary_month)
	{	
		$salary_starting_date = date('Y-m-01', strtotime($salary_month));
		$salary_closing_date = date('Y-m-t', strtotime($salary_month));
		
		$salary =  $this->db->select("*")
		->from('salary')
		->join('designation', 'salary.salary_employee_designation = designation.designation_id', 'LEFT')
		->join('department', 'salary.salary_employee_department = department.department_id', 'LEFT')
		->where('salary.salary_month BETWEEN "'.$salary_starting_date.'" and "'.$salary_closing_date.'"')
		->where('salary.salary_status', 1)
		->order_by('designation.designation_id', 'ASC') 
		->order_by('designation.designation_grade', 'ASC') 
		->order_by('salary.salary_employee_id_number', 'ASC') 
		->get()
		->result();
		
		$output = '';
		$serial = 0;
		$serial_cpount = 0;
		$basic_salary = 0;
		$house_rent = 0;
		$medical_allowance = 0;
		$conveyance_allowance = 0;
		$others_allowance = 0;
		$gross_salary = 0;
		$bonus = 0;
		$deduction_stamp = 0;
		$deduction_tax = 0;
		$deduction_vat = 0;
		$deduction_advance = 0;
		$deduction_loan = 0;
		$deduction_others = 0;
		$payable_amount = 0;
		$paid_amount = 0;
		$due_amount = 0;
		
		foreach($salary as $row)
		{
		$basic_salary += $row->salary_basic_salary;
		$house_rent += $row->salary_house_rent_salary;
		$medical_allowance += $row->salary_medical_allowance;
		$conveyance_allowance += $row->salary_conveyance_allowance;
		$others_allowance += $row->salary_others_allowance;
		$gross_salary += $row->salary_gross_salary;
		$bonus += $row->salary_bonus;
		$deduction_stamp += $row->salary_deduction_stamp;
		$deduction_tax += $row->salary_deduction_tax;
		$deduction_vat += $row->salary_deduction_vat;
		$deduction_advance += $row->salary_deduction_advance;
		$deduction_loan += $row->salary_deduction_loan;
		$deduction_others += $row->salary_deduction_others;
		$payable_amount += $row->salary_payable_amount;
		$paid_amount += $row->salary_paid_amount;
		$due_amount += $row->salary_due_amount;
		?>
		<tr>
			<td class="text-center"><?= str_pad(++$serial, 2, '0', STR_PAD_LEFT);?></td>
			<td class="text-left"><?= $row->salary_employee_name;?></td>
			<td class="text-left"><?= $row->designation_name;?></td>
			<td class="text-right"><?= number_format($row->salary_basic_salary,2 . '');?></td>
			<td class="text-right"><?= number_format($row->salary_house_rent_salary,2 . '');?></td>
			<td class="text-right"><?= number_format($row->salary_medical_allowance,2 . '');?></td>
			<td class="text-right"><?= number_format($row->salary_conveyance_allowance,2 . '');?></td>
			<td class="text-right"><?= number_format($row->salary_others_allowance,2 . '');?></td>
			<td class="text-right"><?= number_format($row->salary_gross_salary,2 . '');?></td>
			<td class="text-right"><?= number_format($row->salary_bonus,2 . '');?></td>
			<td class="text-right"><?= number_format($row->salary_deduction_stamp,2 . '');?></td>
			<td class="text-right"><?= number_format($row->salary_deduction_tax,2 . '');?></td>
			<td class="text-right"><?= number_format($row->salary_deduction_vat,2 . '');?></td>
			<td class="text-right"><?= number_format($row->salary_deduction_advance,2 . '');?></td>
			<td class="text-right"><?= number_format($row->salary_deduction_loan,2 . '');?></td>
			<td class="text-right"><?= number_format($row->salary_deduction_others,2 . '');?></td>
			<td class="text-right"><?= number_format($row->salary_payable_amount,2 . '');?></td>
			<td class="text-right"><?= number_format($row->salary_paid_amount,2 . '');?></td>
			<td class="text-right"><?= number_format($row->salary_due_amount,2 . '');?></td>
		</tr>
		<?php }?>
		<tr class="text-uppercase">
			<th class="text-center" colspan="3"><?= $this->lang->line('total');?></th> 
			<th class="text-right"><?= number_format($basic_salary,2 . '');?></th>
			<th class="text-right"><?= number_format($house_rent,2 . '');?></th>
			<th class="text-right"><?= number_format($medical_allowance,2 . '');?></th>
			<th class="text-right"><?= number_format($conveyance_allowance,2 . '');?></th>
			<th class="text-right"><?= number_format($others_allowance,2 . '');?></th>
			<th class="text-right"><?= number_format($gross_salary,2 . '');?></th>
			<th class="text-right"><?= number_format($bonus,2 . '');?></th> 
			<th class="text-right"><?= number_format($deduction_stamp,2 . '');?></th>
			<th class="text-right"><?= number_format($deduction_tax,2 . '');?></th>
			<th class="text-right"><?= number_format($deduction_vat,2 . '');?></th>
			<th class="text-right"><?= number_format($deduction_advance,2 . '');?></th>
			<th class="text-right"><?= number_format($deduction_loan,2 . '');?></th>
			<th class="text-right"><?= number_format($deduction_others,2 . '');?></th>
			<th class="text-right"><?= number_format($payable_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($paid_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($due_amount,2 . '');?></th>
		</tr>
		<?php		
		return $output;
	} 
	 
	/* ------------------------------------------------------
	Collection Summary Report Model
	------------------------------------------------------- */
	function collection_summary_report_old($from_date, $to_date, $user)
	{
		$output = '';
		
		$appointment_sum =  $this->db->select("SUM(appointment_fees) as appointment_bill_amount, SUM(appointment_discount) as appointment_discount_amount, SUM(appointment_amount) as appointment_receivable_amount, SUM(appointment_paid_amount) as appointment_collection_amount, SUM(appointment_due_amount) as appointment_due_amount, SUM(appointment_doctor_charge) as appointment_doctor_charge, SUM(appointment_due_amount) as appointment_due_amount")
		->from('appointment') 
		->where('appointment_status', 1)
		->where('appointment_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
		->order_by('appointment_date', 'ASC')
		->get()
		->result();
		foreach($appointment_sum as $appointment_row){  
			$appointment_bill_amount		= $appointment_row->appointment_bill_amount;
			$appointment_discount_amount	= $appointment_row->appointment_discount_amount;
			$appointment_deposit_amount		= 0; 
			$appointment_receivable_amount	= $appointment_row->appointment_receivable_amount;
			$appointment_collection_amount	= $appointment_row->appointment_collection_amount;
			$appointment_due_amount			= $appointment_row->appointment_due_amount;
			$appointment_rc_amount			= 0;
			$appointment_doctor_charge		= $appointment_row->appointment_doctor_charge;
			$appointment_others_charge		= 0;
			$appointment_balance_amount		= $appointment_collection_amount-($appointment_doctor_charge+$appointment_others_charge); 
		}
		$investigation_sum =  $this->db->select("SUM(investigation_test_rate) as investigation_bill_amount, SUM(investigation_discount_amount) as investigation_discount_amount, SUM(investigation_amount) as investigation_receivable_amount, SUM(investigation_paid_amount) as investigation_collection_amount, SUM(investigation_rc_amount) as investigation_rc_amount, SUM(investigation_doctor_charge) as investigation_doctor_charge, SUM(investigation_others_charge) as investigation_others_charge")
		->from('investigation') 
		->where('investigation_status', 1)
		->where('investigation_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
		->order_by('investigation_id', 'ASC')
		->get()
		->result();
		foreach($investigation_sum as $investigation_row){  
			
			$query_amount =  $this->db->select("SUM(investigation_collection_amount) as collection_amount")
			->from('investigation_collection')   
			->where('investigation_collection_status', 1)  
			->where('investigation_collection_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
			->order_by('investigation_collection_id', 'ASC')
			->get()	
			->result(); 	
			foreach($query_amount as $collection_row){   
			$investigation_collection_amount 	= $collection_row->collection_amount;
			}
			$investigation_bill_amount			= $investigation_row->investigation_bill_amount;
			$investigation_discount_amount		= $investigation_row->investigation_discount_amount;
			$investigation_deposit_amount		= 0; 
			$investigation_receivable_amount	= $investigation_row->investigation_receivable_amount; 
			$investigation_due_amount			= $investigation_receivable_amount-$investigation_collection_amount;
			$investigation_rc_amount			= $investigation_row->investigation_rc_amount;
			$investigation_doctor_charge		= $investigation_row->investigation_doctor_charge;
			$investigation_others_charge		= $investigation_row->investigation_others_charge;
			$investigation_balance_amount		= $investigation_collection_amount-($investigation_rc_amount+$investigation_doctor_charge+$investigation_others_charge); 
		}
		
		$admission_sum =  $this->db->select("SUM(admission_fee) as admission_fee")
		->from('admission') 
		->where('admission_status', 1)
		->where('admission_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
		->order_by('admission_id', 'ASC')
		->get()
		->result();
		foreach($admission_sum as $admission_row){  
			
			$admission_bill_amount			= $admission_row->admission_fee;
			$admission_discount_amount		= 0;  
			$admission_deposit_amount		= 0;  
			$admission_receivable_amount	= $admission_row->admission_fee;
			$admission_collection_amount	= $admission_row->admission_fee;
			$admission_due_amount			= 0;
			$admission_rc_amount			= 0;
			$admission_doctor_charge		= 0;
			$admission_others_charge		= 0;
			$admission_balance_amount		= $admission_row->admission_fee;
		} 
		
		$admission_deposit_sum =  $this->db->select("SUM(admission_deposit_amount) as admission_deposit_amount")
		->from('admission_deposit') 
		->where('admission_deposit_status', 1)
		->where('admission_deposit_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
		->order_by('admission_deposit_id', 'ASC')
		->get()
		->result();
		foreach($admission_deposit_sum as $admission_deposit_row){  
			
			$admission_deposit_bill_amount			= $admission_deposit_row->admission_deposit_amount;
			$admission_deposit_discount_amount		= 0;  
			$admission_deposit_deposit_amount		= 0;  
			$admission_deposit_receivable_amount	= $admission_deposit_row->admission_deposit_amount;
			$admission_deposit_collection_amount	= $admission_deposit_row->admission_deposit_amount;
			$admission_deposit_due_amount			= 0;
			$admission_deposit_rc_amount			= 0;
			$admission_deposit_doctor_charge		= 0;
			$admission_deposit_others_charge		= 0;
			$admission_deposit_balance_amount		= $admission_deposit_row->admission_deposit_amount;
		}
		
		$bill_collection_sum =  $this->db->select("SUM(bill_collection_sub_total_amount) as bill_collection_bill_amount, SUM(bill_collection_discount_amount) as bill_collection_discount_amount, SUM(bill_collection_payable_amount) as bill_collection_receivable_amount, SUM(bill_collection_paid_amount) as bill_collection_collection_amount, SUM(bill_collection_due_amount) as bill_collection_due_amount, SUM(bill_collection_patient_rc_amount) as bill_collection_rc_amount, SUM(bill_collection_patient_doctor_charge) as bill_collection_doctor_charge, SUM(bill_collection_patient_others_charge) as bill_collection_others_charge")
		->from('bill_collection') 
		->where('bill_collection_status', 1)
		->where('bill_collection_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
		->order_by('bill_collection_id', 'ASC')
		->get()
		->result();
		foreach($bill_collection_sum as $bill_collection_row){  
			
			$deposit = $this->db->select("SUM(admission_deposit_amount) as deposit_amount")
			->from('admission_deposit')  
			->where('admission_deposit_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
			->where('admission_deposit_status', 1)  
			->order_by('admission_deposit_id', 'ASC') 
			->get()
			->result();
			foreach($deposit as $deposit_row)
			{
				$admission_deposit_amount = $deposit_row->deposit_amount;
			}
			
			$bill_collection_bill_amount		= $bill_collection_row->bill_collection_bill_amount;
			$bill_collection_discount_amount	= $bill_collection_row->bill_collection_discount_amount;
			$bill_collection_deposit_amount		= $admission_deposit_amount; 
			$bill_collection_receivable_amount	= $bill_collection_row->bill_collection_receivable_amount; 
			$bill_collection_collection_amount	= $bill_collection_row->bill_collection_collection_amount; 
			$bill_collection_due_amount			= $bill_collection_receivable_amount-$bill_collection_collection_amount;
			$bill_collection_rc_amount			= $bill_collection_row->bill_collection_rc_amount;
			$bill_collection_doctor_charge		= $bill_collection_row->bill_collection_doctor_charge;
			$bill_collection_others_charge		= $bill_collection_row->bill_collection_others_charge;
			$bill_collection_balance_amount		= $bill_collection_collection_amount-($bill_collection_rc_amount+$bill_collection_doctor_charge+$bill_collection_others_charge); 
		}
		?>
		<tr>
			<td class="text-center">01</td>
			<td class="text-center" rowspan="2">OPD</td> 
			<td class="text-left">Appointment</td> 
			<td class="text-right"><?= number_format($appointment_bill_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($appointment_discount_amount,2 . '');?></td>    
			<td class="text-right"><?= number_format($admission_deposit_deposit_amount,2 . '');?></td>  
			<td class="text-right"><?= number_format($appointment_receivable_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($appointment_collection_amount,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("appointment/appointment_collection_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td> 
			<td class="text-right"><?= number_format($appointment_due_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($appointment_rc_amount,2 . '');?></td>
			<td class="text-right"><?= number_format($appointment_doctor_charge,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("appointment/doctor_charge_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($appointment_others_charge,2 . '');?></td>
			<td class="text-right"><?= number_format($appointment_balance_amount,2 . '');?></td>
		</tr> 
		
		<tr>
			<td class="text-center">02</td>
			<td class="text-left">Investigation</td> 
			 
			<td class="text-right"><?= number_format($investigation_bill_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($investigation_discount_amount,2 . '');?></td>    
			<td class="text-right"><?= number_format($investigation_deposit_amount,2 . '');?></td>  
			<td class="text-right"><?= number_format($investigation_receivable_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($investigation_collection_amount,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("investigation/investigation_collection_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($investigation_due_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($investigation_rc_amount,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("reference/reference_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($investigation_doctor_charge,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("investigation/doctor_charge_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($investigation_others_charge,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("investigation/others_charge_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($investigation_balance_amount,2 . '');?></td>
		</tr>  
		
		<?php 
		$opd_bill_amount  		= $appointment_bill_amount + $investigation_bill_amount;
		$opd_discount_amount	= $appointment_discount_amount + $investigation_discount_amount;
		$opd_deposit_amount		= $appointment_deposit_amount + $investigation_deposit_amount;
		$opd_receivable_amount	= $appointment_receivable_amount + $investigation_receivable_amount;
		$opd_collection_amount	= $appointment_collection_amount + $investigation_collection_amount;
		$opd_due_amount			= $appointment_due_amount + $investigation_due_amount;
		$opd_rc_amount			= $appointment_rc_amount + $investigation_rc_amount;
		$opd_doctor_charge		= $appointment_doctor_charge + $investigation_doctor_charge;
		$opd_others_charge		= $appointment_others_charge + $investigation_others_charge;
		$opd_balance_amount		= $appointment_balance_amount + $investigation_balance_amount;
		?>
		<tr class="text-right"> 
			<th class="text-right" colspan="3">Sub Total</th>
			<th class="text-right"><?= number_format($opd_bill_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($opd_discount_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($opd_deposit_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($opd_receivable_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($opd_collection_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($opd_due_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($opd_rc_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($opd_doctor_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($opd_others_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($opd_balance_amount,2 . '');?></th>
		</tr>  
		<tr>
			<td class="text-center">03</td>
			<td class="text-center" rowspan="3">IPD</td> 
			<td class="text-left">Admission Fee</td> 
			<td class="text-right"><?= number_format($admission_bill_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($admission_discount_amount,2 . '');?></td>    
			<td class="text-right"><?= number_format(0,2 . '');?></td>  
			<td class="text-right"><?= number_format($admission_receivable_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($admission_collection_amount,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("admission/admission_fee_collection_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td> 
			<td class="text-right"><?= number_format($admission_due_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($admission_rc_amount,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_doctor_charge,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_others_charge,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_balance_amount,2 . '');?></td>
		</tr> 
		 
		<tr>
			<td class="text-center">04</td>
			<td class="text-left">Admission Deposit</td> 
			<td class="text-right"><?= number_format($admission_deposit_bill_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($admission_deposit_discount_amount,2 . '');?></td>    
			<td class="text-right"><?= number_format($admission_deposit_deposit_amount,2 . '');?></td>  
			<td class="text-right"><?= number_format($admission_deposit_receivable_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($admission_deposit_collection_amount,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("admission/admission_deposit_collection_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td> 
			<td class="text-right"><?= number_format($admission_deposit_due_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($admission_deposit_rc_amount,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_deposit_doctor_charge,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_deposit_others_charge,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_deposit_balance_amount,2 . '');?></td>
		</tr> 
		 
		<tr>
			<td class="text-center">05</td>
			<td class="text-left">IPD Bill Collection</td> 
			<td class="text-right"><?= number_format($bill_collection_bill_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($bill_collection_discount_amount,2 . '');?></td>    
			<td class="text-right"><?= number_format($bill_collection_deposit_amount,2 . '');?></td>  
			<td class="text-right"><?= number_format($bill_collection_receivable_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($bill_collection_collection_amount,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("admission/bill_collection_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td> 
			<td class="text-right"><?= number_format($bill_collection_due_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($bill_collection_rc_amount,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("admission/bill_collection_rc_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($bill_collection_doctor_charge,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("admission/bill_collection_doctor_charge_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($bill_collection_others_charge,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("admission/bill_collection_others_charge_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($bill_collection_balance_amount,2 . '');?></td>
		</tr>  
		
		<?php 
		$ipd_bill_amount  		= $admission_bill_amount + $admission_deposit_bill_amount + $bill_collection_bill_amount;
		$ipd_discount_amount	= $admission_discount_amount + $admission_deposit_discount_amount + $bill_collection_discount_amount;
		$ipd_deposit_amount		= $admission_deposit_deposit_amount + $bill_collection_deposit_amount;
		$ipd_receivable_amount	= $admission_receivable_amount + $admission_deposit_receivable_amount + $bill_collection_receivable_amount;
		$ipd_collection_amount	= $admission_collection_amount + $admission_deposit_collection_amount + $bill_collection_collection_amount;
		$ipd_due_amount			= $admission_due_amount + $admission_deposit_due_amount + $bill_collection_due_amount;
		$ipd_rc_amount			= $admission_rc_amount + $admission_deposit_rc_amount + $bill_collection_rc_amount;
		$ipd_doctor_charge		= $admission_doctor_charge + $admission_deposit_doctor_charge + $bill_collection_doctor_charge;
		$ipd_others_charge		= $admission_others_charge + $admission_deposit_others_charge + $bill_collection_others_charge;
		$ipd_balance_amount		= $admission_balance_amount + $admission_deposit_balance_amount + $bill_collection_balance_amount;
		?>
		<tr class="text-right"> 
			<th class="text-right" colspan="3">Sub Total</th>
			<th class="text-right"><?= number_format($ipd_bill_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($ipd_discount_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($ipd_deposit_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($ipd_receivable_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($ipd_collection_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($ipd_due_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($ipd_rc_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($ipd_doctor_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($ipd_others_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($ipd_balance_amount,2 . '');?></th>
		</tr>  
		
		<?php 
		$bill_amount  		= $opd_bill_amount + $ipd_bill_amount;
		$discount_amount	= $opd_discount_amount + $ipd_discount_amount;
		$deposit_amount		= $opd_deposit_amount + $ipd_deposit_amount;
		$receivable_amount	= $opd_receivable_amount + $ipd_receivable_amount;
		$collection_amount	= $opd_collection_amount + $ipd_collection_amount;
		$due_amount			= $opd_due_amount + $ipd_due_amount;
		$rc_amount			= $opd_rc_amount + $ipd_rc_amount;
		$doctor_charge		= $opd_doctor_charge + $ipd_doctor_charge;
		$others_charge		= $opd_others_charge + $ipd_others_charge;
		$balance_amount		= $opd_balance_amount + $ipd_balance_amount;
		?> 
		<tr class="text-uppercase"> 
			<th class="text-right" colspan="3">Grand Total</th>
			<th class="text-right"><?= number_format($bill_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($discount_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($deposit_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($receivable_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($collection_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($due_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($rc_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($doctor_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($others_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($balance_amount,2 . '');?></th>
		</tr>  
		
		<tr class="text-uppercase">
			<th class="text-left" colspan="18">
			<?= $this->lang->line('in_word');?>: 
			<?php 
			$number 		= abs($balance_amount);
			$in_word_amount = $this->number_to_word_convert->convert_number($number);
			?>
			<?= $in_word_amount;?> <?= $this->lang->line('currency_only');?>.
			</th>
		</tr>
		<?php return $output;
	}  
	 
	/* ------------------------------------------------------
	Collection Summary Report Model
	------------------------------------------------------- */
	function collection_summary_report($from_date, $to_date, $user)
	{
		$output = '';
		
		$appointment_sum =  $this->db->select("SUM(appointment_fees) as appointment_bill_amount, SUM(appointment_discount) as appointment_discount_amount, SUM(appointment_amount) as appointment_receivable_amount, SUM(appointment_paid_amount) as appointment_collection_amount, SUM(appointment_due_amount) as appointment_due_amount, SUM(appointment_doctor_charge) as appointment_doctor_charge, SUM(appointment_due_amount) as appointment_due_amount")
		->from('appointment') 
		->where('appointment_status', 1)
		->where('appointment_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
		->order_by('appointment_date', 'ASC')
		->get()
		->result();
		foreach($appointment_sum as $appointment_row){  
			$appointment_bill_amount		= $appointment_row->appointment_bill_amount;
			$appointment_discount_amount	= $appointment_row->appointment_discount_amount;
			$appointment_deposit_amount		= 0; 
			$appointment_receivable_amount	= $appointment_row->appointment_receivable_amount;
			$appointment_collection_amount	= $appointment_row->appointment_collection_amount;
			$appointment_due_amount			= $appointment_row->appointment_due_amount;
			$appointment_rc_amount			= 0;
			$appointment_doctor_charge		= $appointment_row->appointment_doctor_charge;
			$appointment_others_charge		= 0;
			$appointment_balance_amount		= $appointment_collection_amount-($appointment_doctor_charge+$appointment_others_charge); 
		}
		$investigation_sum =  $this->db->select("SUM(investigation_test_rate) as investigation_bill_amount, SUM(investigation_discount_amount) as investigation_discount_amount, SUM(investigation_amount) as investigation_receivable_amount, SUM(investigation_paid_amount) as investigation_collection_amount, SUM(investigation_rc_amount) as investigation_rc_amount, SUM(investigation_doctor_charge) as investigation_doctor_charge, SUM(investigation_others_charge) as investigation_others_charge")
		->from('investigation') 
		->where('investigation_status', 1)
		->where('investigation_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
		->order_by('investigation_id', 'ASC')
		->get()
		->result();
		foreach($investigation_sum as $investigation_row){  
			
			$query_amount =  $this->db->select("SUM(investigation_collection_amount) as collection_amount")
			->from('investigation_collection')   
			->where('investigation_collection_status', 1)  
			->where('investigation_collection_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
			->order_by('investigation_collection_id', 'ASC')
			->get()	
			->result(); 	
			foreach($query_amount as $collection_row){   
			$investigation_collection_amount 	= $collection_row->collection_amount;
			}
			$investigation_bill_amount			= $investigation_row->investigation_bill_amount;
			$investigation_discount_amount		= $investigation_row->investigation_discount_amount;
			$investigation_deposit_amount		= 0; 
			$investigation_receivable_amount	= $investigation_row->investigation_receivable_amount; 
			$investigation_due_amount			= $investigation_receivable_amount-$investigation_collection_amount;
			$investigation_rc_amount			= $investigation_row->investigation_rc_amount;
			$investigation_doctor_charge		= $investigation_row->investigation_doctor_charge;
			$investigation_others_charge		= $investigation_row->investigation_others_charge;
			$investigation_balance_amount		= $investigation_collection_amount-($investigation_rc_amount+$investigation_doctor_charge+$investigation_others_charge); 
		}
		
		$admission_sum =  $this->db->select("SUM(admission_fee) as admission_fee")
		->from('admission') 
		->where('admission_status', 1)
		->where('admission_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
		->order_by('admission_id', 'ASC')
		->get()
		->result();
		foreach($admission_sum as $admission_row){  
			
			$admission_bill_amount			= $admission_row->admission_fee;
			$admission_discount_amount		= 0;  
			$admission_deposit_amount		= 0;  
			$admission_receivable_amount	= $admission_row->admission_fee;
			$admission_collection_amount	= $admission_row->admission_fee;
			$admission_due_amount			= 0;
			$admission_rc_amount			= 0;
			$admission_doctor_charge		= 0;
			$admission_others_charge		= 0;
			$admission_balance_amount		= $admission_row->admission_fee;
		} 
		
		$admission_deposit_sum =  $this->db->select("SUM(admission_deposit_amount) as admission_deposit_amount")
		->from('admission_deposit') 
		->where('admission_deposit_status', 1)
		->where('admission_deposit_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
		->order_by('admission_deposit_id', 'ASC')
		->get()
		->result();
		foreach($admission_deposit_sum as $admission_deposit_row){  
			
			$admission_deposit_bill_amount			= $admission_deposit_row->admission_deposit_amount;
			$admission_deposit_discount_amount		= 0;  
			$admission_deposit_deposit_amount		= 0;  
			$admission_deposit_receivable_amount	= $admission_deposit_row->admission_deposit_amount;
			$admission_deposit_collection_amount	= $admission_deposit_row->admission_deposit_amount;
			$admission_deposit_due_amount			= 0;
			$admission_deposit_rc_amount			= 0;
			$admission_deposit_doctor_charge		= 0;
			$admission_deposit_others_charge		= 0;
			$admission_deposit_balance_amount		= $admission_deposit_row->admission_deposit_amount;
		}
		
		$bill_collection_sum =  $this->db->select("SUM(bill_collection_sub_total_amount) as bill_collection_bill_amount, SUM(bill_collection_discount_amount) as bill_collection_discount_amount, SUM(bill_collection_payable_amount) as bill_collection_receivable_amount, SUM(bill_collection_paid_amount) as bill_collection_collection_amount, SUM(bill_collection_due_amount) as bill_collection_due_amount, SUM(bill_collection_patient_rc_amount) as bill_collection_rc_amount, SUM(bill_collection_patient_doctor_charge) as bill_collection_doctor_charge, SUM(bill_collection_patient_others_charge) as bill_collection_others_charge")
		->from('bill_collection') 
		->where('bill_collection_status', 1)
		->where('bill_collection_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
		->order_by('bill_collection_id', 'ASC')
		->get()
		->result();
		foreach($bill_collection_sum as $bill_collection_row){  
			
			$deposit = $this->db->select("SUM(admission_deposit_amount) as deposit_amount")
			->from('admission_deposit')  
			->where('admission_deposit_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
			->where('admission_deposit_status', 1)  
			->order_by('admission_deposit_id', 'ASC') 
			->get()
			->result();
			foreach($deposit as $deposit_row)
			{
				$admission_deposit_amount = $deposit_row->deposit_amount;
			}
			
			$doctor_charge = $this->db->select("SUM(admission_doctor_charge_doctor) as admission_doctor_charge, SUM(admission_doctor_charge_others) as admission_others_charge")
			->from('admission_doctor_charge')  
			->where('admission_doctor_charge_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
			->where('admission_doctor_charge_status', 1)  
			->order_by('admission_doctor_charge_id', 'ASC') 
			->get()
			->result();
			foreach($doctor_charge as $doctor_charge_row)
			{
				$a_doctor_charge = $doctor_charge_row->admission_doctor_charge;
				$a_others_charge = $doctor_charge_row->admission_others_charge;
			}
			
			$bill_collection_bill_amount		= $bill_collection_row->bill_collection_bill_amount;
			$bill_collection_discount_amount	= $bill_collection_row->bill_collection_discount_amount;
			$bill_collection_deposit_amount		= $admission_deposit_amount; 
			$bill_collection_receivable_amount	= $bill_collection_row->bill_collection_receivable_amount; 
			$bill_collection_collection_amount	= $bill_collection_row->bill_collection_collection_amount; 
			$bill_collection_due_amount			= $bill_collection_receivable_amount-$bill_collection_collection_amount;
			$bill_collection_rc_amount			= $bill_collection_row->bill_collection_rc_amount;
			$bill_collection_doctor_charge		= $a_doctor_charge;
			$bill_collection_others_charge		= $a_others_charge;
			$bill_collection_balance_amount		= $bill_collection_collection_amount-($bill_collection_rc_amount+$bill_collection_doctor_charge+$bill_collection_others_charge); 
		}
		?>
		<tr>
			<td class="text-center">01</td>
			<td class="text-center" rowspan="2">OPD</td> 
			<td class="text-left">Appointment</td>      
			<td class="text-right"><?= number_format($appointment_collection_amount,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("appointment/appointment_collection_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>  
			<td class="text-right"><?= number_format($appointment_rc_amount,2 . '');?></td>
			<td class="text-right"><?= number_format($appointment_doctor_charge,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("appointment/doctor_charge_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($appointment_others_charge,2 . '');?></td>
			<td class="text-right"><?= number_format($appointment_balance_amount,2 . '');?></td>
		</tr> 
		
		<tr>
			<td class="text-center">02</td>
			<td class="text-left">Investigation</td> 
			  
			<td class="text-right"><?= number_format($investigation_collection_amount,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("investigation/investigation_collection_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td> 
			<td class="text-right"><?= number_format($investigation_rc_amount,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("reference/reference_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($investigation_doctor_charge,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("investigation/doctor_charge_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($investigation_others_charge,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("investigation/others_charge_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($investigation_balance_amount,2 . '');?></td>
		</tr>  
		
		<?php 
		$opd_bill_amount  		= $appointment_bill_amount + $investigation_bill_amount;
		$opd_discount_amount	= $appointment_discount_amount + $investigation_discount_amount;
		$opd_deposit_amount		= $appointment_deposit_amount + $investigation_deposit_amount;
		$opd_receivable_amount	= $appointment_receivable_amount + $investigation_receivable_amount;
		$opd_collection_amount	= $appointment_collection_amount + $investigation_collection_amount;
		$opd_due_amount			= $appointment_due_amount + $investigation_due_amount;
		$opd_rc_amount			= $appointment_rc_amount + $investigation_rc_amount;
		$opd_doctor_charge		= $appointment_doctor_charge + $investigation_doctor_charge;
		$opd_others_charge		= $appointment_others_charge + $investigation_others_charge;
		$opd_balance_amount		= $appointment_balance_amount + $investigation_balance_amount;
		?>
		<tr class="text-right"> 
			<th class="text-right" colspan="3">Sub Total</th> 
			<th class="text-right"><?= number_format($opd_collection_amount,2 . '');?></th> 
			<th class="text-right"><?= number_format($opd_rc_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($opd_doctor_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($opd_others_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($opd_balance_amount,2 . '');?></th>
		</tr>  
		<tr>
			<td class="text-center">03</td>
			<td class="text-center" rowspan="3">IPD</td> 
			<td class="text-left">Admission Fee</td>  
			<td class="text-right"><?= number_format($admission_collection_amount,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("admission/admission_fee_collection_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>  
			<td class="text-right"><?= number_format($admission_rc_amount,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_doctor_charge,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_others_charge,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_balance_amount,2 . '');?></td>
		</tr> 
		 
		<tr>
			<td class="text-center">04</td>
			<td class="text-left">Admission Deposit</td>   
			<td class="text-right"><?= number_format($admission_deposit_collection_amount,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("admission/admission_deposit_collection_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>  
			<td class="text-right"><?= number_format($admission_deposit_rc_amount,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_deposit_doctor_charge,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_deposit_others_charge,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_deposit_balance_amount,2 . '');?></td>
		</tr> 
		 
		<tr>
			<td class="text-center">05</td>
			<td class="text-left">IPD Bill Collection</td>  
			<td class="text-right"><?= number_format($bill_collection_collection_amount,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("admission/bill_collection_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>  
			<td class="text-right"><?= number_format($bill_collection_rc_amount,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("admission/bill_collection_rc_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($bill_collection_doctor_charge,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("admission/bill_collection_doctor_charge_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($bill_collection_others_charge,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("admission/bill_collection_others_charge_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($bill_collection_balance_amount,2 . '');?></td>
		</tr>  
		
		<?php 
		$ipd_bill_amount  		= $admission_bill_amount + $admission_deposit_bill_amount + $bill_collection_bill_amount;
		$ipd_discount_amount	= $admission_discount_amount + $admission_deposit_discount_amount + $bill_collection_discount_amount;
		$ipd_deposit_amount		= $admission_deposit_deposit_amount + $bill_collection_deposit_amount;
		$ipd_receivable_amount	= $admission_receivable_amount + $admission_deposit_receivable_amount + $bill_collection_receivable_amount;
		$ipd_collection_amount	= $admission_collection_amount + $admission_deposit_collection_amount + $bill_collection_collection_amount;
		$ipd_due_amount			= $admission_due_amount + $admission_deposit_due_amount + $bill_collection_due_amount;
		$ipd_rc_amount			= $admission_rc_amount + $admission_deposit_rc_amount + $bill_collection_rc_amount;
		$ipd_doctor_charge		= $admission_doctor_charge + $admission_deposit_doctor_charge + $bill_collection_doctor_charge;
		$ipd_others_charge		= $admission_others_charge + $admission_deposit_others_charge + $bill_collection_others_charge;
		$ipd_balance_amount		= $admission_balance_amount + $admission_deposit_balance_amount + $bill_collection_balance_amount;
		?>
		<tr class="text-right"> 
			<th class="text-right" colspan="3">Sub Total</th> 
			<th class="text-right"><?= number_format($ipd_collection_amount,2 . '');?></th> 
			<th class="text-right"><?= number_format($ipd_rc_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($ipd_doctor_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($ipd_others_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($ipd_balance_amount,2 . '');?></th>
		</tr>  
		
		<?php 
		$bill_amount  		= $opd_bill_amount + $ipd_bill_amount;
		$discount_amount	= $opd_discount_amount + $ipd_discount_amount;
		$deposit_amount		= $opd_deposit_amount + $ipd_deposit_amount;
		$receivable_amount	= $opd_receivable_amount + $ipd_receivable_amount;
		$collection_amount	= $opd_collection_amount + $ipd_collection_amount;
		$due_amount			= $opd_due_amount + $ipd_due_amount;
		$rc_amount			= $opd_rc_amount + $ipd_rc_amount;
		$doctor_charge		= $opd_doctor_charge + $ipd_doctor_charge;
		$others_charge		= $opd_others_charge + $ipd_others_charge;
		$balance_amount		= $opd_balance_amount + $ipd_balance_amount;
		?> 
		<tr class="text-uppercase"> 
			<th class="text-right" colspan="3">Grand Total</th> 
			<th class="text-right"><?= number_format($collection_amount,2 . '');?></th> 
			<th class="text-right"><?= number_format($rc_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($doctor_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($others_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($balance_amount,2 . '');?></th>
		</tr>  
		
		<tr class="text-uppercase">
			<th class="text-left" colspan="18">
			<?= $this->lang->line('in_word');?>: 
			<?php 
			$number 		= abs($balance_amount);
			$in_word_amount = $this->number_to_word_convert->convert_number($number);
			?>
			<?= $in_word_amount;?> <?= $this->lang->line('currency_only');?>.
			</th>
		</tr>
		<?php return $output;
	} 
	
	/* ------------------------------------------------------
	Daily Collection Summary Report Model
	------------------------------------------------------- */
	function daily_collection_summary_old($to_date, $user)
	{
		$from_date = $to_date;
		$output = '';
		
		$appointment_sum =  $this->db->select("SUM(appointment_fees) as appointment_bill_amount, SUM(appointment_discount) as appointment_discount_amount, SUM(appointment_amount) as appointment_receivable_amount, SUM(appointment_paid_amount) as appointment_collection_amount, SUM(appointment_due_amount) as appointment_due_amount, SUM(appointment_doctor_charge) as appointment_doctor_charge, SUM(appointment_due_amount) as appointment_due_amount")
		->from('appointment') 
		->where('appointment_status', 1)
		->where('appointment_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
		->order_by('appointment_date', 'ASC')
		->get()
		->result();
		foreach($appointment_sum as $appointment_row){  
			$appointment_bill_amount		= $appointment_row->appointment_bill_amount;
			$appointment_discount_amount	= $appointment_row->appointment_discount_amount;
			$appointment_deposit_amount		= 0; 
			$appointment_receivable_amount	= $appointment_row->appointment_receivable_amount;
			$appointment_collection_amount	= $appointment_row->appointment_collection_amount;
			$appointment_due_amount			= $appointment_row->appointment_due_amount;
			$appointment_rc_amount			= 0;
			$appointment_doctor_charge		= $appointment_row->appointment_doctor_charge;
			$appointment_others_charge		= 0;
			$appointment_balance_amount		= $appointment_collection_amount-($appointment_doctor_charge+$appointment_others_charge); 
		}
		$investigation_sum =  $this->db->select("SUM(investigation_test_rate) as investigation_bill_amount, SUM(investigation_discount_amount) as investigation_discount_amount, SUM(investigation_amount) as investigation_receivable_amount, SUM(investigation_rc_amount) as investigation_rc_amount, SUM(investigation_doctor_charge) as investigation_doctor_charge, SUM(investigation_others_charge) as investigation_others_charge")
		->from('investigation') 
		->where('investigation_status', 1)
		->where('investigation_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
		->order_by('investigation_id', 'ASC')
		->get()
		->result();
		foreach($investigation_sum as $investigation_row){  
			
			$query_amount =  $this->db->select("SUM(investigation_collection_amount) as collection_amount")
			->from('investigation_collection')   
			->where('investigation_collection_status', 1)  
			->where('investigation_collection_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
			->order_by('investigation_collection_id', 'ASC')
			->get()	
			->result(); 	
			foreach($query_amount as $collection_row){ 
				$investigation_collection_amount = $collection_row->collection_amount;
			}
			
			$investigation_bill_amount			= $investigation_row->investigation_bill_amount;
			$investigation_discount_amount		= $investigation_row->investigation_discount_amount;
			$investigation_deposit_amount		= 0; 
			$investigation_receivable_amount	= $investigation_row->investigation_receivable_amount; 
			$investigation_due_amount			= $investigation_receivable_amount-$investigation_collection_amount;
			$investigation_rc_amount			= $investigation_row->investigation_rc_amount;
			$investigation_doctor_charge		= $investigation_row->investigation_doctor_charge;
			$investigation_others_charge		= $investigation_row->investigation_others_charge;
			$investigation_balance_amount		= $investigation_collection_amount-($investigation_rc_amount+$investigation_doctor_charge+$investigation_others_charge); 
		}
		
		$admission_sum =  $this->db->select("SUM(admission_fee) as admission_fee")
		->from('admission') 
		->where('admission_status', 1)
		->where('admission_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
		->order_by('admission_id', 'ASC')
		->get()
		->result();
		foreach($admission_sum as $admission_row){  
			
			$admission_bill_amount			= $admission_row->admission_fee;
			$admission_discount_amount		= 0;  
			$admission_deposit_amount		= 0;  
			$admission_receivable_amount	= $admission_row->admission_fee;
			$admission_collection_amount	= $admission_row->admission_fee;
			$admission_due_amount			= 0;
			$admission_rc_amount			= 0;
			$admission_doctor_charge		= 0;
			$admission_others_charge		= 0;
			$admission_balance_amount		= $admission_row->admission_fee;
		} 
		
		$admission_deposit_sum =  $this->db->select("SUM(admission_deposit_amount) as admission_deposit_amount")
		->from('admission_deposit') 
		->where('admission_deposit_status', 1)
		->where('admission_deposit_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
		->order_by('admission_deposit_id', 'ASC')
		->get()
		->result();
		foreach($admission_deposit_sum as $admission_deposit_row){  
			
			$admission_deposit_bill_amount			= $admission_deposit_row->admission_deposit_amount;
			$admission_deposit_discount_amount		= 0;  
			$admission_deposit_deposit_amount		= 0;  
			$admission_deposit_receivable_amount	= $admission_deposit_row->admission_deposit_amount;
			$admission_deposit_collection_amount	= $admission_deposit_row->admission_deposit_amount;
			$admission_deposit_due_amount			= 0;
			$admission_deposit_rc_amount			= 0;
			$admission_deposit_doctor_charge		= 0;
			$admission_deposit_others_charge		= 0;
			$admission_deposit_balance_amount		= $admission_deposit_row->admission_deposit_amount;
		}
		
		$bill_collection_sum =  $this->db->select("SUM(bill_collection_sub_total_amount) as bill_collection_bill_amount, SUM(bill_collection_discount_amount) as bill_collection_discount_amount, SUM(bill_collection_payable_amount) as bill_collection_receivable_amount, SUM(bill_collection_paid_amount) as bill_collection_collection_amount, SUM(bill_collection_due_amount) as bill_collection_due_amount, SUM(bill_collection_patient_rc_amount) as bill_collection_rc_amount, SUM(bill_collection_patient_doctor_charge) as bill_collection_doctor_charge, SUM(bill_collection_patient_others_charge) as bill_collection_others_charge")
		->from('bill_collection') 
		->where('bill_collection_status', 1)
		->where('bill_collection_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
		->order_by('bill_collection_id', 'ASC')
		->get()
		->result();
		foreach($bill_collection_sum as $bill_collection_row){  
			
			$deposit = $this->db->select("SUM(admission_deposit_amount) as deposit_amount")
			->from('admission_deposit')  
			->where('admission_deposit_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
			->where('admission_deposit_status', 1)  
			->order_by('admission_deposit_id', 'ASC') 
			->get()
			->result();
			foreach($deposit as $deposit_row)
			{
				$admission_deposit_amount = $deposit_row->deposit_amount;
			}
			
			$bill_collection_bill_amount		= $bill_collection_row->bill_collection_bill_amount;
			$bill_collection_discount_amount	= $bill_collection_row->bill_collection_discount_amount;
			$bill_collection_deposit_amount		= $admission_deposit_amount; 
			$bill_collection_receivable_amount	= $bill_collection_row->bill_collection_receivable_amount; 
			$bill_collection_collection_amount	= $bill_collection_row->bill_collection_collection_amount; 
			$bill_collection_due_amount			= $bill_collection_receivable_amount-$bill_collection_collection_amount;
			$bill_collection_rc_amount			= $bill_collection_row->bill_collection_rc_amount;
			$bill_collection_doctor_charge		= $bill_collection_row->bill_collection_doctor_charge;
			$bill_collection_others_charge		= $bill_collection_row->bill_collection_others_charge;
			$bill_collection_balance_amount		= $bill_collection_collection_amount-($bill_collection_rc_amount+$bill_collection_doctor_charge+$bill_collection_others_charge); 
		}
		?>
		<tr>
			<td class="text-center">01</td>
			<td class="text-center" rowspan="2">OPD</td> 
			<td class="text-left">Appointment</td> 
			<td class="text-right"><?= number_format($appointment_bill_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($appointment_discount_amount,2 . '');?></td>    
			<td class="text-right"><?= number_format($admission_deposit_deposit_amount,2 . '');?></td>  
			<td class="text-right"><?= number_format($appointment_receivable_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($appointment_collection_amount,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("appointment/appointment_collection_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td> 
			<td class="text-right"><?= number_format($appointment_due_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($appointment_rc_amount,2 . '');?></td>
			<td class="text-right"><?= number_format($appointment_doctor_charge,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("appointment/doctor_charge_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($appointment_others_charge,2 . '');?></td>
			<td class="text-right"><?= number_format($appointment_balance_amount,2 . '');?></td>
		</tr> 
		
		<tr>
			<td class="text-center">02</td>
			<td class="text-left">Investigation</td> 
			 
			<td class="text-right"><?= number_format($investigation_bill_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($investigation_discount_amount,2 . '');?></td>    
			<td class="text-right"><?= number_format($investigation_deposit_amount,2 . '');?></td>  
			<td class="text-right"><?= number_format($investigation_receivable_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($investigation_collection_amount,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("investigation/investigation_collection_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($investigation_due_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($investigation_rc_amount,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("reference/reference_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($investigation_doctor_charge,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("investigation/doctor_charge_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($investigation_others_charge,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("investigation/others_charge_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($investigation_balance_amount,2 . '');?></td>
		</tr>   
		
		<?php 
		$opd_bill_amount  		= $appointment_bill_amount + $investigation_bill_amount;
		$opd_discount_amount	= $appointment_discount_amount + $investigation_discount_amount;
		$opd_deposit_amount		= $appointment_deposit_amount + $investigation_deposit_amount;
		$opd_receivable_amount	= $appointment_receivable_amount + $investigation_receivable_amount;
		$opd_collection_amount	= $appointment_collection_amount + $investigation_collection_amount;
		$opd_due_amount			= $appointment_due_amount + $investigation_due_amount;
		$opd_rc_amount			= $appointment_rc_amount + $investigation_rc_amount;
		$opd_doctor_charge		= $appointment_doctor_charge + $investigation_doctor_charge;
		$opd_others_charge		= $appointment_others_charge + $investigation_others_charge;
		$opd_balance_amount		= $appointment_balance_amount + $investigation_balance_amount;
		?>
		<tr class="text-right"> 
			<th class="text-right" colspan="3">Sub Total</th>
			<th class="text-right"><?= number_format($opd_bill_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($opd_discount_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($opd_deposit_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($opd_receivable_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($opd_collection_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($opd_due_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($opd_rc_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($opd_doctor_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($opd_others_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($opd_balance_amount,2 . '');?></th>
		</tr>  
		<tr>
			<td class="text-center">03</td>
			<td class="text-center" rowspan="3">IPD</td> 
			<td class="text-left">Admission Fee</td> 
			<td class="text-right"><?= number_format($admission_bill_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($admission_discount_amount,2 . '');?></td>    
			<td class="text-right"><?= number_format(0,2 . '');?></td>  
			<td class="text-right"><?= number_format($admission_receivable_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($admission_collection_amount,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("admission/admission_fee_collection_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td> 
			<td class="text-right"><?= number_format($admission_due_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($admission_rc_amount,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_doctor_charge,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_others_charge,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_balance_amount,2 . '');?></td>
		</tr> 
		 
		<tr>
			<td class="text-center">04</td>
			<td class="text-left">Admission Deposit</td> 
			<td class="text-right"><?= number_format($admission_deposit_bill_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($admission_deposit_discount_amount,2 . '');?></td>    
			<td class="text-right"><?= number_format($admission_deposit_deposit_amount,2 . '');?></td>  
			<td class="text-right"><?= number_format($admission_deposit_receivable_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($admission_deposit_collection_amount,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("admission/admission_deposit_collection_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td> 
			<td class="text-right"><?= number_format($admission_deposit_due_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($admission_deposit_rc_amount,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_deposit_doctor_charge,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_deposit_others_charge,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_deposit_balance_amount,2 . '');?></td>
		</tr> 
		 
		<tr>
			<td class="text-center">05</td>
			<td class="text-left">IPD Bill Collection</td> 
			<td class="text-right"><?= number_format($bill_collection_bill_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($bill_collection_discount_amount,2 . '');?></td>    
			<td class="text-right"><?= number_format($bill_collection_deposit_amount,2 . '');?></td>  
			<td class="text-right"><?= number_format($bill_collection_receivable_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($bill_collection_collection_amount,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("admission/bill_collection_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td> 
			<td class="text-right"><?= number_format($bill_collection_due_amount,2 . '');?></td> 
			<td class="text-right"><?= number_format($bill_collection_rc_amount,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("admission/bill_collection_rc_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($bill_collection_doctor_charge,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("admission/bill_collection_doctor_charge_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($bill_collection_others_charge,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("admission/bill_collection_others_charge_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($bill_collection_balance_amount,2 . '');?></td>
		</tr>  
		
		<?php 
		$ipd_bill_amount  		= $admission_bill_amount + $admission_deposit_bill_amount + $bill_collection_bill_amount;
		$ipd_discount_amount	= $admission_discount_amount + $admission_deposit_discount_amount + $bill_collection_discount_amount;
		$ipd_deposit_amount		= $admission_deposit_deposit_amount + $bill_collection_deposit_amount;
		$ipd_receivable_amount	= $admission_receivable_amount + $admission_deposit_receivable_amount + $bill_collection_receivable_amount;
		$ipd_collection_amount	= $admission_collection_amount + $admission_deposit_collection_amount + $bill_collection_collection_amount;
		$ipd_due_amount			= $admission_due_amount + $admission_deposit_due_amount + $bill_collection_due_amount;
		$ipd_rc_amount			= $admission_rc_amount + $admission_deposit_rc_amount + $bill_collection_rc_amount;
		$ipd_doctor_charge		= $admission_doctor_charge + $admission_deposit_doctor_charge + $bill_collection_doctor_charge;
		$ipd_others_charge		= $admission_others_charge + $admission_deposit_others_charge + $bill_collection_others_charge;
		$ipd_balance_amount		= $admission_balance_amount + $admission_deposit_balance_amount + $bill_collection_balance_amount;
		?>
		<tr class="text-right"> 
			<th class="text-right" colspan="3">Sub Total</th>
			<th class="text-right"><?= number_format($ipd_bill_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($ipd_discount_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($ipd_deposit_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($ipd_receivable_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($ipd_collection_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($ipd_due_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($ipd_rc_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($ipd_doctor_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($ipd_others_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($ipd_balance_amount,2 . '');?></th>
		</tr>  
		
		<?php 
		$bill_amount  		= $opd_bill_amount + $ipd_bill_amount;
		$discount_amount	= $opd_discount_amount + $ipd_discount_amount;
		$deposit_amount		= $opd_deposit_amount + $ipd_deposit_amount;
		$receivable_amount	= $opd_receivable_amount + $ipd_receivable_amount;
		$collection_amount	= $opd_collection_amount + $ipd_collection_amount;
		$due_amount			= $opd_due_amount + $ipd_due_amount;
		$rc_amount			= $opd_rc_amount + $ipd_rc_amount;
		$doctor_charge		= $opd_doctor_charge + $ipd_doctor_charge;
		$others_charge		= $opd_others_charge + $ipd_others_charge;
		$balance_amount		= $opd_balance_amount + $ipd_balance_amount;
		?> 
		<tr class="text-uppercase"> 
			<th class="text-right" colspan="3">Grand Total</th>
			<th class="text-right"><?= number_format($bill_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($discount_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($deposit_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($receivable_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($collection_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($due_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($rc_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($doctor_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($others_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($balance_amount,2 . '');?></th>
		</tr>  
		
		<tr class="text-uppercase">
			<th class="text-left" colspan="18">
			<?= $this->lang->line('in_word');?>: 
			<?php 
			$number 		= abs($balance_amount);
			$in_word_amount = $this->number_to_word_convert->convert_number($number);
			?>
			<?= $in_word_amount;?> <?= $this->lang->line('currency_only');?>.
			</th>
		</tr>
		
		<tr class="text-uppercase"> 
			<th class="text-right" colspan="12"> OPD Income</th>
			<th class="text-right"><?= number_format($opd_collection_amount,2 . '');?></th>
		</tr>  
		
		<tr class="text-uppercase"> 
			<th class="text-right" colspan="12"> IPD Income</th>
			<th class="text-right"><?= number_format($ipd_collection_amount,2 . '');?></th>
		</tr>  
		 
		
		<tr class="text-uppercase"> 
			<th class="text-right" colspan="12"> Total Income</th>
			<th class="text-right"><?= number_format($opd_collection_amount+$ipd_collection_amount,2 . '');?></th>
		</tr>  
		
		<tr class="text-uppercase"> 
			<th class="text-right" colspan="13">&nbsp;</th>
		</tr>  
		
		<tr class="text-uppercase"> 
			<th class="text-center" colspan="11">&nbsp;</th>
			<th class="text-center" colspan="2">Accounts Section</th>
		</tr>  
		
		<tr class="text-uppercase"> 
			<th class="text-center" colspan="11">&nbsp;</th>
			<th class="text-center">Debit</th>
			<th class="text-center">Credit</th>
		</tr> 
		
		<tr class="text-uppercase">   
			<th class="text-right" colspan="11">
			120111 - Cash (OPD)
			</th> 
			<th class="text-right" colspan="">
				<input type="hidden" class="text-right" name="accounts_details_accounts_type[]" value="100000"readonly>
				<input type="hidden" class="text-right" name="accounts_details_accounts_category[]" value="2"readonly>
				<input type="hidden" class="text-right" name="accounts_details_control_group[]" value="65"readonly>
				<input type="hidden" class="text-right" name="accounts_details_general_ledger[]" value="67"readonly>
				<input type="hidden" class="text-right" name="accounts_details_subsidiary_ledger[]" value="68"readonly>
				<input type="text" class="text-right" name="accounts_details_debit[]" value="<?= number_format($opd_collection_amount,2, '.', '');?>"readonly>
				<input type="hidden" class="text-right" name="accounts_details_credit[]" value="0"readonly>
			</th> 
			<th class="text-right" colspan="">
				
			</th> 
		</tr>    
		
		<tr class="text-uppercase">   
			<th class="text-right" colspan="11"> 
			310111 - Patient Consultancy<br/>
			310112 - Investigation Income
			</th> 
			<th class="text-right" colspan="">
				
			</th> 
			
			<th class="text-right"> 
			<input type="hidden" class="text-right" name="accounts_details_accounts_type[]" value="300000"readonly>
			<input type="hidden" class="text-right" name="accounts_details_accounts_type[]" value="300000"readonly>
				<input type="hidden" class="text-right" name="accounts_details_accounts_category[]" value="86"readonly>
				<input type="hidden" class="text-right" name="accounts_details_accounts_category[]" value="86"readonly>
				<input type="hidden" class="text-right" name="accounts_details_control_group[]" value="87"readonly>
				<input type="hidden" class="text-right" name="accounts_details_control_group[]" value="87"readonly>
				<input type="hidden" class="text-right" name="accounts_details_general_ledger[]" value="88"readonly>
				<input type="hidden" class="text-right" name="accounts_details_general_ledger[]" value="88"readonly>
				<input type="hidden" class="text-right" name="accounts_details_subsidiary_ledger[]" value="89"readonly>
				<input type="hidden" class="text-right" name="accounts_details_subsidiary_ledger[]" value="90"readonly>
			<input type="hidden" class="text-right" name="accounts_details_debit[]" value="0"readonly>
			<input type="hidden" class="text-right" name="accounts_details_debit[]" value="0"readonly>
			<input type="text" class="text-right" name="accounts_details_credit[]" value="<?= number_format($appointment_collection_amount,2, '.', '');?>"readonly><br/>
			<input type="text" class="text-right" name="accounts_details_credit[]" value="<?= number_format($investigation_collection_amount,2, '.', '');?>"readonly>
			</th> 
		</tr>  
		
		<tr class="text-uppercase">   
			<th class="text-right" colspan="11">
			120111 - Cash (IPD)
			</th> 
			<th class="text-right" colspan="">
			<input type="hidden" class="text-right" name="accounts_details_accounts_type[]" value="100000"readonly>
				<input type="hidden" class="text-right" name="accounts_details_accounts_category[]" value="2"readonly>
				<input type="hidden" class="text-right" name="accounts_details_control_group[]" value="65"readonly>
				<input type="hidden" class="text-right" name="accounts_details_general_ledger[]" value="67"readonly>
				<input type="hidden" class="text-right" name="accounts_details_subsidiary_ledger[]" value="68"readonly>
				<input type="text" class="text-right" name="accounts_details_debit[]" value="<?= number_format($ipd_collection_amount,2, '.', '');?>"readonly>
				<input type="hidden" class="text-right" name="accounts_details_credit[]" value="0"readonly>
			</th> 
			<th class="text-right" colspan="">
				
			</th> 
		</tr>    
		
		<tr class="text-uppercase">   
			<th class="text-right" colspan="11"> 
			310121 - Admission Fee<br/>
			310124 - Admission Deposit<br/>
			310122 - Patient Discharge
			</th> 
			<th class="text-right" colspan="">
				
			</th> 
			
			<th class="text-right"> 
			<input type="hidden" class="text-right" name="accounts_details_accounts_type[]" value="300000"readonly>
			<input type="hidden" class="text-right" name="accounts_details_accounts_type[]" value="300000"readonly>
			<input type="hidden" class="text-right" name="accounts_details_accounts_type[]" value="300000"readonly>
				<input type="hidden" class="text-right" name="accounts_details_accounts_category[]" value="86"readonly>
				<input type="hidden" class="text-right" name="accounts_details_accounts_category[]" value="86"readonly>
				<input type="hidden" class="text-right" name="accounts_details_accounts_category[]" value="86"readonly>
				<input type="hidden" class="text-right" name="accounts_details_control_group[]" value="87"readonly>
				<input type="hidden" class="text-right" name="accounts_details_control_group[]" value="87"readonly>
				<input type="hidden" class="text-right" name="accounts_details_control_group[]" value="87"readonly>
				<input type="hidden" class="text-right" name="accounts_details_general_ledger[]" value="91"readonly>
				<input type="hidden" class="text-right" name="accounts_details_general_ledger[]" value="91"readonly>
				<input type="hidden" class="text-right" name="accounts_details_general_ledger[]" value="91"readonly>
				<input type="hidden" class="text-right" name="accounts_details_subsidiary_ledger[]" value="92"readonly>
				<input type="hidden" class="text-right" name="accounts_details_subsidiary_ledger[]" value="209"readonly>
				<input type="hidden" class="text-right" name="accounts_details_subsidiary_ledger[]" value="93"readonly>
				
				<input type="hidden" class="text-right" name="accounts_details_debit[]" value="0"readonly>
				<input type="hidden" class="text-right" name="accounts_details_debit[]" value="0"readonly>
				<input type="hidden" class="text-right" name="accounts_details_debit[]" value="0"readonly>
			<input type="text" class="text-right" name="accounts_details_credit[]" value="<?= number_format($admission_collection_amount,2, '.', '');?>"readonly><br/>
			<input type="text" class="text-right" name="accounts_details_credit[]" value="<?= number_format($admission_deposit_collection_amount,2, '.', '');?>"readonly><br/>
			<input type="text" class="text-right" name="accounts_details_credit[]" value="<?= number_format($bill_collection_collection_amount,2, '.', '');?>"readonly>
			</th> 
		</tr>   
		
		<tr class="text-uppercase">   
			<th class="text-right" colspan="11">
			Total Amount
			</th> 
			<th class="text-right" colspan="">
				<input type="text" class="text-right text-bold" name="accounts_total_debit" value="<?= number_format($collection_amount,2, '.', '');?>"readonly>
			</th> 
			<th class="text-right" colspan="">
				<input type="hidden" class="text-center" name="count" value="7">
				<input type="text" class="text-right text-bold" name="accounts_total_credit" value="<?= number_format($collection_amount,2, '.', '');?>"readonly>
				<input type="hidden" class="text-right text-bold" name="posting_date" value="<?= $to_date;?>"readonly>
			</th> 
		</tr> 
		
		<tr class="text-uppercase"> 
			<th class="text-center" colspan="11">&nbsp;</th>
			<th class="text-center" colspan="2"><button type="submit" class="btn btn-brand btn-success text-uppercase btn-block"onclick="return confirm('<?= $this->lang->line("model_create_warning");?>')">Authorize</button></th>
		</tr>  

		<?php return $output;
	}  

	/* ------------------------------------------------------
	Daily Collection Summary Report Model
	------------------------------------------------------- */
	function daily_collection_summary($to_date, $user)
	{
		$output = '';
		$ses_record_id = $this->session->userdata('ses_record_id');
		$from_date = date('Y-m-d', strtotime($to_date));
		$current_date = $to_date;
        $previous_date =  date_sub(date_create($current_date), date_interval_create_from_date_string("1 days"));
        $previous_date = date_format($previous_date, "Y-m-d");
		
		
		$where = array();
		$where['sales_date >= '] = $current_date;
		$where['sales_date <= '] = $current_date;
		
		// Pharmacy Details Start
		//$pharmacy_sales_amount	= 0;
		//$pharmacy_collection_amount	= 0;
		//$pharmacy_due_amount	= 0;
		
		//$pharmacy_query = $this->Common_model->findAll("sales_orders", $where, "sales_id", "desc");
		//foreach ($pharmacy_query as $key => $pharmacy_value) {
		//	$pharmacy_sales_amount += $pharmacy_value->grand_net_total;
		//	$pharmacy_collection_amount += $pharmacy_value->paid_amount;
		//	$pharmacy_due_amount += $pharmacy_value->due_amount;
		//}
		
		// pharmacy Due Collection
		//$data['values'] = $this->Common_model->findAll('mr',array(),'mr_id','desc');
		
		
		//$mr_where['mr_date >= '] = $current_date;
		//$mr_where['mr_date <= '] = $current_date;
		//$pharmacy_due_collection_amount	= 0;
		
		//$pharmacy_due_query = $this->Common_model->findAll("mr", $mr_where, "mr_id", "desc");
		//foreach ($pharmacy_due_query as $key => $pharmacy_due_value) {
		//	$pharmacy_due_collection_amount += $pharmacy_due_value->mr_amount;
		//}
		
		
        $pharmacyWhere = array();
        $pharmacyWhere['sales_date >= '] = $current_date;
		$pharmacyWhere['sales_date <= '] = $current_date;
        //$pharmacyWhere['sales_date'] = $previous_date;
		
		$pharmacyQuery = $this->Common_model->calculateSumMultiple('sales_orders', $pharmacyWhere, array('grand_net_total', 'paid_amount', 'due_amount'));
		
		$data['pharmacy_collection_amount'] = $pharmacyQuery->paid_amount;
		
		
        $pharmacyPurchaseWhere = array();
        $pharmacyPurchaseWhere['purchase_date >= '] = $current_date;
		$pharmacyPurchaseWhere['purchase_date <= '] = $current_date;
        $pharmacyPurchaseWhere['purchase_type'] = 'Medicine';
        $pharmacyPurchaseWhere['show_hide'] = 'Show';
		
		$pharmacyPurchaseQuery = $this->Common_model->calculateSumMultiple('purchase_orders', $pharmacyPurchaseWhere, array('paid_amount'));
		
		$data['pharmacy_purchase_amount'] = $pharmacyPurchaseQuery->paid_amount;
		
        $pharmacyDueWhere = array();
        $pharmacyDueWhere['mr_date >= '] = $current_date;
		$pharmacyDueWhere['mr_date <= '] = $current_date;
        //$pharmacyDueWhere['mr_date'] = $previous_date;
		
		$pharmacyDueQuery = $this->Common_model->calculateSumMultiple('mr', $pharmacyDueWhere, array('mr_amount'));
		
		$data['pharmacy_due_collection_amount'] = $pharmacyDueQuery->mr_amount;
		
		
        $pharmacyDuePaymentWhere = array();
        $pharmacyDuePaymentWhere['payment_date >= '] = $current_date;
		$pharmacyDuePaymentWhere['payment_date <= '] = $current_date;
        $pharmacyDuePaymentWhere['show_hide'] = 'Show';
		
		$pharmacyDuePaymentQuery = $this->Common_model->calculateSumMultiple('supplier_payments', $pharmacyDuePaymentWhere, array('payment_amount'));
		
		$data['pharmacy_due_payment_amount'] = $pharmacyDuePaymentQuery->payment_amount;
		
        $pharmacySpllierReturnWhere = array();
        $pharmacySpllierReturnWhere['return_date >= '] = $current_date;
		$pharmacySpllierReturnWhere['return_date <= '] = $current_date;
        $pharmacySpllierReturnWhere['return_type'] = 'Medicine';
        $pharmacySpllierReturnWhere['show_hide'] = 'Show';
		
		$pharmacySpllierReturnQuery = $this->Common_model->calculateSumMultiple('return_manages', $pharmacySpllierReturnWhere, array('grand_return_amount'));
		
		$data['pharmacy_supplier_return_amount'] = $pharmacySpllierReturnQuery->grand_return_amount;
		
        $pharmacyCustomerReturnWhere = array();
        $pharmacyCustomerReturnWhere['return_date >= '] = $current_date;
		$pharmacyCustomerReturnWhere['return_date <= '] = $current_date;
        $pharmacyCustomerReturnWhere['return_type'] = 'Medicine';
        $pharmacyCustomerReturnWhere['show_hide'] = 'Show';
		
		$pharmacyCustomerReturnQuery = $this->Common_model->calculateSumMultiple('customer_return_manages', $pharmacyCustomerReturnWhere, array('grand_return_amount'));
		
		$data['pharmacy_customer_return_amount'] = $pharmacyCustomerReturnQuery->grand_return_amount;
		
		// Pharmacy Details End
		
		
		$pathologyWhereBF = array();
        $pathologyWhereBF['date'] = $previous_date;
        $pathologyWhereBF['type'] = 'Test Invoice';
        // var_dump($pathologyWhereBF);die;
        $operationWhereBF['date'] = $previous_date;
        $operationInvoiceWhereBF['date'] = $previous_date;
        $operationInvoiceWhereBF['type'] = 'Admission';
        $operationWhereBF['type'] = 'Operation';

        $operationDetailsWhereBF = array();
        $operationDetailsWhereBF['operation_date'] = $previous_date;

        // var_dump($pathologyWhereBF);die;

        $ecgWhereBF['date'] = $previous_date;
        $ecgWhereBF['test_category'] = 'ECG';
        $xrayWhereBF['date'] = $previous_date;
        $xrayWhereBF['test_category like'] = '%X-Ray%';
        $ultraWhereBF['date'] = $previous_date;
        $ultraWhereBF['test_category like'] = 'Ultrasonogram';

        $generalIncomeWhereBF = array();
        $generalIncomeWhereBF['date'] = $previous_date;

        $consultancyWhereBF = array();
        $consultancyWhereBF['type'] = 'Appointment';
        $consultancyWhereBF['date'] = $previous_date;

        $commission_patholgyWhereBF = array();
        $commission_patholgyWhereBF['type'] = 'Test Invoice';
        $commission_patholgyWhereBF['date'] = $previous_date;

        $operation_commissionWhereBF = array();
        $operation_commissionWhereBF['operation_date'] = $previous_date;

        $sonologistExpenseWhereBF = array();
        $sonologistExpenseWhereBF['date'] = $previous_date;

        $generalExpenseWhereBF = array();
        $generalExpenseWhereBF['date'] = $previous_date;
        $staffSalaryWhereBF = array();
        $staffSalaryWhereBF['status'] = 'Paid';
        $staffSalaryWhereBF['date'] = $previous_date;

        $dueCollectionWhereBF = array();
        $dueCollectionWhereBF['mr_date'] = $previous_date;


        $salesWhereBF = array();
        $salesWhereBF['sales_from'] = 'Direct';
        $salesWhereBF['sales_date'] = $previous_date;

        $mrWhereBF = array();
        $mrWhereBF['mr_date'] = $previous_date;

        $emergencyWhereBF = array();
        $emergencyWhereBF['type'] = 'Emergency';
        $emergencyWhereBF['date'] = $previous_date;

        $ambulanceWhereBF = array();
        $ambulanceWhereBF['type'] = 'Ambulance';
        $ambulanceWhereBF['date'] = $previous_date;

        $doctorServiceWhereBF = array();
        $doctorServiceWhereBF['type'] = 'Doctor Service';
        $doctorServiceWhereBF['date'] = $previous_date;

        $donorWhereBF = array();
        $donorWhereBF['type'] = 'Donor';
        $donorWhereBF['date'] = $previous_date;

        $dressingWhereBF = array();
        $dressingWhereBF['type'] = 'Dressing';
        $dressingWhereBF['date'] = $previous_date;

        $supplier_paymentsWhereBF = array();
        $supplier_paymentsWhereBF['payment_date'] = $previous_date;

        $incomeWhereBF = array();
        $incomeWhereBF['income_date'] = $previous_date;
        $expenseWhereBF = array();
        $expenseWhereBF['approval'] = 'Approved';
        $expenseWhereBF['expense_date'] = $previous_date;

        $labInWhereBF = array();
        $labInWhereBF['in_date'] = $previous_date;
		
		if (!empty($created_by)) {
            $pathologyWhereBF['created_by'] = $created_by;
            $operationWhereBF['created_by'] = $created_by;
            $operationInvoiceWhereBF['created_by'] = $created_by;
            $operationDetailsWhereBF['created_by'] = $created_by;
            $ecgWhereBF['created_by'] = $created_by;
            $xrayWhereBF['created_by'] = $created_by;
            $ultraWhere['created_by'] = $created_by;
            $generalIncomeWhereBF['created_by'] = $created_by;
            $consultancyWhereBF['created_by'] = $created_by;
            $commission_patholgyWhereBF['created_by'] = $created_by;
            $operation_commissionWhereBF['created_by'] = $created_by;
            $generalExpenseWhereBF['created_by'] = $created_by;
            $staffSalaryWhereBF['created_by'] = $created_by;
            $dueCollectionWhereBF['created_by'] = $created_by;
            $salesWhereBF['created_by'] = $created_by;
            $emergencyWhereBF['created_by'] = $created_by;
            $ambulanceWhereBF['created_by'] = $created_by;
            $doctorServiceWhereBF['created_by'] = $created_by;
            $donorWhereBF['created_by'] = $created_by;
            $dressingWhereBF['created_by'] = $created_by;
            $supplier_paymentsWhereBF['created_by'] = $created_by;
            $incomeWhereBF['created_by'] = $created_by;
            $expenseWhereBF['created_by'] = $created_by;
            $labInWhereBF['created_by'] = $created_by;
        }
		
		$data['pathologyBF'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhereBF, 'sub_total');
        $data['pathology_paidBF'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhereBF, 'paid');
        $data['pathology_dueBF'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhereBF, 'due');
        // var_dump($data['pathology_paidBF']);die;
        $data['operationBF'] = $this->Common_model->calCulateSum('create_bill', $operationWhereBF, 'sub_total');
        $operation_paidBF = $this->Common_model->calculateSumMultiple('create_bill', $operationWhereBF, array('paid', 'medicine_cost'));
        $data['operation_paidBF'] = $operation_paidBF->paid; // + $operation_paid->medicine_cost ; //+ $operation_paid->advance ;
        $data['operation_dueBF'] = $this->Common_model->calCulateSum('create_bill', $operationWhereBF, 'due');
		
		$operationInvoiceBF = $this->Common_model->calculateSumMultiple('create_bill', $operationInvoiceWhereBF, array('sub_total', 'advance'));
        $data['operationInvoiceBF'] = $operationInvoiceBF->sub_total + $operationInvoiceBF->advance;

        $data['ecgBF'] = $this->Common_model->calCulateSum('sales_test', $ecgWhereBF, 'test_price');
        $data['xrayBF'] = $this->Common_model->calCulateSum('sales_test', $xrayWhereBF, 'test_price');
        $data['ultraBF'] = $this->Common_model->calCulateSum('sales_test', $ultraWhereBF, 'test_price');
		
		$consultancyBF = $this->Common_model->calculateSumMultiple('create_bill', $consultancyWhereBF, array('sub_total', 'paid', 'due', 'doctor_commission'));
        //var_dump($consultancy);die;
        $data['consultancyBF'] = isset($consultancyBF) ?  $consultancyBF->sub_total : 0;
        $data['consultancy_paidBF'] = isset($consultancyBF) ?  $consultancyBF->paid : 0;
        $data['consultancy_dueBF'] = isset($consultancyBF) ?  $consultancyBF->due : 0;
        $data['consultancy_doctor_commissionBF'] = isset($consultancyBF) ?  $consultancyBF->doctor_commission : 0;
        $doctor_commission_patholgyBF = $this->Common_model->calculateSumMultiple('create_bill', $commission_patholgyWhereBF, array('doctor_commission', 'reference_by_commission'));
        $doctor_commissionBF = isset($doctor_commission_patholgyBF) ? $doctor_commission_patholgyBF->doctor_commission : 0;
        $reference_by_commissionBF = isset($doctor_commission_patholgyBF) ? $doctor_commission_patholgyBF->reference_by_commission : 0;
        $data['doctor_commission_patholgyBF'] = $doctor_commissionBF + $reference_by_commissionBF;
		
		$operation_commissionBF =  $this->Common_model->calculateSumMultiple('operation_details', $operationDetailsWhereBF, array('surgeon_commission', 'surgeon_assistant_commission', 'anesthesia_commission', 'medicine_cost'));
        $surgeon_commissionBF = isset($operation_commissionBF) ? $operation_commissionBF->surgeon_commission : 0;
        $anesthesia_commissionBF = isset($operation_commissionBF) ? $operation_commissionBF->anesthesia_commission : 0;
        $medicine_costBF = isset($operation_commissionBF) ? $operation_commissionBF->medicine_cost : 0;
        $surgeon_assistant_commissionBF = isset($operation_commissionBF) ? $operation_commissionBF->surgeon_assistant_commission : 0;
        $data['operation_commissionBF'] =  $surgeon_commissionBF + $anesthesia_commissionBF + $medicine_costBF + $surgeon_assistant_commissionBF;
		
		$data['sonologistExpenseBF'] = $this->Common_model->calCulateSum('sonologist', $sonologistExpenseWhereBF, 'amount');

        $data['staffSalaryBF'] = $this->Common_model->calCulateSum('create_salary_sheet', $staffSalaryWhereBF, 'net_salary');

        $data['dueCollectionBF'] = $this->Common_model->calCulateSum('due_collections', $dueCollectionWhereBF, 'mr_amount');
		
		$sales_ordersBF = $this->Common_model->calculateSumMultiple('sales_orders', $salesWhereBF, array('grand_net_total', 'paid_amount', 'due_amount'));
        $data['sales_amountBF'] = $sales_ordersBF->grand_net_total;
        $data['sales_paid_amountBF'] = $sales_ordersBF->paid_amount;
        $data['sales_due_amountBF'] = $sales_ordersBF->due_amount;
        $data['pharmacy_collectionBF'] = $this->Common_model->calCulateSum('mr', $mrWhereBF, 'mr_amount');

        $data['supplier_paymentsBF'] = $this->Common_model->calCulateSum('supplier_payments', $supplier_paymentsWhereBF, 'payment_amount');
		
		$emergencyBF = $this->Common_model->calculateSumMultiple('create_bill', $emergencyWhereBF, array('sub_total', 'paid', 'doctor_commission', 'others_cost'));
        $data['emergency_totalBF'] = isset($emergencyBF) ? $emergencyBF->sub_total : 0;
        $data['emergency_paidBF'] = isset($emergencyBF) ? $emergencyBF->paid : 0;
        $data['emergency_doctor_commissionBF'] = isset($emergencyBF) ? $emergencyBF->doctor_commission : 0;
        $data['emergency_others_costBF'] = isset($emergencyBF) ? $emergencyBF->others_cost : 0;
		
		$ambulanceBF = $this->Common_model->calculateSumMultiple('create_bill', $ambulanceWhereBF, array('sub_total', 'paid', 'fuel_cost', 'road_cost', 'service_maintanance_cost'));
        $data['ambulance_totalBF'] = isset($ambulanceBF) ? $ambulanceBF->sub_total : 0;
        $data['ambulance_paidBF'] = isset($ambulanceBF) ? $ambulanceBF->paid : 0;
        $data['ambulance_fuel_costBF'] = isset($ambulanceBF) ? $ambulanceBF->fuel_cost : 0;
        $data['ambulance_road_costBF'] = isset($ambulanceBF) ? $ambulanceBF->road_cost : 0;
        $data['ambulance_service_maintanance_costBF'] = isset($ambulanceBF) ? $ambulanceBF->service_maintanance_cost : 0;
		
		$doctor_serviceBF = $this->Common_model->calculateSumMultiple('create_bill', $doctorServiceWhereBF, array('sub_total', 'paid', 'due', 'doctor_commission', 'reference_by_commission'));
        $data['doctor_service_totalBF'] = isset($doctor_serviceBF) ? $doctor_serviceBF->sub_total : 0;
        $data['doctor_service_paidBF'] = isset($doctor_serviceBF) ? $doctor_serviceBF->paid : 0;
        $data['doctor_service_reference_by_commissionBF'] = isset($doctor_serviceBF) ? $doctor_serviceBF->reference_by_commission : 0;
        $data['doctor_service_commissionBF'] = isset($doctor_serviceBF) ? $doctor_serviceBF->doctor_commission : 0;
        $data['doctor_service_commissionBF'] = $data['doctor_service_reference_by_commissionBF'] + $data['doctor_service_commissionBF'];
        $data['doctor_service_dueBF'] = isset($doctor_serviceBF) ? $doctor_serviceBF->due : 0;
		
		$donorBF = $this->Common_model->calculateSumMultiple('create_bill', $donorWhereBF, array('sub_total', 'paid'));
        $data['donor_totalBF'] = isset($donorBF) ? $donorBF->sub_total : 0;
        $data['donor_paidBF'] = isset($donorBF) ? $donorBF->paid : 0;
		
		$dressingBF = $this->Common_model->calculateSumMultiple('create_bill', $dressingWhereBF, array('sub_total', 'paid', 'doctor_commission'));
        $data['dressing_totalBF'] = isset($dressingBF) ? $dressingBF->sub_total : 0;
        $data['dressing_paidBF'] = isset($dressingBF) ? $dressingBF->paid : 0;
        $data['dressing_doctor_commissionBF'] = isset($dressingBF) ? $dressingBF->doctor_commission : 0;


        $data['general_incomeBF'] = $this->Common_model->calCulateSum('incomes', $incomeWhereBF, 'voucher_amount');
        $data['general_expenseBF'] = $this->Common_model->calCulateSum('expenses', $expenseWhereBF, 'voucher_amount');
        $data['lab_productBF'] = $this->Common_model->calCulateSum('lab_product_in', $labInWhereBF, 'grand_total_price');
        $data['total_paid_amountBF'] = $data['pathology_paidBF'] +  $data['operation_paidBF'] + $data['operationInvoiceBF'] +  $data['consultancy_paidBF'] + $data['dueCollectionBF']  + $data['emergency_paidBF']  + $data['ambulance_paidBF'] + $data['doctor_service_paidBF'] +  $data['general_incomeBF'] + $data['donor_paidBF'] + $data['dressing_paidBF'] + $data['sales_paid_amountBF'];
        $data['total_expense_amountBF'] = $data['doctor_commission_patholgyBF'] + $data['consultancy_doctor_commissionBF']  + $data['operation_commissionBF'] + $data['sonologistExpenseBF'] + $data['staffSalaryBF']  + $data['emergency_doctor_commissionBF'] + $data['emergency_others_costBF'] + $data['ambulance_fuel_costBF'] +  $data['ambulance_road_costBF'] + $data['ambulance_service_maintanance_costBF'] + $data['doctor_service_commissionBF'] + $data['general_expenseBF'] + $data['lab_productBF'] + $data['dressing_doctor_commissionBF'] + $data['supplier_paymentsBF'];
        $data['balance_amountBF'] = $data['total_paid_amountBF'] - $data['total_expense_amountBF'];

		/* B/F */

        $pathologyWhere = array();
        if (!admin()) {
            $pathologyWhere['show_hide'] = "Show";
        }
        $pathologyWhere['date'] = $current_date;
        $pathologyWhere['type'] = 'Test Invoice';
		

        $ivTestTnvoiceWhereWhere = array();
        if (!admin()) {
            $ivTestTnvoiceWhereWhere['show_hide'] = "Show";
        }
        $ivTestTnvoiceWhereWhere['date'] = $current_date;
        $ivTestTnvoiceWhereWhere['type'] = 'IVF Test Invoice';
		
        $pathologyRfPaymentWhere = array();
        if (!admin()) {
            $pathologyRfPaymentWhere['show_hide'] = "Show";
        }
        $pathologyRfPaymentWhere['date'] = $current_date;
        $pathologyRfPaymentWhere['type'] = 'Test Invoice';
        $pathologyRfPaymentWhere['test_invoice_payment_status'] = 'Paid';

		
        $ivfTestRfPaymentWhere = array();
        if (!admin()) {
            $ivfTestRfPaymentWhere['show_hide'] = "Show";
        }
        $ivfTestRfPaymentWhere['date'] = $current_date;
        $ivfTestRfPaymentWhere['type'] = 'IVF Test Invoice';
        $ivfTestRfPaymentWhere['test_invoice_payment_status'] = 'Paid';
		
        $operationWhere = array();
        if (!admin()) {
            $operationWhere['show_hide'] = "Show";
        }
        $operationWhere['date'] = $current_date;
        $operationInvoiceWhere = array();
        if (!admin()) {
            $operationInvoiceWhere['show_hide'] = "Show";
        }
        $operationInvoiceWhere['date'] = $current_date;
        $operationInvoiceWhere['type'] = 'Admission';

        $dayCareAdmissionInvoiceWhere = array();
        if (!admin()) {
            $dayCareAdmissionInvoiceWhere['show_hide'] = "Show";
        }
        $dayCareAdmissionInvoiceWhere['date'] = $current_date;
        $dayCareAdmissionInvoiceWhere['type'] = 'DayCareAdmission';

        $dayCareInvestigationInvoiceWhere = array();
        if (!admin()) {
            $dayCareInvestigationInvoiceWhere['show_hide'] = "Show";
        }
        $dayCareInvestigationInvoiceWhere['date'] = $current_date;
        $dayCareInvestigationInvoiceWhere['type'] = 'Investigation Invoice';

        $dayCareServiceInvoiceWhere = array();
        if (!admin()) {
            $dayCareServiceInvoiceWhere['show_hide'] = "Show";
        }
        $dayCareServiceInvoiceWhere['date'] = $current_date;
        $dayCareServiceInvoiceWhere['type'] = 'Day Care Service';

        $brachytherapyWhere = array();
        if (!admin()) {
            $brachytherapyWhere['show_hide'] = "Show";
        }
        $brachytherapyWhere['date'] = $current_date;
        $brachytherapyWhere['type'] = 'Brachytherapy';


        $operationAdmissionAdvanceInvoiceWhere = array();
        if (!admin()) {
            $operationAdmissionAdvanceInvoice['show_hide'] = "Show";
        }
        $operationAdmissionAdvanceInvoiceWhere['date'] = $current_date;
        $operationAdmissionAdvanceInvoiceWhere['type'] = 'AdmissionAdvance';
        $operationWhere['type'] = 'Operation';

        $operationDetailsWhere = array();
        if (!admin()) {
            $operationDetailsWhere['show_hide'] = "Show";
        }
        $operationDetailsWhere['payment_status'] = 'Paid';
        // $operationDetailsWhere['operation_date'] = $current_date;
        $operationDetailsWhere['payment_date'] = $current_date;
		
        $operationDetailsPaymentWhere = array();
        if (!admin()) {
            $operationDetailsPaymentWhere['show_hide'] = "Show";
        }
        // $operationDetailsPaymentWhere['payment_status'] = 'Paid';
        $operationDetailsPaymentWhere['operation_date'] = $current_date;
        $operationDetailsPaymentWhere['payment_status'] = 'Paid';

        $operationDetailsRfPaymentWhere = array();
        if (!admin()) {
            $operationDetailsRfPaymentWhere['show_hide'] = "Show";
        }
        // $operationDetailsRfPaymentWhere['payment_status'] = 'Paid';
        $operationDetailsRfPaymentWhere['operation_date'] = $current_date;
        $operationDetailsRfPaymentWhere['ref_comm_payment_status'] = 'Paid';

        $ecgWhere['date'] = $current_date;
        $ecgWhere['test_category'] = 'ECG';
        $xrayWhere['date'] = $current_date;
        $xrayWhere['test_category like'] = '%X-Ray%';
        $ultraWhere['date'] = $current_date;
        $ultraWhere['test_category like'] = 'Ultrasonogram';

        $generalIncomeWhere = array();
        if (!admin()) {
            $generalIncomeWhere['show_hide'] = "Show";
        }
        $generalIncomeWhere['date'] = $current_date;

        $consultancyWhere = array();
        if (!admin()) {
            $consultancyWhere['show_hide'] = "Show";
        }
        $consultancyWhere['type'] = 'Appointment';
        $consultancyWhere['date'] = $current_date;

        $consultancyPaymentWhere = array();
        if (!admin()) {
            $consultancyPaymentWhere['show_hide'] = "Show";
        }
        $consultancyPaymentWhere['type'] = 'Appointment';
        $consultancyPaymentWhere['date'] = $current_date;
        $consultancyPaymentWhere['doctor_visit_payment_status'] = 'Paid';

        $commission_patholgyWhere = array();
        if (!admin()) {
            $commission_patholgyWhere['show_hide'] = "Show";
        }
        $commission_patholgyWhere['test_invoice_payment_status'] = 'Paid';
        $commission_patholgyWhere['type'] = 'Test Invoice';
        $commission_patholgyWhere['date'] = $current_date;

        $operation_commissionWhere = array();
        if (!admin()) {
            $operation_commissionWhere['show_hide'] = "Show";
        }
        $operation_commissionWhere['operation_date'] = $current_date;

        $sonologistExpenseWhere = array();
        if (!admin()) {
            $sonologistExpenseWhere['show_hide'] = "Show";
        }
        $sonologistExpenseWhere['date'] = $current_date;

        $generalExpenseWhere = array();
        if (!admin()) {
            $generalExpenseWhere['show_hide'] = "Show";
        }
        $generalExpenseWhere['date'] = $current_date;
        $staffSalaryWhere = array();
        if (!admin()) {
            $staffSalaryWhere['show_hide'] = "Show";
        }
        $staffSalaryWhere['status'] = 'Paid';
        $staffSalaryWhere['date'] = $current_date;

        $dueCollectionWhere = array();
        if (!admin()) {
            $dueCollectionWhere['show_hide'] = "Show";
        }
        $dueCollectionWhere['mr_date'] = $current_date;
        $dueCollectionWhere['invoice_type!='] = 'Dental';
        $dueCollectionWhere['ivf_status'] = 0;
        
        $ivfDueCollectionWhere = array();
        if (!admin()) {
            $ivfDueCollectionWhere['show_hide'] = "Show";
        }
        $ivfDueCollectionWhere['mr_date'] = $current_date;
        $ivfDueCollectionWhere['invoice_type!='] = 'Dental';
        $ivfDueCollectionWhere['ivf_status'] = 1;


        $salesWhere = array();
        if (!admin()) {
            $salesWhere['show_hide'] = "Show";
        }
        $salesWhere['sales_from'] = 'Direct';
        $salesWhere['sales_date'] = $current_date;

        $mrWhere = array();
        if (!admin()) {
            $mrWhere['show_hide'] = "Show";
        }
        $mrWhere['mr_date'] = $current_date;

        $emergencyWhere = array();
        if (!admin()) {
            $emergencyWhere['show_hide'] = "Show";
        }
        $emergencyWhere['type'] = 'Emergency';
        $emergencyWhere['date'] = $current_date;

        $donationWhere = array();
        if (!admin()) {
            $donationWhere['show_hide'] = "Show";
        }
        $donationWhere['type'] = 'Donor';
        $donationWhere['date'] = $current_date;

        $ambulanceWhere = array();
        if (!admin()) {
            $ambulanceWhere['show_hide'] = "Show";
        }
        $ambulanceWhere['type'] = 'Ambulance';
        $ambulanceWhere['date'] = $current_date;

        $doctorServiceWhere = array();
        if (!admin()) {
            $doctorServiceWhere['show_hide'] = "Show";
        }
        $doctorServiceWhere['type'] = 'Doctor Service';
        $doctorServiceWhere['date'] = $current_date;

        $donorWhere = array();
        if (!admin()) {
            $donorWhere['show_hide'] = "Show";
        }
        $donorWhere['type'] = 'Donor';
        $donorWhere['date'] = $current_date;

        $dressingWhere = array();
        if (!admin()) {
            $dressingWhere['show_hide'] = "Show";
        }
        $dressingWhere['type'] = 'Dressing';
        $dressingWhere['date'] = $current_date;

        $supplier_paymentsWhere = array();
        if (!admin()) {
            $supplier_paymentsWhere['show_hide'] = "Show";
        }
        $supplier_paymentsWhere['payment_date'] = $current_date;

        $incomeWhere = array();
        if (!admin()) {
            $incomeWhere['show_hide'] = "Show";
        }
        $incomeWhere['income_date'] = $current_date;
        $expenseWhere = array();
        if (!admin()) {
            $expenseWhere['show_hide'] = "Show";
        }
        $expenseWhere['approval'] = 'Approved';
        $expenseWhere['expense_date'] = $current_date;

        $labInWhere = array();
        $labInWhere['approval'] = 'Approved';
        if (!admin()) {
            $labInWhere['show_hide'] = "Show";
        }
        $labInWhere['in_date'] = $current_date;
        //var_dump($labInWhere) ; die ;
        if (!empty($created_by)) {
            $pathologyWhere['created_by'] = $created_by;
            $ivTestTnvoiceWhereWhere['created_by'] = $created_by;
            $pathologyRfPaymentWhere['created_by'] = $created_by;
            $ivfTestRfPaymentWhere['created_by'] = $created_by;
            $operationWhere['created_by'] = $created_by;
            $operationInvoiceWhere['created_by'] = $created_by;
            $dayCareAdmissionInvoiceWhere['created_by'] = $created_by;
            $dayCareInvestigationInvoiceWhere['created_by'] = $created_by;
            $dayCareServiceInvoiceWhere['created_by'] = $created_by;
            $brachytherapyWhere['created_by'] = $created_by;
            $operationAdmissionAdvanceInvoiceWhere['created_by'] = $created_by;
            $operationDetailsWhere['created_by'] = $created_by;
            $operationDetailsPaymentWhere['created_by'] = $created_by;
            $operationDetailsRfPaymentWhere['created_by'] = $created_by;
            $ecgWhere['created_by'] = $created_by;
            $xrayWhere['created_by'] = $created_by;
            $ultraWhere['created_by'] = $created_by;
            $generalIncomeWhere['created_by'] = $created_by;
            $consultancyWhere['created_by'] = $created_by;
            $consultancyPaymentWhere['created_by'] = $created_by;
            $commission_patholgyWhere['created_by'] = $created_by;
            $operation_commissionWhere['created_by'] = $created_by;
            $generalExpenseWhere['created_by'] = $created_by;
            $staffSalaryWhere['created_by'] = $created_by;
            $dueCollectionWhere['created_by'] = $created_by;
            $ivfDueCollectionWhere['created_by'] = $created_by;
            $salesWhere['created_by'] = $created_by;
            $emergencyWhere['created_by'] = $created_by;
            $ambulanceWhere['created_by'] = $created_by;
            $doctorServiceWhere['created_by'] = $created_by;
            $donorWhere['created_by'] = $created_by;
            $dressingWhere['created_by'] = $created_by;
            $supplier_paymentsWhere['created_by'] = $created_by;
            $incomeWhere['created_by'] = $created_by;
            $expenseWhere['created_by'] = $created_by;
            $labInWhere['created_by'] = $created_by;
        }

        $data['pathology'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhere, 'sub_total');
        $pathologyData = $this->Common_model->calculateSumMultiple('create_bill', $pathologyWhere, ['paid', 'reference_by_commission']);
        $pathologyRfPaymentData = $this->Common_model->calculateSumMultiple('create_bill', $pathologyRfPaymentWhere, ['discount', 'reference_by_commission']);
        $ivfTestRfPaymentData = $this->Common_model->calculateSumMultiple('create_bill', $ivfTestRfPaymentWhere, ['discount', 'reference_by_commission']);
		// ddd($this->db->last_query());
		$data['pathology_paid'] =$pathologyData->paid;
        $data['pathology_due'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhere, 'due');

        $data['ivf_test_invoice'] = $this->Common_model->calCulateSum('create_bill', $ivTestTnvoiceWhereWhere, 'sub_total');
        $data['ivf_test_invoice_paid'] = $this->Common_model->calCulateSum('create_bill', $ivTestTnvoiceWhereWhere, 'paid');
        $data['ivf_test_invoice_due'] = $this->Common_model->calCulateSum('create_bill', $ivTestTnvoiceWhereWhere, 'due');
		
		$data['pathology_rf_commission'] = $pathologyRfPaymentData->reference_by_commission-$pathologyRfPaymentData->discount;
		$data['ivf_test_rf_commission'] = $ivfTestRfPaymentData->reference_by_commission-$ivfTestRfPaymentData->discount;

        $pathologyWhere['approved_discount'] = 'No';

        $pathologyDiscount = $this->Common_model->calCulateSum('create_bill', $pathologyWhere, 'discount');
        $pathologyDiscount = isset($pathologyDiscount)?$pathologyDiscount:0;
        $data['pathology'] += $pathologyDiscount;
        $data['pathology_due'] += $pathologyDiscount ;
        $data['operation'] = $this->Common_model->calCulateSum('create_bill', $operationWhere, 'sub_total');
        $operation_paid = $this->Common_model->calculateSumMultiple('create_bill', $operationWhere, array('paid', 'medicine_cost','due'));
        $data['operation_paid'] = $operation_paid->paid; // + $operation_paid->medicine_cost ; //+ $operation_paid->advance ;
        $data['operation_due'] = $operation_paid->due; 
        $operationWhere['approved_discount'] = 'No';

        $operationDiscount = $this->Common_model->calCulateSum('create_bill', $operationWhere, 'discount');
        $operationDiscount = isset($operationDiscount)?$operationDiscount:0;
        $data['operation'] += $operationDiscount ;
        $data['operation_due'] += $operationDiscount ;


        $operationInvoice = $this->Common_model->calculateSumMultiple('create_bill', $operationInvoiceWhere, array('sub_total', 'advance'));
        $data['operationInvoice'] = $operationInvoice->sub_total + $operationInvoice->advance;

		$operationDetails = $this->Common_model->calculateSumMultiple('operation_details', $operationDetailsWhere, array('surgeon_commission', 'anesthesia_commission', 'surgeon_assistant_commission', 'service_fee', 'medicine_cost', 'reference_by_payment'));
		
		$operationPaymentDetails = $this->Common_model->calculateSumMultiple('operation_details', $operationDetailsPaymentWhere, array('surgeon_commission', 'anesthesia_commission', 'surgeon_assistant_commission', 'service_fee', 'medicine_cost', 'reference_by_payment'));

		$operationRfPaymentDetails = $this->Common_model->calculateSumMultiple('operation_details', $operationDetailsRfPaymentWhere, array('surgeon_commission', 'anesthesia_commission', 'surgeon_assistant_commission', 'service_fee', 'medicine_cost', 'reference_by_payment'));

		// ddd($operationDetails);

		$data['operation_commission_doctors'] = ($operationPaymentDetails->surgeon_commission > 0) ? $operationPaymentDetails->surgeon_commission : 0;

		$data['operation_others_cost'] = $operationPaymentDetails->anesthesia_commission + $operationPaymentDetails->service_fee + $operationPaymentDetails->medicine_cost + $operationPaymentDetails->surgeon_assistant_commission;

		$data['operation_rf_commissions'] = $operationRfPaymentDetails->reference_by_payment;

        $dayCareAdmissionInvoice = $this->Common_model->calculateSumMultiple('create_bill', $dayCareAdmissionInvoiceWhere, array('sub_total', 'advance'));
        $data['dayCareAdmissionInvoice'] = $dayCareAdmissionInvoice->sub_total + $dayCareAdmissionInvoice->advance;

        $dayCareInvestigationInvoice = $this->Common_model->calculateSumMultiple('create_bill', $dayCareInvestigationInvoiceWhere, array('sub_total', 'paid','due'));
        $data['dayCareInvestigationInvoiceSubtotal'] = $dayCareInvestigationInvoice->sub_total;
        $data['dayCareInvestigationInvoicePaid'] = $dayCareInvestigationInvoice->paid;
        $data['dayCareInvestigationInvoiceDue'] = $dayCareInvestigationInvoice->due;

        $dayCareInvestigationInvoiceWhere['approved_discount'] = 'No';
        $dayCareInvestigationInvoiceDiscount = $this->Common_model->calCulateSum('create_bill', $dayCareInvestigationInvoiceWhere, 'discount');
        $dayCareInvestigationInvoiceDiscount = isset($dayCareInvestigationInvoiceDiscount)?$dayCareInvestigationInvoiceDiscount:0;
        $data['dayCareInvestigationInvoiceSubtotal'] +=  $dayCareInvestigationInvoiceDiscount ;
        $data['dayCareInvestigationInvoiceDue'] +=  $dayCareInvestigationInvoiceDiscount ;
       // var_dump($dayCareInvestigationInvoiceDiscount);die;
	   
	   $dayCareServiceInvoice= $this->Common_model->calculateSumMultiple('create_bill', $dayCareServiceInvoiceWhere, array('sub_total', 'paid','due'));
        $data['dayCareServiceInvoiceSubtotal'] = $dayCareServiceInvoice->sub_total;
        $data['dayCareServiceInvoicePaid'] = $dayCareServiceInvoice->paid;
        $data['dayCareServiceInvoiceDue'] = $dayCareServiceInvoice->due;

        $dayCareServiceInvoiceWhere['approved_discount'] = 'No';
        $dayCareServiceInvoiceDiscount = $this->Common_model->calCulateSum('create_bill', $dayCareServiceInvoiceWhere, 'discount');
        $dayCareServiceInvoiceDiscount = isset($dayCareServiceInvoiceDiscount)?$dayCareServiceInvoiceDiscount:0;
        $data['dayCareServiceInvoiceSubtotal'] +=  $dayCareServiceInvoiceDiscount ;
        $data['dayCareServiceInvoiceDue'] +=  $dayCareServiceInvoiceDiscount ;

        //var_dump($data['dayCareServiceInvoiceDue']);die;

        $brachytherapyInvoice= $this->Common_model->calculateSumMultiple('create_bill', $brachytherapyWhere, array('sub_total', 'paid','due'));
        $data['brachytherapyInvoiceSubtotal'] = $brachytherapyInvoice->sub_total;
        $data['brachytherapyInvoicePaid'] = $brachytherapyInvoice->paid;
        $data['brachytherapyInvoiceDue'] = $brachytherapyInvoice->due;
		
		$brachytherapyWhere['approved_discount'] = 'No';
        $brachytherapyDiscount = $this->Common_model->calCulateSum('create_bill', $brachytherapyWhere, 'discount');
        $brachytherapyDiscount = isset($brachytherapyDiscount)?$brachytherapyDiscount:0;
        $data['brachytherapyInvoiceSubtotal'] +=  $brachytherapyDiscount ;
        $data['brachytherapyInvoiceDue'] +=  $brachytherapyDiscount ;



        $operationAdmissionAdvanceInvoice = $this->Common_model->calculateSum('create_bill', $operationAdmissionAdvanceInvoiceWhere, 'sub_total');
        $data['operationAdmissionAdvanceInvoice'] = isset($operationAdmissionAdvanceInvoice) ? $operationAdmissionAdvanceInvoice : 0;

        $data['ecg'] = $this->Common_model->calCulateSum('sales_test', $ecgWhere, 'test_price');
        $data['xray'] = $this->Common_model->calCulateSum('sales_test', $xrayWhere, 'test_price');
        $data['ultra'] = $this->Common_model->calCulateSum('sales_test', $ultraWhere, 'test_price');
		
		$consultancy = $this->Common_model->calculateSumMultiple('create_bill', $consultancyWhere, array('sub_total', 'paid', 'due', 'doctor_commission'));
        
		$consultancyPayment = $this->Common_model->calculateSumMultiple('create_bill', $consultancyPaymentWhere, array('doctor_commission'));
        
        $data['consultancy'] = isset($consultancy) ?  $consultancy->sub_total : 0;
        $data['consultancy_paid'] = isset($consultancy) ?  $consultancy->paid : 0;
        $data['consultancy_due'] = isset($consultancy) ?  $consultancy->due : 0;
        $data['consultancy_doctor_commission'] = isset($consultancyPayment) ?  $consultancyPayment->doctor_commission : 0;
		
        $consultancyWhere['approved_discount'] = 'No';
        $consultancyDiscount = $this->Common_model->calCulateSum('create_bill', $consultancyWhere, 'discount');
        $consultancyDiscount = isset($consultancyDiscount)?$consultancyDiscount:0;
        $data['consultancy'] += $consultancyDiscount;
        $data['consultancy_due'] += $consultancyDiscount ;
        //var_dump($consultancyDiscount);die;

        $doctor_commission_patholgy = $this->Common_model->calculateSumMultiple('create_bill', $commission_patholgyWhere, array('discount', 'doctor_commission', 'reference_by_commission'));
        $test_invoice_discount = isset($doctor_commission_patholgy) ? $doctor_commission_patholgy->discount : 0;
        $doctor_commission = isset($doctor_commission_patholgy) ? $doctor_commission_patholgy->doctor_commission : 0;
        $reference_by_commission = isset($doctor_commission_patholgy) ? $doctor_commission_patholgy->reference_by_commission : 0;
        $data['doctor_commission_patholgy'] = $doctor_commission + $reference_by_commission - $test_invoice_discount;
        // var_dump( $data['doctor_commission_patholgy']  ) ; die; 

        // $operation_commission =  $this->Common_model->calculateSumMultiple('operation_details', $operationDetailsWhere, array('surgeon_commission', 'surgeon_assistant_commission', 'anesthesia_commission', 'medicine_cost', 'service_fee', 'reference_by_payment'));
        $operation_commission =  $this->Common_model->calculateSumMultiple('operation_expense', $operationDetailsWhere, array('surgeon_commission', 'surgeon_assistant_commission', 'anesthesia_commission', 'medicine_cost', 'service_fee', 'reference_by_payment'));
		$surgeon_commission = isset($operation_commission) ? $operation_commission->surgeon_commission : 0;
        $surgeon_commission = isset($operation_commission) ? $operation_commission->surgeon_commission : 0;
        $anesthesia_commission = isset($operation_commission) ? $operation_commission->anesthesia_commission : 0;
        $medicine_cost = isset($operation_commission) ? $operation_commission->medicine_cost : 0;
        $service_fee = isset($operation_commission) ? $operation_commission->service_fee : 0;
        $reference_by_payment = isset($operation_commission) ? $operation_commission->reference_by_payment : 0;
        $surgeon_assistant_commission = isset($operation_commission) ? $operation_commission->surgeon_assistant_commission : 0;
        $data['operation_commission'] =  $surgeon_commission + $anesthesia_commission + $medicine_cost + $surgeon_assistant_commission  + $service_fee + $reference_by_payment;
        $data['operation_commission_doctor'] =  $surgeon_commission + $anesthesia_commission + $surgeon_assistant_commission;
        $data['operation_commission_others'] =  $medicine_cost + $service_fee;

        $data['sonologistExpense'] = $this->Common_model->calCulateSum('sonologist', $sonologistExpenseWhere, 'amount');

        $data['staffSalary'] = $this->Common_model->calCulateSum('create_salary_sheet', $staffSalaryWhere, 'net_salary');

        // $data['dueCollection'] = $this->Common_model->calCulateSum('due_collections', $dueCollectionWhere, 'mr_amount');
		$data['dueCollection'] = $this->Common_model->calCulateSum('due_collection_details', $dueCollectionWhere, 'current_collection');
        $data['ivfDueCollection'] = $this->Common_model->calCulateSum('due_collection_details', $ivfDueCollectionWhere, 'current_collection');

        $sales_orders = $this->Common_model->calculateSumMultiple('sales_orders', $salesWhere, array('grand_net_total', 'paid_amount', 'due_amount'));
        $data['sales_amount'] = $sales_orders->grand_net_total;
        $data['sales_paid_amount'] = $sales_orders->paid_amount;
        $data['sales_due_amount'] = $sales_orders->due_amount;
        $data['pharmacy_collection'] = $this->Common_model->calCulateSum('mr', $mrWhere, 'mr_amount');

        $data['supplier_payments'] = $this->Common_model->calCulateSum('supplier_payments', $supplier_paymentsWhere, 'payment_amount');
		
		$emergency = $this->Common_model->calculateSumMultiple('create_bill', $emergencyWhere, array('sub_total', 'paid', 'doctor_commission', 'others_cost'));
        $data['emergency_total'] = isset($emergency) ? $emergency->sub_total : 0;
        $data['emergency_paid'] = isset($emergency) ? $emergency->paid : 0;
        $data['emergency_doctor_commission'] = isset($emergency) ? $emergency->doctor_commission : 0;
        $data['emergency_others_cost'] = isset($emergency) ? $emergency->others_cost : 0;

		$donation = $this->Common_model->calculateSumMultiple('create_bill', $donationWhere, array('sub_total', 'paid', 'doctor_commission', 'others_cost'));
        $data['donation_total'] = isset($donation) ? $donation->sub_total : 0;
        $data['donation_paid'] = isset($donation) ? $donation->paid : 0;
        $data['donation_doctor_commission'] = isset($donation) ? $donation->doctor_commission : 0;
        $data['donation_others_cost'] = isset($donation) ? $donation->others_cost : 0;

        $ambulance = $this->Common_model->calculateSumMultiple('create_bill', $ambulanceWhere, array('sub_total', 'paid', 'fuel_cost', 'road_cost', 'service_maintanance_cost'));
        $data['ambulance_total'] = isset($ambulance) ? $ambulance->sub_total : 0;
        $data['ambulance_paid'] = isset($ambulance) ? $ambulance->paid : 0;
        $data['ambulance_fuel_cost'] = isset($ambulance) ? $ambulance->fuel_cost : 0;
        $data['ambulance_road_cost'] = isset($ambulance) ? $ambulance->road_cost : 0;
        $data['ambulance_service_maintanance_cost'] = isset($ambulance) ? $ambulance->service_maintanance_cost : 0;

        $doctor_service = $this->Common_model->calculateSumMultiple('create_bill', $doctorServiceWhere, array('sub_total', 'paid', 'due', 'doctor_commission', 'reference_by_commission'));
        $data['doctor_service_total'] = isset($doctor_service) ? $doctor_service->sub_total : 0;
        $data['doctor_service_paid'] = isset($doctor_service) ? $doctor_service->paid : 0;
        $data['doctor_service_reference_by_commission'] = isset($doctor_service) ? $doctor_service->reference_by_commission : 0;
        $data['doctor_service_commission'] = isset($doctor_service) ? $doctor_service->doctor_commission : 0;
        $data['doctor_service_commission'] = $data['doctor_service_reference_by_commission'] + $data['doctor_service_commission'];
        $data['doctor_service_due'] = isset($doctor_service) ? $doctor_service->due : 0;
		
		$donor = $this->Common_model->calculateSumMultiple('create_bill', $donorWhere, array('sub_total', 'paid'));
        $data['donor_total'] = isset($donor) ? $donor->sub_total : 0;
        $data['donor_paid'] = isset($donor) ? $donor->paid : 0;
		
		$dressing = $this->Common_model->calculateSumMultiple('create_bill', $dressingWhere, array('sub_total', 'paid', 'doctor_commission'));
        $data['dressing_total'] = isset($dressing) ? $dressing->sub_total : 0;
        $data['dressing_paid'] = isset($dressing) ? $dressing->paid : 0;
        $data['dressing_doctor_commission'] = isset($dressing) ? (isset($dressing->doctor_commission) ? $dressing->doctor_commission : 0 ) : 0;
		
		$data['general_income'] = $this->Common_model->calCulateSum('incomes', $incomeWhere, 'voucher_amount');
        $data['general_expense'] = $this->Common_model->calCulateSum('expenses', $expenseWhere, 'voucher_amount');
        $data['lab_product'] = $this->Common_model->calCulateSum('lab_product_in', $labInWhere, 'grand_total_price');
		
		//$totalProductPurchase = $this->Common_model->getTotalProductPurchase($current_date, $current_date);
        // ddd($this->db->last_query());
        //$data['product_purchase'] = !empty($totalProductPurchase) ? $totalProductPurchase->total: 0;
		
		$data['total_paid_amount'] = $data['pathology_paid'] + $data['ivf_test_invoice_paid'] +  $data['operation_paid'] + $data['operationInvoice'] +  $data['consultancy_paid'] + $data['dueCollection']  + $data['ivfDueCollection']  + $data['emergency_paid']  + $data['ambulance_paid'] + $data['doctor_service_paid'] +  $data['general_income'] + $data['donor_paid'] + $data['dressing_paid'] + $data['operationAdmissionAdvanceInvoice'] + $data['dayCareAdmissionInvoice'] + $data['dayCareInvestigationInvoicePaid'] + $data['dayCareServiceInvoicePaid'] + $data['brachytherapyInvoicePaid'];

        $data['total_expense_amount'] = $data['doctor_commission_patholgy'] + $data['consultancy_doctor_commission']  + $data['operation_commission'] + $data['sonologistExpense'] + $data['staffSalary']  + $data['emergency_doctor_commission'] + $data['emergency_others_cost'] + $data['ambulance_fuel_cost'] +  $data['ambulance_road_cost'] + $data['ambulance_service_maintanance_cost'] + $data['doctor_service_commission'] + $data['general_expense'] + $data['lab_product'] + $data['dressing_doctor_commission'] + $data['product_purchase'];

        $data['balance_amount'] = $data['total_paid_amount'] - $data['total_expense_amount'];
		
		
		$diagnosticIncomeWhere = array();
        $diagnosticIncomeWhere['income_date >= '] = $current_date;
		$diagnosticIncomeWhere['income_date <= '] = $current_date;
        $diagnosticIncomeWhere['income_type'] = 'Diagnostic';
        $diagnosticIncomeWhere['show_hide'] = 'Show';
		
		$diagnosticIncomeQuery = $this->Common_model->calculateSumMultiple('incomes', $diagnosticIncomeWhere, array('voucher_amount'));
		
		$data['diagnostic_income_amount'] = $diagnosticIncomeQuery->voucher_amount;
		
		$hospitalIncomeWhere = array();
        $hospitalIncomeWhere['income_date >= '] = $current_date;
		$hospitalIncomeWhere['income_date <= '] = $current_date;
        $hospitalIncomeWhere['income_type'] = 'Hospital';
        $hospitalIncomeWhere['show_hide'] = 'Show';
		
		$hospitalIncomeQuery = $this->Common_model->calculateSumMultiple('incomes', $hospitalIncomeWhere, array('voucher_amount'));
		
		$data['hospital_income_amount'] = $hospitalIncomeQuery->voucher_amount;
		
		$diagnosticExpenseWhere = array();
        $diagnosticExpenseWhere['expense_date >= '] = $current_date;
		$diagnosticExpenseWhere['expense_date <= '] = $current_date;
        $diagnosticExpenseWhere['expense_type'] = 'Diagnostic';
        //$diagnosticExpenseWhere['approval'] = 'Approved';
        $diagnosticExpenseWhere['show_hide'] = 'Show';
		
		$diagnosticExpenseQuery = $this->Common_model->calculateSumMultiple('expenses', $diagnosticExpenseWhere, array('voucher_amount'));
		
		$data['diagnostic_expense_amount'] = $diagnosticExpenseQuery->voucher_amount;
		
		$hospitalExpenseWhere = array();
        $hospitalExpenseWhere['expense_date >= '] = $current_date;
		$hospitalExpenseWhere['expense_date <= '] = $current_date;
        $hospitalExpenseWhere['expense_type'] = 'Hospital';
        //$hospitalExpenseWhere['approval'] = 'Approved';
        $hospitalExpenseWhere['show_hide'] = 'Show';
		
		$hospitalExpenseQuery = $this->Common_model->calculateSumMultiple('expenses', $hospitalExpenseWhere, array('voucher_amount'));
		
		$data['hospital_expense_amount'] = $hospitalExpenseQuery->voucher_amount;
		
		
		$advanceSalaryWhere = array();
        $advanceSalaryWhere['date >= '] = $current_date;
		$advanceSalaryWhere['date <= '] = $current_date;
        //$advanceSalaryWhere['status'] = 'Paid';
		
		$advanceSalaryQuery = $this->Common_model->calculateSumMultiple('create_salary_sheet_advanced', $advanceSalaryWhere, array('advanced_amount'));
		
		$data['advance_salary_amount'] = $advanceSalaryQuery->advanced_amount;
		
		
		$SalaryWhere = array();
        $SalaryWhere['date >= '] = $current_date;
		$SalaryWhere['date <= '] = $current_date;
        $SalaryWhere['status'] = 'Paid';
		
		$SalaryQuery = $this->Common_model->calculateSumMultiple('create_salary_sheet', $SalaryWhere, array('net_salary'));
		
		$data['salary_amount'] = $SalaryQuery->net_salary;
		
		$StoreWhere = array();
        $StoreWhere['in_date >= '] = $current_date;
		$StoreWhere['in_date <= '] = $current_date;
        $StoreWhere['approval'] = 'Paid';
		
		$StoreQuery = $this->Common_model->calculateSumMultiple('lab_product_in', $StoreWhere, array('grand_total_price'));
		
		$data['store_expense_amount'] = $StoreQuery->grand_total_price;

		$dentalWhere = array();
        if (!admin()) {
            $dentalWhere['show_hide'] = "Show";
        }
        $dentalWhere['date'] = $current_date;
        $dentalWhere['type'] = 'Dental';

		
        $dentalCollectionWhere = array();
        if (!admin()) {
            $dentalCollectionWhere['show_hide'] = "Show";
        }
        $dentalCollectionWhere['mr_date'] = $current_date;
        $dentalCollectionWhere['invoice_type'] = 'Dental';

		$data['dental_paid'] = $this->Common_model->calCulateSum('create_bill', $dentalWhere, 'paid');
		$data['dentalCollection'] = $this->Common_model->calCulateSum('due_collection_details', $dentalCollectionWhere, 'current_collection');

		$data['dental_collection'] = $data['dental_paid']?$data['dental_paid']:0;
		$data['dental_due_collection'] = $data['dentalCollection']?$data['dentalCollection']:0;
		
		?>
		<tr>
			<td class="text-center">01</td>
			<td class="text-center" rowspan="2">OPD</td>  
			<td class="text-left">Doctor Visit</td>
			<td class="text-right"><?= number_format(!empty($data['consultancy_paid'])?$data['consultancy_paid']:0,2 . '');?></td>
			<td class="text-right"><?= number_format(0,2 . '');?></td>
			<td class="text-right"><?= number_format(!empty($data['consultancy_doctor_commission'])?$data['consultancy_doctor_commission']:0,2 . '');?></td>
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(!empty($data['consultancy_paid']-$data['consultancy_doctor_commission'])?$data['consultancy_paid']- $data['consultancy_doctor_commission']:0,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-center">02</td> 
			<td class="text-left">Test Invoice</td>
			<td class="text-right"><?= number_format(!empty($data['pathology_paid'])?$data['pathology_paid']:0,2 . '');?></td>
			<td class="text-right"><?= number_format(!empty($data['pathology_rf_commission'])?$data['pathology_rf_commission']:0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td>
			<td class="text-right"><?= number_format(!empty($data['sonologistExpense'])?$data['sonologistExpense']:0,2 . '');?></td> 
			<td class="text-right"><?= number_format(!empty($data['pathology_paid']-($data['pathology_rf_commission']+$data['sonologistExpense']))?$data['pathology_paid']-($data['pathology_rf_commission']+$data['sonologistExpense']):0,2 . '');?></td>
		</tr>
		<?php 
			$opd_sub_total_amount 					= $data['consultancy_paid']+$data['pathology_paid'];
			$opd_sub_total_amount_rf 				= $data['pathology_rf_commission'];
			$opd_sub_total_amount_doctor_payment 	= $data['consultancy_doctor_commission'];
			$opd_sub_total_amount_others_payment 	= $data['sonologistExpense'];
			$opd_sub_total_balance 					= $opd_sub_total_amount-($opd_sub_total_amount_rf+$opd_sub_total_amount_doctor_payment+$opd_sub_total_amount_others_payment);
		?>
		<tr class="text-right"> 
			<th class="text-right" colspan="3">Sub Total</th>
			<th class="text-right"><?= number_format(!empty($opd_sub_total_amount)?$opd_sub_total_amount:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($opd_sub_total_amount_rf)?$opd_sub_total_amount_rf:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($opd_sub_total_amount_doctor_payment)?$opd_sub_total_amount_doctor_payment:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($opd_sub_total_amount_others_payment)?$opd_sub_total_amount_others_payment:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($opd_sub_total_balance)?$opd_sub_total_balance:0,2 . '');?></th>
		</tr>
		<!-- <tr>
			<td class="text-center">03</td>
			<td class="text-center" rowspan="4">Cancer Treatment</td>  
			<td class="text-left">Day Care Invoice</td>
			<td class="text-right"><?= number_format(!empty($data['dayCareAdmissionInvoice'])?$data['dayCareAdmissionInvoice']:0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td>
			<td class="text-right"><?= number_format(!empty($data['dayCareAdmissionInvoice'])?$data['dayCareAdmissionInvoice']:0,2 . '');?></td>  
		</tr>
		<tr>
			<td class="text-center">04</td> 
			<td class="text-left">Day Care Investigation</td>
			<td class="text-right"><?= number_format(!empty($data['dayCareInvestigationInvoicePaid'])?$data['dayCareInvestigationInvoicePaid']:0,2 . '');?></td>
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(!empty($data['dayCareInvestigationInvoicePaid'])?$data['dayCareInvestigationInvoicePaid']:0,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-center">05</td> 
			<td class="text-left">Day Care Therapy Invoice</td>
			<td class="text-right"><?= number_format(!empty($data['dayCareServiceInvoicePaid'])?$data['dayCareServiceInvoicePaid']:0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td>
			<td class="text-right"><?= number_format(!empty($data['dayCareServiceInvoicePaid'])?$data['dayCareServiceInvoicePaid']:0,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-center">06</td> 
			<td class="text-left">Brachytherapy</td>
			<td class="text-right"><?= number_format(!empty($data['brachytherapyInvoicePaid'])?$data['brachytherapyInvoicePaid']:0,2 . '');?></td>
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td>
			<td class="text-right"><?= number_format(!empty($data['brachytherapyInvoicePaid'])?$data['brachytherapyInvoicePaid']:0,2 . '');?></td> 
		</tr>
		
		<?php 
			// $cancer_tx_sub_total_amount				= $data['dayCareAdmissionInvoice']+$data['dayCareInvestigationInvoicePaid']+$data['dayCareServiceInvoicePaid']+$data['brachytherapyInvoicePaid'];
			// $cancer_tx_sub_total_amount_rf 			= 0;
			// $cancer_tx_sub_total_amount_doctor_payment 	= 0;
			// $cancer_tx_sub_total_amount_others_payment 	= 0;
			// $cancer_tx_sub_total_balance 				= $cancer_tx_sub_total_amount-($cancer_tx_sub_total_amount_rf+$cancer_tx_sub_total_amount_doctor_payment+$cancer_tx_sub_total_amount_others_payment);
		?>
		<tr class="text-right"> 
			<th class="text-right" colspan="3">Sub Total</th>
			<th class="text-right"><?= number_format(!empty($cancer_tx_sub_total_amount)?$cancer_tx_sub_total_amount:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($cancer_tx_sub_total_amount_rf)?$cancer_tx_sub_total_amount_rf:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($cancer_tx_sub_total_amount_doctor_payment)?$cancer_tx_sub_total_amount_doctor_payment:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($cancer_tx_sub_total_amount_others_payment)?$cancer_tx_sub_total_amount_others_payment:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($cancer_tx_sub_total_balance)?$cancer_tx_sub_total_balance:0,2 . '');?></th>
		</tr> -->
		
		<tr>
			<td class="text-center">03</td>
			<td class="text-center" rowspan="3">IPD</td>  
			<td class="text-left">Admission Invoice</td>
			<td class="text-right"><?= number_format(!empty($data['operationInvoice'])?$data['operationInvoice']:0,2 . '');?></td>
			<td class="text-right"><?= number_format(0,2 . '');?></td>
			<td class="text-right"><?= number_format(0,2 . '');?></td>
			<td class="text-right"><?= number_format(0,2 . '');?></td>
			<td class="text-right"><?= number_format(!empty($data['operationInvoice'])?$data['operationInvoice']:0,2 . '');?></td>
		</tr> 
		<tr>
			<td class="text-center">05</td> 
			<td class="text-left">Advance Received</td>
			<td class="text-right"><?= number_format(!empty($data['operationAdmissionAdvanceInvoice'])?$data['operationAdmissionAdvanceInvoice']:0,2 . '');?></td>
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td>
			<td class="text-right"><?= number_format(!empty($data['operationAdmissionAdvanceInvoice'])?$data['operationAdmissionAdvanceInvoice']:0,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-center">06</td> 
			<td class="text-left">IPD Bill Collection</td>
			<td class="text-right"><?= number_format(!empty($data['operation_paid'])?$data['operation_paid']:0,2 . '');?></td>
			<td class="text-right"><?= number_format(!empty($data['operation_rf_commissions'])?$data['operation_rf_commissions']:0,2 . '');?></td>
			<td class="text-right"><?= number_format(!empty($data['operation_commission_doctors'])?$data['operation_commission_doctors']:0,2 . '');?></td>
			<td class="text-right"><?= number_format(!empty($data['operation_others_cost']+$data['operation_commission'])?$data['operation_others_cost']+$data['operation_commission']:0,2 . '');?></td>
			<td class="text-right"><?= number_format($data['operation_paid']-($data['operation_rf_commissions']+$data['operation_commission_doctors']+$data['operation_others_cost']+$data['operation_commission']),2 . '');?></td>
		</tr>
		<?php 
			$ipd_sub_total_amount					= $data['operationInvoice']+$data['operationAdmissionAdvanceInvoice']+$data['operation_paid'];
			$ipd_sub_total_amount_rf 				= $data['operation_rf_commissions'];
			$ipd_sub_total_amount_doctor_payment 	= $data['operation_commission_doctors'];
			$ipd_sub_total_amount_others_payment 	= $data['operation_others_cost']+$data['operation_commission'];
			$ipd_sub_total_balance 					= $ipd_sub_total_amount-($ipd_sub_total_amount_rf+$ipd_sub_total_amount_doctor_payment+$ipd_sub_total_amount_others_payment);
		?>
		<tr class="text-right"> 
			<th class="text-right" colspan="3">Sub Total</th>
			<th class="text-right"><?= number_format(!empty($ipd_sub_total_amount)?$ipd_sub_total_amount:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($ipd_sub_total_amount_rf)?$ipd_sub_total_amount_rf:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($ipd_sub_total_amount_doctor_payment)?$ipd_sub_total_amount_doctor_payment:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($ipd_sub_total_amount_others_payment)?$ipd_sub_total_amount_others_payment:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($ipd_sub_total_balance)?$ipd_sub_total_balance:0,2 . '');?></th>
		</tr>
		
		<tr>
			<td class="text-center">06</td>
			<td class="text-center">Due Collection</td>  
			<td class="text-left">Due Collection (OPD & IPD)</td>
			<td class="text-right"><?= number_format(!empty($data['dueCollection'])?$data['dueCollection']:0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(!empty($data['dueCollection'])?$data['dueCollection']:0,2 . '');?></td>
		</tr>
		<?php 
			$due_collection_sub_total_amount					= $data['dueCollection'];
			$due_collection_sub_total_amount_rf 				= 0;
			$due_collection_sub_total_amount_doctor_payment 	= 0;
			$due_collection_sub_total_amount_others_payment 	= 0;
			$due_collection_sub_total_balance 				= $due_collection_sub_total_amount-($due_collection_sub_total_amount_rf+$due_collection_sub_total_amount_doctor_payment+$due_collection_sub_total_amount_others_payment);
		?>
		<tr class="text-right">
			<th class="text-right" colspan="3">Sub Total</th>
			<th class="text-right"><?= number_format(!empty($due_collection_sub_total_amount)?$due_collection_sub_total_amount:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($due_collection_sub_total_amount_rf)?$due_collection_sub_total_amount_rf:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($due_collection_sub_total_amount_doctor_payment)?$due_collection_sub_total_amount_doctor_payment:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($due_collection_sub_total_amount_others_payment)?$due_collection_sub_total_amount_others_payment:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($due_collection_sub_total_balance)?$due_collection_sub_total_balance:0,2 . '');?></th>
		</tr>
		
		<tr>
			<td class="text-center">07</td>
			<td class="text-center" rowspan="3">Emergency</td>  
			<td class="text-left">Emergency</td>
			<td class="text-right"><?= number_format(!empty($data['emergency_paid'])?$data['emergency_paid']:0,2 . '');?></td>
			<td class="text-right"><?= number_format(0,2 . '');?></td>
			<td class="text-right"><?= number_format(!empty($data['emergency_doctor_commission'])?$data['emergency_doctor_commission']:0,2 . '');?></td>
			<td class="text-right"><?= number_format($data['emergency_others_cost'],2 . '');?></td> 
			<td class="text-right"><?= number_format(!empty($data['emergency_paid']-$data['emergency_doctor_commission'] - $data['emergency_others_cost'])?$data['emergency_paid']-$data['emergency_doctor_commission'] - $data['emergency_others_cost']:0,2 . '');?></td>
		</tr> 
		<tr>
			<td class="text-center">08</td> 
			<td class="text-left">Dressing</td>
			<td class="text-right"><?= number_format(!empty($data['dressing_paid'])?$data['dressing_paid']:0,2 . '');?></td>
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(!empty($data['dressing_doctor_commission'])?$data['dressing_doctor_commission']:0,2 . '');?></td>
			<td class="text-right"><?= number_format(!empty($data['dressing_paid']-$data['dressing_doctor_commission'])?$data['dressing_paid']-$data['dressing_doctor_commission']:0,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-center">09</td> 
			<td class="text-left">Blood Donation</td>
			<td class="text-right"><?= number_format(!empty($data['donation_paid'])?$data['donation_paid']:0,2 . '');?></td>
			<td class="text-right"><?= number_format(!empty($data['donation_doctor_commission'])?$data['donation_doctor_commission']:0,2 . '');?></td>
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(!empty($data['donation_paid']-$data['donation_doctor_commission'])?$data['donation_paid']-$data['donation_doctor_commission']:0,2 . '');?></td>
		</tr>
		<?php 
			$emergency_sub_total_amount 				= $data['emergency_paid']+$data['dressing_paid'] + $data['donation_paid'];
			$emergency_sub_total_amount_rf 				= 0;
			$emergency_sub_total_amount_doctor_payment 	= $data['emergency_doctor_commission'];
			$emergency_sub_total_amount_others_payment 	= $data['emergency_others_cost']+ $data['dressing_doctor_commission'];
			$emergency_sub_total_balance 					= $emergency_sub_total_amount-($emergency_sub_total_amount_rf+$emergency_sub_total_amount_doctor_payment+$emergency_sub_total_amount_others_payment);
		?>
		
		<tr class="text-right">
			<th class="text-right" colspan="3">Sub Total</th>
			<th class="text-right"><?= number_format(!empty($emergency_sub_total_amount)?$emergency_sub_total_amount:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($emergency_sub_total_amount_rf)?$emergency_sub_total_amount_rf:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($emergency_sub_total_amount_doctor_payment)?$emergency_sub_total_amount_doctor_payment:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($emergency_sub_total_amount_others_payment)?$emergency_sub_total_amount_others_payment:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($emergency_sub_total_balance)?$emergency_sub_total_balance:0,2 . '');?></th>
		</tr>
		
		<tr>
			<td class="text-center">10</td>
			<td class="text-center" rowspan="3">Pharmacy</td>  
			<td class="text-left">Medicine Sales/Purchase</td>
			<td class="text-right"><?= number_format(!empty($data['pharmacy_collection_amount'])?$data['pharmacy_collection_amount']:0,2 . '');?></td>
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(!empty($data['pharmacy_purchase_amount'])?$data['pharmacy_purchase_amount']:0,2 . '');?></td>
			<td class="text-right"><?= number_format($data['pharmacy_collection_amount']-$data['pharmacy_purchase_amount']);?></td>
		</tr>
		<tr>
			<td class="text-center">11</td> 
			<td class="text-left">Due Collection/Payment</td>
			<td class="text-right"><?= number_format(!empty($data['pharmacy_due_collection_amount'])?$data['pharmacy_due_collection_amount']:0,2 . '');?></td>
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(!empty($data['pharmacy_due_payment_amount'])?$data['pharmacy_due_payment_amount']:0,2 . '');?></td>
			<td class="text-right"><?= number_format($data['pharmacy_due_collection_amount']-$data['pharmacy_due_payment_amount']);?></td> 
		</tr>
		<tr>
			<td class="text-center">12</td> 
			<td class="text-left">Return (Supplier/Customer)</td>
			<td class="text-right"><?= number_format(!empty($data['pharmacy_supplier_return_amount'])?$data['pharmacy_supplier_return_amount']:0,2 . '');?></td>
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(!empty($data['pharmacy_customer_return_amount'])?$data['pharmacy_customer_return_amount']:0,2 . '');?></td>
			<td class="text-right"><?= number_format($data['pharmacy_supplier_return_amount']-$data['pharmacy_customer_return_amount']);?></td> 
		</tr>
		<?php 
			$pharmacy_sub_total_amount					= $data['pharmacy_collection_amount'] + $data['pharmacy_due_collection_amount'] + $data['pharmacy_supplier_return_amount'];
			$pharmacy_sub_total_amount_rf 				= 0;
			$pharmacy_sub_total_amount_doctor_payment 	= 0;
			$pharmacy_sub_total_amount_others_payment 	= $data['pharmacy_purchase_amount'] + $data['pharmacy_due_payment_amount']+ $data['pharmacy_customer_return_amount'];
			$pharmacy_sub_total_balance 				= $pharmacy_sub_total_amount-($pharmacy_sub_total_amount_rf+$pharmacy_sub_total_amount_doctor_payment+$pharmacy_sub_total_amount_others_payment);
		?>
		<tr class="text-right">
			<th class="text-right" colspan="3">Sub Total</th>
			<th class="text-right"><?= number_format(!empty($pharmacy_sub_total_amount)?$pharmacy_sub_total_amount:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($pharmacy_sub_total_amount_rf)?$pharmacy_sub_total_amount_rf:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($pharmacy_sub_total_amount_doctor_payment)?$pharmacy_sub_total_amount_doctor_payment:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($pharmacy_sub_total_amount_others_payment)?$pharmacy_sub_total_amount_others_payment:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($pharmacy_sub_total_balance)?$pharmacy_sub_total_balance:0,2 . '');?></th>
		</tr>

		<tr>
			<td class="text-center">13</td>
			<td class="text-center" rowspan="2">Dental</td>  
			<td class="text-left">Dental Invoice </td>
			<td class="text-right"><?= number_format(!empty($data['dental_collection'])?$data['dental_collection']:0,2 . '');?></td>
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td>
			<td class="text-right"><?= number_format(!empty($data['dental_collection'])?$data['dental_collection']:0,2 . '');?></td>
		</tr>

		<tr>
			<td class="text-center">14</td>
			<td class="text-left">Dental Due Collection </td>
			<td class="text-right"><?= number_format(!empty($data['dental_due_collection'])?$data['dental_due_collection']:0,2 . '');?></td>
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td>
			<td class="text-right"><?= number_format(!empty($data['dental_due_collection'])?$data['dental_due_collection']:0,2 . '');?></td>
		</tr>

		<?php 
			$dental_sub_total_amount					= $data['dental_collection'] + $data['dental_due_collection'];
			$dental_sub_total_amount_rf 				= 0;
			$dental_sub_total_amount_doctor_payment 	= 0;
			$dental_sub_total_amount_others_payment 	= 0;
			$dental_sub_total_balance 				= $dental_sub_total_amount-($dental_sub_total_amount_rf+$dental_sub_total_amount_doctor_payment+$dental_sub_total_amount_others_payment);
		?>
		<tr class="text-right">
			<th class="text-right" colspan="3">Sub Total</th>
			<th class="text-right"><?= number_format(!empty($dental_sub_total_amount)?$dental_sub_total_amount:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($dental_sub_total_amount_rf)?$dental_sub_total_amount_rf:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($dental_sub_total_amount_doctor_payment)?$dental_sub_total_amount_doctor_payment:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($dental_sub_total_amount_others_payment)?$dental_sub_total_amount_others_payment:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($dental_sub_total_balance)?$dental_sub_total_balance:0,2 . '');?></th>
		</tr>
		
		<tr>
			<td class="text-center">15</td>
			<td class="text-center" rowspan="2">Others Income</td>  
			<td class="text-left">Diagnostic</td>
			<td class="text-right"><?= number_format($data['diagnostic_income_amount']);?></td>
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td>
			<td class="text-right"><?= number_format(0,2 . '');?></td>
			<td class="text-right"><?= number_format($data['diagnostic_income_amount']);?></td>
		</tr>
		<tr>
			<td class="text-center">16</td> 
			<td class="text-left">Hospital</td>
			<td class="text-right"><?= number_format($data['hospital_income_amount']);?></td>
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td>
			<td class="text-right"><?= number_format(0,2 . '');?></td>
			<td class="text-right"><?= number_format($data['hospital_income_amount']);?></td>
		</tr>
		<?php 
			$others_income_sub_total_amount					= $data['diagnostic_income_amount'] + $data['hospital_income_amount'];
			$others_income_sub_total_amount_rf 				= 0;
			$others_income_sub_total_amount_doctor_payment 	= 0;
			$others_income_sub_total_amount_others_payment 	= 0;
			$others_income_sub_total_balance 				= $others_income_sub_total_amount-($others_income_sub_total_amount_rf+$others_income_sub_total_amount_doctor_payment+$others_income_sub_total_amount_others_payment);
		?>
		<tr class="text-right">
			<th class="text-right" colspan="3">Sub Total</th>
			<th class="text-right"><?= number_format(!empty($others_income_sub_total_amount)?$others_income_sub_total_amount:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($others_income_sub_total_amount_rf)?$others_income_sub_total_amount_rf:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($others_income_sub_total_amount_doctor_payment)?$others_income_sub_total_amount_doctor_payment:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($others_income_sub_total_amount_others_payment)?$others_income_sub_total_amount_others_payment:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($others_income_sub_total_balance)?$others_income_sub_total_balance:0,2 . '');?></th>
		</tr>
		
		<tr>
			<td class="text-center">17</td>
			<td class="text-center" rowspan="4">Others Expense</td>  
			<td class="text-left">Diagnostic</td>
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td>
			<td class="text-right"><?= number_format(0,2 . '');?></td>
			<td class="text-right"><?= number_format($data['diagnostic_expense_amount']);?></td>
			<td class="text-right"><?= number_format(-$data['diagnostic_expense_amount']);?></td>
		</tr>
		<tr>
			<td class="text-center">18</td> 
			<td class="text-left">Hospital</td>
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td>
			<td class="text-right"><?= number_format(0,2 . '');?></td>
			<td class="text-right"><?= number_format($data['hospital_expense_amount']);?></td>
			<td class="text-right"><?= number_format(-$data['hospital_expense_amount']);?></td>
		</tr>
		<tr>
			<td class="text-center">19</td> 
			<td class="text-left">Advance Salary</td>
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td>
			<td class="text-right"><?= number_format(0,2 . '');?></td>
			<td class="text-right"><?= number_format($data['advance_salary_amount']);?></td>
			<td class="text-right"><?= number_format(-$data['advance_salary_amount']);?></td>
		</tr>
		<tr>
			<td class="text-center">20</td> 
			<td class="text-left">Salary</td>
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td>
			<td class="text-right"><?= number_format(0,2 . '');?></td>
			<td class="text-right"><?= number_format($data['salary_amount']);?></td>
			<td class="text-right"><?= number_format(-$data['salary_amount']);?></td>
		</tr>
		<?php 
			$others_expense_sub_total_amount					= 0;
			$others_expense_sub_total_amount_rf 				= 0;
			$others_expense_sub_total_amount_doctor_payment 	= 0;
			$others_expense_sub_total_amount_others_payment 	= $data['hospital_expense_amount']+$data['diagnostic_expense_amount']+$data['advance_salary_amount']+$data['salary_amount'];
			$others_expense_sub_total_balance 					= -$others_expense_sub_total_amount_others_payment;
		?>
		<tr class="text-right">
			<th class="text-right" colspan="3">Sub Total</th>
			<th class="text-right"><?= number_format(!empty($others_expense_sub_total_amount)?$others_expense_sub_total_amount:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($others_expense_sub_total_amount_rf)?$others_expense_sub_total_amount_rf:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($others_expense_sub_total_amount_doctor_payment)?$others_expense_sub_total_amount_doctor_payment:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($others_expense_sub_total_amount_others_payment)?$others_expense_sub_total_amount_others_payment:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($others_expense_sub_total_balance)?$others_expense_sub_total_balance:0,2 . '');?></th>
		</tr>
		<tr>
			<td class="text-center">21</td>
			<td class="text-center" rowspan="1">Store</td>  
			<td class="text-left">Store Expense</td>
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td>
			<td class="text-right"><?= number_format(0,2 . '');?></td>
			<td class="text-right"><?= number_format($data['store_expense_amount']);?></td>
			<td class="text-right"><?= number_format($data['store_expense_amount']);?></td>
		</tr>
		<?php 
			$store_expense_sub_total_amount					= 0;
			$store_expense_sub_total_amount_rf 				= 0;
			$store_expense_sub_total_amount_doctor_payment 	= 0;
			$store_expense_sub_total_amount_others_payment 	= $data['store_expense_amount'];
			$store_expense_sub_total_balance 				= -$store_expense_sub_total_amount_others_payment;
		?>
		<tr class="text-right">
			<th class="text-right" colspan="3">Sub Total</th>
			<th class="text-right"><?= number_format(!empty($store_expense_sub_total_amount)?$store_expense_sub_total_amount:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($store_expense_sub_total_amount_rf)?$store_expense_sub_total_amount_rf:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($store_expense_sub_total_amount_doctor_payment)?$store_expense_sub_total_amount_doctor_payment:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($store_expense_sub_total_amount_others_payment)?$store_expense_sub_total_amount_others_payment:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($store_expense_sub_total_balance)?$store_expense_sub_total_balance:0,2 . '');?></th>
		</tr>

		
		<tr>
			<td class="text-center">22</td>
			<td class="text-center" rowspan="2">IVF Collection</td>  
			<td class="text-left">IVF Test Invoice</td><td class="text-right"><?= number_format(!empty($data['ivf_test_invoice_paid'])?$data['ivf_test_invoice_paid']:0,2 . '');?></td>
			<td class="text-right"><?= number_format(!empty($data['ivf_test_rf_commission'])?$data['ivf_test_rf_commission']:0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td>
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(!empty($data['ivf_test_invoice_paid']-($data['ivf_test_rf_commission']+0))?$data['ivf_test_invoice_paid']-($data['ivf_test_rf_commission']+0):0,2 . '');?></td>
		</tr>
		
		<tr>
			<td class="text-center">23</td> 
			<td class="text-left">IVF Due Collection</td>
			<td class="text-right"><?= number_format(!empty($data['ivfDueCollection'])?$data['ivfDueCollection']:0,2 . '');?></td>
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(0,2 . '');?></td>
			<td class="text-right"><?= number_format(0,2 . '');?></td> 
			<td class="text-right"><?= number_format(!empty($data['ivfDueCollection'])?$data['ivfDueCollection']:0,2 . '');?></td>
		</tr>
		<?php 
			$ivf_sub_total_amount 					= $data['ivf_test_invoice_paid']+$data['ivfDueCollection'];
			$ivf_sub_total_amount_rf 				= $data['ivf_test_rf_commission'];
			$ivf_sub_total_amount_doctor_payment 	= 0;
			$ivf_sub_total_amount_others_payment 	= 0;
			$ivf_sub_total_balance 					= $ivf_sub_total_amount-($ivf_sub_total_amount_rf+$ivf_sub_total_amount_doctor_payment+$ivf_sub_total_amount_others_payment);
		?>
		<tr class="text-right"> 
			<th class="text-right" colspan="3">Sub Total</th>
			<th class="text-right"><?= number_format(!empty($ivf_sub_total_amount)?$ivf_sub_total_amount:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($ivf_sub_total_amount_rf)?$ivf_sub_total_amount_rf:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($ivf_sub_total_amount_doctor_payment)?$ivf_sub_total_amount_doctor_payment:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($ivf_sub_total_amount_others_payment)?$ivf_sub_total_amount_others_payment:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($ivf_sub_total_balance)?$ivf_sub_total_balance:0,2 . '');?></th>
		</tr>
		
		<?php 
			$cancer_tx_sub_total_amount_rf = 0;
			$cancer_tx_sub_total_amount = 0;
			$cancer_tx_sub_total_amount_doctor_payment = 0;
			$cancer_tx_sub_total_amount_others_payment = 0;
			
			$grand_total_amount			= $opd_sub_total_amount + $ipd_sub_total_amount + $cancer_tx_sub_total_amount +  $emergency_sub_total_amount + $due_collection_sub_total_amount + $pharmacy_sub_total_amount + $others_income_sub_total_amount + $others_expense_sub_total_amount + $store_expense_sub_total_amount + $dental_sub_total_amount + $ivf_sub_total_amount;

			$grand_total_amount_rf		= $opd_sub_total_amount_rf + $ipd_sub_total_amount_rf + $cancer_tx_sub_total_amount_rf + $emergency_sub_total_amount_rf +$due_collection_sub_total_amount_rf + $pharmacy_sub_total_amount_rf + $others_income_sub_total_amount_rf + $others_expense_sub_total_amount_rf + $store_expense_sub_total_amount_rf + $dental_sub_total_amount_rf + $ivf_sub_total_amount_rf;

			$grand_total_amount_doctor_payment	= $opd_sub_total_amount_doctor_payment + $ipd_sub_total_amount_doctor_payment + $emergency_sub_total_amount_doctor_payment + $cancer_tx_sub_total_amount_doctor_payment + $due_collection_sub_total_amount_doctor_payment +  $pharmacy_sub_total_amount_doctor_payment +  $others_income_sub_total_amount_doctor_payment + $others_expense_sub_total_amount_doctor_payment+ $store_expense_sub_total_amount_doctor_payment+ $dental_sub_total_amount_doctor_payment + $ivf_sub_total_amount_doctor_payment;

			$grand_total_amount_others_payment 		= $opd_sub_total_amount_others_payment + $ipd_sub_total_amount_others_payment + $cancer_tx_sub_total_amount_others_payment + $emergency_sub_total_amount_others_payment + $due_collection_sub_total_amount_others_payment +$pharmacy_sub_total_amount_others_payment +$others_income_sub_total_amount_others_payment +$others_expense_sub_total_amount_others_payment +$store_expense_sub_total_amount_others_payment+$dental_sub_total_amount_others_payment + $ivf_sub_total_amount_others_payment;

			$grand_total_balance 					= $grand_total_amount-($grand_total_amount_rf+$grand_total_amount_doctor_payment+$grand_total_amount_others_payment);
		?>
		<tr class="text-right">
			<th class="text-right" colspan="3">Grand Total</th>
			<th class="text-right"><?= number_format(!empty($grand_total_amount)?$grand_total_amount:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($grand_total_amount_rf)?$grand_total_amount_rf:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($grand_total_amount_doctor_payment)?$grand_total_amount_doctor_payment:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($grand_total_amount_others_payment)?$grand_total_amount_others_payment:0,2 . '');?></th>
			<th class="text-right"><?= number_format(!empty($grand_total_balance)?$grand_total_balance:0,2 . '');?></th>
		</tr>
		<?php return $output;
	}

	/* ------------------------------------------------------
	Daily Collection Summary Report Print Model
	------------------------------------------------------- */
	function daily_collection_summary_print($to_date, $user)
	{
		$from_date = $to_date;
		$output = '';
		
		$appointment_sum =  $this->db->select("SUM(appointment_fees) as appointment_bill_amount, SUM(appointment_discount) as appointment_discount_amount, SUM(appointment_amount) as appointment_receivable_amount, SUM(appointment_paid_amount) as appointment_collection_amount, SUM(appointment_due_amount) as appointment_due_amount, SUM(appointment_doctor_charge) as appointment_doctor_charge, SUM(appointment_due_amount) as appointment_due_amount")
		->from('appointment') 
		->where('appointment_status', 1)
		->where('appointment_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
		->order_by('appointment_date', 'ASC')
		->get()
		->result();
		foreach($appointment_sum as $appointment_row){  
			$appointment_bill_amount		= $appointment_row->appointment_bill_amount;
			$appointment_discount_amount	= $appointment_row->appointment_discount_amount;
			$appointment_deposit_amount		= 0; 
			$appointment_receivable_amount	= $appointment_row->appointment_receivable_amount;
			$appointment_collection_amount	= $appointment_row->appointment_collection_amount;
			$appointment_due_amount			= $appointment_row->appointment_due_amount;
			$appointment_rc_amount			= 0;
			$appointment_doctor_charge		= $appointment_row->appointment_doctor_charge;
			$appointment_others_charge		= 0;
			$appointment_balance_amount		= $appointment_collection_amount-($appointment_doctor_charge+$appointment_others_charge); 
		}
		$investigation_sum =  $this->db->select("SUM(investigation_test_rate) as investigation_bill_amount, SUM(investigation_discount_amount) as investigation_discount_amount, SUM(investigation_amount) as investigation_receivable_amount, SUM(investigation_rc_amount) as investigation_rc_amount, SUM(investigation_doctor_charge) as investigation_doctor_charge, SUM(investigation_others_charge) as investigation_others_charge")
		->from('investigation') 
		->where('investigation_status', 1)
		->where('investigation_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
		->order_by('investigation_id', 'ASC')
		->get()
		->result();
		foreach($investigation_sum as $investigation_row){  
			
			$query_amount =  $this->db->select("SUM(investigation_collection_amount) as collection_amount")
			->from('investigation_collection')   
			->where('investigation_collection_status', 1)  
			->where('investigation_collection_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
			->order_by('investigation_collection_id', 'ASC')
			->get()	
			->result(); 	
			foreach($query_amount as $collection_row){ 
				$investigation_collection_amount = $collection_row->collection_amount;
			}
			
			$investigation_bill_amount			= $investigation_row->investigation_bill_amount;
			$investigation_discount_amount		= $investigation_row->investigation_discount_amount;
			$investigation_deposit_amount		= 0; 
			$investigation_receivable_amount	= $investigation_row->investigation_receivable_amount; 
			$investigation_due_amount			= $investigation_receivable_amount-$investigation_collection_amount;
			$investigation_rc_amount			= $investigation_row->investigation_rc_amount;
			$investigation_doctor_charge		= $investigation_row->investigation_doctor_charge;
			$investigation_others_charge		= $investigation_row->investigation_others_charge;
			$investigation_balance_amount		= $investigation_collection_amount-($investigation_rc_amount+$investigation_doctor_charge+$investigation_others_charge); 
		}
		
		$admission_sum =  $this->db->select("SUM(admission_fee) as admission_fee")
		->from('admission') 
		->where('admission_status', 1)
		->where('admission_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
		->order_by('admission_id', 'ASC')
		->get()
		->result();
		foreach($admission_sum as $admission_row){  
			
			$admission_bill_amount			= $admission_row->admission_fee;
			$admission_discount_amount		= 0;  
			$admission_deposit_amount		= 0;  
			$admission_receivable_amount	= $admission_row->admission_fee;
			$admission_collection_amount	= $admission_row->admission_fee;
			$admission_due_amount			= 0;
			$admission_rc_amount			= 0;
			$admission_doctor_charge		= 0;
			$admission_others_charge		= 0;
			$admission_balance_amount		= $admission_row->admission_fee;
		} 
		
		$admission_deposit_sum =  $this->db->select("SUM(admission_deposit_amount) as admission_deposit_amount")
		->from('admission_deposit') 
		->where('admission_deposit_status', 1)
		->where('admission_deposit_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
		->order_by('admission_deposit_id', 'ASC')
		->get()
		->result();
		foreach($admission_deposit_sum as $admission_deposit_row){  
			
			$admission_deposit_bill_amount			= $admission_deposit_row->admission_deposit_amount;
			$admission_deposit_discount_amount		= 0;  
			$admission_deposit_deposit_amount		= 0;  
			$admission_deposit_receivable_amount	= $admission_deposit_row->admission_deposit_amount;
			$admission_deposit_collection_amount	= $admission_deposit_row->admission_deposit_amount;
			$admission_deposit_due_amount			= 0;
			$admission_deposit_rc_amount			= 0;
			$admission_deposit_doctor_charge		= 0;
			$admission_deposit_others_charge		= 0;
			$admission_deposit_balance_amount		= $admission_deposit_row->admission_deposit_amount;
		}
		
		$bill_collection_sum =  $this->db->select("SUM(bill_collection_sub_total_amount) as bill_collection_bill_amount, SUM(bill_collection_discount_amount) as bill_collection_discount_amount, SUM(bill_collection_payable_amount) as bill_collection_receivable_amount, SUM(bill_collection_paid_amount) as bill_collection_collection_amount, SUM(bill_collection_due_amount) as bill_collection_due_amount, SUM(bill_collection_patient_rc_amount) as bill_collection_rc_amount, SUM(bill_collection_patient_doctor_charge) as bill_collection_doctor_charge, SUM(bill_collection_patient_others_charge) as bill_collection_others_charge")
		->from('bill_collection') 
		->where('bill_collection_status', 1)
		->where('bill_collection_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
		->order_by('bill_collection_id', 'ASC')
		->get()
		->result();
		foreach($bill_collection_sum as $bill_collection_row){  
			
			$deposit = $this->db->select("SUM(admission_deposit_amount) as deposit_amount")
			->from('admission_deposit')  
			->where('admission_deposit_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
			->where('admission_deposit_status', 1)  
			->order_by('admission_deposit_id', 'ASC') 
			->get()
			->result();
			foreach($deposit as $deposit_row)
			{
				$admission_deposit_amount = $deposit_row->deposit_amount;
			}
			
			$doctor_charge = $this->db->select("SUM(admission_doctor_charge_doctor) as admission_doctor_charge, SUM(admission_doctor_charge_others) as admission_others_charge")
			->from('admission_doctor_charge')  
			->where('admission_doctor_charge_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
			->where('admission_doctor_charge_status', 1)  
			->order_by('admission_doctor_charge_id', 'ASC') 
			->get()
			->result();
			foreach($doctor_charge as $doctor_charge_row)
			{
				$a_doctor_charge = $doctor_charge_row->admission_doctor_charge;
				$a_others_charge = $doctor_charge_row->admission_others_charge;
			}
			
			$bill_collection_bill_amount		= $bill_collection_row->bill_collection_bill_amount;
			$bill_collection_discount_amount	= $bill_collection_row->bill_collection_discount_amount;
			$bill_collection_deposit_amount		= $admission_deposit_amount; 
			$bill_collection_receivable_amount	= $bill_collection_row->bill_collection_receivable_amount; 
			$bill_collection_collection_amount	= $bill_collection_row->bill_collection_collection_amount; 
			$bill_collection_due_amount			= $bill_collection_receivable_amount-$bill_collection_collection_amount;
			$bill_collection_rc_amount			= $bill_collection_row->bill_collection_rc_amount;
			$bill_collection_doctor_charge		= $a_doctor_charge;
			$bill_collection_others_charge		= $a_others_charge;
			$bill_collection_balance_amount		= $bill_collection_collection_amount-($bill_collection_rc_amount+$bill_collection_doctor_charge+$bill_collection_others_charge); 
		}
		?>
		<tr>
			<td class="text-center">01</td>
			<td class="text-center" rowspan="2">OPD</td> 
			<td class="text-left">Appointment</td>  
			<td class="text-right"><?= number_format($appointment_collection_amount,2 . '');?>
			</td>  
			<td class="text-right"><?= number_format($appointment_rc_amount,2 . '');?></td>
			<td class="text-right"><?= number_format($appointment_doctor_charge,2 . '');?>
			</td>
			<td class="text-right"><?= number_format($appointment_others_charge,2 . '');?></td>
			<td class="text-right"><?= number_format($appointment_balance_amount,2 . '');?></td>
		</tr> 
		
		<tr>
			<td class="text-center">02</td>
			<td class="text-left">Investigation</td> 
			  
			<td class="text-right"><?= number_format($investigation_collection_amount,2 . '');?>
			</td> 
			<td class="text-right"><?= number_format($investigation_rc_amount,2 . '');?>
			</td>
			<td class="text-right"><?= number_format($investigation_doctor_charge,2 . '');?>
			</td>
			<td class="text-right"><?= number_format($investigation_others_charge,2 . '');?>
			</td>
			<td class="text-right"><?= number_format($investigation_balance_amount,2 . '');?></td>
		</tr>   
		
		<?php 
		$opd_bill_amount  		= $appointment_bill_amount + $investigation_bill_amount;
		$opd_discount_amount	= $appointment_discount_amount + $investigation_discount_amount;
		$opd_deposit_amount		= $appointment_deposit_amount + $investigation_deposit_amount;
		$opd_receivable_amount	= $appointment_receivable_amount + $investigation_receivable_amount;
		$opd_collection_amount	= $appointment_collection_amount + $investigation_collection_amount;
		$opd_due_amount			= $appointment_due_amount + $investigation_due_amount;
		$opd_rc_amount			= $appointment_rc_amount + $investigation_rc_amount;
		$opd_doctor_charge		= $appointment_doctor_charge + $investigation_doctor_charge;
		$opd_others_charge		= $appointment_others_charge + $investigation_others_charge;
		$opd_balance_amount		= $appointment_balance_amount + $investigation_balance_amount;
		?>
		<tr class="text-right"> 
			<th class="text-right" colspan="3">Sub Total</th> 
			<th class="text-right"><?= number_format($opd_collection_amount,2 . '');?></th> 
			<th class="text-right"><?= number_format($opd_rc_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($opd_doctor_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($opd_others_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($opd_balance_amount,2 . '');?></th>
		</tr>  
		<tr>
			<td class="text-center">03</td>
			<td class="text-center" rowspan="3">IPD</td> 
			<td class="text-left">Admission Fee</td>  
			<td class="text-right"><?= number_format($admission_collection_amount,2 . '');?>
			</td>  
			<td class="text-right"><?= number_format($admission_rc_amount,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_doctor_charge,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_others_charge,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_balance_amount,2 . '');?></td>
		</tr> 
		 
		<tr>
			<td class="text-center">04</td>
			<td class="text-left">Admission Deposit</td>  
			<td class="text-right"><?= number_format($admission_deposit_collection_amount,2 . '');?>
			</td>  
			<td class="text-right"><?= number_format($admission_deposit_rc_amount,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_deposit_doctor_charge,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_deposit_others_charge,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_deposit_balance_amount,2 . '');?></td>
		</tr> 
		 
		<tr>
			<td class="text-center">05</td>
			<td class="text-left">IPD Bill Collection</td>   
			<td class="text-right"><?= number_format($bill_collection_collection_amount,2 . '');?>
			</td>  
			<td class="text-right"><?= number_format($bill_collection_rc_amount,2 . '');?>
			</td>
			<td class="text-right"><?= number_format($bill_collection_doctor_charge,2 . '');?>
			</td>
			<td class="text-right"><?= number_format($bill_collection_others_charge,2 . '');?>
			</td>
			<td class="text-right"><?= number_format($bill_collection_balance_amount,2 . '');?></td>
		</tr>  
		
		<?php 
		$ipd_bill_amount  		= $admission_bill_amount + $admission_deposit_bill_amount + $bill_collection_bill_amount;
		$ipd_discount_amount	= $admission_discount_amount + $admission_deposit_discount_amount + $bill_collection_discount_amount;
		$ipd_deposit_amount		= $admission_deposit_deposit_amount + $bill_collection_deposit_amount;
		$ipd_receivable_amount	= $admission_receivable_amount + $admission_deposit_receivable_amount + $bill_collection_receivable_amount;
		$ipd_collection_amount	= $admission_collection_amount + $admission_deposit_collection_amount + $bill_collection_collection_amount;
		$ipd_due_amount			= $admission_due_amount + $admission_deposit_due_amount + $bill_collection_due_amount;
		$ipd_rc_amount			= $admission_rc_amount + $admission_deposit_rc_amount + $bill_collection_rc_amount;
		$ipd_doctor_charge		= $admission_doctor_charge + $admission_deposit_doctor_charge + $bill_collection_doctor_charge;
		$ipd_others_charge		= $admission_others_charge + $admission_deposit_others_charge + $bill_collection_others_charge;
		$ipd_balance_amount		= $admission_balance_amount + $admission_deposit_balance_amount + $bill_collection_balance_amount;
		?>
		<tr class="text-right"> 
			<th class="text-right" colspan="3">Sub Total</th> 
			<th class="text-right"><?= number_format($ipd_collection_amount,2 . '');?></th> 
			<th class="text-right"><?= number_format($ipd_rc_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($ipd_doctor_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($ipd_others_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($ipd_balance_amount,2 . '');?></th>
		</tr>  
		
		<?php 
		$bill_amount  		= $opd_bill_amount + $ipd_bill_amount;
		$discount_amount	= $opd_discount_amount + $ipd_discount_amount;
		$deposit_amount		= $opd_deposit_amount + $ipd_deposit_amount;
		$receivable_amount	= $opd_receivable_amount + $ipd_receivable_amount;
		$collection_amount	= $opd_collection_amount + $ipd_collection_amount;
		$due_amount			= $opd_due_amount + $ipd_due_amount;
		$rc_amount			= $opd_rc_amount + $ipd_rc_amount;
		$doctor_charge		= $opd_doctor_charge + $ipd_doctor_charge;
		$others_charge		= $opd_others_charge + $ipd_others_charge;
		$balance_amount		= $opd_balance_amount + $ipd_balance_amount;
		?> 
		<tr class="text-uppercase"> 
			<th class="text-right" colspan="3">Grand Total</th>
			<th class="text-right"><?= number_format($collection_amount,2 . '');?></th> 
			<th class="text-right"><?= number_format($rc_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($doctor_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($others_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($balance_amount,2 . '');?></th>
		</tr>  
		
		<tr class="text-uppercase">
			<th class="text-left" colspan="8">
			<?= $this->lang->line('in_word');?>: 
			<?php 
			$number 		= abs($balance_amount);
			$in_word_amount = $this->number_to_word_convert->convert_number($number);
			?>
			<?= $in_word_amount;?> <?= $this->lang->line('currency_only');?>.
			</th>
		</tr>
		
		<tr class="text-uppercase"> 
			<th class="text-right" colspan="7"> OPD Income</th>
			<th class="text-right"><?= number_format($opd_collection_amount,2 . '');?></th>
		</tr>  
		
		<tr class="text-uppercase"> 
			<th class="text-right" colspan="7"> IPD Income</th>
			<th class="text-right"><?= number_format($ipd_collection_amount,2 . '');?></th>
		</tr>  
		 
		
		<tr class="text-uppercase"> 
			<th class="text-right" colspan="7"> Total Income</th>
			<th class="text-right"><?= number_format($opd_collection_amount+$ipd_collection_amount,2 . '');?></th>
		</tr> 
		<?php return $output;
	}

	function getLedgeers(){
		$this->db->select('g.*')
		->from('chart_of_accounts a')
		->join('chart_of_accounts c', 'c.chart_of_accounts_accounts_category = a.chart_of_accounts_id')
		->join('chart_of_accounts g', 'g.chart_of_accounts_accounts_category = c.chart_of_accounts_id')
		->join('accounts_type', 'accounts_type.accounts_type_code = a.chart_of_accounts_accounts_category')
		->where('accounts_type.accounts_type_status', 1)
		->where('a.chart_of_accounts_status', 1)
		->where('c.chart_of_accounts_status', 1)
		->where('g.chart_of_accounts_status', 1);

		return $this->db->order_by('g.chart_of_accounts_name','ASC')->get()->result();
	}

	function day_close($to_date, $user)
	{
		$output = '';
		$ses_record_id = $this->session->userdata('ses_record_id');
		$from_date = date('Y-m-d', strtotime($to_date));
		$current_date = $to_date;
        $previous_date =  date_sub(date_create($current_date), date_interval_create_from_date_string("1 days"));
        $previous_date = date_format($previous_date, "Y-m-d");
		
		
		$where = array();
		$where['sales_date >= '] = $current_date;
		$where['sales_date <= '] = $current_date;
		
		// Pharmacy Details Start
		//$pharmacy_sales_amount	= 0;
		//$pharmacy_collection_amount	= 0;
		//$pharmacy_due_amount	= 0;
		
		//$pharmacy_query = $this->Common_model->findAll("sales_orders", $where, "sales_id", "desc");
		//foreach ($pharmacy_query as $key => $pharmacy_value) {
		//	$pharmacy_sales_amount += $pharmacy_value->grand_net_total;
		//	$pharmacy_collection_amount += $pharmacy_value->paid_amount;
		//	$pharmacy_due_amount += $pharmacy_value->due_amount;
		//}
		
		// pharmacy Due Collection
		//$data['values'] = $this->Common_model->findAll('mr',array(),'mr_id','desc');
		
		
		//$mr_where['mr_date >= '] = $current_date;
		//$mr_where['mr_date <= '] = $current_date;
		//$pharmacy_due_collection_amount	= 0;
		
		//$pharmacy_due_query = $this->Common_model->findAll("mr", $mr_where, "mr_id", "desc");
		//foreach ($pharmacy_due_query as $key => $pharmacy_due_value) {
		//	$pharmacy_due_collection_amount += $pharmacy_due_value->mr_amount;
		//}
		
		
        $pharmacyWhere = array();
        $pharmacyWhere['sales_date >= '] = $current_date;
		$pharmacyWhere['sales_date <= '] = $current_date;
        //$pharmacyWhere['sales_date'] = $previous_date;
		
		$pharmacyQuery = $this->Common_model->calculateSumMultiple('sales_orders', $pharmacyWhere, array('grand_net_total', 'paid_amount', 'due_amount'));
		
		$data['pharmacy_collection_amount'] = $pharmacyQuery->paid_amount;
		
		
        $pharmacyPurchaseWhere = array();
        $pharmacyPurchaseWhere['purchase_date >= '] = $current_date;
		$pharmacyPurchaseWhere['purchase_date <= '] = $current_date;
        $pharmacyPurchaseWhere['purchase_type'] = 'Medicine';
        $pharmacyPurchaseWhere['show_hide'] = 'Show';
		
		$pharmacyPurchaseQuery = $this->Common_model->calculateSumMultiple('purchase_orders', $pharmacyPurchaseWhere, array('paid_amount'));
		
		$data['pharmacy_purchase_amount'] = $pharmacyPurchaseQuery->paid_amount;
		
        $pharmacyDueWhere = array();
        $pharmacyDueWhere['mr_date >= '] = $current_date;
		$pharmacyDueWhere['mr_date <= '] = $current_date;
        //$pharmacyDueWhere['mr_date'] = $previous_date;
		
		$pharmacyDueQuery = $this->Common_model->calculateSumMultiple('mr', $pharmacyDueWhere, array('mr_amount'));
		
		$data['pharmacy_due_collection_amount'] = $pharmacyDueQuery->mr_amount;
		
		
        $pharmacyDuePaymentWhere = array();
        $pharmacyDuePaymentWhere['payment_date >= '] = $current_date;
		$pharmacyDuePaymentWhere['payment_date <= '] = $current_date;
        $pharmacyDuePaymentWhere['show_hide'] = 'Show';
		
		$pharmacyDuePaymentQuery = $this->Common_model->calculateSumMultiple('supplier_payments', $pharmacyDuePaymentWhere, array('payment_amount'));
		
		$data['pharmacy_due_payment_amount'] = $pharmacyDuePaymentQuery->payment_amount;
		
        $pharmacySpllierReturnWhere = array();
        $pharmacySpllierReturnWhere['return_date >= '] = $current_date;
		$pharmacySpllierReturnWhere['return_date <= '] = $current_date;
        $pharmacySpllierReturnWhere['return_type'] = 'Medicine';
        $pharmacySpllierReturnWhere['show_hide'] = 'Show';
		
		$pharmacySpllierReturnQuery = $this->Common_model->calculateSumMultiple('return_manages', $pharmacySpllierReturnWhere, array('grand_return_amount'));
		
		$data['pharmacy_supplier_return_amount'] = $pharmacySpllierReturnQuery->grand_return_amount;
		
        $pharmacyCustomerReturnWhere = array();
        $pharmacyCustomerReturnWhere['return_date >= '] = $current_date;
		$pharmacyCustomerReturnWhere['return_date <= '] = $current_date;
        $pharmacyCustomerReturnWhere['return_type'] = 'Medicine';
        $pharmacyCustomerReturnWhere['show_hide'] = 'Show';
		
		$pharmacyCustomerReturnQuery = $this->Common_model->calculateSumMultiple('customer_return_manages', $pharmacyCustomerReturnWhere, array('grand_return_amount'));
		
		$data['pharmacy_customer_return_amount'] = $pharmacyCustomerReturnQuery->grand_return_amount;
		
		// Pharmacy Details End
		
		
		$pathologyWhereBF = array();
        $pathologyWhereBF['date'] = $previous_date;
        $pathologyWhereBF['type'] = 'Test Invoice';
        // var_dump($pathologyWhereBF);die;
        $operationWhereBF['date'] = $previous_date;
        $operationInvoiceWhereBF['date'] = $previous_date;
        $operationInvoiceWhereBF['type'] = 'Admission';
        $operationWhereBF['type'] = 'Operation';

        $operationDetailsWhereBF = array();
        $operationDetailsWhereBF['operation_date'] = $previous_date;

        // var_dump($pathologyWhereBF);die;

        $ecgWhereBF['date'] = $previous_date;
        $ecgWhereBF['test_category'] = 'ECG';
        $xrayWhereBF['date'] = $previous_date;
        $xrayWhereBF['test_category like'] = '%X-Ray%';
        $ultraWhereBF['date'] = $previous_date;
        $ultraWhereBF['test_category like'] = 'Ultrasonogram';

        $generalIncomeWhereBF = array();
        $generalIncomeWhereBF['date'] = $previous_date;

        $consultancyWhereBF = array();
        $consultancyWhereBF['type'] = 'Appointment';
        $consultancyWhereBF['date'] = $previous_date;

        $commission_patholgyWhereBF = array();
        $commission_patholgyWhereBF['type'] = 'Test Invoice';
        $commission_patholgyWhereBF['date'] = $previous_date;



        $operation_commissionWhereBF = array();
        $operation_commissionWhereBF['operation_date'] = $previous_date;

        $sonologistExpenseWhereBF = array();
        $sonologistExpenseWhereBF['date'] = $previous_date;

        $generalExpenseWhereBF = array();
        $generalExpenseWhereBF['date'] = $previous_date;
        $staffSalaryWhereBF = array();
        $staffSalaryWhereBF['status'] = 'Paid';
        $staffSalaryWhereBF['date'] = $previous_date;

        $dueCollectionWhereBF = array();
        $dueCollectionWhereBF['mr_date'] = $previous_date;


        $salesWhereBF = array();
        $salesWhereBF['sales_from'] = 'Direct';
        $salesWhereBF['sales_date'] = $previous_date;

        $mrWhereBF = array();
        $mrWhereBF['mr_date'] = $previous_date;

        $emergencyWhereBF = array();
        $emergencyWhereBF['type'] = 'Emergency';
        $emergencyWhereBF['date'] = $previous_date;

        $ambulanceWhereBF = array();
        $ambulanceWhereBF['type'] = 'Ambulance';
        $ambulanceWhereBF['date'] = $previous_date;

        $doctorServiceWhereBF = array();
        $doctorServiceWhereBF['type'] = 'Doctor Service';
        $doctorServiceWhereBF['date'] = $previous_date;

        $donorWhereBF = array();
        $donorWhereBF['type'] = 'Donor';
        $donorWhereBF['date'] = $previous_date;

        $dressingWhereBF = array();
        $dressingWhereBF['type'] = 'Dressing';
        $dressingWhereBF['date'] = $previous_date;

        $supplier_paymentsWhereBF = array();
        $supplier_paymentsWhereBF['payment_date'] = $previous_date;

        $incomeWhereBF = array();
        $incomeWhereBF['income_date'] = $previous_date;
        $expenseWhereBF = array();
        $expenseWhereBF['approval'] = 'Approved';
        $expenseWhereBF['expense_date'] = $previous_date;

        $labInWhereBF = array();
        $labInWhereBF['in_date'] = $previous_date;
		
		if (!empty($created_by)) {
            $pathologyWhereBF['created_by'] = $created_by;
            $operationWhereBF['created_by'] = $created_by;
            $operationInvoiceWhereBF['created_by'] = $created_by;
            $operationDetailsWhereBF['created_by'] = $created_by;
            $ecgWhereBF['created_by'] = $created_by;
            $xrayWhereBF['created_by'] = $created_by;
            $ultraWhere['created_by'] = $created_by;
            $generalIncomeWhereBF['created_by'] = $created_by;
            $consultancyWhereBF['created_by'] = $created_by;
            $commission_patholgyWhereBF['created_by'] = $created_by;
            $operation_commissionWhereBF['created_by'] = $created_by;
            $generalExpenseWhereBF['created_by'] = $created_by;
            $staffSalaryWhereBF['created_by'] = $created_by;
            $dueCollectionWhereBF['created_by'] = $created_by;
            $salesWhereBF['created_by'] = $created_by;
            $emergencyWhereBF['created_by'] = $created_by;
            $ambulanceWhereBF['created_by'] = $created_by;
            $doctorServiceWhereBF['created_by'] = $created_by;
            $donorWhereBF['created_by'] = $created_by;
            $dressingWhereBF['created_by'] = $created_by;
            $supplier_paymentsWhereBF['created_by'] = $created_by;
            $incomeWhereBF['created_by'] = $created_by;
            $expenseWhereBF['created_by'] = $created_by;
            $labInWhereBF['created_by'] = $created_by;
        }
		
		$data['pathologyBF'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhereBF, 'sub_total');
        $data['pathology_paidBF'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhereBF, 'paid');
        $data['pathology_dueBF'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhereBF, 'due');
        // var_dump($data['pathology_paidBF']);die;
        $data['operationBF'] = $this->Common_model->calCulateSum('create_bill', $operationWhereBF, 'sub_total');
        $operation_paidBF = $this->Common_model->calculateSumMultiple('create_bill', $operationWhereBF, array('paid', 'medicine_cost'));
        $data['operation_paidBF'] = $operation_paidBF->paid; // + $operation_paid->medicine_cost ; //+ $operation_paid->advance ;
        $data['operation_dueBF'] = $this->Common_model->calCulateSum('create_bill', $operationWhereBF, 'due');
		
		$operationInvoiceBF = $this->Common_model->calculateSumMultiple('create_bill', $operationInvoiceWhereBF, array('sub_total', 'advance'));
        $data['operationInvoiceBF'] = $operationInvoiceBF->sub_total + $operationInvoiceBF->advance;

        $data['ecgBF'] = $this->Common_model->calCulateSum('sales_test', $ecgWhereBF, 'test_price');
        $data['xrayBF'] = $this->Common_model->calCulateSum('sales_test', $xrayWhereBF, 'test_price');
        $data['ultraBF'] = $this->Common_model->calCulateSum('sales_test', $ultraWhereBF, 'test_price');
		
		$consultancyBF = $this->Common_model->calculateSumMultiple('create_bill', $consultancyWhereBF, array('sub_total', 'paid', 'due', 'doctor_commission'));
        //var_dump($consultancy);die;
        $data['consultancyBF'] = isset($consultancyBF) ?  $consultancyBF->sub_total : 0;
        $data['consultancy_paidBF'] = isset($consultancyBF) ?  $consultancyBF->paid : 0;
        $data['consultancy_dueBF'] = isset($consultancyBF) ?  $consultancyBF->due : 0;
        $data['consultancy_doctor_commissionBF'] = isset($consultancyBF) ?  $consultancyBF->doctor_commission : 0;
        $doctor_commission_patholgyBF = $this->Common_model->calculateSumMultiple('create_bill', $commission_patholgyWhereBF, array('doctor_commission', 'reference_by_commission'));
        $doctor_commissionBF = isset($doctor_commission_patholgyBF) ? $doctor_commission_patholgyBF->doctor_commission : 0;
        $reference_by_commissionBF = isset($doctor_commission_patholgyBF) ? $doctor_commission_patholgyBF->reference_by_commission : 0;
        $data['doctor_commission_patholgyBF'] = $doctor_commissionBF + $reference_by_commissionBF;
		
		$operation_commissionBF =  $this->Common_model->calculateSumMultiple('operation_details', $operationDetailsWhereBF, array('surgeon_commission', 'surgeon_assistant_commission', 'anesthesia_commission', 'medicine_cost'));
        $surgeon_commissionBF = isset($operation_commissionBF) ? $operation_commissionBF->surgeon_commission : 0;
        $anesthesia_commissionBF = isset($operation_commissionBF) ? $operation_commissionBF->anesthesia_commission : 0;
        $medicine_costBF = isset($operation_commissionBF) ? $operation_commissionBF->medicine_cost : 0;
        $surgeon_assistant_commissionBF = isset($operation_commissionBF) ? $operation_commissionBF->surgeon_assistant_commission : 0;
        $data['operation_commissionBF'] =  $surgeon_commissionBF + $anesthesia_commissionBF + $medicine_costBF + $surgeon_assistant_commissionBF;
		
		$data['sonologistExpenseBF'] = $this->Common_model->calCulateSum('sonologist', $sonologistExpenseWhereBF, 'amount');

        $data['staffSalaryBF'] = $this->Common_model->calCulateSum('create_salary_sheet', $staffSalaryWhereBF, 'net_salary');

        $data['dueCollectionBF'] = $this->Common_model->calCulateSum('due_collections', $dueCollectionWhereBF, 'mr_amount');
		
		$sales_ordersBF = $this->Common_model->calculateSumMultiple('sales_orders', $salesWhereBF, array('grand_net_total', 'paid_amount', 'due_amount'));
        $data['sales_amountBF'] = $sales_ordersBF->grand_net_total;
        $data['sales_paid_amountBF'] = $sales_ordersBF->paid_amount;
        $data['sales_due_amountBF'] = $sales_ordersBF->due_amount;
        $data['pharmacy_collectionBF'] = $this->Common_model->calCulateSum('mr', $mrWhereBF, 'mr_amount');

        $data['supplier_paymentsBF'] = $this->Common_model->calCulateSum('supplier_payments', $supplier_paymentsWhereBF, 'payment_amount');
		
		$emergencyBF = $this->Common_model->calculateSumMultiple('create_bill', $emergencyWhereBF, array('sub_total', 'paid', 'doctor_commission', 'others_cost'));
        $data['emergency_totalBF'] = isset($emergencyBF) ? $emergencyBF->sub_total : 0;
        $data['emergency_paidBF'] = isset($emergencyBF) ? $emergencyBF->paid : 0;
        $data['emergency_doctor_commissionBF'] = isset($emergencyBF) ? $emergencyBF->doctor_commission : 0;
        $data['emergency_others_costBF'] = isset($emergencyBF) ? $emergencyBF->others_cost : 0;
		
		$ambulanceBF = $this->Common_model->calculateSumMultiple('create_bill', $ambulanceWhereBF, array('sub_total', 'paid', 'fuel_cost', 'road_cost', 'service_maintanance_cost'));
        $data['ambulance_totalBF'] = isset($ambulanceBF) ? $ambulanceBF->sub_total : 0;
        $data['ambulance_paidBF'] = isset($ambulanceBF) ? $ambulanceBF->paid : 0;
        $data['ambulance_fuel_costBF'] = isset($ambulanceBF) ? $ambulanceBF->fuel_cost : 0;
        $data['ambulance_road_costBF'] = isset($ambulanceBF) ? $ambulanceBF->road_cost : 0;
        $data['ambulance_service_maintanance_costBF'] = isset($ambulanceBF) ? $ambulanceBF->service_maintanance_cost : 0;
		
		$doctor_serviceBF = $this->Common_model->calculateSumMultiple('create_bill', $doctorServiceWhereBF, array('sub_total', 'paid', 'due', 'doctor_commission', 'reference_by_commission'));
        $data['doctor_service_totalBF'] = isset($doctor_serviceBF) ? $doctor_serviceBF->sub_total : 0;
        $data['doctor_service_paidBF'] = isset($doctor_serviceBF) ? $doctor_serviceBF->paid : 0;
        $data['doctor_service_reference_by_commissionBF'] = isset($doctor_serviceBF) ? $doctor_serviceBF->reference_by_commission : 0;
        $data['doctor_service_commissionBF'] = isset($doctor_serviceBF) ? $doctor_serviceBF->doctor_commission : 0;
        $data['doctor_service_commissionBF'] = $data['doctor_service_reference_by_commissionBF'] + $data['doctor_service_commissionBF'];
        $data['doctor_service_dueBF'] = isset($doctor_serviceBF) ? $doctor_serviceBF->due : 0;
		
		$donorBF = $this->Common_model->calculateSumMultiple('create_bill', $donorWhereBF, array('sub_total', 'paid'));
        $data['donor_totalBF'] = isset($donorBF) ? $donorBF->sub_total : 0;
        $data['donor_paidBF'] = isset($donorBF) ? $donorBF->paid : 0;
		
		$dressingBF = $this->Common_model->calculateSumMultiple('create_bill', $dressingWhereBF, array('sub_total', 'paid', 'doctor_commission'));
        $data['dressing_totalBF'] = isset($dressingBF) ? $dressingBF->sub_total : 0;
        $data['dressing_paidBF'] = isset($dressingBF) ? $dressingBF->paid : 0;
        $data['dressing_doctor_commissionBF'] = isset($dressingBF) ? $dressingBF->doctor_commission : 0;


        $data['general_incomeBF'] = $this->Common_model->calCulateSum('incomes', $incomeWhereBF, 'voucher_amount');
        $data['general_expenseBF'] = $this->Common_model->calCulateSum('expenses', $expenseWhereBF, 'voucher_amount');
        $data['lab_productBF'] = $this->Common_model->calCulateSum('lab_product_in', $labInWhereBF, 'grand_total_price');
        $data['total_paid_amountBF'] = $data['pathology_paidBF'] +  $data['operation_paidBF'] + $data['operationInvoiceBF'] +  $data['consultancy_paidBF'] + $data['dueCollectionBF']  + $data['emergency_paidBF']  + $data['ambulance_paidBF'] + $data['doctor_service_paidBF'] +  $data['general_incomeBF'] + $data['donor_paidBF'] + $data['dressing_paidBF'] + $data['sales_paid_amountBF'];
        $data['total_expense_amountBF'] = $data['doctor_commission_patholgyBF'] + $data['consultancy_doctor_commissionBF']  + $data['operation_commissionBF'] + $data['sonologistExpenseBF'] + $data['staffSalaryBF']  + $data['emergency_doctor_commissionBF'] + $data['emergency_others_costBF'] + $data['ambulance_fuel_costBF'] +  $data['ambulance_road_costBF'] + $data['ambulance_service_maintanance_costBF'] + $data['doctor_service_commissionBF'] + $data['general_expenseBF'] + $data['lab_productBF'] + $data['dressing_doctor_commissionBF'] + $data['supplier_paymentsBF'];
        $data['balance_amountBF'] = $data['total_paid_amountBF'] - $data['total_expense_amountBF'];

		/* B/F */

        $pathologyWhere = array();
        if (!admin()) {
            $pathologyWhere['show_hide'] = "Show";
        }
        $pathologyWhere['date'] = $current_date;
        $pathologyWhere['type'] = 'Test Invoice';

		$ivTestTnvoiceWhereWhere = array();
        if (!admin()) {
            $ivTestTnvoiceWhereWhere['show_hide'] = "Show";
        }
        $ivTestTnvoiceWhereWhere['date'] = $current_date;
        $ivTestTnvoiceWhereWhere['type'] = 'IVF Test Invoice';
		
        $pathologyRfPaymentWhere = array();
        if (!admin()) {
            $pathologyRfPaymentWhere['show_hide'] = "Show";
        }
        $pathologyRfPaymentWhere['date'] = $current_date;
        $pathologyRfPaymentWhere['type'] = 'Test Invoice';
        $pathologyRfPaymentWhere['test_invoice_payment_status'] = 'Paid';

        $ivfTestRfPaymentWhere = array();
        if (!admin()) {
            $ivfTestRfPaymentWhere['show_hide'] = "Show";
        }
        $ivfTestRfPaymentWhere['date'] = $current_date;
        $ivfTestRfPaymentWhere['type'] = 'IVF Test Invoice';
        $ivfTestRfPaymentWhere['test_invoice_payment_status'] = 'Paid';
		
        $operationWhere = array();
        if (!admin()) {
            $operationWhere['show_hide'] = "Show";
        }
        $operationWhere['date'] = $current_date;
        $operationInvoiceWhere = array();
        if (!admin()) {
            $operationInvoiceWhere['show_hide'] = "Show";
        }
        $operationInvoiceWhere['date'] = $current_date;
        $operationInvoiceWhere['type'] = 'Admission';

        $dayCareAdmissionInvoiceWhere = array();
        if (!admin()) {
            $dayCareAdmissionInvoiceWhere['show_hide'] = "Show";
        }
        $dayCareAdmissionInvoiceWhere['date'] = $current_date;
        $dayCareAdmissionInvoiceWhere['type'] = 'DayCareAdmission';

        $dayCareInvestigationInvoiceWhere = array();
        if (!admin()) {
            $dayCareInvestigationInvoiceWhere['show_hide'] = "Show";
        }
        $dayCareInvestigationInvoiceWhere['date'] = $current_date;
        $dayCareInvestigationInvoiceWhere['type'] = 'Investigation Invoice';

        $dayCareServiceInvoiceWhere = array();
        if (!admin()) {
            $dayCareServiceInvoiceWhere['show_hide'] = "Show";
        }
        $dayCareServiceInvoiceWhere['date'] = $current_date;
        $dayCareServiceInvoiceWhere['type'] = 'Day Care Service';

        $brachytherapyWhere = array();
        if (!admin()) {
            $brachytherapyWhere['show_hide'] = "Show";
        }
        $brachytherapyWhere['date'] = $current_date;
        $brachytherapyWhere['type'] = 'Brachytherapy';


        $operationAdmissionAdvanceInvoiceWhere = array();
        if (!admin()) {
            $operationAdmissionAdvanceInvoice['show_hide'] = "Show";
        }
        $operationAdmissionAdvanceInvoiceWhere['date'] = $current_date;
        $operationAdmissionAdvanceInvoiceWhere['type'] = 'AdmissionAdvance';
        $operationWhere['type'] = 'Operation';

        $operationDetailsWhere = array();
        if (!admin()) {
            $operationDetailsWhere['show_hide'] = "Show";
        }
        $operationDetailsWhere['payment_status'] = 'Paid';
        // $operationDetailsWhere['operation_date'] = $current_date;
        $operationDetailsWhere['payment_date'] = $current_date;
		
        $operationDetailsPaymentWhere = array();
        if (!admin()) {
            $operationDetailsPaymentWhere['show_hide'] = "Show";
        }
        // $operationDetailsPaymentWhere['payment_status'] = 'Paid';
        $operationDetailsPaymentWhere['operation_date'] = $current_date;
        $operationDetailsPaymentWhere['payment_status'] = 'Paid';

        $operationDetailsRfPaymentWhere = array();
        if (!admin()) {
            $operationDetailsRfPaymentWhere['show_hide'] = "Show";
        }
        // $operationDetailsRfPaymentWhere['payment_status'] = 'Paid';
        $operationDetailsRfPaymentWhere['operation_date'] = $current_date;
        $operationDetailsRfPaymentWhere['ref_comm_payment_status'] = 'Paid';

        $ecgWhere['date'] = $current_date;
        $ecgWhere['test_category'] = 'ECG';
        $xrayWhere['date'] = $current_date;
        $xrayWhere['test_category like'] = '%X-Ray%';
        $ultraWhere['date'] = $current_date;
        $ultraWhere['test_category like'] = 'Ultrasonogram';

        $generalIncomeWhere = array();
        if (!admin()) {
            $generalIncomeWhere['show_hide'] = "Show";
        }
        $generalIncomeWhere['date'] = $current_date;

        $consultancyWhere = array();
        if (!admin()) {
            $consultancyWhere['show_hide'] = "Show";
        }
        $consultancyWhere['type'] = 'Appointment';
        $consultancyWhere['date'] = $current_date;

        $consultancyPaymentWhere = array();
        if (!admin()) {
            $consultancyPaymentWhere['show_hide'] = "Show";
        }
        $consultancyPaymentWhere['type'] = 'Appointment';
        $consultancyPaymentWhere['date'] = $current_date;
        $consultancyPaymentWhere['doctor_visit_payment_status'] = 'Paid';

        $commission_patholgyWhere = array();
        if (!admin()) {
            $commission_patholgyWhere['show_hide'] = "Show";
        }
        $commission_patholgyWhere['test_invoice_payment_status'] = 'Paid';
        $commission_patholgyWhere['type'] = 'Test Invoice';
        $commission_patholgyWhere['date'] = $current_date;

        $operation_commissionWhere = array();
        if (!admin()) {
            $operation_commissionWhere['show_hide'] = "Show";
        }
        $operation_commissionWhere['operation_date'] = $current_date;

        $sonologistExpenseWhere = array();
        if (!admin()) {
            $sonologistExpenseWhere['show_hide'] = "Show";
        }
        $sonologistExpenseWhere['date'] = $current_date;

        $generalExpenseWhere = array();
        if (!admin()) {
            $generalExpenseWhere['show_hide'] = "Show";
        }
        $generalExpenseWhere['date'] = $current_date;
        $staffSalaryWhere = array();
        if (!admin()) {
            $staffSalaryWhere['show_hide'] = "Show";
        }
        $staffSalaryWhere['status'] = 'Paid';
        $staffSalaryWhere['date'] = $current_date;
		
		$dueCollectionWhere = array();
        if (!admin()) {
            $dueCollectionWhere['show_hide'] = "Show";
        }
        $dueCollectionWhere['mr_date'] = $current_date;
        $dueCollectionWhere['invoice_type!='] = 'Dental';
        $dueCollectionWhere['ivf_status'] = 0;
        
        $ivfDueCollectionWhere = array();
        if (!admin()) {
            $ivfDueCollectionWhere['show_hide'] = "Show";
        }
        $ivfDueCollectionWhere['mr_date'] = $current_date;
        $ivfDueCollectionWhere['invoice_type!='] = 'Dental';
        $ivfDueCollectionWhere['ivf_status'] = 1;


        $salesWhere = array();
        if (!admin()) {
            $salesWhere['show_hide'] = "Show";
        }
        $salesWhere['sales_from'] = 'Direct';
        $salesWhere['sales_date'] = $current_date;

        $mrWhere = array();
        if (!admin()) {
            $mrWhere['show_hide'] = "Show";
        }
        $mrWhere['mr_date'] = $current_date;

        $emergencyWhere = array();
        if (!admin()) {
            $emergencyWhere['show_hide'] = "Show";
        }
        $emergencyWhere['type'] = 'Emergency';
        $emergencyWhere['date'] = $current_date;

        $donationWhere = array();
        if (!admin()) {
            $donationWhere['show_hide'] = "Show";
        }
        $donationWhere['type'] = 'Donor';
        $donationWhere['date'] = $current_date;

        $ambulanceWhere = array();
        if (!admin()) {
            $ambulanceWhere['show_hide'] = "Show";
        }
        $ambulanceWhere['type'] = 'Ambulance';
        $ambulanceWhere['date'] = $current_date;

        $doctorServiceWhere = array();
        if (!admin()) {
            $doctorServiceWhere['show_hide'] = "Show";
        }
        $doctorServiceWhere['type'] = 'Doctor Service';
        $doctorServiceWhere['date'] = $current_date;

        $donorWhere = array();
        if (!admin()) {
            $donorWhere['show_hide'] = "Show";
        }
        $donorWhere['type'] = 'Donor';
        $donorWhere['date'] = $current_date;

        $dressingWhere = array();
        if (!admin()) {
            $dressingWhere['show_hide'] = "Show";
        }
        $dressingWhere['type'] = 'Dressing';
        $dressingWhere['date'] = $current_date;

        $supplier_paymentsWhere = array();
        if (!admin()) {
            $supplier_paymentsWhere['show_hide'] = "Show";
        }
        $supplier_paymentsWhere['payment_date'] = $current_date;

        $incomeWhere = array();
        if (!admin()) {
            $incomeWhere['show_hide'] = "Show";
        }
        $incomeWhere['income_date'] = $current_date;
        $expenseWhere = array();
        if (!admin()) {
            $expenseWhere['show_hide'] = "Show";
        }
        $expenseWhere['approval'] = 'Approved';
        $expenseWhere['expense_date'] = $current_date;

        $labInWhere = array();
        $labInWhere['approval'] = 'Approved';
        if (!admin()) {
            $labInWhere['show_hide'] = "Show";
        }
        $labInWhere['in_date'] = $current_date;
        //var_dump($labInWhere) ; die ;
        if (!empty($created_by)) {
            $pathologyWhere['created_by'] = $created_by;
            $ivTestTnvoiceWhereWhere['created_by'] = $created_by;
            $pathologyRfPaymentWhere['created_by'] = $created_by;
            $ivfTestRfPaymentWhere['created_by'] = $created_by;
            $operationWhere['created_by'] = $created_by;
            $operationInvoiceWhere['created_by'] = $created_by;
            $dayCareAdmissionInvoiceWhere['created_by'] = $created_by;
            $dayCareInvestigationInvoiceWhere['created_by'] = $created_by;
            $dayCareServiceInvoiceWhere['created_by'] = $created_by;
            $brachytherapyWhere['created_by'] = $created_by;
            $operationAdmissionAdvanceInvoiceWhere['created_by'] = $created_by;
            $operationDetailsWhere['created_by'] = $created_by;
            $operationDetailsPaymentWhere['created_by'] = $created_by;
            $operationDetailsRfPaymentWhere['created_by'] = $created_by;
            $ecgWhere['created_by'] = $created_by;
            $xrayWhere['created_by'] = $created_by;
            $ultraWhere['created_by'] = $created_by;
            $generalIncomeWhere['created_by'] = $created_by;
            $consultancyWhere['created_by'] = $created_by;
            $consultancyPaymentWhere['created_by'] = $created_by;
            $commission_patholgyWhere['created_by'] = $created_by;
            $operation_commissionWhere['created_by'] = $created_by;
            $generalExpenseWhere['created_by'] = $created_by;
            $staffSalaryWhere['created_by'] = $created_by;
            $dueCollectionWhere['created_by'] = $created_by;
            $ivfDueCollectionWhere['created_by'] = $created_by;
            $salesWhere['created_by'] = $created_by;
            $emergencyWhere['created_by'] = $created_by;
            $ambulanceWhere['created_by'] = $created_by;
            $doctorServiceWhere['created_by'] = $created_by;
            $donorWhere['created_by'] = $created_by;
            $dressingWhere['created_by'] = $created_by;
            $supplier_paymentsWhere['created_by'] = $created_by;
            $incomeWhere['created_by'] = $created_by;
            $expenseWhere['created_by'] = $created_by;
            $labInWhere['created_by'] = $created_by;
        }

        $data['pathology'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhere, 'sub_total');
        $pathologyData = $this->Common_model->calculateSumMultiple('create_bill', $pathologyWhere, ['paid', 'reference_by_commission']);
        $pathologyRfPaymentData = $this->Common_model->calculateSumMultiple('create_bill', $pathologyRfPaymentWhere, ['discount', 'reference_by_commission']);
		$ivfTestRfPaymentData = $this->Common_model->calculateSumMultiple('create_bill', $ivfTestRfPaymentWhere, ['discount', 'reference_by_commission']);
		// ddd($this->db->last_query());
        $data['pathology_due'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhere, 'due');
		
		$data['pathology_paid'] =$pathologyData->paid;

		

        $data['ivf_test_invoice'] = $this->Common_model->calCulateSum('create_bill', $ivTestTnvoiceWhereWhere, 'sub_total');
        $data['ivf_test_invoice_paid'] = $this->Common_model->calCulateSum('create_bill', $ivTestTnvoiceWhereWhere, 'paid');
        $data['ivf_test_invoice_due'] = $this->Common_model->calCulateSum('create_bill', $ivTestTnvoiceWhereWhere, 'due');
		
		$data['pathology_rf_commission'] = $pathologyRfPaymentData->reference_by_commission-$pathologyRfPaymentData->discount;
		$data['ivf_test_rf_commission'] = $ivfTestRfPaymentData->reference_by_commission-$ivfTestRfPaymentData->discount;

        $pathologyWhere['approved_discount'] = 'No';

        $pathologyDiscount = $this->Common_model->calCulateSum('create_bill', $pathologyWhere, 'discount');
        $pathologyDiscount = isset($pathologyDiscount)?$pathologyDiscount:0;
        $data['pathology'] += $pathologyDiscount;
        $data['pathology_due'] += $pathologyDiscount ;
        $data['operation'] = $this->Common_model->calCulateSum('create_bill', $operationWhere, 'sub_total');
        $operation_paid = $this->Common_model->calculateSumMultiple('create_bill', $operationWhere, array('paid', 'medicine_cost','due'));
        $data['operation_paid'] = $operation_paid->paid; // + $operation_paid->medicine_cost ; //+ $operation_paid->advance ;
        $data['operation_due'] = $operation_paid->due; 
        $operationWhere['approved_discount'] = 'No';

        $operationDiscount = $this->Common_model->calCulateSum('create_bill', $operationWhere, 'discount');
        $operationDiscount = isset($operationDiscount)?$operationDiscount:0;
        $data['operation'] += $operationDiscount ;
        $data['operation_due'] += $operationDiscount ;


        $operationInvoice = $this->Common_model->calculateSumMultiple('create_bill', $operationInvoiceWhere, array('sub_total', 'advance'));
        $data['operationInvoice'] = $operationInvoice->sub_total + $operationInvoice->advance;

		$operationDetails = $this->Common_model->calculateSumMultiple('operation_details', $operationDetailsWhere, array('surgeon_commission', 'anesthesia_commission', 'surgeon_assistant_commission', 'service_fee', 'medicine_cost', 'reference_by_payment'));
		
		$operationPaymentDetails = $this->Common_model->calculateSumMultiple('operation_details', $operationDetailsPaymentWhere, array('surgeon_commission', 'anesthesia_commission', 'surgeon_assistant_commission', 'service_fee', 'medicine_cost', 'reference_by_payment'));

		$operationRfPaymentDetails = $this->Common_model->calculateSumMultiple('operation_details', $operationDetailsRfPaymentWhere, array('surgeon_commission', 'anesthesia_commission', 'surgeon_assistant_commission', 'service_fee', 'medicine_cost', 'reference_by_payment'));

		// ddd($operationDetails);

		$data['operation_commission_doctors'] = ($operationPaymentDetails->surgeon_commission > 0) ? $operationPaymentDetails->surgeon_commission : 0;

		$data['operation_others_cost'] = $operationPaymentDetails->anesthesia_commission + $operationPaymentDetails->service_fee + $operationPaymentDetails->medicine_cost + $operationPaymentDetails->surgeon_assistant_commission;

		$data['operation_rf_commissions'] = $operationRfPaymentDetails->reference_by_payment;

        $dayCareAdmissionInvoice = $this->Common_model->calculateSumMultiple('create_bill', $dayCareAdmissionInvoiceWhere, array('sub_total', 'advance'));
        $data['dayCareAdmissionInvoice'] = $dayCareAdmissionInvoice->sub_total + $dayCareAdmissionInvoice->advance;

        $dayCareInvestigationInvoice = $this->Common_model->calculateSumMultiple('create_bill', $dayCareInvestigationInvoiceWhere, array('sub_total', 'paid','due'));
        $data['dayCareInvestigationInvoiceSubtotal'] = $dayCareInvestigationInvoice->sub_total;
        $data['dayCareInvestigationInvoicePaid'] = $dayCareInvestigationInvoice->paid;
        $data['dayCareInvestigationInvoiceDue'] = $dayCareInvestigationInvoice->due;

        $dayCareInvestigationInvoiceWhere['approved_discount'] = 'No';
        $dayCareInvestigationInvoiceDiscount = $this->Common_model->calCulateSum('create_bill', $dayCareInvestigationInvoiceWhere, 'discount');
        $dayCareInvestigationInvoiceDiscount = isset($dayCareInvestigationInvoiceDiscount)?$dayCareInvestigationInvoiceDiscount:0;
        $data['dayCareInvestigationInvoiceSubtotal'] +=  $dayCareInvestigationInvoiceDiscount ;
        $data['dayCareInvestigationInvoiceDue'] +=  $dayCareInvestigationInvoiceDiscount ;
       // var_dump($dayCareInvestigationInvoiceDiscount);die;
	   
	   $dayCareServiceInvoice= $this->Common_model->calculateSumMultiple('create_bill', $dayCareServiceInvoiceWhere, array('sub_total', 'paid','due'));
        $data['dayCareServiceInvoiceSubtotal'] = $dayCareServiceInvoice->sub_total;
        $data['dayCareServiceInvoicePaid'] = $dayCareServiceInvoice->paid;
        $data['dayCareServiceInvoiceDue'] = $dayCareServiceInvoice->due;

        $dayCareServiceInvoiceWhere['approved_discount'] = 'No';
        $dayCareServiceInvoiceDiscount = $this->Common_model->calCulateSum('create_bill', $dayCareServiceInvoiceWhere, 'discount');
        $dayCareServiceInvoiceDiscount = isset($dayCareServiceInvoiceDiscount)?$dayCareServiceInvoiceDiscount:0;
        $data['dayCareServiceInvoiceSubtotal'] +=  $dayCareServiceInvoiceDiscount ;
        $data['dayCareServiceInvoiceDue'] +=  $dayCareServiceInvoiceDiscount ;

        //var_dump($data['dayCareServiceInvoiceDue']);die;

        $brachytherapyInvoice= $this->Common_model->calculateSumMultiple('create_bill', $brachytherapyWhere, array('sub_total', 'paid','due'));
        $data['brachytherapyInvoiceSubtotal'] = $brachytherapyInvoice->sub_total;
        $data['brachytherapyInvoicePaid'] = $brachytherapyInvoice->paid;
        $data['brachytherapyInvoiceDue'] = $brachytherapyInvoice->due;
		
		$brachytherapyWhere['approved_discount'] = 'No';
        $brachytherapyDiscount = $this->Common_model->calCulateSum('create_bill', $brachytherapyWhere, 'discount');
        $brachytherapyDiscount = isset($brachytherapyDiscount)?$brachytherapyDiscount:0;
        $data['brachytherapyInvoiceSubtotal'] +=  $brachytherapyDiscount ;
        $data['brachytherapyInvoiceDue'] +=  $brachytherapyDiscount ;



        $operationAdmissionAdvanceInvoice = $this->Common_model->calculateSum('create_bill', $operationAdmissionAdvanceInvoiceWhere, 'sub_total');
        $data['operationAdmissionAdvanceInvoice'] = isset($operationAdmissionAdvanceInvoice) ? $operationAdmissionAdvanceInvoice : 0;

        $data['ecg'] = $this->Common_model->calCulateSum('sales_test', $ecgWhere, 'test_price');
        $data['xray'] = $this->Common_model->calCulateSum('sales_test', $xrayWhere, 'test_price');
        $data['ultra'] = $this->Common_model->calCulateSum('sales_test', $ultraWhere, 'test_price');
		
		$consultancy = $this->Common_model->calculateSumMultiple('create_bill', $consultancyWhere, array('sub_total', 'paid', 'due', 'doctor_commission'));
        
		$consultancyPayment = $this->Common_model->calculateSumMultiple('create_bill', $consultancyPaymentWhere, array('doctor_commission'));
        
        $data['consultancy'] = isset($consultancy) ?  $consultancy->sub_total : 0;
        $data['consultancy_paid'] = isset($consultancy) ?  $consultancy->paid : 0;
        $data['consultancy_due'] = isset($consultancy) ?  $consultancy->due : 0;
        $data['consultancy_doctor_commission'] = isset($consultancyPayment) ?  $consultancyPayment->doctor_commission : 0;
		
        $consultancyWhere['approved_discount'] = 'No';
        $consultancyDiscount = $this->Common_model->calCulateSum('create_bill', $consultancyWhere, 'discount');
        $consultancyDiscount = isset($consultancyDiscount)?$consultancyDiscount:0;
        $data['consultancy'] += $consultancyDiscount;
        $data['consultancy_due'] += $consultancyDiscount ;
        //var_dump($consultancyDiscount);die;

        $doctor_commission_patholgy = $this->Common_model->calculateSumMultiple('create_bill', $commission_patholgyWhere, array('discount', 'doctor_commission', 'reference_by_commission'));
        $test_invoice_discount = isset($doctor_commission_patholgy) ? $doctor_commission_patholgy->discount : 0;
        $doctor_commission = isset($doctor_commission_patholgy) ? $doctor_commission_patholgy->doctor_commission : 0;
        $reference_by_commission = isset($doctor_commission_patholgy) ? $doctor_commission_patholgy->reference_by_commission : 0;
        $data['doctor_commission_patholgy'] = $doctor_commission + $reference_by_commission - $test_invoice_discount;
        // var_dump( $data['doctor_commission_patholgy']  ) ; die; 

        // $operation_commission =  $this->Common_model->calculateSumMultiple('operation_details', $operationDetailsWhere, array('surgeon_commission', 'surgeon_assistant_commission', 'anesthesia_commission', 'medicine_cost', 'service_fee', 'reference_by_payment'));
        $operation_commission =  $this->Common_model->calculateSumMultiple('operation_expense', $operationDetailsWhere, array('surgeon_commission', 'surgeon_assistant_commission', 'anesthesia_commission', 'medicine_cost', 'service_fee', 'reference_by_payment'));
		$surgeon_commission = isset($operation_commission) ? $operation_commission->surgeon_commission : 0;
        $surgeon_commission = isset($operation_commission) ? $operation_commission->surgeon_commission : 0;
        $anesthesia_commission = isset($operation_commission) ? $operation_commission->anesthesia_commission : 0;
        $medicine_cost = isset($operation_commission) ? $operation_commission->medicine_cost : 0;
        $service_fee = isset($operation_commission) ? $operation_commission->service_fee : 0;
        $reference_by_payment = isset($operation_commission) ? $operation_commission->reference_by_payment : 0;
        $surgeon_assistant_commission = isset($operation_commission) ? $operation_commission->surgeon_assistant_commission : 0;
        $data['operation_commission'] =  $surgeon_commission + $anesthesia_commission + $medicine_cost + $surgeon_assistant_commission  + $service_fee + $reference_by_payment;
        $data['operation_commission_doctor'] =  $surgeon_commission + $anesthesia_commission + $surgeon_assistant_commission;
        $data['operation_commission_others'] =  $medicine_cost + $service_fee;

        $data['sonologistExpense'] = $this->Common_model->calCulateSum('sonologist', $sonologistExpenseWhere, 'amount');

        $data['staffSalary'] = $this->Common_model->calCulateSum('create_salary_sheet', $staffSalaryWhere, 'net_salary');

        // $data['dueCollection'] = $this->Common_model->calCulateSum('due_collections', $dueCollectionWhere, 'mr_amount');
		$data['dueCollection'] = $this->Common_model->calCulateSum('due_collection_details', $dueCollectionWhere, 'current_collection');
        $data['ivfDueCollection'] = $this->Common_model->calCulateSum('due_collection_details', $ivfDueCollectionWhere, 'current_collection');

        $sales_orders = $this->Common_model->calculateSumMultiple('sales_orders', $salesWhere, array('grand_net_total', 'paid_amount', 'due_amount'));
        $data['sales_amount'] = $sales_orders->grand_net_total;
        $data['sales_paid_amount'] = $sales_orders->paid_amount;
        $data['sales_due_amount'] = $sales_orders->due_amount;
        $data['pharmacy_collection'] = $this->Common_model->calCulateSum('mr', $mrWhere, 'mr_amount');

        $data['supplier_payments'] = $this->Common_model->calCulateSum('supplier_payments', $supplier_paymentsWhere, 'payment_amount');
		
		$emergency = $this->Common_model->calculateSumMultiple('create_bill', $emergencyWhere, array('sub_total', 'paid', 'doctor_commission', 'others_cost'));
        $data['emergency_total'] = isset($emergency) ? $emergency->sub_total : 0;
        $data['emergency_paid'] = isset($emergency) ? $emergency->paid : 0;
        $data['emergency_doctor_commission'] = isset($emergency) ? $emergency->doctor_commission : 0;
        $data['emergency_others_cost'] = isset($emergency) ? $emergency->others_cost : 0;

		$donation = $this->Common_model->calculateSumMultiple('create_bill', $donationWhere, array('sub_total', 'paid', 'doctor_commission', 'others_cost'));
        $data['donation_total'] = isset($donation) ? $donation->sub_total : 0;
        $data['donation_paid'] = isset($donation) ? $donation->paid : 0;
        $data['donation_doctor_commission'] = isset($donation) ? $donation->doctor_commission : 0;
        $data['donation_others_cost'] = isset($donation) ? $donation->others_cost : 0;

        $ambulance = $this->Common_model->calculateSumMultiple('create_bill', $ambulanceWhere, array('sub_total', 'paid', 'fuel_cost', 'road_cost', 'service_maintanance_cost'));
        $data['ambulance_total'] = isset($ambulance) ? $ambulance->sub_total : 0;
        $data['ambulance_paid'] = isset($ambulance) ? $ambulance->paid : 0;
        $data['ambulance_fuel_cost'] = isset($ambulance) ? $ambulance->fuel_cost : 0;
        $data['ambulance_road_cost'] = isset($ambulance) ? $ambulance->road_cost : 0;
        $data['ambulance_service_maintanance_cost'] = isset($ambulance) ? $ambulance->service_maintanance_cost : 0;

        $doctor_service = $this->Common_model->calculateSumMultiple('create_bill', $doctorServiceWhere, array('sub_total', 'paid', 'due', 'doctor_commission', 'reference_by_commission'));
        $data['doctor_service_total'] = isset($doctor_service) ? $doctor_service->sub_total : 0;
        $data['doctor_service_paid'] = isset($doctor_service) ? $doctor_service->paid : 0;
        $data['doctor_service_reference_by_commission'] = isset($doctor_service) ? $doctor_service->reference_by_commission : 0;
        $data['doctor_service_commission'] = isset($doctor_service) ? $doctor_service->doctor_commission : 0;
        $data['doctor_service_commission'] = $data['doctor_service_reference_by_commission'] + $data['doctor_service_commission'];
        $data['doctor_service_due'] = isset($doctor_service) ? $doctor_service->due : 0;
		
		$donor = $this->Common_model->calculateSumMultiple('create_bill', $donorWhere, array('sub_total', 'paid'));
        $data['donor_total'] = isset($donor) ? $donor->sub_total : 0;
        $data['donor_paid'] = isset($donor) ? $donor->paid : 0;
		
		$dressing = $this->Common_model->calculateSumMultiple('create_bill', $dressingWhere, array('sub_total', 'paid', 'doctor_commission'));
        $data['dressing_total'] = isset($dressing) ? $dressing->sub_total : 0;
        $data['dressing_paid'] = isset($dressing) ? $dressing->paid : 0;
        $data['dressing_doctor_commission'] = isset($dressing) ? (isset($dressing->doctor_commission) ? $dressing->doctor_commission : 0 ) : 0;
		
		$data['general_income'] = $this->Common_model->calCulateSum('incomes', $incomeWhere, 'voucher_amount');
        $data['general_expense'] = $this->Common_model->calCulateSum('expenses', $expenseWhere, 'voucher_amount');
        $data['lab_product'] = $this->Common_model->calCulateSum('lab_product_in', $labInWhere, 'grand_total_price');
		
		//$totalProductPurchase = $this->Common_model->getTotalProductPurchase($current_date, $current_date);
        // ddd($this->db->last_query());
        //$data['product_purchase'] = !empty($totalProductPurchase) ? $totalProductPurchase->total: 0;
		
		$data['total_paid_amount'] = $data['pathology_paid'] + $data['ivf_test_invoice_paid'] +  $data['operation_paid'] + $data['operationInvoice'] +  $data['consultancy_paid'] + $data['dueCollection'] + $data['ivfDueCollection']  + $data['emergency_paid']  + $data['ambulance_paid'] + $data['doctor_service_paid'] +  $data['general_income'] + $data['donor_paid'] + $data['dressing_paid'] + $data['operationAdmissionAdvanceInvoice'] + $data['dayCareAdmissionInvoice'] + $data['dayCareInvestigationInvoicePaid'] + $data['dayCareServiceInvoicePaid'] + $data['brachytherapyInvoicePaid'];

        $data['total_expense_amount'] = $data['doctor_commission_patholgy'] + $data['consultancy_doctor_commission']  + $data['operation_commission'] + $data['sonologistExpense'] + $data['staffSalary']  + $data['emergency_doctor_commission'] + $data['emergency_others_cost'] + $data['ambulance_fuel_cost'] +  $data['ambulance_road_cost'] + $data['ambulance_service_maintanance_cost'] + $data['doctor_service_commission'] + $data['general_expense'] + $data['lab_product'] + $data['dressing_doctor_commission'] + $data['product_purchase'];

        $data['balance_amount'] = $data['total_paid_amount'] - $data['total_expense_amount'];
		
		
		$diagnosticIncomeWhere = array();
        $diagnosticIncomeWhere['income_date >= '] = $current_date;
		$diagnosticIncomeWhere['income_date <= '] = $current_date;
        $diagnosticIncomeWhere['income_type'] = 'Diagnostic';
        $diagnosticIncomeWhere['show_hide'] = 'Show';
		
		$diagnosticIncomeQuery = $this->Common_model->calculateSumMultiple('incomes', $diagnosticIncomeWhere, array('voucher_amount'));
		
		$data['diagnostic_income_amount'] = $diagnosticIncomeQuery->voucher_amount;
		
		$hospitalIncomeWhere = array();
        $hospitalIncomeWhere['income_date >= '] = $current_date;
		$hospitalIncomeWhere['income_date <= '] = $current_date;
        $hospitalIncomeWhere['income_type'] = 'Hospital';
        $hospitalIncomeWhere['show_hide'] = 'Show';
		
		$hospitalIncomeQuery = $this->Common_model->calculateSumMultiple('incomes', $hospitalIncomeWhere, array('voucher_amount'));
		
		$data['hospital_income_amount'] = $hospitalIncomeQuery->voucher_amount;
		
		$diagnosticExpenseWhere = array();
        $diagnosticExpenseWhere['expense_date >= '] = $current_date;
		$diagnosticExpenseWhere['expense_date <= '] = $current_date;
        $diagnosticExpenseWhere['expense_type'] = 'Diagnostic';
        //$diagnosticExpenseWhere['approval'] = 'Approved';
        $diagnosticExpenseWhere['show_hide'] = 'Show';
		
		$diagnosticExpenseQuery = $this->Common_model->calculateSumMultiple('expenses', $diagnosticExpenseWhere, array('voucher_amount'));
		
		$data['diagnostic_expense_amount'] = $diagnosticExpenseQuery->voucher_amount;
		
		$hospitalExpenseWhere = array();
        $hospitalExpenseWhere['expense_date >= '] = $current_date;
		$hospitalExpenseWhere['expense_date <= '] = $current_date;
        $hospitalExpenseWhere['expense_type'] = 'Hospital';
        //$hospitalExpenseWhere['approval'] = 'Approved';
        $hospitalExpenseWhere['show_hide'] = 'Show';
		
		$hospitalExpenseQuery = $this->Common_model->calculateSumMultiple('expenses', $hospitalExpenseWhere, array('voucher_amount'));
		
		$data['hospital_expense_amount'] = $hospitalExpenseQuery->voucher_amount;
		
		
		$advanceSalaryWhere = array();
        $advanceSalaryWhere['date >= '] = $current_date;
		$advanceSalaryWhere['date <= '] = $current_date;
        //$advanceSalaryWhere['status'] = 'Paid';
		
		$advanceSalaryQuery = $this->Common_model->calculateSumMultiple('create_salary_sheet_advanced', $advanceSalaryWhere, array('advanced_amount'));
		
		$data['advance_salary_amount'] = $advanceSalaryQuery->advanced_amount;
		
		
		$SalaryWhere = array();
        $SalaryWhere['date >= '] = $current_date;
		$SalaryWhere['date <= '] = $current_date;
        $SalaryWhere['status'] = 'Paid';
		
		$SalaryQuery = $this->Common_model->calculateSumMultiple('create_salary_sheet', $SalaryWhere, array('net_salary'));
		
		$data['salary_amount'] = $SalaryQuery->net_salary;
		
		$StoreWhere = array();
        $StoreWhere['in_date >= '] = $current_date;
		$StoreWhere['in_date <= '] = $current_date;
        $StoreWhere['approval'] = 'Paid';
		
		$StoreQuery = $this->Common_model->calculateSumMultiple('lab_product_in', $StoreWhere, array('grand_total_price'));
		
		$data['store_expense_amount'] = $StoreQuery->grand_total_price;

		$dentalWhere = array();
        if (!admin()) {
            $dentalWhere['show_hide'] = "Show";
        }
        $dentalWhere['date'] = $current_date;
        $dentalWhere['type'] = 'Dental';

		
        $dentalCollectionWhere = array();
        if (!admin()) {
            $dentalCollectionWhere['show_hide'] = "Show";
        }
        $dentalCollectionWhere['mr_date'] = $current_date;
        $dentalCollectionWhere['invoice_type'] = 'Dental';

		$data['dental_paid'] = $this->Common_model->calCulateSum('create_bill', $dentalWhere, 'paid');
		$data['dentalCollection'] = $this->Common_model->calCulateSum('due_collection_details', $dentalCollectionWhere, 'current_collection');

		$data['dental_collection'] = $data['dental_paid']?$data['dental_paid']:0;
		$data['dental_due_collection'] = $data['dentalCollection']?$data['dentalCollection']:0;


		//Receipts
		$doctor_visit 					= $data['consultancy_paid'];
		$test_invoice 					= $data['pathology_paid'];
		$admission_invoice 				= $data['operationInvoice'];
		$advance_received 				= $data['operationAdmissionAdvanceInvoice'];
		$operation_collection 			= $data['operation_paid'];
		$due_collection 				= $data['dueCollection'];
		$emergency 						= $data['emergency_paid'];
		$dressing						= $data['dressing_paid'];
		$blood_donation					= $data['donation_paid'];
		$pharma_medicine_sales			= $data['pharmacy_collection_amount'];
		$pharma_due_collection			= $data['pharmacy_due_collection_amount'];
		$pharma_supplier_return			= $data['pharmacy_supplier_return_amount'];
		$general_income					= $data['diagnostic_income_amount'] + $data['hospital_income_amount'];
		$dental_collection			    = $data['dental_collection'];
		$dental_due_collection			= $data['dental_due_collection'];

		$ivf_test_invoice				= $data['ivf_test_invoice_paid'];
		$ivf_due_collection				= $data['ivfDueCollection'];

		$total_receipts 				= $doctor_visit + $test_invoice + $admission_invoice + $advance_received + $operation_collection + $due_collection + $emergency + $dressing + $blood_donation + $pharma_medicine_sales + $pharma_due_collection + $pharma_supplier_return + $general_income + $dental_collection + $dental_due_collection + $ivf_test_invoice + $ivf_due_collection;

		$doctor_visit_coa 				= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'doctor-visit'),'chart_of_accounts_id');
		$test_invoice_coa 				= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'test-invoice'),'chart_of_accounts_id');
		$admission_invoice_coa 			= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'admission-invoice'),'chart_of_accounts_id');
		$advance_received_coa 			= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'advance-received'),'chart_of_accounts_id');
		$operation_collection_coa 		= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'operation-collection'),'chart_of_accounts_id');
		$due_collection_coa 			= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'due-collection'),'chart_of_accounts_id');
		$emergency_coa 					= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'emergency'),'chart_of_accounts_id');
		$dressing_coa 					= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'dressing'),'chart_of_accounts_id');
		$blood_donation_coa 			= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'blood-donation'),'chart_of_accounts_id');
		$pharma_medicine_sales_coa 		= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'medicine-sales'),'chart_of_accounts_id');
		$pharma_due_collection_coa 		= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'pharma-due-collection'),'chart_of_accounts_id');
		$pharma_supplier_return_coa 	= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'pharma-supplier-return'),'chart_of_accounts_id');
		$general_income_coa 			= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'general-income'),'chart_of_accounts_id');
		$dental_collection_coa 			= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'dental'),'chart_of_accounts_id');
		$dental_due_collection_coa 		= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'dental-due'),'chart_of_accounts_id');
		$ivf_test_invoice_coa 			= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'ivf-test-invoice'),'chart_of_accounts_id');
		$ivf_due_collection_coa 		= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'ivf-due-collection'),'chart_of_accounts_id');

		$doctor_visit_payment 			= $data['consultancy_doctor_commission'];
		$test_invoice_payment 			= $data['pathology_rf_commission'] + $data['sonologistExpense'] + $data['ivf_test_rf_commission'];
		$operation_expense 				= $data['operation_commission_doctors'] + $data['operation_commission'];
		$operation_ref_payment			= $data['operation_rf_commissions'];
		$emergency_expense				= $data['emergency_doctor_commission'] + $data['emergency_others_cost'];
		$dressing_expense				= $data['dressing_doctor_commission'];
		$pharma_pedicine_purchase		= $data['pharmacy_purchase_amount'];
		$pharma_due_payment				= $data['pharmacy_due_payment_amount'];
		$pharma_customer_return			= $data['pharmacy_customer_return_amount'];
		$advance_salary					= $data['advance_salary_amount'];
		$staff_salary					= $data['salary_amount'];
		$general_expense				= $data['diagnostic_expense_amount'] + $data['hospital_expense_amount'];
		$store_expense					= $data['store_expense_amount'];

		$total_payments 				= $doctor_visit_payment + $test_invoice_payment + $operation_expense + $operation_ref_payment + $emergency_expense + $dressing_expense + $pharma_pedicine_purchase + $pharma_due_payment + $pharma_customer_return + $advance_salary + $staff_salary + $general_expense + $store_expense;

		$doctor_visit_payment_coa 		= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'doctor-visit-payment'),'chart_of_accounts_id');
		$test_invoice_payment_coa 		= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'test-invoice-payment'),'chart_of_accounts_id');
		$operation_expense_coa 			= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'operation-expense'),'chart_of_accounts_id');
		$operation_ref_payment_coa 		= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'operation-ref-payment'),'chart_of_accounts_id');
		$emergency_expense_coa 			= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'emergency-expense'),'chart_of_accounts_id');
		$dressing_expense_coa 			= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'dressing-expense'),'chart_of_accounts_id');
		$pharma_pedicine_purchase_coa 	= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'medicine-purchase'),'chart_of_accounts_id');
		$pharma_due_payment_coa 		= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'pharma-due-payment'),'chart_of_accounts_id');
		$pharma_customer_return_coa 	= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'pharma-customer-return'),'chart_of_accounts_id');
		$advance_salary_coa 			= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'advance-salary'),'chart_of_accounts_id');
		$staff_salary_coa 				= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'staff-salary'),'chart_of_accounts_id');
		$general_expense_coa 			= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'general-expense'),'chart_of_accounts_id');
		$store_expense_coa 				= $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'store-expense'),'chart_of_accounts_id');

		// Cash & Bank COA
		$cash_coa = $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'cash'),'chart_of_accounts_id');
		$bank_coa = $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'bank'),'chart_of_accounts_id');
		$investments_coa = $this->accounts_model->findDataReturnValue('chart_of_accounts','chart_of_accounts_id',array('chart_of_accounts_link_slug'=>'investments'),'chart_of_accounts_id');

		$rv_accounts_data = [
			'accounts_project' 				=> 0,
			'accounts_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
			'accounts_voucher_posting_month'=> date('F', strtotime($to_date)),
			'accounts_voucher_posting_year' => date('Y', strtotime($to_date)),
			'accounts_voucher_type' 		=> 1,
			'accounts_voucher_type_code' 	=> 'RV',
			'accounts_voucher_type_name' 	=> 'Receipt Voucher',
			'accounts_reference_number' 	=> '',
			'accounts_narration' 			=> 'Day Close Receipts Voucher',
			'accounts_total_debit' 			=> $total_receipts,
			'accounts_total_credit' 		=> $total_receipts,
			'accounts_status' 				=> 1
		];

		$rv_accounts_details_data = [
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 1,
				'accounts_details_voucher_type_code' 	=> 'RV',
				'accounts_details_voucher_type_name' 	=> 'Receipt Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Receipts Voucher',
				'accounts_details_subsidiary_ledger' 	=> $cash_coa,
				'accounts_details_debit' 				=> $total_receipts,
				'accounts_details_credit' 				=> 0,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 1,
				'accounts_details_voucher_type_code' 	=> 'RV',
				'accounts_details_voucher_type_name' 	=> 'Receipt Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Receipts Voucher',
				'accounts_details_subsidiary_ledger' 	=> $doctor_visit_coa,
				'accounts_details_debit' 				=> 0,
				'accounts_details_credit' 				=> $doctor_visit,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 1,
				'accounts_details_voucher_type_code' 	=> 'RV',
				'accounts_details_voucher_type_name' 	=> 'Receipt Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Receipts Voucher',
				'accounts_details_subsidiary_ledger' 	=> $test_invoice_coa,
				'accounts_details_debit' 				=> 0,
				'accounts_details_credit' 				=> $test_invoice,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 1,
				'accounts_details_voucher_type_code' 	=> 'RV',
				'accounts_details_voucher_type_name' 	=> 'Receipt Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Receipts Voucher',
				'accounts_details_subsidiary_ledger' 	=> $admission_invoice_coa,
				'accounts_details_debit' 				=> 0,
				'accounts_details_credit' 				=> $admission_invoice,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 1,
				'accounts_details_voucher_type_code' 	=> 'RV',
				'accounts_details_voucher_type_name' 	=> 'Receipt Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Receipts Voucher',
				'accounts_details_subsidiary_ledger' 	=> $advance_received_coa,
				'accounts_details_debit' 				=> 0,
				'accounts_details_credit' 				=> $advance_received,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 1,
				'accounts_details_voucher_type_code' 	=> 'RV',
				'accounts_details_voucher_type_name' 	=> 'Receipt Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Receipts Voucher',
				'accounts_details_subsidiary_ledger' 	=> $operation_collection_coa,
				'accounts_details_debit' 				=> 0,
				'accounts_details_credit' 				=> $operation_collection,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 1,
				'accounts_details_voucher_type_code' 	=> 'RV',
				'accounts_details_voucher_type_name' 	=> 'Receipt Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Receipts Voucher',
				'accounts_details_subsidiary_ledger' 	=> $due_collection_coa,
				'accounts_details_debit' 				=> 0,
				'accounts_details_credit' 				=> $due_collection,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 1,
				'accounts_details_voucher_type_code' 	=> 'RV',
				'accounts_details_voucher_type_name' 	=> 'Receipt Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Receipts Voucher',
				'accounts_details_subsidiary_ledger' 	=> $emergency_coa,
				'accounts_details_debit' 				=> 0,
				'accounts_details_credit' 				=> $emergency,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 1,
				'accounts_details_voucher_type_code' 	=> 'RV',
				'accounts_details_voucher_type_name' 	=> 'Receipt Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Receipts Voucher',
				'accounts_details_subsidiary_ledger' 	=> $dressing_coa,
				'accounts_details_debit' 				=> 0,
				'accounts_details_credit' 				=> $dressing,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 1,
				'accounts_details_voucher_type_code' 	=> 'RV',
				'accounts_details_voucher_type_name' 	=> 'Receipt Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Receipts Voucher',
				'accounts_details_subsidiary_ledger' 	=> $blood_donation_coa,
				'accounts_details_debit' 				=> 0,
				'accounts_details_credit' 				=> $blood_donation,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 1,
				'accounts_details_voucher_type_code' 	=> 'RV',
				'accounts_details_voucher_type_name' 	=> 'Receipt Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Receipts Voucher',
				'accounts_details_subsidiary_ledger' 	=> $pharma_medicine_sales_coa,
				'accounts_details_debit' 				=> 0,
				'accounts_details_credit' 				=> $pharma_medicine_sales,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 1,
				'accounts_details_voucher_type_code' 	=> 'RV',
				'accounts_details_voucher_type_name' 	=> 'Receipt Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Receipts Voucher',
				'accounts_details_subsidiary_ledger' 	=> $pharma_due_collection_coa,
				'accounts_details_debit' 				=> 0,
				'accounts_details_credit' 				=> $pharma_due_collection,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 1,
				'accounts_details_voucher_type_code' 	=> 'RV',
				'accounts_details_voucher_type_name' 	=> 'Receipt Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Receipts Voucher',
				'accounts_details_subsidiary_ledger' 	=> $pharma_supplier_return_coa,
				'accounts_details_debit' 				=> 0,
				'accounts_details_credit' 				=> $pharma_supplier_return,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 1,
				'accounts_details_voucher_type_code' 	=> 'RV',
				'accounts_details_voucher_type_name' 	=> 'Receipt Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Receipts Voucher',
				'accounts_details_subsidiary_ledger' 	=> $dental_collection_coa,
				'accounts_details_debit' 				=> 0,
				'accounts_details_credit' 				=> $dental_collection,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 1,
				'accounts_details_voucher_type_code' 	=> 'RV',
				'accounts_details_voucher_type_name' 	=> 'Receipt Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Receipts Voucher',
				'accounts_details_subsidiary_ledger' 	=> $dental_due_collection_coa,
				'accounts_details_debit' 				=> 0,
				'accounts_details_credit' 				=> $dental_due_collection,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 1,
				'accounts_details_voucher_type_code' 	=> 'RV',
				'accounts_details_voucher_type_name' 	=> 'Receipt Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Receipts Voucher',
				'accounts_details_subsidiary_ledger' 	=> $general_income_coa,
				'accounts_details_debit' 				=> 0,
				'accounts_details_credit' 				=> $general_income,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 1,
				'accounts_details_voucher_type_code' 	=> 'RV',
				'accounts_details_voucher_type_name' 	=> 'Receipt Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Receipts Voucher',
				'accounts_details_subsidiary_ledger' 	=> $ivf_test_invoice_coa,
				'accounts_details_debit' 				=> 0,
				'accounts_details_credit' 				=> $ivf_test_invoice,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 1,
				'accounts_details_voucher_type_code' 	=> 'RV',
				'accounts_details_voucher_type_name' 	=> 'Receipt Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Receipts Voucher',
				'accounts_details_subsidiary_ledger' 	=> $ivf_due_collection_coa,
				'accounts_details_debit' 				=> 0,
				'accounts_details_credit' 				=> $ivf_due_collection,
				'accounts_details_status' 				=> 1
			]
		];

		$pv_accounts_data = [
			'accounts_project' 				=> 0,
			'accounts_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
			'accounts_voucher_posting_month'=> date('F', strtotime($to_date)),
			'accounts_voucher_posting_year' => date('Y', strtotime($to_date)),
			'accounts_voucher_type' 		=> 2,
			'accounts_voucher_type_code' 	=> 'PV',
			'accounts_voucher_type_name' 	=> 'Payment Voucher',
			'accounts_reference_number' 	=> '',
			'accounts_narration' 			=> 'Day Close Payments Voucher',
			'accounts_total_debit' 			=> $total_payments,
			'accounts_total_credit' 		=> $total_payments,
			'accounts_status' 				=> 1
		];

		$pv_accounts_details_data = [
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 2,
				'accounts_details_voucher_type_code' 	=> 'PV',
				'accounts_details_voucher_type_name' 	=> 'Payment Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Payments Voucher',
				'accounts_details_subsidiary_ledger' 	=> $doctor_visit_payment_coa,
				'accounts_details_debit' 				=> $doctor_visit_payment,
				'accounts_details_credit' 				=> 0,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 2,
				'accounts_details_voucher_type_code' 	=> 'PV',
				'accounts_details_voucher_type_name' 	=> 'Payment Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Payments Voucher',
				'accounts_details_subsidiary_ledger' 	=> $test_invoice_payment_coa,
				'accounts_details_debit' 				=> $test_invoice_payment,
				'accounts_details_credit' 				=> 0,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 2,
				'accounts_details_voucher_type_code' 	=> 'PV',
				'accounts_details_voucher_type_name' 	=> 'Payment Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Payments Voucher',
				'accounts_details_subsidiary_ledger' 	=> $operation_expense_coa,
				'accounts_details_debit' 				=> $operation_expense,
				'accounts_details_credit' 				=> 0,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 2,
				'accounts_details_voucher_type_code' 	=> 'PV',
				'accounts_details_voucher_type_name' 	=> 'Payment Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Payments Voucher',
				'accounts_details_subsidiary_ledger' 	=> $operation_ref_payment_coa,
				'accounts_details_debit' 				=> $operation_ref_payment,
				'accounts_details_credit' 				=> 0,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 2,
				'accounts_details_voucher_type_code' 	=> 'PV',
				'accounts_details_voucher_type_name' 	=> 'Payment Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Payments Voucher',
				'accounts_details_subsidiary_ledger' 	=> $emergency_expense_coa,
				'accounts_details_debit' 				=> $emergency_expense,
				'accounts_details_credit' 				=> 0,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 2,
				'accounts_details_voucher_type_code' 	=> 'PV',
				'accounts_details_voucher_type_name' 	=> 'Payment Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Payments Voucher',
				'accounts_details_subsidiary_ledger' 	=> $dressing_expense_coa,
				'accounts_details_debit' 				=> $dressing_expense,
				'accounts_details_credit' 				=> 0,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 2,
				'accounts_details_voucher_type_code' 	=> 'PV',
				'accounts_details_voucher_type_name' 	=> 'Payment Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Payments Voucher',
				'accounts_details_subsidiary_ledger' 	=> $pharma_pedicine_purchase_coa,
				'accounts_details_debit' 				=> $pharma_pedicine_purchase,
				'accounts_details_credit' 				=> 0,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 2,
				'accounts_details_voucher_type_code' 	=> 'PV',
				'accounts_details_voucher_type_name' 	=> 'Payment Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Payments Voucher',
				'accounts_details_subsidiary_ledger' 	=> $pharma_due_payment_coa,
				'accounts_details_debit' 				=> $pharma_due_payment,
				'accounts_details_credit' 				=> 0,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 2,
				'accounts_details_voucher_type_code' 	=> 'PV',
				'accounts_details_voucher_type_name' 	=> 'Payment Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Payments Voucher',
				'accounts_details_subsidiary_ledger' 	=> $pharma_customer_return_coa,
				'accounts_details_debit' 				=> $pharma_customer_return,
				'accounts_details_credit' 				=> 0,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 2,
				'accounts_details_voucher_type_code' 	=> 'PV',
				'accounts_details_voucher_type_name' 	=> 'Payment Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Payments Voucher',
				'accounts_details_subsidiary_ledger' 	=> $advance_salary_coa,
				'accounts_details_debit' 				=> $advance_salary,
				'accounts_details_credit' 				=> 0,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 2,
				'accounts_details_voucher_type_code' 	=> 'PV',
				'accounts_details_voucher_type_name' 	=> 'Payment Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Payments Voucher',
				'accounts_details_subsidiary_ledger' 	=> $staff_salary_coa,
				'accounts_details_debit' 				=> $staff_salary,
				'accounts_details_credit' 				=> 0,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 2,
				'accounts_details_voucher_type_code' 	=> 'PV',
				'accounts_details_voucher_type_name' 	=> 'Payment Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Payments Voucher',
				'accounts_details_subsidiary_ledger' 	=> $general_expense_coa,
				'accounts_details_debit' 				=> $general_expense,
				'accounts_details_credit' 				=> 0,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> 0,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 2,
				'accounts_details_voucher_type_code' 	=> 'PV',
				'accounts_details_voucher_type_name' 	=> 'Payment Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Payments Voucher',
				'accounts_details_subsidiary_ledger' 	=> $store_expense_coa,
				'accounts_details_debit' 				=> $store_expense,
				'accounts_details_credit' 				=> 0,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> $project,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 2,
				'accounts_details_voucher_type_code' 	=> 'PV',
				'accounts_details_voucher_type_name' 	=> 'Payment Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Payments Voucher',
				'accounts_details_subsidiary_ledger' 	=> $cash_coa,
				'accounts_details_debit' 				=> 0,
				'accounts_details_credit' 				=> $total_payments,
				'accounts_details_status' 				=> 1
			]
		];

		if($total_payments>$total_receipts) {
			$funds_needed = $total_payments - $total_receipts;
		} else {
			$funds_needed = 0;
		}

		$rv_cb_accounts_data = [
			'accounts_project' 				=> $project,
			'accounts_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
			'accounts_voucher_posting_month'=> date('F', strtotime($to_date)),
			'accounts_voucher_posting_year' => date('Y', strtotime($to_date)),
			'accounts_voucher_type' 		=> 1,
			'accounts_voucher_type_code' 	=> 'RV',
			'accounts_voucher_type_name' 	=> 'Receipt Voucher',
			'accounts_reference_number' 	=> '',
			'accounts_narration' 			=> 'Day Close Funds Receipt from Investor Voucher',
			'accounts_total_debit' 			=> $funds_needed,
			'accounts_total_credit' 		=> $funds_needed,
			'accounts_status' 				=> 1
		];
		
		$rv_cb_accounts_details_data = [
			[
				'accounts_details_project' 				=> $project,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 1,
				'accounts_details_voucher_type_code' 	=> 'RV',
				'accounts_details_voucher_type_name' 	=> 'Receipt Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Funds Receipt from Investor Voucher',
				'accounts_details_subsidiary_ledger' 	=> $cash_coa,
				'accounts_details_debit' 				=> $funds_needed,
				'accounts_details_credit' 				=> 0,
				'accounts_details_status' 				=> 1
			],
			[
				'accounts_details_project' 				=> $project,
				'accounts_details_voucher_posting_date' => date('Y-m-d', strtotime($to_date)),
				'accounts_details_voucher_posting_month'=> date('F', strtotime($to_date)),
				'accounts_details_voucher_posting_year' => date('Y', strtotime($to_date)),
				'accounts_details_voucher_type' 		=> 1,
				'accounts_details_voucher_type_code' 	=> 'RV',
				'accounts_details_voucher_type_name' 	=> 'Receipt Voucher',
				'accounts_details_reference_number' 	=> '',
				'accounts_details_narration' 			=> 'Day Close Funds Receipt from Investor Voucher',
				'accounts_details_subsidiary_ledger' 	=> $investments_coa,
				'accounts_details_debit' 				=> 0,
				'accounts_details_credit' 				=> $funds_needed,
				'accounts_details_status' 				=> 1
			]
		];

		?>
		<tr>
			<td class="text-center" rowspan="17">01</td>
			<th class="text-center" rowspan="17">Receipts</th>  
			<td class="text-left">Doctor Visit</td>
			<td class="text-center">RV <?= $doctor_visit_coa;?></td>
			<td class="text-right"><?= number_format($doctor_visit,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-left">Test Invoice</td>
			<td class="text-center">RV <?= $test_invoice_coa;?></td>
			<td class="text-right"><?= number_format($test_invoice,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-left">Admission Invoice</td>
			<td class="text-center">RV <?= $admission_invoice_coa;?></td>
			<td class="text-right"><?= number_format($admission_invoice,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-left">Advance Received</td>
			<td class="text-center">RV <?= $advance_received_coa;?></td>
			<td class="text-right"><?= number_format($advance_received,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-left">Operation Collection</td>
			<td class="text-center">RV <?= $operation_collection_coa;?></td>
			<td class="text-right"><?= number_format($operation_collection,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-left">Due Collection (OPD & IPD)</td>
			<td class="text-center">RV <?= $due_collection_coa;?></td>
			<td class="text-right"><?= number_format($due_collection,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-left">Emergency</td>
			<td class="text-center">RV <?= $emergency_coa;?></td>
			<td class="text-right"><?= number_format($emergency,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-left">Dressing</td>
			<td class="text-center">RV <?= $dressing_coa;?></td>
			<td class="text-right"><?= number_format($dressing,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-left">Blood Donation</td>
			<td class="text-center">RV <?= $blood_donation_coa;?></td>
			<td class="text-right"><?= number_format($blood_donation,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-left">Pharma Medicine Sales</td>
			<td class="text-center">RV <?= $pharma_medicine_sales_coa;?></td>
			<td class="text-right"><?= number_format($pharma_medicine_sales,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-left">Pharma Due Collection</td>
			<td class="text-center">RV <?= $pharma_due_collection_coa;?></td>
			<td class="text-right"><?= number_format($pharma_due_collection,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-left">Pharma Supplier Return</td>
			<td class="text-center">RV <?= $pharma_supplier_return_coa;?></td>
			<td class="text-right"><?= number_format($pharma_supplier_return,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-left">Dental Collection</td>
			<td class="text-center">RV <?= $dental_collection_coa;?></td>
			<td class="text-right"><?= number_format($dental_collection,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-left">Dental Due Collection</td>
			<td class="text-center">RV <?= $dental_due_collection_coa;?></td>
			<td class="text-right"><?= number_format($dental_due_collection,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-left">General Income</td>
			<td class="text-center">RV <?= $general_income_coa;?></td>
			<td class="text-right"><?= number_format($general_income,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-left">IVF Test Invoice</td>
			<td class="text-center">RV <?= $ivf_test_invoice_coa;?></td>
			<td class="text-right"><?= number_format($ivf_test_invoice,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-left">IVF Due Collection</td>
			<td class="text-center">RV <?= $ivf_due_collection_coa;?></td>
			<td class="text-right"><?= number_format($ivf_due_collection,2 . '');?></td>
		</tr>

		<tr>
			<th class="text-right" colspan="4">Total Receipts</th>
			<th class="text-right"><?= number_format($total_receipts,2 . '');?></th>
		</tr>

		<tr>
			<td class="text-center" rowspan="13">02</td>
			<th class="text-center" rowspan="13">Payments</th>  
			<td class="text-left">Doctor Visit Payment</td>
			<td class="text-center">PV <?= $doctor_visit_payment_coa;?></td>
			<td class="text-right"><?= number_format($doctor_visit_payment,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-left">Test Invoice Payment</td>
			<td class="text-center">PV <?= $test_invoice_payment_coa;?></td>
			<td class="text-right"><?= number_format($test_invoice_payment,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-left">Operation Expense</td>
			<td class="text-center">PV <?= $operation_expense_coa;?></td>
			<td class="text-right"><?= number_format($operation_expense,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-left">Operation Ref. Payment</td>
			<td class="text-center">PV <?= $operation_ref_payment_coa;?></td>
			<td class="text-right"><?= number_format($operation_ref_payment,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-left">Eemergency Expense</td>
			<td class="text-center">PV <?= $emergency_expense_coa;?></td>
			<td class="text-right"><?= number_format($emergency_expense,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-left">Dressing Expense</td>
			<td class="text-center">PV <?= $dressing_expense_coa;?></td>
			<td class="text-right"><?= number_format($dressing_expense,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-left">Pharma Medicine Purchase</td>
			<td class="text-center">PV <?= $pharma_pedicine_purchase_coa;?></td>
			<td class="text-right"><?= number_format($pharma_pedicine_purchase,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-left">Pharma Due Payment</td>
			<td class="text-center">PV <?= $pharma_due_payment_coa;?></td>
			<td class="text-right"><?= number_format($pharma_due_payment,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-left">Pharma Customer Return</td>
			<td class="text-center">PV <?= $pharma_customer_return_coa;?></td>
			<td class="text-right"><?= number_format($pharma_customer_return,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-left">Advance Salary</td>
			<td class="text-center">PV <?= $advance_salary_coa;?></td>
			<td class="text-right"><?= number_format($advance_salary,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-left">Staff Salary</td>
			<td class="text-center">PV <?= $staff_salary_coa;?></td>
			<td class="text-right"><?= number_format($staff_salary,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-left">General Expense</td>
			<td class="text-center">PV <?= $general_expense_coa;?></td>
			<td class="text-right"><?= number_format($general_expense,2 . '');?></td>
		</tr>
		<tr>
			<td class="text-left">Store Expense</td>
			<td class="text-center">PV <?= $store_expense_coa;?></td>
			<td class="text-right"><?= number_format($store_expense,2 . '');?></td>
		</tr>
		
		<tr>
			<th class="text-right" colspan="4">Total Payments</th>
			<th class="text-right"><?= number_format($total_payments,2 . '');?></th>
		</tr>

		<tr>
			<td class="text-center" colspan="5">&nbsp;</td>
		</tr>
		
		<tr>
			<th class="text-right" colspan="4">Cash Collection</th>
			<th class="text-right"><?= number_format($total_receipts,2 . '');?></th>
		</tr>
		
		<tr>
			<th class="text-right" colspan="4">Bank Collection</th>
			<th class="text-right"><?= number_format(0,2 . '');?></th>
		</tr>
		
		<tr>
			<td class="text-center" colspan="5">&nbsp;</td>
		</tr>
		
		<tr>
			<th class="text-right" colspan="4">Cash Payment</th>
			<th class="text-right"><?= number_format($total_payments,2 . '');?></th>
		</tr>
		
		<tr>
			<th class="text-right" colspan="4">Bank Payment</th>
			<th class="text-right"><?= number_format(0,2 . '');?></th>
		</tr>
		<?php if($total_payments>$total_receipts){?>
		<tr>
			<th class="text-right" colspan="4">Funds Needed</th>
			<th class="text-right"><?= number_format(($total_payments-$total_receipts),2 . '');?></th>
		</tr>
		<?php }?>

		<?php $posting_check = $this->db->select("*")
		->from('accounts')
		->where('accounts_voucher_posting_date',$to_date)
		->where('accounts_voucher_posting_status','Auto')
		->get()
		->row();
		if(!$posting_check) {?>
		<tr>
			<th class="text-right" colspan="4"></th>
			<th class="text-right">
				<script>	
					$(document).ready(function(){
						$('#insertClick').click(function(){
						  var rv_accounts_data = <?= json_encode($rv_accounts_data);?>;
						  var rv_accounts_details_data = <?= json_encode($rv_accounts_details_data);?>;
						  var pv_accounts_data = <?= json_encode($pv_accounts_data);?>;
						  var pv_accounts_details_data = <?= json_encode($pv_accounts_details_data);?>;
						  var rv_cb_accounts_data = <?= json_encode($rv_cb_accounts_data);?>;
						  var rv_cb_accounts_details_data = <?= json_encode($rv_cb_accounts_details_data);?>;
						  var invest_payment_type = 'Cash';
						  
						   $.ajax({
							url:"<?= base_url('accounts/day_close_create');?>",
							
							method:"POST",
							data:{
								rv_accounts_data:rv_accounts_data,
								rv_accounts_details_data:rv_accounts_details_data,
								pv_accounts_data:pv_accounts_data,
								pv_accounts_details_data:pv_accounts_details_data,
								rv_cb_accounts_data:rv_cb_accounts_data,
								rv_cb_accounts_details_data:rv_cb_accounts_details_data,
								invest_payment_type:invest_payment_type
							},
							success:function(data)
								{
									// $('#modal_ajax').modal('show');
									// $('#data_message').html(data);
									// document.getElementById("insert").reset();
									alert(data);
									location.reload();
								}
						   });
						});
					});
				</script>
				<button type="button" id="insertClick" class="btn btn-brand btn-sm btn-danger tx-uppercase" onclick="return confirm('<?= $this->lang->line("model_close_warning"); ?>')"><?= $this->lang->line('close'); ?></button>
			</th>
		</tr>
		<?php }?>
		<?php return $output;
	}

	/* ------------------------------------------------------
	Find Data Model
	------------------------------------------------------- */
	function findDataReturnValue($table, $return, $where, $select)
	{
		if(!empty($select)){
			
		$this->db->select($select);
		} else {
		$this->db->select('*');
		}
		
        $this->db->from($table);
        $this->db->where($where);
        $query = $this->db->get()->row();
        return $query->$return;
	}

	/* ------------------------------------------------------
	Daily Collection Summary Report Model
	------------------------------------------------------- */
	function daily_collection_summary_bk($to_date, $user)
	{
		$from_date = $to_date;
		$output = '';
		
		$appointment_sum =  $this->db->select("SUM(appointment_fees) as appointment_bill_amount, SUM(appointment_discount) as appointment_discount_amount, SUM(appointment_amount) as appointment_receivable_amount, SUM(appointment_paid_amount) as appointment_collection_amount, SUM(appointment_due_amount) as appointment_due_amount, SUM(appointment_doctor_charge) as appointment_doctor_charge, SUM(appointment_due_amount) as appointment_due_amount")
		->from('appointment') 
		->where('appointment_status', 1)
		->where('appointment_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
		->order_by('appointment_date', 'ASC')
		->get()
		->result();
		foreach($appointment_sum as $appointment_row){  
			$appointment_bill_amount		= $appointment_row->appointment_bill_amount;
			$appointment_discount_amount	= $appointment_row->appointment_discount_amount;
			$appointment_deposit_amount		= 0; 
			$appointment_receivable_amount	= $appointment_row->appointment_receivable_amount;
			$appointment_collection_amount	= $appointment_row->appointment_collection_amount;
			$appointment_due_amount			= $appointment_row->appointment_due_amount;
			$appointment_rc_amount			= 0;
			$appointment_doctor_charge		= $appointment_row->appointment_doctor_charge;
			$appointment_others_charge		= 0;
			$appointment_balance_amount		= $appointment_collection_amount-($appointment_doctor_charge+$appointment_others_charge); 
		}
		$investigation_sum =  $this->db->select("SUM(investigation_test_rate) as investigation_bill_amount, SUM(investigation_discount_amount) as investigation_discount_amount, SUM(investigation_amount) as investigation_receivable_amount, SUM(investigation_rc_amount) as investigation_rc_amount, SUM(investigation_doctor_charge) as investigation_doctor_charge, SUM(investigation_others_charge) as investigation_others_charge")
		->from('investigation') 
		->where('investigation_status', 1)
		->where('investigation_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
		->order_by('investigation_id', 'ASC')
		->get()
		->result();
		foreach($investigation_sum as $investigation_row){  
			
			$query_amount =  $this->db->select("SUM(investigation_collection_amount) as collection_amount")
			->from('investigation_collection')   
			->where('investigation_collection_status', 1)  
			->where('investigation_collection_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
			->order_by('investigation_collection_id', 'ASC')
			->get()	
			->result(); 	
			foreach($query_amount as $collection_row){ 
				$investigation_collection_amount = $collection_row->collection_amount;
			}
			
			$investigation_bill_amount			= $investigation_row->investigation_bill_amount;
			$investigation_discount_amount		= $investigation_row->investigation_discount_amount;
			$investigation_deposit_amount		= 0; 
			$investigation_receivable_amount	= $investigation_row->investigation_receivable_amount; 
			$investigation_due_amount			= $investigation_receivable_amount-$investigation_collection_amount;
			$investigation_rc_amount			= $investigation_row->investigation_rc_amount;
			$investigation_doctor_charge		= $investigation_row->investigation_doctor_charge;
			$investigation_others_charge		= $investigation_row->investigation_others_charge;
			$investigation_balance_amount		= $investigation_collection_amount-($investigation_rc_amount+$investigation_doctor_charge+$investigation_others_charge); 
		}
		
		$admission_sum =  $this->db->select("SUM(admission_fee) as admission_fee")
		->from('admission') 
		->where('admission_status', 1)
		->where('admission_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
		->order_by('admission_id', 'ASC')
		->get()
		->result();
		foreach($admission_sum as $admission_row){  
			
			$admission_bill_amount			= $admission_row->admission_fee;
			$admission_discount_amount		= 0;  
			$admission_deposit_amount		= 0;  
			$admission_receivable_amount	= $admission_row->admission_fee;
			$admission_collection_amount	= $admission_row->admission_fee;
			$admission_due_amount			= 0;
			$admission_rc_amount			= 0;
			$admission_doctor_charge		= 0;
			$admission_others_charge		= 0;
			$admission_balance_amount		= $admission_row->admission_fee;
		} 
		
		$admission_deposit_sum =  $this->db->select("SUM(admission_deposit_amount) as admission_deposit_amount")
		->from('admission_deposit') 
		->where('admission_deposit_status', 1)
		->where('admission_deposit_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
		->order_by('admission_deposit_id', 'ASC')
		->get()
		->result();
		foreach($admission_deposit_sum as $admission_deposit_row){  
			
			$admission_deposit_bill_amount			= $admission_deposit_row->admission_deposit_amount;
			$admission_deposit_discount_amount		= 0;  
			$admission_deposit_deposit_amount		= 0;  
			$admission_deposit_receivable_amount	= $admission_deposit_row->admission_deposit_amount;
			$admission_deposit_collection_amount	= $admission_deposit_row->admission_deposit_amount;
			$admission_deposit_due_amount			= 0;
			$admission_deposit_rc_amount			= 0;
			$admission_deposit_doctor_charge		= 0;
			$admission_deposit_others_charge		= 0;
			$admission_deposit_balance_amount		= $admission_deposit_row->admission_deposit_amount;
		}
		
		$bill_collection_sum =  $this->db->select("SUM(bill_collection_sub_total_amount) as bill_collection_bill_amount, SUM(bill_collection_discount_amount) as bill_collection_discount_amount, SUM(bill_collection_payable_amount) as bill_collection_receivable_amount, SUM(bill_collection_paid_amount) as bill_collection_collection_amount, SUM(bill_collection_due_amount) as bill_collection_due_amount, SUM(bill_collection_patient_rc_amount) as bill_collection_rc_amount, SUM(bill_collection_patient_doctor_charge) as bill_collection_doctor_charge, SUM(bill_collection_patient_others_charge) as bill_collection_others_charge")
		->from('bill_collection') 
		->where('bill_collection_status', 1)
		->where('bill_collection_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
		->order_by('bill_collection_id', 'ASC')
		->get()
		->result();
		foreach($bill_collection_sum as $bill_collection_row){  
			
			$deposit = $this->db->select("SUM(admission_deposit_amount) as deposit_amount")
			->from('admission_deposit')  
			->where('admission_deposit_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
			->where('admission_deposit_status', 1)  
			->order_by('admission_deposit_id', 'ASC') 
			->get()
			->result();
			foreach($deposit as $deposit_row)
			{
				$admission_deposit_amount = $deposit_row->deposit_amount;
			}
			
			$doctor_charge = $this->db->select("SUM(admission_doctor_charge_doctor) as admission_doctor_charge, SUM(admission_doctor_charge_others) as admission_others_charge")
			->from('admission_doctor_charge')  
			->where('admission_doctor_charge_date BETWEEN "'.$from_date.'" and "'.$to_date.'"')
			->where('admission_doctor_charge_status', 1)  
			->order_by('admission_doctor_charge_id', 'ASC') 
			->get()
			->result();
			foreach($doctor_charge as $doctor_charge_row)
			{
				$a_doctor_charge = $doctor_charge_row->admission_doctor_charge;
				$a_others_charge = $doctor_charge_row->admission_others_charge;
			}
			
			$bill_collection_bill_amount		= $bill_collection_row->bill_collection_bill_amount;
			$bill_collection_discount_amount	= $bill_collection_row->bill_collection_discount_amount;
			$bill_collection_deposit_amount		= $admission_deposit_amount; 
			$bill_collection_receivable_amount	= $bill_collection_row->bill_collection_receivable_amount; 
			$bill_collection_collection_amount	= $bill_collection_row->bill_collection_collection_amount; 
			$bill_collection_due_amount			= $bill_collection_receivable_amount-$bill_collection_collection_amount;
			$bill_collection_rc_amount			= $bill_collection_row->bill_collection_rc_amount;
			$bill_collection_doctor_charge		= $a_doctor_charge;
			$bill_collection_others_charge		= $a_others_charge;
			$bill_collection_balance_amount		= $bill_collection_collection_amount-($bill_collection_rc_amount+$bill_collection_doctor_charge+$bill_collection_others_charge); 
		}
		?>
		<tr>
			<td class="text-center">01</td>
			<td class="text-center" rowspan="2">OPD</td> 
			<td class="text-left">Appointment</td>  
			<td class="text-right"><?= number_format($appointment_collection_amount,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("appointment/appointment_collection_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>  
			<td class="text-right"><?= number_format($appointment_rc_amount,2 . '');?></td>
			<td class="text-right"><?= number_format($appointment_doctor_charge,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("appointment/doctor_charge_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($appointment_others_charge,2 . '');?></td>
			<td class="text-right"><?= number_format($appointment_balance_amount,2 . '');?></td>
		</tr> 
		
		<tr>
			<td class="text-center">02</td>
			<td class="text-left">Investigation</td> 
			  
			<td class="text-right"><?= number_format($investigation_collection_amount,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("investigation/investigation_collection_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td> 
			<td class="text-right"><?= number_format($investigation_rc_amount,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("reference/reference_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($investigation_doctor_charge,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("investigation/doctor_charge_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($investigation_others_charge,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("investigation/others_charge_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($investigation_balance_amount,2 . '');?></td>
		</tr>   
		
		<?php 
		$opd_bill_amount  		= $appointment_bill_amount + $investigation_bill_amount;
		$opd_discount_amount	= $appointment_discount_amount + $investigation_discount_amount;
		$opd_deposit_amount		= $appointment_deposit_amount + $investigation_deposit_amount;
		$opd_receivable_amount	= $appointment_receivable_amount + $investigation_receivable_amount;
		$opd_collection_amount	= $appointment_collection_amount + $investigation_collection_amount;
		$opd_due_amount			= $appointment_due_amount + $investigation_due_amount;
		$opd_rc_amount			= $appointment_rc_amount + $investigation_rc_amount;
		$opd_doctor_charge		= $appointment_doctor_charge + $investigation_doctor_charge;
		$opd_others_charge		= $appointment_others_charge + $investigation_others_charge;
		$opd_balance_amount		= $appointment_balance_amount + $investigation_balance_amount;
		?>
		<tr class="text-right"> 
			<th class="text-right" colspan="3">Sub Total</th> 
			<th class="text-right"><?= number_format($opd_collection_amount,2 . '');?></th> 
			<th class="text-right"><?= number_format($opd_rc_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($opd_doctor_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($opd_others_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($opd_balance_amount,2 . '');?></th>
		</tr>  
		<tr>
			<td class="text-center">03</td>
			<td class="text-center" rowspan="3">IPD</td> 
			<td class="text-left">Admission Fee</td>  
			<td class="text-right"><?= number_format($admission_collection_amount,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("admission/admission_fee_collection_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>  
			<td class="text-right"><?= number_format($admission_rc_amount,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_doctor_charge,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_others_charge,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_balance_amount,2 . '');?></td>
		</tr> 
		 
		<tr>
			<td class="text-center">04</td>
			<td class="text-left">Admission Deposit</td>  
			<td class="text-right"><?= number_format($admission_deposit_collection_amount,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("admission/admission_deposit_collection_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>  
			<td class="text-right"><?= number_format($admission_deposit_rc_amount,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_deposit_doctor_charge,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_deposit_others_charge,2 . '');?></td>
			<td class="text-right"><?= number_format($admission_deposit_balance_amount,2 . '');?></td>
		</tr> 
		 
		<tr>
			<td class="text-center">05</td>
			<td class="text-left">IPD Bill Collection</td>   
			<td class="text-right"><?= number_format($bill_collection_collection_amount,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("admission/bill_collection_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>  
			<td class="text-right"><?= number_format($bill_collection_rc_amount,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("admission/bill_collection_rc_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($bill_collection_doctor_charge,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("admission/bill_collection_doctor_charge_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($bill_collection_others_charge,2 . '');?>
				<a class="btn-outline-warning bg-success rounded-pill d-print-none" href="javascript:void(0);" title="<?= $this->lang->line('view');?>" onclick="window.open('<?= base_url("admission/bill_collection_others_charge_transection/?from_date=$from_date&to_date=$to_date");?>','print_popup','width=800,height=700')"><i class=" fa fa-eye"></i></a>
			</td>
			<td class="text-right"><?= number_format($bill_collection_balance_amount,2 . '');?></td>
		</tr>  
		
		<?php 
		$ipd_bill_amount  		= $admission_bill_amount + $admission_deposit_bill_amount + $bill_collection_bill_amount;
		$ipd_discount_amount	= $admission_discount_amount + $admission_deposit_discount_amount + $bill_collection_discount_amount;
		$ipd_deposit_amount		= $admission_deposit_deposit_amount + $bill_collection_deposit_amount;
		$ipd_receivable_amount	= $admission_receivable_amount + $admission_deposit_receivable_amount + $bill_collection_receivable_amount;
		$ipd_collection_amount	= $admission_collection_amount + $admission_deposit_collection_amount + $bill_collection_collection_amount;
		$ipd_due_amount			= $admission_due_amount + $admission_deposit_due_amount + $bill_collection_due_amount;
		$ipd_rc_amount			= $admission_rc_amount + $admission_deposit_rc_amount + $bill_collection_rc_amount;
		$ipd_doctor_charge		= $admission_doctor_charge + $admission_deposit_doctor_charge + $bill_collection_doctor_charge;
		$ipd_others_charge		= $admission_others_charge + $admission_deposit_others_charge + $bill_collection_others_charge;
		$ipd_balance_amount		= $admission_balance_amount + $admission_deposit_balance_amount + $bill_collection_balance_amount;
		?>
		<tr class="text-right"> 
			<th class="text-right" colspan="3">Sub Total</th> 
			<th class="text-right"><?= number_format($ipd_collection_amount,2 . '');?></th> 
			<th class="text-right"><?= number_format($ipd_rc_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($ipd_doctor_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($ipd_others_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($ipd_balance_amount,2 . '');?></th>
		</tr>  
		
		<?php 
		$bill_amount  		= $opd_bill_amount + $ipd_bill_amount;
		$discount_amount	= $opd_discount_amount + $ipd_discount_amount;
		$deposit_amount		= $opd_deposit_amount + $ipd_deposit_amount;
		$receivable_amount	= $opd_receivable_amount + $ipd_receivable_amount;
		$collection_amount	= $opd_collection_amount + $ipd_collection_amount;
		$due_amount			= $opd_due_amount + $ipd_due_amount;
		$rc_amount			= $opd_rc_amount + $ipd_rc_amount;
		$doctor_charge		= $opd_doctor_charge + $ipd_doctor_charge;
		$others_charge		= $opd_others_charge + $ipd_others_charge;
		$balance_amount		= $opd_balance_amount + $ipd_balance_amount;
		?> 
		<tr class="text-uppercase"> 
			<th class="text-right" colspan="3">Grand Total</th>
			<th class="text-right"><?= number_format($collection_amount,2 . '');?></th> 
			<th class="text-right"><?= number_format($rc_amount,2 . '');?></th>
			<th class="text-right"><?= number_format($doctor_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($others_charge,2 . '');?></th>
			<th class="text-right"><?= number_format($balance_amount,2 . '');?></th>
		</tr>  
		
		<tr class="text-uppercase">
			<th class="text-left" colspan="8">
			<?= $this->lang->line('in_word');?>: 
			<?php 
			$number 		= abs($balance_amount);
			$in_word_amount = $this->number_to_word_convert->convert_number($number);
			?>
			<?= $in_word_amount;?> <?= $this->lang->line('currency_only');?>.
			</th>
		</tr>
		
		<tr class="text-uppercase"> 
			<th class="text-right" colspan="7"> OPD Income</th>
			<th class="text-right"><?= number_format($opd_collection_amount,2 . '');?></th>
		</tr>  
		
		<tr class="text-uppercase"> 
			<th class="text-right" colspan="7"> IPD Income</th>
			<th class="text-right"><?= number_format($ipd_collection_amount,2 . '');?></th>
		</tr>  
		 
		
		<tr class="text-uppercase"> 
			<th class="text-right" colspan="7"> Total Income</th>
			<th class="text-right"><?= number_format($opd_collection_amount+$ipd_collection_amount,2 . '');?></th>
		</tr> 
		<?php $user_group 			= $this->session->userdata('user_group');
		if ($user_group == 1 || $user_group == 2 || $user_group == 3 || $user_group == 6)
		{?> 
		<?php $requisition_authorized = $this->db->select("SUM(requisition_approved_amount) as requisition_authorized_amount")
			->from('requisition')  
			->where('requisition_date BETWEEN "'.$from_date.'" and "'.$to_date.'"') 
			->order_by('requisition_id', 'ASC') 
			->get()
			->result();
			foreach($requisition_authorized as $requisition_authorized_row)
			{
				$requisition_authorized_amount = $requisition_authorized_row->requisition_authorized_amount;
			}
		?>
		<tr class="text-uppercase">
			<th class="text-right" colspan="7"><?= $this->lang->line('requisition');?> <?= $this->lang->line('authorize');?></th>
			<th class="text-right"><?= number_format($requisition_authorized_amount,2 . '');?></th>
		</tr> 
		<tr class="text-uppercase"> 
			<th class="text-right" colspan="8">&nbsp;</th>
		</tr>  
		
		<tr class="text-uppercase"> 
			<th class="text-center" colspan="6">&nbsp;</th>
			<th class="text-center" colspan="2">Accounts Section</th>
		</tr>  
		
		<tr class="text-uppercase"> 
			<th class="text-center" colspan="6">&nbsp;</th>
			<th class="text-center">Debit</th>
			<th class="text-center">Credit</th>
		</tr> 
		
		<tr class="text-uppercase">   
			<th class="text-right" colspan="6">
			120111 - Cash (OPD)
			</th> 
			<th class="text-right" colspan="">
				<input type="hidden" class="text-right" name="accounts_details_project[]" value="2"readonly>
				<input type="hidden" class="text-right" name="accounts_details_accounts_type[]" value="100000"readonly>
				<input type="hidden" class="text-right" name="accounts_details_accounts_category[]" value="2"readonly>
				<input type="hidden" class="text-right" name="accounts_details_control_group[]" value="65"readonly>
				<input type="hidden" class="text-right" name="accounts_details_general_ledger[]" value="77"readonly>
				<input type="hidden" class="text-right" name="accounts_details_subsidiary_ledger[]" value="78"readonly>
				<input type="text" class="text-right" name="accounts_details_debit[]" value="<?= number_format($opd_collection_amount,2, '.', '');?>"readonly>
				<input type="hidden" class="text-right" name="accounts_details_credit[]" value="0"readonly>
			</th> 
			<th class="text-right" colspan="">
				
			</th> 
		</tr>    
		
		<tr class="text-uppercase">   
			<th class="text-right" colspan="6"> 
			310111 - Patient Consultancy<br/>
			310112 - Investigation Income
			</th> 
			<th class="text-right" colspan="">
				
			</th> 
			
			<th class="text-right"> 
				<input type="hidden" class="text-right" name="accounts_details_project[]" value="2"readonly>
				<input type="hidden" class="text-right" name="accounts_details_project[]" value="2"readonly>
				<input type="hidden" class="text-right" name="accounts_details_accounts_type[]" value="300000"readonly>
				<input type="hidden" class="text-right" name="accounts_details_accounts_type[]" value="300000"readonly>
				<input type="hidden" class="text-right" name="accounts_details_accounts_category[]" value="86"readonly>
				<input type="hidden" class="text-right" name="accounts_details_accounts_category[]" value="86"readonly>
				<input type="hidden" class="text-right" name="accounts_details_control_group[]" value="87"readonly>
				<input type="hidden" class="text-right" name="accounts_details_control_group[]" value="87"readonly>
				<input type="hidden" class="text-right" name="accounts_details_general_ledger[]" value="88"readonly>
				<input type="hidden" class="text-right" name="accounts_details_general_ledger[]" value="88"readonly>
				<input type="hidden" class="text-right" name="accounts_details_subsidiary_ledger[]" value="89"readonly>
				<input type="hidden" class="text-right" name="accounts_details_subsidiary_ledger[]" value="90"readonly>
				<input type="hidden" class="text-right" name="accounts_details_debit[]" value="0"readonly>
				<input type="hidden" class="text-right" name="accounts_details_debit[]" value="0"readonly>
				<input type="text" class="text-right" name="accounts_details_credit[]" value="<?= number_format($appointment_collection_amount,2, '.', '');?>"readonly><br/>
				<input type="text" class="text-right" name="accounts_details_credit[]" value="<?= number_format($investigation_collection_amount,2, '.', '');?>"readonly>
			</th> 
		</tr>  
		
		<tr class="text-uppercase">   
			<th class="text-right" colspan="6">
			120111 - Cash (IPD)
			</th> 
			<th class="text-right" colspan="">
				<input type="hidden" class="text-right" name="accounts_details_project[]" value="1"readonly>
				<input type="hidden" class="text-right" name="accounts_details_accounts_type[]" value="100000"readonly>
				<input type="hidden" class="text-right" name="accounts_details_accounts_category[]" value="2"readonly>
				<input type="hidden" class="text-right" name="accounts_details_control_group[]" value="65"readonly>
				<input type="hidden" class="text-right" name="accounts_details_general_ledger[]" value="77"readonly>
				<input type="hidden" class="text-right" name="accounts_details_subsidiary_ledger[]" value="78"readonly>
				<input type="text" class="text-right" name="accounts_details_debit[]" value="<?= number_format($ipd_collection_amount,2, '.', '');?>"readonly>
				<input type="hidden" class="text-right" name="accounts_details_credit[]" value="0"readonly>
			</th> 
			<th class="text-right" colspan="">
				
			</th> 
		</tr>    
		
		<tr class="text-uppercase">   
			<th class="text-right" colspan="6"> 
			310121 - Admission Fee<br/>
			310124 - Admission Deposit<br/>
			310122 - Patient Discharge
			</th> 
			<th class="text-right" colspan="">
				
			</th> 
			
			<th class="text-right"> 
				<input type="hidden" class="text-right" name="accounts_details_project[]" value="1"readonly>
				<input type="hidden" class="text-right" name="accounts_details_project[]" value="1"readonly>
				<input type="hidden" class="text-right" name="accounts_details_project[]" value="1"readonly>
				<input type="hidden" class="text-right" name="accounts_details_accounts_type[]" value="300000"readonly>
				<input type="hidden" class="text-right" name="accounts_details_accounts_type[]" value="300000"readonly>
				<input type="hidden" class="text-right" name="accounts_details_accounts_type[]" value="300000"readonly>
				<input type="hidden" class="text-right" name="accounts_details_accounts_category[]" value="86"readonly>
				<input type="hidden" class="text-right" name="accounts_details_accounts_category[]" value="86"readonly>
				<input type="hidden" class="text-right" name="accounts_details_accounts_category[]" value="86"readonly>
				<input type="hidden" class="text-right" name="accounts_details_control_group[]" value="87"readonly>
				<input type="hidden" class="text-right" name="accounts_details_control_group[]" value="87"readonly>
				<input type="hidden" class="text-right" name="accounts_details_control_group[]" value="87"readonly>
				<input type="hidden" class="text-right" name="accounts_details_general_ledger[]" value="91"readonly>
				<input type="hidden" class="text-right" name="accounts_details_general_ledger[]" value="91"readonly>
				<input type="hidden" class="text-right" name="accounts_details_general_ledger[]" value="91"readonly>
				<input type="hidden" class="text-right" name="accounts_details_subsidiary_ledger[]" value="92"readonly>
				<input type="hidden" class="text-right" name="accounts_details_subsidiary_ledger[]" value="209"readonly>
				<input type="hidden" class="text-right" name="accounts_details_subsidiary_ledger[]" value="93"readonly>
				
				<input type="hidden" class="text-right" name="accounts_details_debit[]" value="0"readonly>
				<input type="hidden" class="text-right" name="accounts_details_debit[]" value="0"readonly>
				<input type="hidden" class="text-right" name="accounts_details_debit[]" value="0"readonly>
			<input type="text" class="text-right" name="accounts_details_credit[]" value="<?= number_format($admission_collection_amount,2, '.', '');?>"readonly><br/>
			<input type="text" class="text-right" name="accounts_details_credit[]" value="<?= number_format($admission_deposit_collection_amount,2, '.', '');?>"readonly><br/>
			<input type="text" class="text-right" name="accounts_details_credit[]" value="<?= number_format($bill_collection_collection_amount,2, '.', '');?>"readonly>
			</th> 
		</tr>   
		
		<tr class="text-uppercase">   
			<th class="text-right" colspan="6">
			Total Amount
			</th> 
			<th class="text-right" colspan="">
				<input type="text" class="text-right text-bold" name="accounts_total_debit" value="<?= number_format($collection_amount,2, '.', '');?>"readonly>
			</th> 
			<th class="text-right" colspan="">
				<input type="hidden" class="text-center" name="count" value="7">
				<input type="text" class="text-right text-bold" name="accounts_total_credit" value="<?= number_format($collection_amount,2, '.', '');?>"readonly>
				<input type="hidden" class="text-right text-bold" name="posting_date" value="<?= $to_date;?>"readonly>
			</th> 
		</tr>  
		
		<tr class="text-uppercase"> 
			<th class="text-center" colspan="6">&nbsp;</th>
			<th class="text-center" colspan="2"><button type="submit" class="btn btn-brand btn-success text-uppercase btn-block"onclick="return confirm('<?= $this->lang->line("model_create_warning");?>')">Authorize</button></th>
		</tr>  
		<?php }?>
		<?php return $output;
	} 
}