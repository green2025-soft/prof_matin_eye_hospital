<?php

defined('BASEPATH') or exit('No direct script access allowed');

class PrescriptionTemplate_model extends MY_Model
{

    protected $table = 'prescription_template';
    protected $primaryKey = 'record_id'; 

    public function __construct()
    {
        parent::__construct();
      
    }


    

}
