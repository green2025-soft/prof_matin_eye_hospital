<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller {

    // Common data that you can share across different controllers
    protected $data = [];

    // Base URL for redirection or form actions
    protected $bUrl = '';

    // Common model instance that can be loaded dynamically
    protected $model;

    protected $title;

    protected $isLogin = true;
    protected $isAdminStaff = true;
    protected $isAdmin = false;

    // Session user data cached
    protected $userData = [];

    public function __construct() {
        parent::__construct();

        // Cache user data
        $this->userData = $this->session->userdata();

        if ($this->isLogin) {
            $this->isLogin();
        }

        if ($this->isAdminStaff) {
            $this->isAdminStaff();
        }
    }

    /**
     * Load common layout with dynamic content.
     * 
     * @param string $pageName The view name for the content page
     */
    protected function render($pageName) {
        $this->setTitle(); // Set default title if not already set

        if (!isset($this->data['bUrl'])) {
            $this->data['bUrl'] = $this->bUrl;
        }

        $this->load->view('admin/layouts/header', $this->data);
        $this->load->view('admin/' . $pageName, $this->data);
        $this->load->view('admin/layouts/footer');
    }

    /**
     * Set default or custom title for the page
     */
    protected function setTitle($title = '') {
        $this->data['title'] = $title ?: ($this->data['title'] ?? $this->title);
        $this->data['page_title'] = $this->data['title'];
        $this->data['info_header'] = $this->data['title'];
    }

    /**
     * Load a model dynamically and assign to $this->model
     */
    protected function loadModel($modelName) {
        $this->load->model($modelName);
        $this->model = $this->$modelName;
    }

    /**
     * Flash message with redirect (Insert / Update / Delete)
     */
    protected function crudAlertMessage($url, $id = null, $isDelete = false) {
        $message = INSERT_MSG;

        if ($id) {
            $message = UPDATE_MSG;
        }

        if ($isDelete) {
            $message = DELETE_MSG;
        }

        $this->setFlashMessage($message, 'success');
        redirect($url, 'refresh');
    }

    /**
     * Generic flash message setter
     */
    protected function setFlashMessage($message, $type = 'success') {
        $this->session->set_flashdata('alertMsg', [
            'type' => $type,
            'text' => $message
        ]);
    }

    /**
     * Check if user is logged in
     */
    protected function isLogin() {
        if (empty($this->userData['ses_record_id'])) {
            redirect('/login', 'refresh');
        }
    }

    /**
     * Check if user is admin/staff
     */
    protected function isAdminStaff() {
        $userRole = $this->userData['ses_user_type'] ?? '';

        if ($this->isAdmin && $userRole !== 'admin') {
            redirect('/login', 'refresh');
        }

        if (!in_array($userRole, ['admin', 'staff'])) {
            redirect('/login', 'refresh');
        }
    }

    /**
     * Redirect if a condition fails
     */
    protected function redirectIfNot($condition, $url = '/login') {
        if (!$condition) {
            redirect($url, 'refresh');
        }
    }

    /**
     * Return JSON response (useful for APIs and AJAX)
     */
    protected function jsonResponse($data = [], $status = 200) {
        $this->output
            ->set_content_type('application/json')
            ->set_status_header($status)
            ->set_output(json_encode($data));
    }

    /**
     * Add CSS or JS dynamically to pass to view
     */
    protected function addAsset($type, $path) {
        if (!isset($this->data[$type])) {
            $this->data[$type] = [];
        }
        $this->data[$type][] = $path;
    }
}
