<?php
class MY_Model extends CI_Model {

    protected $table = '';        // Table name
    protected $primaryKey = 'id'; // Primary key name
    protected $timestamp = true; // Primary key name
    protected $createOrUpdateBy = false;

    public function __construct() {
        parent::__construct();
    }

    // Create a new record
    public function create($data) {
        if ($this->timestamp){
            $data['created_at'] = date('Y-m-d H:i:s');
        }
        if ($this->createOrUpdateBy) {
            $userId = $this->session->userdata('ses_record_id');
            $data['created_by'] = $userId;
        }
        unset($data['update_id']);	
        
        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
    }

    // Get all records
    public function all() {
        return $this->db->get($this->table)->result();
    }

    public function get() {
        return $this->db->get($this->table)->result(); 
    }

    // Get a record by primary key
    public function find($id, $primaryKey=null) {
        if (!$id) return null;
        $primaryKey = $primaryKey ?? $this->primaryKey;
        return $this->db->get_where($this->table, [$primaryKey => $id])->row();
    }

     public function first() {
        return $this->db->get($this->table)->row();
    }

    // Update a record by primary key
    public function update($id, $data, $primaryKey=null) {
        $primaryKey = $primaryKey ?? $this->primaryKey;
        unset($data['update_id']);	
        if ($this->timestamp){
            $data['updated_at'] = date('Y-m-d H:i:s');
        }
        if ($this->createOrUpdateBy) {
            $userId = $this->session->userdata('ses_record_id');
            $data['updated_by'] = $userId;
        }
        $this->db->where($primaryKey, $id);
       
        $this->db->update($this->table, $data);
        return $id;
    }

    public function updateOrInsert($data, $id = null, $primaryKey=null) {
        // If the ID is provided, try to update the record
        if ($id) {
           return $this->update($id, $data, $primaryKey); 
        }else{
        
           return $this->create($data);
        }
    }

    // Delete a record by primary key
    public function delete($id, $primaryKey=null) {
        return $this->db->delete($this->table, [$primaryKey => $id]);
    }


    

public function orderDesc($primaryKey=null){
    $primaryKey = $primaryKey ?? $this->primaryKey;
    $this->orderBy($primaryKey, 'DESC');
    return $this;
}

public function orderBy($field, $direction = "asc") {
     $this->db->order_by($field, $direction);
     return $this;
}

public function select($fields){
    $this->db->select($fields);
    return $this; 
}


public function where($field, $value=''){
    if (is_array($field)) {
        $this->db->where($field);
    }else{
         $this->db->where($field, $value);
    }
    return $this; 
}

public function whereId($field, $value){
    // dd($value);
    if (!empty($value)) {
        $this->db->where_in($field, $value);
    }else{
        $this->db->where('1', 0); 
    }
    return $this; 
}

public function groupBy($field){
    $this->db->group_by()($field);
    return $this; 
}

public function selectSum($field){
    $this->db->select_sum($field);
    return $this; 
}
public function count(){
      return $this->db->count_all($this->table);
}

public function max($field){
    $this->db->select_max($field);
    $query = $this->db->get($this->table);
    $result = $query->row_array();
    return isset($result[$field]) ? (int) $result[$field] : 0;
}
public function leftJoin($relatedTable, $foreignKey, $primaryKey = 'id', $primaryTable = '')
{
    $primaryTable = $primaryTable ?: $this->table;

    if (strpos($relatedTable, ' ') !== false) {
        [$tableName, $alias] = explode(' ', $relatedTable, 2);
        $on = "$primaryTable.$foreignKey = $alias.$primaryKey";
    } else {
        $tableName = $relatedTable;
        $alias = $relatedTable;
        $on = "$primaryTable.$foreignKey = $tableName.$primaryKey";
    }

    $this->db->join("$tableName $alias", $on, 'left');
    return $this;
}



public function rightJoin($relatedTable, $foreignKey, $primaryKey = 'id', $primaryTable='')
{
    $primaryTable = $primaryTable ?: $this->table;

    if (strpos($relatedTable, ' ') !== false) {
        [$tableName, $alias] = explode(' ', $relatedTable, 2);
        $on = "$primaryTable.$foreignKey = $alias.$primaryKey";
    } else {
        $tableName = $relatedTable;
        $alias = $relatedTable;
        $on = "$primaryTable.$foreignKey = $tableName.$primaryKey";
    }
    $this->db->join("$tableName $alias", $on, 'right');

    return $this;
}

public function hasMany(
    &$parents,
    $childTable,
    $foreignKey,
    $localKey = 'id',
    $relationName = 'items',
    $conditions = []
) {
    if (empty($parents)) return;

    $localKeys = array_column($parents, $localKey);

    // 🔐 Prevent SQL Error: Skip if no keys to match
    if (empty($localKeys)) {
        foreach ($parents as &$parent) {
            $parent->$relationName = []; // still attach empty array
        }
        return $parents;
    }

    $this->db->where_in($foreignKey, $localKeys);

    if (!empty($conditions)) {
        foreach ($conditions as $key => $value) {
            $this->db->where($key, $value);
        }
    }

    $children = $this->db->get($childTable)->result();

    // Group children by foreign key
    $grouped = [];
    foreach ($children as $child) {
        $grouped[$child->$foreignKey][] = $child;
    }

    // Attach relation to parents
    foreach ($parents as &$parent) {
        $key = $parent->$localKey;
        $parent->$relationName = $grouped[$key] ?? [];
    }

    return $parents;
}

public function with(&$parents, $childRelationName, $foreignKeyInChild, $joinTable, $joinKey = 'id', $as = null)
{
    if (empty($parents)) return;

    $ids = [];

    // Step 1: Collect all foreign keys from all child items
    foreach ($parents as $parent) {
           
        if (!empty($parent->$childRelationName)) {
            foreach ($parent->$childRelationName as $child) {
               
                if (isset($child->$foreignKeyInChild)) {
                    $ids[] = $child->$foreignKeyInChild;
                }
            }
        }
    }
  
    $ids = array_unique($ids);
    if (empty($ids)) return;

    // Step 2: Fetch all join table data
    $this->db->where_in($joinKey, $ids);
    $records = $this->db->get($joinTable)->result();

    // Step 3: Map by key
    $map = [];
    foreach ($records as $record) {
        $map[$record->$joinKey] = $record;
    }

    if (!$as) {
        $as = rtrim($joinTable, 's'); // e.g. products → product
    }

    // Step 4: Attach join data to each child item
    foreach ($parents as &$parent) {
        if (!empty($parent->$childRelationName)) {
            foreach ($parent->$childRelationName as &$child) {
                $child->$as = $map[$child->$foreignKeyInChild] ?? null;
            }
        }
    }

    return $parents;
}


public function loadRelations(&$parents, array $relations)
{
    foreach ($relations as $relation) {
        
        if (count($relation) === 2 || count($relation) === 3 || count($relation) === 4) {
            $childTable = $relation[0];
            $foreignKey = $relation[1];
            $localKey = $relation[2] ?? 'id';
            $relationName = $relation[3] ?? 'items';

            $this->hasMany($parents, $childTable, $foreignKey, $localKey, $relationName);

        } elseif (count($relation) >= 5) {
            $childRelationName = $relation[0];
            $foreignKeyInChild = $relation[1];
            $joinTable = $relation[2];
            $joinKey = $relation[3];
            $alias = $relation[4];

            $this->with($parents, $childRelationName, $foreignKeyInChild, $joinTable, $joinKey, $alias);
        }
    }

    return $parents;
}


public function belongsTo(&$parents, $foreignKey, $relatedTable, $relatedKey = 'id', $relationName = null)
{
    if (empty($parents)) return;

    // 1. Collect all unique foreign keys
    $foreignIds = [];
    foreach ($parents as $parent) {
        if (isset($parent->$foreignKey)) {
            $foreignIds[] = $parent->$foreignKey;
        }
    }
    $foreignIds = array_unique($foreignIds);

    if (empty($foreignIds)) return;

    // 2. Fetch related records
    $this->db->where_in($relatedKey, $foreignIds);
    $relatedRecords = $this->db->get($relatedTable)->result();

    // 3. Map related records by ID
    $map = [];
    foreach ($relatedRecords as $record) {
        $map[$record->$relatedKey] = $record;
    }

    // 4. Determine relation name
    if (!$relationName) {
        $relationName = rtrim($relatedTable, 's'); // e.g., customers => customer
    }

    // 5. Attach related data to each parent
    foreach ($parents as &$parent) {
        $parent->$relationName = $map[$parent->$foreignKey] ?? null;
    }

    return $parents;
}



public function belongsToSingle(&$parent, $foreignKey, $relatedTable, $relatedKey = 'id', $relationName = null)
{
    if (empty($parent)) return;

    $temp = [$parent];
    $this->belongsTo($temp, $foreignKey, $relatedTable, $relatedKey, $relationName);
    $parent = $temp[0];

    return $parent;
}

public function whereExists(Closure $callback)
{
     $subDb = clone $this->db;
    $callback($subDb);
    $subQuery = $subDb->get_compiled_select();
    $this->db->where("EXISTS ({$subQuery})");
    return $this;

}

public function whereNotExists(Closure $callback)
{
    $subDb = clone $this->db;
    $callback($subDb);
    $subQuery = $subDb->get_compiled_select();
    $this->db->where("NOT EXISTS ({$subQuery})");
    return $this;
}

public function withSingle(&$parents, $childRelationName, $foreignKeyInChild, $joinTable, $joinKey = 'id', $as = null)
{
    if (empty($parents)) return;

    $ids = [];

    foreach ($parents as $parent) {
        if (!empty($parent->$childRelationName) && isset($parent->$childRelationName->$foreignKeyInChild)) {
            $ids[] = $parent->$childRelationName->$foreignKeyInChild;
        }
    }

    $ids = array_unique($ids);
    if (empty($ids)) return;

    // Fetch the join data
    $this->db->where_in($joinKey, $ids);
    $records = $this->db->get($joinTable)->result();

    $map = [];
    foreach ($records as $record) {
        $map[$record->$joinKey] = $record;
    }

    if (!$as) {
        $as = rtrim($joinTable, 's');
    }

    // Attach to each child inside parent
    foreach ($parents as &$parent) {
        if (!empty($parent->$childRelationName) && isset($parent->$childRelationName->$foreignKeyInChild)) {
            $fk = $parent->$childRelationName->$foreignKeyInChild;
            $parent->$childRelationName->$as = $map[$fk] ?? null;
        }
    }

    return $parents;
}


    
    
}
