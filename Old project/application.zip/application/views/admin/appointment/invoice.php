<?php
// dd($value);
$invoice = $this->Common_model->findById('create_bill',array('record_id'=>$value->invoice_id));
$folder_name = 'appointment';
$bill_title = 'CASH MEMO/BILL';
$qr_code_url = 'operation_bill/qrcode_image/' . $value->invoice_id;
$designation = $this->Common_model->findById('designation', array('record_id' => $doctor->designation_id));
$doctor_name = "";
if (isset($doctor)) {
    $doctor_name = $doctor->name;
    if (isset($designation)) {
        $doctor_name .= ' - ' . $designation->designation;
    }
} else {
    $doctor_name = $value->referred_doctor;
}

// $referred_doctor = $doctor_name;
$appointmentDr = $doctor_name;
$in_word_amount = $value->paid;

$delivery_date = $value->delivery_date;
// $delivery_date .= $value->delivery_time?', '.$value->delivery_time:'';
$value->invoice_no = generate_invoice_no($invoice);
$drSerialNo         = $value->serial_no;


$this->load->view('admin/common/invoice_common', get_defined_vars());
?>