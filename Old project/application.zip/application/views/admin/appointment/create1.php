<style>
    input[type=radio] {
        width: 18px;
        height: 18px;
    }
</style>
<aside>
    <section class="content">
        <div class="row">
            <section class="col-xs-12 connectedSortable">
                <div class="box box-info no_print">
                    <div class="box-header">
                        <h3 class="box-title"><?= isset($page_title) ? $page_title : '' ?></h3>
                    </div>
                    <?php echo form_open_multipart('appointment/saveOrUpdate'); ?>
                    <div class="box-body">
                        <div class="row">
                            <div class="form-group  col-sm-3 col-xs-12">
                                <div class="" style="padding-top: 25px;padding-left:20%">
                                    <?php $hospitalChecked = 'checked';
                                    $onlineChecked = '';
                                    if (isset($value)) {
                                        if ($value->serial_id) {
                                            $hospitalChecked = '' ;
                                            $onlineChecked = 'checked' ;
                                        }
                                    }
                                    ?>
                                    <label class="radio-inline1">
                                        <input type="radio" name="invoice_status" value="Created" <?= $hospitalChecked ?>>Direct
                                    </label>
                                    <label class="radio-inline">
                                        <input type="radio" name="invoice_status" value="Not_Created" <?= $onlineChecked ?>>Online/Reception
                                    </label>
                                </div>
                            </div>
                            <div class="form-group col-sm-2">
                                <label for="serial_no">Serial No (<span class="required">*</span>) </label>
                                <input type="text" class="form-control text-right Created" id="serial_no" placeholder="" name="serial_no" value="<?= isset($value) ? $value->prefix . '-' . $value->serial_no : $serial_no ?>" required="" readonly <?php if(isset($value)){if($value->serial_id){?> style="display:none" <?php }} ?>>
                                <?php 
                                $where = array() ;
                                $where['approval'] = 'Approved' ;
                                $select = "--Select--" ;
                                $selected = "" ;
                                if(isset($value)){
                                    if($value->serial_id){
                                        $where['record_id'] = $value->serial_id ;
                                        $select = '' ;
                                        $selected = $value->serial_id ;
                                    }
                                }
                                ?>
                                <select name="serial_id" id="serial_id" class="form-control Not_Created selectpicker1" data-live-search="true1" <?php if(isset($value)){if($value->serial_id){?> style="display:block" <?php }else{ ?> style="display: none!important;" <?php }}else{?> style="display: none!important;" <?php } ?>  >
                                    <?= options(
                                        'appointments',
                                        $where,
                                        array('prefix', 'serial_no'),
                                        'record_id',
                                        '',
                                        'record_id',
                                        'desc',
                                        $select,
                                        $selected,
                                        array('doctor_id', 'patient_id')
                                    )
                                    ?>
                                </select>
                                <input type="hidden" name="update_id" id="update_id" value="<?= isset($value) ? $value->record_id : 0 ?>">
                            </div>
                            <div class="form-group col-sm-2">
                                <label for="date">Visit Date (<span class="required">*</span>) </label>

                                <input type="text" class="form-control new_datepicker" id="date" placeholder="" name="date" value="<?= isset($value) ? $value->date : date('Y-m-d') ?>" required="" autocomplete="off">
                            </div>
                            <div class="form-group col-sm-4 hide">
                                <label for="reference_by">Reference By </label>
                                <div class="input-group">
                                    <select id="reference_by" name="reference_by" class="form-control selectpicker reference_by" data-live-search="true">
                                        <?= options(
                                            'reference_by',
                                            array(),
                                            array('record_id', 'reference_name'),
                                            'record_id',
                                            '',
                                            'record_id',
                                            'desc',
                                            'Select Reference By',
                                            isset($value) ? $value->reference_by : 0
                                        )
                                        ?>
                                    </select>
                                    <span class="input-group-addon">
                                        <button type="button" id="btnReference" style="height: 20px;" class="btn btn-success fa fa-plus-square btn-sm" data-toggle="modal" data-target="#referenceModal">
                                        </button>
                                    </span>
                                </div>
                            </div>
                            <div class="form-group col-sm-5">
                                <label for="department">Doctor Name (<span class="required">*</span>)</label>
                                <div class="input-group">
                                    <select id="doctor_id" name="doctor_id" class="form-control selectpicker" data-live-search="true" required="">
                                        <?= options(
                                            'doctor',
                                            array(),
                                            array('record_id', 'name'),
                                            'record_id',
                                            '',
                                            'record_id',
                                            'asc',
                                            'Select Doctor',
                                            isset($value) ? $value->doctor_id : 0,
                                            array('frees', 'follow_up_fee', 'commission_fee', 'follow_up_commission', 'doctors_time')
                                        )
                                        ?>
                                    </select>
                                    <span class="input-group-addon">
                                        <button type="button" id="d_plus" style="height: 20px;" class="btn btn-success fa fa-plus-square btn-sm" data-toggle="modal" data-target="#doctorModal"></button>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-sm-3">
                                <label for="patient_id">Patient Name (<span class="required">*</span>) </label>
                                <div class="input-group">
                                    <select name="patient_id" id="patient_id" class="form-control selectpicker" data-live-search="true" required="">
                                        <?= options(
                                            'patient',
                                            array(),
                                            array('record_id', 'name'),
                                            'record_id',
                                            '',
                                            'record_id',
                                            'desc',
                                            'Select Patient',
                                            isset($value) ? $value->patient_id : 0,
                                            array('name', 'gender', 'age', 'mobile', 'gender')
                                        )
                                        ?>
                                    </select>

                                    <span class="input-group-addon">
                                        <button type="button" id="c_plus" style="height: 20px;" class="btn btn-success fa fa-plus-square btn-sm" data-toggle="modal" data-target="#patientModal">
                                        </button>
                                    </span>
                                </div>
                            </div>
                            <div class="form-group col-sm-3">
                                <label for="mobile">Mobile No (<span class="required">*</span>) </label>
                                <input type="text" class="form-control" id="mobile" placeholder="" value="<?= isset($patient) ? $patient->mobile : '' ?>" required="" readonly>
                            </div>
                            <div class="form-group col-sm-3">
                                <label for="age">Age (<span class="required">*</span>) </label>
                                <input type="text" class="form-control" id="age" placeholder="" value="<?= isset($patient) ? $patient->age : '' ?>" required readonly>
                            </div>
                            <div class="form-group col-sm-3">
                                <label for="gender">Gender (<span class="required">*</span>) </label>
                                <input type="text" class="form-control" id="sex" placeholder="" value="<?= isset($patient) ? $patient->gender : '' ?>" required readonly>
                            </div>
                        </div>
                        <div class="row">


                            <div class="form-group col-sm-2">
                                <label for="frees" class="lbl-color">Visit Amount </label>
                                <input type="text" class="form-control text-right numeric" id="frees" placeholder="" name="doctor_fee" value="<?= isset($value) ? $value->doctor_fee : '' ?>">
                            </div>
                            <div class="form-group col-sm-2">
                                <label for="payable_amount">Total (<span class="required">*</span>) </label>
                                <input type="text" class="form-control text-right numeric" id="payable_amount" placeholder="" name="amount" value="<?= isset($value) ? $value->doctor_fee : '' ?>" readonly required>
                            </div>


                            <div class="form-group col-sm-2">
                                <label for="discount_percentage">Discount (%) </label>
                                <input type="text" class="form-control text-right numeric" id="discount_percentage" placeholder="" name="discount_percentage" value="<?= isset($value) ? $value->discount_percentage : '' ?>">
                            </div>
                            <div class="form-group col-sm-2">
                                <label for="discount_amount">Discount </label>
                                <input type="text" class="form-control text-right numeric" id="discount_amount" placeholder="" name="discount" value="<?= isset($value) ? $value->discount : '' ?>">
                            </div>
                            <div class="form-group col-sm-2">
                                <label for="sub_total_amount">Sub_Total (<span class="required">*</span>) </label>
                                <input type="text" class="form-control text-right numeric" id="sub_total_amount" placeholder="" name="sub_total" value="<?= isset($value) ? $value->sub_total : '' ?>" readonly required>
                            </div>
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="paid" class="lbl-color">Paid</label>
                                <input type="text" class="form-control text-right numeric" id="paid_amount" placeholder="" name="paid" value="<?= isset($value) ? $value->paid : '' ?>">
                            </div>

                        </div>

                        <div class="row">
                            <div class="form-group col-sm-3">
                                <label for="commission_fee" class="lbl-color">Doctor Payment </label>
                                <input type="text" class="form-control text-right numeric" id="commission_fee" placeholder="" name="doctor_commission" value="<?= isset($value) ? $value->doctor_commission : '' ?>">
                            </div>
                            <div class="form-group col-sm-3 col-xs-12">
                                <label for="due">Due</label>
                                <input type="text" class="form-control text-right numeric" id="due_amount" placeholder="" name="due" value="<?= isset($value) ? $value->due : '' ?>" readonly>


                            </div>
                            <div class="form-group col-sm-3 col-xs-12">
                                <label for="comments">Comments</label>
                                <input type="text" class="form-control" id="comments" placeholder="" name="comments" value="<?= isset($value) ? $value->comments : '' ?>">
                            </div>

                            <div class="form-group col-sm-3 col-xs-12">
                                <label for="appointment_time">Visit Hour </label>
                                <input type="text" name="appointment_time" id="appointment_time" class="form-control">
                            </div>
                            <div class="form-group col-sm-12 col-xs-12 text-center">
                                <div class="box-footer1 clearfix">
                                    <button type="submit" class="btn btn-success" style="margin-top: 25px;">Submit <i class="fa fa-arrow-circle-right"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>

                    </form>
                </div>
            </section>
        </div>
    </section>
</aside>
<script type="text/javascript">
    $(document).on('change', '#patient_id,#doctor_id', function(e) {
        var patient_id = $('#patient_id').val();
        var doctor_id = $('#doctor_id').val();
        var discount_percentage, discount_amount;
        var formURL = "<?= base_url('appointment/get_doctor_fee'); ?>";
        $.ajax({
            url: formURL,
            type: "POST",
            data: {
                patient_id: patient_id,
                doctor_id: doctor_id
            },
            dataType: "json",
            success: function(data) {
                $('#frees').val(data.doctor_fee);
                $('#commission_fee').val(data.commission_fee);
                $('#payable_amount').val(data.doctor_fee);
                discount_percentage = $('#discount_percentage').val();
                discount_percentage = +discount_percentage;
                discount_amount = (data.doctor_fee * discount_percentage) / 100;
                discount_amount = +discount_amount;
                $('#discount_amount').val(discount_amount);
                sub_total_amount = data.doctor_fee - discount_amount;
                $('#sub_total_amount').val(sub_total_amount);
                $('#paid_amount').val(sub_total_amount);
                $('#due_amount').val(0);
            }
        });
        e.preventDefault();
    })

    $(document).on('keyup', '#frees', function(e) {
        var frees, payable_amount, discount_amount = 0,
            sub_total_amount, discount_percentage;
        frees = $('#frees').val();
        frees = +frees;
        payable_amount = frees;

        discount_percentage = $('#discount_percentage').val();
        discount_percentage = +discount_percentage;

        discount_amount = (frees * discount_percentage) / 100;
        $('#discount_amount').val(discount_amount);
        sub_total_amount = frees - discount_amount;;
        $('#payable_amount').val(payable_amount);
        $('#sub_total_amount').val(sub_total_amount);
        $('#paid_amount').val(sub_total_amount);
        $('#due_amount').val(0);
    })

    $(document).on('keyup', '#discount_amount', function(e) {
        var payable_amount = 0,
            discount_amount = 0,
            sub_total_amount = 0,
            discount_percentage = 0;
        payable_amount = $('#payable_amount').val();
        payable_amount = +payable_amount;
        discount_amount = $('#discount_amount').val();
        discount_amount = +discount_amount;
        sub_total_amount = payable_amount - discount_amount;
        $('#sub_total_amount').val(sub_total_amount);
        $('#paid_amount').val(sub_total_amount);
        $('#commission_fee').val(sub_total_amount);
        $('#due_amount').val(0);
        if (payable_amount > 0) {
            discount_percentage = (100 * discount_amount) / payable_amount;
        } else {
            discount_percentage = 0;
        }
        $('#discount_percentage').val(discount_percentage.toFixed(2));

    })

    $(document).on('keyup', '#discount_percentage', function(e) {
        var payable_amount, paid, discount_amount, discount_percentage, sub_total_amount;
        payable_amount = $('#payable_amount').val();
        payable_amount = +payable_amount;
        discount_percentage = $('#discount_percentage').val();
        discount_percentage = +discount_percentage;
        discount_amount = (payable_amount * discount_percentage) / 100;
        $('#discount_amount').val(discount_amount);

        sub_total_amount = payable_amount - discount_amount;
        $('#sub_total_amount').val(sub_total_amount);
        $('#paid_amount').val(sub_total_amount);
        $('#commission_fee').val(sub_total_amount);
        $('#due_amount').val(0);
    })



    $(document).on('keyup', '#doctor_commission', function(e) {
        var payable_amount, discount_amount, sub_total_amount, doctor_commission = 0;
        doctor_commission = $(this).val();
        doctor_commission = +doctor_commission;
        payable_amount = $('#payable_amount').val();
        payable_amount = +payable_amount;
        discount_amount = $('#discount_amount').val();
        discount_amount = +discount_amount;
        sub_total_amount = payable_amount - discount_amount;
        $('#sub_total_amount').val(sub_total_amount);
        $('#paid_amount').val(sub_total_amount);
        $('#due_amount').val(0);
    })
    $(document).on('keyup', '#paid_amount', function(e) {
        $('#commission_fee').val(0);
        var paid_amount, sub_total_amount, due_amount;
        paid_amount = $('#paid_amount').val();
        paid_amount = +paid_amount;
        sub_total_amount = $('#sub_total_amount').val();
        sub_total_amount = +sub_total_amount;
        if (paid_amount > sub_total_amount) {
            alert('Paid amount should be less than or equal to sub total amount');
            $('#paid_amount').val(0);
        }
        due_amount = sub_total_amount - paid_amount;
        $('#due_amount').val(due_amount);
    })
    $(document).on('keyup', '#commission_fee', function(e) {
        var paid_amount, commission_fee;
        paid_amount = $('#paid_amount').val();
        paid_amount = +paid_amount;
        commission_fee = $('#commission_fee').val();
        commission_fee = +commission_fee;
        if (commission_fee > paid_amount) {
            alert('Doctor Pay should be less than or equal to Paid Amount');
            commission_fee = paid_amount;
            $('#commission_fee').val(commission_fee);
        }
    })
    $(document).on('click', 'input[name=invoice_status]', function() {
        var invoice_status = $(this).val();
        if (invoice_status == 'Created') {
            $('.Created').show(1000);
            $('#serial_no').attr('required', 'required');
            $('#serial_id').removeAttr('required');
            $('.Not_Created').hide(1000);
        } else {
            $('.Created').hide(1000);
            $('.Not_Created').show(1000);
            $('#serial_id').attr('required', 'required');
            $('#serial_no').removeAttr('required');
        }
    })
    $(document).on('change', '#serial_id', function() {
        var serial_id, doctor_id, patient_id, option;
        serial_id = $(this).val();
        option = $('#serial_id :selected');
        patient_id = option.data('patient_id');
        doctor_id = option.data('doctor_id');
        $('#patient_id').val(patient_id).selectpicker('refresh');
        $('#doctor_id').val(doctor_id).selectpicker('refresh');
        $('#patient_id').trigger('change');
        $('#doctor_id').trigger('change');
    })
</script>
