<style>
    input[type=radio] {
        width: 18px;
        height: 18px;
    }
    .textRed{
        color: red !important;
    }
</style>
<aside>
    <section class="content">
        <div class="row">
            <section class="col-xs-12 connectedSortable">
                <div class="box box-info no_print">
                    <div class="box-header">
                        <h3 class="box-title"><?= isset($page_title) ? $page_title : '' ?></h3>
                    </div>
                    <?php echo form_open_multipart('appointment/saveOrUpdate'); ?>
                    <div class="box-body">
                        <?php if (!isset($value)):?>
                        <ul class="nav nav-tabs">
                            <li class="active">
                                <a href="#"  class="textRed"><b>Doctor Visit</b></a>
                            </li>
                            <li>
                                <a href="<?= base_url('test_invoice/create') ?>"  class="textRed" ><b>Investigation</b></a>
                            </li>
                            <li>
                                <a href="<?= base_url('operation_bill/create') ?>"  class="textRed"><b>Operation</b></a>
                            </li>
                        </ul>
                        <br>
                        <?php endif?>
                        <div class="row">
                            <input type="hidden" name="invoice_status" value="Not_Created">
                            

                            <div class="form-group col-sm-3">
                                <label for="department">Doctor Name (<span class="required">*</span>)</label>
                                <select id="doctor_id" name="doctor_id" class="form-control selectpicker" data-live-search="true" required="">
                                <?php if (isset($value)) { ?>
                                <option value="<?php echo $doctor->record_id; ?>"><?php echo $doctor->record_id.'-'.$doctor->name; ?></option>
                                <?php }else{ ?>
                                <!-- <option value="">Select Doctor</option> -->
                               
                                        <?= options(
                                            'doctor',
                                            array(),
                                            array('record_id', 'name'),
                                            'record_id',
                                            '',
                                            'record_id',
                                            'asc',
                                            'Select Doctor',
                                            isset($value) ? $value->doctor_id : 0,
                                            array('frees', 'follow_up_fee', 'commission_fee', 'follow_up_commission', 'doctors_time')
                                        )
                                        ?>
                                         <?php } ?>
                                    </select>
                                <!-- <div class="input-group">
                                    <select id="doctor_id" name="doctor_id" class="form-control selectpicker" data-live-search="true" required="">
                                        <?= options(
                                            'doctor',
                                            array(),
                                            array('record_id', 'name'),
                                            'record_id',
                                            '',
                                            'record_id',
                                            'asc',
                                            'Select Doctor',
                                            isset($value) ? $value->doctor_id : 0,
                                            array('frees', 'follow_up_fee', 'commission_fee', 'follow_up_commission', 'doctors_time')
                                        )
                                        ?>
                                    </select>
                                    <span class="input-group-addon">
                                        <button type="button" id="d_plus" style="height: 20px;" class="btn btn-success fa fa-plus-square btn-sm" data-toggle="modal" data-target="#doctorModal"></button>
                                    </span>
                                </div> -->
                            </div>


                            <div class="form-group col-sm-2">
                                <label for="serial_id">Serial No (<span class="required">*</span>) </label>
                                <div class="input-group">
                                <select name="serial_id" id="serial_id" class="form-control selectpicker" data-live-search="true1"  required>
                                <?php if (isset($value)) { ?>
                                <option value="<?php echo $value->record_id; ?>"><?php echo $value->serial_no.'-'.$patient->name; ?></option>
                                <?php }else{ ?>
                                <option value="">Select Serial No.</option>
                                <?php } ?>

                                </select>

                                
                                <input type="text" name="serial_no" id="serial_no" class="form-control" style="display: none;" placeholder="New Serial" readonly>
                                <input type="hidden" name="update_id" id="update_id" value="<?= isset($value) ? $value->record_id : 0 ?>">
                                <span class="input-group-addon">
                                            <button type="button" id="c_plus" style="height: 20px;" class="btn btn-success fa fa-plus-square btn-sm">
                                            </button>
                                        </span>
                                </div>
                            </div>
                           
                            <div class="form-group col-sm-3 col-xs-12">
                                <label for="patient_id">Patient Name (<span class="required">*</span>) </label>
                                <div class="<?= !isset($value)?'input-group':'' ?>">
                                    <select name="patient_id" id="patient_id" class="form-control selectpicker" data-live-search="true" required="">
                                        <?php $patients = $this->Common_model->findAll('patient', [], 'record_id', 'desc');?>
                                        <option value="">Select Patient</option>
                                        <?php  foreach ($patients as $patientInfo):
                                        if(isset($value) && $value->patient_id !=$patientInfo->record_id)  continue;
                                        $patientAge = calculateCurrentAge($patientInfo);
                                            ?>
                                        <option value="<?= $patientInfo->record_id ?>" <?= isset($value) && $value->patient_id== $patientInfo->record_id ? 'selected' : ''  ?> data-mobile="<?= $patientInfo->mobile ?>"  data-name="<?= $patientInfo->name ?>" data-gender="<?= $patientInfo->gender ?>" data-age="<?= $patientAge ?>" data-address="<?= $patientInfo->address ?>" ><?= $patientInfo->record_id ?>-<?= $patientInfo->name ?><?= ($patientInfo->mobile)?'-'.$patientInfo->mobile:'' ?></option>
                                        <?php endforeach?>
                                    </select>
                                    <?php if(!isset($value) ):?>
                                    <span class="input-group-addon">
                                        <button type="button" id="c_plus" style="height: 20px;" class="btn btn-success fa fa-plus-square btn-sm" data-toggle="modal" data-target="#patientModal">
                                        </button>
                                    </span>
                                    <?php endif?>
                                </div>
                            </div>
                             <div class="form-group col-sm-2">
                                <label for="date">Visit Date (<span class="required">*</span>) </label>
                                <input type="text" class="form-control new_datepicker" id="date" placeholder="" name="date" value="<?= isset($value) ? $value->date : date('Y-m-d') ?>" required="" autocomplete="off">
                            </div>
                            <div class="form-group col-sm-2 col-xs-12">
                                <label >Visit Type (<span class="required">*</span>)</label> <br>
                                <label class="radio-inline">
                                        <input type="radio" name="appointment_type" onclick="return false;" value="New" <?php if (isset($value)) {
                                            if ($value->appointment_type == "New") {
                                                echo 'checked' ;
                                            } 
                                        }else{ echo 'checked' ;}?> required>New
                                        </label>
                                        <label class="radio-inline">
                                            <input type="radio" name="appointment_type" onclick="return false;" value="Follow-Up" <?php if (isset($value)) {
                                            if ($value->appointment_type == "Follow-Up") {
                                                echo 'checked' ;
                                            } 
                                        }?>>Follow-Up
                                        </label>
                                    </div>

                            </div>


                            
                        <div class="row">
                        
                            
                                    
                            <div class="form-group col-sm-2">
                                <label for="mobile">Mobile No (<span class="required">*</span>) </label>
                                <input type="text" class="form-control" id="mobile" placeholder="" value="<?= isset($patient) ? $patient->mobile : '' ?>" required="" readonly>
                            </div>
                            <div class="form-group col-sm-2">
                                <label for="age">Age (<span class="required">*</span>) </label>
                                <input type="text" class="form-control" id="age" placeholder="" value="<?= isset($patient) ? $patient->age : '' ?>" required readonly>
                            </div>
                            <div class="form-group col-sm-2">
                                <label for="gender">Gender (<span class="required">*</span>) </label>
                                <input type="text" class="form-control" id="sex" placeholder="" value="<?= isset($patient) ? $patient->gender : '' ?>" required readonly>
                            </div>
                      


                            <div class="form-group col-sm-2">
                                <label for="frees" class="lbl-color">Visit Amount </label>
                                <input type="text" class="form-control text-right numeric" id="frees" placeholder="" name="doctor_fee" value="<?= isset($value) ? $value->doctor_fee : '' ?>">
                            </div>
                            <div class="form-group col-sm-2">
                                <label for="payable_amount">Total (<span class="required">*</span>) </label>
                                <input type="text" class="form-control text-right numeric" id="payable_amount" placeholder="" name="amount" value="<?= isset($value) ? $value->doctor_fee : '' ?>" readonly required>
                            </div>

                            
                            <div class="form-group col-sm-2">
                                <label for="discount_percentage">Discount (%) </label>
                                <input type="text" class="form-control text-right numeric" id="discount_percentage" placeholder="" name="discount_percentage" value="<?= isset($value) ? $value->discount_percentage : '' ?>">
                            </div>
                            <div class="clearfix"></div>
                            <div class="form-group col-sm-2">
                                <label for="discount_amount">Discount </label>
                                <input type="text" class="form-control text-right numeric" id="discount_amount" placeholder="" name="discount" value="<?= isset($value) ? $value->discount : '' ?>">
                            </div>
                            <div class="form-group col-sm-2">
                                <label for="sub_total_amount">Sub_Total (<span class="required">*</span>) </label>
                                <input type="text" class="form-control text-right numeric" id="sub_total_amount" placeholder="" name="sub_total" value="<?= isset($value) ? $value->sub_total : '' ?>" readonly required>
                            </div>
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="paid" class="lbl-color">Paid</label>
                                <input type="text" class="form-control text-right numeric" id="paid_amount" placeholder="" name="paid" value="<?= isset($value) ? $value->paid : '' ?>">
                            </div>

                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="due">Due</label>
                                <input type="text" class="form-control text-right numeric" id="due_amount" placeholder="" name="due" value="<?= isset($value) ? $value->due : '' ?>" readonly>
                            </div>
                    
                            <div class="form-group col-sm-2">
                                <label for="commission_fee" class="lbl-color">Doctor Payment </label>
                                <input type="text" class="form-control text-right numeric" id="commission_fee" placeholder="" name="doctor_commission" value="<?= isset($value) ? $value->doctor_commission : '' ?>">
                            </div>
                            
                             
                             <div class="form-group col-sm-2 col-xs-12">
                                <label for="appointment_time">Visit Hour </label>
                                <input type="text" name="appointment_time" id="appointment_time" class="form-control">
                            </div>
                            <div class="clearfix"></div>
                            <div class="form-group col-sm-3 col-xs-12">
                                <label for="comments">Remarks</label>
                                <input type="text" class="form-control" id="comments" placeholder="" name="comments" value="<?= isset($value) ? $value->comments : '' ?>">
                            </div>

                            
                            <div class="form-group col-sm-2 col-xs-12">
                                        <label for="discount_type">Ref. By</label>
                                        <select id="reference_by" name="reference_by" class="form-control selectpicker reference_by" data-live-search="true">
                                            <!-- <option value="0" data-xray='0' data-echo_cardiogram='0' data-endoscopy='0' data-commission='0'>--Select--</option> -->
                                            <?= options(
                                            'reference_by',
                                            array(),
                                            array('record_id', 'reference_name'),
                                            'record_id',
                                            '',
                                            'record_id',
                                            'desc',
                                            'Select Reference',
                                            isset($value) ? $value->reference_by : 0
                                            //array()
                                        )
                                        ?>
                                        </select>
                                    </div>
                                    <div class="form-group col-sm-3 col-xs-12 hide" >
                                        <label style="margin-top: 25px;" id="marketing"></label>
                                        <input type="hidden" value="<?=isset($value) ? $value->marketing_staff : 0 ?>" name="marketing_staff" id="marketing_staff" >
                                    </div>
                            <div class="form-group col-sm-12 col-xs-12 text-center">
                                <div class="box-footer1 clearfix">
                                    <button type="submit" class="btn btn-success" style="margin-top: 25px;">Submit <i class="fa fa-arrow-circle-right"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>

                    </form>
                </div>
            </section>
        </div>
    </section>
</aside>
<script type="text/javascript">
    // $(document).on('change', '#patient_id,#doctor_id', function(e) {
    //     var patient_id = $('#patient_id').val();
    //     var doctor_id = $('#doctor_id').val();
    //     var discount_percentage, discount_amount;
    //     var formURL = "<?= base_url('appointment/get_doctor_fee'); ?>";
    //     $.ajax({
    //         url: formURL,
    //         type: "POST",
    //         data: {
    //             patient_id: patient_id,
    //             doctor_id: doctor_id
    //         },
    //         dataType: "json",
    //         success: function(data) {
    //             $('#frees').val(data.doctor_fee);
    //             $('#commission_fee').val(data.commission_fee);
    //             $('#payable_amount').val(data.doctor_fee);
    //             discount_percentage = $('#discount_percentage').val();
    //             discount_percentage = +discount_percentage;
    //             discount_amount = (data.doctor_fee * discount_percentage) / 100;
    //             discount_amount = +discount_amount;
    //             $('#discount_amount').val(discount_amount);
    //             sub_total_amount = data.doctor_fee - discount_amount;
    //             $('#sub_total_amount').val(sub_total_amount);
    //             $('#paid_amount').val(sub_total_amount);
    //             $('#due_amount').val(0);
    //         }
    //     });
    //     e.preventDefault();
    // })

    

    // $(document).on('change', '#doctor_id', function(e) {
    //     var doctor_id = $('#doctor_id').val();
    //     var discount_percentage, discount_amount;
    //     var visitType = $('input[name="appointment_type"]:checked').val();

    //         option = $('#doctor_id :selected');
    //         if (visitType == 'New') {
    //             charge = option.data('frees');
    //             comission = option.data('commission_fee');
    //         }
    //         else if (visitType == 'Follow-Up') {
    //             charge = option.data('follow_up_fee');
    //             comission = option.data('follow_up_commission');

    //         }


    //             $('#frees').val(charge);
    //             $('#commission_fee').val(comission);
    //             $('#payable_amount').val(charge);
    //             discount_percentage = $('#discount_percentage').val();
    //             discount_percentage = +discount_percentage;
    //             discount_amount = (charge * discount_percentage) / 100;
    //             discount_amount = +discount_amount;
    //             $('#discount_amount').val(discount_amount);
    //             sub_total_amount = charge - discount_amount;
    //             $('#sub_total_amount').val(sub_total_amount);
    //             $('#paid_amount').val(sub_total_amount);
    //             $('#due_amount').val(0);

     
    //     e.preventDefault();
    // })

    $(document).on('keyup', '#frees', function(e) {
        var frees, payable_amount, discount_amount = 0,
            sub_total_amount, discount_percentage;
        frees = $('#frees').val();
        frees = +frees;
        payable_amount = frees;

        discount_percentage = $('#discount_percentage').val();
        discount_percentage = +discount_percentage;

        discount_amount = (frees * discount_percentage) / 100;
        $('#discount_amount').val(discount_amount);
        sub_total_amount = frees - discount_amount;;
        $('#payable_amount').val(payable_amount);
        $('#sub_total_amount').val(sub_total_amount);
        $('#paid_amount').val(sub_total_amount);
        $('#due_amount').val(0);
    })

    $(document).on('keyup', '#discount_amount', function(e) {
        var payable_amount = 0,
            discount_amount = 0,
            sub_total_amount = 0,
            discount_percentage = 0;
        payable_amount = $('#payable_amount').val();
        payable_amount = +payable_amount;
        discount_amount = $('#discount_amount').val();
        discount_amount = +discount_amount;
        sub_total_amount = payable_amount - discount_amount;
        $('#sub_total_amount').val(sub_total_amount);
        $('#paid_amount').val(sub_total_amount);
        $('#commission_fee').val(sub_total_amount);
        $('#due_amount').val(0);
        if (payable_amount > 0) {
            discount_percentage = (100 * discount_amount) / payable_amount;
        } else {
            discount_percentage = 0;
        }
        $('#discount_percentage').val(discount_percentage.toFixed(2));

    })

    $(document).on('keyup', '#discount_percentage', function(e) {
        var payable_amount, paid, discount_amount, discount_percentage, sub_total_amount;
        payable_amount = $('#payable_amount').val();
        payable_amount = +payable_amount;
        discount_percentage = $('#discount_percentage').val();
        discount_percentage = +discount_percentage;
        discount_amount = (payable_amount * discount_percentage) / 100;
        $('#discount_amount').val(discount_amount);

        sub_total_amount = payable_amount - discount_amount;
        $('#sub_total_amount').val(sub_total_amount);
        $('#paid_amount').val(sub_total_amount);
        $('#commission_fee').val(sub_total_amount);
        $('#due_amount').val(0);
    })



    $(document).on('keyup', '#doctor_commission', function(e) {
        var payable_amount, discount_amount, sub_total_amount, doctor_commission = 0;
        doctor_commission = $(this).val();
        doctor_commission = +doctor_commission;
        payable_amount = $('#payable_amount').val();
        payable_amount = +payable_amount;
        discount_amount = $('#discount_amount').val();
        discount_amount = +discount_amount;
        sub_total_amount = payable_amount - discount_amount;
        $('#sub_total_amount').val(sub_total_amount);
        $('#paid_amount').val(sub_total_amount);
        $('#due_amount').val(0);
    })
    $(document).on('keyup', '#paid_amount', function(e) {
        $('#commission_fee').val(0);
        var paid_amount, sub_total_amount, due_amount;
        paid_amount = $('#paid_amount').val();
        paid_amount = +paid_amount;
        sub_total_amount = $('#sub_total_amount').val();
        sub_total_amount = +sub_total_amount;
        if (paid_amount > sub_total_amount) {
            alert('Paid amount should be less than or equal to sub total amount');
            $('#paid_amount').val(0);
        }
        due_amount = sub_total_amount - paid_amount;
        $('#due_amount').val(due_amount);
    })
    $(document).on('keyup', '#commission_fee', function(e) {
        var paid_amount, commission_fee;
        paid_amount = $('#paid_amount').val();
        paid_amount = +paid_amount;
        commission_fee = $('#commission_fee').val();
        commission_fee = +commission_fee;
        if (commission_fee > paid_amount) {
            alert('Doctor Pay should be less than or equal to Paid Amount');
            commission_fee = paid_amount;
            $('#commission_fee').val(commission_fee);
        }
    })
    // $(document).on('click', 'input[name=invoice_status]', function() {
    //     var invoice_status = $(this).val();
    //     if (invoice_status == 'Created') {
    //         $('.Created').show(1000);
    //         $('#serial_no').attr('required', 'required');
    //         $('#serial_id').removeAttr('required');
    //         $('.Not_Created').hide(1000);
    //     } else {
    //         $('.Created').hide(1000);
    //         $('.Not_Created').show(1000);
    //         $('#serial_id').attr('required', 'required');
    //         $('#serial_no').removeAttr('required');
    //     }
    // })
    // $(document).on('change', '#serial_id', function() {
    //     var serial_id, doctor_id, patient_id, option;
    //     serial_id = $(this).val();
    //     option = $('#serial_id :selected');
    //     patient_id = option.data('patient_id');
    //     doctor_id = option.data('doctor_id');
    //     $('#patient_id').val(patient_id).selectpicker('refresh');
    //     $('#doctor_id').val(doctor_id).selectpicker('refresh');
    //     $('#patient_id').trigger('change');
    //     $('#doctor_id').trigger('change');
    // })
</script>
<script>
        $(document).ready(function() {
        $('#doctor_id, #date').on('change', function() {
            var doctor_id = $('#doctor_id').val();
            var date = $('#date').val();
            // if(doctor_id == ""){
            //     alert ('Select a Doctor please.')
            // }else{

            $.ajax({
                type: 'POST',
                url: '<?php echo site_url('appointment/get_doctor_serial'); ?>',
                data: {doctor_id: doctor_id, date: date},
                dataType: 'json',
                success: function(response) {
                    
                    $('#serial_id').html(response).selectpicker('refresh');
                },
                error: function() {
                    alert('Error fetching data.');
                }
            });
        //}
        });

        // $('form:eq(0)').submit(function(event) { 
                
        //         var fieldValue = $('#example_field').val();
        //         if (fieldValue !== 'someCondition') {
                    
        //             event.preventDefault();
        //             alert('Condition not met. Form not submitted.');
        //         }
        //     });

         $(document).on('change', '#serial_id', function() {
        
        var option = $('#serial_id :selected');
        var patient_id = option.data('patient_id');
        var patient_name = option.data('name');
        var patient_age = option.data('age');
        var patient_gender = option.data('gender');
        var patient_mobile = option.data('mobile');
        var ref = option.data('ref');
        $('#patient_name').val(patient_name);
        $('#patient_id').val(patient_id).selectpicker('refresh');
        $('#reference_by').val(ref).selectpicker('refresh');
        $('#age').val(patient_age);
        $('#sex').val(patient_gender);
        $('#mobile').val(patient_mobile);
        load_marketing();
        $('#patient_id').trigger('change')
        
    })

    $('input[type=radio][name=appointment_type]').change(function() {
    //     option = $('#doctor_id :selected');
    // if (this.value == 'New') {
    //     charge = option.data('frees');
    //     comission = option.data('commission_fee');
    // }
    // else if (this.value == 'Follow-Up') {
    //     charge = option.data('follow_up_fee');
    //     comission = option.data('follow_up_commission');
    // }
    //             $('#frees').val(charge);
    //             $('#commission_fee').val(comission);
    //             $('#payable_amount').val(charge);
    //             discount_percentage = $('#discount_percentage').val();
    //             discount_percentage = +discount_percentage;
    //             discount_amount = (charge * discount_percentage) / 100;
    //             discount_amount = +discount_amount;
    //             $('#discount_amount').val(discount_amount);
    //             var sub_total_amount = charge - discount_amount;
    //             $('#sub_total_amount').val(sub_total_amount);
    //             $('#paid_amount').val(sub_total_amount);
    //             $('#due_amount').val(0);
    var visitType = $('input[name="appointment_type"]:checked').val();
        var doctor_id = $('#doctor_id').val();
        var discount_percentage, discount_amount;
        var formURL = "<?= base_url('appointment/get_doctor_fee'); ?>";
        $.ajax({
            url: formURL,
            type: "POST",
            data: {
                visitType: visitType,
                doctor_id: doctor_id
            },
            dataType: "json",
            success: function(data) {
                $('#frees').val(data.doctor_fee);
                $('#commission_fee').val(data.commission_fee);
                $('#payable_amount').val(data.doctor_fee);
                discount_percentage = $('#discount_percentage').val();
                discount_percentage = +discount_percentage;
                discount_amount = (data.doctor_fee * discount_percentage) / 100;
                discount_amount = +discount_amount;
                $('#discount_amount').val(discount_amount.toFixed(2));
                sub_total_amount = data.doctor_fee - discount_amount;
                $('#sub_total_amount').val(sub_total_amount.toFixed(2));
                $('#paid_amount').val(sub_total_amount.toFixed(2));
                $('#due_amount').val(0);
            }
        });
});

function load_serial()
    {
        var doctor_id = $('#doctor_id').val();
            var date = $('#date').val();

            if(doctor_id == ""){
                alert ('Select a Doctor please.')
            }else{

            $.ajax({
                type: 'POST',
                url: '<?php echo site_url('doctor_serial/get_doctor_serial'); ?>',
                data: {doctor_id: doctor_id, date: date},
                dataType: 'json',
                success: function(response) {
                    
                    $('#serial_no').val(response.serial_no);
                },
                error: function() {
                    alert('Error fetching data.');
                }
                
            });
    }
}

$(function(e) {
    
        $(document).on('click', '#c_plus', function() {
            $('#serial_id').hide();
            $('#serial_id').selectpicker('refresh')
            $('#serial_id').removeAttr('required');
            $('#serial_no').show();
            $('#serial_no').attr('required', 'required')
            load_serial();
        });
    });

      
        
    });
    </script>

    <script>
        load_marketing();
        $("#reference_by").on("change paste keyup", function() {
        
            load_marketing();
        
    });

    function load_marketing()
    {
        var reference_by = $('#reference_by').val();
        var formURL = '<?= base_url('appointment/load_ref_staff') ?>';
        var formData = {
            reference_by: reference_by
        };
        $.ajax({
            type: "POST",
            url: formURL,
            data: formData,
            dataType: "json",
            success: function(response) {
                $('#marketing').html('Marketing: '+response.staff_name);
                $('#marketing_staff').val(response.staff_id);

            }
        });

    }
    </script>

    <script>
    $(document).on('change', '#serial_id', function(e) {
         const isEdit = '<?= isset($value)?true:false ?>'
         if(!isEdit){
            setTimeout(() => {
                doctor_fee()
            }, 300); 
        }                              
    })
    $(document).on('change', '#doctor_id, #patient_id', function(e) {
        doctor_fee()
    })


    function doctor_fee()
        {
            const doctor_id       = $("#doctor_id").val();
            const patient_id      = $("#patient_id").val();
            const date            = $("#date").val();
            const url             = "<?= base_url('appointment/get_doctor_fee'); ?>";
            
            $.ajax({
                url:url,
                type:"get",
                dataType:"json",
                data:{doctor_id,patient_id, date},
                success:function(data){
                    
                    
                    $('#frees').val(data.doctor_fee);
                    $('#doctor_fee').val(data.doctor_fee);
                    $('#commission_fee').val(data.commission_fee);
                    $('#payable_amount').val(data.doctor_fee);
                    let discount_percentage = $('#discount_percentage').val();
                    discount_percentage = +discount_percentage;
                    let discount_amount = (data.doctor_fee * discount_percentage) / 100;
                    discount_amount = +discount_amount;
                    $('#discount_amount').val(discount_amount.toFixed(2));
                    let sub_total_amount = data.doctor_fee - discount_amount;
                    $('#sub_total_amount').val(sub_total_amount.toFixed(2));
                    $('#paid_amount').val(sub_total_amount.toFixed(2));
                    $('#due_amount').val(0);
                    $("input[name='appointment_type']").prop("checked", false);
                    $("input[name='appointment_type'][value='"+data.visit_type +"']").prop("checked", true);

                },
                error:function(err,status)
                {
 
                    
                }
            });
        }
    </script>

 