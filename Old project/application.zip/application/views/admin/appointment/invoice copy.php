<section class="content">
    <div id="invoice">
        <div class="report_header">
            <?php $this->load->view('admin/common/report_header') ?>
        </div>
        
        <div class="container">
            <?php $this->load->view('admin/common/report_header_barcode'); ?>
            <div class="row patient_area">
                <div class="form-group col-sm-6 col-xs-6" style="color: black !important; font-size: 20px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <?php $invoice = $this->Common_model->findById('create_bill',array('record_id'=>$value->invoice_id)); ?>
                    <b>Invoice No: </b><?=isset($invoice)?$invoice->invoice_no:''?>
                </div>
                <div class="form-group col-sm-6 col-xs-6" style="text-align: right; color: black !important; font-size: 20px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Serial No: </b><?=$value->prefix.'-'.$value->serial_no?>
                </div>
                <div class="form-group col-sm-6 col-xs-6" style="color: black !important; font-size: 20px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Patient: </b><?=isset($patient)?$patient->name:''?>
                </div>
                <div class="form-group col-sm-6 col-xs-6" style="text-align: right; color: black !important; font-size: 20px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <?php
                    // dd($invoice);
                        $time = '' ;
                            if(isset($value)){
                                $s = $value->created_at;
                                $dt = new DateTime($s);
                                $date = $dt->format('d-m-Y');
                                $time = $dt->format('h:i:s A');
                            }
                        ?>
                        <b>Times: </b><?=$time?>
                </div>
                <div class="form-group col-sm-6 col-xs-6" style="color: black !important; font-size: 20px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Age: </b><?=isset($patient)?$patient->age:''?>
                </div>
                <div class="form-group col-sm-6 col-xs-6" style="text-align: right; color: black !important; font-size: 20px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Gender: </b><?=isset($patient)?$patient->gender:''?>
                </div>
                <div class="form-group col-sm-6 col-xs-6" style="color: black !important; font-size: 20px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Weight: </b><?=isset($patient)?$patient->weight:''?>
                </div>
                <div class="form-group col-sm-6 col-xs-6" style="text-align: right;color: black !important; font-size: 20px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Mobile: </b><?=isset($patient)?$patient->mobile:''?>
                </div> 
            </div>
            <div class="row" style="margin-top:10px;">
                <div class="col-md-12">
                    
                </div>
            </div>

            <div class="row">
                <div class="form-group col-sm-12 col-xs-12"style="text-align: center; font-weight: bold; padding-bottom: 0px; margin-bottom: 0px;">
                    <table id="" class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th style="text-align: center;">Appointment Doctor Name</th>
                                <th style="text-align: center;">Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="text-align: center;">
                                    <?php $designation = $this->Common_model->findById('designation',array('record_id'=>$doctor->designation_id)) ?>
                                    <?=isset($doctor)?$doctor->name:''?>
                                    <?=isset($designation)?' - '.$designation->designation:''?>
                                        
                                    </td>
                                <td style="text-align: center;"><?php echo $value->doctor_fee; ?></td>
                            </tr>
                        </tbody>
                    </table>
                     <?php
                     $collection = $this->Common_model->calCulateSum('due_collection_details',array('invoice_id'=>$value->invoice_id),'current_collection');
                                      $collection = isset($collection)?$collection:0;

                                      $sub_total = $value->sub_total;
                                      $paid_amount = $value->paid;
                                      $paid_amount += $collection ;
                                      $due_amount = $sub_total - $paid_amount ;
                    ?>
                    <table id="" class="table table-bordered table-hover">
                        <tbody>
                            <tr>
                                <th style="text-align: right;" colspan="2">Total: <?php echo $value->doctor_fee; ?></th>
                            </tr>
                            <tr>
                                <th style="text-align: right;" colspan="2">Discount: <?php echo $value->discount; ?></th>
                            </tr>
                            <tr>
                                <th style="text-align: right;" colspan="2">Balance: <?php echo $value->sub_total; ?></th>
                            </tr>
                            <tr>
                                <th style="text-align: right;" colspan="2">Paid: <?php echo $paid_amount; ?></th>
                            </tr>
                            <tr>
                                <th style="text-align: right;" colspan="2">Due: <?php echo $due_amount; ?></th>
                            </tr>
                            <tr>
                                <th style="text-align: right;" colspan="2">In Word:<?php echo $this->numbertowords->convert_number($paid_amount); ?> Taka Only.</th>
                            </tr>
                            <tr>
                            <th style="text-align: left;" colspan="2">
                            Ref: <?=isset($patient)?$ref->reference_name:''?>
                            </th>

                            </tr>
                        </tbody>
                    </table>
                    
                </div>
            </div>

            <?php $this->load->view('admin/common/report_footer') ?>
        </div>
    </div>
        <?php $this->load->view('admin/common/copyright') ?>
</section>

