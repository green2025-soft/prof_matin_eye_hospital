<aside >
    <section class="content">
        <div class="row">
            <section class="col-xs-12 connectedSortable"> 
                <div class="box box-info ">
                    <div class="box-header">
                        <h3 class="box-title"><?=isset($page_title)?$page_title:''?></h3>
                        <form class="no_print" action="<?= base_url('appointment') ?>" method="GET">
              <div class="box-body">
                <div class="row">
                  <div class="col-md-2">
                    <div class="form-group">
                      <label for="from_date">From Date</label>
                      <input type="text" class="form-control search_datepicker" id="from_date" placeholder="YYYY-MM-DD" name="from_date" value="<?= isset($from_date) && !empty($from_date) ? $from_date : date('Y-m-d') ?>" autocomplete="off">
                    </div>
                  </div>
                  <div class="col-md-2">
                    <div class="form-group">
                      <label for="to_date">To Date</label>
                      <input type="text" class="form-control search_datepicker" id="to_date" placeholder="YYYY-MM-DD" name="to_date" value="<?= isset($to_date) && !empty($to_date) ? $to_date : date('Y-m-d') ?>" autocomplete="off">
                    </div>
                  </div>
                  <div class="col-md-3">
                    <div class="form-group">
                      <label for="doctor_id">Doctor </label>
                      <select name="doctor_id" id="doctor_id" class="form-control selectpicker" data-live-search="true">
                        <?= options(
                          'doctor',
                          array(),
                          array('record_id', 'name'),
                          'record_id',
                          '',
                          'record_id',
                          'desc',
                          'Select Doctor',
                          isset($doctor_id) && !empty($doctor_id) ? $doctor_id : 0
                        )
                        ?>
                      </select>
                    </div>
                  </div>

                  <div class="col-md-2 hide">
                    <div class="form-group">
                      <label for="marketing_staff">Marketing </label>
                      <select name="marketing_staff" id="marketing_staff" class="form-control selectpicker" data-live-search="true">
                        <option value="">Select Marketing</option>
                        <?php if($marketing){
                          foreach($marketing as $info){ ?>
                             <option value="<?=$info->record_id ?>" <?php if($marketing_staff == $info->record_id){echo 'selected';} ?>><?= $info->name.'('.$info->record_id.')' ?></option>
                            <?php }} ?>

                      </select>
                    </div>
                  </div>
               
                  
                  <div class="col-md-2">
                    <div class="form-group" style="margin-top: 25px;">
                      <button type="submit" class="pull-left btn btn-success">Search <i class="fa fa-search"></i></button>
                    </div>
                  </div>
                </div>
              </div>
            </form>
                    </div>
                    <div class="box-body">
                       <?php $this->load->view('admin/common/report_header') ?>
                        <div class="box-body table-responsive">
                        <table id="example2" class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th style="text-align: center;">SL</th>
                                    <th style="text-align: center;">Date</th>
                                    <th style="text-align: center;">Inv_No</th>
                                    <th style="text-align: center;">Serial</th>
                                    <th style="text-align: center;">Doctor</th>
                                    <th style="text-align: center;">Patient</th>
                                    <!--<th style="text-align: center;">Department</th>-->
                                    <th style="text-align: right;">Total</th>
                                    <th style="text-align: right;">Disc.</th>
                                    <th style="text-align: right;">Sub_Total</th>
                                    <th style="text-align: right;">Paid</th>
                                    <th style="text-align: right;">Due</th>
                                    <th style="text-align: center;">Ref.</th>
                                    <!-- <th style="text-align: center;">Marketing</th> -->
                                     <th>Remarks</th>
                                    <th class="no_print" style="text-align: center;">Created</th>
                                    <th style="text-align: center;width: 140px;" class="no_print">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $count = 0;$sub_total = 0 ; $paid_amount = 0; $due_amount = 0 ;

                                $total_paid = 0;
                                $total_due = 0;
                                foreach ($values as $single_value) {
                                    $count++;
                                    // dd($single_value);
                                    $bill = $this->Common_model->findById('create_bill', array('record_id ' => $single_value->invoice_id));
                                    $doctor = $this->Common_model->findById('doctor',array('record_id'=>$single_value->doctor_id)) ;
                                    $patient = $this->Common_model->findById('patient',array('record_id'=>$single_value->patient_id)) ;
                                    $reference_by = $this->Common_model->findById('reference_by',array('record_id'=>$single_value->reference_by)) ;
                                    $collection = $this->Common_model->calCulateSum('due_collection_details',array('invoice_id'=>$single_value->invoice_id),'current_collection');
                                    //$staff = $this->Common_model->findById('staff', array('record_id' => $single_value->marketing_staff));
                                    $collection = isset($collection)?$collection:0;

                                      $sub_total = $single_value->sub_total;
                                      $paid_amount = $single_value->paid;
                                      $paid_amount += $collection ;
                                      $due_amount = $sub_total - $paid_amount ;

                                      $total_paid += $paid_amount;
                                      $total_due += $due_amount;
                                    ?>
                                    <tr>
                                        <td style="text-align: center;"><?php echo $count; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->date ?></td>
                                        <td style="text-align: center;"><?php echo $bill->invoice_no ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->prefix.'-'.$single_value->serial_no; ?></td>
                                        <td style="text-align: left;"><?=isset($doctor)?$doctor->name.'['.$doctor->record_id.']':''?></td>
                                        <td style="text-align: left;"><?=isset($patient)?$patient->name.'['.$patient->record_id.']':''?></td>
                                        <td style="text-align: right;"><?php echo $single_value->doctor_fee; ?></td>
                                        <td style="text-align: right;"><?php echo $single_value->discount; ?></td>
                                        <td style="text-align: right;"><?php echo $sub_total; ?></td>
                                        <td style="text-align: right;"><?php echo $paid_amount; ?></td>
                                        <td style="text-align: right;"><?php echo $due_amount; ?></td>
                                        <td style="text-align: left;"><?=isset($reference_by)?$reference_by->reference_name.'['.$reference_by->record_id.']':''?></td>
                                        <!-- <td><?= isset($staff) ? $staff->name : '' ?></td> -->
                                         <td><?= $single_value->comments ?></td>
                                        <td style="text-align: left;" class="no_print"><?=creator($single_value->created_by)?></td>
                                        <td style="text-align: center;" class="no_print">
                                            <a class="btn btn-primary"
                                               href="<?=base_url("appointment/view2/$single_value->record_id"); ?>"><i class="fa fa-eye"></i>
                                            </a>
                                             <?php if($collection <= 0){ ?>
                                            <a class="btn btn-info"
                                               href="<?=base_url("appointment/edit/$single_value->record_id"); ?>"><i class="fa fa-pencil"></i>
                                            </a>
                                            <?php } ?>
                                            <a class="btn btn-danger"
                                               href="<?=base_url("appointment/delete/$single_value->record_id"); ?>" onclick="return confirm('Are you sure to delete this record?')"><i class="fa fa-trash-o"></i>
                                            </a>
                                            <?php $class = "btn-success";
                                            if (admin()) {
                                                $button_text = $single_value->show_hide;
                                                if ($button_text == "Show") {
                                                    $class = "btn-success";
                                                } else {
                                                    $class = "btn-danger";
                                                }
                                            ?>
                                                <a class="btn <?= $class ?> btnShowHide" href="javascript:void(0)" data-url="<?= base_url("crud/show_hide/appointments/record_id/$single_value->record_id"); ?>"><?= $button_text ?></i>
                                                </a>
                                            <?php } ?>
                                        </td>
                                    </tr>
                                <?php } ?>
                                <tr>
                                    <td colspan="9" align="right">
                                                Total
                                    </td>
                                    
                                    <td align="right"><?= $total_paid ?></td>
                                    <td align="right"><?= $total_due ?></td>
                                    <td colspan="2"></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    </div>
                </div>
            </section>
        </div>
    </section>
</aside>
<style>
  @media print {
     @page {
       size: A4 landscape;
     }
  }
</style>