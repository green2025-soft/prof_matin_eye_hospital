  <table class="table bill-table text-center">
    <thead>
        <tr>
     
            <th style="text-align: left;width: 80%; border-left: var(--b1)">Appointment Doctor Name</th>
            <th  style="border-right: var(--b1); text-align: right;">Amount</th>
            <!--<th style="text-align: center;">Total Price</th>-->
        </tr>
    </thead>
    <tbody>
        
        
        
        <tr>
            <td class="text-left"><?=$appointmentDr?></td>
            <td class="text-right"><strong><?=currency($value->doctor_fee) ?></strong></td>
        </tr>


      
    </tbody>
</table>
  <table class="table bill-table ">
    <tr>
        <td width="55%" class="">
             <div class="note-paid">
                <div class="note-title" >Remarks : <?= $value->comments ?></div>
                <div class="paid"><?= $value->due > 0?'DUE':'PAID' ?></div>
            </div>
        </td>
        <td colspan="2" style="text-align: left; padding: 0; vertical-align: text-top; ">
            <table class="table" style="border: none; margin: 0;">
                <tr>
                    <th class="bt1 text-left">Total Amount:</th> 
                    <th class="bt1 text-right"><?= currency($value->doctor_fee) ?></th> 
                </tr>
               
                <tr>
                    <th class="bt1 text-left" >Discount (-):</th> 
                    <th class="bt1 text-right"><?= currency($value->discount)??0 ?></th> 
                </tr>
                <tr>
                    <th class="bt1 text-left" >Sub Total:</th> 
                    <th class="bt1 text-right"><?=currency($value->sub_total)?></th> 
                </tr>
                <tr>
                <th class="bt1 text-left">Paid Amount:</th> 
                    <th class="bt1 text-right" ><?= currency($value->paid) ?></th> 
                </tr>
                <tr>
                    <th class="text-left">Due Amount:</th> 
                    <th class="text-right"> <?= currency($value->due??0)  ?></th> 
                </tr>
            </table>
        </td>
    </tr>
  </table>
                    