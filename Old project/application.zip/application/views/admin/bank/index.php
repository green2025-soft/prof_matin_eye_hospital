
<aside>
    <section class="content">
        <div class="row">
            <section class="col-xs-12 connectedSortable"> 
                <div  class="box box-info no_print">
                    <div class="box-header">
                        <h3 class="box-title"><?=isset($page_title)?$page_title:''?></h3>
                    </div>
                    <?php echo form_open_multipart('bank/saveOrUpdateBank'); ?>
                    <div class="box-body">
                        <div class="row">
                            <div class="form-group col-sm-3">
                              <label for="bank_name">Bank Name (<span class="required">*</span>) </label>
                              <input type="text" class="form-control" id="bank_name" 
                              placeholder="" name="bank_name" required="">
                              <input type="hidden" name="update_id" id="update_id" value="0">
                          </div>
                          <div class="form-group col-sm-3">
                              <label for="account_no">Account No </label>
                              <input type="text" class="form-control" id="account_no" placeholder="" name="account_no">
                          </div>
                          <div class="form-group col-sm-3">
                              <label for="location">Branch Area </label>
                              <input type="text" class="form-control" id="location" placeholder="" name="location">
                          </div>
                          <div class="col-sm-1">
                            <button type="submit" class="pull-left btn btn-success update mt-25">Create <i class="fa fa-arrow-circle-right"></i></button>
                        </div>
                    </div>
                </div>

            </form>
            <div class="box-body table-responsive">
                <div class="info-header">
                    <h4><?=isset($info_header)?$info_header:''?></h4> 
                </div>
                <table id="example2" class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th style="text-align: center;">#</th>
                            <th style="text-align: center;">Name</th>
                            <th style="text-align: center;">Account No</th>
                            <th style="text-align: center;">Branch Area</th>
                            <th style="text-align: center;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $count = 0;
                        foreach ($values as $single_value) {
                            $count++;
                            ?>
                            <tr>
                                <td style="text-align: center;"><?php echo $count; ?></td>
                                <td style="text-align: center;"><?php echo $single_value->bank_name; ?></td>
                                <td style="text-align: center;"><?php echo $single_value->account_no; ?></td>
                                <td style="text-align: center;"><?php echo $single_value->location; ?></td>
                                <td style="text-align: center;">
                                    <a href="javascript:void(0)" class="btn btn-primary btnEdit" data-record_id="<?=$single_value->record_id?>"><i class="fa fa-pencil"></i></a>
                                    <a class="btn btn-danger"
                                    href="<?=base_url("bank/delete/$single_value->record_id")?>" onclick="return confirm('Are you sure to delete this record?')"><i class="fa fa-trash-o"></i>
                                </a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</section>
</div>
</section>
</aside>

<script type="text/javascript">
    $(document).on('click','.btnEdit',function(e){
        var id = $(this).data('record_id');
        var formURL = "<?php echo site_url('crud/edit/banks/record_id'); ?>";
        $.ajax(
        {
            url : formURL,
            type: "POST",
            data : {id: id},
            dataType: "json",
            success:function(data){
              $('#update_id').val(data.record_id);
              $('#bank_name').val(data.bank_name);
              $('#account_no').val(data.account_no);
              $('#location').val(data.location);
              $('#bank_name').focus();
              $('.update').text("Update");
              $("html, body").animate({ scrollTop: 0 }, "slow");
          }
      });
        e.preventDefault();
    });
</script>