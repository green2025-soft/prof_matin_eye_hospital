<section class="content">
    <div class="row">
        <section class="col-xs-12 connectedSortable"> 
            <div  class="box box-info no_print">
                <div class="box-header">
                    <h3 class="box-title"><?=isset($page_title)?$page_title:''?></h3>
                </div>
            <div class="box-body table-responsive">
                
                <form action="<?=base_url("backup/export")?>" method="POST">
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                Download database
                            </div>
                        </div>
                        
                    </div>
                </div>
                <div class="box-footer clearfix">
                    <button type="submit" class="pull-left btn btn-success update">Send <i class="fa fa-download"></i></button>
                </div>
            </form>
        </div>
    </div>
</section>
</div>
</section>
