<style>
    table.table-bordered{
        border: grey 1px solid !important;
        font-weight: bold !important;
        color: black !important;
        font-size: 13px !important;
    }
    table.table-bordered > thead > tr > th{
        border: grey 1px solid !important;
        font-weight: bold !important;
        color: white !important;
        font-size: 13px !important;
        background: #0aad87 !important;
    }
    table.table-bordered > tbody > tr > td{
        border: grey 1px solid !important;
        font-weight: bold !important;
        color: black !important;
        font-size: 13px !important;
    }
</style>

<?php
if ($msg == "main") {
    $msg = "";
} elseif ($msg == "empty") {
    $msg = "Please fill out all required fields";
} elseif ($msg == "created") {
    $msg = "Created Successfully";
} elseif ($msg == "edit") {
    $msg = "Edited Successfully";
} elseif ($msg == "delete") {
    $msg = "Deleted Successfully";
} elseif ($msg == "active") {
    $msg = "ID is active Now";
} elseif ($msg == "inactive") {
    $msg = "ID is inactive Now";
}
?>
<aside >
    <section class="content">
        <div class="row">
            <section class="col-xs-12 connectedSortable" id="full_page">
                <div class="box box-info no_print">
                    <div class="box-body">
                        <p style="font-size: 20px; color: green; font-weight: bold; text-align: center;">Doctor Consultation</p>
                        <p style="font-size: 20px; color: #066;" id="message"><?php echo $msg; ?></p>
                        <div class="row">
                            <div class="form-group col-sm-4 col-xs-12">
                                <label for="patient_id">Patient Name (<span class="required">*</span>) </label>
                                <div class="input-group">
                                    <select name="patient_id" id="patient_id" class="form-control selectpicker"
                                            data-live-search="true">
                                        <option value="">--Select--</option>
                                        <?php foreach ($all_patient as $info) { ?>
                                            <option data-id="<?=$info->record_id?>" value="<?php echo $info->record_id . "###" . $info->name; ?>">
                                                <?php echo "$info->name [ID: $info->record_id]"; ?>
                                            </option>
                                        <?php } ?>
                                    </select>
                                    <input type="text" class="form-control" id="new_patient"
                                           placeholder="New Patient Name"
                                           name="new_patient" style="display: none">
                                    <span class="input-group-addon">
                                        <button type="button" id="c_plus" style="height: 20px;"
                                                class="btn btn-success fa fa-plus-square btn-sm"></button>
                                        <button type="button" id="c_back" style="height: 20px; display:none;"
                                                class="btn btn-info fa fa-backward btn-sm"></button>
                                    </span>
                                </div>
                            </div> 
                            <!--Patient Name Add and Insert New-->

                            <div class="form-group col-sm-4 col-xs-12">
                                <label for="mobile">Mobile No. (<span class="required">*</span>) </label>
                                <input type="text" name="mobile" id="mobile" class="form-control">
                            </div>
                            <div class="form-group col-sm-4 col-xs-12">
                                <label for="age">Age (<span class="required">*</span>) </label>
                                <input type="text" class="form-control" id="age" name="age">
                            </div>
                            <div class="form-group col-sm-4 col-xs-12">
                                <label for="address">Address</label>
                                <input type="text" class="form-control" id="address"
                                       value="" placeholder="" name="address">
                            </div>

                            <div class="form-group col-sm-4 col-xs-12">
                                <label for="doctor_name">Doctor Name (<span class="required">*</span>) </label>
                                <select name="doctor_name" id="doctor_name" class="form-control selectpicker" data-container="body" data-live-search="true">
                                    <option value="">-- Select --</option>
                                    <?php foreach ($all_doctor as $info) { ?>
                                        <option  data-id="<?=$info->record_id?>" value="<?php echo $info->name . "###" . $info->designation ?>">
                                            <?php
                                            echo $info->name .
                                            " [" . $info->designation . "]";
                                            ?>
                                        </option>
                                    <?php } ?>
                                </select>
                            </div>
                            <div class="form-group col-sm-4 col-xs-12">
                                <label for="doctor_fee">Doctor Fee (<span class="required">*</span>) </label>
                                <input type="text" class="form-control text-right numeric" id="doctor_fee" placeholder="" readonly=""
                                       name="doctor_fee">
                            </div>
                            <div class="form-group col-sm-4 col-xs-12">
                                <label for="discount">Discount</label>
                                <input type="text" class="form-control text-right numeric" id="discount" placeholder=""
                                       name="discount">
                            </div>
                            <div class="form-group col-sm-4 col-xs-12" id="referenceByDiv" style="display: none;">
                                <label for="discount">Reference By</label>
                                    <input type="text" name="reference_by" id="reference_by" class="form-control">
                            </div>
                            <div class="form-group col-sm-4 col-xs-12">
                                <label for="sub_total">Sub-total</label>
                                <input type="text" class="form-control text-right numeric" id="sub_total" placeholder="" readonly=""
                                       name="sub_total">
                            </div>
                            <div class="form-group col-sm-4 col-xs-12">
                                <label for="doctor_commission">Doctor Commission</label>
                                <input type="text" class="form-control text-right numeric" id="doctor_commission" placeholder=""
                                       name="doctor_commission">
                            </div>
                            <div class="form-group col-sm-4 col-xs-12">
                                <label for="company_commission">Hospital Amount</label>
                                <input type="text" class="form-control text-right numeric" id="company_commission" placeholder="" readonly=""
                                       name="company_commission">
                            </div>
                            <div class="form-group col-sm-4 col-xs-12">
                                <label for="date">Appointment Date (<span class="required">*</span>) </label>
                                <input type="text" class="form-control new_datepicker" id="date"
                                       value="<?php echo date('Y-m-d'); ?>" placeholder="Date" name="date">
                            </div>
                            <div class="form-group col-sm-4 col-xs-12">
                                <label for="appointment_time">Appointment Time (<span class="required">*</span>) </label>
                                <input type="time" class="form-control" id="appointment_time" placeholder=""
                                       name="appointment_time">
                            </div>
                        </div>
                    </div>
                    <div class="box-footer clearfix">
                        <button type="button" class="pull-left btn btn-success" id="submit">Submit <i
                                class="fa fa-arrow-circle-right"></i></button>
                    </div>
                    </form>
                </div>
            </section>
        </div>
    </section>
</aside>

<script type="text/javascript">

    var c_status = 0;

    $('#c_plus').on('click', function () {
        $('#patient_id').selectpicker('hide');
        $('#new_patient').show();
        $('#c_back').show();
        $('#patient_id').hide();
        $('#c_plus').hide();
        c_status = 1;
        $('#mobile').val('');
        $('#age').val('');
    });


    $('#c_back').on('click', function () {
        $('#patient_id').selectpicker('show');
        $('#new_patient').hide();
        $('#c_back').hide();
        $('#patient_id').show();
        $('#c_plus').show();
        $('#new_patient').val('');
        c_status = 0;
    });
//    Add and Insert Patient End
    $("#patient_id").on("change paste keyup", function () {
        var patient = $('#patient_id').val().split("###");
        var patient_id = patient[0];
        var patient_name = patient[1];
        var post_data = {
            'patient_id': patient_id,
            '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
        };

        $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>Get_ajax_value/get_patient_age_mobile_address",
            data: post_data,
            dataType: 'json',
            success: function (data) {
                $('#age').val(data[0]);
                $('#mobile').val(data[1]);
                $('#address').val(data[2]);
            }
        });
    });

    $("#discount, #doctor_commission").on("change paste keyup", function () {
        var discount = $('#discount').val();
        var doctor_commission = $('#doctor_commission').val();
        if (discount == "") {
            discount = 0;
        }

        if (doctor_commission == "") {
            doctor_commission = 0;
        }
        if(discount > 0){
            $('#referenceByDiv').show('fast');
        }else{
            $('#referenceByDiv').hide('fast');
        }
        var doctor_fee = $('#doctor_fee').val();
        var sub_total = parseFloat(doctor_fee) - parseFloat(discount);
        var company_commission = parseFloat(sub_total) - parseFloat(doctor_commission);
        $('#sub_total').val(sub_total);
        $('#company_commission').val(company_commission);
    });

    $("#doctor_name,#patient_id").on("change paste keyup", function () {
        var $option = $('#doctor_name').find('option:selected');
        var doctor_id = $option.data('id') ;
        var patient_id = $('#patient_id').find('option:selected').data('id');
        var post_data = {
            'doctor_id': doctor_id,
            'patient_id': patient_id,
            '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
        };

        $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>Get_ajax_value/get_doctor_fee",
            data: post_data,
            dataType: 'json',
            success: function (data) {
                $('#doctor_fee').val(data.doctor_fee);
                $('#sub_total').val(data.doctor_fee);
                $('#doctor_commission').val(data.commission_fee);
                $('#discount').val(0);
                $('#company_commission').val(data.doctor_fee - data.commission_fee);
            }
        });
        setTimeout(function(e){
            $('#discount').trigger('keyup');
        },1000)
    });

    $('#search_appointment').on('click', function () {
        var date = $('#s_date').val();
        var post_data = {
            'date': date,
            '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
        };
        $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>Get_ajax_value/appointment_by_date",
            data: post_data,
            success: function (data) {
                $('#appointment').html(data);
            }
        });
    });

    $("#submit").click(function () {
        var sub_total = $('#sub_total').val();
        var doctor_commission = $('#doctor_commission').val();
        if (doctor_commission > sub_total) {
            alert("Doctor Commision is more than Sub-total Amount");
        } else {
            var date = $('#date').val();
            if (c_status == 1) {
                var patient_id = "";
                var patient_name = $('#new_patient').val();
            } else {
                var patient = $('#patient_id').val().split("###");
                var patient_id = patient[0];
                var patient_name = patient[1];
            }
            var doctor = $('#doctor_name').val().split("###");
            var doctor_id = $('#doctor_name').find('option:selected').data('id') ;
            var doctor_name = doctor[0];
            var doctor_designation = doctor[1];

            var age = $('#age').val();
            var mobile = $('#mobile').val();
            var address = $('#address').val();
            var doctor_fee = $('#doctor_fee').val();
            var discount = $('#discount').val();
            var reference_by = $('#reference_by').val();
            var sub_total = $('#sub_total').val();
            var doctor_commission = $('#doctor_commission').val();
            var company_commission = $('#company_commission').val();
            var appointment_time = $('#appointment_time').val();

            if(patient_name == '' || doctor_name == '' || mobile == '' || age == '' || doctor_fee == '' || date == '' || appointment_time == ''){
                alert('Please, fill up all required fields!');
                return false;
            }

           // var post_data = {} ;

            var post_data = {
                'date': date,
                 'patient_id': patient_id, 
                 'patient_name': patient_name, 
                 'doctor_designation': doctor_designation, 
                 'doctor_id':doctor_id,
                  'doctor_name': doctor_name, 
                  'age': age,'address': address, 
                  'doctor_fee': doctor_fee, 
                  'appointment_time': appointment_time, 
                  'mobile': mobile, 
                  'c_status': c_status,
                  'discount': discount,
                  'reference_by':reference_by, 
                  'sub_total': sub_total, 
                  'doctor_commission':doctor_commission, 
                  'company_commission': company_commission,
                  '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>'
            };


            $.ajax({
                type: "POST",
                url: "<?php echo base_url(); ?>Get_ajax_value/consultancy_confirm",
                data: post_data,
                success: function (data) {
                    console.log(data);
                    window.location.replace("<?php echo base_url(); ?>Show_edit_form/invoice_app/" + data);
                }
            });
        }
    });
</script>

<script>
    $(document).ready(function () {
        datatable();
    });
    function datatable() {
        $('#datatable').dataTable({
            //"info":false,
            "autoWidth": false,
            "order": false,
            "oSearch": {"bSmart": false}
        });
    }
</script>

<style>
    @media print {
        @page 
        {
            size: A4 landscape;   /* auto is the current printer page size */
            margin: -5mm 0mm 0mm 10mm;
        }
        html
        {
            background-color: #FFFFFF; 
            margin: 0px;  /* this affects the margin on the html before sending to printer */
        }
        .no_print {
            display: none;
        }
        ::-webkit-scrollbar{
            display: none;
        }
        .dataTables_filter {
            display: none;
        }
        .dataTables_paginate {
            display: none;
        }
        .dataTables_info {
            display: none;
        }
        .dataTables_length {
            display: none;
        }
        .dataTables_orderable{
            display: none;
        }
        table.dataTable thead .sorting:after,
        table.dataTable thead .sorting_asc:after,
        table.dataTable thead .sorting_desc:after {
            display: none;
        }
    }
</style>