<section class="content">
    <div id="invoice">
        <div class="report_header">
            <?php $this->load->view('admin/common/report_header') ?>
        </div>
        
        <div class="container">
            <div class="row patient_area">
                <div class="form-group col-sm-4 col-xs-6" style="color: black !important; font-size: 17px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Invoice No: </b><?=$value->invoice_no?>
                </div>
                <div class="form-group col-sm-4 col-xs-6" style="color: black !important; font-size: 17px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Date: </b><?=$value->date?>
                </div>
                <div class="clearfix"></div>
                <div class="form-group col-sm-4 col-xs-6" style="color: black !important; font-size: 17px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Patient Name: </b><?=isset($value)?$value->name.'['.$value->patient_id.']':''?>
                </div>
                <div class="form-group col-sm-4 col-xs-6" style="color: black !important; font-size: 17px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Age: </b><?=isset($value)?$value->age:''?>
                </div>
                <div class="form-group col-sm-4 col-xs-6" style="color: black !important; font-size: 17px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Contact No: </b><?=isset($value)?$value->mobile:''?>
                </div>
                <div class="clearfix"></div>
                
                <div class="form-group col-sm-4 col-xs-6" style="color: black !important; font-size: 17px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Doctor: </b><?=isset($value)?$value->doctor_name.'['.$value->doctor_id.']':''?>
                </div>
                <div class="form-group col-sm-4 col-xs-6" style="color: black !important; font-size: 17px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Donor : </b><?=isset($value)?$value->donor_name:''?>
                </div>
                <div class="form-group col-sm-4 col-xs-6" style="color: black !important; font-size: 17px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Donor Age : </b><?=isset($value)?$value->donor_age:''?>
                </div>
            </div>
            <div class="row" style="margin-top:10px;">
                <div class="col-md-12">
                <?php $this->load->view('admin/common/report_header_barcode'); ?>
                </div>
            </div>

            <div class="row">
                <div class="form-group col-sm-12 col-xs-12" style="text-align: center; font-weight: bold; padding-bottom: 0px; margin-bottom: 0px;">
                    <table id="" class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th style="text-align: center;">Particular</th>
                                <th style="text-align: center;">Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="text-align: center;">Test</td>
                                <td style="text-align: center;"><?php echo $value->test_price; ?></td>
                            </tr> 
                            <tr>
                                <td style="text-align: center;">Others Cost</td>
                                <td style="text-align: center;"><?php echo $value->others_cost; ?></td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th style="text-align: right;" colspan="2">Total : <?php echo ($value->test_price + $value->others_cost); ?></th>
                            </tr>
                            <tr>
                                <th style="text-align: right;" colspan="2">Discount : <?php echo $value->discount_amount; ?></th>
                            </tr><tr>
                                <th style="text-align: right;" colspan="2">Balance : <?php echo $value->sub_total_amount; ?></th>
                            </tr><tr>
                                <th style="text-align: right;" colspan="2">Paid : <?php echo $value->paid_amount; ?></th>
                            </tr><tr>
                                <th style="text-align: right;" colspan="2">Due : <?php echo $value->due_amount; ?></th>
                            </tr>
                            <th colspan="2">
                                In word : <?=$this->numbertowords->convert_number($value->paid_amount).' Tk Only.'?>
                            </th>
                        </tfoot>
                    </table>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <p>
                            <span style="font-weight: 700;text-decoration: underline;font-size: 16px;">Comments : </span> <?=$value->comments?>
                        </p>
                    </div>
                </div>
            </div>

            <?php $this->load->view('admin/common/report_footer') ?>
        </div>
    </div>
</section>

