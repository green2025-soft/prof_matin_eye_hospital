<aside >
    <section class="content">
        <div class="row">
            <section class="col-xs-12 connectedSortable"> 
                <div class="box box-info no_print">
                    <div class="box-header">
                        <h3 class="box-title"><?=isset($page_title)?$page_title:''?></h3>
                    </div>
                    <div class="box-body">
                        <div class="box-body table-responsive">
                        <table id="example2" class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th style="text-align: center;">SL</th>
                                    <th style="text-align: center;">Date</th>
                                    <th style="text-align: center;">Invoice</th>
                                    <th style="text-align: center;">Donor</th>
                                    <th style="text-align: center;">Age</th>
                                    <th style="text-align: center;">Patient</th>
                                    <th style="text-align: center;">Doctor</th>
                                    <th style="text-align: center;">B.Group</th>
                                    <th style="text-align: center;">T.Name</th>
                                    <th style="text-align: center;">Sub_Total</th>
                                    <th style="text-align: center;">Paid</th>
                                    <th style="text-align: center;">Due</th>
                                    <th style="text-align: center;">Comments</th>
                                    <th style="text-align: center;">Created</th>
                                    <th style="text-align: center;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $count = 0;
                                foreach ($values as $single_value) {
                                    $count++;
                                    $invoice = $this->Common_model->findById('create_bill',array('record_id'=>$single_value->invoice_id));
                                    ?>
                                    <tr>
                                        <td style="text-align: center;"><?php echo $count; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->date; ?></td>
                                        <td style="text-align: center;"><?=isset($invoice)?$invoice->prefix.$invoice->invoice_no:''?></td>
                                         <td style="text-align: center;"><?php echo $single_value->donor_name; ?></td>
                                         <td style="text-align: center;"><?php echo $single_value->donor_age?></td>
                                        <td style="text-align: center;"><?=isset($single_value)?$single_value->name.'['.$single_value->patient_id.']':''?></td>
                                        <td style="text-align: center;"><?php echo $single_value->doctor_name; ?></td>
                                        
                                        <td style="text-align: center;"><?php echo $single_value->group_name; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->test_name; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->sub_total_amount; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->paid_amount; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->due_amount; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->comments; ?></td>
                                        <td style="text-align: center;"><?=creator($single_value->created_by)?></td>
                                        <td style="text-align: center;">
                                            <a class="btn btn-primary"
                                               href="<?=base_url("blood_donor/view2/$single_value->blood_donor_id"); ?>"><i class="fa fa-eye"></i>
                                            </a>
                                            <a class="btn btn-info"
                                               href="<?=base_url("blood_donor/edit/$single_value->blood_donor_id"); ?>"><i class="fa fa-pencil"></i>
                                            </a>
                                            <a class="btn btn-danger"
                                               href="<?=base_url("blood_donor/delete/$single_value->blood_donor_id"); ?>" onclick="return confirm('Are you sure to delete this record?')"><i class="fa fa-trash-o"></i>
                                            </a>
                                            <?php $class = "btn-success";
                                                if (admin()) {
                                                    $button_text = $single_value->show_hide;
                                                    if ($button_text == "Show") {
                                                        $class = "btn-success";
                                                    } else {
                                                        $class = "btn-danger";
                                                    }
                                                ?>
                                                    <a class="btn <?= $class ?> btnShowHide" href="javascript:void(0)" data-url="<?= base_url("crud/show_hide/blood_donors/record_id/$single_value->blood_donor_id"); ?>"><?= $button_text ?></i>
                                                    </a>
                                                <?php } ?>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                    </div>
                </div>
            </section>
        </div>
    </section>
</aside>