
<aside >
    <section class="content">
        <div class="row">
            <section class="col-xs-12 connectedSortable"> 
                <div class="box box-info no_print">
                    <div class="box-header">
                        <h3 class="box-title"><?=isset($page_title)?$page_title:''?></h3>
                    </div>
                    <?php echo form_open_multipart('blood_donor/saveOrUpdate'); ?>
                    <div class="box-body">
                        <div class="row">
                            <div class="form-group col-sm-3">
                                <label for="date">Date (<span class="required">*</span>) </label>
                                <input type="text" class="form-control new_datepicker" id="date" 
                                placeholder="" name="date" value="<?=isset($value)?$value->date:date('Y-m-d')?>" required="" autocomplete="off">
                                <input type="hidden" name="update_id" name="update_id" value="<?=isset($value)?$value->record_id:0?>">
                            </div>
                            <div class="form-group col-sm-3">
                                <label for="patient_id">Patient Name (<span class="required">*</span>) </label>
                                <div class="input-group">
                                    <select name="patient_id" id="patient_id" class="form-control selectpicker"
                                    data-live-search="true" required="">
                                    <?=options(
                                        'patient',
                                        array(), 
                                        array('record_id','name'),
                                        'record_id',
                                        '',
                                        'record_id',
                                        'desc',
                                        'Select Patient',isset($value)?$value->patient_id:0,array('name','gender','age','mobile'))
                                        ?>
                                    </select>

                                    <span class="input-group-addon">
                                        <button type="button" id="c_plus" style="height: 20px;"
                                        class="btn btn-success fa fa-plus-square btn-sm" data-toggle="modal" data-target="#patientModal">
                                    </button>
                                </span>
                            </div>
                        </div>
                        <div class="form-group col-sm-3">
                            <label for="donor_name">Donor Name (<span class="required">*</span>) </label>
                            <input type="text" class="form-control" id="donor_name" placeholder="Enter Donor Name" name="donor_name" value="<?=isset($value)?$value->donor_name:''?>" required >
                        </div>
                        <div class="form-group col-sm-3">
                            <label for="donor_name">Age </label>
                            <input type="text" class="form-control text-right numeric" id="donor_age" placeholder="Enter Donor Age" name="donor_age" value="<?=isset($value)?$value->donor_age:''?>" >
                        </div>
                    </div>
                    
                    <div class="row"> 
                        <div class="form-group col-sm-3 col-xs-12">
                            <label for="doctor_id">Reference Doctor</label>
                            <select name="doctor_id" id="doctor_id" class="form-control selectpicker"
                                    data-live-search="true">
                                <?=options(
                                    'doctor',
                                    array(), 
                                    array('record_id','name'),
                                    'record_id',
                                    '',
                                    'record_id',
                                    'asc',
                                    'Select Doctor',isset($value)?$value->doctor_id:0,array('name','designation','mobile'))
                                    ?>
                            </select>
                        </div>
                        <div class="form-group col-sm-3 col-xs-12">
                            <label for="blood_group_id">Blood Group</label>
                            <select name="blood_group_id" id="blood_group_id" class="form-control selectpicker"
                                    data-live-search="true" >
                                <?=options(
                                    'blood_groups',
                                    array(), 
                                    array(),
                                    'record_id',
                                    'group_name',
                                    'record_id',
                                    'asc',
                                    'Select Blood Group',isset($value)?$value->blood_group_id:0)
                                    ?>
                            </select>
                        </div>
                        <div class="form-group col-sm-3 col-xs-12">
                            <label for="test_id">Test Name</label>
                            <select name="test_id" id="test_id" class="form-control selectpicker"
                                    data-live-search="true">
                                <?=options(
                                    'test_name',
                                    array(), 
                                    array('record_id','test_name'),
                                    'record_id',
                                    '',
                                    'record_id',
                                    'asc',
                                    'Select Test Name',isset($value)?$value->test_id:0,array('test_price'))
                                    ?>
                            </select>
                        </div>
                        <div class="form-group col-sm-3">
                            <label for="donor_name">Test Price </label>
                            <input type="text" class="form-control text-right numeric" id="test_price" placeholder="Enter Test Price" name="test_price" value="<?=isset($value)?$value->test_price:''?>" >
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-sm-3">
                            <label for="others_cost">Others Cost </label>
                            <input type="text" class="form-control text-right numeric" id="others_cost" placeholder="Enter Other Cost" name="others_cost" value="<?=isset($value)?$value->others_cost:''?>" >
                        </div>
                        <div class="form-group col-sm-3">
                            <label for="discount_amount">Discount </label>
                            <input type="text" class="form-control text-right numeric" id="discount_amount" placeholder="Enter Discount" name="discount_amount" value="<?=isset($value)?$value->discount_amount:''?>" >
                        </div><div class="form-group col-sm-3">
                            <label for="discount_amount">Sub-Total </label>
                            <input type="text" class="form-control text-right numeric" id="sub_total_amount" placeholder="Sub-Total" name="sub_total_amount" value="<?=isset($value)?$value->sub_total_amount:''?>" readonly>
                        </div><div class="form-group col-sm-3">
                            <label for="discount_amount">Paid </label>
                            <input type="text" class="form-control text-right numeric" id="paid_amount" placeholder="Enter Paid" name="paid_amount" value="<?=isset($value)?$value->paid_amount:''?>" >
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-sm-3">
                            <label for="due_amount">Due </label>
                            <input type="text" class="form-control text-right numeric" id="due_amount" placeholder="Due" name="due_amount" value="<?=isset($value)?$value->due_amount:''?>" readonly >
                        </div>
                        <div class="form-group col-sm-3">
                            <label for="comments">Comments</label>
                            <textarea class="form-control" id="comments" placeholder="" rows="1" cols="12" name="comments"><?=isset($value)?$value->comments:''?></textarea>
                        </div>
                         <div class="form-group col-sm-3">
                            <div class="box-footer1 clearfix">
                    <button type="submit" class="pull-left btn btn-success mt-25">Submit <i class="fa fa-arrow-circle-right"></i></button>
                </div>
                         </div>
                    </div>
                </div>
                
            </form>
        </div>
    </section>
</div>
</section>
</aside>
<script type="text/javascript">
    $(document).on('keyup','#test_price,#others_cost,#discount_amount',function(e){
        calculate();
    })
    $(document).on('keyup','#paid_amount',function(e){
        var sub_total_amount = paid_amount = due_amount = 0 ;
        sub_total_amount = $('#sub_total_amount').val() ;
        sub_total_amount = +sub_total_amount ;
        paid_amount = $(this).val() ;
        paid_amount = +paid_amount ;
        if(paid_amount > sub_total_amount){
            alert('Paid should be less than or equal sub_total_amount!');
            paid_amount = sub_total_amount ;
            $(this).val(paid_amount);
        }
        due_amount = sub_total_amount - paid_amount ;
        $('#due_amount').val(due_amount);
    })
    $(document).on('change','#test_id',function(e){
        var test_price = 0, option ;
        option = $('#test_id option:selected') ;
        test_price = option.data('test_price') ;
        test_price = +test_price ;
        $('#test_price').val(test_price);
        calculate() ;
    })

    function calculate(){
        var test_price = others_cost = discount_amount = sub_total_amount = paid_amount = due_amount = 0 ;
        test_price = $('#test_price').val();
        test_price = +test_price ;
        others_cost = $('#others_cost').val();
        others_cost = +others_cost ;
        discount_amount = $('#discount_amount').val() ;
        discount_amount = +discount_amount ;
        sub_total_amount = paid_amount = test_price + others_cost - discount_amount;
        $('#sub_total_amount').val(sub_total_amount);
        $('#paid_amount').val(paid_amount);
        $('#due_amount').val(0);
    }
</script>