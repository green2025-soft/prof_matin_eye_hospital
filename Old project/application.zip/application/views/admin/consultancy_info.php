<style>
    table.table-bordered{
        border: grey 1px solid !important;
        font-weight: bold !important;
        color: black !important;
        font-size: 13px !important;
    }
    table.table-bordered > thead > tr > th{
        border: grey 1px solid !important;
        font-weight: bold !important;
        color: white !important;
        font-size: 13px !important;
        background: #0aad87 !important;
    }
    table.table-bordered > tbody > tr > td{
        border: grey 1px solid !important;
        font-weight: bold !important;
        color: black !important;
        font-size: 13px !important;
    }
</style>

<?php
if ($msg == "main") {
    $msg = "";
} elseif ($msg == "empty") {
    $msg = "Please fill out all required fields";
} elseif ($msg == "created") {
    $msg = "Created Successfully";
} elseif ($msg == "edit") {
    $msg = "Edited Successfully";
} elseif ($msg == "delete") {
    $msg = "Deleted Successfully";
} elseif ($msg == "active") {
    $msg = "ID is active Now";
} elseif ($msg == "inactive") {
    $msg = "ID is inactive Now";
}
?>
<aside >
    <section class="content">
        <div class="row">
            <section class="col-xs-12 connectedSortable" id="full_page">
                <div class="box box-info no_print">
                    
                  
                    <div>
                        <h3 style="color: blue; text-align: center;">All Consultation Info.</h3>
                    </div>

                    <!--                    <div class="row">
                                            <div class="form-group col-sm-4 col-xs-12">
                                                <label for="s_date">Search By Date</label>
                                                <input type="text" name="s_date" id="s_date" class="form-control new_datepicker">
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group col-sm-4 col-xs-12">
                                                <button type="button" class="pull-left btn btn-success" id="search_appointment">Search &nbsp<i
                                                        class="fa fa-search"></i></button>
                                            </div>
                                        </div>-->

                    <div class="box-body table-responsive" style="width: 100%; overflow-x: scroll; color: black;"
                         id="appointment">
                        <table id="datatable" class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th style="text-align: center;">SL</th>
                                    <th style="text-align: center;">Patient[ID]</th>
                                    <th style="text-align: center;">Mobile</th>
                                    <th style="text-align: center;">Address</th>
                                    <th style="text-align: center;">Age</th>
                                    <th style="text-align: center;">Doctor</th>
                                    <th style="text-align: center;">Fee</th>
                                    <th style="text-align: center;">Discount</th>
                                    <th style="text-align: center;">S.Total</th>
                                    <th style="text-align: center;">Commission</th>
                                    <th style="text-align: center;">Hospital</th>
                                    <th style="text-align: center;">Appt_Date</th>
                                    <th style="text-align: center;">Appt_Time</th>
                                    <th style="text-align: center;">Created By</th>
                                    <th style="text-align: center;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $count = 0;
                                foreach ($all_value as $single_value) {
                                    $count++;
                                    ?>
                                    <tr>
                                        <td style="text-align: center;"><?php echo $count; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->patient_name . "[" . $single_value->patient_id . "]"; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->mobile; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->address; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->age; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->doctor_name . " [" . $single_value->designation . "]"; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->doctor_fee; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->discount; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->sub_total; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->doctor_commission; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->company_commission; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->date; ?></td>
                                        <td style="text-align: center;"><?php echo date("h:i A", strtotime($single_value->appointment_time)); ?></td>
                                       <td style="text-align: center;">
                                        <?php
                                          $createdBy = $single_value->created_by ;
                                          $user_name = '' ;
                                          if($createdBy == 1){
                                            $user = $this->Common_model->findById('admin',array('record_id'=>$createdBy));
                                            $user_name = isset($user)?$user->name:'';
                                          }elseif($createdBy > 1){
                                            $user = $this->Common_model->findById('staff',array('record_id'=>$createdBy));
                                            $user_name = isset($user)?$user->name:'';
                                          }
                                          echo $user_name ;
                                        ?>
                                        </td>
                                        <td style="text-align: center;">
                                            <a style="margin: 5px;"
                                               href="<?php echo base_url(); ?>Show_edit_form/invoice_app/<?php echo $single_value->record_id; ?>"
                                               class="btn btn-success">Invoice
                                            </a>
                                            <a style="margin: 5px;" class="btn btn-info"
                                               href="<?php echo base_url(); ?>Show_edit_form/consultancy/<?php echo $single_value->record_id; ?>/main"><i class="fa fa-pencil"></i>
                                            </a>
                                            <a style="margin: 5px;"
                                               href="<?php echo base_url(); ?>Delete/consultancy/<?php echo $single_value->record_id; ?>"
                                               class="btn btn-danger" onclick="return confirm('Are you sure to delete this record?')"><i class="fa fa-trash-o"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>

                        </table>
                    </div><!-- /.box-body -->
                </div>
            </section>
        </div>
    </section>
</aside>

<script type="text/javascript">

    var c_status = 0;

    $('#c_plus').on('click', function () {
        $('#patient_id').selectpicker('hide');
        $('#new_patient').show();
        $('#c_back').show();
        $('#patient_id').hide();
        $('#c_plus').hide();
        c_status = 1;
        $('#mobile').val('');
        $('#age').val('');
    });


    $('#c_back').on('click', function () {
        $('#patient_id').selectpicker('show');
        $('#new_patient').hide();
        $('#c_back').hide();
        $('#patient_id').show();
        $('#c_plus').show();
        $('#new_patient').val('');
        c_status = 0;
    });
//    Add and Insert Patient End
    $("#patient_id").on("change paste keyup", function () {
        var patient = $('#patient_id').val().split("###");
        var patient_id = patient[0];
        var patient_name = patient[1];
        var post_data = {
            'patient_id': patient_id,
            '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
        };

        $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>Get_ajax_value/get_patient_age_mobile_address",
            data: post_data,
            dataType: 'json',
            success: function (data) {
                $('#age').val(data[0]);
                $('#mobile').val(data[1]);
                $('#address').val(data[2]);
            }
        });
    });

    $("#discount, #doctor_commission").on("change paste keyup", function () {
        var discount = $('#discount').val();
        var doctor_commission = $('#doctor_commission').val();
        if (discount == "") {
            discount = 0;
        }

        if (doctor_commission == "") {
            doctor_commission = 0;
        }
        if(discount > 0){
            $('#referenceByDiv').show('fast');
        }else{
            $('#referenceByDiv').hide('fast');
        }
        var doctor_fee = $('#doctor_fee').val();
        var sub_total = parseFloat(doctor_fee) - parseFloat(discount);
        var company_commission = parseFloat(sub_total) - parseFloat(doctor_commission);
        $('#sub_total').val(sub_total);
        $('#company_commission').val(company_commission);
    });

    $("#doctor_name,#patient_id").on("change paste keyup", function () {
        var $option = $('#doctor_name').find('option:selected');
        var doctor_id = $option.data('id') ;
        var patient_id = $('#patient_id').find('option:selected').data('id');
        var post_data = {
            'doctor_id': doctor_id,
            'patient_id': patient_id,
            '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
        };

        $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>Get_ajax_value/get_doctor_fee",
            data: post_data,
            dataType: 'json',
            success: function (data) {
                $('#doctor_fee').val(data.doctor_fee);
                $('#sub_total').val(data.doctor_fee);
                $('#doctor_commission').val(data.commission_fee);
                $('#discount').val(0);
                $('#company_commission').val(data.doctor_fee - data.commission_fee);
            }
        });
        setTimeout(function(e){
            $('#discount').trigger('keyup');
        },1000)
    });

    $('#search_appointment').on('click', function () {
        var date = $('#s_date').val();
        var post_data = {
            'date': date,
            '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
        };
        $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>Get_ajax_value/appointment_by_date",
            data: post_data,
            success: function (data) {
                $('#appointment').html(data);
            }
        });
    });

    $("#submit").click(function () {
        var sub_total = $('#sub_total').val();
        var doctor_commission = $('#doctor_commission').val();
        if (doctor_commission > sub_total) {
            alert("Doctor Commision is more than Sub-total Amount");
        } else {
            var date = $('#date').val();
            if (c_status == 1) {
                var patient_id = "";
                var patient_name = $('#new_patient').val();
            } else {
                var patient = $('#patient_id').val().split("###");
                var patient_id = patient[0];
                var patient_name = patient[1];
            }
            var doctor = $('#doctor_name').val().split("###");
            var doctor_id = $('#doctor_name').find('option:selected').data('id') ;
            var doctor_name = doctor[0];
            var doctor_designation = doctor[1];

            var age = $('#age').val();
            var mobile = $('#mobile').val();
            var address = $('#address').val();
            var doctor_fee = $('#doctor_fee').val();
            var discount = $('#discount').val();
            var reference_by = $('#reference_by').val();
            var sub_total = $('#sub_total').val();
            var doctor_commission = $('#doctor_commission').val();
            var company_commission = $('#company_commission').val();
            var appointment_time = $('#appointment_time').val();

            if(patient_name == '' || doctor_name == '' || mobile == '' || age == '' || doctor_fee == '' || date == '' || appointment_time == ''){
                alert('Please, fill up all required fields!');
                return false;
            }

           // var post_data = {} ;

            var post_data = {
                'date': date,
                 'patient_id': patient_id, 
                 'patient_name': patient_name, 
                 'doctor_designation': doctor_designation, 
                 'doctor_id':doctor_id,
                  'doctor_name': doctor_name, 
                  'age': age,'address': address, 
                  'doctor_fee': doctor_fee, 
                  'appointment_time': appointment_time, 
                  'mobile': mobile, 
                  'c_status': c_status,
                  'discount': discount,
                  'reference_by':reference_by, 
                  'sub_total': sub_total, 
                  'doctor_commission':doctor_commission, 
                  'company_commission': company_commission,
                  '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>'
            };


            $.ajax({
                type: "POST",
                url: "<?php echo base_url(); ?>Get_ajax_value/consultancy_confirm",
                data: post_data,
                success: function (data) {
                    console.log(data);
                    window.location.replace("<?php echo base_url(); ?>Show_edit_form/invoice_app/" + data);
                }
            });
        }
    });
</script>

<script>
    $(document).ready(function () {
        datatable();
    });
    function datatable() {
        $('#datatable').dataTable({
            //"info":false,
            "autoWidth": false,
            "order": false,
            "oSearch": {"bSmart": false}
        });
    }
</script>

<style>
    @media print {
        @page 
        {
            size: A4 landscape;   /* auto is the current printer page size */
            margin: -5mm 0mm 0mm 10mm;
        }
        html
        {
            background-color: #FFFFFF; 
            margin: 0px;  /* this affects the margin on the html before sending to printer */
        }
        .no_print {
            display: none;
        }
        ::-webkit-scrollbar{
            display: none;
        }
        .dataTables_filter {
            display: none;
        }
        .dataTables_paginate {
            display: none;
        }
        .dataTables_info {
            display: none;
        }
        .dataTables_length {
            display: none;
        }
        .dataTables_orderable{
            display: none;
        }
        table.dataTable thead .sorting:after,
        table.dataTable thead .sorting_asc:after,
        table.dataTable thead .sorting_desc:after {
            display: none;
        }
    }
</style>