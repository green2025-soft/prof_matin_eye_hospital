<?php $contact = $this->Common_model->findById('contact',array('id'=>1)) ;
   $img_url = "assets/img/logo.jpg" ;
    if(file_exists($contact->logo)){
        $img_url = $contact->logo ;
    }
    $img_url = base_url($img_url) ;
?>
<div style="position: absolute;right: 10px;" class="no_print">
  <button  id="print" onclick="window.print()" class="btn btn-warning waves-effect waves-light">
    <i class="fa fa-print"></i>
  </button>
  <a href="<?=isset($redirect)?$redirect:'#'?>">
    <button class="btn btn-danger waves-effect waves-light">
      <i class="fa fa-times"></i>
    </button> 
  </a>
</div>
<div style="color: black; text-align: left; margin: 0px; padding: 0px; padding-top: 20px; border-radius: 10px !important;">
  <p style="font-weight: bold; padding: 0px; margin:0px; font-size: 30px;">
     <span><?=isset($doctor)?$doctor->name:''?></span>
   </p>
   <p style="font-weight: bolder; padding: 0px; margin:0px; font-size: 16px;"><?=isset($doctor)?$doctor->designation:''?></p>
   <p style="font-weight: normal; padding: 0px; margin:0px; font-size: 16px;"><?=isset($doctor)?$doctor->working_place:''?></p>
</div>
<div style="color: black; text-align: left; margin: 0px; padding: 0px; padding-top: 2px; border-radius: 10px !important;display:none;">
  <p style="font-weight: bold; padding: 0px; margin:0px; font-size: 18px;">
     <span><?=isset($contact)?$contact->c_name:''?></span>
   </p>
   <p style="font-weight: normal; padding: 0px; margin:0px; font-size: 16px;"><?=isset($contact)?$contact->address:''?></p>
   <p style="font-weight: normal; padding: 0px; margin:0px;font-size: 16px;">Mobile: <?=isset($contact)?$contact->hotline:''?><?=isset($contact)?!empty($contact->hotline2)?', '.$contact->hotline2:'':''
   ?><?=isset($contact)?!empty($contact->hotline3)?', '.$contact->hotline3:'':''?></p>
</div>