<?php $contact = $this->Common_model->findById('contact', array('id' => 1));
$img_url = "assets/img/logo.jpg";
if (file_exists($contact->logo)) {
  $img_url = $contact->logo;
}
$img_url = base_url($img_url);
$img_url_new = base_url('assets/img/logo/bipsh-logo.png');
?>
<div style="position: absolute;right: 10px;" class="no_print">
<?php if(isset($hide) && isset($chalanLink) ){ ?>
  <!-- <a href="<?=$chalanLink?>" class="no_print btn btn-success waves-effect waves-light">
    <i class="fa fa-print">Challan</i>
  </a> -->
  <?php } ?>
  <button id="print" onclick="window.print()" class="btn btn-warning waves-effect waves-light">
    <i class="fa fa-print"></i>
  </button>
  <a href="<?= isset($redirect) ? $redirect : "javascript:void(0)" ?>" <?php if (empty($redirect)) { ?> onclick="window.history.back();" <?php } ?>>
    <button class="btn btn-danger waves-effect waves-light">
      <i class="fa fa-times"></i>
    </button>
  </a>
</div>


<div style="color: black; text-align: center; margin: 0px; padding: 0px; padding-top: 20px; border-radius: 10px !important;">
  <div class="row">
    <div class="col-md-12 text-center">
      <div style="display: inline-block;">
        <img src="<?=$img_url?>" alt="Logo" width="60" style="vertical-align: middle; margin-right: 10px;">
        <span class="hospital_title" style="vertical-align: middle;"><b><?=isset($contact)?$contact->c_name:''?></b></span>
      </div>
    </div>
    <div class="col-md-12 col-sm-12 col-xs-12 text-center">
      <p class="hospital_address"><?=isset($contact)?$contact->address:''?> <br><?=isset($contact)?$contact->hotline:''?></p>
    </div>
  </div>

</div>