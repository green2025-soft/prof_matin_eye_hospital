<br>
<div class="row">
    <div class="col-xs-4">
        <div class="barcode">
            <?php
            $barcodeUrl = "assets/img/barcode.jpg";
            if (isset($value)) {
                $barcode = "assets/img/barcode/$value->record_id.jpg";
                if (file_exists($barcode)) {
                    $barcodeUrl = $barcode;
                }
            }
            $barcodeUrl = base_url($barcodeUrl);

            ?>
            <img src="<?= $barcodeUrl ?>" class="img-responsive">
        </div>
        <div class="money-receipt hide">
            <p>Money Receipt</p>
        </div>
    </div>
    <div class="col-xs-4">
        <div class="customer-copy">
            <p>Money Receipt</p>
        </div>
        <div class="original-copy hide">
            <p>Original Copy</p>
        </div>
    </div>
    <div class="col-xs-4">
        <div class="row barcode">
            <img src="<?= $barcodeUrl ?>" class="img-responsive pull-right">
        </div>
        <div class="row date">
            <p><b>Date: </b><?= isset($value) ? date('d/m/Y', strtotime($value->date)) : '' ?></p>
        </div>
    </div>
</div>