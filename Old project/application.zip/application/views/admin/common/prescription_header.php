<?php $contact = $this->Common_model->findById('contact',array('id'=>1)) ;
   $img_url = "assets/img/logo.jpg" ;
    if(file_exists($contact->logo)){
        $img_url = $contact->logo ;
    }
    $img_url = base_url($img_url) ;
    
?>
<div style="position: absolute;right: 10px;" class="no_print">
  <button  id="print" onclick="window.print()" class="btn btn-warning waves-effect waves-light">
    <i class="fa fa-print"></i>
  </button>
  <a href="<?=isset($redirect)?$redirect:'#'?>">
    <button class="btn btn-danger waves-effect waves-light">
      <i class="fa fa-times"></i>
    </button> 
  </a>
</div>
<div style="color: black; text-align: center; margin: 0px; padding: 0px; padding-top: 20px; border-radius: 10px !important;">
 

<table width="100%" style="font-weight: bold; padding: 0px; margin:0px; font-size: 20px; text-align: center;">
  <tr>
    
    <td>
    <img src="<?= $img_url ?>" style="border-radius: 10px; height: 40px;" alt="Logo">  
    <span style="font-size: 25px;"><?= isset($contact) ? $contact->c_name : '' ?></span>
    </td>
    
  </tr>
</table>

  