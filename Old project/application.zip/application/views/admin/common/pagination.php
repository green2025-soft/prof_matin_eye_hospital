<style>
    .page-item:hover{
        cursor: pointer;
    }
    #paginator-div {
        width: 79%;
        display: inline-block;
    }

    .justify-content-end {
        justify-content: flex-end !important;
    }

    .pagination {
        display: flex;
        padding-left: 0;
        list-style: none;
        border-radius: 0.42rem;
    }

    .disabled-page-link {
        position: relative;
        display: block;
        padding: 0.5rem 0.75rem;
        margin-left: -1px;
        line-height: 1.25;
        background-color: #eee;
        border: 1px solid #ebedf2;
    }

    .page-link {
        position: relative;
        display: block;
        padding: 0.5rem 0.75rem;
        margin-left: -1px;
        line-height: 1.25;
        color: #3699FF;
        background-color: #ffffff;
        border: 1px solid #E4E6EF;
    }

    .page-item.active .page-link {
        z-index: 3;
        color: #ffffff;
        background-color: #3699FF;
        border-color: #3699FF;
    }

    .pagination {
        display: flex;
        padding-left: 0;
        list-style: none;
        border-radius: 0.42rem;
    }

    .page-link {
        position: relative;
        display: block;
        padding: 0.5rem 0.75rem;
        margin-left: -1px;
        line-height: 1.25;
        color: #3699FF;
        background-color: #ffffff;
        border: 1px solid #E4E6EF;
    }

    .page-link:hover {
        z-index: 2;
        color: #0073e9;
        text-decoration: none;
        background-color: #EBEDF3;
        border-color: #E4E6EF;
    }

    .page-link:focus {
        z-index: 3;
        outline: 0;
        box-shadow: none;
    }

    .page-item:first-child .page-link {
        margin-left: 0;
        border-top-left-radius: 0.42rem;
        border-bottom-left-radius: 0.42rem;
    }

    .page-item:last-child .page-link {
        border-top-right-radius: 0.42rem;
        border-bottom-right-radius: 0.42rem;
    }

    .page-item.active .page-link {
        z-index: 3;
        color: #ffffff;
        background-color: #3699FF;
        border-color: #3699FF;
    }

    .page-item.disabled .page-link {
        color: #7E8299;
        pointer-events: none;
        cursor: auto;
        background-color: #ffffff;
        border-color: #EBEDF3;
    }

    .pagination-lg .page-link {
        padding: 0.75rem 1.5rem;
        font-size: 1.08rem;
        line-height: 1.5;
    }

    .pagination-lg .page-item:first-child .page-link {
        border-top-left-radius: 0.85rem;
        border-bottom-left-radius: 0.85rem;
    }

    .pagination-lg .page-item:last-child .page-link {
        border-top-right-radius: 0.85rem;
        border-bottom-right-radius: 0.85rem;
    }

    .pagination-sm .page-link {
        padding: 0.25rem 0.5rem;
        font-size: 0.925rem;
        line-height: 1.35;
    }

    .pagination-sm .page-item:first-child .page-link {
        border-top-left-radius: 0.28rem;
        border-bottom-left-radius: 0.28rem;
    }

    .pagination-sm .page-item:last-child .page-link {
        border-top-right-radius: 0.28rem;
        border-bottom-right-radius: 0.28rem;
    }
</style>

<?php
$page_limit = 10;
?>
<ul class="pagination justify-content-end">
    <li class="page-item page_navigate" data-page="P">
        <?php if ($current_page == 1) : ?>
            <span class="disabled-page-link">Previous</span>
        <?php else : ?>
            <a class="page-link without_page_number" data-page="<?php echo $current_page - 1; ?>">Previous</a>
        <?php endif; ?>
    </li>
    <?php $j = 1; ?>
    <?php if ($pages >= 1 && $current_page <= $pages) : ?>
        <?php
        $counter = 1;
        $l = 1;
        $is_dotted_after_one = false;
        if ($current_page >= ceil($page_limit / 2) && $pages > $page_limit) {
            $is_dotted_after_one = true;
        ?>
            <li class="page-item page-number <?= ($current_page == 1) ? "active" : '' ?> page-<?= 1 ?>" data-page="<?= 1 ?>">
                <a class="page-link"><?= 1 ?></a>
            </li>
            <li class="page-item dotted-page-link">
                ...
            </li>

            <?php
        } else if ($current_page < ceil($page_limit / 2) && $pages > $page_limit) {
            for ($x = 1; $x <= $current_page - 1; $x++) {
            ?>
                <li class="page-item page-number <?= ($current_page == $x) ? "active" : '' ?> page-<?= $x ?>" data-page="<?= $x ?>">
                    <a class="page-link"><?= $x ?></a>
                </li>
            <?php
                $l++;
                $counter++;
            }
        }
        if ($pages > $page_limit) {
            $loop_cnt = $current_page;

            if ($current_page > ceil($page_limit / 2)) {
                $loop_cnt = $current_page - (($current_page - ceil($page_limit / 2)) % ceil($page_limit / 2));
            }

            if (($pages - $loop_cnt) < $page_limit && $pages > $page_limit) {
                $loop_diff = ($pages - $loop_cnt);

                $loop_diff = $page_limit - $loop_diff;
                if ($loop_diff == 1) {
                    $loop_diff++;
                } else {
                    $loop_cnt = $loop_cnt - ($loop_diff - 1);
                }
            }

            if ($loop_cnt == $current_page) {
                if (($current_page - ceil($page_limit / 2)) % ceil($page_limit / 2) >= 0) {
                    $loop_cnt--;
                    $counter++;
                }
            }

            /*if ( $current_page == $pages )
                {
                    $loop_cnt = $current_page - 2;
                }*/
            if ($loop_cnt <= 0) {
                $loop_cnt = $current_page;
            }
        } else {
            $loop_cnt = 1;
        }
        if ($loop_cnt < $l) {
            $loop_cnt = $l;
        }
        if ($is_dotted_after_one && $loop_cnt == 2) {
            $loop_cnt++;
        }
        $P = $loop_cnt;
        //echo $loop_cnt . "  " . $l;
        for ($x = $loop_cnt; $x <= $pages; $x++) {
            if ($counter <= $page_limit) {
            ?>
                <li class="page-item page-number <?= ($current_page == $x) ? "active" : '' ?> page-<?= $x ?>" data-page="<?= $x ?>">
                    <a class="page-link" data-page="<?= $x ?>"><?= $x ?></a>
                </li>
            <?php
                $P += 1;
            }
            $counter++;
        }
        //echo $pages . "  " . $P . "  " . ($current_page < $pages - ceil($page_limit/2));
        if (($current_page < $pages - ceil($page_limit / 2) && $pages > $page_limit && $P < $pages) || $P == $pages) {
            ?>
            <?php if ($P < $pages) : ?>
                <li class="page-item dotted-page-link">
                    ...
                </li>
            <?php endif; ?>
            <li class="page-item page-number <?= ($current_page == $pages) ? "active" : '' ?> page-<?= $pages ?>" data-page="<?= $pages ?>">
                <a class="page-link" data-page="<?= $pages?>"><?= $pages ?></a>
            </li>
        <?php
        }
        ?>
    <?php endif; ?>
    <li class="page-item page_navigate" data-page="N">
        <?php if ($current_page == $pages) : ?>
            <span class="disabled-page-link">Next</span>
        <?php else : ?>
            <a class="page-link without_page_number" data-page="<?php echo $current_page + 1; ?>">Next</a>
        <?php endif; ?>

    </li>
    <input type="hidden" id="max_page" value="<?= $j - 1 ?>">
</ul>