<style>
.sign{
    margin-bottom: 5px;
}
.signature div{
    text-align: left;
}
.signature div p{
    margin: 0;
}
.signature .sign{
    margin-left: 50px;
}
.signature .desi{
    font-size: 13px;

}
</style>
<div class="row signature result-input-footer" style="margin-left: -50px;">

   
    
    <div class="col-sm-4 col-xs-6 pull-left">
    <?php if($testDetails->dutyDoctor){
        if(file_exists($testDetails->dutyDoctor->signature)){
            $docimgUrl = base_url($testDetails->dutyDoctor->signature);
        ?>
        <img src="<?=$docimgUrl?>" height="50" class="sign">
       <?php } else{?>
            <span style="height: 55px; width: 100%; display: block;"> &nbsp;</span>
        <?php } ?>
        <p></p>
        <span style="font-weight: bold;"><?= $testDetails->dutyDoctor->name?></span><br>
        <span class="desi"><?= $testDetails->dutyDoctor->designation?></span><br>
        <span class="desi"><?= nl2br($testDetails->dutyDoctor->description)?></span>
        <?php } ?>
    </div>
    
    <div class="col-sm-4 col-xs-6 pull-right">
    <?php if($testDetails->dutyStaff){
        
        if(file_exists($testDetails->dutyStaff->signature)){
            $imgUrl = base_url($testDetails->dutyStaff->signature);
        ?>
        <img src="<?=$imgUrl?>" height="50" class="sign">
        <?php } else{?>
            <span style="height: 55px; width: 100%; display: block;"> &nbsp;</span>
        <?php } ?>
        <p></p>
       <span style="font-weight: bold;"><?= $testDetails->dutyStaff->name?></span><br>
        <span class="desi"><?= $testDetails->dutyStaff->designation?></span><br>
        <span class="desi"><?= nl2br($testDetails->dutyStaff->description)?></span>
        <?php } ?>
    </div>

     <div class="col-sm-4 col-xs-4">
    <?php if($testDetails->dutyStaff2){
        
        if(file_exists($testDetails->dutyStaff2->signature)){
            $imgUrl = base_url($testDetails->dutyStaff2->signature);
        ?>
        <img src="<?=$imgUrl?>" height="50" class="sign">
        <?php } else{?>
            <span style="height: 55px; width: 100%; display: block;"> &nbsp;</span>
        <?php } ?>
        <p></p>
       <span style="font-weight: bold;"><?= $testDetails->dutyStaff2->name?></span><br>
        <span class="desi"><?= $testDetails->dutyStaff2->designation?></span><br>
        <span class="desi"><?= nl2br($testDetails->dutyStaff2->description)?></span>
        <?php } ?>
    </div>

</div>