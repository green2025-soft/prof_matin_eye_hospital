<div class="row signature">
<div class="col-sm-4 col-xs-4">
        <p>Director</p>
    </div>
    <div class="col-sm-4 col-xs-4">
        <p>MD</p>
    </div><div class="col-sm-4 col-xs-4">
        <p>Chairman</p>
    </div>
    <div class="col-sm-3 col-xs-3 hide">
    	<?php
            $user_type = $this->session->userdata('ses_user_type');
            $record_id = $this->session->userdata('ses_record_id');
            $created_by = 0 ;
            if(isset($value)){
            	$created_by = $value->created_by ;
            }
            $name = '' ;
            if($created_by == 1){
                $user = $this->Common_model->findById('admin',array('record_id'=>$created_by));
                $name = isset($user)?$user->name:'' ;
            }else{
                $user = $this->Common_model->findById('staff',array('record_id'=>$created_by));
                $name = isset($user)?$user->name:'' ;
            }
            
        ?>
        
        <?php if(isset($duty_staff)){ ?>
            <p><?=$duty_staff->name.' - ' . $duty_staff->designation?></p>
        <?php }else{?>
            <span></span>
            <p><?=$name;?></p>
        <?php } ?>
    </div>
</div>