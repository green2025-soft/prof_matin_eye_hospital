
<div style="position: absolute;right: 10px;z-index: 99999999999" class="no_print">
  <button  id="print" onclick="window.print()" class="btn btn-warning waves-effect waves-light">
    <i class="fa fa-print"></i>
  </button>
  <a href="<?=isset($redirect)?$redirect:'#'?>">
    <button class="btn btn-danger waves-effect waves-light">
      <i class="fa fa-times"></i>
    </button> 
  </a>
</div>
