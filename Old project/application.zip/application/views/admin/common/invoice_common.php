<style>
    :root{
        --blue:#12396d;
        --fs:15px;
        --fs14:14px;
        --fs16:16px;
        --fs17:17px;
        --fs18:18px;
        --fs19:19px;
        --fs22:22px;
        --fs25:25px;
        --b2:2px solid var(--blue);
        --b1:1px solid var(--blue);
    }
    .bt1{
        border-bottom: var(--b1);
    }
    .text-left{
        text-align: left !important;
    }
    .text-right{
        text-align: right !important;
    }

    /* GENERAL */
    *{box-sizing:border-box}

    body{
        margin:0;
        padding:0;
        background:#eee;
        color:#000;
        font-family:Arial,Helvetica,sans-serif;
    
    }

    body, 
    .table-borderless td,
    .table-borderless th, 
    .hospital-address, 
    .info-row,
    .contact-line, 
    .bill-table>thead>tr>th, 
    .bill-table>tbody>tr>td,
    .note-title, 
    .summary-row, 
    .bottom-info, 
    .footer-box
    {
        font-size:var(--fs17);
    }

    .blue,
    .info-label,
    .note-title,
    .paid,
    .bottom-info,
    .bottom-info strong,
    .footer-box,
    .hospital-title,
    .bill-title,
    .contact-line strong{
        color:var(--blue);
    }

    .table-borderless{margin:0}

    .table-borderless td,
    .table-borderless th{
        border:0!important;
        padding:3px 0!important;
    }


    /* BILL */
    .bill{
        width:210mm;
        margin:10px auto;
        padding:8mm;
        background:#fff;
        border:var(--b2);
    }


    /* HEADER */
    .hospital-logo{
        width:85px;
        height:auto;
        display:block;
        margin:0 auto 6px;
    }

    .header-logo img{width:110px}

    .hospital-title{
        margin:4px 0;
        font-size:32px;
        font-weight:bold;
        line-height:1.15;
    }

    .hospital-address{
        margin-bottom:7px;
    }

    .contact-line{
        line-height:1.5;
    }


    /* QR */
    .header-qr img{max-width:110px}

    .qr{
        width:105px;
        height:105px;
        padding:3px;
        margin:6px auto 3px;
        border:var(--b2);
    }

    .qr img{
        width:100%;
        height:100%;
        display:block;
    }


    /* HEADER LINE */
    .header-line{
        margin:8px 0;
        border-top:var(--b2);
    }


    /* TITLE */
    .bill-title{
        margin:5px 0 10px;
        font-size:var(--fs25);
        font-weight:bold;
        text-decoration:underline;
        line-height:1.2;
    }


    /* PATIENT */
    .patient-box{
        margin-bottom:10px;
        padding:9px 14px;
        border:var(--b2);
        border-radius:12px;
    }

    .info-row{
        line-height:1.8;
    }

    .info-label{
        font-weight:bold;
        padding-right:0;
    }

    .info-value{
        padding-right:0;
        /* font-weight:bold; */
    }


    /* TABLE */
    .bill-table{
        margin-bottom:0;
        border:var(--b1);
    }

    .bill-table>thead>tr>th{
        padding:9px 5px;
        /* color:#fff; */
        /* background:var(--blue); */
        border:var(--b1);
        /* border-bottom:var(--b1); */
        
         vertical-align:middle;
    }

    .bill-table>tbody>tr>td{
        padding:10px 5px;
        border:var(--b1);
    }


    .bill-table>tbody>tr>td{
        vertical-align:middle;
    }


    /* NOTE */
    .note-paid{
        min-height:200px;
        position:relative;
        padding:5px 18px;
        border-top:0;
    }

    .note-title{
        font-weight:bold;
    }


    /* PAID */
    .paid{
        position:absolute;
        top:58px;
        left:0;
        right:0;
        width:fit-content;
        padding:0 18px;
        margin:auto;
        border:var(--b2);
        border-radius:10px;
        text-align:center;
        font-size:58px;
        font-weight:bold;
    }


    /* SUMMARY */
    .summary{
        min-height:175px;
        border:var(--b1);
        border-top:0;
    }

    .summary-row{
        height:43.75px;
        padding:11px 13px;
        border-bottom:var(--b1);
        font-weight:bold;
    }

    .summary-row:last-child{border-bottom:0}

    .summary-amount{float:right}


    /* BOTTOM + FOOTER */
    .bottom-info{
        padding:7px 2px 0;
    }

    .footer-box{
        margin-top:8px;
        padding:7px;
        text-align:center;
        border:var(--b2);
        border-radius:10px;
    }

    .footer-box div{line-height:1.5}


    /* MOBILE */
    @media screen and (max-width:768px){

        .bill{
            width:100%;
            min-height:auto;
            margin:0;
            padding:16px;
        }

        .hospital-title{font-size:20px}

        .patient-box{padding:8px}

    }


    /* PRINT */
    @media print{

        @page{size:A4 portrait}

        html,
        body{
            width:210mm;
            min-height:297mm;
            margin:0;
            padding:0;
            background:#fff!important;
        }

        *{
            -webkit-print-color-adjust:exact!important;
            print-color-adjust:exact!important;
        }



        .bill{
            width:100%;
            min-height:0;
            margin:0;
            padding:5mm;
            border:var(--b2);
        }


        /* Print Header */
        .hospital-logo{
            width:78px;
            margin-bottom:4px;
        }

        .hospital-title{
            font-size:32px;
            margin:3px 0;
        }

        .hospital-address{
            margin-bottom:5px;
        }

        .contact-line{
            line-height:1.4;
        }

        .qr{
            width:92px;
            height:92px;
            margin-top:5px;
            margin-bottom:2px;
        }

        .header-line{margin:6px 0}


        /* Print Title + Patient */
        .bill-title{
            font-size:22px;
            margin:4px 0 8px;
        }

        .patient-box{
            padding:7px 12px;
            margin-bottom:8px;
        }

       


        /* Print Table */
        .bill-table>thead>tr>th{
            padding:7px 4px;
            /* background:var(--blue)!important; */
            /* color:#fff!important; */
        }

        .bill-table>tbody>tr>td{
            padding:8px 4px;
        }


        /* Print Note */
        .note-paid{
            min-height:182px;
            padding:4px 14px;
        }


        .paid{
            top:45px;
            font-size:48px;
        }


        /* Print Summary */
        .summary{min-height:145px}

        .summary-row{
            height:36.25px;
            padding:9px 10px;
        }


        /* Print Bottom */
        .bottom-info{
            padding-top:5px;
        }
    

        .footer-box{
            margin-top:6px;
            padding:5px;
        }


        /* Bootstrap */
        .row{
            margin-left:-5px;
            margin-right:-5px;
        }

        [class*="col-"]{
            padding-left:5px;
            padding-right:5px;
        }

    }
</style>

<?php $contact = $this->Common_model->findById('contact',array('id'=>1)) ;
   $img_url = "assets/img/logo.jpg" ;
    if(file_exists($contact->logo)){
        $img_url = $contact->logo ;
    }
    $img_url = base_url($img_url);
    // dd($contact);
    
?>
<div class="content">
    <div style="position: absolute;right: 10px;" class="no_print">
        <button  id="print" onclick="window.print()" class="btn btn-warning waves-effect waves-light">
            <i class="fa fa-print"></i>
        </button>
        <a href="<?=isset($redirect)?$redirect:"javascript:void(0)"?>" <?php if(empty($redirect)){?> onclick="window.history.back();" <?php } ?>>
            <button class="btn btn-danger waves-effect waves-light">
                <i class="fa fa-times"></i>
            </button> 
        </a>
    </div>
    <div class="bill">
        <!-- ================= HEADER ================= -->
        <div class="row bill-header">
            <div class="col-xs-2 text-center header-logo">
                <img src="<?=$img_url?>" alt="<?=$contact->c_name?>">
            </div>
            <!-- CENTER : HOSPITAL INFORMATION -->
             <div class="col-xs-8 text-center header-info">
                 <div class="hospital-title"><?=$contact->c_name?></div>
                 <div class="hospital-address"><?=$contact->address?></div>
                 <div class="contact-line">
                    <strong>HOTLINE:</strong>
                    <?=isset($contact)?$contact->hotline:''?>
                    <?= $contact->hotline2 ? ', '.$contact->hotline2 : '' ?>
                 </div>
                 <div class="contact-line">
                    <strong>E-MAIL:</strong>
                    <?=$contact->email?>
                 </div>
             </div>
            <div class="col-xs-2 text-center header-qr">
                <img src="<?= site_url( $qr_code_url) ?>" alt="QR Code">
            </div>
        </div>
        <div class="header-line"></div>
        <div class="bill-title text-center">  <?= $bill_title ?></div>
         <!-- ================= PATIENT INFORMATION ================= -->
          <?php if(!isset($isNotPatientInfo)):?>
        <div class="patient-box">
            <div class="info-row">
                <table class="table table-borderless">
                    <?php if (isset($drSerialNo)):?>
                    <tr>
                        <td><div class="info-label">Serial No.</div></td>
                        <td colspan="5"><div class="ifo-value">: <?= $drSerialNo ?></div></td>
                    </tr>
                    <?php endif?>
                    <tr>
                        <td style="width: 105px;">
                            <div class="info-label">Invoice No.</div>
                        </td>
                        <td>
                            <div class="info-value">:<b> <?=  $value->invoice_no  ?></b></div>
                        </td>
                        <td style="width: 75px;">
                            <div class="info-label">Date</div>
                        </td>
                        <td>
                            <div class="info-value">: <?= isset($value) ? date("d M Y", strtotime($value->date)): '' ?></div>
                        </td>
                        <td style="width: 70px;">
                            <div class="info-label">Time</div>
                        </td>
                        <td>
                            <div class="info-value">: <?= date("h:i A", strtotime($value->created_at)) ?></div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class="info-label">P.Name</div>
                        </td>
                        <td colspan="3">
                            <div class="info-value">: <b><?= isset($patient) ? $patient->name : '' ?></b></div>
                        </td>
                        
                        <td>
                            <div class="info-label">Age</div>
                        </td>
                        <td>
                            <div class="info-value">: <?= isset($patient) ? calculateCurrentAge($patient) : '' ?></div>
                        </td>
                    </tr>
                    <tr>
                        <td><div class="info-label">Mobile</div></td>
                        <td><div class="info-value">: <?= isset($patient) ? $patient->mobile : '' ?></div></td>
                        <td><div class="info-label">P.ID</div></td>
                        <td><div class="info-value">: <?= isset($patient) ? $patient->record_id : '' ?></div></td>
                        <td><div class="info-label">Gender</div></td>
                        <td><div class="info-value">: <?= isset($patient) ? $patient->gender : '' ?></div></td>
                    </tr>
                    
                    <?php if ($referred_doctor):?>
                    <tr>
                        <td>
                            <div class="info-label">Refd Doctor</div>
                        </td>
                        <td colspan="5">
                            <div class="info-value">:  <?= $referred_doctor ?></div>
                        </td>
                    </tr>
                    <?php endif?>
                </table>
            </div>
        </div>
        <?php endif?>
        <!-- ========================== SERVICE TABLE ==========================  -->
         
        <?php $this->load->view('admin/' . $folder_name . '/item_table', get_defined_vars());?>
            
         

        <!-- =============== AMOUNT IN WORDS  =============== -->
          <div class="bottom-info">
            <p><strong>In Words :</strong> &nbsp; <?= $this->numbertowords->convert_number($in_word_amount) . ' Tk Only.' ?></p>
            <?php if (isset($delivery_date) && $delivery_date):?>
            <p><strong>Delivery Date:</strong> &nbsp; <?=$delivery_date ?></p>
            <?php endif?>
        </div>



        <!-- =============== SIGNATURE  =============== -->
         <div class="bottom-info" style="margin-top: 50px;">
            <table style="width: 100%;">
                <tr>
                    <td> <strong>Auth. Signature</strong></td>
                    <td> <strong>Printed On:</strong>
                            <?= date('d/m/Y h:i A') ?>
                    </td>
                    <td>
                        <strong>Prepared By:</strong>
                         <?= creator($value->created_by) ?>  
                    </td>
                </tr>
            </table>
         </div>

    </div>
</div>
<div class="container">
    <?php $this->load->view('admin/common/copyright') ?>
</div>

