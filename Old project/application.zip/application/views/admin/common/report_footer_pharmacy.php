<style>
   @media print {
   .footersine {
  position: fixed;
  width: 100%;
  bottom: 10px;
  box-sizing: border-box;
}
}
</style>

<div class="row signature1 footersine">
    <div class="col-sm-7 col-xs-7">
        <!-- <p>Signature</p> -->
    </div>
    <div class="col-sm-5 col-xs-5">
   
    	<?php
            $user_type = $this->session->userdata('ses_user_type');
            $record_id = $this->session->userdata('ses_record_id');
            $created_by = 0 ;
            if(isset($value)){
            	$created_by = $value->created_by ;
            }
            $name = '' ;
            if($created_by == 1){
                $user = $this->Common_model->findById('admin',array('record_id'=>$created_by));
                $name = isset($user)?$user->name:'' ;
            }else{
                $user = $this->Common_model->findById('staff',array('record_id'=>$created_by));
                $name = isset($user)?$user->name:'' ;
            }
           // echo $name;
        ?>
         <p ><span style="border-top: 1px dotted #000;">Prepared By: <b><?=$name?></b></span></p>
    </div>
    <div class="col-sm-7 col-xs-7" style="margin-left:150px">

   
    </div>
    <?php $contact = $this->Common_model->findById('contact', array('id' => 1));?>
    <div class="col-sm-12 col-xs-12" style="border-top: 1px solid #000; margin-top:20px; text-align:center; font-weight:bold; front-size:18px; background:#e67e22 !important;">
            <div class="col-xs-12">
                <i class="fa fa-home"></i>
                <?= isset($contact) ? $contact->address : '' ?><br>
                <i class="fa fa-phone"></i>
                <?= isset($contact) ? $contact->hotline : '' ?><?= isset($contact) ? !empty($contact->hotline2) ? ', ' . $contact->hotline2 : '' : ''?>
                <?= isset($contact) ? !empty($contact->hotline3) ? ', ' . $contact->hotline3 : '' : '' ?>
            </div>
            <div class="col-xs-12">
                <i class="fa fa-envelope"></i>
                <?= isset($contact) ? $contact->email : '' ?>
                <i class="fa fa-globe"></i>
                <?= isset($contact) ? ($contact->web) : '' ?>
                
            </div>


        </div>
       
</div>
