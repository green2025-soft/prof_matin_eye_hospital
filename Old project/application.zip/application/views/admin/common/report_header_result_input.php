<?php $contact = $this->Common_model->findById('contact',array('id'=>1)) ;
$img_url = "assets/img/logo.jpg" ;
if(file_exists($contact->logo)){
  $img_url = $contact->logo ;
}
$img_url = base_url($img_url) ;
?>
<div style="position: absolute;right: 10px;top:10%" class="no_print">
  <button  id="print" onclick="window.print()" class="btn btn-warning waves-effect waves-light">
    <i class="fa fa-print"></i>
  </button>
  <a href="<?=isset($redirect)?$redirect:'#'?>">
    <button class="btn btn-danger waves-effect waves-light">
      <i class="fa fa-times"></i>
    </button> 
  </a>
</div>

<!-- <table class="table" style="width: 98%;margin-bottom: -15px;padding-left: 100px;">
  <tbody>
    <tr>
      <td style="width: 20%;border-top: none;">
        <p style="font-weight: bold; padding: 0px; margin:0px; font-size: 30px;">
          <span><img src="<?=$img_url?>" style="border-radius: 10px;width: 80px;height: 80px;"
           alt="Logo"></span>

         </p>
       </td>
       <td style="width: 80%;border-top: none;">
        
            <p style="text-align: right; font-weight: bold; padding: 0px; margin:0px; font-size: 16px;">
              <i class="fa fa-map-marker"></i> <?=isset($contact)?$contact->address:''?></p>
              <p style="text-align: right; font-weight: bold; padding: 0px; margin:0px;font-size: 16px;">

               <i class="fa fa-phone"></i> <?=isset($contact)?$contact->hotline:''?><?=isset($contact)?!empty($contact->hotline2)?', '.$contact->hotline2:'':''
               ?><?=isset($contact)?!empty($contact->hotline3)?', '.$contact->hotline3:'':''?></p>
               <p style="text-align: right; font-weight: bold; padding: 0px; margin:0px; font-size: 16px;">
              <i class="fa fa-envelope"></i> <?=isset($contact)?$contact->email:''?></p>
              <p style="text-align: right; font-weight: bold; padding: 0px; margin:0px; font-size: 16px;">
              <i class="fa fa-globe"></i> <?=isset($contact)?$contact->web:''?></p>
              <p class="c_name" style="padding-left: 100px; font-weight: bolder;font-size: 30px;text-align: left;margin-top: -38px;"><?=isset($contact)?$contact->c_name:''?></p>
             
         </td>
       </tr>
     </tbody>
   </table> -->
   <div style="margin-top: 60px;">&nbsp;</div>

<style type="text/css">
  @media print{
      .c_name{
        padding-left: 10!important;
      }
  }
</style>