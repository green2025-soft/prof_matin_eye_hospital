<div class="row signature">
    <div class="col-sm-6 col-xs-6">
        <!-- <p>Signature</p> -->
    </div>
    <div class="col-sm-6 col-xs-6">
    	<?php
            $user_type = $this->session->userdata('ses_user_type');
            $record_id = $this->session->userdata('ses_record_id');
            $created_by = 0 ;
            if(isset($value)){
            	$created_by = $value->created_by ;
            }
            $name = '' ;
            if($created_by == 1){
                $user = $this->Common_model->findById('admin',array('record_id'=>$created_by));
                $name = isset($user)?$user->name:'' ;
            }else{
                $user = $this->Common_model->findById('staff',array('record_id'=>$created_by));
                $name = isset($user)?$user->name:'' ;
            }
           // echo $name;
        ?>
    <p>     <?=creator($value->created_by)?></p>
    </div>
</div>