<style>
.sign{
    margin-bottom: 5px;
}
</style>
<div class="row signature result-input-footer" style="margin-left: -50px;">

   
    
    <div class="col-sm-4 col-xs-4">
    <?php if($testDetails->duty_doc_name){
        if(file_exists($testDetails->duty_doc_sign)){
            $docimgUrl = base_url($testDetails->duty_doc_sign);
        ?>
        <img src="<?=$docimgUrl?>" height="50" class="sign">
        <?php } ?>
        <p></p>
        <span style="font-weight: bold;"><?= $testDetails->duty_doc_name?></span><br>
        <span><?= $testDetails->duty_doc_designation?></span>
        <?php } ?>
    </div>
    
    <div class="col-sm-4 col-xs-4">
    <?php if($testDetails->staff_name){
        if(file_exists($testDetails->staff_sign)){
            $imgUrl = base_url($testDetails->staff_sign);
        ?>
        <img src="<?=$imgUrl?>" height="50" class="sign">
        <?php } ?>
        <p></p>
        <span style="font-weight: bold;"><?= $testDetails->staff_name?></span><br>
        <span><?= $testDetails->staff_designation?></span>
        <?php } ?>
    </div>
    <div class="col-sm-4 col-xs-4">
    <?php if($testDetails->staff_name2){
        if(file_exists($testDetails->staff_sign2)){
            $imgUrl2 = base_url($testDetails->staff_sign2);
        ?>
        <img src="<?=$imgUrl2?>" height="50" class="sign">
        <?php } ?>
        <p></p>
        <span style="font-weight: bold;"><?= $testDetails->staff_name2?></span><br>
        <span><?= $testDetails->staff2_designation?></span>
        <?php } ?>
    </div>
</div>