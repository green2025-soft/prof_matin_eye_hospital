<div class="row copyright">
	<div class="col-md-12">
		<p>Developed By : Green Software & Technology (greensoftwarebd.com) </p>
	</div>
</div>