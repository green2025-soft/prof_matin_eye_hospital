<div class="form-group col-xs-6"  style="color: black !important; font-size: 17px; padding: 0px 5px 0px 5px; margin: -3px;">
    <b>Invoice No: </b><?=isset($value)?$value->prefix.$value->invoice_no:''?>
</div>

<div class="form-group col-xs-6"  style="text-align: right; color: black !important; font-size: 20px; padding: 0px 5px 0px 5px; margin: -3px;">
    <b>Mobile: </b><?=isset($patient)?$patient->mobile:''?>
</div>
<div class="form-group col-xs-6"  style="color: black !important; font-size: 20px; padding: 0px 5px 0px 5px; margin: -3px;">
    <b>Patient Name: </b><?=isset($patient)?$patient->name:''?>
</div>
<div class="form-group col-xs-6"  style="text-align: right; color: black !important; font-size: 20px; padding: 0px 5px 0px 5px; margin: -3px;">
    <b>Times: </b><?=isset($value)?date('h:m:s A',strtotime($value->created_at)):''?>
</div>
<div class="form-group col-xs-6"  style="text-align: left; color: black !important; font-size: 20px; padding: 0px 5px 0px 5px; margin: -3px;">
    <b>Age: </b><?=isset($patient)?$patient->age:''?>
</div>
<div class="form-group col-xs-6"  style="text-align: right; color: black !important; font-size: 20px; padding: 0px 5px 0px 5px; margin: -3px;">
    <b>Gender: </b><?=isset($patient)?$patient->gender:''?>
</div>

<div class="form-group col-xs-12"  style="color: black !important; font-size: 20px; padding: 0px 5px 0px 5px; margin: -3px;">
    <b>Ref. Doctor: </b><?=isset($doctor)?$doctor->name.' - ' . $doctor->designation:''?>
</div>
