<style>
   @media print {
   .footersine {
  position: fixed;
  width: 100%;
  bottom: 5px;
  box-sizing: border-box;
}
}
</style>

<div class="row signature1 footersine" style="margin-bottom: 20px;">
    
    <?php $contact = $this->Common_model->findById('contact', array('id' => 1));
    // dd($contact);
    ?>
    <div class="col-sm-12 col-xs-12" style="border-top: 1px solid #000; margin-top:20px; text-align:center; font-weight:bold; front-size:18px;  ">
            <div class="col-xs-12">
                <i class="fa fa-home"></i>
                <?= isset($contact) ? $contact->address : '' ?><br>
                <i class="fa fa-phone"></i>
                <?= isset($contact) ? $contact->hotline : '' ?><?= isset($contact) ? !empty($contact->hotline2) ? ', ' . $contact->hotline2 : '' : ''?>
                <?= isset($contact) ? !empty($contact->hotline3) ? ', ' . $contact->hotline3 : '' : '' ?>
                <br><i class="fa fa-envelope"></i> <?= isset($contact) ? !empty($contact->email) ?$contact->email : '' : '' ?>
                <?= isset($contact) ? !empty($contact->email) ? '<i class="fa fa-globe"></i> ' . $contact->web : '' : '' ?>
            </div>
    


        </div>
       
</div>
