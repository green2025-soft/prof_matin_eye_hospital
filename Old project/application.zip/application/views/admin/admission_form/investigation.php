<section class="content">
    <div id="invoice">
        <div class="report_header">
            <?php $this->load->view('admin/common/report_header') ?>
            <br>
        </div>
        
        <div class="container">
            <div class="row">
                <div class="form-group col-sm-12 col-xs-12">
                    <div class="row">
                        <div class="col-xs-12">

                            <h4 style="color: #000!important;">OPERATION/CONDUCTION NOTE</h4> 

                            <table id="datatable" class="table table-bordered table-hover">
                                <tbody>

                                    <tr>
                                        <td style="text-align: left; width: 50%; padding: 2px;"><h6>Date & Time : <b style="font-weight: bolder;"><?=isset($value)?$value->admission_date:''?></b></h6></td>

                                    </tr>
                                    <tr>
                                        <td style="text-align: left; width: 50%; padding: 2px;"><h6>Indication : <b style="font-weight: bolder;"><?=isset($value)?$value->indication:''?></b></h6></td>

                                    </tr>
                                    <tr>

                                        <td style="text-align: left; width: 50%; padding: 2px;"><h6>Name of Operation  : <b style="font-weight: bolder;"><?=isset($value)?$value->operation_name:''?></b></h6></td>
                                    </tr>
                                    <tr>
                                        <td style="text-align: left; width: 50%; padding: 2px;"><h6>Findings : <b style="font-weight: bolder;"><?=isset($value)?$value->findings:''?></b></h6></td>
                                    </tr>
                                    <tr>
                                        <td style="text-align: left; width: 50%;padding: 2px;"><h6>Surgeon : <b style="font-weight: bolder;"><?=isset($value)?$value->sergeon_name.' - '.$value->sergeon_designation:''?></b></h6></td>
                                    </tr><tr>
                                        <td style="text-align: left; width: 50%;padding: 2px;"><h6>Assistant1 : <b style="font-weight: bolder;"><?=isset($value)?$value->assistant1:''?></h6></td>
                                        </tr><tr>
                                            <td style="text-align: left; width: 50%;padding: 2px;"><h6>Assistant2 : <b style="font-weight: bolder;"><?=isset($value)?$value->assistant2:''?></b></h6></td>
                                        </tr>
                                        <tr>
                                            <td style="text-align: left; width: 50%;padding: 2px;"><h6>Anesthesia : <b style="font-weight: bolder;"><?=isset($value)?$value->anesthesia_name.' - '.$value->anesthesia_designation:''?></b></h6></td>
                                        </tr>
                                        <tr>
                                            <td style="text-align: left; width: 50%;padding: 2px;"><h6>Anesthersiologist : <b style="font-weight: bolder;"><?=isset($value)?$value->anesthersiologist:''?></b></h6></td>
                                        </tr>
                                    </tbody>
                                </table> 

                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-xs-4">
                                <div style="background: mediumblue;padding: 0 28px; border-radius: 10px 10px 10px 10px;
                                color: #fff;text-align: center;font-weight: bolder;">BABY NOTE
                                
                            </div>

                        </div>
                        <div class="col-xs-8">
                            <div  style="border: 1px dashed #000;padding: 10px;background-color: #fff;">
                                <div class="row">
                                    <div class="col-xs-12">
                                        <p>Time of Delivery : <?=isset($value)?$value->time_of_delivery:''?></p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-6"><p>Sex : <?=isset($value)?$value->baby_sex:''?></p></div>
                                    <div class="col-xs-6"><p>Weight : <?=isset($value)?$value->baby_weight:''?></p></div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-xs-12">
                            <br>
                        
                            <p>Other Notes : <?=isset($value)?$value->others_note:''?></p>    
                        </div>
                        
                    </div>

                </div>
            </div>

            <?php //$this->load->view('admin/common/report_footer') ?>
        </div>
    </div>
</section>

