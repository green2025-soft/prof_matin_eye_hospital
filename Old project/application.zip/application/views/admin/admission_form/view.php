<section class="content">
    <div id="invoice">
        <div class="report_header">
            <?php $this->load->view('admin/common/report_header') ?>
        </div>
        
        <div class="container">
            <div class="row">
                <div class="form-group col-sm-12 col-xs-12">
                    <!-- <hr style="border: 1px solid #d4d9d8 !important; padding: 0px; margin: 3px;"> -->
                    <h2 style="text-align: center; font-weight: bolder; ">ADMISSION FORM</h2>
                    <table class="table">
                        <tr>
                            <td style="border-top: none;width: 50%">Reg. No : <b style="font-weight: bolder;"><?=isset($value)?$value->registration_no:''?></b></td>
                            <td style="border-top: none;width: 50%">
                                <b style="font-weight: bolder;">
                                Bed/Cabin : <?=isset($value)?$value->opd_cabin_ward:''?>(<?=isset($value)?$value->floor_no.' - '.$value->room_no:''?>)</b></td>
                        </tr>
                    </table>
                    <table id="datatable" class="table table-bordered table-hover">
                        <tbody>
                            <tr>
                                <td style="text-align: left; width: 50%; padding: 2px;"><h6>Name : <b style="font-weight: bolder;"><?=isset($value)?$value->patient_name.' ['.$value->patient_id.']':''?></b></h6></td>
                                <td style="text-align: left; width: 50%; padding: 2px;">
                                    <h6>Age: 
                                        <b style="font-weight: bolder;"><?=isset($value)?$value->patient_age:''?> YRS</b>,
                                        Sex: <b style="font-weight: bolder;"><?=isset($value)?$value->patient_gender:''?></b>
                                    </h6>
                                </td>
                            </tr>
                            <tr>
                                <td style="text-align: left; width: 50%; padding: 2px;" colspan="2"><h6>Guardian Name : <b style="font-weight: bolder;"><?=isset($value)?$value->full_name:''?></b></h6></td>
                            </tr>
                            <tr>
                                <td style="text-align: left; width: 50%; padding: 2px;"><h6>Religion : <b style="font-weight: bolder;"><?=isset($value)?$value->religion:''?></b></h6></td>
                                <td style="text-align: left; width: 50%; padding: 2px;">
                                    <h6>Marital Status: 
                                        <b style="font-weight: bolder;"><?=isset($value)?$value->marital_status:''?></b>
                                    </h6>
                                </td>
                            </tr>
                            <tr>
                                <td style="text-align: left; width: 50%; padding: 2px;" colspan="2"><h6>Address : <b style="font-weight: bolder;"><?=isset($value)?$value->address:''?></b></h6></td>
                            </tr>
                            <tr>
                                <td style="text-align: left; width: 50%; padding: 2px;"><h6>Date of Admission : <b style="font-weight: bolder;"><?=isset($value)?$value->admission_date:''?></b></h6></td>
                                <td>
                                <?php
                                    $time = '';
                                    if (isset($value)) {
                                        $s = $value->admission_created_at;
                                        $dt = new DateTime($s);
                                        $date = $dt->format('d-m-Y');
                                        $time = $dt->format('h:i:s A');
                                    }
                                    ?>
                                    <h6>Time:
                                        <b style="font-weight: bolder;"> <?= $time ?> </b>
                                    </h6>
                                </td>
                            </tr>
                            <tr>    
                                <td style="text-align: left; width: 50%; padding: 2px;">
                                    <h6>Date of Discharge: 
                                        <b style="font-weight: bolder;"> </b>
                                    </h6>
                                </td>
                                <td>
                                    <h6>Time: 
                                        <b style="font-weight: bolder;"> </b>
                                    </h6>
                                </td>
                            </tr>
                            <tr>
                                <td style="text-align: left; width: 50%; padding: 2px;" colspan="2"><h6>Admitted Under : <b style="font-weight: bolder;"><?=isset($value)?$value->admitted_under:''?></b></h6></td>
                                
                            </tr>
                            <tr>
                                <td style="text-align: left; width: 50%; padding: 2px;" colspan="2"><h6>Diagnosis : <b style="font-weight: bolder;"><?=isset($value)?$value->diagnosis:''?></b></h6></td>
                                
                            </tr>
                        </tbody>
                    </table>
                    


                    <div class="row <?=isset($value)?$value->form_type=='Observation'?'hide':'':''?>">
                        <div class="col-xs-12">
                            <!-- <h2>Investigation</h2> -->
                            <p>অস্ত্রোপচার ও অজ্ঞান করার সম্মতিপত্র</p>
                            <div style="border: 1px dashed #000;padding: 10px;background-color: #fff;">
                                আমি আমার রোগীকে অজ্ঞান করাইয়া অস্ত্রোপচার করাইতে সুস্থ মস্তিস্কে রাজি আছি ।  ইহাতে কোন প্রকার অসুবিধা হইলে অথবা দুর্ঘটনা ঘটিলে ডাক্তার এবং  হাসপাতাল কর্তৃপক্ষ দায়ী থাকিবে না।
                            </div> 

                        </div>
                    </div>
                    <br>
                    <br>
                    <div class="row">
                        <div class="col-xs-6">
                            <p>Signature of guardian...........................</br>
                            Mobile : <?=isset($value)?$value->patient_mobile:""?></p>
                        </div>
                        <div class="col-xs-6">
                            <p style="text-align: right;">Admission Clerk......................................</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-12">
                            <br>
                            <span>Clinical Note</span>
                            <div  style="border: 1px dashed #000;padding: 10px;background-color: #fff;height: 70px;">
                                
                            </div>
                        </div>
                    </div>

                        
                    </div>
                </div>

                <?php //$this->load->view('admin/common/report_footer') ?>
            </div>
        </div>
    </section>

<style type="text/css">
    @media print{
        @page{
            size:A4;
            margin:30mm 0 0 0!important;
        }
    }
</style>