<section class="content">
    <div id="invoice">
        <div class="report_header">
            <?php $this->load->view('admin/common/report_header') ?>
        </div>
        
        <div class="container">
            <div class="row">
                <div class="form-group col-sm-12 col-xs-12">
                    <hr style="border: 1px solid #d4d9d8 !important; padding: 0px; margin: 3px;"><p style="font-weight: bolder; font-size: 16px;">Patient Information</p><table id="datatable" class="table table-bordered table-hover">
                        <tbody>
                            <tr>
                                <td style="text-align: left; width: 50%; padding: 2px;"><h6>Registration Number : <b style="font-weight: bolder;"><?=isset($value)?$value->registration_no:''?></b></h6></td>
                                <td style="text-align: left; width: 50%; padding: 2px;"><h6>Name : <b style="font-weight: bolder;"><?=isset($value)?$value->patient_name.' ['.$value->patient_id.']':''?></b></h6></td>
                            </tr>
                            <tr>
                                <td style="text-align: left; width: 50%; padding: 2px;"><h6>Admission No : <b style="font-weight: bolder;"><?=isset($value)?$value->admission_no:''?></b></h6></td>
                                <td style="text-align: left; width: 50%; padding: 2px;"><h6>Age: <b style="font-weight: bolder;"><?=isset($value)?$value->patient_age:''?> YRS</b>,
                                    Sex: <b style="font-weight: bolder;"><?=isset($value)?$value->patient_gender:''?></b>,
                                    Phone: <b style="font-weight: bolder;"><?=isset($value)?$value->patient_mobile:''?></b></h6></td>
                                </tr>
                            </tbody>
                        </table>

                        <p style="font-weight: bolder; font-size: 16px;">Surgical</p><table id="datatable" class="table table-bordered table-hover">
                            <tbody>

                                <tr>
                                    <td style="text-align: left; width: 50%; padding: 2px;"><h6>Admission Date : <b style="font-weight: bolder;"><?=isset($value)?$value->admission_date:''?></b></h6></td>
                                    <td style="text-align: left; width: 50%;padding: 2px;"><h6></h6></td>
                                </tr>
                                <tr>
                                    <td style="text-align: left; width: 50%; padding: 2px;"><h6>Category : <b style="font-weight: bolder;"><?=isset($value)?$value->category_name:''?></b></h6></td>
                                    <td style="text-align: left; width: 50%; padding: 2px;"><h6>Operation Name : <b style="font-weight: bolder;"><?=isset($value)?$value->operation_name:''?></b></h6></td>
                                </tr>
                                <tr>
                                    <td style="text-align: left; width: 50%; padding: 2px;"><h6>Diagnosis : <b style="font-weight: bolder;"><?=isset($value)?$value->diagnosis:''?></b></h6></td>
                                    <td style="text-align: left; width: 50%;padding: 2px;"><h6>Surgeon : <b style="font-weight: bolder;"><?=isset($value)?$value->sergeon_name.' - '.$value->sergeon_designation:''?></b></h6></td>
                                </tr>
                                <tr>
                                    <td style="text-align: left; width: 50%;padding: 2px;"><h6>Anesthesia : <b style="font-weight: bolder;"><?=isset($value)?$value->anesthesia_name.' - '.$value->anesthesia_designation:''?></b></h6></td>
                                    <td style="text-align: left; width: 50%; padding: 2px;"><h6>&nbsp;</h6></td>
                                </tr>
                            </tbody>
                        </table>

                        <hr style="border: 1px solid #d4d9d8 !important;"><p style="font-weight: bolder; font-size: 16px;">Declaration</p><table id="datatable" class="table table-bordered table-hover">
                            <tbody>


                                <tr>
                                    <td style="text-align: left; padding: 2px;"><h6 style="line-height: 1.8; font-size: 13px;"><b style="font-weight: bolder;">অঙ্গীকার নামা</b><br>
                                        আমি আমার রুগীর রোগ এর চিকিৎসা সম্পর্কে জেনেছি। আমি আমার রুগীর অপারেশন এবং অজ্ঞান করার জন্য সংশ্লিষ্ট  চিকিৎসককে অনুমতি দিলাম। 
                                        এতে কোনো অসুবিধা হলে হাসপাতাল কর্তৃপক্ষ দায়ী থাকবেনা।
                                    </h6></td>
                                </tr>
                            </tbody>
                        </table>

                        <table id="datatable" class="table table-bordered table-hover">
                            <tbody>
                                <tr>
                                    <td style="text-align: left; width: 50%; padding: 2px;"><h6>রুগীর সাথে সম্পর্ক : <b style="font-weight: bolder;"><?=isset($value)?$value->relation_of_patient:''?></b></h6></td>
                                    <td style="text-align: left; width: 50%; padding: 2px;"><h6>স্বাক্ষর : <b style="font-weight: bolder;"></b></h6></td>
                                </tr>
                                <tr>
                                    <td style="text-align: left; width: 50%; padding: 2px;"><h6>পূর্ণ নাম : <b style="font-weight: bolder;"><?=isset($value)?$value->full_name:''?></b></h6></td>
                                    <td style="text-align: left;width: 50%; padding: 2px;"><h6>তারিখ : <b style="font-weight: bolder;"></b></h6></td>
                                </tr>
                                <tr>
                                    <td style="text-align: left; width: 100%; padding: 2px;" colspan="2"><h6>ঠিকানা : <b style="font-weight: bolder;"><?=isset($value)?$value->re_address:''?></b></h6></td>
                                </tr>
                            </tbody>
                        </table>
                        <hr style="border: 1px solid #d4d9d8 !important; margin-bottom: 5px;"><p style="font-weight: bolder; font-size: 16px;">Instruction</p><table id="datatable" class="table table-bordered table-hover">
                            <tbody>


                                <tr>
                                    <td style="text-align: center; width: 15%; padding: 2px;"><h6>Date</h6></td>
                                    <td style="text-align: center; width: 60%; padding: 2px;"><h6>History/Clinical Findings/Diagnosis/Treatment Plan/Operation Note</h6></td>
                                    <td style="text-align: center; width: 25%; padding: 2px;"><h6>Medicine</h6></td>
                                </tr>
                                <tr>
                                    <td style="text-align: left;"></td>
                                    <td style="text-align: left;"></td>
                                    <td style="text-align: left;">
                                        <h6>
                                            <!-- <ul>
                                                <li style="padding: 20px 5px 10px 5px;">Dialation</li>
                                                <li style="padding: 20px 5px 10px 5px;">Biometry - Due / Paid</li>
                                                <li style="padding: 20px 5px 10px 5px;">Acemox</li>
                                                <li style="padding: 20px 5px 10px 5px;">Electro K</li>
                                                <li style="padding: 20px 5px 10px 5px;">BP</li>
                                                <li style="padding: 20px 5px 10px 5px;">RBS</li>
                                                <li style="padding: 20px 5px 10px 5px;">ECG</li>
                                            </ul> -->
                                        </h6>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="3" style="padding: 2px;"><h6>Signature of duty Doctor: </h6></td>
                                </tr>
                                <tr>
                                    <td colspan="3" style="padding: 2px;"><h6>Date: </h6></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <?php $this->load->view('admin/common/report_footer') ?>
            </div>
        </div>
    </section>

