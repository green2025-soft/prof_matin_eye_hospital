<section class="content">
    <div class="row">
        <section class="col-xs-12 connectedSortable" id="full_page">
            <div class="box box-info">
                <div class="box-header">
                    <h3 class="box-title"><?= isset($page_title) ? $page_title : '' ?></h3>
                    <form class="no_print" action="<?= base_url('admission_form') ?>" method="GET">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="from_date">From Date</label>
                                        <input type="text" class="form-control search_datepicker" id="from_date" placeholder="YYYY-MM-DD" name="from_date" value="<?= isset($from_date) && !empty($from_date) ? $from_date : date('Y-m-d') ?>" autocomplete="off">
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="to_date">To Date</label>
                                        <input type="text" class="form-control search_datepicker" id="to_date" placeholder="YYYY-MM-DD" name="to_date" value="<?= isset($to_date) && !empty($to_date) ? $to_date : date('Y-m-d') ?>" autocomplete="off">
                                    </div>
                                </div>
                                <div class="form-group col-sm-3 col-xs-12">
                                    <label for="sergeon_id">Ref. Doctor</label>
                                    <select name="sergeon_id" id="sergeon_id" class="form-control selectpicker" data-live-search="true">
                                        <?= options(
                                            'doctor',
                                            array(),
                                            array('record_id', 'name'),
                                            'record_id',
                                            '',
                                            'record_id',
                                            'asc',
                                            '--Select--',
                                            isset($sergeon_id) ? $sergeon_id : 0
                                        )
                                        ?>
                                    </select>
                                </div>
                                <div class="form-group col-sm-3 col-xs-12">
                                <label for="registration_no">Admission No </label>
                                <select name="admission_id" id="admission_id" class="form-control selectpicker" data-live-search="true">
                                    <option value="">--Select--</option>
                                    <?php $selected = "";
                                    foreach ($admissionInvoice as $admission) {
                                        $patient = $this->Common_model->findById('patient', array('record_id' => $admission->patient_id));
                                        $patient_name = isset($patient) ? $patient->name . "[$patient->record_id]" : "";
                                            if ($admission_id == $admission->record_id) {
                                                $selected = 'selected';
                                            } else {
                                                $selected = '';
                                            }
                                        
                                    ?>
                                        <option value="<?= $admission->record_id ?>" data-patient_id="<?= $admission->patient_id ?>" <?= $selected ?>><?= $admission->admission_no . ' - ' . $patient_name ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                                <div class="col-md-2">
                                    <div class="form-group" style="margin-top: 25px;">
                                        <button type="submit" class="pull-left btn btn-success">Search <i class="fa fa-search"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="box-body table-responsive">
                    <div class="report_header">
                        <?php $this->load->view('admin/common/report_header') ?>
                    </div>
                    <table id="example2" class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th style="text-align: center;">SL</th>
                                <th style="text-align: center;">Date</th>
                                <th style="text-align: center;">Admission</th>
                                <th style="text-align: center;">Reg.No</th>
                                <th style="text-align: center;">Patient</th>
                                <th style="text-align: center;">Ref_Doctor</th>
                                <!--<th style="text-align: center;">Anesthesia </th>-->
                                <th style="text-align: center;">Operation </th>
                                <th style="text-align: center;">Diagnosis </th>
                                <!--<th style="text-align: center;">Relation</th> -->
                                <th style="text-align: center;">Address </th>
                                <th style="text-align: center;">Bed </th>
                                <th style="text-align: center;">Status </th>
                                <th style="text-align: center;">User</th>
                                <th style="text-align: center;" class="no_print">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $count = 0;
                            foreach ($values as $single_value) {
                                $count++;
                                
                                $no_of_bill = $this->Common_model->countAll("operation_details",array("admission_id"=>$single_value->admission_id));
                                $no_of_bill = isset($no_of_bill)?$no_of_bill:0;
                                if($no_of_bill){
                                    $status = "Release" ;
                                }else{
                                    $status = "Service On";
                                }
                            ?>
                                <tr>
                                    <td style="text-align: center;"><?php echo $count; ?></td>
                                    <td style="text-align: center;"><?= converted_date($single_value->admission_date) ?></td>
                                    <td style="text-align: center;"><?= $single_value->admission_no ?></td>
                                    <td style="text-align: center;"><?= $single_value->registration_no ?></td>

                                    <td style="text-align: center;"><?= isset($single_value) ? $single_value->name . '[' . $single_value->patient_id . ']' : '' ?>


                                    <td style="text-align: center;"><?php echo $single_value->sergeon_name . '[' . $single_value->sergeon_id . ']'; ?></td>
                                    <!--<td style="text-align: center;"><?php echo $single_value->anesthesia_name; ?></td>-->
                                    <td style="text-align: center;"><?php echo $single_value->operation_name; ?></td>
                                     <td style="text-align: center;"><?php echo $single_value->diagnosis; ?></td>
                                    <!--<td style="text-align: center;"><?php echo $single_value->relation_of_patient; ?></td> -->
                                    <td style="text-align: center;"><?php echo $single_value->address; ?></td>
                                    <td style="text-align: center;">
                                        <?php echo $single_value->opd_cabin_ward; ?><br>

                                        <?php echo $single_value->room_no; ?><br>


                                    </td>
                                    <td style="text-align: center;">
                                        <?= $status ?>
                                    </td>
                                    <td style="text-align: center;">
                                        <?php
                                        $createdBy = $single_value->operation_invoice_created_by;
                                        $user_name = '';
                                        if ($createdBy == 1) {
                                            $user = $this->Common_model->findById('admin', array('record_id' => $createdBy));
                                            $user_name = isset($user) ? $user->name : '';
                                        } elseif ($createdBy > 1) {
                                            $user = $this->Common_model->findById('staff', array('record_id' => $createdBy));
                                            $user_name = isset($user) ? $user->name : '';
                                        }
                                        echo $user_name;
                                        ?>
                                    </td>
                                    <td style="text-align: center;" class="no_print">

                                        <a href="<?= base_url("admission_form/view2/$single_value->operation_invoice_record_id") ?>" class="btn btn-sm btn-info"><i class="fa fa-eye"></i>
                                        </a>

                                        <a href="<?= base_url("admission_form/edit/$single_value->operation_invoice_record_id") ?>" class="btn btn-sm btn-success"><i class="fa fa-edit"></i>
                                        </a>
                                        <div class="clearfix"></div>

                                        <a href="<?= base_url("admission_form/delete/$single_value->operation_invoice_record_id") ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are You Sure ?')"><i class="fa fa-trash-o"></i>
                                        </a>
                                        <?php $class = "btn-success";
                                        if (admin()) {
                                            $button_text = $single_value->show_hide;
                                            if ($button_text == "Show") {
                                                $class = "btn-success";
                                            } else {
                                                $class = "btn-danger";
                                            }
                                        ?>
                                            <a class="btn <?= $class ?> btnShowHide" href="javascript:void(0)" data-url="<?= base_url("crud/show_hide/operation_invoice/record_id/$single_value->operation_invoice_record_id"); ?>"><?= $button_text ?></i>
                                            </a>
                                        <?php } ?>


                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div><!-- /.box-body -->
            </div>
        </section>
    </div>
</section>