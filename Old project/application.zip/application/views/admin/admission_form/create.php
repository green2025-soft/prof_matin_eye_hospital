<style type="text/css">
    .devide {
        text-decoration: underline;
        color: green;
        font-weight: bolder;
    }
</style>
<section class="content">
    <div class="row">
        <section class="col-xs-12 connectedSortable" id="full_page">
            <div class="box box-info no_print">
                <div class="box-header">
                    <h3 class="box-title"><?= isset($page_title) ? $page_title : '' ?></h3>
                </div>
                <form action="<?= base_url('admission_form/saveOrUpdate') ?>" method='post'>
                    <div class="box-body">
                        <h5 class="devide text-center">Before Operation/Observation</h5>
                        <div class="row">
                            <div class="form-group  col-sm-2 col-xs-12">
                                <div class="" style="padding-top: 25px;">
                                    <label class="radio-inline1">
                                        <input type="radio" name="form_type" value="Operation" <?= isset($value) ? $value->form_type == 'Operation' ? 'checked' : '' : 'checked' ?>>Operation
                                    </label>
                                    <label class="radio-inline">
                                        <input type="radio" name="form_type" value="Observation" <?= isset($value) ? $value->form_type == 'Observation' ? 'checked' : '' : '' ?>>Observation
                                    </label>
                                </div>
                            </div>
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="registration_no" class="lbl-color">Reg.No (<span class="required">*</span>)</label>
                                <input type="text" class="form-control" id="registration_no" name="registration_no" value="<?= isset($value) ? $value->prefix . '-' . $value->serial_no : $registration_no ?>" placeholder="" readonly required>
                            </div>
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="admission_id" class="lbl-color">Admission No(<span class="required">*</span>)</label>
                                <?php $where = array();
                                if (isset($value)) {
                                    $where['record_id'] = $value->admission_id;
                                } else {
                                    //$where['patient_status'] = 'New' ;
                                }
                                ?>
                                <select name="admission_id" id="admission_id" class="form-control selectpicker" data-live-search="true" required="">
                                    <option value="">--Select--</option>
                                    <?php $selected = "" ; foreach ($admissionInvoice as $admission) {
                                        $patient1 = $this->Common_model->findById('patient',array('record_id'=>$admission->patient_id));
                                        $patient_name = isset($patient1)?$patient1->name."[$patient1->record_id]":"" ;
                                        if(isset($value)){
                                            if($value->admission_id == $admission->record_id){
                                                $selected = 'selected' ;
                                            }else{
                                                $selected = '' ;
                                            }
                                        }
                                        ?>
                                        <option value="<?=$admission->record_id?>" data-patient_id="<?=$admission->patient_id?>" <?=$selected?>><?=$admission->admission_no.' - ' . $patient_name?></option>
                                    <?php } ?>
                                </select>
                                <input type="hidden" name="update_id" id="update_id" value="<?= isset($value) ? $value->record_id : '' ?>">
                                <input type="hidden" name="admission_no" id="admission_no" value="<?= isset($value) ? $value->admission_no : '' ?>">
                            </div>

                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="admission_date">Date(<span class="required">*</span>)</label>
                                <input type="text" class="form-control closing_datepicker" id="admission_date" name="admission_date" value="<?= isset($value) ? $value->admission_date : closing_date(date('Y-m-d')) ?>">
                                <input type="hidden" name="update_id" id="update_id" value="<?= isset($value) ? $value->record_id : 0 ?>">
                            </div>
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="patient_id">Patient Name(<span class="required">*</span>) </label>
                                <input type="text" id="patient_id" class="form-control" value="<?= isset($patient) ? $patient->name . '[' . $patient->record_id . ']' : '' ?>" readonly="" required="" readonly="">
                                <input type="hidden" name="patient_id" value="<?= isset($patient) ? $patient->record_id : '' ?>" readonly="" required="">
                            </div>
                            <div class="form-group col-sm-1 col-xs-12">
                                <label for="age">Age(<span class="required">*</span>)</label>
                                <input type="text" class="form-control" id="age" value="<?= isset($patient) ? $patient->age : '' ?>" readonly="" required="">
                            </div>
                            <div class="form-group col-sm-1 col-xs-12">
                                <label for="sex">Gender(<span class="required">*</span>)</label>
                                <input type="text" id="sex" class="form-control" value="<?= isset($patient) ? $patient->gender : '' ?>" readonly="" required="">
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="mobile">Mobile No. (<span class="required">*</span>)</label>
                                <input type="text" id="mobile" class="form-control" value="<?= isset($patient) ? $patient->mobile : '' ?>" readonly="" required="">
                            </div>
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="address">Address</label>
                                <input type="text" class="form-control" id="address" value="<?= isset($patient) ? $patient->address : '' ?>" value="" placeholder="" readonly="">
                            </div>
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="religion">Religion</label>
                                <select class="form-control" id="religion" name="religion">
                                    <option value="Islam" <?php if (isset($value)) {
                                                                if ($value->religion == "Islam") {
                                                                    echo "selected";
                                                                }
                                                            } ?>>Islam</option>
                                    <option value="Hindu" <?php if (isset($value)) {
                                                                if ($value->religion == "Hindu") {
                                                                    echo "selected";
                                                                }
                                                            } ?>>Hindu</option>
                                    <option value="Buddha" <?php if (isset($value)) {
                                                                if ($value->religion == "Buddha") {
                                                                    echo "selected";
                                                                }
                                                            } ?>>Buddha</option>
                                    <option value="Christian " <?php if (isset($value)) {
                                                                    if ($value->religion == "Christian ") {
                                                                        echo "selected";
                                                                    }
                                                                } ?>>Christian </option>
                                    <option value="Others " <?php if (isset($value)) {
                                                                if ($value->religion == "Others ") {
                                                                    echo "selected";
                                                                }
                                                            } ?>>Others </option>
                                </select>
                            </div>
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="marital_status">Marital Status</label>
                                <select class="form-control" id="marital_status" name="marital_status">
                                    <option value="Married" <?php if (isset($value)) {
                                                                if ($value->marital_status == "Married") {
                                                                    echo "selected";
                                                                }
                                                            } ?>>Married</option>
                                    <option value="Unmarried" <?php if (isset($value)) {
                                                                    if ($value->marital_status == "Unmarried") {
                                                                        echo "selected";
                                                                    }
                                                                } ?>>Unmarried</option>
                                </select>
                            </div>
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="sergeon_id">Sergeon (Doctor)</label>
                                <select name="sergeon_id" id="sergeon_id" class="form-control selectpicker" data-live-search="true">
                                    <?= options(
                                        'doctor',
                                        array(),
                                        array('record_id', 'name'),
                                        'record_id',
                                        '',
                                        'record_id',
                                        'asc',
                                        '--Select--',
                                        isset($value) ? $value->sergeon_id : 0
                                    )
                                    ?>
                                </select>
                            </div>
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="doctor_id">Assistant Name</label>
                                <input type="text" name="surgeon_assistant" id="surgeon_assistant" class="form-control" value="<?= isset($value) ? $value->surgeon_assistant : '' ?>" placeholder="Surgeon Assistant">
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="anesthesia_id">Anesthesia </label>
                                <select name="anesthesia_id" id="anesthesia_id" class="form-control selectpicker" data-live-search="true">
                                    <?= options(
                                        'doctor',
                                        array(),
                                        array('record_id', 'name'),
                                        'record_id',
                                        '',
                                        'record_id',
                                        'asc',
                                        '--Select--',
                                        isset($value) ? $value->anesthesia_id : 0
                                    )
                                    ?>
                                </select>
                            </div>
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="operation_category_id" style="color: blue;">Operation Category</label>
                                <select name="operation_category_id" id="operation_category_id" class="form-control selectpicker1">
                                    <?= options(
                                        'operation_category',
                                        array(),
                                        array(),
                                        'record_id',
                                        'category_name',
                                        'category_name',
                                        'asc',
                                        '--Select--',
                                        isset($value) ? $value->operation_category_id : 0
                                    )
                                    ?>
                                </select>
                            </div>
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="operation_name_id" style="color: blue;" id="lbl_operation_name">Operation Name</label>
                                <select name="operation_name_id" id="operation_name_id" class="form-control">
                                    <option value="">--Select--</option>
                                    <?php if (isset($operation_names)) {
                                        foreach ($operation_names as $key2 => $value2) { ?>
                                            <option value="<?= $value2->record_id ?>" data-operation_price="<?= $value2->rate ?>" <?php if (isset($value)) {
                                                                                                                                    if ($value->operation_name_id == $value2->record_id) {
                                                                                                                                        echo "selected";
                                                                                                                                    }
                                                                                                                                } ?>><?= $value2->operation_name ?></option>
                                    <?php }
                                    } ?>
                                </select>
                                <input type="hidden" name="operation_price" id="operation_price" value="<?= isset($value) ? $value->operation_price : '' ?>" class="form-control" readonly>
                            </div>
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="diagnosis">Diagnosis</label>
                                <textarea type="text" class="form-control" id="diagnosis" name="diagnosis" rows="1" cols="12"><?= isset($value) ? $value->diagnosis : '' ?></textarea>
                            </div>
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="full_name">Guardian Name</label>
                                <input type="text" id="full_name" name="full_name" class="form-control" value="<?= isset($value) ? $value->full_name : '' ?>">
                            </div>
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="relation_of_patient">Relation of Patient</label>
                                <input type="text" id="relation_of_patient" name="relation_of_patient" class="form-control" value="<?= isset($value) ? $value->relation_of_patient : '' ?>">
                            </div>
                            </div>
                        <div class="row">

                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="address">Address</label>
                                <input type="text" class="form-control" id="address" name="address" value="<?= isset($value) ? $value->address : '' ?>" value="" placeholder="">
                            </div>

                        
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="opd_cabin_ward" style="color: blue;">Cabin/Ward </label>
                                <select class="form-control" id="opd_cabin_ward" name="opd_cabin_ward">
                                    <option value="">--Select--</option>
                                    <option value="Cabin" <?php if (isset($value)) {
                                                                if ($value->opd_cabin_ward == 'Cabin') {
                                                                    echo "selected";
                                                                }
                                                            } ?>>Cabin</option>
                                    <option value="Ward" <?php if (isset($value)) {
                                                                if ($value->opd_cabin_ward == 'Ward') {
                                                                    echo "selected";
                                                                }
                                                            } ?>>Ward</option>
                                </select>
                            </div>
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="bed_id">Bed </label>
                                <select class="form-control" id="bed_id" name="bed_id" value="">
                                    <option value="">--Select--</option>
                                    <?php if (isset($beds)) {
                                        foreach ($beds as $key3 => $value3) { ?>
                                            <option value="<?= $value3->record_id ?>" data-bed_no="<?= $value3->bed_no ?>" data-bed_type="<?= $value3->bed_type ?>" data-floor_no="<?= $value3->floor_no ?>" data-room_no="<?= $value3->room_no ?>" data-charge="<?= $value3->charge ?>" <?php if (isset($value)) {
                                                                                                                                                                                                                                                                                    if ($value->bed_id == $value3->record_id) {
                                                                                                                                                                                                                                                                                        echo "selected";
                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                } ?>><?= $value3->bed_no ?> - <?= $value3->bed_type ?> - <?= $value3->room_no ?> - <?= $value3->floor_no ?></option>
                                    <?php }
                                    } ?>
                                </select>
                            </div>
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="floor_no">Floor No </label>
                                <input type="text" class="form-control" id="floor_no" value="<?= isset($value) ? isset($bed) ? $bed->floor_no : '' : '' ?>" readonly="">
                            </div>
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="room_no">Room No </label>
                                <input type="text" class="form-control" id="room_no" value="<?= isset($value) ? isset($bed) ? $bed->room_no : '' : '' ?>" readonly="">
                            </div>
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="bed_type">Bed Type </label>
                                <input type="text" class="form-control" id="bed_type" value="<?= isset($value) ? isset($bed) ? $bed->bed_type : '' : '' ?>" readonly="">
                            </div>
                            </div>
                        <div class="row">
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="charge">Charge (Per Day) </label>
                                <input type="text" class="form-control text-right" id="charge" name="charge_per_day" value="<?= isset($value) ? $value->charge_per_day : '' ?>" readonly="">
                            </div>

                        
                            <div class="form-group  col-sm-2 col-xs-12 hide">
                                <label for="reference_by">Reference By (<span class="required">*</span>)</label>
                                <div class="input-group">
                                    <select id="reference_by" name="reference_by" class="form-control selectpicker11 reference_by" data-live-search1="true">
                                        <?= options(
                                            'reference_by',
                                            array(),
                                            array('record_id', 'reference_name'),
                                            'record_id',
                                            '',
                                            'record_id',
                                            'desc',
                                            'Select Reference By',
                                            isset($value) ? $value->reference_by : 0
                                        )
                                        ?>
                                    </select>

                                    <span class="input-group-addon">
                                        <button type="button" id="btnReference" style="height: 20px;" class="btn btn-success fa fa-plus-square btn-sm" data-toggle="modal" data-target="#referenceModal">
                                        </button>
                                    </span>
                                </div>
                            </div>

                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="admitted_under">Admitted Under </label>
                                <input type="text" id="admitted_under" name="admitted_under" class="form-control" value="<?= isset($value) ? $value->admitted_under : '' ?>">
                            </div>


                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="indication">Indication </label>
                                <textarea type="text" class="form-control" id="indication" name="indication" rows="1" cols="12"><?= isset($value) ? $value->indication : '' ?></textarea>
                            </div>



                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="assistant1">Assistant1 </label>
                                <input type="text" id="assistant1" name="assistant1" class="form-control" value="<?= isset($value) ? $value->assistant1 : '' ?>">
                            </div>
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="assistant2">Assistant2</label>
                                <input type="text" class="form-control" id="assistant2" name="assistant2" value="<?= isset($value) ? $value->assistant2 : '' ?>" placeholder="">
                            </div>
                            <div class="clearfix"></div>
                            <h5 class="devide text-center">After Operation/Observation</h5>
                            <div class="form-group col-sm-2 col-xs-12 hide">
                                <label for="anesthersiologist">Anesthersiologist</label>
                                <input type="text" class="form-control" id="anesthersiologist" name="anesthersiologist" value="<?= isset($value) ? $value->anesthersiologist : '' ?>">
                            </div>
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="time_of_delivery">Delivery Date & Time</label>
                                <input type="text" class="form-control" id="time_of_delivery" name="time_of_delivery" value="<?= isset($value) ? $value->time_of_delivery : '' ?>" placeholder="Delivery Date & Time">
                            </div>
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="baby_sex">Gender of Baby</label>
                                <input type="text" class="form-control" id="baby_sex" name="baby_sex" value="<?= isset($value) ? $value->baby_sex : '' ?>">
                            </div>
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="baby_weight">Baby Weight</label>
                                <input type="text" class="form-control" id="baby_weight" name="baby_weight" value="<?= isset($value) ? $value->baby_weight : '' ?>">
                            </div>
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="sex">Findings</label>
                                <textarea type="text" id="findings" name="findings" class="form-control" rows="1" cols="12"><?= isset($value) ? $value->findings : '' ?></textarea>
                            </div>
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="others_note">Other Notes</label>
                                <textarea type="text" class="form-control" id="others_note" name="others_note" rows="1" cols="12"><?= isset($value) ? $value->others_note : '' ?></textarea>
                            </div>
                            <div class="form-group  col-sm-2 col-xs-12">
                                <button type="submit" class="pull-left btn btn-success" id="submit" style="margin-top: 25px;">
                                    <?php if (isset($value)) {  ?>
                                        Update
                                    <?php } else { ?>
                                        Submit
                                    <?php } ?>
                                    <i class="fa fa-arrow-circle-right"></i></button>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">

                        </div>
                    </div>
            </div>
            </form>
    </div>
</section>
</div>
</section>
<script type="text/javascript">
    $(document).on('change', '#operation_category_id', function(e) {
        var operation_category_id = $(this).val();
        $.ajax({
            url: "<?= base_url('admission_form/get_operation_name') ?>",
            type: 'post',
            dataType: 'html',
            data: {
                operation_category_id: operation_category_id
            },
            success: function(response) {
                $("#operation_name_id").html(response);
                //$("#operation_name_id").selectpicker('refresh');
            }
        });
    });
    $(document).on('change', '#operation_name_id', function(e) {
        var operation_price, option, operation_name_id;
        operation_name_id = $(this).val();
        option = $('#operation_name_id option:selected');
        operation_price = option.data('operation_price');
        $('#operation_price').val(operation_price);
        if (operation_name_id) {
            $('#lbl_operation_name').text('Operation Name (' + operation_price + ')');
        } else {
            $('#lbl_operation_name').text('Operation Name');
        }
    })
    $('#opd_cabin_ward').change(function() {

        $('#floor_no').val('');
        $('#room_no').val('');
        $('#bed_type').val('');
        $('#charge').val('');

        var opd_cabin_ward = $(this).val();
        $.ajax({
            url: "<?= base_url('admission_form/get_bed_info') ?>",
            type: 'post',
            dataType: 'html',
            data: {
                opd_cabin_ward: opd_cabin_ward
            },
            success: function(response) {
                console.log(response);
                $("#bed_id").html(response);
                // $("#bed_id").selectpicker('refresh');
            }
        });
        // $('#bed_id').trigger('change');
    });
    $('#bed_id').change(function() {
        var floor_no, room_no, bed_type, charge, option;
        option = $('#bed_id option:selected');
        floor_no = option.data('floor_no');
        room_no = option.data('room_no');
        bed_type = option.data('bed_type');
        charge = option.data('charge');
        $('#floor_no').val(floor_no);
        $('#room_no').val(room_no);
        $('#bed_type').val(bed_type);
        $('#charge').val(charge);
    })
</script>
<script type="text/javascript">
    $(document).on('change', '#admission_id', function(e) {
        var admission_id, sub_total = 0,
            operation_price = 0,
            medicine_cost = 0;
        admission_id = $('#admission_id').val();
        if (!admission_id) {
            $('#patient_id').val(0);
            $('input[name=patient_id]').val('');
            $('#age').val('');
            $('#mobile').val('');
            $('#sex').val('');
            $('#address').val('');
            return;
        }
        $.ajax({
            url: "<?= base_url("patient_admission/get_admissiom") ?>",
            type: 'post',
            dataType: 'json',
            data: {
                admission_id: admission_id
            },
            success: function(response) {
                console.log(response);
                if (response) {
                    $('#patient_id').val(response.patient.name + '[' + response.patient.record_id + ']');
                    $('input[name=patient_id]').val(response.patient.record_id);
                    $('#admission_no').val(response.admission_no);
                    $('#age').val(response.patient.age);
                    $('#mobile').val(response.patient.mobile);
                    $('#sex').val(response.patient.gender);
                    $('#address').val(response.patient.address);
                    console.log(response.form_type);
                    $("input[name=form_type][value=" + response.form_type + "]").prop('checked', true);
                }
            }
        });
    })
</script>