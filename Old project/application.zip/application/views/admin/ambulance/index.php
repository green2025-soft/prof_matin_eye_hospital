
<section class="content">
    <div class="row">
        <section class="col-xs-12 connectedSortable"> 
            <div  class="box box-info no_print">
                <div class="box-header">
                    <h3 class="box-title"><?=isset($page_title)?$page_title:''?></h3>
                </div>
                <?php echo form_open_multipart('ambulance/saveOrUpdate'); ?>
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="ambulance_no">Ambulance No (<span class="required">*</span>) </label>
                                <input type="text" class="form-control" id="ambulance_no" placeholder="Enter Ambulance No" name="ambulance_no" value="" required="">
                                <input type="hidden" name="update_id" id="update_id" value="0">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="ambulance_type">Ambulance Type (<span class="required">*</span>) </label>
                                <select class="form-control" name="ambulance_type" id="ambulance_type">
                                    <option value="">--Select Ambulance Type--</option>
                                    <option value="AC">AC</option>
                                    <option value="Non AC">Non AC</option>
                                    <option value="Others">Others</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="box-footer clearfix">
                    <button type="submit" class="pull-left btn btn-success update">Create <i class="fa fa-arrow-circle-right"></i></button>
                </div>
            </form>
            <div class="box-body table-responsive" style="width: 100%; overflow-x: scroll; color: black;">
                <div class="info-header">
                    <h4><?=isset($info_header)?$info_header:''?></h4> 
                </div>
                <table id="example2" class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th style="text-align: center;">SL</th>
                            <th style="text-align: center;">Ambulance No</th>
                            <th style="text-align: center;">Ambulance Type</th>
                            <th style="text-align: center;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $count = 0;
                        foreach ($values as $single_value) {
                            $count++;
                            ?>
                            <tr>
                                <td style="text-align: center;"><?php echo $count; ?></td>
                                <td style="text-align: center;"><?php echo $single_value->ambulance_no; ?></td>
                                <td style="text-align: center;"><?php echo $single_value->ambulance_type; ?></td>
                                <td style="text-align: center;">
                                    <a href="javascript:void(0)" class="btn btn-primary btnEdit" data-record_id="<?=$single_value->record_id?>"><i class="fa fa-pencil"></i></a>
                                    <a class="btn btn-danger"
                                    href="<?=base_url("ambulance_no/delete/$single_value->record_id")?>" onclick="return confirm('Are you sure to delete this record?')"><i class="fa fa-trash-o"></i>
                                </a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</section>
</div>
</section>
<script type="text/javascript">
    $(document).on('click','.btnEdit',function(e){
        var id = $(this).data('record_id');
        var formURL = "<?php echo site_url('crud/edit/ambulance/record_id'); ?>";
        $.ajax(
        {
            url : formURL,
            type: "POST",
            data : {id: id},
            dataType: "json",
            success:function(data){
              $('#update_id').val(data.record_id);
              $('#ambulance_no').val(data.ambulance_no);
              $('#ambulance_type').val(data.ambulance_type);
              $('#ambulance_no').focus();
              $('.update').text("Update");
              $("html, body").animate({ scrollTop: 0 }, "slow");
          }
      });
        e.preventDefault();
    });
</script>