<section class="content">
   <div class="row">
    <section class="col-xs-12 connectedSortable">
        <div class="box box-info">
            <div class="box-header">
                <h3 class="box-title"><?=isset($page_title)?$page_title:''?></h3>
            </div>
            <form action="<?=base_url('contact_us/saveOrUpdate')?>" method="post"
              autocomplete="off" enctype="multipart/form-data">
              <div class="box-body">
                <div class="row">
                    <h4 style="color: red;"><?php echo validation_errors(); ?></h4>
                    <div class="form-group col-sm-3 col-xs-12">
                        <label for="c_name">Company Name <span class="required">*</span></label>
                        <input type="text" name="c_name" id="c_name" class="form-control" placeholder="Enter company name" value="<?php echo $contact->c_name; ?>">
                        <input type="hidden" name="update_id" id="update_id" value="<?=$contact->id?>">
                    </div>
                    <div class="form-group col-sm-3 col-xs-12">
                        <?php 
                            $img_url = "assets/img/logo.jpg" ;
                            if(file_exists($contact->logo)){
                                $img_url = $contact->logo ;
                            }
                            $img_url = base_url($img_url) ;
                        ?>
                        
                       
                        <div class="row">
                            <div class="col-sm-9 col-xs-9">
                                 <label for="logo">Backend Logo <span class="required">*</span></label>
                            </div>
                            <div class="col-sm-3 col-xs-3">
                            <img src="<?=$img_url?>" id="logo" name="logo" class="img-responsive" style="width: 35px;height: 25px;">
                        </div>
                        </div>
                        <input type="file" name="logo" id="logo" class="form-control">
                    </div>
                    <div class="form-group col-sm-3 col-xs-12">
                        <?php 
                            $img_url = "assets/img/logo.png" ;
                            if(file_exists($contact->frontend_logo)){
                                $img_url = $contact->frontend_logo ;
                            }
                            $img_url = base_url($img_url) ;
                        ?>
                        
                       
                        <div class="row">
                            <div class="col-sm-9 col-xs-9">
                                 <label for="frontend_logo">Frontend Logo <span class="required">*</span></label>
                            </div>
                            <div class="col-sm-3 col-xs-3">
                            <img src="<?=$img_url?>"  class="img-responsive" style="width: 35px;height: 25px;">
                        </div>
                        </div>
                        <input type="file" name="frontend_logo" class="form-control">
                    </div>
                    <div class="form-group col-sm-3 col-xs-12">
                        <label for="address">Address <span class="required">*</span></label>
                        <input type="text" name="address" id="address" class="form-control" placeholder="Enter full address" value="<?php echo $contact->address; ?>">
                    </div>
                    <div class="form-group col-sm-3 col-xs-12">
                        <label for="email">Email <span class="required">*</span></label>
                        <input type="email" name="email" id="email" class="form-control" placeholder="Enter email address" value="<?php echo $contact->email; ?>">
                    </div>
                    
                    <div class="form-group col-sm-3 col-xs-12">
                        <label for="email2">Email 2 <span style="font-size: smaller">(Optional)</span></label>
                        <input type="email" name="email2" id="email2" class="form-control" placeholder="Enter Email" value="<?php echo $contact->email2; ?>">
                    </div>
                    
                    <div class="form-group col-sm-3 col-xs-12">
                        <label for="email3">Email 3 <span style="font-size: smaller">(Optional)</span></label>
                        <input type="email" name="email3" id="email3" class="form-control" placeholder="Enter Email" value="<?php echo $contact->email3; ?>">
                    </div>
                    
                    <div class="form-group col-sm-3 col-xs-12">
                        <label for="facebook">Facebook <span style="font-size: smaller"></span></label>
                        <input type="text" name="facebook" id="facebook" class="form-control" placeholder="Enter Facebook" value="<?php echo $contact->facebook; ?>">
                    </div>
                    <div class="clearfix"></div>
                    <div class="form-group col-sm-3 col-xs-12">
                        <label for="web">Web Address <span class="required">*</span></label>
                        <input type="text" name="web" id="web" class="form-control" placeholder="Enter website address" value="<?php echo $contact->web; ?>">
                    </div>
                    <div class="form-group col-sm-3 col-xs-12">
                        <label for="hotline">Hotline No. <span class="required">*</span></label>
                        <input type="text" name="hotline" id="hotline" class="form-control" placeholder="Enter hotline no.(contact info)" value="<?php echo $contact->hotline; ?>">
                    </div>
                    <div class="form-group col-sm-3 col-xs-12">
                        <label for="hotline2">Addtional Hotline No. <span
                            style="font-size: smaller">(Optional)</span></label>
                            <input type="text" name="hotline2" id="hotline2" class="form-control" placeholder="Enter second hotline no.(contact info)" value="<?php echo $contact->hotline2; ?>">
                        </div>
                       
                        <div class="form-group col-sm-3 col-xs-12">
                            <label for="hotline3">Additional Hotline No. <span style="font-size: smaller">(Optional)</span></label>
                            <input type="text" name="hotline3" id="hotline3" class="form-control" placeholder="Enter third hotline no.(contact info)" value="<?php echo $contact->hotline3; ?>">
                        </div>
                         <div class="clearfix"></div>
                        <div class="form-group col-sm-12 col-xs-12">
                            <label for="about_us">About Us <span style="font-size: smaller"></span></label>
                            <textarea name="about_us" id="about_us" class="form-control summernote" placeholder="Enter about us" rows="4" cols="12"><?php echo $contact->about_us; ?></textarea>
                        </div>

                    </div>
                    <div class="row">
                        <div class="form-group col-sm-3 col-xs-12">
                            <button type="submit" class="btn btn-primary btn-info">Update
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>
</div>
</section>


