<?php
$inputVal = fn($key, $default = '') => getValue($key, $value ?? '', $default);
$staffMembers = $this->Common_model->findAll('staff', [], 'name', 'asc');
$doctors = $this->Common_model->findAll('doctor', [], 'name', 'asc');
$patients = $this->Common_model->findAll('patient', [], 'record_id', 'desc');
?>
<aside>
    <section class="content">
        <div class="row">
            <section class="col-xs-12 connectedSortable">
                <div class="box box-info no_print">
                    <div class="box-header">
                        <h3 class="box-title"><?= isset($page_title) ? $page_title : '' ?></h3>
                    </div>
                    <?php echo form_open_multipart($bUrl . '/saveOrUpdate'); ?>
                    <input type="hidden" name="update_id" id="update_id" value="<?= $inputVal('id', 0) ?>">
                    <div class="box-body">
                        <div class="row">
                            <div class="form-group col-sm-3">
                                <label for="date">Date <span class="required">*</span></label>
                                <input type="text" class="form-control search_datepicker" id="date" name="date" value="<?= $inputVal('date', date('Y-m-d')) ?>" autocomplete="off" maxlength="150" required>
                            </div>
                            <div class="form-group col-sm-3">
                                <label for="place">Place</label>
                                <input type="text" class="form-control" id="place" name="place" value="<?= $inputVal('place') ?>" maxlength="255">
                            </div>
                            <div class="form-group col-sm-3">
                                <label for="doctor_id">Doctor Name</label>
                                <select name="doctor_id" id="doctor_id" class="form-control selectpicker" data-live-search="true" data-container="body">
                                    <option value="">Select Doctor</option>
                                    <?php foreach ($doctors as $doctorInfo): ?>
                                        <option value="<?= (int) $doctorInfo->record_id ?>" <?= getSelected($doctorInfo->record_id, 'doctor_id', $value ?? null) ?>><?= $doctorInfo->record_id . ' - ' . $doctorInfo->name ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            

                            <div class="form-group col-sm-3">
                                <label for="dr_assistant">Doctor Assistant</label>
                                <input type="text" class="form-control" id="dr_assistant" name="dr_assistant" value="<?= $inputVal('dr_assistant') ?>" maxlength="255">
                            </div>
                            <div class="clearfix"></div>
                            <div class="form-group col-sm-3">
                                <label for="counsellor_name">Counsellor Name</label>
                                <input type="text" class="form-control" id="counsellor_name" name="counsellor_name" value="<?= $inputVal('counsellor_name') ?>" maxlength="255">
                            </div>
                            <div class="form-group col-sm-3">
                                <label for="salesman_id">Salesman</label>
                                <select name="salesman_id" id="salesman_id" class="form-control selectpicker" data-live-search="true" data-container="body">
                                    <option value="">Select Salesman</option>
                                    <?php foreach ($staffMembers as $staffInfo): ?>
                                        <option value="<?= (int) $staffInfo->record_id ?>" <?= getSelected($staffInfo->record_id, 'salesman_id', $value ?? null) ?>><?= $staffInfo->record_id . ' - ' . $staffInfo->name ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            

                            <div class="form-group col-sm-3">
                                <label for="nurse_id">Nurse</label>
                                <select name="nurse_id" id="nurse_id" class="form-control selectpicker" data-live-search="true" data-container="body">
                                    <option value="">Select Nurse</option>
                                    <?php foreach ($staffMembers as $staffInfo): ?>
                                        <option value="<?= (int) $staffInfo->record_id ?>" <?= getSelected($staffInfo->record_id, 'nurse_id', $value ?? null) ?>><?= $staffInfo->record_id . ' - ' . $staffInfo->name ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-sm-3 col-xs-12">
                                <label for="patient_id">Patient Name </label>
                                <div class="input-group">
                                    <select name="patient_id" id="patient_id" class="form-control selectpicker" data-live-search="true" >
                                        <option value="">Select Patient</option>
                                        <?php foreach ($patients as $patientInfo):
                                            // The shared patient handler decodes percent escapes in addresses.
                                            $patientAddress = str_replace('%', '%25', $patientInfo->address ?? '');
                                        ?>
                                            <option value="<?= (int) $patientInfo->record_id ?>" 
                                                <?= getSelected($patientInfo->record_id, 'patient_id', $value ?? null) ?> 
                                                data-mobile="<?= $patientInfo->mobile ?? '' ?>" 
                                                data-name="<?= $patientInfo->name ?>" 
                                                data-gender="<?= $patientInfo->gender ?? '' ?>" 
                                                data-age="<?= calculateCurrentAge($patientInfo) ?>" 
                                                data-address="<?= $patientAddress ?>">
                                                <?= $patientInfo->record_id . '-' . $patientInfo->name . (!empty($patientInfo->mobile) ? '-' . $patientInfo->mobile : '') ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <span class="input-group-addon">
                                        <button type="button" id="c_plus" style="height: 20px;" class="btn btn-success fa fa-plus-square btn-sm" data-toggle="modal" data-target="#patientModal" title="Add Patient" aria-label="Add Patient"></button>
                                    </span>
                                </div>
                            </div>
                            <!-- <div class="clearfix"></div> -->

                            <div class="form-group col-sm-3">
                                <label for="mobile">Mobile No</label>
                                <input type="text" class="form-control" id="mobile" value="" readonly>
                            </div>
                            <div class="form-group col-sm-3">
                                <label for="age">Age</label>
                                <input type="text" class="form-control" id="age" value="" readonly>
                            </div>
                            <div class="form-group col-sm-3">
                                <label for="sex">Gender</label>
                                <input type="text" class="form-control" id="sex" value="" readonly>
                            </div>
                            <div class="form-group col-sm-3">
                                <label for="address">Address</label>
                                <input type="text" class="form-control" id="address" value="" readonly>
                            </div>
                            <!-- <div class="clearfix"></div> -->

                            <div class="form-group col-sm-3">
                                <label for="ot_adv">OT Advance</label>
                                <input type="number" class="form-control text-right" id="ot_adv" name="ot_adv" value="<?= $inputVal('ot_adv', 0) ?>" min="0" step="0.01">
                            </div>
                            <div class="form-group col-sm-3">
                                <label for="medicine_total">Medicine Total</label>
                                <input type="number" class="form-control text-right" id="medicine_total" name="medicine_total" value="<?= $inputVal('medicine_total', 0) ?>" min="0" step="0.01">
                            </div>
                            <div class="form-group col-sm-3">
                                <label for="optic_total">Optic Total</label>
                                <input type="number" class="form-control text-right" id="optic_total" name="optic_total" value="<?= $inputVal('optic_total', 0) ?>" min="0" step="0.01">
                            </div>
                            <div class="form-group col-sm-3">
                                <label>Remarks</label>
                                <input type="text" class="form-control" name="remarks" value="<?= $inputVal('remarks') ?>" >
                            </div>

                            <div class="form-group col-sm-12 col-xs-12 text-center">
                                <div class="box-footer clearfix">
                                    <button type="submit" class="btn btn-success mt-25">Submit <i class="fa fa-arrow-circle-right"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>
                    </form>
                </div>
            </section>
        </div>
    </section>
</aside>

<script>
    $(function () {
        var patientSelect = $('#patient_id');

        function fillPatientInfo() {
            var option = patientSelect.find('option:selected');
            $('#mobile').val(option.data('mobile') || '');
            $('#age').val(option.data('age') || '');
            $('#sex').val(option.data('gender') || '');
            $('#address').val(decodeURI(option.data('address') || ''));
        }

        patientSelect.on('change', fillPatientInfo);
        fillPatientInfo();
    });
</script>
