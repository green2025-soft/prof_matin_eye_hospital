<style>
    .text-right{
        text-align: right !important;
    }
</style>
<aside>
    <section class="content">
        <div class="row">
            <section class="col-xs-12 connectedSortable">
                <div class="box box-info no_print">
                    <div class="box-header">
                        <h3 class="box-title"><?= isset($page_title) ? $page_title : '' ?></h3>
                        
                    </div>
                    <div class="box-body">
                        <form  method="GET">
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="form-group col-sm-2">
                                        <label for="from_date">From Date</label>
                                        <input type="text" class="form-control search_datepicker" id="from_date" name="from_date"  value="<?= $from_date ?>" autocomplete="off">
                                    </div>
                                    <div class="form-group col-sm-2">
                                        <label for="to_date">To Date</label>
                                        <input type="text" class="form-control search_datepicker" id="to_date" name="to_date"  value="<?= $to_date  ?>" autocomplete="off">
                                    </div>
                                    <div class="form-group col-sm-6" style="margin-top: 25px;">
                                        <button type="submit" class="btn btn-success">Search <i class="fa fa-search"></i></button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <div class="clearfix"></div>
                        <div class="box-body table-responsive">
                        <table id="example2" class="table table-bordered table-hover text-center">
                            <thead>
                                <tr>
                                    <th>Sl</th>
                                    <th>Date</th>
                                    <th>Place</th>
                                    <th>Doctor Name</th>
                                    <th>Doctor Assistant</th>
                                    <th>Counsellor Name</th>
                                    <th>Salesman</th>
                                    <th>Nurse</th>
                                    <th>Patient Name</th>
                                    <th>OT Advance</th>
                                    <th>Medicine Total</th>
                                    <th>Optic Total</th>
                                    <th>Remarks</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sl = 0;
                                $totalOtAdvance = 0;
                                $totalMedicine  = 0;
                                $totalOptic     = 0;

                                foreach ($values as $single_value) {
                                    $doctor         = $single_value->doctor ?? null;
                                    $salesman       = $single_value->salesman ?? null;
                                    $nurse          = $single_value->nurse ?? null;
                                    $patient        = $single_value->patient ?? null;

                                    $otAdvance      = (float) ($single_value->ot_adv ?? 0);
                                    $medicineTotal  = (float) ($single_value->medicine_total ?? 0);
                                    $opticTotal     = (float) ($single_value->optic_total ?? 0);

                                    $totalOtAdvance += $otAdvance;
                                    $totalMedicine  += $medicineTotal;
                                    $totalOptic     += $opticTotal;

                                    ?>
                                    <tr>
                                        <td><?= ++$sl ?></td>
                                        <td><?= $single_value->date ?? '' ?></td>
                                        <td><?= $single_value->place ?? '' ?></td>
                                        <td><?= $doctor ? $doctor->name . ' [' . $doctor->record_id . ']' : '' ?></td>
                                        <td><?= $single_value->dr_assistant ?? '' ?></td>
                                        <td><?= $single_value->counsellor_name ?? '' ?></td>
                                        <td><?= $salesman ? $salesman->name . ' [' . $salesman->record_id . ']' : '' ?></td>
                                        <td><?= $nurse ? $nurse->name . ' [' . $nurse->record_id . ']' : '' ?></td>
                                        <td><?= $patient ? $patient->name . ' [' . $patient->record_id . ']' : '' ?></td>
                                        
                                        <td class="text-right"><?= currency($otAdvance) ?></td>
                                        <td class="text-right"><?= currency($medicineTotal) ?></td>
                                        <td class="text-right"><?= currency($opticTotal) ?></td>
                                        <td><?= $single_value->remarks ?></td>
                                        <td>
                                            <a class="btn btn-info"
                                               href="<?= base_url($bUrl . '/edit/' . (int) $single_value->id) ?>" title="Edit Campaign" aria-label="Edit Campaign"><i class="fa fa-pencil"></i>
                                            </a>
                                            <a class="btn btn-danger"
                                               href="<?= base_url($bUrl . '/delete/' . (int) $single_value->id) ?>" title="Delete Campaign" aria-label="Delete Campaign" onclick="return confirm('Are you sure to delete this record?')"><i class="fa fa-trash-o"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th colspan="9" class="text-right">Total :</th>
                                    <th class="text-right"><?= currency($totalOtAdvance) ?></th>
                                    <th class="text-right"><?= currency($totalMedicine) ?></th>
                                    <th class="text-right"><?= currency($totalOptic) ?></th>
                                    <th colspan="2"></th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    </div>
                </div>
            </section>
        </div>
    </section>
</aside>
