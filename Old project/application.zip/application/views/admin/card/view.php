<section class="content">
<?php
$user_type = $this->session->ses_user_type;
	$contact = $this->Common_model->findById('contact',array('id'=>1));
	$APP_NAME = isset($contact)?$contact->c_name:'' ;
	$helpline = isset($contact)?$contact->hotline:'' ;
	$logo = LOGO ;
	if(isset($contact)){
		if(file_exists($contact->logo)){
			$logo = $contact->logo;
		}
	}
	$logo = base_url($logo);
?>
    <style>
        table > tbody > tr > td{
            padding: 0 20px;
        }
        html {
            font-size: 17px;
            color: rgb(255, 255, 255);
            font-family: 'Heebo', sans-serif;
            /* font-family: "Source Sans Pro", sans-serif; */
            background-color: #ffffff;
        }

        .front-side,
        .back-side {
            width: 390px;
            height: 220px;
            display: grid;
            grid-template-columns: 2% 96% 2%;
            grid-template-rows: 4% 92% 4%;
            position: relative;
            margin: 20px auto;
            overflow: hidden;
            box-shadow: 2px 5px 15px 0px #17161694;
            background-color: darkgoldenrod!important;
        }

        .color-grid {
            /*display: grid;
            grid-template-columns: repeat(3, 150px);*/
            grid-template-rows: repeat(8, 50px);
            grid-gap: 8px;
            width: 150px;
            height: 400px;
            transform: rotate(-45deg);
        }

        .black {
            background-color: #343536;
            grid-column: 2 / span 2;
            grid-row: 1 / span 3;
        }

        .red1 {
            background-color: #e45e4f;
            grid-row: 2 / span 5;
        }

        .red2 {
            background-color: #e45e4f;
            grid-column: 2 / span 2;
            grid-row: 4/7;
        }

        .green {
            background-color: #007e67;
            grid-column: 2/4;
            grid-row: 7/9;
        }

        .info-grid {
            grid-column: 2/3;
            grid-row: 2/3;
            z-index: 2;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.363);
            box-shadow: 0px 2px 15px rgba(0, 0, 0, 0.432);
            border-radius: 6px;
            font-size: 0.7rem;
            /*12px;*/
            display: grid;
            grid-template-columns: 15px repeat(3, 1fr) 15px;
            grid-template-rows: repeat(3, 1fr);
            line-height: 1px;
        }

        .info-grid .name {
            grid-column: 2 / span 2;
            grid-row: 1 / span 1;
            font-size: 1.2em;
            letter-spacing: .1rem;
            /*margin-top: 8px;*/
        }

        .info-grid .name h5 {
            font-weight: unset;
        }

        .info-grid .addr {
            grid-column: 2 / span 2;
            grid-row: 3;
        }

        .info-grid .phoneNo {
            grid-column: 3 / span 2;
            grid-row: 2;
            text-align: start;
        }

        .info-grid .emailId {
            grid-column: 3 / span 2;
            grid-row: 3;
            text-align: end;
            font-size: 1.1em;
        }

        .back-side .name-tag {
            grid-column: 1 / span 4;
            grid-row: 2 / span 1;
            align-self: center;
            z-index: 2;
            width: 100%;
            height: 40%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            background-color: rgba(255, 255, 255, 0.363);
            box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.288);
            font-size: 0.6rem;
            /*12px;*/
            letter-spacing: .1rem;
            text-align: center;
        }

        .name-tag h1,
        h3 {
            margin: 2px;
            font-weight: unset;
        }

        .credits {
            margin-top: 40px;
            text-align: center;
            color: #343536;
        }
    </style>
    <div id="invoice">
        <div class="report_header">
            <?php $this->load->view('admin/common/report_header_print') ?>
        </div>
        <div class="container">

            <body>
                <div class="front-side">
                    <div class="color-grid">
                        <div class="black"></div>
                        <div class="red1"></div>
                        <div class="red2"></div>
                        <div class="green"></div>
                    </div>
                    <div class="info-grid1">
                        <div class="name1">
                            <h4><?=$APP_NAME?></h4>
                            <hr style="margin: 10px!important;">
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                            <table>
                                <tr>
                                    <td>Name</td>
                                    <td>: <?=isset($patient)?$patient->name:""?></td>
                                </tr>
                                <tr>
                                    <td>Card No</td>
                                    <td>: <?=isset($value)?$value->card_prefix.$value->card_no:""?></td>
                                </tr>
                                <tr>
                                    <td>Issue Date</td>
                                    <td>: <?=isset($value)?$value->issue_date:""?></td>
                                </tr>
                                <tr>
                                    <td>Validity Date</td>
                                    <td>: <?=isset($value)?$value->expiry_date:""?></td>
                                </tr>
                            </table>
                            </div>
                        </div>

                        <hr style="margin: 10px!important;">
                        <p class="text-right">Our Patient Discount Card ||
                            Helpline : <?=$helpline?>
                        </p>
                        
                    </div>
                </div>
            </body>
        </div>
    </div>
</section>