<aside>
    <section class="content">
        <div class="row">
            <section class="col-xs-12 connectedSortable">
                <div class="box box-info no_print">
                    <div class="box-header">
                        <h3 class="box-title"><?= isset($page_title) ? $page_title : '' ?></h3>
                    </div>
                    <?php echo form_open_multipart('card/saveOrUpdate'); ?>
                    <div class="box-body">
                        <div class="row">
                        <div class="form-group col-sm-3 col-xs-12">
                                <label for="patient_id">Patient (<span class="required">*</span>) </label>
                                <div class="input-group">
                                    <select name="patient_id" id="patient_id" class="form-control selectpicker" data-live-search="true" required="">
                                        <?= options(
                                            'patient',
                                            array(),
                                            array('record_id', 'name'),
                                            'record_id',
                                            '',
                                            'record_id',
                                            'desc',
                                            'Select Patient',
                                            isset($value) ? $value->patient_id : 0,
                                            array('name', 'age', 'mobile', 'gender')
                                        )
                                        ?>
                                    </select>

                                    <span class="input-group-addon">
                                        <button type="button" id="c_plus" style="height: 20px;" class="btn btn-success fa fa-plus-square btn-sm" data-toggle="modal" data-target="#patientModal">
                                        </button>
                                    </span>
                                </div>
                            </div>
                            <div class="form-group col-sm-3">
                                <label for="card_no">Card No (<span class="required">*</span>) </label>
                                <input type="text" class="form-control" id="card_no" placeholder="" name="card_no" value="<?= $card_no ?>" required="" readonly>
                                <input type="hidden" name="update_id" id="update_id" value="0">
                            </div>
                            <div class="form-group col-sm-3">
                                <label for="issue_date">Issue Date (<span class="required">*</span>) </label>
                                <input type="text" class="form-control search_datepicker" id="issue_date" placeholder="" name="issue_date" value="<?= date('Y-m-d') ?>" required="" autocomplete="off">
                            </div>
                            <div class="form-group col-sm-3">
                                <label for="expiry_date">Validity Date (<span class="required">*</span>) </label>
                                <input type="text" class="form-control search_datepicker" id="expiry_date" placeholder="" name="expiry_date" value="<?= date('Y-m-d') ?>" required="" autocomplete="off">
                            </div>
                            <div class="clearfix"></div>
                            <div class="form-group col-sm-3">
                                <label for="discount">Discount(%) </label>
                                <input type="text" class="form-control text-right numeric" id="discount" placeholder="" name="discount">
                            </div>
                            <div class="col-sm-1">
                                <button type="submit" class="pull-left btn btn-success update mt-25">Create <i class="fa fa-arrow-circle-right"></i></button>
                            </div>
                        </div>
                    </div>

                    </form>
                    <div class="box-body table-responsive">
                        <div class="info-header">
                            <h4><?= isset($info_header) ? $info_header : '' ?></h4>
                        </div>
                        <table id="example2" class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th style="text-align: center;">#</th>
                                    <th style="text-align: center;">Patient</th>
                                    <th style="text-align: center;">Card No</th>
                                    <th style="text-align: center;">Discount</th>
                                    <th style="text-align: center;">Issue_Date</th>
                                    <th style="text-align: center;">Validity_Date</th>
                                    <th style="text-align: center;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $count = 0;
                                foreach ($values as $single_value) {
                                    $patient = $this->Common_model->findById("patient", array("record_id" => $single_value->patient_id));
                                    $count++;
                                ?>
                                    <tr>
                                        <td style="text-align: center;"><?php echo $count; ?></td>
                                        <td style="text-align: center;"><?= isset($patient) ? $patient->name : "" ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->card_prefix . $single_value->card_no; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->discount; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->issue_date; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->expiry_date; ?></td>
                                        <td style="text-align: center;">
                                            <a href="javascript:void(0)" class="btn btn-primary btnEdit" data-record_id="<?= $single_value->record_id ?>"><i class="fa fa-pencil"></i></a>
                                            <a class="btn btn-danger" href="<?= base_url("card/delete/$single_value->record_id") ?>" onclick="return confirm('Are you sure to delete this record?')"><i class="fa fa-trash-o"></i>
                                        </a>
                                        <a href="<?= base_url("card/view/$single_value->record_id") ?>" class="btn btn-primary btnPrint" data-record_id="<?= $single_value->record_id ?>"><i class="fa fa-print"></i></a>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>
        </div>
    </section>
</aside>

<script type="text/javascript">
    $(document).on('click', '.btnEdit', function(e) {
        var id = $(this).data('record_id');
        //alert(id) ;
        var formURL = "<?php echo site_url('crud/edit/cards/record_id'); ?>";
        $.ajax({
            url: formURL,
            type: "POST",
            data: {
                id: id
            },
            dataType: "json",
            success: function(data) {
                console.log(data);
                $('#update_id').val(data.record_id);
                $('#card_no').val(data.card_prefix + '' + data.card_no);
                $('#patient_id').val(data.patient_id).selectpicker('refresh');
                $('#discount').val(data.discount);
                $('#issue_date').val(data.issue_date);
                $('#expiry_date').val(data.expiry_date);
                $('#card_no').focus();
                $('.update').text("Update");
                $("html, body").animate({
                    scrollTop: 0
                }, "slow");
            }
        });
        e.preventDefault();
    });
    $(document).on("change", "#patient_id", function(params) {
        var option, discount;
        option = $("#patient_id :selected");
        discount = option.data('discount');
        $("#discount").val(discount);
    })
</script>