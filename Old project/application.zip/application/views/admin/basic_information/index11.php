
<aside>
    <section class="content">
        <div class="row">
            <section class="col-xs-12 connectedSortable"> 
                <div  class="box box-info no_print">
                    <div class="box-header">
                        <h3 class="box-title"><?=isset($page_title)?$page_title:''?></h3>
                    </div>
                    <?php echo form_open_multipart('department/saveOrUpdate'); ?>
                    <div class="box-body">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group" >
                            <label for="department">Department (<span class="required">*</span>) </label>
                            <input type="text" class="form-control" id="department" placeholder="Enter Department" name="department" value="" required="">
                            <input type="hidden" name="update_id" id="update_id" value="0">
                        </div>
                            </div>
                        </div>
                    </div>
                    <div class="box-footer clearfix">
                        <button type="submit" class="pull-left btn btn-success update">Create <i class="fa fa-arrow-circle-right"></i></button>
                    </div>
                    </form>
                    <div class="box-body table-responsive" style="width: 100%; overflow-x: scroll; color: black;">
                        <div class="info-header">
                            <h4><?=isset($info_header)?$info_header:''?></h4> 
                        </div>
                        <table id="example2" class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th style="text-align: center;">SL</th>
                                    <th style="text-align: center;">Department</th>
                                    <th style="text-align: center;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $count = 0;
                                foreach ($values as $single_value) {
                                    $count++;
                                    ?>
                                    <tr>
                                        <td style="text-align: center;"><?php echo $count; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->department; ?></td>
                                        <td style="text-align: center;">
                                            <a href="javascript:void(0)" class="btn btn-primary btnEdit" data-record_id="<?=$single_value->record_id?>"><i class="fa fa-pencil"></i></a>
                                            <a class="btn btn-danger"
                                               href="<?=base_url("department/delete/$single_value->record_id")?>" onclick="return confirm('Are you sure to delete this record?')"><i class="fa fa-trash-o"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>
        </div>
    </section>
</aside>
<script type="text/javascript">
    $(document).on('click','.btnEdit',function(e){
        var id = $(this).data('record_id');
        var formURL = "<?php echo site_url('crud/edit/department/record_id'); ?>";
          $.ajax(
          {
            url : formURL,
            type: "POST",
            data : {id: id},
            dataType: "json",
            success:function(data){
              $('#update_id').val(data.record_id);
              $('#department').val(data.department);
              $('#department').focus();
              $('.update').text("Update");
              $("html, body").animate({ scrollTop: 0 }, "slow");
            }
          });
          e.preventDefault();
        });
</script>