
    <section class="content">
        <div class="row">
            <section class="col-xs-12 connectedSortable">
                <div class="box box-info">
                    <div class="box-header">
                        <h3 class="box-title"><?=isset($page_title)?$page_title:''?></h3>
                    </div>
                    <form action="<?=base_url('basic_information/saveOrUpdate')?>" method="POST"  enctype="multipart/form-data">
                    <div class="box-body">
                        <div class="row">
                            <div class="form-group col-sm-4 col-xs-12">
                                <label for="title">Select Title (<span class="required">*</span>)</label>
                                <select name="title" id="title" class="form-control selectpicker"
                                        data-container="body" required>
                                    <option value="">-- Select --</option>
                                    <option value="1">Hospital Profile</option>
                                    <option value="2">Message from Chairman</option>
                                    <option value="3">Message from Managing Director</option>
                                    <option value="4">X-Ray Description</option>
                                    <option value="9">Ultrasonography</option>
                                    <option value="12">ECG</option>
                                </select>
                                <input type="hidden" name="update_id" id="update_id" value="0">
                            </div>
                            <div class="form-group col-sm-4 col-xs-12">
                                <label for="image">Image (If Any)</label>
                                <input type="file" class="form-control" id="image" placeholder="" name="image">
                            </div>
                            <div class="form-group col-sm-4 col-xs-12">
                                <div>
                                    <img id="img_content" id="img_content" class="img-responsive" style="width: 100px;height: 110px;">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-sm-8 col-xs-12">
                                <label for="details">Details (<span class="required">*</span>)</label>
                                <textarea rows="6" class="form-control" id="details" name="details" required></textarea>
                            </div>
                        </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <button type="submit" class="pull-left btn btn-success">Submit <i
                                            class="fa fa-arrow-circle-right"></i>
                                </button>
                                </div>
                            </div>
                        </div>
                    </form>
                    </div>
                </div>

                <div class="box box-info">
                    <div class="info-header">
                        <h4><?=isset($info_header)?$info_header:''?></h4> 
                    </div>

                    <!-- /.box-header -->
                    <div class="box-body table-responsive">
                        <table id="example2" class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                <th style="text-align: center;">SL</th>
                                <th style="text-align: center;">Title</th>
                                <th style="text-align: center;">Image</th>
                                <th style="text-align: center;">Details</th>
                                <th style="text-align: center;">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php
                            $count = 0;
                            foreach ($values as $single_value) {
                                $count++;
                                ?>
                                <tr>
                                    <td style="text-align: center;"><?php echo $count; ?></td>
                                    <td style="text-align: center;">
                                        <?php
                                        $title_id = $single_value->title;
                                        if ($title_id == 1) {
                                            echo "Hospital Profile";
                                        } elseif ($title_id == 2) {
                                            echo "Message from Chairman";
                                        } elseif ($title_id == 3) {
                                            echo "Message from Director";
                                        } elseif ($title_id == 4) {
                                            echo "X-ray Description";
                                        } elseif ($title_id == 5) {
                                            echo "Message from Upazilla Chairman";
                                        } elseif ($title_id == 6) {
                                            echo "Message from UNO";
                                        } elseif ($title_id == 7) {
                                            echo "Message from Meyor";
                                        } elseif ($title_id == 8) {
                                            echo "Mission-Vision";
                                        } elseif ($title_id == 9) {
                                            echo "Ultrasonography";
                                        } elseif ($title_id == 10) {
                                            echo "IService List";
                                        } elseif ($title_id == 11) {
                                            echo "Dress Code";
                                        }elseif ($title_id == 12) {
                                            echo "ECG";
                                        }
                                        ?>
                                    </td>
                                    <td style="text-align: center;">
                                        <?php if (file_exists($single_value->image)) { ?>
                                            <img src="<?=base_url($single_value->image)?>"
                                                 style="width: 100px; height: 70px;">
                                        <?php } else {
                                            echo "No Image";
                                        } ?>
                                    </td>
                                    <td style="text-align: justify;"><?php echo $single_value->details; ?></td>
                                    <td style="text-align: center;">
                                        <a style="margin: 5px;" data-record_id="<?=$single_value->record_id?>"
                                           href="javascript:void(0)"
                                           class="btn btn-info btnEdit"><i class="fa fa-pencil"></i>
                                        </a>
                                        <a style="margin: 5px;"
                                           href="<?=base_url("basic_information/delete/$single_value->record_id")?>" class="btn btn-danger" onclick="return confirm('Are you sure to this record?')"><i class="fa fa-trash-o"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php } ?>
                            </tbody>

                        </table>
                    </div><!-- /.box-body -->
                </div>
            </section>
        </div>
    </section>
    <script type="text/javascript">
        var base_url = "<?=base_url('/')?>" ;
    $(document).on('click','.btnEdit',function(e){
        var id = $(this).data('record_id');
        var formURL = "<?php echo site_url('crud/edit/single_page_content/record_id'); ?>";
          $.ajax(
          {
            url : formURL,
            type: "POST",
            data : {id: id},
            dataType: "json",
            success:function(data){
              $('#update_id').val(data.record_id);
              $('#title').val(data.title);
              $('#details').html(data.details);
              $('#img_content').attr('src',base_url + data.image);
              $("#title").selectpicker('refresh');
              $('#title').focus();
              $('.update').text("Update");
              $("html, body").animate({ scrollTop: 0 }, "slow");
            }
          });
          e.preventDefault();
        });
</script>