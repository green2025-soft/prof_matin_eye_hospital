<section class="content">
    <div id="invoice">
        <div class="report_header">
            <?php $this->load->view('admin/common/report_header') ?>
        </div>
        
        <div class="container">
            <?php $this->load->view('admin/common/report_header_barcode'); ?>
            <div class="row patient_area">
                <div class="form-group col-md-4 col-xs-4" style="color: black !important; font-size: 20px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Ambul No: </b><?=isset($patient)?$ambulance->ambulance_no.' - ' . $ambulance->ambulance_type:''?>
                </div>
                <div class="form-group col-md-4 col-xs-4" style="text-align:center; color: black !important; font-size: 20px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Trip No: </b><?=$value->trip_no?>
                </div>
                <div class="form-group col-md-4 col-xs-4" style="text-align:right; color: black !important; font-size: 20px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Times: </b><?=$value->date?>
                </div>
                <div class="clearfix"></div>
                <div class="form-group col-md-4 col-xs-4" style="color: black !important; font-size: 20px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Patient : </b><?=isset($patient)?$patient->name:''?>
                </div>
                
                
                
                <div class="form-group col-md-4 col-xs-4" style="text-align:center; color: black !important; font-size: 20px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Age: </b><?=isset($patient)?$patient->age:''?>
                </div>
                <div class="form-group col-md-4 col-xs-4" style="text-align:right; color: black !important; font-size: 20px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Gender: </b><?=isset($patient)?$patient->gender:''?>
                </div>
                <div class="clearfix"></div>
                <div class="form-group col-md-4 col-xs-4" style="color: black !important; font-size: 20px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Road: </b><?=$value->road_name?>
                </div>
                <div class="form-group col-md-4 col-xs-4" style="text-align:center; color: black !important; font-size: 20px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Driver: </b><?=$value->driver_name?>
                </div>
                <div class="form-group col-md-4 col-xs-4" style="text-align:right; color: black !important; font-size: 20px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Mobile No: </b><?=$value->driver_mobile_no?>
                </div>
            </div>
            <div class="row" style="margin-top:10px;">
                <div class="col-md-12">
                    
                </div>
            </div>

            <div class="row">
                <div class="form-group col-sm-12 col-xs-12" style="text-align: center; font-weight: bold; padding-bottom: 0px; margin-bottom: 0px;">
                    <table id="" class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th style="text-align: center;">Particular</th>
                                <th style="text-align: center;">Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="text-align: center;">Total Receive</td>
                                <td style="text-align: center;"><?php echo $value->total_receive; ?></td>
                            </tr>
                            
                        </tbody>
                        <tfoot>
                            <tr>
                                <td style="text-align: right;" colspan="2">In Word:<?php echo $this->numbertowords->convert_number($value->total_receive); ?> Taka Only.</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <p>
                            <span style="font-weight: 700;text-decoration: underline;font-size: 16px;">Comments : </span> <?=$value->comments?>
                        </p>
                    </div>
                </div>
            </div>

            <?php $this->load->view('admin/common/report_footer') ?>
        </div>
        <?php $this->load->view('admin/common/copyright') ?>
    </div>
</section>

