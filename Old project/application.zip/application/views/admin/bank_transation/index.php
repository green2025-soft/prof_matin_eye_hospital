<aside >
    <section class="content">
        <div class="row">
            <section class="col-xs-12 connectedSortable"> 
                <div class="box box-info no_print">
                    <div class="box-header">
                        <h3 class="box-title"><?=isset($page_title)?$page_title:''?></h3>
                    </div>
                    <div class="box-body">
                        <div class="box-body table-responsive">
                        <table id="example2" class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th style="text-align: center;">SL</th>
                                    <th style="text-align: center;">Date</th>
                                    <th style="text-align: center;">Type</th>
                                    <th style="text-align: center;">Bank Name</th>
                                    <th style="text-align: center;">Account No</th>
                                    <th style="text-align: center;">Amount</th>
                                    <th style="text-align: center;">Remarks</th>
                                    <th style="text-align: center;">Created</th>
                                    <th style="text-align: center;width: 190px;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $count = 0;
                                foreach ($values as $single_value) {
                                    $count++;
                                    $bank = $this->Common_model->findById('banks',array('record_id'=>$single_value->bank_id)) ;
                                    ?>
                                    <tr>
                                        <td style="text-align: center;"><?php echo $count; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->date; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->transation_type; ?></td>
                                        <td style="text-align: center;"><?=isset($bank)?$bank->bank_name:''?></td>
                                        <td style="text-align: center;"><?=isset($bank)?$bank->account_no:''?></td>

                                        <td style="text-align: center;"><?php echo $single_value->amount; ?></td>
                                        <td style="text-align: right;"><?php echo $single_value->carry_received; ?></td>
                                         <td style="text-align: center;"><?=creator($single_value->created_by)?></td>
                                        <td style="text-align: center;">
                                            <a class="btn btn-info"
                                               href="<?=base_url("bank_transation/edit/$single_value->record_id"); ?>"><i class="fa fa-pencil"></i>
                                            </a>
                                            <a class="btn btn-danger"
                                               href="<?=base_url("bank_transation/delete/$single_value->record_id"); ?>" onclick="return confirm('Are you sure to delete this record?')"><i class="fa fa-trash-o"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                    </div>
                </div>
            </section>
        </div>
    </section>
</aside>