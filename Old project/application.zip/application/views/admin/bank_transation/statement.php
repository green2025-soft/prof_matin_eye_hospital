<section class="content">
    <section class="content">
        <div class="row">
            <section class="col-xs-12 connectedSortable"> 
                <div class="box box-info no_print">
                    <div class="box-header">
                        <h3 class="box-title"><?=isset($page_title)?$page_title:''?></h3>
                    </div>
                    <form action="<?=base_url('bank_transation/bank_statement')?>" method="GET">
                    <div class="box-body">
                        <div class="row">

                            <div class="form-group col-sm-3">
                                <label for="from_date">From Date </label>
                                <input type="text" class="form-control search_datepicker" id="from_date" 
                                placeholder="" name="from_date" value="<?=isset($from_date)?$from_date:''?>" autocomplete="off">
                            </div>
                            <div class="form-group col-sm-3">
                                <label for="to_date">To Date </label>
                                <input type="text" class="form-control search_datepicker" id="to_date" 
                                placeholder="" name="to_date" value="<?=isset($to_date)?$to_date:''?>" autocomplete="off">
                            </div>
                            <div class="form-group col-sm-3">
                                <label for="bank_id">Bank/Partner</label>
                                
                                <select name="bank_id" id="bank_id" class="form-control selectpicker"
                                data-live-search="true">
                                <?=options(
                                    'banks',
                                    array(), 
                                    array('record_id','bank_name','account_no'),
                                    'record_id',
                                    '',
                                    'record_id',
                                    'desc',
                                    'Select Bank/Partner',isset($bank_id)?$bank_id:0)
                                    ?>
                                </select>

                            </div>
                            <div class="form-group col-sm-3">
                                <label for="date">Type </label>
                                <select class="form-control" id="transation_type" name="transation_type">
                                    <option value="">--Select Type--</option>
                                    <option value="Deposit" <?php if(isset($transation_type)){ if($transation_type == 'Deposit'){echo "selected";}} ?>>Deposit</option>
                                    <option value="Withdraw" <?php if(isset($transation_type)){ if($transation_type == 'Withdraw'){echo "selected";}} ?>>Withdraw</option>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-sm-12 text-center col-xs-12">
                                <div class="box-footer1 clearfix">
                                    <button type="submit" class=" btn btn-success" style="margin-top: 25px;">Search <i class="fa fa-search"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>

                </form>
            </div>
        </section>
    </div>
</section>
<div id="invoice">
    <div class="report_header">
        <?php $this->load->view('admin/common/report_header') ?>
    </div>

    <div class="container">
        <div class="row" style="margin-top:10px;">
            <div class="col-md-12">
                <h4 class="text-center"><?=$range?></h4>
            </div>
        </div>

        <div class="row">
            <div class="form-group col-sm-12 col-xs-12" style="text-align: center; font-weight: bold; padding-bottom: 0px; margin-bottom: 0px;">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th style="text-align: center;">SL</th>
                            <th style="text-align: center;">Date</th>
                            <th style="text-align: center;">Type</th>
                            <th style="text-align: center;">Bank/Partner Name</th>
                            <th style="text-align: center;">Account No</th>
                            <th style="text-align: center;">Amount</th>
                            <th style="text-align: center;">Balance</th>
                            <th style="text-align: center;">Remarks</th>
                        </tr>
                    </thead>
                    <tbody>
                         <tr>
                            <td colspan="6" class="text-right"><b>Opening  Blance</b> </td>
                            <td class="text-center"><b><?= currency($openingBalance??0) ?></b></td>
                            <td></td>
                        </tr>
                        <?php
                        $count = 0;
                        $balance = $openingBalance??0;
                        // dd($balance );
                        if(count($values) > 0 ){
                        foreach ($values as $single_value) {
                            $count++;
                            $bank = $this->Common_model->findById('banks',array('record_id'=>$single_value->bank_id)) ;
                            if($single_value->transation_type == 'Deposit'){
                                $balance += $single_value->amount;
                            }elseif($single_value->transation_type == 'Withdraw'){
                                $balance -= $single_value->amount ;
                            }
                            ?>
                            <tr>
                                <td style="text-align: center;"><?php echo $count; ?></td>
                                <td style="text-align: center;"><?php echo $single_value->date; ?></td>
                                <td style="text-align: center;"><?php echo $single_value->transation_type; ?></td>
                                <td style="text-align: center;"><?=isset($bank)?$bank->bank_name:''?></td>
                                <td style="text-align: center;"><?=isset($bank)?$bank->account_no:''?></td>

                                <td style="text-align: center;"><?php echo $single_value->amount; ?></td>
                                <td style="text-align: center;"><?=$balance?></td>
                                <td style="text-align: center;"><?php echo $single_value->carry_received; ?></td>

                            </tr>
                        <?php }}else{?>
                            <tr>
                                <td colspan="8">
                                    <h3 class="text-center">There is no data available here.</h3>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th colspan="6" class="text-right"> Closing Blance</th>
                            <th class="text-center"><?= currency($balance) ?></th>
                            <th></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>

        <?php if(count($values) > 1 ){ $this->load->view('admin/common/report_footer') ;} ?>
    </div>
</div>
</section>
    <?php if(count($values) > 1 ){ $this->load->view('admin/common/copyright') ;} ?>

