
<aside >
    <section class="content">
        <div class="row">
            <section class="col-xs-12 connectedSortable"> 
                <div class="box box-info no_print">
                    <div class="box-header">
                        <h3 class="box-title"><?=isset($page_title)?$page_title:''?></h3>
                    </div>
                    <form id="frmBankTransation" action="<?=base_url('bank_transation/saveOrUpdate')?>" method="POST">
                    <div class="box-body">
                        <div class="row">
                            
                            <div class="form-group col-sm-4">
                                <label for="date">Date (<span class="required">*</span>) </label>
                                <input type="text" class="form-control closing_datepicker" id="date" 
                                placeholder="" name="date" value="<?=isset($value)?$value->date:closing_date(date('Y-m-d'))?>" required="" autocomplete="off" required>
                            </div>
                            <div class="form-group col-sm-4">
                                <label for="bank_id">Bank/Partner (<span class="required">*</span>) </label>
                                <div class="input-group">
                                    <select name="bank_id" id="bank_id" class="form-control selectpicker"
                                    data-live-search="true" required="">
                                    <?=options(
                                        'banks',
                                        array(), 
                                        array('record_id','bank_name','account_no'),
                                        'record_id',
                                        '',
                                        'record_id',
                                        'desc',
                                        'Select Bank/Partner',isset($value)?$value->bank_id:0)
                                        ?>
                                    </select>

                                    <span class="input-group-addon">
                                        <button type="button" id="c_plus" style="height: 20px;"
                                        class="btn btn-success fa fa-plus-square btn-sm" data-toggle="modal" data-target="#bankModal">
                                    </button>
                                </span>
                            </div>
                            <div id="bank_balance" style="display: none;;">
                                Balance : <span id="account_balance"></span>
                            </div>
                        </div>
                           <div class="clearfix"></div>
                            <div class="form-group col-sm-3">
                                <label for="date">Type (<span class="required">*</span>) </label>
                                <select class="form-control" id="transation_type" name="transation_type" required="">
                                    <option value="">--Select Type--</option>
                                    <option value="Deposit" <?php if(isset($value)){ if($value->transation_type == 'Deposit'){echo "selected";}} ?>>Deposit</option>
                                    <option value="Withdraw" <?php if(isset($value)){ if($value->transation_type == 'Withdraw'){echo "selected";}} ?>>Withdraw</option>
                                </select>
                            </div>

                            
                     
                        <div class="form-group col-sm-3">
                                <label for="amount">Amount (<span class="required">*</span>) </label>
                                <input type="text" class="form-control text-right numeric" id="amount" placeholder="" name="amount" value="<?=isset($value)?$value->amount:''?>" required="">
                                <input type="hidden" name="update_id" id="update_id" value="<?=isset($value)?$value->record_id:0?>">
                            </div>
                        <div class="form-group col-sm-4">
                            <label for="carry_received">Remarks </label>
                            <input type="text" class="form-control" id="carry_received" placeholder="" name="carry_received" value="<?=isset($value)?$value->carry_received:''?>">
                        </div>

                    </div>
                    <div class="row">
                        <div class="form-group col-sm-12 col-xs-12 text-center">
                            <div class="box-footer1 clearfix">
                                <button type="submit" class="btn btn-success submit" style="margin-top: 25px;">Submit <i class="fa fa-arrow-circle-right"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
                
            </form>
        </div>
    </section>
</div>
</section>
</aside>
<script type="text/javascript">
    $(document).on('change','#bank_id',function(e){
        var bank_id = $('#bank_id').val();
        if(!bank_id){
            $('#bank_balance').hide(1000);
            return;
        }
        var formURL = "<?=base_url('bank_transation/get_bank_account_balance'); ?>";
        $.ajax(
        {
            url : formURL,
            type: "POST",
            data : {bank_id: bank_id},
            dataType: "html",
            success:function(data){
                $('#bank_balance').show(1000);
                $('#account_balance').html(data);
          }
      });
        e.preventDefault();
    })
/*    $(document).on('change','#transation_type',function(e){
        var transation_type = $('#transation_type').val() ;
        var account_balance = $('#account_balance').text();
        account_balance = +account_balance ;
        if(account_balance == 0 && transation_type == 'Withdraw'){
            $('.submit').hide(1000);
        }else{
            $('.submit').show(1000);
        }
    })*/

    $(document).on('submit','#frmBankTransation',function(e){
        var transation_type = $('#transation_type').val() ;
        var account_balance = $('#account_balance').text();
        account_balance = +account_balance ;
        var amount = $('#amount').val();
        amount = +amount ;
        if(account_balance == 0 && transation_type == 'Withdraw'){
            alert('There is no account balance in this bank!');
            return false;
        }
        if(amount > account_balance && transation_type == 'Withdraw'){
            alert('Withdraw amount should be less than or equal account balance!');
             return false;
        }
    })
    $(document).on('keyup','#amount',function(){
        var transation_type = $('#transation_type').val() ;
        var account_balance = $('#account_balance').text();
        account_balance = +account_balance ;
        var amount = $('#amount').val();
        amount = +amount ;
        /*if(account_balance == 0 && transation_type == 'Withdraw'){
            alert('There is no account balance in this bank!');
            $(this).val(account_balance);
        }*/
        if(amount > account_balance && transation_type == 'Withdraw'){
            alert('Withdraw amount should be less than or equal account balance!');
            $(this).val(account_balance);
        }
    })
</script>