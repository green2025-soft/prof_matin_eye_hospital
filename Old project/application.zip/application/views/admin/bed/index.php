
<aside>
    <section class="content">
        <div class="row">
            <section class="col-xs-12 connectedSortable"> 
                <div  class="box box-info no_print">
                    <div class="box-header">
                        <h3 class="box-title"><?=isset($page_title)?$page_title:''?></h3>
                    </div>
                    <?php echo form_open_multipart('bed/saveOrUpdate'); ?>
                    <div class="box-body">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group" >
                                    <label for="opd_cabin_ward">OPD/Cabin/Ward (<span class="required">*</span>) </label>
                                    <select class="form-control" id="opd_cabin_ward" name="opd_cabin_ward" value="" required="">
                                        <option value="OPD">OPD</option>
                                        <option value="Cabin">Cabin</option>
                                        <option value="Ward">Ward</option>
                                    </select>
                                    <input type="hidden" name="update_id" id="update_id" value="0">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group" >
                                    <label for="floor_no">Floor No (<span class="required">*</span>) </label>
                                    <input type="text" class="form-control" id="floor_no" placeholder="Enter Floor No" name="floor_no" value="" required="">
                                </div>
                            </div><div class="col-md-4">
                                <div class="form-group" >
                                    <label for="room_no">Room No (<span class="required">*</span>) </label>
                                    <input type="text" class="form-control" id="room_no" placeholder="Enter Room No" name="room_no" value="" required="">
                                </div>
                            </div><div class="col-md-4">
                                <div class="form-group" >
                                    <label for="bed_no">Bed No (<span class="required">*</span>) </label>
                                    <input type="text" class="form-control" id="bed_no" placeholder="Enter Bed No" name="bed_no" value="" required="">
                                </div>
                            </div><div class="col-md-4">
                                <div class="form-group" >
                                    <label for="bed_type">Bed Type (<span class="required">*</span>) </label>
                                    <select class="form-control" id="bed_type" name="bed_type" value="" required="">
                                        <option value="Non AC">Non AC</option>
                                        <option value="AC">AC</option>
                                        <option value="VIP">VIP</option>
                                    </select>
                                </div>
                            </div><div class="col-md-4">
                                <div class="form-group" >
                                    <label for="charge">Charge(<span class="required">*</span>) </label>
                                    <input type="text" class="form-control text-right numeric" id="charge" placeholder="Enter Charge" name="charge" value="" required="">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="box-footer clearfix">
                        <button type="submit" class="pull-left btn btn-success update">Create <i class="fa fa-arrow-circle-right"></i></button>
                    </div>
                </form>
                <div class="box-body table-responsive">
                    <div class="info-header">
                        <h4><?=isset($info_header)?$info_header:''?></h4> 
                    </div>
                    <table id="example2" class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th style="text-align: center;">SL</th>
                                <th style="text-align: center;">OPD/Cabin/Ward</th>
                                <th style="text-align: center;">Floor No</th>
                                <th style="text-align: center;">Room No</th>
                                <th style="text-align: center;">Bed No</th>
                                <th style="text-align: center;">Bed Type</th>
                                <th style="text-align: center;">Charge</th>
                                <th style="text-align: center;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $count = 0;
                            foreach ($values as $single_value) {
                                $count++;
                                ?>
                                <tr>
                                    <td style="text-align: center;"><?php echo $count; ?></td>
                                    <td style="text-align: center;"><?=$single_value->opd_cabin_ward?></td>
                                    <td style="text-align: center;"><?=$single_value->floor_no?></td>
                                    <td style="text-align: center;"><?=$single_value->room_no?></td>
                                    <td style="text-align: center;"><?=$single_value->bed_no?></td>
                                    <td style="text-align: center;"><?=$single_value->bed_type?></td>
                                    <td style="text-align: center;"><?=$single_value->charge?></td>
                                    <td style="text-align: center;">
                                        <a href="javascript:void(0)" class="btn btn-primary btnEdit" data-record_id="<?=$single_value->record_id?>"><i class="fa fa-pencil"></i></a>
                                        <a class="btn btn-danger"
                                        href="<?=base_url("bed/delete/$single_value->record_id")?>" onclick="return confirm('Are you sure to delete this record?')"><i class="fa fa-trash-o"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</div>
</section>
</aside>
<script type="text/javascript">
    $(document).on('click','.btnEdit',function(e){
        var id = $(this).data('record_id');
        var formURL = "<?php echo site_url('crud/edit/beds/record_id'); ?>";
        $.ajax(
        {
            url : formURL,
            type: "POST",
            data : {id: id},
            dataType: "json",
            success:function(data){
              $('#update_id').val(data.record_id);
              $('#opd_cabin_ward').val(data.opd_cabin_ward);
              $('#opd_cabin_ward').focus();
              $('#floor_no').val(data.floor_no);
              $('#room_no').val(data.room_no);
              $('#bed_no').val(data.bed_no);
              $('#bed_type').val(data.bed_type);
              $('#charge').val(data.charge);
              $('.update').text("Update");
              $("html, body").animate({ scrollTop: 0 }, "slow");
          }
      });
        e.preventDefault();
    });
</script>