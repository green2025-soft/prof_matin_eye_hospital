<section class="content">
    <div id="invoice">
        <div class="report_header">
            <?php $this->load->view('admin/common/report_header') ?>
        </div>
        
        <div class="container">
            <div class="row" style="margin-top:10px;">
                <div class="col-md-12">
                    <p class="report_title"><?=isset($page_title)?$page_title:''?></p>
                </div>
            </div>

            <table class="table table-bordered1">
        <thead>
          <tr>
            <td colspan="10">
              <div class="" style="padding: 5px;border: 1px solid #000">
                <table class="" width="100%">
                  <tr>
                    <td style="width: 15%;">Invoice No</td>
                    <td style="width: 45%">: <?=isset($value)?$value->prefix.$value->in_no:''?></td>
                    <td>Supplier</td>
                    <td>: <?=isset($supplier)?$supplier->supplier_name.'['.$supplier->record_id.']':''?></td>
                  </tr>
                  <tr>
                    <td>Date</td>
                    <td>: <?=isset($value)?$value->in_date:''?></td>
                    <td>Supp_Invoice</td>
                    <td>: <?=isset($value)?$value->supplier_invoice:''?></td>
                  </tr>
                </table>
              </div>
            </td>
          </tr>
          <tr>
            <th>#</th>
            <th style="text-align: left;">Product Name</th>
            <th style="text-align: center;">Qty</th>
            <th style="width:10%;text-align: center;">Price</th>
            <th style="width:10%;text-align: center;">Total</th>
          </tr>
        </thead>
         <tbody>
          <?php $i = 0;$grand_net_total = 0 ; $grand_order_qty =0; 
          foreach ($values as $key1 => $value1) {
            ++$i;
            $grand_net_total += $value1->total_price;
            $grand_order_qty += $value1->quantity;
            $product = $this->Common_model->findById('product_name',array('record_id'=>$value1->product_id));
            ?>
              <tr>
                <td><?=$i?></td>
                <td style="text-align: left;"><?=isset($product)?$product->product_name.'[' .$product->code_no.']':''?>
                </td>
                <td style="text-align: center;"><?=$value1->quantity?></td>
                <td style="text-align: center;"><?=$value1->unit_price?></td>
                <td style="text-align: center;"><?=$value1->total_price?></td>
             </tr>
          <?php } ?>
         </tbody>
         <tfoot>
           <tr>
              <th colspan="2" style="text-align: right;"><strong>Total  :</strong></th>
              <th style="text-align: center;"><?=$grand_order_qty?></th>
              <th>&nbsp;</th>
              <th style="text-align: center;"><?=$grand_net_total?></th>
           </tr>
           <tr>
             <td colspan="9" style="border-top:none!important;">In word : <?=$this->numbertowords->convert_number($grand_net_total).' Tk Only.'?></td>
           </tr>
           <tr>
             <td colspan="9" style="border-top:none!important;">&nbsp;</td>
           </tr>
         </tfoot>
      </table>

           

            <?php $this->load->view('admin/common/report_footer') ?>
        </div>
    </div>
            <?php $this->load->view('admin/common/copyright') ?>
</section>

