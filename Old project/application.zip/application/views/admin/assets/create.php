<aside>
  <section class="content">
    <div class="row">
      <section class="col-xs-12 connectedSortable">
        <div class="box box-info no_print">
          <div class="box-header">
            <h3 class="box-title"><?= !empty($page_title) ? $page_title : '' ?></h3>
          </div>
          <form class="form-horizontal" action="<?= base_url("asset/saveOrUpdate") ?>" method="POST">
            <div class="box-body">
              <div class="row">

                <div class="col-md-2 hide">
                  <div class="form-group">
                    <div class="col-sm-12">
                      <label for="date" class="control-label">Date
                        <span class="required">*</span></label>
                      <input type="text" class="form-control new_datepicker" value="<?= isset($value) ? $value->date : date('Y-m-d') ?>" id="date" name="date" placeholder="YYYY-MM-DD" required="" autocomplete="off" onkeypress="return false;">
                      <input type="hidden" name="update_id" id="update_id" value="<?= isset($value) ? $value->record_id : 0 ?>">
                    </div>
                  </div>
                </div>


              </div>
              <!-- <div class="sub-title">Products</div> -->
              <div class="form-block1">
                <div class="row">
                  <div class="col-md-2">
                    <div class="form-group">
                      <div class="col-sm-12">
                        <label for="type" class="control-label">Type (<span class="required">*</span>)</label>
                        <select class="form-control selectpicker" data-live-search="true" id="type" name="type" required>
                          <option value="">--Select--</option>
                          <option value="Fixed Asset" <?= isset($value) ? (($value->type == "Fixed Asset") ? "selected" : "") : "" ?>>Fixed Asset</option>
                          <option value="Current Asset" <?= isset($value) ? (($value->type == "Current Asset") ? "selected" : "") : "" ?>>Current Asset</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  <div class="col-md-3">
                    <div class="form-group">
                      <div class="col-sm-12">
                        <label for="item_id" class="control-label">Item Name (<span class="required">*</span>)
                        </label>
                        <div class="input-group">
                          <select class="form-control selectpicker" data-live-search="true" id="item_id" name="item_id" required>
                            <?= options(
                              'items',
                              array(),
                              array('item_name'),
                              'record_id',
                              '',
                              'record_id',
                              'desc',
                              '--Select--',
                              isset($value) ? $value->item_id : 0
                            )
                            ?>
                          </select>
                          <span class="input-group-addon">
                            <button type="button" id="c_plus" style="height: 20px;" class="btn btn-success fa fa-plus-square btn-sm" data-toggle="modal" data-target="#itemNameModal">
                            </button>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-2">
                    <div class="form-group">
                      <div class="col-sm-12">
                        <label for="no_of_qty" class="control-label">No of Qty (<span class="required">*</span>)
                        </label>
                        <input type="text" class="form-control text-right numeric" id="no_of_qty" name="no_of_qty" placeholder="No of Qty" value="<?= isset($value) ? $value->no_of_qty : 1 ?>" required>
                      </div>
                    </div>
                  </div>


                  <div class="col-md-2">
                    <div class="form-group">
                      <div class="col-sm-12">
                        <label for="unit_price" class="control-label">Amount (<span class="required">*</span>)
                        </label>
                        <input type="text" class="form-control text-right numeric" id="unit_price" name="unit_price" placeholder="Unit Price" value="<?= isset($value) ? $value->unit_price : "" ?>" required>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-2 hide">
                    <div class="form-group">
                      <div class="col-sm-12">
                        <label for="total_price" class="control-label">Total Price (<span class="required">*</span>)
                        </label>
                        <input type="text" class="form-control text-right numeric" id="total_price" name="total_price" placeholder="Total Price" value="<?= isset($value) ? $value->total_price : "" ?>" readonly="">
                      </div>
                    </div>
                  </div>
                  <div class="col-md-2">
                    <div class="form-group">
                      <div class="col-sm-12">
                        <label for="warranty" class="control-label">Warranty/Validity (If any)
                        </label>
                        <input type="text" class="form-control new_datepicker" value="<?= isset($value) ? $value->warranty : '' ?>" id="warranty" name="warranty" placeholder="">
                      </div>
                    </div>
                  </div>
                </div>
                <div class="row">
                  
                  <div class="col-md-3">
                    <div class="form-group">
                      <div class="col-sm-12">
                        <label for="purchase_by" class="control-label">Purchase By
                        </label>
                        <input type="text" class="form-control" value="<?= isset($value) ? $value->purchase_by : '' ?>" id="purchase_by" name="purchase_by" placeholder="">
                      </div>
                    </div>
                  </div>
                  <div class="col-md-3">
                    <div class="form-group">
                      <div class="col-sm-12">
                        <label for="remarks" class="control-label">Remarks</label>
                        <textarea class="form-control" id="remarks" name="remarks" rows="1" cols="12" placeholder="Enter Remarks"><?= isset($value) ? $value->remarks : '' ?></textarea>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-1">
                    <div class="form-group">
                      <div class="col-sm-12">
                        <button class="btn btn-primary pull-left" style="margin-top: 25px;">Submit</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </section>
    </div>
  </section>
  <!-- /.box-body -->
  <!-- <div class="box-footer">
    Footer
  </div> -->
  <!-- /.box-footer-->
</aside>
<!-- /.box -->

<script type="text/javascript">
  var record_id = 0;
  //update data by ajax

  function clearField() {
    $('#item_id').val("").selectpicker('refresh');
    $('#no_of_qty').val("")
    $('#unit_price').val("")
    $('#total_price').val("")
  }

  function calculateTotal() {
    var sum = 0,
      value = 0;
    $('.total_price').each(function() {
      value = $(this).text();
      value = +value;
      sum += value;
    });
    $('#grand_total_price').text(sum);
    $('input[name=grand_total_price]').val(sum);

    var sum = 0,
      value = 0;
    $('.no_of_qty').each(function() {
      value = $(this).text();
      value = +value;
      sum += value;
    });
    $('#grand_no_of_qty').text(sum);
    $('input[name=grand_no_of_qty]').val(sum);
  }


  $(document).on('click', '#btnAddToCart', function(e) {
    var item_id, item_id_option, product_name, no_of_qty, unit_price, total_price, tr, html;
    item_id_option = $('#item_id option:selected');
    item_id = $('#item_id').val();
    product_name = item_id_option.text();
    no_of_qty = $('#no_of_qty').val();
    no_of_qty = +no_of_qty;
    unit_price = $('#unit_price').val();
    unit_price = +unit_price;
    total_price = $('#total_price').val();
    total_price = +total_price;

    if (!item_id) {
      alert('Please select product');
      return;
    }
    if (!no_of_qty) {
      alert('Please enter no_of_qty');
      return;
    }
    if (!unit_price) {
      alert('Please enter unit price');
      return;
    }



    $('.draftbox-container').show();
    $('.update').show();
    html = '<input type="hidden" name="record_id[]" value="' + record_id + '">';
    html += '<input type="hidden" name="item_id[]" value="' + item_id + '">';
    html += '<input type="hidden" name="no_of_qty[]" value="' + no_of_qty + '">';
    html += '<input type="hidden" name="unit_price[]" value="' + unit_price + '">';
    html += '<input type="hidden" name="total_price[]" value="' + total_price + '">';

    var editRow = '<a href="javascript:void(0)" style="margin-right:5px;" class="btn btn-primary editRow"><span class="fa fa-pencil"></span></a>';
    var deleteRow = '<a href="javascript:void(0)" data-id="0" class="btn btn-danger deleteRow"><span class="fa fa-trash-o"></span></a>';

    tr = '<tr>' +
      '<td class="hide">' + html + '</td>' +
      '<td class="serial"></td>' +
      '<td>' + product_name + '</td>' +
      '<td style="text-align:right;" class="no_of_qty">' + no_of_qty + '</td>' +
      '<td style="text-align:right;" class="">' + unit_price + '</td>' +
      '<td style="text-align:right;" class="total_price">' + total_price + '</td>' +
      '<td class="">' + editRow + '' + deleteRow + '</td>' +
      '</tr>';

    if (replaceRow == '') {
      $('#draftbox tbody').append(tr);
    } else {
      replaceRow.replaceWith(tr);
      replaceRow = '';
    }

    setTimeout(function(e) {
      setSerial('draftbox', 'serial');
      calculateTotal();
    }, 500);
    clearField();
  });

  $(document).on('click', '.deleteRow', function(e) {
    e.preventDefault();
    var row, id;
    id = $(this).data('id');
    row = $(this).closest('tr');
    if (id) {
      $.ajax({
        url: '<?= base_url('crud/deleteJson') ?>',
        type: "POST",
        data: {
          table: 'lab_product_in_details',
          field: 'record_id',
          'folder': '',
          id: id
        },
        dataType: "json",
        success: function(data) {}
      });
    }
    row.remove();


    setTimeout(function(e) {
      setSerial('draftbox', 'serial');
      calculateTotal();
    }, 500);
  })
  var replaceRow = '';

  $(document).on('click', '.editRow', function(e) {
    var item_id, no_of_qty, unit_price, unit_price, total_price, tr;
    tr = $(this).closest('tr');
    replaceRow = tr;
    record_id = tr.find('input[name="record_id[]"]').val();
    item_id = tr.find('input[name="item_id[]"]').val();
    no_of_qty = tr.find('input[name="no_of_qty[]"]').val();
    unit_price = tr.find('input[name="unit_price[]"]').val();
    total_price = tr.find('input[name="total_price[]"]').val();
    $('#item_id').val(item_id).trigger('change');
    $('#no_of_qty').val(no_of_qty);
    $('#unit_price').val(unit_price);
    $('#total_price').val(total_price);
  })

  $(document).on('keyup', '#no_of_qty,#unit_price', function(e) {
    var no_of_qty, unit_price, total_price = 0;
    no_of_qty = $('#no_of_qty').val();
    no_of_qty = +no_of_qty;
    unit_price = $('#unit_price').val();
    unit_price = +unit_price;
    total_price = unit_price ;//no_of_qty * unit_price;
    $('#total_price').val(total_price);
  })
  $(document).on('change', "#type", function(e) {
    var type, supplier_id, option;
    option = $("#type :selected");
    supplier_id = option.data('supplier_id');
    $('#supplier_id').val(supplier_id).selectpicker('refresh');
    type = $(this).val();
    var formData = {
      type: type
    };
    var formURL = "<?= base_url("lab_product_in/load_products") ?>";
    $.ajax({
      url: formURL,
      type: "POST",
      data: formData,
      success: function(response) {
        $('.draftbox-container').html(response);
        $('.draftbox-container').show(1000);
      }
    });
  })
</script>