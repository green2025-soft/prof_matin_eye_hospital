<aside>
    <section class="content">
        <div class="row">
            <section class="col-xs-12 connectedSortable">
                <div class="box box-info no_print">
                    <div class="box-header">
                        <h3 class="box-title"><?= isset($page_title) ? $page_title : '' ?></h3>
                        <form class="no_print" action="<?= base_url('asset') ?>" method="GET">
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <div class="col-sm-12">
                                                <label for="item_id" class="control-label">Item Name
                                                </label>
                                                <select class="form-control selectpicker" data-live-search="true" id="item_id" name="item_id">
                                                    <?= options(
                                                        'items',
                                                        array(),
                                                        array('item_name'),
                                                        'record_id',
                                                        '',
                                                        'record_id',
                                                        'desc',
                                                        '--Select--',
                                                        isset($item_id) ? $item_id : 0
                                                    )
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="from_date">From Date</label>
                                            <input type="text" class="form-control search_datepicker" id="from_date" placeholder="YYYY-MM-DD" name="from_date" value="<?= isset($from_date) && !empty($from_date) ? $from_date : date('Y-m-d') ?>" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="to_date">To Date</label>
                                            <input type="text" class="form-control search_datepicker" id="to_date" placeholder="YYYY-MM-DD" name="to_date" value="<?= isset($to_date) && !empty($to_date) ? $to_date : date('Y-m-d') ?>" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group" style="margin-top: 25px;">
                                            <button type="submit" class="pull-left btn btn-success">Search <i class="fa fa-search"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>

                    <div class="box-body table-responsive">
                        <table id="example2" class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th style="text-align: center;">SL</th>
                                    <th style="text-align: center;">Type</th>
                                    <th style="text-align: center;">Item</th>
                                    <th style="text-align: center;">Qty</th>
                                  <!--   <th style="text-align: center;">Unit_Price</th> -->
                                    <th style="text-align: center;">Total_Price</th>
                                    <th style="text-align: center;">Purchase_By</th>
                                    <th style="text-align: center;">Warranty</th>
                                    <th style="text-align: center;">Remarks</th>
                                    <th style="text-align: center;">Created</th>
                                    <th style="text-align: center;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $count = 0;
                                $total_amount = 0 ;
                                foreach ($values as $value) {
                                    $count++;
                                    $item = $this->Common_model->findById('items', array('record_id' => $value->item_id));
                                    $total_amount += $value->total_price ;
                                ?>
                                    <tr>
                                        <td style="text-align: center;"><?= $count ?></td>
                                        <td style="text-align: center;"><?= $value->type ?></td>
                                        <td style="text-align: center;"><?= isset($item) ? $item->item_name . '[' . $item->record_id . ']' : '' ?></td>
                                        <td style="text-align: right;"><?= $value->no_of_qty ?></td>
                                        <td style="text-align: right;display:none;"><?= $value->unit_price ?></td>
                                        <td style="text-align: right;"><?= $value->total_price ?></td>
                                        <td style="text-align: right;"><?= $value->purchase_by ?></td>
                                        <td style="text-align: right;"><?= $value->warranty ?></td>
                                        <td style="text-align: right;"><?= $value->remarks ?></td>
                                        <td style="text-align: center;"><?= creator($value->created_by) ?></td>
                                        <td style="text-align: center;">
                                            <!-- <a href="<?= base_url("asset/view2/$value->record_id") ?>" class="btn btn-info"><i class="fa fa-eye"></i></a> -->
                                            <a href="<?= base_url("asset/edit/$value->record_id") ?>" class="btn btn-primary"><i class="fa fa-pencil"></i></a>
                                            <a class="btn btn-danger" href="<?= base_url("asset/delete/$value->record_id") ?>" onclick="return confirm('Are you sure to delete this record?')"><i class="fa fa-trash-o"></i>
                                            </a>
                                            <?php $class = "btn-success";
                                            if (admin()) {
                                                $button_text = $value->show_hide;
                                                if ($button_text == "Show") {
                                                    $class = "btn-success";
                                                } else {
                                                    $class = "btn-danger";
                                                }
                                            ?>
                                                <a class="btn <?= $class ?> btnShowHide" href="javascript:void(0)" data-url="<?= base_url("crud/show_hide/assets/record_id/$value->record_id"); ?>"><?= $button_text ?></i>
                                                </a>
                                            <?php } ?>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                            <?php if($total_amount > 0){ ?>
                            <tfoot>
                                <tr>
                                    <th colspan="4" class="text-right">Total:</th>
                                    <th class="text-right"><?=$total_amount?></th>
                                    <th colspan="5"></th>
                                </tr>
                            </tfoot>
                            <?php } ?>
                        </table>
                    </div>
                </div>
            </section>
        </div>
    </section>
</aside>
<script type="text/javascript">
    $(document).on('click', '.btnEdit', function(e) {
        var id = $(this).data('record_id');
        var formURL = "<?php echo site_url('crud/edit/lab_product_use_in/record_id'); ?>";
        $.ajax({
            url: formURL,
            type: "POST",
            data: {
                id: id
            },
            dataType: "json",
            success: function(data) {
                $('#update_id').val(data.record_id);
                $('#date').val(data.date);
                $('#product_id').val(data.product_id);
                $('#qty').val(data.qty);
                $('#unit_price').val(data.unit_price);
                $('#total_price').val(data.total_price);
                $('#product_id').focus();
                $('#product_id').selectpicker('refresh');
                $('.update').text("Update");
                $("html, body").animate({
                    scrollTop: 0
                }, "slow");
            }
        });
        e.preventDefault();
    });

    $(document).on('keyup', '#qty,#unit_price', function(e) {
        var qty = 0,
            unit_price = 0,
            total_price = 0;
        qty = $('#qty').val();
        qty = +qty;
        unit_price = $('#unit_price').val();
        unit_price = +unit_price;

        total_price = qty * unit_price;
        $('#total_price').val(total_price);
    })
</script>