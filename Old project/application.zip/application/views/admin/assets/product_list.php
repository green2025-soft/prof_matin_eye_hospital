<div class="col-md-12">
                  <!-- <h3>Item Draftbox</h3> -->
                  <br>
                  <table class="table table-bordered" id="draftbox">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Product</th>
                        <th>Qty</th>
                        <th>Price</th>
                        <th>Total</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $i = 0;
                      if (isset($values) && count($values)) {
                        foreach ($values as $key1 => $value1) {
                          ++$i;
                          $product = $this->Common_model->findById('product_name', array('record_id' => $value1->product_id));
                      ?>
                          <tr>
                            <td class="hide">
                              <input type="hidden" name="record_id[]" value="<?= isset($value1) ? $value1->record_id : 0 ?>">
                              <input type="hidden" name="product_id[]" value="<?= isset($value1) ? $value1->product_id : 0 ?>">
                              <input type="hidden" name="quantity[]" value="<?= isset($value1) ? $value1->quantity : '' ?>">
                              <input type="hidden" name="unit_price[]" value="<?= isset($value1) ? $value1->unit_price : '' ?>">
                              <input type="hidden" name="total_price[]" value="<?= isset($value1) ? $value1->total_price : '' ?>">
                            </td>
                            <td><?= $i ?></td>
                            <td><?= isset($product) ? $product->code_no . ' - ' .$product->product_name : '' ?></td>
                            <td style="text-align: right;" class="quantity"><?= isset($value1) ? $value1->quantity : '' ?></td>
                            <td style="text-align: right;" class="unit_price"><?= isset($value1) ? $value1->unit_price : '' ?></td>
                            <td style="text-align: right;" class="total_price"><?= isset($value1) ? $value1->total_price : '' ?></td>
                            <td>
                              <a href="javascript:void(0)" style="margin-right:5px;" class="btn btn-primary editRow"><span class="fa fa-pencil"></span></a>
                              <a href="javascript:void(0)" data-id="<?= isset($value1) ? $value1->record_id : 0 ?>" class="btn btn-danger deleteRow"><span class="fa fa-trash-o"></span></a>
                            </td>
                          </tr>
                      <?php  }
                      } ?>

                    </tbody>
                    <tfoot>
                      <tr>
                        <th colspan="2" style="text-align: right;">Total :
                          <input type="hidden" name="grand_total_price" class="form-control text-right numeric" value="<?= isset($value) ? $value->grand_total_price : '' ?>">
                          <input type="hidden" name="grand_quantity" class="form-control text-right numeric" value="<?= isset($value) ? $value->grand_quantity : '' ?>">
                        </th>
                        <th style="text-align: right;" id="grand_quantity"><?= isset($value) ? $value->grand_quantity : '' ?></th>
                        <th>&nbsp;</th>
                        <th style="text-align: right;" id="grand_total_price"><?= isset($value) ? $value->grand_total_price : '' ?></th>
                        <th>
                          <button type="submit" class="btn btn-info pull-right update" style="display: <?= isset($values) && count($values) ? 'block' : 'none' ?>;">Submit</button>
                        </th>
                      </tr>
                    </tfoot>
                  </table>
                </div>