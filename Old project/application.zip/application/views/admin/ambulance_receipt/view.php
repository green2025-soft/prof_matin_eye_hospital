<section class="content">
    <div id="invoice">
        <div class="report_header">
            <?php $this->load->view('admin/common/report_header') ?>
        </div>
        
        <div class="container">
            <div class="row patient_area">
                <div class="form-group col-sm-4 col-xs-6" style="color: black !important; font-size: 17px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Ambulance No: </b><?=isset($patient)?$ambulance->ambulance_no.' - ' . $ambulance->ambulance_type:''?>
                </div>
                <div class="form-group col-sm-4 col-xs-6" style="color: black !important; font-size: 17px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Trip No: </b><?=$value->trip_no?>
                </div>
                <div class="form-group col-sm-4 col-xs-6" style="color: black !important; font-size: 17px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Date: </b><?=$value->date.' '. $value->date?>
                </div>
                <div class="form-group col-sm-4 col-xs-6" style="color: black !important; font-size: 17px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Patient Name: </b><?=isset($patient)?$patient->name:''?>
                </div>
                <div class="form-group col-sm-4 col-xs-6" style="color: black !important; font-size: 17px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Age: </b><?=isset($patient)?$patient->age:''?>
                </div>
                <div class="form-group col-sm-4 col-xs-6" style="color: black !important; font-size: 17px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Contact No: </b><?=isset($patient)?$patient->mobile:''?>
                </div>
                <div class="form-group col-sm-4 col-xs-6" style="color: black !important; font-size: 17px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Road Name: </b><?=$value->road_name?>
                </div>
                <div class="form-group col-sm-4 col-xs-6" style="color: black !important; font-size: 17px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Driver Name: </b><?=$value->driver_name?>
                </div>
                <div class="form-group col-sm-4 col-xs-6" style="color: black !important; font-size: 17px; padding: 0px 5px 0px 5px; margin: 0px;">
                    <b>Mobile No: </b><?=$value->driver_mobile_no?>
                </div>
            </div>
            <div class="row" style="margin-top:10px;">
                <div class="col-md-12">
                    <p class="report_title"><?=isset($page_title)?$page_title:''?></p>
                </div>
            </div>

            <div class="row">
                <div class="form-group col-sm-12 col-xs-12" style="text-align: center; font-weight: bold; padding-bottom: 0px; margin-bottom: 0px;">
                    <table id="" class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th style="text-align: center;">Title</th>
                                <th style="text-align: center;">Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="text-align: center;">Total Receive</td>
                                <td style="text-align: center;"><?php echo $value->total_receive; ?></td>
                            </tr>
                            
                        </tbody>
                    </table>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <p>
                            <span style="font-weight: 700;text-decoration: underline;font-size: 16px;">Comments : </span> <?=$value->comments?>
                        </p>
                    </div>
                </div>
            </div>

            <?php $this->load->view('admin/common/report_footer') ?>
        </div>
    </div>
</section>

