
<aside >
    <section class="content">
        <div class="row">
            <section class="col-xs-12 connectedSortable"> 
                <div class="box box-info no_print">
                    <div class="box-header">
                        <h3 class="box-title"><?=isset($page_title)?$page_title:''?></h3>
                    </div>
                    <?php echo form_open_multipart('ambulance_receipt/saveOrUpdate'); ?>
                    <div class="box-body">
                        <div class="row">
                            <div class="form-group col-sm-3">
                                <label for="trip_no">Trip No (<span class="required">*</span>) </label>
                                <input type="text" class="form-control text-right" id="trip_no" placeholder="" name="trip_no" value="<?=isset($value)?$value->trip_no:$trip_no?>" required="" readonly>
                                <input type="hidden" name="update_id" id="update_id" value="<?=isset($value)?$value->record_id:0?>">
                            </div>
                            <div class="form-group col-sm-3">
                                <label for="date">Date (<span class="required">*</span>) </label>
                                <input type="text" class="form-control closing_datepicker" id="date" 
                                placeholder="" name="date" value="<?=isset($value)?$value->date:closing_date(date('Y-m-d'))?>" required="" autocomplete="off">
                            </div>
                            <div class="form-group col-sm-3">
                                <label for="patient_id">Patient Name (<span class="required">*</span>) </label>
                                <div class="input-group">
                                    <select name="patient_id" id="patient_id" class="form-control selectpicker"
                                    data-live-search="true" required="">
                                    <?=options(
                                        'patient',
                                        array(), 
                                        array('record_id','name'),
                                        'record_id',
                                        '',
                                        'record_id',
                                        'desc',
                                        'Select Patient',isset($value)?$value->patient_id:0,array('name','gender','age','mobile'))
                                        ?>
                                    </select>

                                    <span class="input-group-addon">
                                        <button type="button" id="c_plus" style="height: 20px;"
                                        class="btn btn-success fa fa-plus-square btn-sm" data-toggle="modal" data-target="#patientModal">
                                    </button>
                                </span>
                            </div>
                        </div>
                            <div class="form-group col-sm-3">
                                <label for="ambulance_id">Ambulance No (<span class="required">*</span>) </label>
                                <select name="ambulance_id" id="ambulance_id" class="form-control selectpicker"
                                data-live-search="true" required="">
                                <?=options(
                                    'ambulance',
                                    array(), 
                                    array('ambulance_no','ambulance_type'),
                                    'record_id',
                                    '',
                                    'ambulance_no',
                                    'ASC',
                                    'Select Ambulance',isset($value)?$value->ambulance_id:0)
                                    ?>
                                </select>
                            </div>
                            
                    </div>
                    <div class="row">
                        <div class="form-group col-sm-3">
                            <label for="department">Road Name</label>
                            <input type="text" name="road_name" id="road_name" class="form-control" value="<?=isset($value)?$value->road_name:''?>">
                        </div>

                        <div class="form-group col-sm-3">
                            <label for="distance">Distance (km) </label>
                            <input type="text" class="form-control text-right numeric" id="distance" placeholder="" name="distance" value="<?=isset($value)?$value->distance:''?>" >
                        </div>
                        <div class="form-group col-sm-3">
                            <label for="total_receive">Total Receive (<span class="required">*</span>) </label>
                            <input type="text" class="form-control text-right numeric" id="total_receive" placeholder="" name="total_receive" value="<?=isset($value)?$value->total_receive:''?>" required >
                        </div>
                        <div class="form-group col-sm-3 col-xs-12">
                            <label for="time_schedule">Fuel Cost </label>
                            <input type="text" name="fuel_cost" id="fuel_cost" class="form-control text-right numeric" value="<?=isset($value)?$value->fuel_cost:''?>">
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="form-group col-sm-3">
                            <label for="road_cost">Road Cost </label>
                            <input type="text" class="form-control text-right numeric" id="road_cost" placeholder="" name="road_cost" value="<?=isset($value)?$value->road_cost:''?>">
                        </div>
                        
                        <div class="form-group col-sm-3">
                            <label for="service_maintanance_cost">Service & Maintanance Cost </label>
                            <input type="text" class="form-control text-right numeric" id="service_maintanance_cost" placeholder="" name="service_maintanance_cost" value="<?=isset($value)?$value->service_maintanance_cost:''?>" >
                        </div>
                        <div class="form-group col-sm-3">
                            <label for="comments">Comments</label>
                            <input type="text" class="form-control" id="comments" placeholder="" name="comments" value="<?=isset($value)?$value->comments:''?>">
                        </div>
                        <div class="form-group col-sm-3 col-xs-12">
                            <label for="driver_name">Driver Name</label>
                            <input type="text" class="form-control" id="driver_name" placeholder="" name="driver_name" value="<?=isset($value)?$value->driver_name:''?>" >
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-sm-3 col-xs-12">
                            <label for="driver_mobile_no">Driver Mobile No</label>
                            <input type="text" class="form-control" id="driver_mobile_no" placeholder="" name="driver_mobile_no" value="<?=isset($value)?$value->driver_mobile_no:''?>" >
                        </div>
                        <div class="form-group col-sm-3 col-xs-12">
                            <div class="box-footer clearfix" style="margin-top: 15px;">
                    <button type="submit" class="pull-left btn btn-success">Submit <i class="fa fa-arrow-circle-right"></i></button>
                </div>
                        </div>
                    </div>
                </div>
                
            </form>
        </div>
    </section>
</div>
</section>
</aside>
<script type="text/javascript">
    $(document).on('change','#patient_id,#doctor_id',function(e){
        var patient_id = $('#patient_id').val();
        var doctor_id = $('#doctor_id').val();
        var formURL = "<?=base_url('appointment/get_doctor_fee'); ?>";
        $.ajax(
        {
            url : formURL,
            type: "POST",
            data : {patient_id: patient_id, doctor_id: doctor_id},
            dataType: "json",
            success:function(data){
              $('#frees').val(data.doctor_fee);
              $('#commission_fee').val(data.commission_fee);
              $('#payable_amount').val(data.doctor_fee);
              discount_amount = $('#discount_amount').val() ;
              discount_amount = +discount_amount ;
              sub_total_amount = data.doctor_fee - discount_amount ; 
              $('#sub_total_amount').val(sub_total_amount);
          }
      });
        e.preventDefault();
    })

    $(document).on('keyup','#discount_amount',function(e){
        var payable_amount, discount_amount, sub_total_amount;
        payable_amount = $('#payable_amount').val() ;
        payable_amount = +payable_amount ;
        discount_amount = $('#discount_amount').val() ;
        discount_amount = +discount_amount ; 
        sub_total_amount = payable_amount - discount_amount ;
        $('#sub_total_amount').val(sub_total_amount);
    })
    $(document).on('keyup','#paid_amount',function(e){
        var paid_amount, sub_total_amount;
        paid_amount = $('#paid_amount').val() ;
        paid_amount = +paid_amount ;
        sub_total_amount = $('#sub_total_amount').val() ;
        sub_total_amount = +sub_total_amount ; 
        if(paid_amount > sub_total_amount){
            alert('Paid amount should be less than or equal to sub total amount');
            $('#paid_amount').val(0);
        }
    })
</script>