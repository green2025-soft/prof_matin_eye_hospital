<aside >
    <section class="content">
        <div class="row">
            <section class="col-xs-12 connectedSortable"> 
                <div class="box box-info no_print">
                    <div class="box-header">
                        <h3 class="box-title"><?=isset($page_title)?$page_title:''?></h3>
                    </div>
                    <div class="box-body">
                        <div class="box-body table-responsive">
                        <table id="example2" class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th style="text-align: center;">SL</th>
                                    <th style="text-align: center;">Date</th>
                                    <th style="text-align: center;">Trip</th>
                                    <th style="text-align: center;">Ambulance</th>
                                    <th style="text-align: center;">Patient</th>
                                    <th style="text-align: center;">Road</th>
                                    <th style="text-align: right;">Distance</th>
                                    <th style="text-align: right;">Amount</th>
                                    <th style="text-align: right;">Fuel</th>
                                    <th style="text-align: right;">Road</th>
                                    <th style="text-align: right;">Service_Cost</th>
                                    <th style="text-align: right;">Comments</th>
                                    <th style="text-align: right;">Driver</th>
                                    <th style="text-align: center;">Mobile</th>
                                    <th style="text-align: center;">Created</th>
                                    <th style="text-align: center;width: 190px;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $count = 0;
                                foreach ($values as $single_value) {
                                    $count++;
                                    $patient = $this->Common_model->findById('patient',array('record_id'=>$single_value->patient_id)) ;
                                    $ambulance = $this->Common_model->findById('ambulance',array('record_id'=>$single_value->ambulance_id)) ;
                                    ?>
                                    <tr>
                                        <td style="text-align: center;"><?php echo $count; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->date; ?></td>
                                        <td style="text-align: center;"><?php echo $single_value->trip_no; ?></td>
                                        <td style="text-align: center;"><?=isset($patient)?$patient->name.' - '.$patient->gender.' - '.$patient->age.' - '.$patient->mobile:''?></td>
                                        <td style="text-align: center;"><?=isset($ambulance)?$ambulance->ambulance_no.' - '.$ambulance->ambulance_type:''?></td>
                                        <td style="text-align: center;"><?php echo $single_value->road_name; ?></td>
                                        <td style="text-align: right;"><?php echo $single_value->distance; ?></td>
                                        <td style="text-align: right;"><?php echo $single_value->total_receive; ?></td>
                                        <td style="text-align: right;"><?php echo $single_value->fuel_cost; ?></td>
                                        <td style="text-align: right;"><?php echo $single_value->road_cost; ?></td>
                                        <td style="text-align: right;"><?php echo $single_value->service_maintanance_cost; ?></td>
                                        <td style="text-align: right;"><?php echo $single_value->comments; ?></td>
                                        <td style="text-align: right;"><?php echo $single_value->driver_name; ?></td>
                                        <td style="text-align: right;"><?php echo $single_value->driver_mobile_no; ?></td>
                                        <td style="text-align: center;"><?=creator($single_value->created_by)?></td>
                                        <td style="text-align: center;">
                                            <a class="btn btn-primary"
                                               href="<?=base_url("ambulance_receipt/view2/$single_value->record_id"); ?>"><i class="fa fa-eye"></i>
                                            </a>
                                            <a class="btn btn-info"
                                               href="<?=base_url("ambulance_receipt/edit/$single_value->record_id"); ?>"><i class="fa fa-pencil"></i>
                                            </a>
                                            <a class="btn btn-danger"
                                               href="<?=base_url("ambulance_receipt/delete/$single_value->record_id"); ?>" onclick="return confirm('Are you sure to delete this record?')"><i class="fa fa-trash-o"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                    </div>
                </div>
            </section>
        </div>
    </section>
</aside>