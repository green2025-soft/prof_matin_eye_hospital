<aside>
    <section class="content">
        <div class="row">
            <section class="col-xs-12 connectedSortable">
                <div class="box box-info no_print">
                    <div class="box-header">
                        <h3 class="box-title"><?= isset($page_title) ? $page_title : '' ?></h3>
                    </div>
                    <?php echo form_open_multipart('balance_transfer/saveOrUpdate'); ?>
                    <div class="box-body">
                        <div class="row">
                            <div class="form-group col-sm-3 col-xs-12">
                                <input type="hidden" name="update_id" id="update_id" value="0">
                                <label for="date_from">Year (<span class="required">*</span>)</label>
                                <!-- <input type="text" class="form-control new_datepicker" id="date_from"
                            value="<?php echo date('Y-m-d'); ?>" placeholder="Date" name="date_from" required> -->
                                <?php $settings = $this->Common_model->findById('contact', array('id' => 1));
                                $starting_year = date('Y', strtotime($settings->app_running_date));
                                $ending_year = date('Y');
                                $year_option = "";
                                for ($i = $ending_year; $i >= $starting_year; --$i) {
                                    $year_option .= '<option value="' . $i . '">' . $i . '</option>';
                                }

                                $current_month = date('m');
                                $month_option = "";
                                $month_array = month();
                                foreach ($month_array as $key => $value) {
                                    $selected = '';
                                    if ($key == $current_month) {
                                        $selected = 'selected';
                                    } else {
                                        $selected = '';
                                    }
                                    $month_option .= '<option value="' . $key . '" ' . $selected . '>' . $value . '</option>';
                                }
                                ?>
                                <select class="form-control" id="year" name="year">
                                    <?= $year_option ?>
                                </select>
                            </div>
                            <div class="form-group col-sm-3 col-xs-12">
                                <label for="month">Month (<span class="required">*</span>)</label>
                                <select class="form-control" id="month" name="month">
                                    <?= $month_option ?>
                                </select>
                            </div>
                            <?php if ($report_type == 'details') { ?>
                                <div class="form-group col-sm-3 col-xs-12">
                                    <label for="report_type">Report Type (<span class="required">*</span>)</label>
                                    <select name="report_type" id="report_type" class="form-control" required>
                                        <option value="">Select</option>
                                        <option value="Diagnostic">Diagnostic</option>
                                        <option value="Hospital">Hospital</option>
                                        <!-- <option value="Pharmacy">Pharmacy</option> -->
                                        <option value="Service">Service</option>
                                    </select>
                                </div>
                            <?php } ?>
                            <?php if ($report_type == 'total') { ?>
                                <div class="form-group col-sm-3 col-xs-12 hide">
                                    <label for="type">Report Type (<span class="required">*</span>)</label>
                                    <select name="type" id="type" class="form-control" required>
                                        <option value="Total">Total</option>
                                        <option value="Details">Details</option>
                                    </select>
                                </div>
                            <?php } ?>
                            <div class="form-group col-sm-3 col-xs-12" style="margin-top: 26px;">
                                <button type="button" id="search_report" class="pull-left btn btn-success">Get Balance <i class="fa fa-search"></i></button>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="balance_amount">Balance(<span class="required">*</span>)</label>
                                <input type="text" name="balance_amount" id="balance_amount" class="form-control text-right numeric" required readonly>
                            </div>
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="particular_id" class="control-label">Particular(<span class="required">*</span>)
                                </label>
                                <select class="form-control selectpicker" data-live-search="true" id="particular_id" name="particular_id" required>
                                    <?= options(
                                        'particulars',
                                        array(),
                                        array('particular_name'),
                                        'record_id',
                                        'particular_name',
                                        'record_id',
                                        'desc',
                                        '--Select--'
                                    )
                                    ?>
                                </select>
                            </div>
                            <div class="form-group col-sm-2 col-xs-12">
                                <label for="transfer_amount">Transfer Amount(<span class="required">*</span>)</label>
                                <input type="text" name="transfer_amount" id="transfer_amount" class="form-control text-right numeric" required>
                            </div>
                            <div class="form-group col-sm-3 col-xs-12">
                                <label for="remarks">Remarks</label>
                                <input type="text" name="remarks" id="remarks" class="form-control">
                            </div>
                            <div class="form-group col-sm-1 col-xs-12" style="margin-top: 26px;">
                                <button type="submit" class="pull-left btn btn-success">Submit</button>
                            </div>
                        </div>
                    </div>
                </div>
        </div>

        </form>
        <div class="box-body table-responsive">
            <div class="info-header">
                <h4><?= isset($info_header) ? $info_header : '' ?></h4>
            </div>
            <table id="example2" class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th style="text-align: center;">SL</th>
                        <th style="text-align: center;">Date</th>
                        <th style="text-align: center;">Year</th>
                        <th style="text-align: center;">Month</th>
                        <th style="text-align: center;">Particular</th>
                        <th style="text-align: center;">Balance_Amount</th>
                        <th style="text-align: center;">Transfer_Amount</th>
                        <th style="text-align: center;">Remarks</th>
                        <th style="text-align: center;">Created</th>
                        <th style="text-align: center;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $count = 0;
                    foreach ($values as $single_value) {
                        $count++;
                        $particular = $this->Common_model->findById('particulars',array('record_id'=>$single_value->particular_id));
                    ?>
                        <tr>
                            <td style="text-align: center;"><?php echo $count; ?></td>
                            <td style="text-align: center;"><?php echo $single_value->date; ?></td>
                            <td style="text-align: center;"><?php echo $single_value->year; ?></td>
                            <td style="text-align: center;"><?php echo $single_value->month_name; ?></td>
                            <td style="text-align: center;"><?=isset($particular)?$particular->particular_name:''?></td>
                            <td style="text-align: center;"><?php echo $single_value->balance_amount; ?></td>
                            <td style="text-align: center;"><?php echo $single_value->transfer_amount; ?></td>
                            <td style="text-align: center;"><?php echo $single_value->remarks; ?></td>
                            <td style="text-align: center;"><?= creator($single_value->created_by) ?></td>
                            <td style="text-align: center;">
                                <a class="btn btn-danger" href="<?= base_url("balance_transfer/delete/$single_value->record_id") ?>" onclick="return confirm('Are you sure to delete this record?')"><i class="fa fa-trash-o"></i>
                                </a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
        </div>
    </section>
    </div>
    </section>
</aside>
<script type="text/javascript">
    $("#search_report").click(function() {
        var year = $('#year').val();
        var month = $('#month').val();
        var report_type = $('#report_type').val();
        var type = $('#type').val();
        var post_data = {
            'year': year,
            'month': month,
            'type': type,
            report_type: report_type
        };
        $.ajax({
            type: "POST",
            url: "<?= base_url("balance_transfer/get_balance") ?>",
            data: post_data,
            success: function(data) {
                $('#balance_amount').val(data);
            }
        });
    });
</script>