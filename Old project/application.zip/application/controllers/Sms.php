<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sms extends CI_Controller {
 

	static $helper 	 = array('utility');

	public function __construct(){
		parent::__construct();
		$this->load->helper(self::$helper);
	}
	public function index()
	{
		$user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Send SMS List';
            $data['page_title'] = 'Send SMS List';
            $data['info_header'] = 'Send SMS List';
            $load_sms = $this->Common_model->findById('load_sms',array('load_sms_id'=>1));
            $sms_qty = $this->Common_model->calCulateSum('sms_log',array(),'send_sms_qty');
            $balance_sms = $load_sms->sms_qty ; // -  $sms_qty ;
            $data['values'] = $this->Common_model->findAll('sms_log',array(),'sms_log_id','desc') ;
            $data['balance_sms'] = $balance_sms ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/sms/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }

	}
	public function create()
	{
		$user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Create SMS';
            $data['page_title'] = 'Create SMS';
            $data['info_header'] = '';
            $data['values'] = $this->Common_model->findAll('smses',array(),'sms_id','desc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/sms/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
	}
	public function send()
	{
		$user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Send SMS';
            $data['page_title'] = 'Send SMS';
            $data['info_header'] = '';
            $data['values'] = $this->Common_model->findAll('smses',array(),'sms_id','desc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/sms/send_sms', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }

	}

	public function saveOrUpdate()
	{
       $data = $_POST;
       $sms_title = trim($data['sms_title']);
       $update_id = $data['update_id'];
       unset($data['update_id']);
       if($update_id == 0){
       	   $sms = $this->Common_model->findById("smses",array('sms_title'=>$sms_title));
       	   if($sms){
       	   	  $this->session->set_userdata('alertMsg',EXIST_MSG);
       	   	  redirect("crud/previousPage");
       	   }
	       $insert = $this->Common_model->saveData('smses',$data);
	       if($insert){
	       	  $this->session->set_userdata('alertMsg',INSERT_MSG);
	       }else{
	       	  $this->session->set_userdata('alertMsg',INSERT_ERROR_MSG);
	       }
	   }else{
	   	    $sms = $this->Common_model->findById("smses",array('sms_id != '=>$update_id,'sms_title'=>$sms_title));
       	   if($sms){
       	   	  $this->session->set_userdata('alertMsg',EXIST_MSG);
       	   	  redirect("crud/previousPage");
       	   }
	   	   $update = $this->Common_model->updateData('smses',$data,array('sms_id'=>$update_id));
	       if($update){
	       	  $this->session->set_userdata('alertMsg',UPDATE_MSG);
	       }else{
	       	  $this->session->set_userdata('alertMsg',UPDATE_ERROR_MSG);
	       }
	   }
       redirect("sms/create");
	}

	public function saveOrUpdateSendSMS(){

		$doctor_id = $this->input->post('doctor_id');
		$patient_id = $this->input->post('patient_id');
		$staff_id = $this->input->post('staff_id');
		$reference_id = $this->input->post('reference_id');
		$sms_id = $this->input->post('sms_id');
		$sms_body = $this->input->post('sms_body');
		$send_date = date('Y-m-d') ;

		$sms_qty = ceil(strlen(utf8_decode($sms_body)) / 159);

		$sms_person = 0;
		$send_sms_qty = 0 ;

		$reserveSmsObj = $this->Common_model->findById('load_sms',array('load_sms_id'=>1));

		if($reserveSmsObj->sms_qty > 1){
			$data = array(
				'sms_id'=>$sms_id,
				'send_date'=>$send_date,
				'sms_body'=>$sms_body,
				'sms_person'=>$sms_person,
				'send_sms_qty'=>$send_sms_qty,
			);
			$insert = $this->Common_model->saveData('sms_log',$data) ;
			$person = 0 ;
			if(!empty($doctor_id)){
				$where = array() ;
				if(in_array('All', $doctor_id)) {}else{
					$where = $doctor_id ;
				}
				$doctors = $this->Common_model->findAllWhereIn('doctor',array(),$where,'record_id','record_id','asc');

				foreach ($doctors as $key => $value) {
					$mobile = $value->mobile ;
					if(!empty($mobile) && strlen($mobile) == 11){
						$reserveSmsObj = $this->Common_model->findById('load_sms',array('load_sms_id'=>1));
						$reserveSms = isset($reserveSmsObj)?$reserveSmsObj->sms_qty:0 ;
						if($reserveSms >= $sms_qty){
							++$person ;
							$smsDetails = array(
								'sms_log_id'=>$insert,
								'send_date'=>$send_date,
								'doctor_id'=>$value->record_id,
							) ;
							$this->Common_model->saveData('sms_log_details',$smsDetails);
							techno_bulk_sms($mobile,$sms_body);
							$balance_sms = $reserveSms - ($person * $sms_qty) ;
							$this->Common_model->updateData('load_sms',array('sms_qty'=>$balance_sms), array('load_sms_id'=>1));
						}
					}
				}
			}

			if(!empty($patient_id)){
				$where = array() ;
				if(in_array('All', $patient_id)) {}else{
					$where = $patient_id ;
				}
				$patients = $this->Common_model->findAllWhereIn('patient',array(),$where,'record_id','record_id','asc');

				foreach ($patients as $key => $value) {
					$mobile = $value->mobile ;
					if(!empty($mobile) && strlen($mobile) == 11){
						$reserveSmsObj = $this->Common_model->findById('load_sms',array('load_sms_id'=>1));
						$reserveSms = isset($reserveSmsObj)?$reserveSmsObj->sms_qty:0 ;
						if($reserveSms >= $sms_qty){
							++$person ;
							$smsDetails = array(
								'sms_log_id'=>$insert,
								'send_date'=>$send_date,
								'patient_id'=>$value->record_id,
							) ;
							$this->Common_model->saveData('sms_log_details',$smsDetails);
							techno_bulk_sms($mobile,$sms_body);
							$balance_sms = $reserveSms - ($person * $sms_qty) ;
							$this->Common_model->updateData('load_sms',array('sms_qty'=>$balance_sms), array('load_sms_id'=>1));
						}
					}
				}
			}
			if(!empty($staff_id)){
				$where = array() ;
				if(in_array('All', $doctor_id)) {}else{
					$where = $doctor_id ;
				}
				$staffs = $this->Common_model->findAllWhereIn('staff',array(),$where,'record_id','record_id','asc');

				foreach ($staffs as $key => $value) {
					$mobile = $value->mobile ;
					if(!empty($mobile) && strlen($mobile) == 11){
						$reserveSmsObj = $this->Common_model->findById('load_sms',array('load_sms_id'=>1));
						$reserveSms = isset($reserveSmsObj)?$reserveSmsObj->sms_qty:0 ;
						if($reserveSms >= $sms_qty){
							++$person ;
							$smsDetails = array(
								'sms_log_id'=>$insert,
								'send_date'=>$send_date,
								'staff_id'=>$value->record_id,
							) ;
							$this->Common_model->saveData('sms_log_details',$smsDetails);
							techno_bulk_sms($mobile,$sms_body);
							$balance_sms = $reserveSms - ($person * $sms_qty) ;
							$this->Common_model->updateData('load_sms',array('sms_qty'=>$balance_sms), array('load_sms_id'=>1));
						}
					}
				}
			}

			if(!empty($reference_id)){
				$where = array() ;
				if(in_array('All', $doctor_id)) {}else{
					$where = $doctor_id ;
				}
				$reference_by = $this->Common_model->findAll('reference_by',array(),$where,'record_id','record_id','asc');
				foreach ($reference_by as $key => $value) {
					$mobile = $value->contact_no ;
					if(!empty($mobile) && strlen($mobile) == 11){
						$reserveSmsObj = $this->Common_model->findById('load_sms',array('load_sms_id'=>1));
						$reserveSms = isset($reserveSmsObj)?$reserveSmsObj->sms_qty:0 ;

						if($reserveSms >= $sms_qty){
							++$person ;
							$smsDetails = array(
								'sms_log_id'=>$insert,
								'send_date'=>$send_date,
								'reference_by'=>$value->record_id,
							) ;
							$this->Common_model->saveData('sms_log_details',$smsDetails);
							techno_bulk_sms($mobile,$sms_body);
							$balance_sms = $reserveSms - ($person * $sms_qty) ;
							$this->Common_model->updateData('load_sms',array('sms_qty'=>$balance_sms), array('load_sms_id'=>1));
						}
					}
				}
			}


			$send_sms_qty = $person * $sms_qty ;
			$this->Common_model->updateData('sms_log',array('sms_person'=>$person,'send_sms_qty'=>$send_sms_qty),array('sms_log_id'=>$insert)) ;
		}else{
			$this->session->set_userdata('alertMsg',"danger_You have no enough sms.");
		}
		redirect("sms");
	}
}


