<?php

class Test_result extends CI_Controller {

    //put your code here
    public function __construct() {
        parent::__construct();
    }

    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'All Test Result';
            $data['page_title'] = 'All Test Result';
            $data['info_header'] = 'All Test Result';
            $data['all_test_result'] = $this->Common_model->get_all_info_orderby('test_result', 'record_id', 'DESC');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_result/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function create() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Test Result Input';
            $data['page_title'] = 'Test Result Input';
            $data['info_header'] = 'All Test Result Input';
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_result/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $date = $this->input->post('date');
            $patient_id = $this->input->post('patient_id');
            $patient = $this->Common_model->findById('patient',array('record_id'=>$patient_id));
            $patient_name = isset($patient)?$patient->name:'' ;
            $test_id = $this->input->post('test_id');

            $test = $this->Common_model->findById('test_name',array('record_id'=>$test_id));
            $test_category_id = isset($test)?$test->test_category_id:0;
            $test_name = isset($test)?$test->test_name:0;
            $category = $this->Common_model->findById('test_category',array('record_id'=>$test_category_id));
            $test_category = isset($category)?$category->test_category:'' ;
            $age = $this->input->post('age');
            $sex = $this->input->post('sex');
            $ref_by = $this->input->post('ref_by');
            $report_date = $this->input->post('report_date');

            $insert_data = array(
                'date' => $date,
                'patient_id' => $patient_id,
                'patient_name' => $patient_name,
                'doctor_name' => $ref_by,
                'age' => $age,
                'sex' => $sex,
                'test_category_id' => $test_category_id,
                'test_id' => $test_id,
                'test_category' => $test_category,
                'test_name' => $test_name,
                'report_date' => $report_date
            );
            $test_inserted_id = $this->Common_model->saveData('test_result', $insert_data);
            $record_id = $test_inserted_id;
            if (  $test_category_id == 1) {
                $insert_data = array(
                    'patient_id' => $patient_id,
                    'patient_name' => $patient_name,
                    'date' => $date,
                    'age' => $age,
                    'sex' => $sex,
                    'referenced_by' => $ref_by,
                    'report_date' => $report_date,
                    'hemoglobin' => $this->input->post('Hemoglobin'),
                    'esr' => $this->input->post('ESR'),
                    'total_wbc' => $this->input->post('Total_WBC_Count'),
                    'neutrophils' => $this->input->post('Neutrophils'),
                    'lymphocytes' => $this->input->post('Lymphocytes'),
                    'monocytes' => $this->input->post('Monocytes'),
                    'eosinophils' => $this->input->post('Eosinophils'),
                    'basophils' => $this->input->post('Basophils'),
                    'others_cell' => $this->input->post('Others_Cell'),
                    'total_eosinophils' => $this->input->post('Total_Eosinophil'),
                    'platelet_count' => $this->input->post('Platelet_Count'),
                    'mpv' => $this->input->post('MPV'),
                    'pdw' => $this->input->post('PDW'),
                    'pct' => $this->input->post('PCT'),
                    'rbc_count' => $this->input->post('RBC_Count'),
                    'hct_pcv' => $this->input->post('HCT_PCV'),
                    'mcv' => $this->input->post('MCV'),
                    'mch' => $this->input->post('MCH'),
                    'mchc' => $this->input->post('MCHC'),
                    'rdw_cv' => $this->input->post('RDW_CV'),
                    'rdw_sd' => $this->input->post('RDW_SD'),
                    'p_lcr' => $this->input->post('P_LCR'),
                    'bt' => $this->input->post('bt'),
                    'ct' => $this->input->post('ct'),
                    'hb_cyan' => $this->input->post('hb_cyan'),
                    'pbf' => $this->input->post('pbf'),
                    'ct' => $this->input->post('ct'),
                    'note' => $this->input->post('note'),
                    'mp' => $this->input->post('mp'),
                    'test_inserted_id' => $test_inserted_id
                );
                $this->Common_model->saveData('report_haematology', $insert_data);

                $this->zend->load('Zend/Barcode');
                $image_file = Zend_Barcode::draw('code128', 'image', array('text' => 'HAE' . sprintf('%d', $record_id)), array());
                imagejpeg($image_file, "./assets/img/barcode/HAE$record_id.jpg");

                redirect('/Test_result/show_report/' . $test_inserted_id, 'refresh');
            } elseif ( $test_category_id == 2) {
                $insert_data = array(
                    'patient_id' => $patient_id,
                    'patient_name' => $patient_name,
                    'date' => $date,
                    'age' => $age,
                    'sex' => $sex,
                    'referenced_by' => $ref_by,
                    'report_date' => $report_date,
                    'bl_gl_fa' => $this->input->post('bl_gl_fa'),
                    'bl_gl_fa_sugar' => $this->input->post('bl_gl_fa_sugar'),
                    'bl_gl_2h' => $this->input->post('bl_gl_2h'),
                    'bl_gl_2h_sugar' => $this->input->post('bl_gl_2h_sugar'),
                    'bl_gl_1h_75' => $this->input->post('bl_gl_1h_75'),
                    'bl_gl_1h_75_sugar' => $this->input->post('bl_gl_1h_75_sugar'),
                    'bl_gl_2h_75' => $this->input->post('bl_gl_2h_75'),
                    'bl_gl_2h_75_sugar' => $this->input->post('bl_gl_2h_75_sugar'),
                    'se_cr' => $this->input->post('se_cr'),
                    'se_bi' => $this->input->post('se_bi'),
                    'se_bi_di' => $this->input->post('se_bi_di'),
                    'se_bi_in' => $this->input->post('se_bi_in'),
                    'se_ur_ac' => $this->input->post('se_ur_ac'),
                    'se_ca' => $this->input->post('se_ca'),
                    'se_am' => $this->input->post('se_am'),
                    'sgpt' => $this->input->post('sgpt'),
                    'sopt' => $this->input->post('sopt'),
                    'se_al_ph' => $this->input->post('se_al_ph'),
                    'se_ur' => $this->input->post('se_ur'),
                    'hba1c' => $this->input->post('hba1c'),
                    'se_ch' => $this->input->post('se_ch'),
                    'tri_gl' => $this->input->post('tri_gl'),
                    'hdl' => $this->input->post('hdl'),
                    'ldl' => $this->input->post('ldl'),
                    'sodium' => $this->input->post('sodium'),
                    'chloride' => $this->input->post('chloride'),
                    'potassium' => $this->input->post('potassium'),
                    'test_inserted_id' => $test_inserted_id,
                    'OGTT' => $this->input->post('OGTT'),
                    'lipid_profile' => $this->input->post('lipid_profile'),
                    'urea_nitrogen' => $this->input->post('urea_nitrogen'),
                    'se_albumin' => $this->input->post('se_albumin'),
                    'se_globulin' => $this->input->post('se_globulin'),
                    'se_protein' => $this->input->post('se_protein'),
                    'se_lipase' => $this->input->post('se_lipase'),
                    'RBS' => $this->input->post('RBS'),
                    'cor_2habf' => $this->input->post('cor_2habf'),
                    'bd_glucose' => $this->input->post('bd_glucose')
                );
                $this->Common_model->saveData('report_biochemistry', $insert_data);

                $this->zend->load('Zend/Barcode');
                $image_file = Zend_Barcode::draw('code128', 'image', array('text' => 'BIO' . sprintf('%d', $record_id)), array());
                imagejpeg($image_file, "./assets/img/barcode/BIO$record_id.jpg");

                redirect('/Test_result/show_report/' . $test_inserted_id, 'refresh');
            } elseif (  $test_category_id == 3) {
                $insert_data = array(
                    'patient_id' => $patient_id,
                    'patient_name' => $patient_name,
                    'date' => $date,
                    'age' => $age,
                    'sex' => $sex,
                    'referenced_by' => $ref_by,
                    'report_date' => $report_date,
                    'HbA1c' => $this->input->post('HbA1c'),
                    'TSH' => $this->input->post('TSH'),
                    'T4' => $this->input->post('T4'),
                    'T3' => $this->input->post('T3'),
                    'Troponin_I' => $this->input->post('Troponin_I'),
                    'CRP' => $this->input->post('CRP'),
                    'test_inserted_id' => $test_inserted_id,
                    'FT3' => $this->input->post('FT3'),
                    'FT4' => $this->input->post('FT4'),
                    'se_ige' => $this->input->post('se_ige'),
                    'se_igg' => $this->input->post('se_igg'),
                    'se_prolectin' => $this->input->post('se_prolectin'),
                    'psa' => $this->input->post('psa'),
                    'testosterone' => $this->input->post('testosterone'),
                    'hcg' => $this->input->post('hcg')
                );
                $this->Common_model->saveData('report_immunology', $insert_data);

                $this->zend->load('Zend/Barcode');
                $image_file = Zend_Barcode::draw('code128', 'image', array('text' => 'IMM' . sprintf('%d', $record_id)), array());
                imagejpeg($image_file, "./assets/img/barcode/IMM$record_id.jpg");

                redirect('/Test_result/show_report/' . $test_inserted_id, 'refresh');
            } elseif (  $test_category_id == 4) {
                $insert_data = array(
                    'patient_id' => $patient_id,
                    'patient_name' => $patient_name,
                    'date' => $date,
                    'age' => $age,
                    'sex' => $sex,
                    'referenced_by' => $ref_by,
                    'report_date' => $report_date,
                    'MT' => $this->input->post('MT'),
                    'comment' => $this->input->post('comment'),
                    'test_inserted_id' => $test_inserted_id
                );
                $this->Common_model->saveData('report_mt', $insert_data);

                $this->zend->load('Zend/Barcode');
                $image_file = Zend_Barcode::draw('code128', 'image', array('text' => 'MT' . sprintf('%d', $record_id)), array());
                imagejpeg($image_file, "./assets/img/barcode/MT$record_id.jpg");

                redirect('/Test_result/show_report/' . $test_inserted_id, 'refresh');
            } elseif ( $test_category_id ==  5) {
                $insert_data = array(
                    'patient_id' => $patient_id,
                    'patient_name' => $patient_name,
                    'date' => $date,
                    'age' => $age,
                    'sex' => $sex,
                    'referenced_by' => $ref_by,
                    'report_date' => $report_date,
                    'Colour' => $this->input->post('Colour'),
                    'Appearance' => $this->input->post('Appearance'),
                    'Sediment' => $this->input->post('Sediment'),
                    'Specific_gravity' => $this->input->post('Specific_gravity'),
                    'PH' => $this->input->post('PH'),
                    'Protein' => $this->input->post('Protein'),
                    'Reducing_Substance' => $this->input->post('Reducing_Substance'),
                    'Ex_Phosphate' => $this->input->post('Ex_Phosphate'),
                    'Ketones' => $this->input->post('Ketones'),
                    'Bilirubin' => $this->input->post('Bilirubin'),
                    'Urobilinogen' => $this->input->post('Urobilinogen'),
                    'Nitrate' => $this->input->post('Nitrate'),
                    'Blood' => $this->input->post('Blood'),
                    'Leukocyte' => $this->input->post('Leukocyte'),
                    'Epithelial_Cell' => $this->input->post('Epithelial_Cell'),
                    'Pus_Cell' => $this->input->post('Pus_Cell'),
                    'RBC' => $this->input->post('RBC'),
                    'Hyaline' => $this->input->post('Hyaline'),
                    'Granular' => $this->input->post('Granular'),
                    'WBC' => $this->input->post('WBC'),
                    'RBC_cast' => $this->input->post('RBC_cast'),
                    'Calcium_Oxalate' => $this->input->post('Calcium_Oxalate'),
                    'Amor_Phosphate' => $this->input->post('Amor_Phosphate'),
                    'Triple_Phosphate' => $this->input->post('Triple_Phosphate'),
                    'Uric_Acid' => $this->input->post('Uric_Acid'),
                    'pregnancy' => $this->input->post('pregnancy'),
                    'Photocoagulation' => $this->input->post('Photocoagulation'),
                    'test_inserted_id' => $test_inserted_id
                );
                $this->Common_model->saveData('report_urinerme', $insert_data);

                $this->zend->load('Zend/Barcode');
                $image_file = Zend_Barcode::draw('code128', 'image', array('text' => 'URI' . sprintf('%d', $record_id)), array());
                imagejpeg($image_file, "./assets/img/barcode/URI$record_id.jpg");

                redirect('/Test_result/show_report/' . $test_inserted_id, 'refresh');
            } elseif ( $test_category_id ==  6) {

                $insert_data = array(
                    'patient_id' => $patient_id,
                    'patient_name' => $patient_name,
                    'date' => $date,
                    'age' => $age,
                    'sex' => $sex,
                    'referenced_by' => $ref_by,
                    'report_date' => $report_date,
                    'consistency' => $this->input->post('consistency'),
                    'color' => $this->input->post('color'),
                    'mucus' => $this->input->post('mucus'),
                    'blood' => $this->input->post('blood'),
                    'reaction' => $this->input->post('reaction'),
                    'occult_blood' => $this->input->post('occult_blood'),
                    'reducing_substance' => $this->input->post('reducing_substance'),
                    'ascaris' => $this->input->post('ascaris'),
                    'ankylostoma' => $this->input->post('ankylostoma'),
                    'trichuris' => $this->input->post('trichuris'),
                    'giardia' => $this->input->post('giardia'),
                    'e_histolytica' => $this->input->post('e_histolytica'),
                    'e_coli' => $this->input->post('e_coli'),
                    'vegetable_cells' => $this->input->post('vegetable_cells'),
                    'muscle_cells' => $this->input->post('muscle_cells'),
                    'fat_globules' => $this->input->post('fat_globules'),
                    'starch_granules' => $this->input->post('starch_granules'),
                    'RBC' => $this->input->post('RBC'),
                    'pus_cells' => $this->input->post('pus_cells'),
                    'epithelial_cells' => $this->input->post('epithelial_cells'),
                    'worm' => $this->input->post('worm'),
                    'test_inserted_id' => $test_inserted_id
                );
                $this->Common_model->saveData('report_stool_rme', $insert_data);

                $this->zend->load('Zend/Barcode');
                $image_file = Zend_Barcode::draw('code128', 'image', array('text' => 'STO' . sprintf('%d', $record_id)), array());
                imagejpeg($image_file, "./assets/img/barcode/STO$record_id.jpg");

                redirect('/Test_result/show_report/' . $test_inserted_id, 'refresh');
            } elseif ( $test_category_id ==  7) {
                $insert_data = array(
                    'patient_id' => $patient_id,
                    'patient_name' => $patient_name,
                    'date' => $date,
                    'age' => $age,
                    'sex' => $sex,
                    'referenced_by' => $ref_by,
                    'report_date' => $report_date,
                    'ABO_group' => $this->input->post('ABO_group'),
                    'Rh_type' => $this->input->post('Rh_type'),
                    'doner_name' => $this->input->post('doner_name'),
                    'doner_abo' => $this->input->post('doner_abo'),
                    'rh_types' => $this->input->post('rh_types'),
                    'cross_matching' => $this->input->post('cross_matching'),
                    'age_d' => $this->input->post('age_d'),
                    'sex_d' => $this->input->post('sex_d'),
                    'scr_test' => $this->input->post('scr_test'),
                    'test_inserted_id' => $test_inserted_id
                );
                $this->Common_model->saveData('report_cross_matching', $insert_data);

                $this->zend->load('Zend/Barcode');
                $image_file = Zend_Barcode::draw('code128', 'image', array('text' => 'CRO' . sprintf('%d', $record_id)), array());
                imagejpeg($image_file, "./assets/img/barcode/CRO$record_id.jpg");

                redirect('/Test_result/show_report/' . $test_inserted_id, 'refresh');
            } elseif ( $test_category_id ==  8) {
                $insert_data = array(
                    'patient_id' => $patient_id,
                    'patient_name' => $patient_name,
                    'date' => $date,
                    'age' => $age,
                    'sex' => $sex,
                    'referenced_by' => $ref_by,
                    'report_date' => $report_date,
                    'Amount' => $this->input->post('Amount'),
                    'Colour' => $this->input->post('Colour'),
                    'Viscosity' => $this->input->post('Viscosity'),
                    'TC_of_Sperm' => $this->input->post('TC_of_Sperm'),
                    'Active_Motile' => $this->input->post('Active_Motile'),
                    'Weakly_Motile' => $this->input->post('Weakly_Motile'),
                    'Non_Motile' => $this->input->post('Non_Motile'),
                    'Morphologically_Normal' => $this->input->post('Morphologically_Normal'),
                    'Morphologically_Abnormal' => $this->input->post('Morphologically_Abnormal'),
                    'Pus_Cell' => $this->input->post('Pus_Cell'),
                    'Epithelial_Cell' => $this->input->post('Epithelial_Cell'),
                    'RBC' => $this->input->post('RBC'),
                    'Fructose' => $this->input->post('Fructose'),
                    'collection_place' => $this->input->post('collection_place'),
                    'ejaculation_time' => $this->input->post('ejaculation_time'),
                    'examination_time' => $this->input->post('examination_time'),
                    'abstinence_period' => $this->input->post('abstinence_period'),
                    'test_inserted_id' => $test_inserted_id
                );
                $this->Common_model->saveData('report_semen_analysis_report', $insert_data);

                $this->zend->load('Zend/Barcode');
                $image_file = Zend_Barcode::draw('code128', 'image', array('text' => 'SEM' . sprintf('%d', $record_id)), array());
                imagejpeg($image_file, "./assets/img/barcode/SEM$record_id.jpg");

                redirect('/Test_result/show_report/' . $test_inserted_id, 'refresh');
            } elseif ( $test_category_id ==  9) {
                $insert_data = array(
                    'patient_id' => $patient_id,
                    'patient_name' => $patient_name,
                    'date' => $date,
                    'age' => $age,
                    'sex' => $sex,
                    'referenced_by' => $ref_by,
                    'report_date' => $report_date,
                    'SKIN' => $this->input->post('SKIN'),
                    'THROAT' => $this->input->post('THROAT'),
                    'test_inserted_id' => $test_inserted_id
                );
                $this->Common_model->saveData('report_skin_scraping', $insert_data);

                $this->zend->load('Zend/Barcode');
                $image_file = Zend_Barcode::draw('code128', 'image', array('text' => 'SKI' . sprintf('%d', $record_id)), array());
                imagejpeg($image_file, "./assets/img/barcode/SKI$record_id.jpg");

                redirect('/Test_result/show_report/' . $test_inserted_id, 'refresh');
            } elseif ( $test_category_id ==  10) {
                $insert_data = array(
                    'patient_id' => $patient_id,
                    'patient_name' => $patient_name,
                    'date' => $date,
                    'age' => $age,
                    'sex' => $sex,
                    'referenced_by' => $ref_by,
                    'report_date' => $report_date,
                    'RA_Test' => $this->input->post('RA_Test'),
                    'CRP' => $this->input->post('CRP'),
                    'HBsAg' => $this->input->post('HBsAg'),
                    'VDRL' => $this->input->post('VDRL'),
                    'Blood_group' => $this->input->post('Blood_group'),
                    'Widal_Test' => $this->input->post('Widal_Test'),
                    'ASO_Titre' => $this->input->post('ASO_Titre'),
                    'Typhoid_Paratyphoid' => $this->input->post('Typhoid_Paratyphoid'),
                    'Brucellosis' => $this->input->post('Brucellosis'),
                    'Typhus_Fever' => $this->input->post('Typhus_Fever'),
                    'test_inserted_id' => $test_inserted_id,
                    'HBsAg_con' => $this->input->post('HBsAg_con'),
                    'TPHA' => $this->input->post('TPHA'),
                    'Aldehyde' => $this->input->post('Aldehyde'),
                    'Typhoid' => $this->input->post('Typhoid'),
                    'TB' => $this->input->post('TB'),
                    'Failaria' => $this->input->post('Failaria'),
                    'Kala_Azar' => $this->input->post('Kala_Azar'),
                    'Malaria' => $this->input->post('Malaria'),
                    'HIV' => $this->input->post('HIV'),
                    'HCV' => $this->input->post('HCV'),
                    'Dengu_ns1' => $this->input->post('Dengu_ns1'),
                    'Dengu_igg_igm' => $this->input->post('Dengu_igg_igm')
                );
                $this->Common_model->saveData('report_serological', $insert_data);



                $this->zend->load('Zend/Barcode');
                $image_file = Zend_Barcode::draw('code128', 'image', array('text' => 'SER' . sprintf('%d', $test_category_id)), array());
                imagejpeg($image_file, "./assets/img/barcode/SER$test_category_id.jpg");

                redirect('/Test_result/show_report/' . $test_inserted_id, 'refresh');
            }
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }


    public function get_test_form() {
        $date = $this->input->post('date');
        $patient_id = $this->input->post('patient_id');
        $test_id = $this->input->post('test_id');

        $test = $this->Common_model->findById('test_name',array('record_id'=>$test_id));
        $test_category_id = isset($test)?$test->test_category_id:0;
        $test_name = isset($test)?$test->test_name:0;

        $test_category = $this->Common_model->findById('test_category',array('record_id'=>$test_category_id));

        $where = array() ;
        $where['date'] = $date;
        $where['patient_id'] = $patient_id;
        $where['test_category'] = isset($test_category)?$test_category->test_category:'';
        $where['test_name'] = $test_name;

        $data['test_name'] = $test_name ;

        $result = $this->Common_model->findById('test_result',$where);

        if(isset($result)){
                $this->load->view('admin/test_result/default_result');
        }else{
            if ( $test_category_id == 1) {
                $this->load->view('admin/Test/haematology', $data);
            } elseif ( $test_category_id == 2) {
                $this->load->view('admin/Test/biochemistry', $data);
            } elseif ( $test_category_id == 3) {
                $this->load->view('admin/Test/IMMUNOLOGY', $data);
            } elseif ( $test_category_id == 4) {
                $this->load->view('admin/Test/MT', $data);
            } elseif ( $test_category_id == 5) {
                $this->load->view('admin/Test/Urine_RME', $data);
            } elseif ( $test_category_id == 6) {
                $this->load->view('admin/Test/Stool_RME', $data);
            } elseif ( $test_category_id == 7) {
                $this->load->view('admin/Test/Cross_matching', $data);
            } elseif ( $test_category_id == 8) {
                $this->load->view('admin/Test/Semen_Analysis_Report', $data);
            } elseif ( $test_category_id == 9) {
                $this->load->view('admin/Test/Skin_Scraping_Report', $data);
            } elseif ( $test_category_id == 10) {
                $this->load->view('admin/Test/Serological_Test_Report', $data);
            }
        }

        
    }


    public function show_report($test_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $info = $this->Common_model->findById('test_result', array('record_id'=> $test_id));

            $test_category = isset($info)?$info->test_category:'';
            $test_name = isset($info)?$info->test_name:'';
            $test_category_id = isset($info)?$info->test_category_id:'';
            
            $data['redirect'] = base_url('test_result/create') ;
            $data['test_id'] = $test_id;
            $data['test_name'] = $test_name;
            if (  $test_category_id == 1) {
                $data["test_res"] = $this->Common_model->get_allinfo_byid('report_haematology', 'test_inserted_id', $test_id);
                $this->load->view('admin/layouts/header');
                $this->load->view('admin/test_result/report_haematology_print', $data);
                $this->load->view('admin/layouts/footer');
            } elseif ( $test_category_id ==  2) {
                $data["test_res"] = $this->Common_model->get_allinfo_byid('report_biochemistry', 'test_inserted_id', $test_id);

                $this->load->view('admin/layouts/header');
                $this->load->view('admin/test_result/report_biochemistry_print', $data);
                $this->load->view('admin/layouts/footer');
            } elseif (  $test_category_id == 3) {
                $data["test_res"] = $this->Common_model->get_allinfo_byid('report_immunology', 'test_inserted_id', $test_id);

                $this->load->view('admin/layouts/header');
                $this->load->view('admin/test_result/report_IMMUNOLOGY_print', $data);
                $this->load->view('admin/layouts/footer');
            } elseif (  $test_category_id == 4) {
                $data["test_res"] = $this->Common_model->get_allinfo_byid('report_mt', 'test_inserted_id', $test_id);

                $this->load->view('admin/layouts/header');
                $this->load->view('admin/test_result/report_MT_print', $data);
                $this->load->view('admin/layouts/footer');
            } elseif ( $test_category_id ==  5) {
                $data["test_res"] = $this->Common_model->get_allinfo_byid('report_urinerme', 'test_inserted_id', $test_id);

                $this->load->view('admin/layouts/header');
                $this->load->view('admin/test_result/report_UrineRME_print', $data);
                $this->load->view('admin/layouts/footer');
            } elseif ( $test_category_id ==  6) {
                $data["test_res"] = $this->Common_model->get_allinfo_byid('report_stool_rme', 'test_inserted_id', $test_id);

                $this->load->view('admin/layouts/header');
                $this->load->view('admin/test_result/report_stool_rme_print', $data);
                $this->load->view('admin/layouts/footer');
            } elseif ( $test_category_id ==  7) {
                $data["test_res"] = $this->Common_model->get_allinfo_byid('report_cross_matching', 'test_inserted_id', $test_id);

                $this->load->view('admin/layouts/header');
                $this->load->view('admin/test_result/report_cross_matching_print', $data);
                $this->load->view('admin/layouts/footer');
            } elseif ( $test_category_id ==  8) {
                $data["test_res"] = $this->Common_model->get_allinfo_byid('report_semen_analysis_report', 'test_inserted_id', $test_id);

                $this->load->view('admin/layouts/header');
                $this->load->view('admin/test_result/report_semen_analysis_report_print', $data);
                $this->load->view('admin/layouts/footer');
            } elseif ( $test_category_id ==  9) {
                $data["test_res"] = $this->Common_model->get_allinfo_byid('report_skin_scraping', 'test_inserted_id', $test_id);

                $this->load->view('admin/layouts/header');
                $this->load->view('admin/test_result/report_Skin_Scraping_Report_print', $data);
                $this->load->view('admin/layouts/footer');
            } elseif ( $test_category_id ==  10) {
                $data["test_res"] = $this->Common_model->get_allinfo_byid('report_serological', 'test_inserted_id', $test_id);

                $this->load->view('admin/layouts/header');
                $this->load->view('admin/test_result/report_Serological_Test_Report_print', $data);
                $this->load->view('admin/layouts/footer');
            }
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function today_patient_test() {
        $patient_id = $this->input->post('patient_id');
        $date = $this->input->post('date');
        $where = array();
        $where["date"] = $date;
        $where["patient_id"] = $patient_id;
        $result = $this->Common_model->findAll('sales_test', $where,'record_id','asc');
        $option = "<option value=>--Select--</option>";
        $doctor_name = "";
        $doctor_id = 0 ;
        $test = '' ;
        $category = '' ;
        foreach ($result as $info) {
            $doctor_id = $info->doctor_id ;
            $test_category = $this->Common_model->findById('test_category',array('record_id'=>$info->test_category_id));
            $test_name = $this->Common_model->findById('test_name',array('record_id'=>$info->test_id));
            $category = isset($test_category)?$test_category->test_category:'' ;
            $test = isset($test_name)?$test_name->test_name:'' ;
            $option .= "<option value='$info->test_id'>$test [$category]</option>";
        }
        if($doctor_id){
            $doctor = $this->Common_model->findById('doctor',array('record_id'=>$doctor_id));
            $doctor_name = isset($doctor)?$doctor->name.' - '.$doctor->designation : '' ;
        }
        $data = array('option'=>$option, 'doctor_name'=>$doctor_name);
        echo json_encode($data);
    }

}
