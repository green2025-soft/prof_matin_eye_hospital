<?php
date_default_timezone_set('Asia/Dhaka');
class Test_result extends CI_Controller
{

    //put your code here
    public function __construct()
    {
        parent::__construct();
        $this->load->library('upload');
    }

    public function index()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Pathological Test Result';
            $data['page_title'] = 'Pathological Test Result';
            $data['info_header'] = 'Pathological Test Result';
            $data['test_names'] = $this->Common_model->findAll('test_name', array(), 'record_id', 'asc');
            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $test_id = $this->input->get('test_id');

            if (!isset($from_date) && !isset($to_date) && !isset($test_id)) {
                $from_date = $to_date = date('Y-m-d');
            }

            $where = array();
            if (!admin()) {
                $where['show_hide'] = 'Show';
            }

            $whereNotIn = array(11,19);
            $whereNotInColumn = 'test_category_id' ;


            if ($test_id) $where['test_id'] = $test_id;
            if (!empty($from_date) && !empty($to_date)) {
                $where['date >= '] = $from_date;
                $where['date <= '] = $to_date;
            } elseif (!empty($from_date) && empty($to_date)) {
                $where['date'] = $from_date;
            } elseif (empty($from_date) && !empty($to_date)) {
                $where['date'] = $to_date;
            }
           // var_dump($where) ; die ;
            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;
            $data['test_id'] = $test_id;

            // $data['all_test_result'] = $this->Common_model->findAllWhereNotIn('test_result', $where,$whereNotIn,$whereNotInColumn, 'record_id', 'DESC');
            $data['all_test_result'] = $this->Common_model->getAllReports($from_date, $to_date, $test_id);
            // ddd($data['all_test_result']);
            $data['permissions'] = getPermissions();
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_result/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function ultra()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Sono Test Result';
            $data['page_title'] = 'Sono Test Result';
            $data['info_header'] = 'Sono Test Result';
            $data['test_names'] = $this->Common_model->findAll('test_name', array('test_category_id' => 11), 'record_id', 'asc');
            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $test_id = $this->input->get('test_id');

            if (!isset($from_date) && !isset($to_date) && !isset($test_id)) {
                $from_date = $to_date = date('Y-m-d');
            }

            $where = array();
            $where['test_category_id'] = 11;
            if ($test_id) $where['test_id'] = $test_id;
            if (!empty($from_date) && !empty($to_date)) {
                $where['date >= '] = $from_date;
                $where['date <= '] = $to_date;
            } elseif (!empty($from_date) && empty($to_date)) {
                $where['date'] = $from_date;
            } elseif (empty($from_date) && !empty($to_date)) {
                $where['date'] = $to_date;
            }
            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;
            $data['test_id'] = $test_id;

            $data['all_test_result'] = $this->Common_model->findAll('test_result', $where, 'record_id', 'DESC');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_result/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function echo()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Echo-Cardiogram Test Result';
            $data['page_title'] = 'Echo-Cardiogram Test Result';
            $data['info_header'] = 'Echo-Cardiogram Test Result';
            $data['test_names'] = $this->Common_model->findAll('test_name', array('test_category_id' => 11), 'record_id', 'asc');
            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $test_id = $this->input->get('test_id');

            if (!isset($from_date) && !isset($to_date) && !isset($test_id)) {
                $from_date = $to_date = date('Y-m-d');
            }

            $where = array();
            $where['test_category_id'] = 19;
            if ($test_id) $where['test_id'] = $test_id;
            if (!empty($from_date) && !empty($to_date)) {
                $where['date >= '] = $from_date;
                $where['date <= '] = $to_date;
            } elseif (!empty($from_date) && empty($to_date)) {
                $where['date'] = $from_date;
            } elseif (empty($from_date) && !empty($to_date)) {
                $where['date'] = $to_date;
            }
            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;
            $data['test_id'] = $test_id;

            $data['all_test_result'] = $this->Common_model->findAll('test_result', $where, 'record_id', 'DESC');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_result/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function create()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Test Result Input';
            $data['page_title'] = 'Test Result Input';
            $data['info_header'] = 'All Test Result Input';

            $today = date('Y-m-d');
            $where = array();
            $where['date'] = $today;
            $where['type'] = 'Test Invoice';
            $data['invoice_list'] = $this->Common_model->findAll('create_bill', $where, 'record_id', 'desc');
            $last_out_product = $this->Common_model->findFirstOrLast('lab_product_out_details', array('out_from' => 'Result Input'), 'record_id', 'desc');
            $data['last_out_product_id'] = isset($last_out_product) ? $last_out_product->product_id : 0;

            $last_result = $this->Common_model->findFirstOrLast('test_reports', array(), 'record_id', 'desc');
            $data['duty_doctor_id'] = isset($last_result) ? $last_result->duty_doctor_id : 0;
            $data['duty_staff_id'] = isset($last_result) ? $last_result->duty_staff_id : 0;
            $data['duty_staff_id2'] = isset($last_result) ? $last_result->duty_staff_id2 : 0;

            
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_result/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function saveOrUpdate()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            // ddd($_POST);
            $loginId = $this->session->userData('ses_record_id');
            $date = $this->input->post('date');
            $blank_result = $this->input->post('blank_result');

            if (isset($blank_result)) {
                $blank_result = 1;
            } else {
                $blank_result = 0;
            }
            //  var_dump($blank_result);die;
            $patient_id = $this->input->post('patient_id');
            $patient = $this->Common_model->findById('patient', array('record_id' => $patient_id));
            $patient_name = isset($patient) ? $patient->name : '';
            $duty_doctor_id = $this->input->post('duty_doctor_id');
            $duty_staff_id = $this->input->post('duty_staff_id');
            $duty_staff_id2 = $this->input->post('duty_staff_id2');
            $test_id = $this->input->post('test_id');
            $invoice_id = $this->input->post('invoice_id');
            $sales_test_id = $this->input->post('sales_test_id');
            $doctor_id = $this->input->post('doctor_id');
            $comments = $this->input->post('comments');
            $reAgentQuantity = $this->input->post('quantity');
            $reAgentID = $this->input->post('product_id');
            $staff_id = $this->input->post('staff_id');

            // $test = $this->Common_model->findById('test_name', array('record_id' => $test_id));
            // $test_category_id = isset($test) ? $test->test_category_id : 0;
            // $test_name = isset($test) ? $test->test_name : 0;
            // $category = $this->Common_model->findById('test_category', array('record_id' => $test_category_id));
            // $test_category = isset($category) ? $category->test_category : '';
            $age = $this->input->post('age');
            $sex = $this->input->post('sex');
            $ref_by = $this->input->post('ref_by');
            $report_date = $this->input->post('report_date');
            $report_fields = $this->input->post('report_field');

            $config['upload_path']      = 'assets/img/attached_file/';
            $config['allowed_types']    = '*';
            $config['max_size']         = '0';
            //$config['file_name']      = time(); 
            $file_field                 = "attached_file";
            $attached_file = '';
            $this->upload->initialize($config);
            if (!empty($_FILES[$file_field]["name"])) {
                if ($this->upload->do_upload($file_field)) {
                    $uploadData = $this->upload->data();
                    $attached_file =   $config['upload_path'] . $uploadData['file_name'];
                }
            }

            // $insert_data = array(
            //     'date' => $date,
            //     'invoice_id' => $invoice_id,
            //     'sales_test_id' => $sales_test_id,
            //     'patient_id' => $patient_id,
            //     'doctor_id' => $doctor_id,
            //     'patient_name' => $patient_name,
            //     'doctor_name' => $ref_by,
            //     'age' => $age,
            //     'sex' => $sex,
            //     'test_category_id' => $test_category_id,
            //     'test_id' => $test_id,
            //     'test_category' => $test_category,
            //     'test_name' => $test_name,
            //     'report_date' => $report_date,
            //     'attached_file' => $attached_file,
            //     'blank_result' => $blank_result,
            // );
            // $test_inserted_id = $this->Common_model->saveData('test_result', $insert_data);
            
            
            if(sizeof($test_id) > 0){

                $testDetails = $this->Common_model->getTestDetails($test_id);

                //check same category

                $testCat = 0;
                $categoryFlag = true;
                foreach($testDetails  as $row){
                    if($testCat == 0){
                        $testCat = $row->test_category_id;
                    }
                    if($testCat !== $row->test_category_id){
                        $categoryFlag = false;
                    }
                }

                if($categoryFlag){

                    $reportFieldData = [];
                    $testNameDataArr = [];

                    $testReportData = array(
                        'collection_date' => $date,
                        'report_date' => date("Y-m-d"),
                        'invoice_id' => $invoice_id,
                        'patient_id' => $patient_id,
                        'duty_doctor_id' => $duty_doctor_id,
                        'duty_staff_id' => $duty_staff_id,
                        'duty_staff_id2' => $duty_staff_id2,
                        'test_category_id' => $testCat,
                        'doctor_id' => $doctor_id,
                        'comments' => $comments,
                        'created_at' => date('Y-m-d H:i:s')
                    );

                    $test_inserted_id = $this->Common_model->saveData('test_reports', $testReportData);

                    // reduce re agent from stock
                    if(sizeof($reAgentQuantity) > 0 && sizeof($reAgentID) > 0 && array_sum($reAgentQuantity) > 0){

                        $dateToday = date('Y-m-d');
                        $productOutInfo = $this->db->order_by('record_id', 'desc')->get_where('re_agent_out', ['out_date'=> $dateToday])->row();

                        $outSerial = 0;

                        if(!empty($productOutInfo)){
                            $outSerial = $productOutInfo->out_no + 1;
                        }

                        $productOutData = [];
                        $productOutData['staff_id'] = $staff_id;
                        $productOutData['patient_id'] = $patient_id;
                        $productOutData['test_result_id'] = $test_inserted_id;
                        $productOutData['test_id'] = $test_id[0];
                        $productOutData['test_category_id'] = $testDetails[0]->test_category_id;
                        $productOutData['out_date'] = $dateToday;
                        $productOutData['prefix'] = date('Ymd');
                        $productOutData['out_no'] = $outSerial;
                        $productOutData['grand_quantity'] = array_sum($reAgentQuantity);
                        $productOutData['comments'] = 'Result Input';
                        $productOutData['created_by'] = $loginId;

                        $this->db->insert('re_agent_out', $productOutData);

                        $labProductOutID = $this->db->insert_id();

                        for($i = 0; $i< sizeof($reAgentID); $i++){

                            $labProdOutDetailsData = [];
                            // $labProdOutDetailsData['patient_id'] = $patient_id;
                            $labProdOutDetailsData['re_agent_out_id'] = $labProductOutID;
                            $labProdOutDetailsData['staff_id'] = $staff_id;
                            $labProdOutDetailsData['out_date'] = date("Y-m-d");
                            $labProdOutDetailsData['product_id'] = $reAgentID[$i];
                            $labProdOutDetailsData['quantity'] = $reAgentQuantity[$i];
                            $labProdOutDetailsData['unit_price'] = 0;
                            $labProdOutDetailsData['total_price'] = 0;
                            $labProdOutDetailsData['created_by'] = $loginId;

                            $this->db->insert('re_agent_out_details', $labProdOutDetailsData);
                        }

                    }

                    // ddd($test_inserted_id);

                    foreach($test_id as $test){
                        
                        $reportFields = $_POST['report_'.$test.'_fields'];
    
                        if(sizeof($reportFields) > 0){
                            $flag = false;
                            foreach($reportFields as $field){
                                if(isset($field)){
                                    $flag = true;
                                    $testNameDataArr[] = [
                                        'test_report_id' => $test_inserted_id,
                                        'test_name_id' => $test,
                                    ];
                                    break;
                                }
                            }

                            if($flag){
                                foreach($reportFields as $key => $value){
                                    $reportFieldData[] = array(
                                        'test_report_id' => $test_inserted_id,
                                        'test_field_id' => $key,
                                        // 'value' => $value,
                                        'value' => str_replace("@#", "<br>", $value),
                                    );
                                }
                            }
                        }
                    }
                    
                    if(sizeof($reportFieldData) > 0 && sizeof($testNameDataArr) > 0){
                        $this->db->insert_batch('test_report_names', $testNameDataArr);
                        $this->db->insert_batch('test_report_fields', $reportFieldData);
                    }

                    echo $test_inserted_id;
                    exit;
                }

            }


            // if ($test_inserted_id) {
            //     $product_ids = $this->input->post('product_id');
            //     if ($product_ids) {
            //         $lab_product_ids = $this->input->post('record_id');
            //         $quantitys = $this->input->post('quantity');
            //         $unit_prices = $this->input->post('unit_price');
            //         $total_prices = $this->input->post('total_price');
            //         $lab_product_out_data = array();
            //         $prefix = str_replace('-', '', $date);
            //         $max = $this->Common_model->findMax('lab_product_out', array('prefix' => $prefix), 'out_no');
            //         $out_no = isset($max) ? $max->out_no + 1 : 1;
            //         $lab_product_out_data['out_date'] = $date;
            //         $lab_product_out_data['prefix'] = $prefix;
            //         $lab_product_out_data['out_no'] = $out_no;
            //         $lab_product_out_data['patient_id'] = $patient_id;
            //         $lab_product_out_data['test_result_id'] = $test_inserted_id;
            //         $lab_product_out_data['test_id'] = $test_id;
            //         $lab_product_out_data['test_category_id'] = $test_category_id;
            //         $lab_product_out_data['grand_quantity'] = is_array($quantitys) ? array_sum($quantitys) : 0;
            //         $lab_product_out_data['comments'] = 'Result Input';
            //         $total_quantity = is_array($quantitys) ? array_sum($quantitys) : 0;
            //         $total_price = is_array($total_prices) ? array_sum($total_prices) : 0;
            //         $lab_product_out_data['grand_total_price'] = $total_quantity * $total_price;
            //         $out_id = $this->Common_model->saveData('lab_product_out', $lab_product_out_data);
            //         if ($out_id) {
            //             if (isset($lab_product_ids)) {
            //                 foreach ($lab_product_ids as $key => $value) {
            //                     $data = array(
            //                         'lab_product_out_id' => $out_id,
            //                         'out_date' => $date,
            //                         'product_id' => $product_ids[$key],
            //                         'quantity' => $quantitys[$key],
            //                         'unit_price' => $unit_prices[$key],
            //                         'total_price' => $total_prices[$key],
            //                         'out_from' => 'Result Input',
            //                     );
            //                     $this->Common_model->saveData('lab_product_out_details', $data);
            //                 }
            //             }
            //         }
            //     }
            // }

            $record_id = $test_inserted_id;


            // $sms_body = "Thanks for patience. $patient->name[$patient->record_id], Report is ready. Please collect your report from the delivery counter.";
            // $send_date = date('Y-m-d');
            // $sms_qty = ceil(strlen(utf8_decode($sms_body)) / 63);
            // $sms_person = 0;
            // $send_sms_qty = 0;
            // $reserveSmsObj = $this->Common_model->findById('load_sms', array('load_sms_id' => 1));
            // if ($reserveSmsObj->sms_qty > 1) {
            //     $data = array(
            //         'sms_id' => 0,
            //         'sms_title' => 'Result Input',
            //         'send_date' => $send_date,
            //         'sms_body' => $sms_body,
            //         'sms_person' => $sms_person,
            //         'send_sms_qty' => $send_sms_qty,
            //     );
            //     $sms_log_id = $this->Common_model->saveData('sms_log', $data);
            //     $person = 0;
            //     $mobile = $patient->mobile;
            //     if (!empty($mobile) && strlen($mobile) == 11) {
            //         $reserveSmsObj = $this->Common_model->findById('load_sms', array('load_sms_id' => 1));
            //         $reserveSms = isset($reserveSmsObj) ? $reserveSmsObj->sms_qty : 0;
            //         if ($reserveSms >= $sms_qty) {
            //             ++$person;
            //             $smsDetails = array(
            //                 'sms_log_id' => $sms_log_id,
            //                 'send_date' => $send_date,
            //                 'patient_id' => $patient_id,
            //             );
            //             $this->Common_model->saveData('sms_log_details', $smsDetails);
            //             techno_bulk_sms($mobile, $sms_body);
            //             $balance_sms = $reserveSms - ($person * $sms_qty);
            //             $this->Common_model->updateData('load_sms', array('sms_qty' => $balance_sms), array('load_sms_id' => 1));
            //         }
            //     }
            //     $send_sms_qty = $person * $sms_qty;
            //     $this->Common_model->updateData('sms_log', array('sms_person' => $person, 'send_sms_qty' => $send_sms_qty), array('sms_log_id' => $sms_log_id));
            // }

            if(sizeof($report_fields) > 0){

                $reportFieldData = [];
                foreach($report_fields as $key => $value){
                    $reportFieldData[] = array(
                        'test_report_id' => $test_inserted_id,
                        'test_field_id' => $key,
                        'value' => $value,
                    );
                }

            }

            $insert_data = array(
                'patient_id' => $patient_id,
                'patient_name' => $patient_name,
                'date' => $date,
                'age' => $age,
                'sex' => $sex,
                'referenced_by' => $ref_by,
                'report_date' => $report_date,
                'hemoglobin' => $this->input->post('Hemoglobin'),
                'esr' => $this->input->post('ESR'),
                'total_wbc' => $this->input->post('Total_WBC_Count'),
                'neutrophils' => $this->input->post('Neutrophils'),
                'lymphocytes' => $this->input->post('Lymphocytes'),
                'monocytes' => $this->input->post('Monocytes'),
                'eosinophils' => $this->input->post('Eosinophils'),
                'basophils' => $this->input->post('Basophils'),
                'others_cell' => $this->input->post('Others_Cell'),
                'total_eosinophils' => $this->input->post('Total_Eosinophil'),
                'platelet_count' => $this->input->post('Platelet_Count'),
                'mpv' => $this->input->post('MPV'),
                'pdw' => $this->input->post('PDW'),
                'pct' => $this->input->post('PCT'),
                'rbc_count' => $this->input->post('RBC_Count'),
                'hct_pcv' => $this->input->post('HCT_PCV'),
                'mcv' => $this->input->post('MCV'),
                'mch' => $this->input->post('MCH'),
                'mchc' => $this->input->post('MCHC'),
                'rdw_cv' => $this->input->post('RDW_CV'),
                'rdw_sd' => $this->input->post('RDW_SD'),
                'p_lcr' => $this->input->post('P_LCR'),
                'bt' => $this->input->post('bt'),
                'ct' => $this->input->post('ct'),
                'hb_cyan' => $this->input->post('hb_cyan'),
                'pbf' => $this->input->post('pbf'),
                'ct' => $this->input->post('ct'),
                'note' => $this->input->post('note'),
                'mp' => $this->input->post('mp'),
                'test_inserted_id' => $test_inserted_id
            );
            $last_id = $this->Common_model->saveData('report_haematology', $insert_data);

            $this->zend->load('Zend/Barcode');
            $image_file = Zend_Barcode::draw('code128', 'image', array('text' => 'HAE' . sprintf('%d', $record_id)), array());
            imagejpeg($image_file, "./assets/img/barcode/HAE$record_id.jpg");

            // redirect('/Test_result/show_report/' . $test_inserted_id, 'refresh');
            echo $test_inserted_id;
            exit;

            if ($test_category_id == 1) {
                $insert_data = array(
                    'patient_id' => $patient_id,
                    'patient_name' => $patient_name,
                    'date' => $date,
                    'age' => $age,
                    'sex' => $sex,
                    'referenced_by' => $ref_by,
                    'report_date' => $report_date,
                    'hemoglobin' => $this->input->post('Hemoglobin'),
                    'esr' => $this->input->post('ESR'),
                    'total_wbc' => $this->input->post('Total_WBC_Count'),
                    'neutrophils' => $this->input->post('Neutrophils'),
                    'lymphocytes' => $this->input->post('Lymphocytes'),
                    'monocytes' => $this->input->post('Monocytes'),
                    'eosinophils' => $this->input->post('Eosinophils'),
                    'basophils' => $this->input->post('Basophils'),
                    'others_cell' => $this->input->post('Others_Cell'),
                    'total_eosinophils' => $this->input->post('Total_Eosinophil'),
                    'platelet_count' => $this->input->post('Platelet_Count'),
                    'mpv' => $this->input->post('MPV'),
                    'pdw' => $this->input->post('PDW'),
                    'pct' => $this->input->post('PCT'),
                    'rbc_count' => $this->input->post('RBC_Count'),
                    'hct_pcv' => $this->input->post('HCT_PCV'),
                    'mcv' => $this->input->post('MCV'),
                    'mch' => $this->input->post('MCH'),
                    'mchc' => $this->input->post('MCHC'),
                    'rdw_cv' => $this->input->post('RDW_CV'),
                    'rdw_sd' => $this->input->post('RDW_SD'),
                    'p_lcr' => $this->input->post('P_LCR'),
                    'bt' => $this->input->post('bt'),
                    'ct' => $this->input->post('ct'),
                    'hb_cyan' => $this->input->post('hb_cyan'),
                    'pbf' => $this->input->post('pbf'),
                    'ct' => $this->input->post('ct'),
                    'note' => $this->input->post('note'),
                    'mp' => $this->input->post('mp'),
                    'test_inserted_id' => $test_inserted_id
                );
                $last_id = $this->Common_model->saveData('report_haematology', $insert_data);

                $this->zend->load('Zend/Barcode');
                $image_file = Zend_Barcode::draw('code128', 'image', array('text' => 'HAE' . sprintf('%d', $record_id)), array());
                imagejpeg($image_file, "./assets/img/barcode/HAE$record_id.jpg");

                // redirect('/Test_result/show_report/' . $test_inserted_id, 'refresh');
                echo $test_inserted_id;
                exit;
            } elseif ($test_category_id == 2) {
                $insert_data = array(
                    'patient_id' => $patient_id,
                    'patient_name' => $patient_name,
                    'date' => $date,
                    'age' => $age,
                    'sex' => $sex,
                    'referenced_by' => $ref_by,
                    'report_date' => $report_date,
                    'bl_gl_fa' => $this->input->post('bl_gl_fa'),
                    'bl_gl_fa_sugar' => $this->input->post('bl_gl_fa_sugar'),
                    'bl_gl_2h' => $this->input->post('bl_gl_2h'),
                    'bl_gl_2h_sugar' => $this->input->post('bl_gl_2h_sugar'),
                    'bl_gl_1h_75' => $this->input->post('bl_gl_1h_75'),
                    'bl_gl_1h_75_sugar' => $this->input->post('bl_gl_1h_75_sugar'),
                    'bl_gl_2h_75' => $this->input->post('bl_gl_2h_75'),
                    'bl_gl_2h_75_sugar' => $this->input->post('bl_gl_2h_75_sugar'),
                    'se_cr' => $this->input->post('se_cr'),
                    'se_bi' => $this->input->post('se_bi'),
                    'se_bi_di' => $this->input->post('se_bi_di'),
                    'se_bi_in' => $this->input->post('se_bi_in'),
                    'se_ur_ac' => $this->input->post('se_ur_ac'),
                    'se_ca' => $this->input->post('se_ca'),
                    'se_am' => $this->input->post('se_am'),
                    'sgpt' => $this->input->post('sgpt'),
                    'sopt' => $this->input->post('sopt'),
                    'se_al_ph' => $this->input->post('se_al_ph'),
                    'se_ur' => $this->input->post('se_ur'),
                    'hba1c' => $this->input->post('hba1c'),
                    'se_ch' => $this->input->post('se_ch'),
                    'tri_gl' => $this->input->post('tri_gl'),
                    'hdl' => $this->input->post('hdl'),
                    'ldl' => $this->input->post('ldl'),
                    'sodium' => $this->input->post('sodium'),
                    'chloride' => $this->input->post('chloride'),
                    'potassium' => $this->input->post('potassium'),
                    'test_inserted_id' => $test_inserted_id,
                    'OGTT' => $this->input->post('OGTT'),
                    'lipid_profile' => $this->input->post('lipid_profile'),
                    'urea_nitrogen' => $this->input->post('urea_nitrogen'),
                    'se_albumin' => $this->input->post('se_albumin'),
                    'se_globulin' => $this->input->post('se_globulin'),
                    'se_protein' => $this->input->post('se_protein'),
                    'se_lipase' => $this->input->post('se_lipase'),
                    'serum_iron' => $this->input->post('serum_iron'),
                    'total_iron' => $this->input->post('total_iron'),
                    'ferritin' => $this->input->post('ferritin'),
                    'RBS' => $this->input->post('RBS'),
                    'cor_2habf' => $this->input->post('cor_2habf'),
                    'bd_glucose' => $this->input->post('bd_glucose'),
                    'ldh' => $this->input->post('ldh'),
                    'total_cholesterol' => $this->input->post('total_cholesterol'),
                    'hdl_ratio' => $this->input->post('hdl_ratio'),
                    'patient' => $this->input->post('patient'),
                    'pathorombin_index' => $this->input->post('pathorombin_index'),
                    'ration' => $this->input->post('ration'),
                    'inr' => $this->input->post('inr'),
                    'control' => $this->input->post('control'),
                    'carbondioxide' => $this->input->post('carbondioxide'),
                    'total_carbondioxide' => $this->input->post('total_carbondioxide'),
                    'bicarbonate' => $this->input->post('bicarbonate'),
                    'ph' => $this->input->post('ph'),
                    'e_gfr' => $this->input->post('e_gfr'),
                );
                $last_id = $this->Common_model->saveData('report_biochemistry', $insert_data);

                $this->zend->load('Zend/Barcode');
                $image_file = Zend_Barcode::draw('code128', 'image', array('text' => 'BIO' . sprintf('%d', $record_id)), array());
                imagejpeg($image_file, "./assets/img/barcode/BIO$record_id.jpg");

                //redirect('/Test_result/show_report/' . $test_inserted_id, 'refresh');
                echo $test_inserted_id;
                exit;
            } elseif ($test_category_id == 3) {
                $insert_data = array(
                    'patient_id' => $patient_id,
                    'patient_name' => $patient_name,
                    'date' => $date,
                    'age' => $age,
                    'sex' => $sex,
                    'referenced_by' => $ref_by,
                    'report_date' => $report_date,
                    'HbA1c' => $this->input->post('HbA1c'),
                    'TSH' => $this->input->post('TSH'),
                    'T4' => $this->input->post('T4'),
                    'T3' => $this->input->post('T3'),
                    'Troponin_I' => $this->input->post('Troponin_I'),
                    'CRP' => $this->input->post('CRP'),
                    'test_inserted_id' => $test_inserted_id,
                    'FT3' => $this->input->post('FT3'),
                    'FT4' => $this->input->post('FT4'),
                    'se_ige' => $this->input->post('se_ige'),
                    'total_ige' => $this->input->post('total_ige'),
                    'se_igg' => $this->input->post('se_igg'),
                    'se_prolectin' => $this->input->post('se_prolectin'),
                    'psa' => $this->input->post('psa'),
                    'testosterone' => $this->input->post('testosterone'),
                    'hcg' => $this->input->post('hcg'),
                    'vitamin_d' => $this->input->post('vitamin_d'),
                    'anti_h_pylori' => $this->input->post('anti_h_pylori'),
                    'd_dimer' => $this->input->post('d_dimer'),
                    'ferritin' => $this->input->post('ferritin'),
                    'hbsag' => $this->input->post('hbsag'),
                    'sample_index' => $this->input->post('sample_index'),
                    'cut_off_index' => $this->input->post('cut_off_index'),
                    'tpsa' => $this->input->post('tpsa'),
                    'cardiac_troponin_i_es' => $this->input->post('cardiac_troponin_i_es'),
                    'date_ad_time_injection' => $this->input->post('date_ad_time_injection'),
                    'date_ad_time_reading' => $this->input->post('date_ad_time_reading'),
                    'dose_of_injection' => $this->input->post('dose_of_injection'),
                    'test_hand' => $this->input->post('test_hand'),
                    'result_induration_diameter' => $this->input->post('result_induration_diameter'),
                    'induration_diameter_less_10' => $this->input->post('induration_diameter_less_10'),
                    'induration_diameter_greater_10' => $this->input->post('induration_diameter_greater_10'),
                    'hbsag_opinion' => $this->input->post('hbsag_opinion'),
                    'opinion' => $this->input->post('opinion'),
                    'anti_ccp_antibody' => $this->input->post('anti_ccp_antibody'),
                    'anti_neuclear_antibody' => $this->input->post('anti_neuclear_antibody'),
                );
                $last_id = $this->Common_model->saveData('report_immunology', $insert_data);

                $this->zend->load('Zend/Barcode');
                $image_file = Zend_Barcode::draw('code128', 'image', array('text' => 'IMM' . sprintf('%d', $record_id)), array());
                imagejpeg($image_file, "./assets/img/barcode/IMM$record_id.jpg");

                //redirect('/Test_result/show_report/' . $test_inserted_id, 'refresh');
                echo $test_inserted_id;
                exit;
            } elseif ($test_category_id == 4) {
                $insert_data = array(
                    'patient_id' => $patient_id,
                    'patient_name' => $patient_name,
                    'date' => $date,
                    'age' => $age,
                    'sex' => $sex,
                    'referenced_by' => $ref_by,
                    'report_date' => $report_date,
                    'MT' => $this->input->post('MT'),
                    'comment' => $this->input->post('comment'),
                    'test_inserted_id' => $test_inserted_id
                );
                $last_id = $this->Common_model->saveData('report_mt', $insert_data);

                $this->zend->load('Zend/Barcode');
                $image_file = Zend_Barcode::draw('code128', 'image', array('text' => 'MT' . sprintf('%d', $record_id)), array());
                imagejpeg($image_file, "./assets/img/barcode/MT$record_id.jpg");

                //  redirect('/Test_result/show_report/' . $test_inserted_id, 'refresh');
                echo $test_inserted_id;
                exit;
            } elseif ($test_category_id ==  5) {
                $insert_data = array(
                    'patient_id' => $patient_id,
                    'patient_name' => $patient_name,
                    'date' => $date,
                    'age' => $age,
                    'sex' => $sex,
                    'referenced_by' => $ref_by,
                    'report_date' => $report_date,
                    'Amount' => $this->input->post('Amount'),
                    'Colour' => $this->input->post('Colour'),
                    'Appearance' => $this->input->post('Appearance'),
                    'Sediment' => $this->input->post('Sediment'),
                    'Specific_gravity' => $this->input->post('Specific_gravity'),
                    'PH' => $this->input->post('PH'),
                    'Protein' => $this->input->post('Protein'),
                    'Reducing_Substance' => $this->input->post('Reducing_Substance'),
                    'Ex_Phosphate' => $this->input->post('Ex_Phosphate'),
                    'Ketones' => $this->input->post('Ketones'),
                    'Bilirubin' => $this->input->post('Bilirubin'),
                    'Urobilinogen' => $this->input->post('Urobilinogen'),
                    'Nitrate' => $this->input->post('Nitrate'),
                    'Blood' => $this->input->post('Blood'),
                    'Leukocyte' => $this->input->post('Leukocyte'),
                    'Epithelial_Cell' => $this->input->post('Epithelial_Cell'),
                    'Pus_Cell' => $this->input->post('Pus_Cell'),
                    'RBC' => $this->input->post('RBC'),
                    'Hyaline' => $this->input->post('Hyaline'),
                    'Granular' => $this->input->post('Granular'),
                    'WBC' => $this->input->post('WBC'),
                    'RBC_cast' => $this->input->post('RBC_cast'),
                    'Calcium_Oxalate' => $this->input->post('Calcium_Oxalate'),
                    'Amor_Phosphate' => $this->input->post('Amor_Phosphate'),
                    'Triple_Phosphate' => $this->input->post('Triple_Phosphate'),
                    'Uric_Acid' => $this->input->post('Uric_Acid'),
                    'pregnancy' => $this->input->post('pregnancy'),
                    'Photocoagulation' => $this->input->post('Photocoagulation'),
                    'test_inserted_id' => $test_inserted_id,
                    'Trichomonus' => $this->input->post('Trichomonus'),
                    'Yeast' => $this->input->post('Yeast'),
                );
                $last_id = $this->Common_model->saveData('report_urinerme', $insert_data);

                $this->zend->load('Zend/Barcode');
                $image_file = Zend_Barcode::draw('code128', 'image', array('text' => 'URI' . sprintf('%d', $record_id)), array());
                imagejpeg($image_file, "./assets/img/barcode/URI$record_id.jpg");

                //   redirect('/Test_result/show_report/' . $test_inserted_id, 'refresh');
                echo $test_inserted_id;
                exit;
            } elseif ($test_category_id ==  6) {

                $insert_data = array(
                    'patient_id' => $patient_id,
                    'patient_name' => $patient_name,
                    'date' => $date,
                    'age' => $age,
                    'sex' => $sex,
                    'referenced_by' => $ref_by,
                    'report_date' => $report_date,
                    'consistency' => $this->input->post('consistency'),
                    'color' => $this->input->post('color'),
                    'mucus' => $this->input->post('mucus'),
                    'blood' => $this->input->post('blood'),
                    'reaction' => $this->input->post('reaction'),
                    'occult_blood' => $this->input->post('occult_blood'),
                    'reducing_substance' => $this->input->post('reducing_substance'),
                    'ascaris' => $this->input->post('ascaris'),
                    'ankylostoma' => $this->input->post('ankylostoma'),
                    'trichuris' => $this->input->post('trichuris'),
                    'giardia' => $this->input->post('giardia'),
                    'e_histolytica' => $this->input->post('e_histolytica'),
                    'e_coli' => $this->input->post('e_coli'),
                    'vegetable_cells' => $this->input->post('vegetable_cells'),
                    'muscle_cells' => $this->input->post('muscle_cells'),
                    'fat_globules' => $this->input->post('fat_globules'),
                    'starch_granules' => $this->input->post('starch_granules'),
                    'RBC' => $this->input->post('RBC'),
                    'pus_cells' => $this->input->post('pus_cells'),
                    'epithelial_cells' => $this->input->post('epithelial_cells'),
                    'worm' => $this->input->post('worm'),
                    'test_inserted_id' => $test_inserted_id
                );
                $last_id = $this->Common_model->saveData('report_stool_rme', $insert_data);

                $this->zend->load('Zend/Barcode');
                $image_file = Zend_Barcode::draw('code128', 'image', array('text' => 'STO' . sprintf('%d', $record_id)), array());
                imagejpeg($image_file, "./assets/img/barcode/STO$record_id.jpg");

                // redirect('/Test_result/show_report/' . $test_inserted_id, 'refresh');
                echo $test_inserted_id;
                exit;
            } elseif ($test_category_id ==  7) {
                $insert_data = array(
                    'patient_id' => $patient_id,
                    'patient_name' => $patient_name,
                    'date' => $date,
                    'age' => $age,
                    'sex' => $sex,
                    'referenced_by' => $ref_by,
                    'report_date' => $report_date,
                    'ABO_group' => $this->input->post('ABO_group'),
                    'Rh_type' => $this->input->post('Rh_type'),
                    'doner_name' => $this->input->post('doner_name'),
                    'doner_abo' => $this->input->post('doner_abo'),
                    'rh_types' => $this->input->post('rh_types'),
                    'cross_matching' => $this->input->post('cross_matching'),
                    'age_d' => $this->input->post('age_d'),
                    'sex_d' => $this->input->post('sex_d'),
                    'scr_test' => $this->input->post('scr_test'),
                    'hbsag' => $this->input->post('hbsag'),
                    'hiv' => $this->input->post('hiv'),
                    'hcv' => $this->input->post('hcv'),
                    'vdrl' => $this->input->post('vdrl'),
                    'mp' => $this->input->post('mp'),
                    'test_inserted_id' => $test_inserted_id
                );
                $last_id = $this->Common_model->saveData('report_cross_matching', $insert_data);

                $this->zend->load('Zend/Barcode');
                $image_file = Zend_Barcode::draw('code128', 'image', array('text' => 'CRO' . sprintf('%d', $record_id)), array());
                imagejpeg($image_file, "./assets/img/barcode/CRO$record_id.jpg");

                //  redirect('/Test_result/show_report/' . $test_inserted_id, 'refresh');
                echo $test_inserted_id;
                exit;
            } elseif ($test_category_id ==  8) {
                $insert_data = array(
                    'patient_id' => $patient_id,
                    'patient_name' => $patient_name,
                    'date' => $date,
                    'age' => $age,
                    'sex' => $sex,
                    'referenced_by' => $ref_by,
                    'report_date' => $report_date,
                    'Amount' => $this->input->post('Amount'),
                    'Colour' => $this->input->post('Colour'),
                    'Viscosity' => $this->input->post('Viscosity'),
                    'TC_of_Sperm' => $this->input->post('TC_of_Sperm'),
                    'Active_Motile' => $this->input->post('Active_Motile'),
                    'Weakly_Motile' => $this->input->post('Weakly_Motile'),
                    'Non_Motile' => $this->input->post('Non_Motile'),
                    'Morphologically_Normal' => $this->input->post('Morphologically_Normal'),
                    'Morphologically_Abnormal' => $this->input->post('Morphologically_Abnormal'),
                    'Pus_Cell' => $this->input->post('Pus_Cell'),
                    'Epithelial_Cell' => $this->input->post('Epithelial_Cell'),
                    'RBC' => $this->input->post('RBC'),
                    'Fructose' => $this->input->post('Fructose'),
                    'collection_place' => $this->input->post('collection_place'),
                    'ejaculation_time' => $this->input->post('ejaculation_time'),
                    'examination_time' => $this->input->post('examination_time'),
                    'abstinence_period' => $this->input->post('abstinence_period'),
                    'test_inserted_id' => $test_inserted_id
                );
                $last_id = $this->Common_model->saveData('report_semen_analysis_report', $insert_data);

                $this->zend->load('Zend/Barcode');
                $image_file = Zend_Barcode::draw('code128', 'image', array('text' => 'SEM' . sprintf('%d', $record_id)), array());
                imagejpeg($image_file, "./assets/img/barcode/SEM$record_id.jpg");

                //redirect('/Test_result/show_report/' . $test_inserted_id, 'refresh');
                echo $test_inserted_id;
                exit;
            } elseif ($test_category_id ==  9) {
                $insert_data = array(
                    'patient_id' => $patient_id,
                    'patient_name' => $patient_name,
                    'date' => $date,
                    'age' => $age,
                    'sex' => $sex,
                    'referenced_by' => $ref_by,
                    'report_date' => $report_date,
                    'SKIN' => $this->input->post('SKIN'),
                    'THROAT' => $this->input->post('THROAT'),
                    'test_inserted_id' => $test_inserted_id
                );
                $last_id = $this->Common_model->saveData('report_skin_scraping', $insert_data);

                $this->zend->load('Zend/Barcode');
                $image_file = Zend_Barcode::draw('code128', 'image', array('text' => 'SKI' . sprintf('%d', $record_id)), array());
                imagejpeg($image_file, "./assets/img/barcode/SKI$record_id.jpg");

                // redirect('/Test_result/show_report/' . $test_inserted_id, 'refresh');
                echo $test_inserted_id;
                exit;
            } elseif ($test_category_id ==  10) {
                $insert_data = array(
                    'patient_id' => $patient_id,
                    'patient_name' => $patient_name,
                    'date' => $date,
                    'age' => $age,
                    'sex' => $sex,
                    'referenced_by' => $ref_by,
                    'report_date' => $report_date,
                    'RA_Test' => $this->input->post('RA_Test'),
                    'CRP' => $this->input->post('CRP'),
                    'CRP_Qualitative_Quantitative' => $this->input->post('CRP_Qualitative_Quantitative'),
                    'HBsAg' => $this->input->post('HBsAg'),
                    'VDRL' => $this->input->post('VDRL'),
                    'Blood_group' => $this->input->post('Blood_group'),
                    'Blood_group1' => $this->input->post('Blood_group1'),
                    'Widal_Test' => $this->input->post('Widal_Test'),
                    'ASO_Titre' => $this->input->post('ASO_Titre'),
                    'Typhoid_Paratyphoid' => $this->input->post('Typhoid_Paratyphoid'),
                    'Brucellosis' => $this->input->post('Brucellosis'),
                    'Typhus_Fever' => $this->input->post('Typhus_Fever'),
                    'test_inserted_id' => $test_inserted_id,
                    'HBsAg_con' => $this->input->post('HBsAg_con'),
                    'HBsAg_elisa' => $this->input->post('HBsAg_elisa'),
                    'HBsAg_screening' => $this->input->post('HBsAg_screening'),
                    'TPHA' => $this->input->post('TPHA'),
                    'Aldehyde' => $this->input->post('Aldehyde'),
                    'Typhoid' => $this->input->post('Typhoid'),
                    'TB' => $this->input->post('TB'),
                    'Failaria' => $this->input->post('Failaria'),
                    'Kala_Azar' => $this->input->post('Kala_Azar'),
                    'Malaria' => $this->input->post('Malaria'),
                    'HIV' => $this->input->post('HIV'),
                    'syphilis_screening' => $this->input->post('syphilis_screening'),
                    'pregnancy_test' => $this->input->post('pregnancy_test'),
                    'HCV' => $this->input->post('HCV'),
                    'Dengu_ns1' => $this->input->post('Dengu_ns1'),
                    'Dengu_igg_igm' => $this->input->post('Dengu_igg_igm'),
                    'Dengu_igg_igm1' => $this->input->post('Dengu_igg_igm1'),
                );
                $last_id = $this->Common_model->saveData('report_serological', $insert_data);



                $this->zend->load('Zend/Barcode');
                $image_file = Zend_Barcode::draw('code128', 'image', array('text' => 'SER' . sprintf('%d', $test_category_id)), array());
                imagejpeg($image_file, "./assets/img/barcode/SER$test_category_id.jpg");

                // redirect('/Test_result/show_report/' . $test_inserted_id, 'refresh');
                echo $test_inserted_id;
                exit;
            } elseif ($test_category_id ==  11) {
                $input = $_POST ; 
                $input['test_inserted_id'] = $test_inserted_id ;
                unset($input['duty_doctor_id']);
                unset($input['duty_staff_id']);
                unset($input['duty_staff_id2']);
                unset($input['age']);
                unset($input['sex']);
                unset($input['ref_by']);
                unset($input['product_id']);
                unset($input['quantity']);
                unset($input['unit_price']);
                unset($input['total_price']);
                unset($input['unit_price']);
                unset($input['unit_price']);
                unset($input['unit_price']);
                //var_dump($input) ;
                $last_id = $this->Common_model->saveData('report_ultra_usg', $input);
                $this->zend->load('Zend/Barcode');
                $image_file = Zend_Barcode::draw('code128', 'image', array('text' => 'SER' . sprintf('%d', $test_category_id)), array());
                imagejpeg($image_file, "./assets/img/barcode/SER$test_category_id.jpg");

                // redirect('/Test_result/show_report/' . $test_inserted_id, 'refresh');
                echo $test_inserted_id;
                exit;
            } elseif ($test_category_id ==  19) {
                $input = $_POST ; 
                $input['test_inserted_id'] = $test_inserted_id ;
                unset($input['duty_doctor_id']);
                unset($input['duty_staff_id']);
                unset($input['duty_staff_id2']);
                unset($input['age']);
                unset($input['sex']);
                unset($input['ref_by']);
                unset($input['product_id']);
                unset($input['quantity']);
                unset($input['unit_price']);
                unset($input['total_price']);
                unset($input['unit_price']);
                unset($input['unit_price']);
                unset($input['unit_price']);
                //var_dump($input) ;
                $last_id = $this->Common_model->saveData('report_echo_cardiogram', $input);
                $this->zend->load('Zend/Barcode');
                $image_file = Zend_Barcode::draw('code128', 'image', array('text' => 'SER' . sprintf('%d', $test_category_id)), array());
                imagejpeg($image_file, "./assets/img/barcode/SER$test_category_id.jpg");

                // redirect('/Test_result/show_report/' . $test_inserted_id, 'refresh');
                echo $test_inserted_id;
                exit;
            } else {
                echo $test_inserted_id;
                exit;
            }
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }


    public function get_test_form()
    {
        $date = $this->input->post('date');
        $patient_id = $this->input->post('patient_id');
        $test_id = $this->input->post('test_id');

        $test = $this->Common_model->findById('test_name', array('record_id' => $test_id));
        $test_category_id = isset($test) ? $test->test_category_id : 0;
        $test_name = isset($test) ? $test->test_name : 0;

        $test_category = $this->Common_model->findById('test_category', array('record_id' => $test_category_id));

        $where = array();
        $where['date'] = $date;
        $where['patient_id'] = $patient_id;
        $where['test_category'] = isset($test_category) ? $test_category->test_category : '';
        $where['test_name'] = $test_name;

        $data['test_name'] = $test_name;

        $result = $this->Common_model->findById('test_result', $where);

        if (isset($result)) {
            $this->load->view('admin/test_result/default_result');
        } elseif ($test_category_id == 1) {
            $data['value'] = $this->Common_model->findFirstOrLast('report_haematology', array(), 'record_id', 'desc');
            $this->load->view('admin/Test/haematology', $data);
        } elseif ($test_category_id == 2) {
            $data['value'] = $this->Common_model->findFirstOrLast('report_biochemistry', array(), 'record_id', 'desc');
            $this->load->view('admin/Test/biochemistry', $data);
        } elseif ($test_category_id == 3) {
            $data['value'] = $this->Common_model->findFirstOrLast('report_immunology', array(), 'record_id', 'desc');
            $this->load->view('admin/Test/IMMUNOLOGY', $data);
        } elseif ($test_category_id == 4) {
            $data['value'] = $this->Common_model->findFirstOrLast('report_mt', array(), 'record_id', 'desc');
            $this->load->view('admin/Test/MT', $data);
        } elseif ($test_category_id == 5) {
            $data['value'] = $this->Common_model->findFirstOrLast('report_urinerme', array(), 'record_id', 'desc');
            $this->load->view('admin/Test/Urine_RME', $data);
        } elseif ($test_category_id == 6) {
            $data['value'] = $this->Common_model->findFirstOrLast('report_stool_rme', array(), 'record_id', 'desc');
            $this->load->view('admin/Test/Stool_RME', $data);
        } elseif ($test_category_id == 7) {
            $data['value'] = $this->Common_model->findFirstOrLast('report_cross_matching', array(), 'record_id', 'desc');
            $this->load->view('admin/Test/Cross_matching', $data);
        } elseif ($test_category_id == 8) {
            $data['value'] = $this->Common_model->findFirstOrLast('report_semen_analysis_report', array(), 'record_id', 'desc');
            $this->load->view('admin/Test/Semen_Analysis_Report', $data);
        } elseif ($test_category_id == 9) {
            $data['value'] = $this->Common_model->findFirstOrLast('report_skin_scraping', array(), 'record_id', 'desc');
            $this->load->view('admin/Test/Skin_Scraping_Report', $data);
        } elseif ($test_category_id == 10) {
            $data['value'] = $this->Common_model->findFirstOrLast('report_serological', array(), 'record_id', 'desc');
            $this->load->view('admin/Test/Serological_Test_Report', $data);
        } elseif ($test_category_id == 11) {
            $data['value'] = $this->Common_model->findFirstOrLast('report_ultra_usg', array(), 'record_id', 'desc');
            $this->load->view('admin/Test/ultra_usg', $data);
        } elseif ($test_category_id == 19) {
            $data['value'] = $this->Common_model->findFirstOrLast('report_echo_cardiogram', array(), 'record_id', 'desc');
            $this->load->view('admin/Test/echo_cardiogram', $data);
        }else {
            $this->load->view('admin/test_result/attached_file', $data);
        }
    }

    public function get_test_detailed_form(){
        $date = $this->input->post('date');
        $invoice_id = $this->input->post('invoice_id');
        $patient_id = $this->input->post('patient_id');
        $testIdArr = $this->input->post('test_id');

        $testDetailsArr = [];
        $i = 0;
        foreach($testIdArr as $test_id){
            $testDetails = $this->Common_model->getTestDetails($test_id);
            $test_category_id = isset($testDetails->test_category_id) ? $testDetails->test_category_id : 0;
            $test_name = isset($testDetails) ? $testDetails->test_name : 0;

            $where = array();
            $where['collection_date'] = $date;
            $where['invoice_id'] = $invoice_id;
            $where['patient_id'] = $patient_id;
            $where['test_category_id'] = $testDetails->test_category_id;
            $where['test_name_id'] = $test_id;

            $result = $this->Common_model
                           ->checkIfTestExists($date, 
                                               $invoice_id, 
                                               $patient_id,
                                               $testDetails->test_category_id,
                                               $test_id);


            $testDetailsArr[$i] = new stdClass;
            $testDetailsArr[$i]->flag = true;
            $testDetailsArr[$i]->details = $testDetails;
            if(empty($result)) {
                $testDetailsArr[$i]->flag = false;
                $testFields = $this->Common_model->findAll('test_fields', array('test_name_id' => $test_id), "priority","asc");
                $testDetailsArr[$i]->testFields = $testFields;
                if($testDetails->test_category_id == 5){
                    
                    $previousSimilarData[$test_id] = $this->Common_model->getPreviousSimilarResult($testDetails->test_category_id, $test_id);
                }
            }
            $i++;
        }

        $data['testDetailsData'] = $testDetailsArr;
        $data['previousSimilarData'] = $previousSimilarData;

        $this->load->view('admin/Test/new/report_input_form', $data);

        // ddd($testDetailsArr);

        // if(!empty($result)) {
        //     $this->load->view('admin/test_result/default_result');
        // }else{
        //     $testFields = $this->Common_model->findAll('test_fields', array('test_name_id' => $test_id), [], 'record_id');
        //     $data['testFields'] = $testFields;

        //     // ddd($data);
        //     $this->load->view('admin/Test/new/report_input_form', $data);
        //     // exit;
        // }

        // if (isset($result)) {
        //     $this->load->view('admin/test_result/default_result');
        // } elseif ($test_category_id == 1) {
        //     $data['value'] = $this->Common_model->findFirstOrLast('report_haematology', array(), 'record_id', 'desc');
        //     $this->load->view('admin/Test/haematology', $data);
        // } elseif ($test_category_id == 2) {
        //     $data['value'] = $this->Common_model->findFirstOrLast('report_biochemistry', array(), 'record_id', 'desc');
        //     $this->load->view('admin/Test/biochemistry', $data);
        // } elseif ($test_category_id == 3) {
        //     $data['value'] = $this->Common_model->findFirstOrLast('report_immunology', array(), 'record_id', 'desc');
        //     $this->load->view('admin/Test/IMMUNOLOGY', $data);
        // } elseif ($test_category_id == 4) {
        //     $data['value'] = $this->Common_model->findFirstOrLast('report_mt', array(), 'record_id', 'desc');
        //     $this->load->view('admin/Test/MT', $data);
        // } elseif ($test_category_id == 5) {
        //     $data['value'] = $this->Common_model->findFirstOrLast('report_urinerme', array(), 'record_id', 'desc');
        //     $this->load->view('admin/Test/Urine_RME', $data);
        // } elseif ($test_category_id == 6) {
        //     $data['value'] = $this->Common_model->findFirstOrLast('report_stool_rme', array(), 'record_id', 'desc');
        //     $this->load->view('admin/Test/Stool_RME', $data);
        // } elseif ($test_category_id == 7) {
        //     $data['value'] = $this->Common_model->findFirstOrLast('report_cross_matching', array(), 'record_id', 'desc');
        //     $this->load->view('admin/Test/Cross_matching', $data);
        // } elseif ($test_category_id == 8) {
        //     $data['value'] = $this->Common_model->findFirstOrLast('report_semen_analysis_report', array(), 'record_id', 'desc');
        //     $this->load->view('admin/Test/Semen_Analysis_Report', $data);
        // } elseif ($test_category_id == 9) {
        //     $data['value'] = $this->Common_model->findFirstOrLast('report_skin_scraping', array(), 'record_id', 'desc');
        //     $this->load->view('admin/Test/Skin_Scraping_Report', $data);
        // } elseif ($test_category_id == 10) {
        //     $data['value'] = $this->Common_model->findFirstOrLast('report_serological', array(), 'record_id', 'desc');
        //     $this->load->view('admin/Test/Serological_Test_Report', $data);
        // } elseif ($test_category_id == 11) {
        //     $data['value'] = $this->Common_model->findFirstOrLast('report_ultra_usg', array(), 'record_id', 'desc');
        //     $this->load->view('admin/Test/ultra_usg', $data);
        // } elseif ($test_category_id == 19) {
        //     $data['value'] = $this->Common_model->findFirstOrLast('report_echo_cardiogram', array(), 'record_id', 'desc');
        //     $this->load->view('admin/Test/echo_cardiogram', $data);
        // }else {
        //     $this->load->view('admin/test_result/attached_file', $data);
        // }
    }


    // public function show_report($test_id)
    // {
    //     $user_type = $this->session->ses_user_type;
    //     if ($user_type == "admin" || $user_type == "staff") {
    //         $info = $this->Common_model->findById('test_result', array('record_id' => $test_id));
    //         $invoice = $this->Common_model->findById('create_bill', array('record_id' => $info->invoice_id));
    //         $data['invoice_no'] = '<b>Inv.No : </b>' . generate_invoice_no($invoice);
    //         $blank_result = '';
    //         $analyzer = '';
    //         if (isset($info)) {
    //             $data['patient'] = $this->Common_model->findById('patient', array('record_id' => $info->patient_id));
    //             $category = $this->Common_model->findById('test_category', array('record_id' => $info->test_category_id));
    //             //  $analyzer = isset($category)?$category->analyzer:'' ;
    //         }
    //         if ($info->blank_result == 1) {
    //             $blank_result = 'display:none';
    //         } else {
    //             $blank_result = '';
    //         }
    //         $data['analyzer'] = $analyzer;
    //         $data['blank_result'] = $blank_result;
    //         $data['doctor'] = $this->Common_model->findById('doctor', array('record_id' => isset($info) ? $info->duty_doctor_id : 0));
    //         $data['staff'] = $this->Common_model->findById('staff', array('record_id' => isset($info) ? $info->duty_staff_id : 0));
    //         $data['staff2'] = $this->Common_model->findById('staff', array('record_id' => isset($info) ? $info->duty_staff_id2 : 0));

    //         $test_category = isset($info) ? $info->test_category : '';
    //         $test_name = isset($info) ? $info->test_name : '';
    //         $test_category_id = isset($info) ? $info->test_category_id : '';

    //         $data['redirect'] = base_url('test_result');
    //         if ($test_category_id == 11) {
    //             $data['redirect'] = base_url('test_result/ultra');
    //         }
    //         $data['test_id'] = $test_id;
    //         $data['test_name'] = $test_name;
    //         $data['info'] = $info;

    //         if ($test_category_id == 1) {
    //             $data["test_res"] = $this->Common_model->get_allinfo_byid('report_haematology', 'test_inserted_id', $test_id);
    //             $this->load->view('admin/layouts/header');
    //             $this->load->view('admin/test_result/report_haematology_print', $data);
    //             $this->load->view('admin/layouts/footer');
    //         } elseif ($test_category_id ==  2) {
    //             $data["test_res"] = $this->Common_model->get_allinfo_byid('report_biochemistry', 'test_inserted_id', $test_id);
    //             // var_dump($data['info']);die;
    //             $this->load->view('admin/layouts/header');
    //             $this->load->view('admin/test_result/report_biochemistry_print', $data);
    //             $this->load->view('admin/layouts/footer');
    //         } elseif ($test_category_id == 3) {
    //             $data["test_res"] = $this->Common_model->get_allinfo_byid('report_immunology', 'test_inserted_id', $test_id);

    //             $this->load->view('admin/layouts/header');
    //             $this->load->view('admin/test_result/report_IMMUNOLOGY_print', $data);
    //             $this->load->view('admin/layouts/footer');
    //         } elseif ($test_category_id == 4) {
    //             $data["test_res"] = $this->Common_model->get_allinfo_byid('report_mt', 'test_inserted_id', $test_id);

    //             $this->load->view('admin/layouts/header');
    //             $this->load->view('admin/test_result/report_MT_print', $data);
    //             $this->load->view('admin/layouts/footer');
    //         } elseif ($test_category_id ==  5) {
    //             $data["test_res"] = $this->Common_model->get_allinfo_byid('report_urinerme', 'test_inserted_id', $test_id);

    //             $this->load->view('admin/layouts/header');
    //             $this->load->view('admin/test_result/report_UrineRME_print', $data);
    //             $this->load->view('admin/layouts/footer');
    //         } elseif ($test_category_id ==  6) {
    //             $data["test_res"] = $this->Common_model->get_allinfo_byid('report_stool_rme', 'test_inserted_id', $test_id);

    //             $this->load->view('admin/layouts/header');
    //             $this->load->view('admin/test_result/report_stool_rme_print', $data);
    //             $this->load->view('admin/layouts/footer');
    //         } elseif ($test_category_id ==  7) {
    //             $data["test_res"] = $this->Common_model->get_allinfo_byid('report_cross_matching', 'test_inserted_id', $test_id);

    //             $this->load->view('admin/layouts/header');
    //             $this->load->view('admin/test_result/report_cross_matching_print', $data);
    //             $this->load->view('admin/layouts/footer');
    //         } elseif ($test_category_id ==  8) {
    //             $data["test_res"] = $this->Common_model->get_allinfo_byid('report_semen_analysis_report', 'test_inserted_id', $test_id);

    //             $this->load->view('admin/layouts/header');
    //             $this->load->view('admin/test_result/report_semen_analysis_report_print', $data);
    //             $this->load->view('admin/layouts/footer');
    //         } elseif ($test_category_id ==  9) {
    //             $data["test_res"] = $this->Common_model->get_allinfo_byid('report_skin_scraping', 'test_inserted_id', $test_id);

    //             $this->load->view('admin/layouts/header');
    //             $this->load->view('admin/test_result/report_Skin_Scraping_Report_print', $data);
    //             $this->load->view('admin/layouts/footer');
    //         } elseif ($test_category_id ==  10) {
    //             $data["test_res"] = $this->Common_model->get_allinfo_byid('report_serological', 'test_inserted_id', $test_id);

    //             $this->load->view('admin/layouts/header');
    //             $this->load->view('admin/test_result/report_Serological_Test_Report_print', $data);
    //             $this->load->view('admin/layouts/footer');
    //         } elseif ($test_category_id ==  11) {
    //             $data["test_res"] = $this->Common_model->get_allinfo_byid('report_ultra_usg', 'test_inserted_id', $test_id);

    //             $this->load->view('admin/layouts/header');
    //             $this->load->view('admin/test_result/report_ultra_usg_print', $data);
    //             $this->load->view('admin/layouts/footer');
    //         }elseif ($test_category_id ==  19) {
    //             $data["test_res"] = $this->Common_model->get_allinfo_byid('report_echo_cardiogram', 'test_inserted_id', $test_id);
    //             //var_dump($data['test_res']) ; die ;
    //             $this->load->view('admin/layouts/header');
    //             $this->load->view('admin/test_result/report_echo_cardiogram_print', $data);
    //             $this->load->view('admin/layouts/footer');
    //         } else {

    //             $this->load->view('admin/layouts/header');
    //             $this->load->view('admin/test_result/report_attached_file', $data);
    //             $this->load->view('admin/layouts/footer');
    //         }
    //     } else {
    //         $data['wrong_msg'] = "";
    //         $this->load->view('website/login_check', $data);
    //     }
    // }

    // public function show_report($report_id)
    // {
    //     $user_type = $this->session->ses_user_type;
    //     if ($user_type == "admin" || $user_type == "staff") {

    //         $testDetails = $this->Common_model->getTestReportDetails($report_id);
    //         $patientData = $this->Common_model->findById('patient', ['record_id'=>$testDetails->patient_id]);

    //         $data['testDetails'] = $testDetails;
    //         $data['patientData'] = $patientData;
    //         $data['redirect'] = base_url('test_result');
    //         $data['test_id'] = $report_id;

    //         $this->load->view('admin/layouts/header');
    //         $this->load->view('admin/test_result/report_print_new', $data);
    //         $this->load->view('admin/layouts/footer');

    //     } else {
    //         $data['wrong_msg'] = "";
    //         $this->load->view('website/login_check', $data);
    //     }
    // }

    public function show_report($report_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {

            $testDetails = $this->Common_model->getTestReportDetails($report_id);
            $patientData = $this->Common_model->findById('patient', ['record_id'=>$testDetails->patient_id]);
            $test_name_id = $this->Common_model->findById('test_report_names', ['test_report_id'=>$report_id]);
            $dutyDoctor = $this->Common_model->findById('report_signatures', ['id'=>$testDetails->duty_doctor_id]);
            $dutyStaff = $this->Common_model->findById('report_signatures', ['id'=>$testDetails->duty_staff_id]);
            $dutyStaff2 = $this->Common_model->findById('report_signatures', ['id'=>$testDetails->duty_staff_id2]);

            
            $testDetails->dutyStaff     =  $dutyStaff;
            $testDetails->dutyStaff2    =  $dutyStaff2;
            $testDetails->dutyDoctor    =  $dutyDoctor;
            

            $data['testDetails'] = $testDetails;
            $data['patientData'] = $patientData;
            $data['redirect'] = base_url('test_result');

            // ddd($data);

            $this->load->view('admin/layouts/header');
            if($test_name_id->test_name_id == 48){
                //$this->load->view('admin/test_result/report_print_urine', $data);
				$this->load->view('admin/test_result/report_print_new', $data);
            }else{
            $this->load->view('admin/test_result/report_print_new', $data);
        }
            $this->load->view('admin/layouts/footer');

        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function today_patient_test_categories(){
        $invoice_id = $this->input->post('invoice_id');
        $patient_id = $this->input->post('patient_id');
        $date = $this->input->post('date');

        $testCategories = $this->Common_model->getInvoiceTestCategories($invoice_id, $patient_id, $date);
        $option = "<option value=>--Select--</option>";

        foreach($testCategories as $category){
            $option .= "<option value='$category->record_id' >$category->test_category</option>";
        }
        $data = array('option' => $option);
        echo json_encode($data);
    }

    public function today_patient_test()
    {
        $invoice_id = $this->input->post('invoice_id');
        $patient_id = $this->input->post('patient_id');
        $date = $this->input->post('date');
        $test_category = $this->input->post('test_category');

        $where = array();
        $where['invoice_no'] = $invoice_id;
        $where["date"] = $date;
        $where["patient_id"] = $patient_id;
        $where["test_category_id"] = $test_category;
        //var_dump($invoice_id) ; die ;
        $result = $this->Common_model->findAll('sales_test', $where, 'record_id', 'asc');
        $option = "";
        $doctor_name = "";
        $doctor_id = 0;
        $invoice_no = 0;
        $test = '';
        $category = '';
        foreach ($result as $info) {
            $invoice_no = $info->invoice_no;
            $test_category = $this->Common_model->findById('test_category', array('record_id' => $info->test_category_id));
            $test_name = $this->Common_model->findById('test_name', array('record_id' => $info->test_id));
            $category = isset($test_category) ? $test_category->test_category : '';
            $test = isset($test_name) ? $test_name->test_name : '';
            $option .= "<option value='$info->test_id' data-invoice_id='$info->invoice_no' data-sales_test_id='$info->record_id' data-doctor_id='$info->doctor_id' data-category_id='$info->test_category_id'>$test_name->record_id - $test - $category</option>";
        }
        if ($invoice_id) {
            $invoice = $this->Common_model->findById('create_bill', array('record_id' => $invoice_id));
            $doctor = $this->Common_model->findById('doctor', array('record_id' => isset($invoice) ? $invoice->doctor_id : 0));
            $designation = $this->Common_model->findById('designation', array('record_id' => isset($doctor) ? $doctor->designation_id : 0));
            $designation_name = isset($designation) ? ' - ' . $designation->designation : '';
            $doctor_name = isset($doctor) ? $doctor->name . $designation_name : '';
            /* var_dump($invoice->referred_doctor) ; die ;
            if(isset($invoice->referred_doctor)){
                $doctor_name =  $invoice->referred_doctor ; 
            }*/
        }
        $data = array('option' => $option, 'doctor_name' => $doctor_name);
        echo json_encode($data);
    }
    public function today_generated_invoice()
    {
        $invoice_id = $this->input->post('invoice_id');
        $patient_id = $this->input->post('patient_id');
        $date = $this->input->post('date');
        $today = $date;
        $where = array();
        $where['date'] = $today;
        $where['type'] = 'Test Invoice';
        $invoice_list = $this->Common_model->findAll('create_bill', $where, 'record_id', 'desc');
        $option = "<option value=>--Select--</option>";
        $doctor_name = "";
        foreach ($invoice_list as $key1 => $value1) {
            $patient = $this->Common_model->findById('patient', array('record_id' => $value1->patient_id));
            $patient_name = isset($patient) ? $patient->name . "[$patient->record_id]" : "";
            $option .= '<option value=' . $value1->record_id . ' data-patient_id=' . $value1->patient_id . ' data-patient_age=' . $patient->age . ' data-patient_gender=' . $patient->gender . ' data-patient_mobile=' . $patient->mobile . '>
            ' . generate_invoice_no($value1) . " - " . $patient_name . '</option>';
        }
        echo $option;
        exit;
    }
    public function delete($id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            $test_result = $this->Common_model->findById('test_reports', array('record_id' => $id));

            $res1 = $this->Common_model->delete_info('record_id', $id, 'test_reports');
            $res2 = $this->Common_model->delete_info('test_report_id', $id, 'test_report_names');
            $res3 = $this->Common_model->delete_info('test_report_id', $id, 'test_report_fields');

            if($res1 && $res2 && $res3){
                $this->session->set_flashdata('message', DELETE_MSG);
            }else{
                $this->session->set_flashdata('message', DELETE_ERROR_MSG);
            }
            redirect('test_result', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }


    public function edit_report($report_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            
            $testDetails = $this->Common_model->getTestReportDetails($report_id);
            $patientData = $this->Common_model->findById('patient', ['record_id'=>$testDetails->patient_id]);

            if($testDetails->doctor_id){
                $options = array(
                    'joins' => array(
                        array(
                            'table' => 'designation',
                            'condition' => 'designation.record_id = doctor.designation_id',
                            'jointype' => 'LEFT'
                        ),
                        
                    ),
                    'select' => '*',
                    'where' => array(
                        'doctor.record_id' => $testDetails->doctor_id,
                    ),
                   
                );
        
                $doctor_info = $this->Common_model->commonJoinsRow("doctor", $options);
                $data['designation'] = $doctor_info->designation;
            }else{
                $data['designation'] = "";
            }

            $data['title'] = 'Test Result Edit';
            $data['page_title'] = 'Test Result Edit';
            $data['info_header'] = 'Test Result Edit';
            $data['duty_doctor_id'] = isset($last_result) ? $last_result->duty_doctor_id : 0;
            $data['duty_staff_id'] = isset($last_result) ? $last_result->duty_staff_id : 0;
            $data['duty_staff_id2'] = isset($last_result) ? $last_result->duty_staff_id2 : 0;
            $data['testDetails'] = $testDetails;
            $data['patientData'] = $patientData;
            $data['redirect'] = base_url('test_result');
            $data['test_id'] = $report_id;


            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_result/edit_report', $data);
            $this->load->view('admin/layouts/footer');

        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }


    public function update()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $update_id = $this->input->post('test_report_id');
            $duty_doctor_id = $this->input->post('duty_doctor_id');
            $duty_staff_id = $this->input->post('duty_staff_id');
            $duty_staff_id2 = $this->input->post('duty_staff_id2');
            $testvalues = $this->input->post('testvalue');
            
            

            $testDetails = $this->Common_model->getTestDetails($test_id);

            $testReportData = array(
                'duty_doctor_id' => $duty_doctor_id,
                'duty_staff_id' => $duty_staff_id,
                'duty_staff_id2' => $duty_staff_id2,
                'comments' => $this->input->post('comments')
            );

           

            $update = $this->Common_model->updateData('test_reports', $testReportData, array('record_id'=>$update_id));

            if (!empty($testvalues) && is_array($testvalues)) {
                
                foreach ($testvalues as $test_field_id => $value) {
                    $update_item = $this->Common_model->updateData('test_report_fields', array('value'=>$value), array('test_report_id'=>$update_id, 'test_field_id'=>$test_field_id));
                }
            }

                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                    redirect("test_result/show_report/".$update_id);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                     redirect("crud/previousPage");
                }

    } else {
        $data['wrong_msg'] = "";
        $this->load->view('website/login_check', $data);
    }
}

public function blank_report_list()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Blank Test Result';
            $data['page_title'] = 'Blank Test Result';
            $data['info_header'] = 'Blank Test Result';
            $data['test_names'] = $this->Common_model->findAll('test_name', array(), 'record_id', 'asc');
            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $test_id = $this->input->get('test_id');

            if (!isset($from_date) && !isset($to_date) && !isset($test_id)) {
                $from_date = $to_date = date('Y-m-d');
            }

            $where = array();
            if (!admin()) {
                $where['show_hide'] = 'Show';
            }

            if ($test_id) $where['test_id'] = $test_id;
            if (!empty($from_date) && !empty($to_date)) {
                $where['date >= '] = $from_date;
                $where['date <= '] = $to_date;
            } elseif (!empty($from_date) && empty($to_date)) {
                $where['date'] = $from_date;
            } elseif (empty($from_date) && !empty($to_date)) {
                $where['date'] = $to_date;
            }

            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;
            $data['test_id'] = $test_id;
            //$data['all_test_result'] = $this->Common_model->getAllReports($from_date, $to_date, $test_id);
            $data['all_test_result'] = $this->Common_model->getAllReportsBlank($from_date, $to_date, $test_id);
            // ddd($data['all_test_result']);
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_result/blank_report_list', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function show_blank_report($report_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {

            $testDetails = $this->Common_model->getTestReportDetails($report_id);
            $patientData = $this->Common_model->findById('patient', ['record_id'=>$testDetails->patient_id]);

            if($testDetails->doctor_id){
                $options = array(
                    'joins' => array(
                        array(
                            'table' => 'designation',
                            'condition' => 'designation.record_id = doctor.designation_id',
                            'jointype' => 'LEFT'
                        ),
                        
                    ),
                    'select' => '*',
                    'where' => array(
                        'doctor.record_id' => $testDetails->doctor_id,
                    ),
                   
                );
        
                $doctor_info = $this->Common_model->commonJoinsRow("doctor", $options);
                $data['designation'] = $doctor_info->designation;
            }else{
                $data['designation'] = "";
            }

            $data['testDetails'] = $testDetails;
            $data['patientData'] = $patientData;
            $data['redirect'] = base_url('test_result/blank_report_list');
            $data['test_id'] = $report_id;
            $data['print_type'] = "blank";

            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_result/report_print_blank', $data);
            $this->load->view('admin/layouts/footer');

        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function get_test_detail()
    {
        $report_id = $this->input->post('id');
        $testDetails = $this->Common_model->getTestReportDetails($report_id);
        $patientData = $this->Common_model->findById('patient', ['record_id'=>$testDetails->patient_id]);
        $test_name_id = $this->Common_model->findById('test_report_names', ['test_report_id'=>$report_id]);
        $data['testDetails'] = $testDetails;
        $data['patientData'] = $patientData;
       
		$this->load->view('admin/test_result/test_report_detail', $data);
    }

    public function test_result_status($report_id)
    {
       $test_data =  array(
        'status' => 'Approved', 
        'approved_by' => $this->session->userData('ses_record_id'), 
        'approved_at' => date('Y-m-d H:i:s'));
     $this->Common_model->updateData('test_reports', $test_data, array('record_id'=>$report_id));
     redirect($_SERVER['HTTP_REFERER']);
    }

public function generate_barcode_image($code_no) {
    $number = str_pad($code_no, 6, '0', STR_PAD_LEFT);
    $this->zend->load('Zend/Barcode');
    Zend_Barcode::render('code128', 'image', array('text'=>$number, 'drawText' => false, 'barHeight' => 30, 'withQuietZones' => false), array());
}
    
}
