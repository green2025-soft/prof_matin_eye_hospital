<?php

defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Profit_distribution extends MY_Controller
{
    
    public function __construct()
    {
        parent::__construct();
        $this->title    = 'Profit Distribution';
        $this->bUrl     = 'profit_distribution';

        $this->loadModel('ProfitDistribution_model');
        $this->load->model(['ProfitDistributionDetails_model'=> 'pddModel', 'PartnerInvestment_model'=>'partnerModel']);
    }
    public function index()
    {
        $this->data = [
            'title'     => 'All '.$this->title,
            'values'    => $this->model->with('details')->with('details.partner')->order_by('id', 'DESC')->all()
        ];
        // dd($this->data);
        $this->render('admin/profit_distribution/index');
    }

    public function create()
    {
        $this->data = [
            'title'         => 'Create '.$this->title,
            'partnersa'     => $this->partnerModel->all()
        ];
        $this->render('admin/profit_distribution/create');
    }

    public function edit($record_id)
    {
         $this->data = [
            'title'     => 'Edit '.$this->title,
            'value'     => $this->model->find($record_id),
            'values'    => $this->pddModel->where('distribution_id', $record_id)->all(),
            'partnersa' => $this->partnerModel->all()
        ];
        $this->render('admin/profit_distribution/create');

    }

    public function saveOrUpdate()
    {
            $input = $this->input->post();
            $update_id = $input['update_id'];
            $this->db->trans_start();
            $data   = $this->model->filterTableData($input);
            $id     = $this->model->updateOrInsert($data, $update_id);
            $this->pddModel->getDelete($id, 'distribution_id');
            

            $partner_ids = $input['partner_id'];
            $rows = [];
            foreach($partner_ids as $key=>$value){
                $rows[] = [
                    'distribution_id'   => $id,
                    'partner_id'        => $value,
                    'profit_percentage' => $input['profit_percentage'][$key],
                    'investment'        => $input['investment'][$key],
                    'profit_amount'     => $input['partner_profit_amount'][$key],
                ];
            }
            $this->pddModel->insertBatch($rows);
            $this->db->trans_complete();
            
            $this->crudAlertMessage($update_id, $this->bUrl);
    }


    public function delete($id)
    {
        $this->model->getDelete($id);
        $this->pddModel->getDelete($id, 'distribution_id');
        $this->crudAlertMessage($id, $this->bUrl, true);
    }
    
}
