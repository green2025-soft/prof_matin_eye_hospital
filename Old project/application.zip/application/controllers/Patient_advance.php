<?php

/**
 * 
 */
class Patient_advance extends CI_Controller
{
	
	public function __construct()
	{
		parent::__construct();
	}

	public function index(){
		$data['title'] = 'Patient Advance List';
        $data['page_title'] = 'Patient Advance List';
        $data['info_header'] = 'Patient Advance Liste';
        $where = array() ;
      //  $where['patient_status'] = 'New';
	  if (!admin()) {
		$where['show_hide'] = 'Show';
	  }
        $data['values'] = $this->Common_model->findAll('admission_advance_invoice',$where,'record_id','desc');
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/patient_advance/index',$data);
		$this->load->view('admin/layouts/footer');			
	}
	public function create(){
		$data['title'] = 'Patient Advance';
        $data['page_title'] = 'Patient Advance';
        $data['info_header'] = '';

		$where = array() ;
		$data['admissionInvoice'] = $this->Common_model->findAll("admission_fee_invoice",$where,"record_id","desc");

		$this->load->view('admin/layouts/header');
		$this->load->view('admin/patient_advance/create',$data);
		$this->load->view('admin/layouts/footer');			
	}
	public function edit($record_id){
		$data['title'] = 'Edit Patient Advance';
        $data['page_title'] = 'Edit Patient Advance';
        $data['info_header'] = '';
        $data['value'] = $this->Common_model->findById('admission_advance_invoice',array('record_id'=>$record_id));
		$where = array() ;
		$where['record_id'] = $data['value']->admission_id ;
		$data['admissionInvoice'] = $this->Common_model->findAll("admission_fee_invoice",$where,"record_id","desc");
        $data['patient'] = $this->Common_model->findById('patient',array('record_id'=>$data['value']->patient_id));
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/patient_advance/create',$data);
		$this->load->view('admin/layouts/footer');			
	}
	public function saveOrUpdate(){
		$input = $_POST ;
		$update_id = $input['update_id'] ; 
		unset($input['update_id']);
		$date  = $input['advance_date'];
		$prefix = 'Adv'. date("Ymd",strtotime($date));
        $maxInvoice = $this->Common_model->findMax('create_bill',array('prefix'=>$prefix,'type'=>'AdmissionAdvance'),'invoice_no');
        $invoice_no = isset($maxInvoice)?$maxInvoice->invoice_no + 1 : 1 ;
        $invoice_data = array(
            'date' => $date,
            'prefix' => $prefix,
            'invoice_no' => $invoice_no,
            'type' => 'AdmissionAdvance',
            'particular' => "Admission Advance",
            'patient_id' => $input['patient_id'],
            'amount' => $input['advance_amount'],
            'discount' => 0,
            'sub_total' => $input['advance_amount'],
            'paid' => $input['advance_amount'],
            'due' => 0,
            'advance' => 0
        );
		
		if($update_id == 0 || empty($update_id)){     
                $invoice_id = $this->Common_model->saveData('create_bill', $invoice_data);
                $input['invoice_id'] = $invoice_id ;
                $input['prefix'] = $prefix ;
                $input['invoice_no'] = $invoice_no ;
                $insert = $this->Common_model->saveData('admission_advance_invoice', $input);
                $update_id = $insert ;
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $admission_invoice = $this->Common_model->findById('admission_advance_invoice',array('record_id'=>$update_id));
                if($date == $admission_invoice->advance_date){
                    $bill = $this->Common_model->findById('create_bill',array('record_id'=>$admission_invoice->invoice_id));
                    $invoice_data['invoice_no'] = $bill->invoice_no ;
                    $input['invoice_no'] = $admission_invoice->invoice_no ;
                }
                $this->Common_model->updateData('create_bill', $invoice_data,array('record_id'=>$admission_invoice->invoice_id));
                $update = $this->Common_model->updateData('admission_advance_invoice', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
		redirect("patient_advance/view2/$update_id");
            }
		redirect("patient_advance/view/$update_id");
	}

	public function view($record_id){
		$data['title'] = 'View Patient Advance';
        $data['page_title'] = 'View Patient Advance';
        $data['info_header'] = '';
        $data['redirect'] =  base_url('patient_advance/create');
        $data['value'] = $this->Common_model->findById('admission_advance_invoice',array('record_id'=>$record_id));
        $data['value']->date = $data['value']->advance_date;
        $data['patient'] = $this->Common_model->findById('patient',array('record_id'=>$data['value']->patient_id));
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/patient_advance/view',$data);
		$this->load->view('admin/layouts/footer');			
	}
	public function view2($record_id){
		$data['title'] = 'View Patient Advance';
        $data['page_title'] = 'View Patient Advance';
        $data['info_header'] = '';
        $data['redirect'] =  base_url('patient_advance');
        $data['value'] = $this->Common_model->findById('admission_advance_invoice',array('record_id'=>$record_id));
        $data['value']->date = $data['value']->advance_date;
        $data['patient'] = $this->Common_model->findById('patient',array('record_id'=>$data['value']->patient_id));
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/patient_advance/view',$data);
		$this->load->view('admin/layouts/footer');			
	}

	public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            $admission_advance_invoice = $this->Common_model->findById('admission_advance_invoice',array('record_id'=>$id));
            if($this->Common_model->delete_info('record_id', $id, 'admission_advance_invoice')){
                $this->Common_model->delete_info('record_id', $admission_advance_invoice->invoice_id, 'create_bill') ;
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
            redirect('patient_advance', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

	public function getOperationName(){
		$category_id = $this->input->post('category_id');
		$names = $this->Common_model->get_all_info_by_array('operation_name',['category_id' => $category_id]);
        $data = "<option value=''>-- Select --</option>";
      	foreach($names as $name){
      	$data .= "<option value='$name->record_id'>$name->operation_name</option>";	
      	}                              
		echo json_encode($data);
	}
	public function getOperationPrice(){
		$operation_id = $this->input->post('operation_id');
		$patient_id = $this->input->post('patient_id');

		$operationsPrices = 0 ;
		$advanceAmount = 0 ;

		$operation= $this->Common_model->findById('operation_name',['record_id' => $operation_id]);
		//var_dump($operation_id);die;
		$operationsPrices = isset($operation)?$operation->rate:0 ;
		$where['patient_id'] = $patient_id ;
		//$where['operation_id'] = $operation_id ;

		$advance_amount = $this->Common_model->calCulateSum('admission_advance_invoice',$where,'advance_amount');


		$paid_amount = $this->Common_model->calCulateSum('operation_details',$where,'advance_amount');
		$return_amount = $this->Common_model->calCulateSum('operation_details',$where,'return_amount');


		$patientPaidAmount = $paid_amount + $return_amount ;

		$balannce = $advance_amount - $patientPaidAmount ;

		$data = array(
			'rate'=> $operationsPrices,
			'advance_fee'=> $balannce,
		);
		echo json_encode($data);
	}
	public function get_admissiom(){
		$record_id  = $this->input->post('admission_id');
		$admission = $this->Common_model->findById('admission_advance_invoice',array('record_id'=>$record_id));
		$patient = $this->Common_model->findById('patient',array('record_id'=>$admission->patient_id));
		$admission->patient = $patient ;
		echo json_encode($admission);
		exit;
	}
}
?>