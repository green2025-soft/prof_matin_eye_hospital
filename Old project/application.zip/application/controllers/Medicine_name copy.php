<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Medicine_name extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('upload');
        $this->load->library('pagination');
    }

    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff" || $user_type == "doctor") {
            $data['title'] = 'Medicine Name';
            $data['page_title'] = 'Medicine Name';
            $data['info_header'] = 'All Medicine Name';
            $generic_name_id = $this->input->get('generic_name_id');
            $product_id = $this->input->get('product_id');
            $page = (isset($_GET['page']) && $_GET['page'] > 1)  ? $_GET['page']  : 1;
            $limit = 100;
            $offset = ($page - 1) * $limit;

            $where = array() ;
            $where['type'] = 'Medicine';
            $where['warehouse'] = 'Pharmacy';

            if(intval($product_id) > 0){
                $where['record_id'] = $product_id;
            }
            if(intval($generic_name_id) > 0){
                $where['generic_id'] = $generic_name_id;
            }

            $totalProducts = $this->Common_model->countAll('drug_medicine',$where);

            $data['pagination']['pages'] = ceil($totalProducts / $limit);
            $data['pagination']['current_page'] = $page;
            $data['page'] = $page;
            $data['limit'] = $limit;
            $data['product_id'] = $product_id;
            $data['generic_name_id'] = $generic_name_id;
            // ddd($page);

            $data['values'] = $this->Common_model->getAllPaginatedMedicines($generic_name_id, $product_id, $limit, $offset);

            $this->load->view('admin/layouts/header');
            $this->load->view('admin/medicine_name/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function create() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff" || $user_type == "doctor") {
            $data['title'] = 'Create Medicine/Product Name';
            $data['page_title'] = 'Create Medicine/Product Name';
            $data['info_header'] = '';
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/medicine_name/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function edit($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff" || $user_type == "doctor") {
            $data['title'] = 'Create Medicine/Product Name';
            $data['page_title'] = 'Create Medicine/Product Name';
            $data['info_header'] = '';
            $data['value'] = $this->Common_model->findById('drug_medicine',array('record_id'=>$record_id));
            // ddd($data['value']);
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/medicine_name/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff" || $user_type == "doctor") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            unset($input['update_id']);
            // ddd($input);

            if($update_id == 0 || empty($update_id)){       

                $getRow = $this->Common_model->findById('drug_medicine',array('generic_id'=>$input['generic_id'], 'dosage_id'=>$input['dosage_id'], 'manufacturer_id' => $input['manufacturer_id'], 'brand_name'=>$input['brand_name']));
                if(isset($getRow)){
                    $this->session->set_flashdata('message', EXIST_MSG);
                    redirect('medicine_name/create', 'refresh');
                }
                
                $insert = $this->Common_model->saveData('drug_medicine', $input);
                $record_id = $insert;
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                
                $update = $this->Common_model->updateData('drug_medicine', $input, array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
                //redirect('medicine_name', 'refresh');
                redirect('medicine_name', 'refresh');
            }
            
            redirect('medicine_name/create', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff" || $user_type == "doctor") {
            if($this->Common_model->delete_info('record_id', $id, 'drug_medicine')){
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
           // redirect("crud/previousPage");
            redirect('medicine_name', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
