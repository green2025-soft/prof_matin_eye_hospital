<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Department extends CI_Controller {

    static $library   = array('upload');

    public function __construct() {
        parent::__construct();
        $this->load->library(self::$library);
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Department';
            $data['page_title'] = 'Department';
            $data['info_header'] = 'All Department';
            $data['values'] = $this->Common_model->findAll('department',array(),'department','asc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/department/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            $published = $this->input->post("published") ;
            if(isset($published)){
                $input['published'] = "Yes";
            }else{
                $input['published'] = "No";
            }
            unset($input['update_id']);
            $department = $input['department'];
            $config['upload_path']      = 'assets/img/department/';
            $config['allowed_types']    = '*';
            $config['max_size']         = '0';
            //$config['file_name']      = time(); 
            $file_field                 = "photo";
            $this->upload->initialize($config);

            if($update_id == 0 || empty($update_id)){       
                $getRow = $this->Common_model->findById('department',array('department'=>$department));
                if(isset($getRow)){
                    $this->session->set_flashdata('message', EXIST_MSG);
                    redirect('department', 'refresh');
                }

                if(!empty($_FILES[$file_field]["name"])){
                    if($this->upload->do_upload($file_field)) {
                        $uploadData = $this->upload->data();
                        $input['photo'] =   $config['upload_path'] . $uploadData['file_name'];
                    }
                }
                
                $insert = $this->Common_model->saveData('department', $input);
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $info = $this->Common_model->findById('department',array('record_id'=>$update_id));
                if(!empty($_FILES[$file_field]["name"])){
                    if(file_exists($info->photo) && !empty($info->photo)) {
                        unlink('./'.$info->photo);
                    }
                    if($this->upload->do_upload($file_field)) {
                            $uploadData = $this->upload->data();
                            $input['photo'] =   $config['upload_path'] . $uploadData['file_name'];
                    }
                }
                $update = $this->Common_model->updateData('department', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            redirect('department', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $id, 'department')){
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
           // redirect("crud/previousPage");
            redirect('department', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
