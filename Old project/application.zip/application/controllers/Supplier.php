<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Supplier extends MY_Controller {

    private $type;
    private $tBUrl;
    public function __construct() {
        parent::__construct();
        
        $this->type = $this->input->get('type') === 'optic' ? 'optic' : 'medicine';
        
        $this->loadModel('Supplier_model');
        $this->title    = 'Manufacturer/Supplier';
        $this->bUrl     = 'supplier';
        $this->tBUrl    = $this->bUrl.'?type='.$this->type;

        $this->load->model(['SupplierPayment_model'=>'spM']);

    }

     public function index()
    {
        $this->data = [
            'title'     => 'All '.$this->title,
            'values'    => $this->model->order_by('record_id', 'DESC')->all(),
            'type'      => $this->type
        ];
        
        $this->render('admin/supplier/index');
    }

    public function payable_info() {

         $this->data = [
            'title'     => $this->title.' Payable List',
			 'type'     => $this->type,
        ];

        $this->data['values'] = $this->spM->order_by('payment_id', 'DESC')->all();

        $this->render('admin/supplier/payable_list');
        
    }

     public function payable() {

        $this->data = [
            'title'     => $this->title.' Payable',
			 'type'     => $this->type,
        ];
        
        $this->render('admin/supplier/payable');
     }



    
    public function saveOrUpdate() {
        $request    = $this->input->post();
        $update_id  = $request['update_id'];
        if($update_id == 0 || empty($update_id)){
            $manufacturer_name  = $request['manufacturer_name'];
            $contact_no         = $request['contact_no'];
            $getRow = $this->model->where(['manufacturer_name'=>$manufacturer_name, 'contact_no'=>$contact_no])->first();
            if(isset($getRow)){
                $this->session->set_flashdata('message', EXIST_MSG);
                redirect($this->tBUrl, 'refresh');
            }

         }
        $this->model->updateOrInsert($request, $update_id);
        $this->crudAlertMessage($update_id, $this->tBUrl); 
    }
  

    public function paymentSaveOrUpdate()
    {
         $input			= $this->input->post();
         $date 			= $input['payment_date'];
         $prefix        = date('Ymd', strtotime($date));

        $this->db->trans_start();
        $paymentQue             = $this->spM->select_max('payment_no')->where(['prefix'=>$prefix])->first();
        $payment_no             = (int) ($paymentQue->payment_no ?? 0) + 1;
        $current_collections    = $input['current_collection'];

        $input['payment_no']    = $payment_no;
        $input['prefix']        = $prefix;
        $input['payment_amount']    = array_sum($current_collections);
        $data   = $this->spM->filterTableData($input);
        $id = $this->spM->create($data);

        foreach ($current_collections as $key => $value) {
             $discount     = $input['discount_amount'][$key];
             $totalAmount  = $discount + $value;
            if($totalAmount > 0){
              $data = [
                  'payment_id'          => $id,
                  'payment_date'        => $date,
                  'payment_type'        => $input['payment_type'],
                  'supplier_id'         => $input['supplier_id'],
                  'purchase_id'         => $input['purchase_id'][$key],
                  'purchase_amount'     => $input['purchase_amount'][$key],
                  'current_collection'  => $value,
                  'discount_amount'     => $discount,
              ];
              $this->Common_model->saveData('supplier_payment_details',$data);
          }
      }

      $this->db->trans_complete();
      $this->crudAlertMessage('', $this->bUrl."/payment_view/$id?type=$this->type"); 
}

public function load_supplier_invoice(){
    $supplier_id = $this->input->post('supplier_id');
    $where['supplier_id'] = $supplier_id ;
    $data['values'] = $this->Common_model->findAll('purchase_orders',$where,'purchase_id','asc') ;
    $this->load->view('admin/supplier/invoice_list',$data);
}

public function delete($id) {
    $this->model->getDelete($id);
    $this->crudAlertMessage($id, $this->tBUrl, true); 
}


public function payment_view($payment_id)
{
    $data['title'] = "Supplier Payment";
    $data['page_title'] = "Supplier Payment";
    $data['info_header'] = "";
    $data['signatureType'] = 'Staff';
    $data['redirect'] = base_url('supplier/payable');
    $data['value'] = $this->Common_model->findById('supplier_payments',array('payment_id'=>$payment_id));
    $manufacturer =  $this->Common_model->findById('drug_manufacturer', array('record_id' => $data['value']->supplier_id));
    $data['supplier'] = $manufacturer->manufacturer_name.'['.$manufacturer->record_id.']';
    $data['supplier_contact'] = !empty($manufacturer->contact_no) ? $manufacturer->contact_no : "";
    

    $where = array('supplier_payment_details.payment_id '=>$payment_id);
    $options = array(
      'joins' => array(
        array(
          'table' => 'purchase_orders',
          'condition' => 'purchase_orders.purchase_id = supplier_payment_details.purchase_id',
          'jointype' => 'LEFT'
      )
    ),
      'select' => 'supplier_payment_details.*,purchase_orders.prefix,purchase_orders.purchase_no,purchase_orders.grand_net_total',
      'where' => $where,
      'order' => array(
        'supplier_payment_details.payment_details_id' => 'asc',
    ),
  );
    $data['values'] = $this->Common_model->commonJoins("supplier_payment_details", $options);

    $this->data = $data;
    $this->data['redirect'] = base_url($this->bUrl."/payable_info?type=$this->type");

    $this->render('admin/supplier/invoice');
}

public function payment_delete($id) {
    $this->spM->getDelete($id, 'payment_id');
    $this->Common_model->delete_info('payment_id', $id, 'supplier_payment_details');
    $this->crudAlertMessage($id, $this->bUrl.'/payable_info?type='.$this->type, true);  
} 

public function due_list() {
    $user_type = $this->session->ses_user_type;
    if ($user_type == "admin" || $user_type == "staff") {
        $supplierID = $data['supplier_id'] = $this->input->get('supplier_id') ?? 0;
        $data['title'] = 'Supplier Due List';
        $data['page_title'] = 'Supplier Due List';
        $data['info_header'] = '';
        $data['suppliers'] =  $this->Common_model->one_column_group_by('supplier_id', 'purchase_orders');

        $this->load->view('admin/layouts/header');
        $this->load->view('admin/supplier/due_list', $data);
        $this->load->view('admin/layouts/footer');
    } else {
        $data['wrong_msg'] = "";
        $this->load->view('website/login_check', $data);
    }
}
}
