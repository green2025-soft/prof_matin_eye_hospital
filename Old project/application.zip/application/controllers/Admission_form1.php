<?php

/**
 * 
 */
class Admission_form extends CI_Controller
{
	
	public function __construct()
	{
		parent::__construct();
	}

	public function index(){
		$data['title'] = 'Admission List';
        $data['page_title'] = 'Admission List';
        $data['info_header'] = '';
        $where = array();
		$options = array(
			'joins' => array(
				array(
					'table' => 'patient',
					'condition' => 'patient.record_id = operation_invoice.patient_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor sergeon',
					'condition' => 'sergeon.record_id = operation_invoice.sergeon_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor anesthesia',
					'condition' => 'anesthesia.record_id = operation_invoice.anesthesia_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_category',
					'condition' => 'operation_category.record_id = operation_invoice.operation_category_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_name',
					'condition' => 'operation_name.record_id = operation_invoice.operation_name_id',
					'jointype' => 'LEFT'
				),array(
					'table' => 'beds',
					'condition' => 'beds.record_id = operation_invoice.bed_id',
					'jointype' => 'LEFT'
				),
			),
			'select' => 'operation_invoice.*,operation_invoice.record_id as operation_invoice_record_id,patient.*,sergeon.name as sergeon_name,sergeon.designation as sergeon_designation,anesthesia.name as anesthesia_name,anesthesia.designation as anesthesia_designation,operation_category.category_name,operation_name.operation_name,beds.*',
			'where' => $where,
			'order' => array(
				'operation_invoice.record_id' => 'desc',
			),
		);
		$data['values'] = $this->Common_model->commonJoins("operation_invoice", $options);
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/admission_form/index',$data);
		$this->load->view('admin/layouts/footer');			
	}
	public function create(){
		$data['title'] = 'Admission Form';
        $data['page_title'] = 'Admission Form';
        $data['info_header'] = '';
        $patient_ids = array() ;
        $admission_invoices = $this->Common_model->findAll('admission_fee_invoice',array('patient_status'=>'New'),'record_id','asc');
        foreach ($admission_invoices as $key1 => $value1) {
        	$patient_ids[] = $value1->patient_id ;
        }
        $data['patient_list'] = $this->Common_model->findAllWhereIn('patient',array(),$patient_ids,'record_id','record_id','asc') ;
        $max = $this->Common_model->findMax('operation_invoice',array(),'admission_no') ;
        $admission_no = isset($max)?$max->admission_no + 1 : 1;
        $data['admission_no'] = str_pad($admission_no,4,0,STR_PAD_LEFT );
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/admission_form/create',$data);
		$this->load->view('admin/layouts/footer');			
	}
	public function edit($record_id){
		$data['title'] = 'Edit Admission List';
        $data['page_title'] = 'Edit Admission List';
        $data['info_header'] = '';
        $data['value'] = $this->Common_model->findById('operation_invoice',array('record_id'=>$record_id));
        $patient_ids = array() ;
        $admission_invoices = $this->Common_model->findAll('admission_fee_invoice',array('patient_status'=>'Admitted'),'record_id','asc');
        foreach ($admission_invoices as $key1 => $value1) {
        	$patient_ids[] = $value1->patient_id ;
        }
        $data['patient_list'] = $this->Common_model->findAllWhereIn('patient',array(),$patient_ids,'record_id','record_id','asc') ;

        $data['operation_names'] = $this->Common_model->findAll('operation_name',array('category_id'=>$data['value']->operation_category_id),'operation_name','asc');
        $data['beds'] = $this->Common_model->findAll('beds',array('opd_cabin_ward'=>$data['value']->opd_cabin_ward),'bed_no','asc');
        $data['bed'] = $this->Common_model->findById('beds',array('record_id'=>$data['value']->bed_id));
        $data['patient'] = $this->Common_model->findById('patient',array('record_id'=>$data['value']->patient_id));
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/admission_form/create',$data);
		$this->load->view('admin/layouts/footer');			
	}
	public function saveOrUpdate(){
		$input = $_POST ;
		$admission_id = $input['admission_id'] ;
		$update_id = $input['update_id'] ; 
		unset($input['update_id']);	

		$this->Common_model->updateData('admission_fee_invoice', array('patient_status'=>'Admitted'), array('record_id'=>$admission_id));

		if($update_id == 0 || empty($update_id)){     
                $insert = $this->Common_model->saveData('operation_invoice', $input);
                $update_id = $insert;
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $update = $this->Common_model->updateData('operation_invoice', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
		$this->session->set_flashdata('message',INSERT_MSG);
		redirect("admission_form/view/$update_id");
	}

	public function view($record_id){
		$data['title'] = 'View Patient Admission';
        $data['page_title'] = 'View Patient Admission';
        $data['info_header'] = '';
        $data['redirect'] =  base_url('admission_form/create');

        $where = array('operation_invoice.record_id'=>$record_id);
		$options = array(
			'joins' => array(
				array(
					'table' => 'admission_fee_invoice',
					'condition' => 'admission_fee_invoice.record_id = operation_invoice.admission_id',
					'jointype' => 'LEFT'
				),array(
					'table' => 'patient',
					'condition' => 'patient.record_id = operation_invoice.patient_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor sergeon',
					'condition' => 'sergeon.record_id = operation_invoice.sergeon_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor anesthesia',
					'condition' => 'anesthesia.record_id = operation_invoice.anesthesia_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_category',
					'condition' => 'operation_category.record_id = operation_invoice.operation_category_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_name',
					'condition' => 'operation_name.record_id = operation_invoice.operation_name_id',
					'jointype' => 'LEFT'
				),array(
					'table' => 'beds',
					'condition' => 'beds.record_id = operation_invoice.bed_id',
					'jointype' => 'LEFT'
				),
			),
			'select' => 'operation_invoice.*,admission_fee_invoice.admission_no as adm_no,operation_invoice.record_id as operation_invoice_record_id,patient.*,operation_invoice.address as re_address,sergeon.name as sergeon_name,sergeon.designation as sergeon_designation,anesthesia.name as anesthesia_name,anesthesia.designation as anesthesia_designation,operation_category.category_name,operation_name.operation_name,beds.*',
			'where' => $where,
			'order' => array(
				'operation_invoice.record_id' => 'asc',
			),
		);
		$data['value'] = $this->Common_model->commonJoinsRow("operation_invoice", $options);

		$this->load->view('admin/layouts/header');
		$this->load->view('admin/admission_form/view',$data);
		$this->load->view('admin/layouts/footer');			
	}

	public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $id, 'operation_invoice')){
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
            redirect('admission_form', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

	public function get_operation_name(){
		$operation_category_id = $this->input->post('operation_category_id');
		$names = $this->Common_model->findAll('operation_name',['category_id' => $operation_category_id],'operation_name','asc');
        $option = "<option value=''>-- Select --</option>";
      	foreach($names as $name){
      		$option .= "<option value='$name->record_id' data-operation_price='$name->rate'>$name->operation_name</option>";	
      	}                              
		echo $option;
		exit ;
	}

	public function get_bed_info(){
		$opd_cabin_ward = $this->input->post('opd_cabin_ward');
		$names = $this->Common_model->findAll('beds',['opd_cabin_ward' => $opd_cabin_ward],'bed_no','asc');
        $option = "<option value=''>-- Select --</option>";
      	foreach($names as $name){
      		$option .= "<option value='$name->record_id' data-bed_no='$name->bed_no'  data-bed_type='$name->bed_type'  data-floor_no='$name->floor_no'  data-room_no='$name->room_no' data-charge='$name->charge'>$name->bed_no - $name->bed_type - $name->room_no - $name->floor_no</option>";	
      	}                              
		echo $option;
		exit ;
	}
}
?>