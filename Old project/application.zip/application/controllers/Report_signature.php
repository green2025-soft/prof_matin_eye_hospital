<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Report_signature extends CI_Controller
{
	private $table		= 'report_signatures';
	

	
	public function __construct()
	{
		parent::__construct();

	}
	public function index()
	{
		$data['title'] 		= "Report Signature List";
		$data['page_title'] = $data['title'];

		$where = [
		];
		
		$data['values'] = $this->Common_model->findAll($this->table, $where, "id", "desc");
		
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/report_signature/index', $data);
		$this->load->view('admin/layouts/footer');
	}
	public function create()
	{
		$request 	= $this->input->get();
		
		$data['title'] = "Create Report Signature";
		$data['page_title'] = $data['title'] ;
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/report_signature/create', $data);
		$this->load->view('admin/layouts/footer');
	}






	public function saveOrUpdate()
	{
		$request 	= $this->input->post();
		$update_id	= $request['update_id'];
		$type 		=  $request['type'];
		$type		= $type ==2?2:1;
		$request['type'] = $type;
		$signature 	= uploadImage('signature', 'uploads/signature/');
		unset($request['update_id']);
		unset($request['signature']);
		if($signature){
			$request['signature'] = $signature;
		}

		if (empty($update_id) || $update_id == 0) {
			$this->Common_model->saveData($this->table, $request);
			$this->session->set_flashdata('message',INSERT_MSG);
		}else{
			$this->session->set_flashdata('message',UPDATE_MSG);
			$this->Common_model->updateData($this->table, $request, ['id' => $update_id]);
		}
		
		redirect("report_signature?type=$type");
		

	}



	public function edit($id)
	{
		$data['title'] ="Edit Report Signature";
		$data['page_title'] = $data['title'];
		
		$data['value'] = $this->Common_model->findById($this->table, ['id' => $id]);
		
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/report_signature/create', $data);
		$this->load->view('admin/layouts/footer');;
	}


	public function delete($id)
	{
		$user_type = $this->session->ses_user_type;
		if ($user_type == "admin"  || $user_type == "staff") {
			$value 	= $this->Common_model->findById($this->table, ['id' => $id]);
			$type	= $value->type ==2?2:1;
			$this->Common_model->delete_info('id', $id, $this->table);
			$this->session->set_flashdata('message', DELETE_MSG);
			
			redirect("report_signature?type=$type", 'refresh');
		} else {
			$data['wrong_msg'] = "";
			$this->load->view('website/login_check', $data);
		}
	}
	
}
