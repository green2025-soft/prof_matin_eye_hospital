<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Test_name extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Test Name';
            $data['page_title'] = 'Test Name';
            $data['info_header'] = 'All Test Name';
            $data['values'] = $this->Common_model->findAll('test_name',array(),array('test_category','test_name'),'asc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_name/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" ||    $user_type == "staff") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            unset($input['update_id']);
            $test_name = $input['test_name'];
            $test_data = array(
                'test_category_id'=>$input['test_category_id'],
                'test_name'=>$input['test_name'],
                'test_price'=>$input['test_price'],
                'room_no'=>$input['room_no'],
                'test_code'=>$input['test_code'],
                'both_rate'=>$input['both_rate'],
                
            );

            if (array_key_exists('accessories_id', $input)) {
                $accessories_ids = $input['accessories_id'];
                $accessories_qtys = $input['accessories_qty'];
                unset($input['accessories_id']);
                unset($input['accessories_qty']);
            }

            if($update_id == 0 || empty($update_id)){       
                $getRow = $this->Common_model->findById('test_name',array('test_name'=>$test_name));
                if(isset($getRow)){
                    $this->session->set_flashdata('message', EXIST_MSG);
                    redirect('test_name', 'refresh');
                }
                
                $insert = $this->Common_model->saveData('test_name', $test_data);
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                    if(isset($accessories_ids)){
                        $accessoriesList = array() ;
                        foreach ($accessories_ids as $key1 => $value1) {
                            $data = array(
                                'test_id'=> $insert,
                                'accessories_id'=>$accessories_ids[$key1],
                                'accessories_qty'=>$accessories_qtys[$key1],
                            );
                            $accessoriesList[] = $data ;
                        } 
                        $this->Common_model->save_batch('test_accessories',$accessoriesList) ;
                    }
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $update = $this->Common_model->updateData('test_name', $test_data ,array('record_id'=>$update_id));
                if($update){

                    $this->Common_model->deleteData('test_accessories',array('test_id'=>$update_id));

                    if(isset($accessories_ids)){
                        $accessoriesList = array() ;
                        foreach ($accessories_ids as $key1 => $value1) {
                            $data = array(
                                'test_id'=> $update_id,
                                'accessories_id'=>$accessories_ids[$key1],
                                'accessories_qty'=>$accessories_qtys[$key1],
                            );
                            $accessoriesList[] = $data ;
                        } 
                        $this->Common_model->save_batch('test_accessories',$accessoriesList);
                    }
                    
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            redirect('test_name', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $id, 'test_name')){
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
           // redirect("crud/previousPage");
            redirect('test_name', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function get_testName_by_category()
    {
        $test_category_id = $this->input->post('test_category_id');
        $values = $this->Common_model->findAll('test_name',array('test_category_id'=>$test_category_id),"record_id","asc") ;
        $options = "<option value=''>--Select--</option>" ;
        foreach ($values as $key => $value) {
            $options .= "<option value='$value->record_id'>$value->record_id - $value->test_name</option>" ;
        }
        echo $options ;
        exit;
    }

    public function edit_acc() {

    $testId = $this->input->post('id');

    $this->db->select("
        product_name.*,
        test_accessories.*,
        COALESCE(in_qty.total_in,0) AS total_in,
        COALESCE(out_qty.total_out,0) AS total_out,
        (COALESCE(in_qty.total_in,0) - COALESCE(out_qty.total_out,0)) AS available_qty
    ");

    $this->db->from('test_accessories');

    $this->db->join(
        'product_name',
        'product_name.record_id = test_accessories.accessories_id',
        'left'
    );

    $this->db->join(
        '(SELECT product_id, SUM(quantity) AS total_in
        FROM lab_product_in_details
        GROUP BY product_id) AS in_qty',
        'in_qty.product_id = test_accessories.accessories_id',
        'left'
    );

    $this->db->join(
        '(SELECT product_id, SUM(quantity) AS total_out
        FROM lab_product_out_details
        GROUP BY product_id) AS out_qty',
        'out_qty.product_id = test_accessories.accessories_id',
        'left'
    );

    $this->db->where('test_accessories.test_id', $testId);
    $this->db->having('available_qty >', 0);

    $query = $this->db->get();

    $result = $query->result();
    echo json_encode($result);
    exit();

     
    }
}


