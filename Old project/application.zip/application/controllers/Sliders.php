<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Sliders  extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('upload');
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Slider';
            $data['page_title'] = 'Slider';
            $data['info_header'] = 'All Slider';
            $data['values'] = $this->Common_model->findAll('sliders',array(),'record_id','desc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/sliders/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            unset($input['update_id']);

          $config['upload_path']      = 'assets/img/sliders/';
          $config['allowed_types']    = '*';
          $config['max_size']         = '0';
          //$config['file_name']      = time(); 
          $file_field                 = "image";

          $this->upload->initialize($config);
            if($update_id == 0 || empty($update_id)){     

                if(!empty($_FILES[$file_field]["name"])){
                    if($this->upload->do_upload($file_field)) {
                        $uploadData = $this->upload->data();
                        $input['image'] =   $config['upload_path'] . $uploadData['file_name'];
                    }
                }

                $insert = $this->Common_model->saveData('sliders', $input);
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $info = $this->Common_model->findById('sliders',array('record_id'=>$update_id));
                if(!empty($_FILES[$file_field]["name"])){
                    if(file_exists($info->image) && !empty($info->image)) {
                        unlink('./'.$info->image);
                    }
                    if($this->upload->do_upload($file_field)) {
                            $uploadData = $this->upload->data();
                            $input['image'] =   $config['upload_path'] . $uploadData['file_name'];
                    }
                }
                $update = $this->Common_model->updateData('sliders', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            redirect('sliders', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            $info = $this->Common_model->findById('sliders',array('record_id'=>$id)) ;
                if($info){
                    if(file_exists($info->image) && !empty($info->image)) {
                    unlink('./'.$info->image);
                }
                $this->Common_model->delete_info('record_id', $id, 'sliders');
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
            redirect('sliders', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
