<?php

defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Api extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Common_model');

        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Methods: GET, OPTIONS, POST, GET, PUT");
        header("Access-Control-Allow-Headers: Content-Type, Content-Length, Accept-Encoding");
    }

    public function index()
    {
        // die('here');
        echo "Hello";
    }


    public function test()
    {
        $date = date('YmdHis');
        $uniqueId = $date . md5(uniqid("", true));

        echo "<pre>";
        var_dump($uniqueId);
        exit;
    }


    // public function lis_result(){
    //     $key = 'GrC1vm8pXBJrwkLkEEbj1NgfGQyQVZXpzXY3N';

    //     $responseData           = [];
    //     $responseData['code']   = 200;
    //     $responseData['msg']    = 'Data Not Found';
    //     $responseData['data']   = "";
    //     $req_key    = $this->input->request_headers('key');
    //     $invoice_id =  $_POST['invoice_id'];
    //     $test_code  =  $_POST['test_code'];

    //     if($key!== $req_key['key']){
    //         $responseData['code']   = 400;
    //         $responseData['msg']    = 'Error, Secret Key is Wrong!';
    //     } else {
    //         $invoice_data = $this->Common_model->one_column_one_info('record_id', 'record_id', $invoice_id, 'create_bill');
    //         if(!$invoice_data){
    //             $responseData['code']   = 404;
    //             $responseData['msg']    = 'Error, Invoice ID Not Matched!';
    //         } else {
    //             $test_data = $this->Common_model->one_column_one_info('record_id', 'test_code', $test_code, 'test_name');
    //             if(!$test_data){
    //                 $responseData['code']   = 404;
    //                 $responseData['msg']    = 'Error, Test Code Not Matched!';
    //             } else {
    //                 $insert_data = array(
    //                     'invoice_id'    => $_POST['invoice_id'],
    //                     'test_code'     => $_POST['test_code'],
    //                     'test_field'    => $_POST['test_field'],
    //                     'test_value'    => $_POST['test_value'],
    //                     'ref_value'     => $_POST['ref_value']
    //                 );

    //                 $responseData['code']   = 200;
    //                 $responseData['msg']    = 'Data Post Successfully';
    //                 $responseData['data']   = $insert_data;
    //             }
    //         }
    //     }

    //     echo json_encode($responseData);
    // }

    public function lis_result()
    {
        $key = 'GrC1vm8pXBJrwkLkEEbj1NgfGQyQVZXpzXY3N';

        $responseData           = [];
        $responseData['code']   = 200;
        $responseData['msg']    = 'Data Not Found';
        //$responseData['data']   = "";
        $req_key    = $this->input->request_headers('key');

        $_POST = json_decode($this->input->raw_input_stream, true);

        $invoice_id =  $_POST['inv_id'];

        if ($key !== $req_key['key']) {
            $responseData['code']   = 400;
            $responseData['msg']    = 'Error, Secret Key is Wrong!';
        } else {
            $invoice_data = $this->Common_model->one_column_one_info('record_id', 'record_id', $invoice_id, 'create_bill');
            if (!$invoice_data) {
                $responseData['code']   = 404;
                $responseData['msg']    = 'Error, Invoice ID Not Matched!';
            } else {

                $result_info = $_POST['result_info'];
                $result_data = [];
                foreach($result_info as $row) {
                    $result_data[] = array(
                        'inv_id'        => $_POST['inv_id'],
                        'create_at'     => $_POST['create_at'],
                        'analyzer_name' => $_POST['analyzer_name'],
                        'parameter'     => $row['parameter'],
                        'result'        => $row['result']
                    );
                }
                $this->db->insert_batch('machine_data_dtls', $result_data);

                $responseData['code']   = 200;
                $responseData['msg']    = 'Data Sent Successfully';
                //$responseData['data']   = $result_data;
            }
        }
        

        echo json_encode($responseData);
    }
}
