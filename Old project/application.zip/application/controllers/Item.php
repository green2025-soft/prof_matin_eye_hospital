<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Item extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Item';
            $data['page_title'] = 'Item';
            $data['info_header'] = 'All Item';
            $data['values'] = $this->Common_model->findAll('items',array(),'record_id','desc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/items/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            unset($input['update_id']);
            $popup = $this->input->post('popup');
            if(isset($popup)){
                unset($input['popup']);
            }
            $item_name = $input['item_name'];
            $record_id = 0 ;
            if($update_id == 0 || empty($update_id)){       
                $getRow = $this->Common_model->findById('items',array('item_name'=>$item_name));
                if(isset($getRow)){
                    $this->session->set_flashdata('message', EXIST_MSG);
                    redirect('items', 'refresh');
                }
                $insert = $this->Common_model->saveData('items', $input);
                $record_id = $insert ;
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $record_id = $update_id ;
                $update = $this->Common_model->updateData('items', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            if (isset($popup)) {
                $item = $this->Common_model->findById('items', array('record_id' => $record_id));
                echo json_encode($item);
                exit;
            }
            redirect('item', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $id, 'items')){
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
           // redirect("crud/previousPage");
            redirect('item', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
