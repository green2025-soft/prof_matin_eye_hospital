<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Bed extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Bed Information';
            $data['page_title'] = 'Bed Information';
            $data['info_header'] = 'All Bed Information';
            $data['values'] = $this->Common_model->findAll('beds',array(),'record_id','desc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/bed/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            $opd_cabin_ward = $input['opd_cabin_ward'] ;
            $floor_no = $input['floor_no'] ;
            $room_no = $input['room_no'] ;
            $bed_no = $input['bed_no'] ;
            unset($input['update_id']);
            if($update_id == 0 || empty($update_id)){       
                $getRow = $this->Common_model->findById('beds',array('opd_cabin_ward'=>$opd_cabin_ward,'floor_no'=>$floor_no,'room_no'=>$room_no,'bed_no'=>$bed_no));
                if(isset($getRow)){
                    $this->session->set_flashdata('message', EXIST_MSG);
                    redirect('bed', 'refresh');
                }
                $insert = $this->Common_model->saveData('beds', $input);
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $update = $this->Common_model->updateData('beds', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            redirect('bed', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $id, 'beds')){
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
           // redirect("crud/previousPage");
            redirect('bed', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
