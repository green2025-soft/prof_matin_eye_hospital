<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Doctor_service extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'All Doctor Service';
            $data['page_title'] = 'All Doctor Service';
            $data['info_header'] = 'All Doctor Service';
            $data['values'] = $this->Common_model->findAll('create_bill',array('type'=>'Doctor Service'),'record_id','desc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/doctor_service/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function create() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Create Doctor Service';
            $data['page_title'] = 'Create Doctor Service';
            $data['info_header'] = '';
            $oxygen = $this->Common_model->findById('expenditure',array('record_id'=>1));
            $data['rate_per_hour'] = isset($oxygen)?$oxygen->expenditure_rate:0 ;
            $data['test_names'] = $this->Common_model->findAll('test_name',array(),'record_id','asc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/doctor_service/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function edit($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Edit Doctor Service';
            $data['page_title'] = 'Edit Doctor Service';
            $data['info_header'] = '';
            $oxygen = $this->Common_model->findById('expenditure',array('record_id'=>1));
            $data['rate_per_hour'] = isset($oxygen)?$oxygen->expenditure_rate:0 ;
            $data['test_names'] = $this->Common_model->findAll('test_name',array(),'record_id','asc');
            $data['value'] = $this->Common_model->findById('create_bill',array('record_id'=>$record_id));
            $data['values'] = $this->Common_model->findAll('doctor_services',array('invoice_no'=>$record_id),'record_id','asc');
            $data['service_list'] = $this->Common_model->findAll('doctor_service_list',array('invoice_no'=>$record_id),'record_id','asc');
            if(isset($data['value'])){
                $data['patient'] = $this->Common_model->findById('patient',array('record_id'=>$data['value']->patient_id));
            }
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/doctor_service/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            //var_dump($input);die;
            $update_id = $input['update_id'] ;
            unset($input['update_id']);
            $date = $input['date'];
            $sales_test_ids = $this->input->post('sales_test_id'); // $input['sales_test_id'];
            $doctor_service_ids = $this->input->post('doctor_service_id') ;
            if($sales_test_ids){
                $test_ids = $input['test_id'];
                $test_category_ids = $input['test_category_id'];
                $test_names = $input['test_name'];
                $test_categorys = $input['test_category'];
                $test_prices = $input['test_price'];
                unset($input['sales_test_id']);
                unset($input['test_id']);
                unset($input['test_category_id']);
                unset($input['test_name']);
                unset($input['test_category']);
                unset($input['test_price']);
            }
            if($doctor_service_ids){
                $service_ids = $input['service_id'];
                $service_names = $input['service_name'];
                $service_amounts = $input['service_amount'];
                unset($input['doctor_service_id']);
                unset($input['service_id']);
                unset($input['service_name']);
                unset($input['service_amount']);
            }

           // var_dump($input);die;

            $prefix = 'Drs'. date("Ymd",strtotime($date));
            $maxSalesTest = $this->Common_model->findMax('create_bill',array('prefix'=>$prefix,'type'=>'Doctor Service'),'invoice_no');
            $invoice_no = isset($maxSalesTest)?$maxSalesTest->invoice_no + 1 : 1 ;

            $input['prefix'] = $prefix ;
            $input['invoice_no'] = $invoice_no ;;
            $input['type'] = 'Doctor Service';
            $input['particular'] = "Doctor Service";

           // var_dump($input) ;die;


            if($update_id == 0 || empty($update_id)){       
                $insert = $this->Common_model->saveData('create_bill', $input);
                if(isset($doctor_service_ids)){
                    foreach ($doctor_service_ids as $key1 => $value1) {
                        $data = array(
                            'invoice_no'=>$insert,
                            'date' => $date,
                            'patient_id' => $input['patient_id'],
                            'doctor_id' => $input['doctor_id'],
                            'service_id' => $service_ids[$key1],
                            'service_name' => $service_names[$key1],
                            'service_amount' => $service_amounts[$key1],
                        );
                        if($value1 == 0){
                            $this->Common_model->saveData('doctor_service_list', $data);
                        }else{
                            $this->Common_model->saveData('doctor_service_list', $data,array('record_id'=>$value1));
                        }
                    }
                }
                if(isset($sales_test_ids)){
                    foreach ($sales_test_ids as $key2 => $value2) {
                        $data = array(
                            'invoice_no'=>$insert,
                            'date' => $date,
                            'patient_id' => $input['patient_id'],
                            'doctor_id' => $input['doctor_id'],
                            'test_id' => $test_ids[$key2],
                            'test_category_id' => $test_category_ids[$key2],
                            'test_name' => $test_names[$key2],
                            'test_category' => $test_categorys[$key2],
                            'test_price' => $test_prices[$key2],
                        );
                        if($value2 == 0){
                            $this->Common_model->saveData('doctor_services', $data);    
                        }else{
                            $this->Common_model->updateData('doctor_services', $data,array('record_id'=>$value2));
                        }
                    }
                }
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
                $update_id = $insert ;
                 redirect("doctor_service/view/$update_id", 'refresh');
            }else{

                $invoice = $this->Common_model->findById('create_bill',array('record_id'=>$update_id));

                if(isset($invoice)){
                    if($invoice->date == $date){
                        $input['invoice_no'] = $invoice->invoice_no ;
                    }
                }
                $update = $this->Common_model->updateData('create_bill', $input,array('record_id'=>$update_id));
               // var_dump($test_ids);die;
                if(isset($doctor_service_ids)){
                    foreach ($doctor_service_ids as $key1 => $value1) {
                        $data = array(
                            'invoice_no'=>$update_id,
                            'date' => $date,
                            'patient_id' => $input['patient_id'],
                            'doctor_id' => $input['doctor_id'],
                            'service_id' => $service_ids[$key1],
                            'service_name' => $service_names[$key1],
                            'service_amount' => $service_amounts[$key1],
                        );
                        if($value1 == 0){
                            $this->Common_model->saveData('doctor_service_list', $data);
                        }else{
                            $this->Common_model->updateData('doctor_service_list', $data,array('record_id'=>$value1));
                        }
                    }
                }
                if(isset($test_ids)){
                    foreach ($test_ids as $key2 => $value2) {
                        $sales_test_id = $sales_test_ids[$key2];
                        $data = array(
                            'invoice_no'=>$update_id,
                            'date' => $date,
                            'patient_id' => $input['patient_id'],
                            'doctor_id' => $input['doctor_id'],
                            'test_id' => $test_ids[$key2],
                            'test_category_id' => $test_category_ids[$key2],
                            'test_name' => $test_names[$key2],
                            'test_category' => $test_categorys[$key2],
                            'test_price' => $test_prices[$key2],
                        );
                        if($sales_test_id){
                            $this->Common_model->updateData('doctor_services', $data,array('record_id'=>$sales_test_id));
                        }else{
                            $this->Common_model->saveData('doctor_services', $data);
                        }                    
                    }

                    if($update){
                        $this->session->set_flashdata('message',UPDATE_MSG);
                    }else{
                        $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                    }
                }
                     redirect("doctor_service/view2/$update_id", 'refresh');
            }
           
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function view($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Doctor Service';
            $data['page_title'] = 'Doctor Service';
            $data['info_header'] = '';
            $data['signatureType'] = 'Patient';
            $data['redirect'] = base_url('doctor_service/create');
            $data['value'] = $this->Common_model->findById('create_bill',array('record_id'=>$record_id));
            $data['values'] = $this->Common_model->findAll('doctor_services',array('invoice_no'=>$record_id),'record_id','asc');
            $data['service_list'] = $this->Common_model->findAll('doctor_service_list',array('invoice_no'=>$record_id),'record_id','asc');
            if(isset($data['value'])){
                $data['patient'] = $this->Common_model->findById('patient',array('record_id'=>$data['value']->patient_id));
                $data['doctor'] = $this->Common_model->findById('doctor',array('record_id'=>$data['value']->doctor_id));
            }
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/doctor_service/invoice', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function view2($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Test Invoice';
            $data['page_title'] = 'Test Invoice';
            $data['info_header'] = '';
            $data['signatureType'] = 'Patient';
            $data['redirect'] = base_url('doctor_service');
            $data['value'] = $this->Common_model->findById('create_bill',array('record_id'=>$record_id));
            $data['values'] = $this->Common_model->findAll('doctor_services',array('invoice_no'=>$record_id),'record_id','asc');
            $data['service_list'] = $this->Common_model->findAll('doctor_service_list',array('invoice_no'=>$record_id),'record_id','asc');
            if(isset($data['value'])){
                $data['patient'] = $this->Common_model->findById('patient',array('record_id'=>$data['value']->patient_id));
                $data['doctor'] = $this->Common_model->findById('doctor',array('record_id'=>$data['value']->doctor_id));
            }
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/doctor_service/invoice', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $id, 'create_bill')){
                $this->Common_model->delete_info('invoice_no', $id, 'doctor_services');
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
           // redirect("crud/previousPage");
            redirect('doctor_service', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function delete_sale_test() {
        $user_type = $this->session->ses_user_type;
        $record_id = $this->input->post('record_id');
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $record_id, 'doctor_services')){
                $this->session->set_flashdata('message',DELETE_MSG);
                echo 1;
            }else{
                echo 0;
            }
           exit;
        } else {
            echo 0;
            exit;
        }
         }
    public function delete_doctor_service() {
        $user_type = $this->session->ses_user_type;
        $record_id = $this->input->post('record_id');
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $record_id, 'doctor_service_list')){
                $this->session->set_flashdata('message',DELETE_MSG);
                echo 1;
            }else{
                echo 0;
            }
           exit;
        } else {
            echo 0;
            exit;
        }
    }
   
}
