<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Meal_type extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff" || $user_type == "doctor") {
            $data['title'] = 'Meal Type';
            $data['page_title'] = 'Meal Type';
            $data['info_header'] = 'All Meal Type';
            $data['values'] = $this->Common_model->findAll('meal_types',array(),'record_id','desc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/meal_type/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff" || $user_type == "doctor") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            unset($input['update_id']);
            $popup = $this->input->post('popup');
            if(isset($popup)){
                unset($input['popup']);
            }
            $meal_type_name = $input['meal_type_name'];
            if($update_id == 0 || empty($update_id)){       
                $getRow = $this->Common_model->findById('meal_types',array('meal_type_name'=>$meal_type_name));
                if(isset($getRow)){
                    $this->session->set_flashdata('message', EXIST_MSG);
                    redirect('meal_type', 'refresh');
                }
                $insert = $this->Common_model->saveData('meal_types', $input);
                $record_id = $insert ;
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $update = $this->Common_model->updateData('meal_types', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            if(isset($popup)){
                $meal_type = $this->Common_model->findById('meal_types',array('record_id'=>$record_id));
                echo json_encode($meal_type);
                exit;
            }
            redirect('meal_type', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff" || $user_type == "doctor") {
            if($this->Common_model->delete_info('record_id', $id, 'meal_types')){
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
           // redirect("crud/previousPage");
            redirect('meal_type', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
