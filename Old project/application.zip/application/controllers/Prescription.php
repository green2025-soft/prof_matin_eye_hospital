<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Prescription extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff" || $user_type == "doctor") {
            $data['title'] = 'Prescription Information';
            $data['page_title'] = 'Prescription Information';
            $user_type = $this->session->ses_user_type;
            $record_id = $this->session->ses_record_id;
            $where = array() ;
            if($user_type == 'doctor'){
                $where['doctor_id'] = $record_id ;
            }
            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $patient_id = $this->input->get('patient_id');

            if(!isset($from_date) && !isset($to_date) && !isset($patient_id)){
                $from_date = $to_date = date('Y-m-d');
            }
            if($patient_id) $where['patient_id'] = $patient_id ;
            if(!empty($from_date) && !empty($to_date)){
                $where['date >= '] = $from_date;
                $where['date <= '] = $to_date;
            }elseif(!empty($from_date) && empty($to_date)){
                $where['date'] = $from_date;
            }elseif(empty($from_date) && !empty($to_date)){
                $where['date'] = $to_date;
            }
            $data['patient_id'] = $patient_id ;
            $data['from_date'] = $from_date ;
            $data['to_date'] = $to_date ;

            $data['values'] = $this->Common_model->findAll('prescription',$where,'record_id','desc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/prescription/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    
    public function create() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff" || $user_type == "doctor") {
            $data['title'] = 'Create Prescription';
            $data['page_title'] = 'Create Prescription';
            $data['test_names'] = $this->Common_model->findAll('test_name',array(),'record_id','asc');
            $where = array('product_name.type'=>'Medicine');
        $options = array(
            'joins' => array(
                array(
                    'table' => 'units',
                    'condition' => 'units.record_id = product_name.unit_id',
                    'jointype' => 'LEFT'
                ),
                array(
                    'table' => 'generic_names',
                    'condition' => 'generic_names.record_id = product_name.product_category_generic_name_id',
                    'jointype' => 'LEFT'
                ),
            ),
            'select' => 'product_name.*,units.unit_short_name,generic_names.generic_name',
            'where' => $where,
            'order' => array(
                'product_name.record_id' => 'asc',
            ),
        );
        $data['products'] = $this->Common_model->commonJoins("product_name", $options);
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/prescription/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function edit($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff" || $user_type == "doctor") {
            $data['title'] = 'Edit Prescription';
            $data['page_title'] = 'Edit Prescription';
            $data['test_names'] = $this->Common_model->findAll('test_name',array(),'record_id','asc');
            $data['value'] = $this->Common_model->findById('prescription',array('record_id'=>$record_id)) ;
            $data['values'] = $this->Common_model->findAll('prescription_details',array('prescription_id'=>$record_id),'record_id','asc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/prescription/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff" || $user_type == "doctor") {
            $input = $_POST ;
          //  var_dump($input);die;
            $update_id = $input['update_id'] ;
            $doctor_id = $input['doctor_id'] ;
            unset($input['update_id']);
            $date = date('Y-m-d');
            $prescription_details_ids = $input['prescription_details_id'];
            $test_ids = $input['test_id'];
            if(is_array($test_ids)) $test_ids = implode(',', $test_ids);
            $input['test_ids'] = $test_ids ;
            $medicine_ids = $input['medicine_id'];
            $medicine_type_ids = $input['medicine_type_id'];
            $doses = $input['dose'];
            $meal_type_ids = $input['meal_type_id'];
            $dayses = $input['days'];
            $times = $input['times'];

            unset($input['prescription_details_id']);
            unset($input['test_id']);
            unset($input['medicine_id']);
            unset($input['medicine_type_id']);
            unset($input['dose']);
            unset($input['meal_type_id']);
            unset($input['days']);
            unset($input['test_name']);
            unset($input['times']);

            $prefix = date("Ymd",strtotime($date));
            $maxPrescription = $this->Common_model->findMax('prescription',array('prefix'=>$prefix, 'doctor_id' =>$doctor_id),'prescription_no');
            $prescription_no = isset($maxPrescription)?$maxPrescription->prescription_no + 1 : 1 ;

            $input['prefix'] = $prefix ;
            $input['prescription_no'] = $prescription_no ;
            $input['date'] = $date ;

            if($update_id == 0 || empty($update_id)){       
                $insert = $this->Common_model->saveData('prescription', $input);
                foreach ($medicine_ids as $key => $value) {
                    $data = array(
                        'prescription_id'=>$insert,
                        'medicine_id' => $medicine_ids[$key],
                        'medicine_type_id' => $medicine_type_ids[$key],
                        'dose' => $doses[$key],
                        'meal_type_id' => $meal_type_ids[$key],
                        'days' => $dayses[$key],
                        'times' => $times[$key],
                    );
                    $this->Common_model->saveData('prescription_details', $data);
                }
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
                $update_id = $insert ;
            }else{

                $prescription = $this->Common_model->findById('prescription',array('record_id'=>$update_id));
                if(isset($prescription)){
                    if($prescription->date == $date){
                        $input['prescription_no'] = $prescription->prescription_no ;
                    }
                }
                $update = $this->Common_model->updateData('prescription', $input,array('record_id'=>$update_id));
                foreach ($medicine_ids as $key => $value) {
                    $prescription_detail_id = $prescription_details_ids[$key];
                    $data = array(
                        'prescription_id'=>$update_id,
                        'medicine_id' => $medicine_ids[$key],
                        'medicine_type_id' => $medicine_type_ids[$key],
                        'dose' => $doses[$key],
                        'meal_type_id' => $meal_type_ids[$key],
                        'days' => $dayses[$key],
                        'times' => $times[$key],
                    );
                    if($prescription_detail_id){
                        $this->Common_model->updateData('prescription_details', $data,array('record_id'=>$prescription_detail_id));
                    }else{
                        $this->Common_model->saveData('prescription_details', $data);
                    }                    
                }
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
                redirect("prescription/view2/$update_id", 'refresh');
            }
           // var_dump("Called");die;
            redirect("prescription/view/$update_id", 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function view($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff" || $user_type == "doctor") {
            $data['title'] = 'View Prescription';
            $data['page_title'] = 'View Prescription';
            $data['info_header'] = '';
            $data['signatureType'] = '';
            $data['redirect'] = base_url('prescription/create');
            $data['value'] = $this->Common_model->findById('prescription',array('record_id'=>$record_id));
            $data['values'] = $this->Common_model->findAll('prescription_details',array('prescription_id'=>$record_id),'record_id','asc');
            if(isset($data['value'])){
                $data['patient'] = $this->Common_model->findById('patient',array('record_id'=>$data['value']->patient_id));
                $data['doctor'] = $this->Common_model->findById('doctor',array('record_id'=>$data['value']->doctor_id));
                //$data['dept'] = $this->Common_model->findById('department',array('record_id'=>$data['doctor']->department));
                $designation = $this->Common_model->findById('designation',array('record_id'=>$data['doctor']->designation_id));
                $designation_name = isset($designation)?$designation->designation:"" ;
                $data['doctor']->designation = $designation_name ;
            }
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/prescription/view', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function view2($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff" || $user_type == "doctor") {
            $data['title'] = 'View Prescription';
            $data['page_title'] = 'View Prescription';
            $data['info_header'] = '';
            $data['signatureType'] = '';
            $data['redirect'] = base_url('prescription');
            $data['value'] = $this->Common_model->findById('prescription',array('record_id'=>$record_id));
            $data['values'] = $this->Common_model->findAll('prescription_details',array('prescription_id'=>$record_id),'record_id','asc');
            if(isset($data['value'])){
                $data['patient'] = $this->Common_model->findById('patient',array('record_id'=>$data['value']->patient_id));
                $data['doctor'] = $this->Common_model->findById('doctor',array('record_id'=>$data['value']->doctor_id));
            }
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/prescription/view', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff" || $user_type == "doctor") {
            if($this->Common_model->delete_info('record_id', $id, 'prescription')){
                $this->Common_model->delete_info('prescription_id', $id, 'prescription_details');
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
            redirect('prescription', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
