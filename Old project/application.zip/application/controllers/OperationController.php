<?php
/**
 * 
 */
class OperationController extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Common_model');
		$this->load->model('Join_model');
	}
	public function category(){
		$categories = $this->Common_model->get_all_info('operation_category');
		$this->load->view('admin/header');
		$this->load->view('admin/operation/category-new',['categories' => $categories]);
		$this->load->view('admin/footer');
	}
	public function createCategory(){
		$record_id = $this->input->post('record_id') ;
		$data['category_name'] = $this->input->post('category_name');
		if(isset($record_id)){
			$getRow = $this->Common_model->findById('operation_category',array('record_id !='=>$record_id,'category_name'=>$data['category_name']));
			if(isset($getRow)){
				$this->session->set_flashData('message',EXIST_MSG);
				$this->session->set_flashData('category_name',$data['category_name']);
				redirect(base_url().'operation/edit-category/'.$record_id);
			}
			$update = $this->Common_model->updateData('operation_category',$data,array('record_id'=>$record_id)) ;
			if($update){
				$this->session->set_flashData('message',UPDATE_MSG);
			}else{
				$this->session->set_flashData('message',UPDATE_ERROR_MSG);
			}
		}else{
			$getRow = $this->Common_model->findById('operation_category',array('category_name'=>$data['category_name']));
			if(isset($getRow)){
				$this->session->set_flashData('message',EXIST_MSG);
				$this->session->set_flashData('category_name',$data['category_name']);
				redirect(base_url().'operation/category');
			}
			$insert = $this->Common_model->saveData('operation_category',$data) ;
			if($insert){
				$this->session->set_flashData('message',INSERT_MSG);
			}else{
				$this->session->set_flashData('message',INSERT_ERROR_MSG);
			}
		}
		redirect(base_url().'operation/category');

	}
	public function editCategory($record_id){
		$categories = $this->Common_model->get_all_info('operation_category');
		$category = $this->Common_model->findById('operation_category',['record_id' => $record_id]);
		$this->load->view('admin/header');
		$this->load->view('admin/operation/category-edit',['categories' => $categories, 'category' => $category]);
		$this->load->view('admin/footer');
	}
	public function deleteCategory($record_id){
		$category = $this->Common_model->findById('operation_name',['category_id' => $record_id]);
		if(isset($category)){
			$this->session->set_flashdata('message','danger_Can not perform this operation. Because Operation Name is inserted Under this category');
		}
		else{
			if($this->Common_model->delete_info('record_id',$record_id,'operation_category')){
				$this->session->set_flashdata('message',DELETE_MSG);
			}else{
				$this->session->set_flashdata('message',DELETE_ERROR_MSG);
			}
		}
		redirect(base_url().'operation/category');
	}
	public function operationName(){
		$categories = $this->Common_model->get_all_info('operation_category');
		$names = $this->Join_model->operationName();
		$this->load->view('admin/header');
		$this->load->view('admin/operation/operation-new',['names' => $names, 'categories' => $categories]);
		$this->load->view('admin/footer');		
	}
	public function createOperationName(){
		$record_id = $this->input->post('record_id') ;	
		$data['category_id'] = $this->input->post('category_id');
		$data['operation_name'] = $this->input->post('operation_name');
		$data['rate'] = $this->input->post('rate');
				
		if(isset($record_id)){
			$getRow = $this->Common_model->findById('operation_name',array('record_id !='=>$record_id,'category_id'=>$data['category_id'],'operation_name'=>$data['operation_name']));
			if(isset($getRow)){
				$this->session->set_flashData('message',EXIST_MSG);
				//$this->session->set_flashData('data',$data);
				redirect(base_url().'operation/edit-operation-name/'.$record_id);
			}
			$update = $this->Common_model->updateData('operation_name',$data,array('record_id'=>$record_id)) ;
			if($update){
				$this->session->set_flashData('message',UPDATE_MSG);
			}else{
				$this->session->set_flashData('message',UPDATE_ERROR_MSG);
			}
		}else{
			$getRow = $this->Common_model->findById('operation_name',array('category_id'=>$data['category_id'],'operation_name'=>$data['operation_name']));
			if(isset($getRow)){
				$this->session->set_flashData('message',EXIST_MSG);
				$this->session->set_flashData('operation_name',$data['operation_name']);
				redirect(base_url().'operation/category');
			}
			$insert = $this->Common_model->saveData('operation_name',$data) ;
			if($insert){
				$this->session->set_flashData('message',INSERT_MSG);
			}else{
				$this->session->set_flashData('message',INSERT_ERROR_MSG);
			}
		}
		redirect(base_url().'operation/operation-name');		
	}
	public function editOperationName($record_id){

		$categories = $this->Common_model->get_all_info('operation_category');
		$names = $this->Join_model->operationName();
		$name = $this->Common_model->findById('operation_name',['record_id' => $record_id]);
		$this->load->view('admin/header');
		$this->load->view('admin/operation/operation-edit',[
													'names' => $names, 
													'categories' => $categories,
													'name' => $name
													]);
		$this->load->view('admin/footer');	
	}
	public function deleteOperationName($record_id){
		$operation = $this->Common_model->findById('operation_details',['operation_id' => $record_id]);
		if(isset($operation)){
			$this->session->set_flashdata('message','danger_Can not perform this operation. Because Other value is inserted Under this operation Name');
		}
		else{
			if($this->Common_model->delete_info('record_id',$record_id,'operation_name')){
				$this->session->set_flashdata('message',DELETE_MSG);
			}ELSE{
				$this->session->set_flashdata('message',DELETE_ERROR_MSG);
			}
		}
		redirect(base_url().'operation/operation-name');
	}
	public function expenditure(){
		$expenditures = $this->Common_model->get_all_info('expenditure');
		$this->load->view('admin/header');
		$this->load->view('admin/operation/expenditure-new',['expenditures' => $expenditures]);
		$this->load->view('admin/footer');
	}
	public function createExpenditure(){
		
		$data['expenditure_title'] = $this->input->post('expenditure_title');
		$data['expenditure_rate'] = $this->input->post('expenditure_rate');
		$record_id = $this->input->post('record_id') ;
		if(isset($record_id)){
			$getRow = $this->Common_model->findById('expenditure',array('record_id !='=>$record_id,'expenditure_title'=>$data['expenditure_title']));
			if(isset($getRow)){
				$this->session->set_flashData('message',EXIST_MSG);
				$this->session->set_flashData('expenditure_title',$data['expenditure_title']);
				$this->session->set_flashData('rate',$data['rate']);
				redirect(base_url().'operation/edit-expenditure/'.$record_id);
			}
			$update = $this->Common_model->updateData('expenditure',$data,array('record_id'=>$record_id)) ;
			if($update){
				$this->session->set_flashData('message',UPDATE_MSG);
			}else{
				$this->session->set_flashData('message',UPDATE_ERROR_MSG);
			}
		}else{
			$getRow = $this->Common_model->findById('expenditure',array('expenditure_title'=>$data['expenditure_title']));
			if(isset($getRow)){
				$this->session->set_flashData('message',EXIST_MSG);
				$this->session->set_flashData('expenditure_title',$data['expenditure_title']);
				$this->session->set_flashData('rate',$data['rate']);
				redirect(base_url().'operation/expenditure');
			}
			$insert = $this->Common_model->saveData('expenditure',$data) ;
			if($insert){
				$this->session->set_flashData('message',INSERT_MSG);
			}else{
				$this->session->set_flashData('message',INSERT_ERROR_MSG);
			}
		}
				
		
		/*f($this->input->post('submit')){
			$this->Common_model->insert_data('expenditure', $data);
			$this->session->set_flashdata('success','Expenditure Title Inserted');
		}
		else{
			$this->Common_model->update_data_onerow('expenditure', $data, 'record_id',$this->input->post('record_id'));
			$this->session->set_flashdata('success','Expenditure Name Updated');
		}*/
		redirect(base_url().'operation/expenditure');
	}
	public function editExpenditure($record_id){
		$expenditures = $this->Common_model->get_all_info('expenditure');
		$expenditure = $this->Common_model->findById('expenditure',['record_id' => $record_id]);

		$this->load->view('admin/header');
		$this->load->view('admin/operation/expenditure-edit',['expenditure' => $expenditure, 'expenditures' => $expenditures]);
		$this->load->view('admin/footer');		
	}
	public function deleteExpenditure($record_id){
		$expenditure = $this->Common_model->findById('operation_equipment',['expenditure_id' => $record_id]);
		if(isset($expenditure)){
			$this->session->set_flashdata('message','danger_Can not perform this operation. Because Other value is inserted Under this operation Equipment');
		}
		else{
			//$this->Common_model->delete_info('record_id',$record_id,'expenditure');
			//$this->session->set_flashdata('success','Expenditure Name Deleted Successfully');
			if($this->Common_model->delete_info('record_id',$record_id,'expenditure')){
				$this->session->set_flashdata('message',DELETE_MSG);
			}else{
				$this->session->set_flashdata('message',DELETE_ERROR_MSG);
			}
		}
		redirect(base_url().'operation/expenditure');
	}
}
?>