<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Purchase_order extends MY_Controller
{



	static $library 	 = array('user_agent', 'Numbertowords');
	
	private $type;
    private $tBUrl;

	public function __construct()
	{
		parent::__construct();

		$this->load->library(self::$library);
		$this->type = $this->input->get('type') === 'optic' ? 'optic' : 'medicine';
        $this->loadModel('PurchaseOrder_model');

		$this->load->model(['PurchaseDetails_model'=>'podM','DrugMedicine_model'=>'medicineM']);

		$this->title    	= "Purchase " . ($this->type === 'optic' ? 'Optics' : 'Medicine');
        $this->bUrl     	= 'purchase_order';
        $this->tBUrl     	= $this->bUrl.'?type='.$this->type;

	}


	 public function index()
    {
		$from_date 	= $this->input->get('from_date')??date('Y-m-d');
		$to_date 	= $this->input->get('to_date')??date('Y-m-d');
		if (!admin()) {
			$where['show_hide'] = 'Show';
		}

		$where = [
			'purchase_date >=' => $from_date,
			'purchase_date <=' => $to_date,
		];

        $this->data = [
            'title'     	=> 'All '.$this->title,
            'values'    	=> $this->model->order_by('purchase_id', 'DESC')->where($where)->all(),
            'type'      	=> $this->type,
            'from_date'		=> $from_date,
            'to_date'      	=> $to_date,
        ];
        
        $this->render('admin/purchase_order/index');
    }

	public function create()
    {
        $this->data = [
            'title'         => 'Create '.$this->title,
			 'type'      	=> $this->type,
        ];
		if($this->type=='optic'){
			$this->render('admin/purchase_order/create_optic');
		}else{
			$this->render('admin/purchase_order/create');
		}
        
    }

	 public function saveOrUpdate()
    {
            $input			= $this->input->post();
            $update_id		= $input['update_id'];
			$date 			= $input['purchase_date'];
			$prefix         = date('Ymd', strtotime($date));
            $this->db->trans_start();

            if(!$update_id){
                $purchase               = $this->model->select_max('purchase_no')->first();
                $purchase_no            = (int) ($purchase->purchase_no ?? 0) + 1;
                $input['purchase_no']   = $purchase_no;
            }else{
				$this->deleteStock($update_id);
			}

			$input['prefix']    = $prefix;
            $data   = $this->model->filterTableData($input);
            $id     = $this->model->updateOrInsert($data, $update_id);
            $this->podM->getDelete($id, 'purchase_order_id');

			$product_ids = $input['product_id'];
			foreach ($product_ids as $key => $value) {
				$extRow 	= ['purchase_order_id' => $id, 'purchase_date' => $date];
				$row 		= $this->podM->filterBatchRow($input, $key, $extRow);
				$detailId  	=  $this->podM->create($row);
				$this->updateStock($value, $row['order_qty'], $date, $detailId, $row['unit_price'], $row['sales_price']);
			}
            
            $this->db->trans_complete();
            
            $this->crudAlertMessage($update_id, $this->tBUrl); 
    }


	public function edit($record_id)
    {
		$value = $this->model->find($record_id);
        $this->data = [
            'title'         => 'Edit '.$this->title,
			 'type'      	=> $this->type,
			 'value'		=> $value,
			 'values'    	=> $this->podM->where('purchase_order_id', $record_id)->all()
        ];
        
		if($this->type=='optic'){
			$this->render('admin/purchase_order/create_optic');
		}else{
			$this->render('admin/purchase_order/create');
		}
    }

	
	public function view($purchase_id)
	{
		$value = $this->model->with('supplier')->find($purchase_id);
		// dd(	$value );

		 $this->data = [
            'title'         => $this->title.' Invoice',
			 'type'      	=> $this->type,
			 'value'		=> $value,
			 'supplier'		=> $value->supplier??[],
			 'values'    	=> $this->podM->where('purchase_order_id', $purchase_id)->all()
        ];
        $this->render('admin/purchase_order/invoice');

	}
	public function view2($purchase_id){
		redirect($this->bUrl.'/view/'.$purchase_id, 'refresh'); 
	}

	public function barcode($purchase_order_details_id)
	{
		$data['title'] = "Generate Barcode";
		$data['page_title'] = "Generate Barcode";
		$data['info_header'] = "";
		$data['signatureType'] = 'Staff';


		$where = array('purchase_order_details.purchase_order_details_id ' => $purchase_order_details_id);
		$options = array(
			'joins' => array(
				array(
					'table' => 'product_name',
					'condition' => 'product_name.record_id = purchase_order_details.product_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'generic_names',
					'condition' => 'generic_names.record_id = product_name.product_category_generic_name_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'units',
					'condition' => 'units.record_id = purchase_order_details.unit_id',
					'jointype' => 'LEFT'
				),

			),
			'select' => 'purchase_order_details.*,product_name.product_name,product_name.product_category,units.unit_short_name,generic_names.generic_name',
			'where' => $where,
			'order' => array(
				'purchase_order_details.purchase_order_details_id' => 'asc',
			),
		);
		$product = $this->Common_model->commonJoinsRow("purchase_order_details", $options);
		$data['redirect'] = base_url("purchase_order/view/$product->purchase_order_id");
		$data['product'] = $product;
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/purchase_order/barcode', $data);
		$this->load->view('admin/layouts/footer');
	}

	public function generate_barcode()
	{
		$purchase_order_details_id = $this->input->post('purchase_order_details_id');
		$product_id = $this->input->post('product_id');
		$data['code_no'] = $purchase_order_details_id . ' - ' . $product_id . '.jpg';
		$data['quantity'] = $this->input->post('quantity');
		$this->load->view('admin/purchase_order/barcode_list', $data);
	}

	public function delete($id)
	{
		$this->deleteStock($id);
		$this->model->getDelete($id, 'purchase_id');
		$this->podM->getDelete($id, 'purchase_order_id');
		$this->crudAlertMessage($id, $this->tBUrl, true); 
	}

	public function load_product()
	{
		$purchase_type = $this->input->post('purchase_type');
		$supplier_id = $this->input->post('supplier_id');
		$warehouse = $this->input->post('warehouse');
			
		$option = "<option value=''>--Select $purchase_type--</option>";
		$products = $this->Common_model->getAllProduct($supplier_id, $purchase_type, $warehouse, 0);
		// ddd($products);
		$prodArr = [];
		$serializedArr = [];
		foreach($products as $prod){
			$prodArr[] = $prod->record_id;
			$serializedArr[$prod->record_id] = new stdClass();
			$serializedArr[$prod->record_id] = $prod;
		}
		$newProducts = [];
		if(sizeof($prodArr) > 0){
			//$newProducts = $this->db->select('*')->from('product_name_new')->where_in('product_id', $prodArr)->get()->result();

			foreach ($products as $newProd) {
				$value = new stdClass();
				if(isset($serializedArr[$newProd->record_id])){
					$value = $serializedArr[$newProd->record_id];
				}
				$product_category = !empty($value->dosage_name) ? ' - ' . $value->dosage_name : '';
				$generic_name = !empty($value->generic_name) ? ' - ' . $value->generic_name : '';
				$strength = !empty($value->strength) ? ' - ' . $value->strength : '';
				$dose = !empty($value->dosage_name) ? ' - ' . $value->dosage_name : '';
				$stock = !empty($value->product_stock) ? $value->product_stock : 0;
				$option .= '<option value="' . $newProd->record_id . '" data-product_name="' . $newProd->brand_name . $product_category . $generic_name . $strength . '" data-unit_price="' . $newProd->unit_price . '" data-unit_mrp="' . $newProd->unit_mrp . '" data-unit_id="1" data-unit_name="Pcs" data-product_code="' . $newProd->record_id . '" data-stock="' . $stock. '">' . $newProd->brand_name . $strength .$dose." - ".$newProd->record_id.'</option>';
			}
		}
	
		echo $option;
		exit;
	}

	public function delete_stock()
	{
		$id = $this->input->post('id');
		
		$order_info = $this->Common_model->findById('purchase_order_details', array('purchase_order_details_id' => $id));
		$stock_info = $this->Common_model->findById('drug_medicine', array('record_id' => $order_info->product_id));
		$new_stock = $stock_info->product_stock-$order_info->order_qty;
		$this->Common_model->updateData('drug_medicine', array('product_stock' => $new_stock), array('record_id' => $stock_info->record_id));

		$stock_history = $this->Common_model->findById('product_stock_history', array('product_id' => $stock_info->record_id, 'stock_date' =>$order_info->purchase_date));
			$history = array(
				'stock_qty' => $new_stock,
				'purchase_qty' => $stock_history->purchase_qty-$order_info->order_qty
			);
			$this->Common_model->updateData('product_stock_history', $history, array('record_id' => $stock_history->record_id));
		//echo $new_stock;
		exit;
	}
	public function delete_purchase_stock($id)
	{
	$purchase_order_details = $this->Common_model->findAll('purchase_order_details',array('purchase_order_id'=>$id),'purchase_order_details_id','asc');
			foreach($purchase_order_details as $detail){
				$stock_info = $this->Common_model->findById('drug_medicine', array('record_id' => $detail->product_id));
				$new_stock = $stock_info->product_stock-$detail->order_qty;
				$this->Common_model->updateData('drug_medicine', array('product_stock' => $new_stock), array('record_id' => $stock_info->record_id));

				$stock_history = $this->Common_model->findById('product_stock_history', array('product_id' => $stock_info->record_id, 'stock_date' =>$detail->purchase_date));
					$history = array(
						'stock_qty' => $new_stock,
						'purchase_qty' => $stock_history->purchase_qty-$detail->order_qty
					);
					$this->Common_model->updateData('product_stock_history', $history, array('record_id' => $stock_history->record_id));

			}
			//exit;
	}

	public function get_product() {
        $term = $this->input->get('term');
        $results = $this->medicineM->search_product($term);
        
        echo json_encode($results);
    }


	private function updateStock($product_id, $qty, $date, $detailId, $price=0, $salePrice=0){
		updateStock($product_id,$detailId, $qty, $date,'purchase',$price, $salePrice);
	}

	private function deleteStock($id){
		$purchase_order_details = $this->Common_model->findAll('purchase_order_details',['purchase_order_id'=>$id, 'purchase_type'=>'Medicine'],'purchase_order_details_id','asc');
		foreach($purchase_order_details as $detail){
			deleteStock($detail->purchase_order_details_id, $detail->product_id);
		}
		
	}



	function recovery_data(){
		$user_type = $this->session->ses_user_type;
		if ($user_type == "admin" ) {
		$this->db->trans_start();
		$product_data = $this->db->select('record_id as product_id')->where('type','Medicine')->from('drug_medicine')->get()->result();
		$a= [];
		foreach($product_data as $row){
			$purchaseData = $this->recoveryQuery($row->product_id,'purchase_order_details', 'purchase_type');
			$salesData = $this->recoveryQuery($row->product_id,'sales_order_details', 'sales_type');
			$returnData = $this->recoveryQuery($row->product_id,'return_details','return_type', 'return_qty');
			$salesReturnData = $this->recoveryQuery($row->product_id,'customer_return_details','return_type', 'return_qty');
			$currentStock = ($purchaseData+$salesReturnData) - ($salesData+$returnData);

			if ($currentStock <0){
				$a[$row->product_id] = $currentStock;
				$currentStock = 0;
			}

			$this->db->where('record_id', $row->product_id)->where('type','Medicine')->update('drug_medicine', ['product_stock'=>$currentStock]);
			
		}
		
		$this->db->trans_complete();
		if (count($a) >0){
			dd($a);
		}

		dd('Successful data recovery complete');
	}
		// echo json_encode($purchase_data);
	}

	private function recoveryQuery($id, $table, $type, $field ='order_qty'){
		return	$this->db->select("SUM($field) as qty")->group_by('product_id')
		->where($type, 'Medicine')
		->where('product_id', $id)->get($table)->row()->qty??0;
	}


	public function history_data_recovery(){
		$user_type = $this->session->ses_user_type;
		if ($user_type == "admin" ) {
			$this->db->trans_start();
			$this->db->truncate('product_stocks');
			$purchaseData = $this->db->select('*')->where('purchase_type', 'Medicine')->get('purchase_order_details')->result();
			foreach($purchaseData as $value){
				$data = [
					'created_by' 		=> $value->created_by,
					'created_at' 		=> $value->created_at,
					'product_id' 		=> $value->product_id,
					'details_id'		=> $value->purchase_order_details_id, 
					'type'				=> 'purchase',
					'quantity'			=> $value->order_qty,
					'price'				=> $value->unit_price,
					'sale_price'		=> $value->sales_price,
					'date'				=> $value->purchase_date
				];
				$this->db->insert('product_stocks',$data);
			}

			$salesData = $this->db->select('sod.*')
			->from('sales_order_details sod')
			->where('sales_type', 'Medicine')->get()->result();

			foreach($salesData as $value){
				$data = [
					'created_by' 		=> $value->created_by,
					'created_at' 		=> $value->created_at,
					'product_id' 		=> $value->product_id,
					'details_id'		=> $value->sales_order_details_id , 
					'type'				=> 'sales',
					'quantity'			=> $value->order_qty,
					'price'				=> $value->purchase_price,
					'sale_price'		=> $value->sales_price,
					'date'				=> $value->sales_date
				];
				$this->db->insert('product_stocks',$data);
			}

			$returnData = $this->db->select('crd.*, sod.purchase_price')
			->from('customer_return_details crd')
			->join('sales_order_details sod', 'sod.sales_order_details_id = crd.sales_order_details_id AND sod.sales_type = "Medicine"', 'left')
			->where('crd.return_type', 'Medicine')->get()->result();

			foreach($returnData as $value){
				$data = [
					'created_by' 		=> $value->created_by,
					'created_at' 		=> $value->created_at,
					'product_id' 		=> $value->product_id,
					'details_id'		=> $value->return_details_id, 
					'type'				=> 'sales_return',
					'quantity'			=> $value->return_qty,
					'price'				=> $value->purchase_price,
					'sale_price'		=> $value->sales_price,
					'date'				=> $value->return_date
				];
				$this->db->insert('product_stocks',$data);
			}

			$salesData = $this->db->select('rd.*')
			->from('return_details rd')
			->where('return_type', 'Medicine')->get()->result();

			foreach($salesData as $value){
				$data = [
					'created_by' 		=> $value->created_by,
					'created_at' 		=> $value->created_at,
					'product_id' 		=> $value->product_id,
					'details_id'		=> $value->return_details_id , 
					'type'				=> 'purchase_return',
					'quantity'			=> $value->return_qty,
					'price'				=> $value->purchase_price,
					'sale_price'		=> 0,
					'date'				=> $value->return_date
				];
				$this->db->insert('product_stocks',$data);
			}

		

			$this->db->trans_complete();

			dd('Successful data recovery complete');
		}
	}


	
}
