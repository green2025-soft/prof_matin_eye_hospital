<?php

defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Reports extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('pagination');
    }
    public function pharmacy_balance_sheet()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Balance Sheet';
            $data['page_title'] = 'Balance Sheet';
            $data['info_header'] = '';

            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $created_by = $this->input->get('created_by');

            if (!isset($from_date) and !isset($to_date) and !isset($created_by)) {
                $from_date = $to_date = date('Y-m-d');
            }

            /*BF = Before Fund/Cash*/

            /***Sales***/
            $where = array();
            $where['sales_date < '] = $from_date;
            if (!empty($created_by)) {
                $where['created_by'] = $created_by;
            }
            $sales_orders_amount = $this->Common_model->calCulateSum('sales_orders', $where, 'grand_net_total');
            $sales_orders_amount = isset($sales_orders_amount) ? $sales_orders_amount : 0;

            $where = array();
            $where['mr_date < '] = $from_date;
            if (!empty($created_by)) {
                $where['created_by'] = $created_by;
            }
            $mrs_amount = $this->Common_model->calCulateSum('mr', $where, 'mr_amount');
            $mrs_amount = isset($mrs_amount) ? $mrs_amount : 0;

            $where = array();
            $where['return_date < '] = $from_date;
            if (!empty($created_by)) {
                $where['created_by'] = $created_by;
            }
            $return_manages_amount = $this->Common_model->calCulateSum('return_manages', $where, 'grand_return_amount');
            $return_manages_amount = isset($return_manages_amount) ? $return_manages_amount : 0;

            $where = array();
            $where['income_type'] = 'Pharmacy';
            $where['income_date < '] = $from_date;
            if (!empty($created_by)) {
                $where['created_by'] = $created_by;
            }
            $incomes_amount = $this->Common_model->calCulateSum('incomes', $where, 'voucher_amount');
            $incomes_amount = isset($incomes_amount) ? $incomes_amount : 0;

            /***Sales***/

            /***Purchase***/
            $where = array();
            $where['purchase_date < '] = $from_date;
            if (!empty($created_by)) {
                $where['created_by'] = $created_by;
            }
            $purchase_orders_amount = $this->Common_model->calCulateSum('purchase_orders', $where, 'grand_net_total');
            $purchase_orders_amount = isset($purchase_orders_amount) ? $purchase_orders_amount : 0;

            $where = array();
            $where['payment_date < '] = $from_date;
            if (!empty($created_by)) {
                $where['created_by'] = $created_by;
            }
            $supplier_payments_amount = $this->Common_model->calCulateSum('supplier_payments', $where, 'payment_amount');
            $supplier_payments_amount = isset($supplier_payments_amount) ? $supplier_payments_amount : 0;

            $where = array();
            $where['return_date < '] = $from_date;
            if (!empty($created_by)) {
                $where['created_by'] = $created_by;
            }
            $returns_amount = $this->Common_model->calCulateSum('customer_return_manages', $where, 'grand_return_amount');
            $returns_amount = isset($returns_amount) ? $returns_amount : 0;

            $where = array();
            $where['approval'] = 'Approved';
            $where['expense_type'] = 'Pharmacy';
            $where['expense_date < '] = $from_date;

            if (!empty($created_by)) {
                $where['created_by'] = $created_by;
            }
            $expenses_amount = $this->Common_model->calCulateSum('expenses', $where, 'voucher_amount');
            $expenses_amount = isset($expenses_amount) ? $expenses_amount : 0;


            $inc_amount = $sales_orders_amount + $mrs_amount +  $return_manages_amount + $incomes_amount;
            $exp_amount = $purchase_orders_amount + $supplier_payments_amount  + $returns_amount + $expenses_amount;
            $hand_cash_value = $inc_amount - $exp_amount;

            //var_dump($hand_cash) ; die; 

            $values = array();

            $hand_cash = new stdClass;
            $hand_cash->type = "Hand Cash";
            $hand_cash->particular = $hand_cash->type;
            $hand_cash->date = date('Y-m-d', strtotime('-1 day', strtotime($from_date)));
            $hand_cash->amount = 0;
            $hand_cash->paid = $hand_cash_value;
            $hand_cash->created_at = $hand_cash->date;
            // var_dump($obj);die;
            // $values[] = $obj;



            /*BF = Before Fund/Cash*/

            /***Sales***/
            $where = array();
            if (!admin()) {
                $where['show_hide'] = "Show";
            }
            if (!empty($from_date) && !empty($to_date)) {
                $where['sales_date >='] = $from_date;
                $where['sales_date <='] = $to_date;
            } else if (!empty($from_date) && empty($to_date)) {
                $where['sales_date'] = $from_date;
            } else if (empty($from_date) && !empty($to_date)) {
                $where['sales_date'] = $to_date;
            }
            if (!empty($created_by)) {
                $where['created_by'] = $created_by;
            }
            $sales_orders = $this->Common_model->findAll('sales_orders', $where, 'sales_id', 'asc');

            foreach ($sales_orders as $key => $value) {
                $value->record_id = $value->sales_id;
                $value->date = $value->sales_date;
                $customer = $this->Common_model->findById('patient', array('record_id' => $value->customer_id));
                $customer_name = isset($customer) ? $customer->name . '[' . $customer->record_id . ']' : '';
                $obj = new stdClass;
                $obj->type = "Sales";
                $obj->customer_id = $value->customer_id;
                $obj->invoice_no = 'S' . $value->sales_id;
                $obj->particular = $obj->invoice_no . ' - ' . $customer_name . view("sales_order/view2/$value->sales_id");
                $obj->date = $value->sales_date;
                $obj->amount = $value->grand_net_total;
                $obj->paid = $value->paid_amount;
                $obj->created_at = $value->created_at;
                $values[] = $obj;
            }
            $where = array();
            if (!admin()) {
                $where['show_hide'] = "Show";
            }
            if (!empty($from_date) && !empty($to_date)) {
                $where['mr_date >='] = $from_date;
                $where['mr_date <='] = $to_date;
            } else if (!empty($from_date) && empty($to_date)) {
                $where['mr_date'] = $from_date;
            } else if (empty($from_date) && !empty($to_date)) {
                $where['mr_date'] = $to_date;
            }
            if (!empty($created_by)) {
                $where['created_by'] = $created_by;
            }
            $mrs = $this->Common_model->findAll('mr', $where, 'mr_id', 'asc');
            foreach ($mrs as $key => $value) {
                $customer = $this->Common_model->findById('patient', array('record_id' => $value->customer_id));
                $customer_name = isset($customer) ? $customer->name . '[' . $customer->record_id . ']' : '';
                $obj = new stdClass;
                $obj->type = "Due";
                $obj->customer_id = $value->customer_id;
                $obj->invoice_no = $value->prefix . $value->mr_no;
                $obj->particular = $obj->invoice_no . '(' . $obj->type . ') - ' . $customer_name;
                $obj->date = $value->mr_date;
                $obj->amount = 0;
                $obj->paid = $value->mr_amount;
                $obj->created_at = $value->created_at;
                $values[] = $obj;
            }
            $where = array();
            if (!empty($from_date) && !empty($to_date)) {
                $where['return_date >='] = $from_date;
                $where['return_date <='] = $to_date;
            } else if (!empty($from_date) && empty($to_date)) {
                $where['return_date'] = $from_date;
            } else if (empty($from_date) && !empty($to_date)) {
                $where['return_date'] = $to_date;
            }
            if (!empty($created_by)) {
                $where['created_by'] = $created_by;
            }
            $return_manages = $this->Common_model->findAll('return_manages', $where, 'return_id', 'asc');
            foreach ($return_manages as $key => $value) {
                $supplier = $this->Common_model->findById('drug_manufacturer', array('record_id' => $value->supplier_id));
                $supplier_name = isset($supplier) ? $supplier->manufacturer_name . '[' . $supplier->record_id . ']' : '';
                $obj = new stdClass;
                $obj->type = "Return";
                $obj->supplier_id = $value->supplier_id;
                $obj->invoice_no = $value->prefix . $value->return_no;
                $obj->particular = $obj->invoice_no . '(' . $obj->type . ') - ' . $supplier_name;
                $obj->date = $value->return_date;
                $obj->amount = $value->grand_return_amount;
                $obj->paid = $value->grand_return_amount;
                $obj->created_at = $value->created_at;
                $values[] = $obj;
            }
            $where = array();
            if (!admin()) {
                $where['show_hide'] = "Show";
            }
            $where['income_type'] = 'Pharmacy';
            if (!empty($from_date) && !empty($to_date)) {
                $where['income_date >='] = $from_date;
                $where['income_date <='] = $to_date;
            } else if (!empty($from_date) && empty($to_date)) {
                $where['income_date'] = $from_date;
            } else if (empty($from_date) && !empty($to_date)) {
                $where['income_date'] = $to_date;
            }
            if (!empty($created_by)) {
                $where['created_by'] = $created_by;
            }
            $incomes = $this->Common_model->findAll('incomes', $where, 'income_id', 'asc');
            foreach ($incomes as $key => $value) {
                $obj = new stdClass;
                $obj->type = "Income Entry";
                $obj->supplier_id = 0;
                $obj->invoice_no = $value->prefix . $value->income_no;
                $obj->particular = $obj->invoice_no . '(' . $obj->type . ')' . view("income/view2/$value->income_id");
                $obj->date = $value->income_date;
                $obj->amount = 0;
                $obj->paid = $value->voucher_amount;
                $obj->created_at = $value->created_at;
                $values[] = $obj;
            }
            function cb($a, $b)
            {
                return strtotime($a->created_at) - strtotime($b->created_at);
            }
            usort($values, 'cb');
            $data['sales'] = $values;
            /***Sales***/

            /***Purchase***/

            $values = array();

            if (!admin()) {
                $where['show_hide'] = "Show";
            }

            // $opening_cost_where = array();
            // $opening_cost_where['opening_date is not '] = NULL;
            // $opening_cost_where['opening_date >= '] = $from_date;
            // $opening_cost_where['opening_date <= '] = $to_date;
            // $opening_amount = $this->Common_model->calCulateSum('product_name', $opening_cost_where, "opening_price");
            // $opening_amount = isset($opening_amount) ? $opening_amount : 0;
            // $obj = new stdClass;
            // $obj->type = "Opening Cost";
            // $obj->supplier_id = 0;
            // $obj->invoice_no = "";
            // $obj->particular = $obj->type;
            // $obj->date = $from_date;
            // $obj->amount = $opening_amount;
            // $obj->paid = $opening_amount;
            // $obj->created_at = $obj->date;
            // $values[] = $obj;


            $where = array();
            if (!empty($from_date) && !empty($to_date)) {
                $where['purchase_date >='] = $from_date;
                $where['purchase_date <='] = $to_date;
            } else if (!empty($from_date) && empty($to_date)) {
                $where['purchase_date'] = $from_date;
            } else if (empty($from_date) && !empty($to_date)) {
                $where['purchase_date'] = $to_date;
            }
            if (!empty($created_by)) {
                $where['created_by'] = $created_by;
            }
            $purchase_orders = $this->Common_model->findAll('purchase_orders', $where, 'purchase_id', 'asc');

            foreach ($purchase_orders as $key => $value) {
                $value->record_id = $value->purchase_id;
                $value->date = $value->purchase_date;
                $supplier = $this->Common_model->findById('drug_manufacturer', array('record_id' => $value->supplier_id));
                $supplier_name = isset($supplier) ? $supplier->manufacturer_name . '[' . $supplier->record_id . ']' : '';
                $obj = new stdClass;
                $obj->type = "Purchase";
                $obj->supplier_id = $value->supplier_id;
                $obj->invoice_no = 'P' . $value->purchase_id;
                $obj->particular = $obj->invoice_no . ' - ' . $supplier_name . view("purchase_order/view2/$value->purchase_id");
                $obj->date = $value->purchase_date;
                $obj->amount = $value->grand_net_total;
                $obj->paid = $value->paid_amount;
                $obj->created_at = $value->created_at;
                $values[] = $obj;
            }

            $where = array();
            if (!admin()) {
                $where['show_hide'] = "Show";
            }
            if (!empty($from_date) && !empty($to_date)) {
                $where['payment_date >='] = $from_date;
                $where['payment_date <='] = $to_date;
            } else if (!empty($from_date) && empty($to_date)) {
                $where['payment_date'] = $from_date;
            } else if (empty($from_date) && !empty($to_date)) {
                $where['payment_date'] = $to_date;
            }

            if (!empty($created_by)) {
                $where['created_by'] = $created_by;
            }

            $supplier_payments = $this->Common_model->findAll('supplier_payments', $where, 'payment_id', 'asc');

            foreach ($supplier_payments as $key => $value) {
                $supplier = $this->Common_model->findById('drug_manufacturer', array('record_id' => $value->supplier_id));
                $supplier_name = isset($supplier) ? $supplier->manufacturer_name . '[' . $supplier->record_id . ']' : '';
                $obj = new stdClass;
                $obj->type = "Payment";
                $obj->supplier_id = $value->supplier_id;
                $obj->invoice_no = $value->prefix . $value->payment_no;
                $obj->particular = $obj->invoice_no . '(' . $obj->type . ') - ' . $supplier_name;
                $obj->date = $value->payment_date;
                $obj->amount = 0;
                $obj->paid = $value->payment_amount;
                $obj->created_at = $value->created_at;
                $values[] = $obj;
            }
            $where = array();
            if (!empty($from_date) && !empty($to_date)) {
                $where['return_date >='] = $from_date;
                $where['return_date <='] = $to_date;
            } else if (!empty($from_date) && empty($to_date)) {
                $where['return_date'] = $from_date;
            } else if (empty($from_date) && !empty($to_date)) {
                $where['return_date'] = $to_date;
            }
            if (!empty($created_by)) {
                $where['created_by'] = $created_by;
            }
            $returns = $this->Common_model->findAll('customer_return_manages', $where, 'return_id', 'asc');
            
            foreach ($returns as $key => $value) {
                $customer = $this->Common_model->findById('patient', array('record_id' => $value->customer_id));
                $customer_name = isset($customer) ? $customer->name . '[' . $customer->record_id . ']' : '';
                $obj = new stdClass;
                $obj->type = "Return";
                $obj->customer_id = $value->customer_id;
                $obj->invoice_no = $value->prefix . $value->return_no;
                $obj->particular = $obj->invoice_no . '(' . $obj->type . ') - ' . $customer_name;
                $obj->date = $value->return_date;
                $obj->amount = 0;
                $obj->paid = $value->grand_return_amount;
                $obj->created_at = $value->created_at;
                $values[] = $obj;
            }
            $where = array();
            if (!admin()) {
                $where['show_hide'] = "Show";
            }
            $where['approval'] = 'Approved';
            $where['expense_type'] = 'Pharmacy';
            if (!empty($from_date) && !empty($to_date)) {
                $where['expense_date >='] = $from_date;
                $where['expense_date <='] = $to_date;
            } else if (!empty($from_date) && empty($to_date)) {
                $where['expense_date'] = $from_date;
            } else if (empty($from_date) && !empty($to_date)) {
                $where['expense_date'] = $to_date;
            }
            if (!empty($created_by)) {
                $where['created_by'] = $created_by;
            }
            $expenses = $this->Common_model->findAll('expenses', $where, 'expense_id', 'asc');
            foreach ($expenses as $key => $value) {
                $obj = new stdClass;
                $obj->type = "Expense";
                $obj->supplier_id = 0;
                $obj->invoice_no = $value->prefix . $value->expense_no;
                $obj->particular = $obj->invoice_no . '(' . $obj->type . ')' . view("expense/view2/$value->expense_id");
                $obj->date = $value->expense_date;
                $obj->amount = 0;
                $obj->paid = $value->voucher_amount;
                $obj->created_at = $value->created_at;
                $values[] = $obj;
            }
            usort($values, 'cb');
            $data['purchases'] = $values;
            /***Purchase***/




            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;
            $data['created_by'] = $created_by;
            $data['hand_cash'] = $hand_cash;
            $data['redirect'] = base_url('reports/pharmacy_balance_sheet');
            $data['signatureType'] = 'Staff';
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/reports/pharmacy_balance_sheet', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function view($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Test Invoice';
            $data['page_title'] = 'Test Invoice';
            $data['info_header'] = '';
            $data['redirect'] = base_url("sales_test");
            $data['value'] = $this->Common_model->findById('create_bill', array('record_id' => $record_id));
            $data['values'] = $this->Common_model->findAll('sales_test', array('invoice_no' => $record_id), 'record_id', 'asc');
            if (isset($data['value'])) {
                $data['patient'] = $this->Common_model->findById('patient', array('record_id' => $data['value']->patient_id));
                $data['doctor'] = $this->Common_model->findById('doctor', array('record_id' => $data['value']->doctor_id));
            }
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_invoice/invoice', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function patient_ledger()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Patient Ledger';
            $data['page_title'] = 'Patient Ledger';
            $data['values'] = $this->Common_model->findAll('due_collections', array(), 'mr_id', 'desc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/reports/patient_ledger', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function show_patient_ledger()
    {
        $from_date = $this->input->post('from_date');
        $to_date = $this->input->post('to_date');
        $patient_id = $this->input->post('patient_id');
        $data['patient_id'] = $patient_id;
        $data['from_date'] = $from_date;
        $data['to_date'] = $to_date;
        $where = array();
        if (!admin()) {
            $where['show_hide'] = "Show";
        }
        if (!empty($from_date) && !empty($to_date)) {
            $where['date >='] = $from_date;
            $where['date <='] = $to_date;
        } else if (!empty($from_date) && empty($to_date)) {
            $where['date'] = $from_date;
        } else if (empty($from_date) && !empty($to_date)) {
            $where['date'] = $to_date;
        }

        if (!empty($patient_id)) {
            $where['patient_id'] = $patient_id;
        }
        $data['values'] = $this->Common_model->findAll('create_bill', $where, 'record_id', 'asc');

        $this->load->view('admin/reports/show_patient_ledger', $data);
    }

    public function patient_due_list()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Patient Due List';
            $data['page_title'] = 'Patient Due List';
            $where = array();
            if (!admin()) {
                $where['show_hide'] = "Show";
            }
            $data['values'] = $this->Common_model->findAll('due_collections', $where, 'mr_id', 'desc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/reports/patient_due_list', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function show_patient_due_list()
    {
        $from_date = $this->input->post('from_date');
        $to_date = $this->input->post('to_date');
        $patient_id = $this->input->post('patient_id');
        $data['patient_id'] = $patient_id;
        $data['from_date'] = $from_date;
        $data['to_date'] = $to_date;

        $discount_type = $this->input->post('discount_type');
        $where_in = array();

        $where_in_column = 'discount_type';
        if ($discount_type == 1) {
            $where_in = array(1, 4);
        }
        if ($discount_type == 2) {
            $where_in = array(2, 5);
        }
        $reference_by = $this->input->post('reference_by');



        $where = array();
        if (!admin()) {
            $where['show_hide'] = "Show";
        }
        $where['type != '] = 'Collection';
        if (!empty($from_date) && !empty($to_date)) {
            $where['date >='] = $from_date;
            $where['date <='] = $to_date;
        } else if (!empty($from_date) && empty($to_date)) {
            $where['date'] = $from_date;
        } else if (empty($from_date) && !empty($to_date)) {
            $where['date'] = $to_date;
        }

        if (!empty($patient_id)) {
            $where['patient_id'] = $patient_id;
        }
        if (!empty($reference_by)) {
            $where['reference_by'] = $reference_by;
        }
        //$data['values'] = $this->Common_model->findAll('create_bill', $where, 'record_id', 'asc');
        $data['values'] = $this->Common_model->findAllWhereIn('create_bill', $where, $where_in, $where_in_column, 'record_id', 'asc');

        $this->load->view('admin/reports/show_patient_due_list', $data);
    }

    public function cash_report()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Total Cash Report';
            $data['page_title'] = 'Total Cash Report';
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/reports/cash_report_index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function monthly_cash_report()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['report_type'] = 'total';
            $data['title'] = 'Monthly Cash Report';
            $data['page_title'] = 'Monthly Cash Report';
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/reports/monthly_cash_report_index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function show_cash_report()
    {
        
        $date_from = $this->input->post('date_from');
        $date_to = $this->input->post('date_to');
        $report_type = $this->input->post('report_type');
        $type = $this->input->post('type');

        $previous_date =  date_sub(date_create($date_from), date_interval_create_from_date_string("1 days"));
        $previous_date = date_format($previous_date, "Y-m-d");

        $start_date = $date_from;
        $grand_total_income = 0;
        $grand_total_expense = 0;
        $grand_total_balance = 0;
        $data['total_paid_amount'] = 0;
        $data['total_expense_amount'] = 0;
        $data['total_balance'] = 0;

        $grand_total_incomeBF = 0;
        $grand_total_expenseBF = 0;
        $grand_total_balanceBF = 0;
        $data['total_paid_amountBF'] = 0;
        $data['total_expense_amountBF'] = 0;
        $data['total_balanceBF'] = 0;

        if ($type == "Total") {
            $count = 0;
            $year = $this->input->post('year');
            $month = $this->input->post('month');
            $date_from = date("$year-$month-01");
            $days = cal_days_in_month(CAL_GREGORIAN, $month, $year);
            $date_to = date("$year-$month-$days");
            $previous_date =  date_sub(date_create($date_from), date_interval_create_from_date_string("1 days"));
            $previous_date = date_format($previous_date, "Y-m-d");

            /**B/F**/
            /* $pathologyWhereBF = array();
            $pathologyWhereBF['date <= '] = $previous_date ;
            $pathologyWhereBF['type'] = 'Test Invoice';
            $operationWhereBF['date <= '] = $previous_date ;
            $operationInvoiceWhereBF['date <= '] = $previous_date ;
            $operationInvoiceWhereBF['type'] = 'Admission' ;
            $operationWhereBF['type'] = 'Operation' ;

            $operationDetailsWhereBF = array() ;
            $operationDetailsWhereBF['operation_date <= '] = $previous_date ;

            $ecgWhereBF['date <= '] = $previous_date ;
            $ecgWhereBF['test_category'] = 'ECG' ;
            $xrayWhereBF['date <= '] = $previous_date ;
            $xrayWhereBF['test_category'] = '%X-Ray%' ; 
            $ultraWhereBF['date <= '] = $previous_date ;
            $ultraWhereBF['test_category like'] = 'Ultrasonogram' ;

            $generalIncomeWhereBF = array();
            $generalIncomeWhereBF['date <= '] = $previous_date ;

            $consultancyWhereBF = array();
            $consultancyWhereBF['type'] = 'Appointment' ;
            $consultancyWhereBF['date <= '] = $previous_date ;

            $commission_patholgyWhereBF = array();
            $commission_patholgyWhereBF['type'] = 'Test Invoice' ;  
            $commission_patholgyWhereBF['date <= '] = $previous_date ;  



            $operation_commissionWhereBF = array();
            $operation_commissionWhereBF['operation_date <= '] = $previous_date ;

            $sonologistExpenseWhereBF = array();
            $sonologistExpenseWhereBF['date <= '] = $previous_date ;

            $generalExpenseWhereBF = array();
            $generalExpenseWhereBF['date <= '] = $previous_date ; 
            $staffSalaryWhereBF = array();
            $staffSalaryWhereBF['status'] = 'Paid' ; 
            $staffSalaryWhereBF['date <= '] = $previous_date ; 

            $dueCollectionWhereBF = array();
            $dueCollectionWhereBF['mr_date <= '] = $previous_date ;


            $salesWhereBF = array() ;
            $salesWhereBF['sales_from'] = 'Direct' ;
            $salesWhereBF['sales_date <= '] = $previous_date ;

            $mrWhereBF = array() ;
            $mrWhereBF['mr_date <= '] = $previous_date ;

            $emergencyWhereBF = array() ;
            $emergencyWhereBF['type'] = 'Emergency' ;
            $emergencyWhereBF['date <= '] = $previous_date ;

            $ambulanceWhereBF = array() ;
            $ambulanceWhereBF['type'] = 'Ambulance' ;
            $ambulanceWhereBF['date <= '] = $previous_date ;

            $doctorServiceWhereBF = array() ;
            $doctorServiceWhereBF['type'] = 'Doctor Service' ;
            $doctorServiceWhereBF['date <= '] = $previous_date ;

            $donorWhereBF = array() ;
            $donorWhereBF['type'] = 'Donor' ;
            $donorWhereBF['date <= '] = $previous_date ;

            $dressingWhereBF = array() ;
            $dressingWhereBF['type'] = 'Dressing' ;
            $dressingWhereBF['date <= '] = $previous_date ;

            $supplier_paymentsWhereBF = array() ;
            $supplier_paymentsWhereBF['payment_date <= '] = $previous_date ;

            $incomeWhereBF = array() ;
            $incomeWhereBF['income_type != '] = 'Pharmacy' ;
            $incomeWhereBF['income_date <= '] = $previous_date ;
            $expenseWhereBF = array() ;
            $expenseWhereBF['approval'] = 'Approved' ;
            $expenseWhereBF['expense_type != '] = 'Pharmacy' ;
            $expenseWhereBF['expense_date <= '] = $previous_date ;

            $labInWhereBF = array() ;
            $labInWhereBF['in_date <= '] = $previous_date ;



            $data['pathologyBF'] = $this->Common_model->calCulateSum('create_bill',$pathologyWhereBF,'sub_total') ;
            $data['pathology_paidBF'] = $this->Common_model->calCulateSum('create_bill',$pathologyWhereBF,'paid') ;
            $data['pathology_dueBF'] = $this->Common_model->calCulateSum('create_bill',$pathologyWhereBF,'due') ;
            $data['operationBF'] = $this->Common_model->calCulateSum('create_bill',$operationWhereBF,'sub_total') ;
            $operation_paidBF = $this->Common_model->calculateSumMultiple('create_bill',$operationWhereBF,array('paid','medicine_cost','advance')) ;
           


            $operationInvoiceBF = $this->Common_model->calculateSumMultiple('create_bill',$operationInvoiceWhereBF, array('sub_total','advance')) ;
            $data['operationInvoiceBF'] = $operationInvoiceBF->sub_total + $operationInvoiceBF->advance;

            $data['operation_paidBF'] = $operation_paidBF->paid ; 
            $data['operation_dueBF'] = $this->Common_model->calCulateSum('create_bill',$operationWhereBF,'due') ;

            $data['ecgBF'] = $this->Common_model->calCulateSum('sales_test',$ecgWhereBF,'test_price') ;
            $data['xrayBF'] = $this->Common_model->calCulateSum('sales_test',$xrayWhereBF,'test_price') ;
            $data['ultraBF'] = $this->Common_model->calCulateSum('sales_test',$ultraWhereBF,'test_price') ;


            $consultancyBF = $this->Common_model->calculateSumMultiple('create_bill',$consultancyWhereBF,array('sub_total','paid','due','doctor_commission'));
            $data['consultancyBF'] = isset( $consultancyBF) ?  $consultancyBF->sub_total : 0 ;
            $data['consultancy_paidBF'] = isset( $consultancyBF) ?  $consultancyBF->paid : 0 ;
            $data['consultancy_dueBF'] = isset( $consultancyBF) ?  $consultancyBF->due : 0 ;
            $data['consultancy_doctor_commissionBF'] = isset( $consultancyBF) ?  $consultancyBF->doctor_commission : 0 ;
            $doctor_commission_patholgyBF = $this->Common_model->calculateSumMultiple('create_bill',$commission_patholgyWhereBF,array('doctor_commission','reference_by_commission'));
            $doctor_commissionBF = isset($doctor_commission_patholgyBF)?$doctor_commission_patholgyBF->doctor_commission:0;
            $reference_by_commissionBF = isset($doctor_commission_patholgyBF)?$doctor_commission_patholgyBF->reference_by_commission:0;
            $data['doctor_commission_patholgyBF'] = $doctor_commissionBF + $reference_by_commissionBF ;


            $operation_commissionBF =  $this->Common_model->calculateSumMultiple('operation_details',$operationDetailsWhereBF,array('surgeon_commission','surgeon_assistant_commission','surgeon_team_commission','anesthesia_commission','medicine_cost','service_fee')); 
            $surgeon_commissionBF = isset($operation_commissionBF)?$operation_commissionBF->surgeon_commission:0 ;
            $anesthesia_commissionBF = isset($operation_commissionBF)?$operation_commissionBF->anesthesia_commission:0 ;
            $medicine_costBF = isset($operation_commissionBF)?$operation_commissionBF->medicine_cost:0 ;
            $surgeon_assistant_commissionBF = isset($operation_commissionBF)?$operation_commissionBF->surgeon_assistant_commission:0 ;
            $surgeon_team_commissionBF = isset($operation_commissionBF)?$operation_commissionBF->surgeon_team_commission:0 ;
            $service_feeBF = isset($operation_commissionBF)?$operation_commissionBF->service_fee:0 ;
            $data['operation_commissionBF'] =  $surgeon_commissionBF + $anesthesia_commissionBF + $medicine_costBF + $surgeon_assistant_commissionBF + $surgeon_team_commissionBF + $service_feeBF ;

            $data['sonologistExpenseBF'] = $this->Common_model->calCulateSum('sonologist',$sonologistExpenseWhereBF,'amount') ;

            $data['staffSalaryBF'] = $this->Common_model->calCulateSum('create_salary_sheet',$staffSalaryWhereBF,'net_salary') ;

            $data['dueCollectionBF'] = $this->Common_model->calCulateSum('due_collections',$dueCollectionWhereBF,'mr_amount') ;

            $sales_ordersBF = $this->Common_model->calculateSumMultiple('sales_orders',$salesWhereBF,array('grand_net_total','paid_amount','due_amount'));
            $data['sales_amountBF'] = $sales_ordersBF->grand_net_total ;
            $data['sales_paid_amountBF'] = $sales_ordersBF->paid_amount ;
            $data['sales_due_amountBF'] = $sales_ordersBF->due_amount ;
            $data['pharmacy_collectionBF'] = $this->Common_model->calCulateSum('mr',$mrWhereBF,'mr_amount') ;

            $data['supplier_paymentsBF'] = $this->Common_model->calCulateSum('supplier_payments',$supplier_paymentsWhereBF,'payment_amount') ;



            $emergencyBF = $this->Common_model->calculateSumMultiple('create_bill',$emergencyWhereBF,array('sub_total','paid','doctor_commission','others_cost')) ;
            $data['emergency_totalBF'] = isset($emergencyBF)?$emergencyBF->sub_total:0;
            $data['emergency_paidBF'] = isset($emergencyBF)?$emergencyBF->paid:0;
            $data['emergency_doctor_commissionBF'] = isset($emergencyBF)?$emergencyBF->doctor_commission:0;
            $data['emergency_others_costBF'] = isset($emergencyBF)?$emergencyBF->others_cost:0;

            $ambulanceBF = $this->Common_model->calculateSumMultiple('create_bill',$ambulanceWhereBF,array('sub_total','paid','fuel_cost','road_cost','service_maintanance_cost')) ;
            $data['ambulance_totalBF'] = isset($ambulanceBF)?$ambulanceBF->sub_total:0;
            $data['ambulance_paidBF'] = isset($ambulanceBF)?$ambulanceBF->paid:0;
            $data['ambulance_fuel_costBF'] = isset($ambulanceBF)?$ambulanceBF->fuel_cost:0;
            $data['ambulance_road_costBF'] = isset($ambulanceBF)?$ambulanceBF->road_cost:0;
            $data['ambulance_service_maintanance_costBF'] = isset($ambulanceBF)?$ambulanceBF->service_maintanance_cost:0;

            $doctor_serviceBF = $this->Common_model->calculateSumMultiple('create_bill',$doctorServiceWhereBF,array('sub_total','paid','due','doctor_commission','reference_by_commission')) ;
            $data['doctor_service_totalBF'] = isset($doctor_serviceBF)?$doctor_serviceBF->sub_total:0;
            $data['doctor_service_paidBF'] = isset($doctor_serviceBF)?$doctor_serviceBF->paid:0;
            $data['doctor_service_reference_by_commissionBF'] = isset($doctor_serviceBF)?$doctor_serviceBF->reference_by_commission:0;
            $data['doctor_service_commissionBF'] = isset($doctor_serviceBF)?$doctor_serviceBF->doctor_commission:0;
            $data['doctor_service_commissionBF'] = $data['doctor_service_reference_by_commissionBF'] + $data['doctor_service_commissionBF'] ;
            $data['doctor_service_dueBF'] = isset($doctor_serviceBF)?$doctor_serviceBF->due:0;

            $donorBF = $this->Common_model->calculateSumMultiple('create_bill',$donorWhereBF,array('sub_total','paid')) ;
            $data['donor_totalBF'] = isset($donorBF)?$donorBF->sub_total:0;
            $data['donor_paidBF'] = isset($donorBF)?$donorBF->paid:0;

            $dressingBF = $this->Common_model->calculateSumMultiple('create_bill',$dressingWhereBF,array('sub_total','paid','doctor_commission')) ;
            $data['dressing_totalBF'] = isset($dressingBF)?$dressingBF->sub_total:0;
            $data['dressing_paidBF'] = isset($dressingBF)?$dressingBF->paid:0;
            $data['dressing_doctor_commissionBF'] = isset($dressingBF)?$dressingBF->doctor_commission:0;

            $data['general_incomeBF'] = $this->Common_model->calCulateSum('incomes',$incomeWhereBF,'voucher_amount') ;
            $data['general_expenseBF'] = $this->Common_model->calCulateSum('expenses',$expenseWhereBF,'voucher_amount') ;
            $data['lab_productBF'] = $this->Common_model->calCulateSum('lab_product_in',$labInWhereBF,'grand_total_price') ;

            $data['total_paid_amountBF'] = $data['pathology_paidBF'] +  $data['operation_paidBF'] + $data['operationInvoiceBF'] +  $data['consultancy_paidBF'] + $data['dueCollectionBF']  + $data['emergency_paidBF']  + $data['ambulance_paidBF'] + $data['doctor_service_paidBF'] + $data['donor_paidBF'] + $data['dressing_paidBF'] + $data['general_incomeBF'] ;
            $data['total_expense_amountBF'] = $data['doctor_commission_patholgyBF'] + $data['consultancy_doctor_commissionBF']  + $data['operation_commissionBF'] + $data['sonologistExpenseBF'] + $data['staffSalaryBF'] + $data['emergency_doctor_commissionBF'] + $data['emergency_others_costBF'] + $data['ambulance_fuel_costBF'] +  $data['ambulance_road_costBF'] + $data['ambulance_service_maintanance_costBF'] + $data['dressing_doctor_commissionBF'] + $data['doctor_service_commissionBF'] + $data['general_expenseBF'] + $data['lab_productBF']  ;
            $data['balance_amountBF'] = $data['total_paid_amountBF'] - $data['total_expense_amountBF'] ;

            $grand_total_incomeBF += $data['total_paid_amountBF'] ;
            $grand_total_expenseBF += $data['total_expense_amountBF'] ;
            $grand_total_balanceBF += $data['balance_amountBF'] ;
            $response['grand_total_balanceBF'] = $grand_total_balanceBF ;
            $response['grand_total_balanceBF'] = round($response['grand_total_balanceBF']);*/

            /**B/F**/
            while (strtotime($date_from) <= strtotime($date_to)) {
                $count++;

                $pathologyWhere = array();
                if (!admin()) {
                    $pathologyWhere['show_hide'] = "Show";
                }
                $pathologyWhere['date'] = $date_from;
                $pathologyWhere['type'] = 'Test Invoice';
                $operationWhere['date'] = $date_from;
                $operationInvoiceWhere = array();
                if (!admin()) {
                    $operationInvoiceWhere['show_hide'] = "Show";
                }
                $operationInvoiceWhere['date'] = $date_from;
                $operationInvoiceWhere['type'] = 'Admission';
                // $operationWhere = array() ;
                if (!admin()) {
                    $operationWhere['show_hide'] = "Show";
                }
                $operationWhere['type'] = 'Operation';

                $operationAdmissionAdvanceInvoiceWhere = array();
                if (!admin()) {
                    $operationAdmissionAdvanceInvoiceWhere['show_hide'] = "Show";
                }
                $operationAdmissionAdvanceInvoiceWhere['date'] = $date_from;
                $operationAdmissionAdvanceInvoiceWhere['type'] = 'AdmissionAdvance';

                $operationDetailsWhere = array();
                if (!admin()) {
                    $operationDetailsWhere['show_hide'] = "Show";
                }
                $operationDetailsWhere['operation_date'] = $date_from;

                $ecgWhere['date'] = $date_from;
                $ecgWhere['test_category'] = 'ECG';
                $xrayWhere['date'] = $date_from;
                $xrayWhere['test_category'] = '%X-Ray%';
                $ultraWhere['date'] = $date_from;
                $ultraWhere['test_category like'] = 'Ultrasonogram';

                $generalIncomeWhere = array();
                if (!admin()) {
                    $generalIncomeWhere['show_hide'] = "Show";
                }
                $generalIncomeWhere['date'] = $date_from;

                $consultancyWhere = array();
                if (!admin()) {
                    $consultancyWhere['show_hide'] = "Show";
                }
                $consultancyWhere['type'] = 'Appointment';
                $consultancyWhere['doctor_visit_payment_date'] = $date_from;
                $consultancyWhere['doctor_visit_payment_status'] = 'Paid';
                
                $consultancypayWhere = array();
                if (!admin()) {
                    $consultancypayWhere['show_hide'] = "Show";
                }
                $consultancypayWhere['type'] = 'Appointment';
                $consultancypayWhere['date'] = $date_from;

                $commission_patholgyWhere = array();
                if (!admin()) {
                    $commission_patholgyWhere['show_hide'] = "Show";
                }
                $commission_patholgyWhere['test_invoice_payment_status'] = 'Paid';
                $commission_patholgyWhere['type'] = 'Test Invoice';
                $commission_patholgyWhere['test_invoice_payment_date'] = $date_from;



                $operation_commissionWhere = array();
                if (!admin()) {
                    $operation_commissionWhere['show_hide'] = "Show";
                }
                $operation_commissionWhere['operation_date'] = $date_from;

                $sonologistExpenseWhere = array();
                if (!admin()) {
                    $sonologistExpenseWhere['show_hide'] = "Show";
                }
                $sonologistExpenseWhere['date'] = $date_from;

                $generalExpenseWhere = array();
                if (!admin()) {
                    $generalExpenseWhere['show_hide'] = "Show";
                }
                $generalExpenseWhere['date'] = $date_from;
                $staffSalaryWhere = array();
                if (!admin()) {
                    $staffSalaryWhere['show_hide'] = "Show";
                }
                $staffSalaryWhere['status'] = 'Paid';
                $staffSalaryWhere['date'] = $date_from;

                $staffSalaryAdvWhere = array();
                $staffSalaryAdvWhere['date'] = $date_from;

                $dueCollectionWhere = array();
                if (!admin()) {
                    $dueCollectionWhere['show_hide'] = "Show";
                }
                $dueCollectionWhere['mr_date'] = $date_from;


                $salesWhere = array();
                if (!admin()) {
                    $salesWhere['show_hide'] = "Show";
                }
                $salesWhere['sales_from'] = 'Direct';
                $salesWhere['sales_date'] = $date_from;

                $mrWhere = array();
                if (!admin()) {
                    $mrWhere['show_hide'] = "Show";
                }
                $mrWhere['mr_date'] = $date_from;

                $emergencyWhere = array();
                if (!admin()) {
                    $emergencyWhere['show_hide'] = "Show";
                }
                $emergencyWhere['type'] = 'Emergency';
                $emergencyWhere['date'] = $date_from;

                $ambulanceWhere = array();
                if (!admin()) {
                    $ambulanceWhere['show_hide'] = "Show";
                }
                $ambulanceWhere['type'] = 'Ambulance';
                $ambulanceWhere['date'] = $date_from;

                $doctorServiceWhere = array();
                if (!admin()) {
                    $doctorServiceWhere['show_hide'] = "Show";
                }
                $doctorServiceWhere['type'] = 'Doctor Service';
                $doctorServiceWhere['date'] = $date_from;

                $donorWhere = array();
                if (!admin()) {
                    $donorWhere['show_hide'] = "Show";
                }
                $donorWhere['type'] = 'Donor';
                $donorWhere['date'] = $date_from;

                $dressingWhere = array();
                if (!admin()) {
                    $dressingWhere['show_hide'] = "Show";
                }
                $dressingWhere['type'] = 'Dressing';
                $dressingWhere['date'] = $date_from;

                $supplier_paymentsWhere = array();
                if (!admin()) {
                    $supplier_paymentsWhere['show_hide'] = "Show";
                }
                $supplier_paymentsWhere['payment_date'] = $date_from;

                $incomeWhere = array();
                if (!admin()) {
                    $incomeWhere['show_hide'] = "Show";
                }
                $incomeWhere['income_type != '] = 'Pharmacy';
                $incomeWhere['income_date'] = $date_from;
                $expenseWhere = [
                    'approval' => 'Approved'
                ];
                if (!admin()) {
                    $expenseWhere['show_hide'] = "Show";
                }
                // $expenseWhere['approval'] = 'Approved' ;
                $expenseWhere['expense_type != '] = 'Pharmacy';
                $expenseWhere['expense_date'] = $date_from;

                $labInWhere = array();
                $labInWhere['approval'] = "Paid";
                if (!admin()) {
                    $labInWhere['show_hide'] = "Show";
                }
                $labInWhere['in_date'] = $date_from;

                $dressingWhere = array();
                if (!admin()) {
                    $dressingWhere['show_hide'] = "Show";
                }
                $dressingWhere['type'] = 'Dressing';
                $dressingWhere['date'] = $date_from;



                $data['pathology'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhere, 'sub_total');
                $data['pathology_paid'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhere, 'paid');
                $data['pathology_due'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhere, 'due');
                $data['operation'] = $this->Common_model->calCulateSum('create_bill', $operationWhere, 'sub_total');
                //  var_dump($operationWhere) ; die ;
                $operation_paid =  $this->Common_model->calculateSumMultiple('create_bill', $operationWhere, array('paid', 'medicine_cost', 'advance'));



                $operationInvoice = $this->Common_model->calculateSumMultiple('create_bill', $operationInvoiceWhere, array('sub_total', 'advance'));
                $data['operationInvoice'] = $operationInvoice->sub_total + $operationInvoice->advance;

                $operationAdmissionAdvanceInvoice = $this->Common_model->calculateSum('create_bill', $operationAdmissionAdvanceInvoiceWhere, 'sub_total');
                $data['operationAdmissionAdvanceInvoice'] = isset($operationAdmissionAdvanceInvoice) ? $operationAdmissionAdvanceInvoice : 0;

                $data['operation_paid'] = $operation_paid->paid;
                $data['operation_due'] = $this->Common_model->calCulateSum('create_bill', $operationWhere, 'due');

                $data['ecg'] = $this->Common_model->calCulateSum('sales_test', $ecgWhere, 'test_price');
                $data['xray'] = $this->Common_model->calCulateSum('sales_test', $xrayWhere, 'test_price');
                $data['ultra'] = $this->Common_model->calCulateSum('sales_test', $ultraWhere, 'test_price');


                $consultancy = $this->Common_model->calculateSumMultiple('create_bill', $consultancyWhere, array('sub_total', 'paid', 'due', 'doctor_commission'));
                $consultancy_payment = $this->Common_model->calculateSumMultiple('create_bill', $consultancypayWhere, array('sub_total', 'paid', 'due', 'doctor_commission'));
                // var_dump($consultancyWhere) ; die;
                $data['consultancy'] = isset($consultancy) ?  $consultancy->sub_total : 0;
                $data['consultancy_paid'] = isset($consultancy_payment) ?  $consultancy_payment->paid : 0;
                $data['consultancy_due'] = isset($consultancy) ?  $consultancy->due : 0;
                $data['consultancy_doctor_commission'] = isset($consultancy) ?  $consultancy->doctor_commission : 0;
                //  $data['doctor_commission_patholgy'] = $this->Common_model->calCulateSum('create_bill',$commission_patholgyWhere,'doctor_commission');
                
                // $doctor_commission_patholgy = $this->Common_model->calculateSumMultiple('create_bill', $commission_patholgyWhere, array('discount', 'doctor_commission', 'reference_by_commission'));
                // $test_invoice_discount = isset($doctor_commission_patholgy) ? $doctor_commission_patholgy->discount : 0;
                // $doctor_commission = isset($doctor_commission_patholgy) ? $doctor_commission_patholgy->doctor_commission : 0;
                // $reference_by_commission = isset($doctor_commission_patholgy) ? $doctor_commission_patholgy->reference_by_commission : 0;
                // $data['doctor_commission_patholgy'] = $doctor_commission + $reference_by_commission - $test_invoice_discount;

                // calculate ref commsissions
                $refCommWhere = [];
                if (!admin()) {
                    $refCommWhere['show_hide'] = "Show";
                }
                $refCommWhere['test_invoice_payment_date'] = $date_from;
                $refCommWhere['type'] = 'Test Invoice';
                $refCommWhere['test_invoice_payment_status'] = 'Paid';
                if (!empty($created_by)) {
                $refCommWhere['created_by'] = $created_by;
                }

                $refCommWdishere = [];
                if (!admin()) {
                    $refCommWdishere['show_hide'] = "Show";
                }
                $refCommWdishere['test_invoice_payment_date'] = $date_from;
                $refCommWdishere['type'] = 'Test Invoice';
                $refCommWdishere['test_invoice_payment_status'] = 'Paid';
                $refCommWdishere['reference_by_commission >'] = 0;
                if (!empty($created_by)) {
                    $refCommWdishere['created_by'] = $created_by;
                }
        
                $reference_by_commission = $this->Common_model->calCulateSum('create_bill', $refCommWhere, 'reference_by_commission');
        
                //$test_invoice_discount = isset($doctor_commission_patholgy) ? $doctor_commission_patholgy->discount : 0;
                //$doctor_commission = isset($doctor_commission_patholgy) ? $doctor_commission_patholgy->doctor_commission : 0;
                $test_invoice_discount = $this->Common_model->calCulateSum('create_bill', $refCommWdishere, 'discount');
                $data['doctor_commission_patholgy'] = $reference_by_commission;
                // dd($data);

                $operation_commissionWhere = array();
                if (!admin()) {
                    $operation_commissionWhere['show_hide'] = "Show";
                }
                $operation_commissionWhere['payment_status'] = 'Paid';
                $operation_commissionWhere['operation_date >='] = $date_from;
                $operation_commissionWhere['operation_date <='] = $date_from;

                $opCommWhere = $operation_commissionWhere;
                // $opCommWhere['payment_status'] = 'Paid';

                $operation_commission =  $this->Common_model->calculateSumMultiple('operation_details', $opCommWhere, array('surgeon_commission', 'surgeon_assistant_commission', 'surgeon_team_commission', 'anesthesia_commission', 'medicine_cost', 'service_fee', 'reference_by_payment'));
                $surgeon_commission = isset($operation_commission) ? $operation_commission->surgeon_commission : 0;
                $anesthesia_commission = isset($operation_commission) ? $operation_commission->anesthesia_commission : 0;
                $medicine_cost = isset($operation_commission) ? $operation_commission->medicine_cost : 0;
                $surgeon_assistant_commission = isset($operation_commission) ? $operation_commission->surgeon_assistant_commission : 0;
                $surgeon_team_commission = isset($operation_commission) ? $operation_commission->surgeon_team_commission : 0;
                $service_fee = isset($operation_commission) ? $operation_commission->service_fee : 0;
                
                $data['operation_commission'] = $medicine_cost + $surgeon_commission + $surgeon_assistant_commission + $anesthesia_commission   + $service_fee + $operation_commission->reference_by_payment;

                //  if ($count ==16){
                //     // dd( $operation_commission->reference_by_payment );
                // }

                $data['sonologistExpense'] = $this->Common_model->calCulateSum('sonologist', $sonologistExpenseWhere, 'amount');

                $data['staffSalary'] = $this->Common_model->calCulateSum('create_salary_sheet', $staffSalaryWhere, 'net_salary');
                $data['staffSalaryAdv'] = $this->Common_model->calCulateSum('create_salary_sheet_advanced', $staffSalaryAdvWhere, 'advanced_amount');

                $data['dueCollection'] = $this->Common_model->calCulateSum('due_collections', $dueCollectionWhere, 'mr_amount');

                $sales_orders = $this->Common_model->calculateSumMultiple('sales_orders', $salesWhere, array('grand_net_total', 'paid_amount', 'due_amount'));
                $data['sales_amount'] = $sales_orders->grand_net_total;
                $data['sales_paid_amount'] = $sales_orders->paid_amount;
                $data['sales_due_amount'] = $sales_orders->due_amount;
                $data['pharmacy_collection'] = $this->Common_model->calCulateSum('mr', $mrWhere, 'mr_amount');

                $data['supplier_payments'] = $this->Common_model->calCulateSum('supplier_payments', $supplier_paymentsWhere, 'payment_amount');



                $emergency = $this->Common_model->calculateSumMultiple('create_bill', $emergencyWhere, array('sub_total', 'paid', 'doctor_commission', 'others_cost'));
                $data['emergency_total'] = isset($emergency) ? $emergency->sub_total : 0;
                $data['emergency_paid'] =  isset($emergency) ? $emergency->paid : 0;
                $data['emergency_doctor_commission'] = isset($emergency) ? $emergency->doctor_commission : 0;
                $data['emergency_others_cost'] = isset($emergency) ? $emergency->others_cost : 0;

                $ambulance = $this->Common_model->calculateSumMultiple('create_bill', $ambulanceWhere, array('sub_total', 'paid', 'fuel_cost', 'road_cost', 'service_maintanance_cost'));
                $data['ambulance_total'] = isset($ambulance) ? $ambulance->sub_total : 0;
                $data['ambulance_paid'] = isset($ambulance) ? $ambulance->paid : 0;
                $data['ambulance_fuel_cost'] = isset($ambulance) ? $ambulance->fuel_cost : 0;
                $data['ambulance_road_cost'] = isset($ambulance) ? $ambulance->road_cost : 0;
                $data['ambulance_service_maintanance_cost'] = isset($ambulance) ? $ambulance->service_maintanance_cost : 0;

                $doctor_service = $this->Common_model->calculateSumMultiple('create_bill', $doctorServiceWhere, array('sub_total', 'paid', 'due', 'doctor_commission', 'reference_by_commission'));
                $data['doctor_service_total'] = isset($doctor_service) ? $doctor_service->sub_total : 0;
                $data['doctor_service_paid'] = isset($doctor_service) ? $doctor_service->paid : 0;
                $data['doctor_service_reference_by_commission'] = isset($doctor_service) ? $doctor_service->reference_by_commission : 0;
                $data['doctor_service_commission'] = isset($doctor_service) ? $doctor_service->doctor_commission : 0;
                $data['doctor_service_commission'] = $data['doctor_service_reference_by_commission'] + $data['doctor_service_commission'];
                $data['doctor_service_due'] = isset($doctor_service) ? $doctor_service->due : 0;




                $donor = $this->Common_model->calculateSumMultiple('create_bill', $donorWhere, array('sub_total', 'paid'));
                $data['donor_total'] = isset($donor) ? $donor->sub_total : 0;
                $data['donor_paid'] = isset($donor) ? $donor->paid : 0;

                $dressing = $this->Common_model->calculateSumMultiple('create_bill', $dressingWhere, array('sub_total', 'paid', 'doctor_commission'));
                $data['dressing_total'] = isset($dressing) ? $dressing->sub_total : 0;
                $data['dressing_paid'] = isset($dressing) ? $dressing->paid : 0;
                $data['dressing_cost'] = isset($dressing) ? $dressing->doctor_commission : 0;

                $data['general_income'] = $this->Common_model->calCulateSum('incomes', $incomeWhere, 'voucher_amount');
                $data['general_expense'] = $this->Common_model->calCulateSum('expenses', $expenseWhere, 'voucher_amount');
                $data['lab_product'] = $this->Common_model->calCulateSum('lab_product_in', $labInWhere, 'grand_total_price');

                $bankWhere = [
                    'date' => $date_from
                ];

                $bankDepositWhere =   $bankWhere;
                $bankDepositWhere['transation_type'] = 'Deposit';
                $bankWithdrawWhere =  $bankWhere;
                $bankWithdrawWhere['transation_type'] = 'Withdraw';
                

                $data['bankDeposit'] = $this->Common_model->calCulateSum('bank_transations',  $bankDepositWhere, 'amount');
                $data['bankWithdraw'] = $this->Common_model->calCulateSum('bank_transations',  $bankWithdrawWhere, 'amount');

                $data['total_paid_amount'] = $data['pathology_paid'] +  $data['operation_paid'] + $data['operationInvoice'] +  $data['consultancy_paid'] + $data['dueCollection']  + $data['emergency_paid']  + $data['ambulance_paid'] + $data['doctor_service_paid'] + $data['donor_paid'] + $data['dressing_paid'] + $data['general_income'] + $data['operationAdmissionAdvanceInvoice'] +   $data['bankWithdraw']; // + $data['sales_paid_amount'] + $data['pharmacy_collection'] ;
                //$data['total_paid_amount'] = $data['pathology_paid'] +  $data['operation_paid'] ; // + $data['operationInvoice'] +  $data['consultancy_paid'] + $data['dueCollection']  + $data['emergency_paid']  + $data['ambulance_paid'] + $data['doctor_service_paid'] + $data['donor_paid'] + $data['dressing_paid'] + $data['general_income'] + $data['operationAdmissionAdvanceInvoice']; // + $data['sales_paid_amount'] + $data['pharmacy_collection'] ;
                $data['total_expense_amount'] = $data['doctor_commission_patholgy'] + $data['consultancy_doctor_commission']  + $data['operation_commission'] + $data['sonologistExpense'] + $data['staffSalary']+ $data['staffSalaryAdv'] + $data['emergency_doctor_commission'] + $data['emergency_others_cost'] + $data['ambulance_fuel_cost'] +  $data['ambulance_road_cost'] + $data['ambulance_service_maintanance_cost'] + $data['doctor_service_commission'] + $data['general_expense'] + $data['lab_product'] + $data['dressing_cost']+   $data['bankDeposit'];
                $data['balance_amount'] = $data['total_paid_amount'] - $data['total_expense_amount']; //  + $data['supplier_payments'] ;

               

                $grand_total_income += round($data['total_paid_amount']);
                $grand_total_expense += round($data['total_expense_amount']);
                $grand_total_balance += round($data['balance_amount']);

                $response['date' . $count] = date('d-m-y', strtotime($date_from));
                $response['con_in_sum' . $count] = $data['consultancy_paid'];
                $response['test_invoice_in_sub_total' . $count] = 0;
                $response['test_invoice_in_paid' . $count] = $data['pathology_paid'];
                $response['test_invoice_in_due' . $count] = 0;
                $response['total_pharmacy' . $count] = $data['sales_paid_amount'];
                $response['emergency_paid' . $count] = $data['emergency_paid'];
                $response['ambulance_paid' . $count] = $data['ambulance_paid'];
                $response['doctor_service_paid' . $count] = $data['doctor_service_paid'];
                $response['donor_paid' . $count] = $data['donor_paid'];
                $response['due_collection' . $count] = $data['pharmacy_collection'] + $data['dueCollection'];
                $response['income' . $count] =  $data['general_income'];
                $response['con_ex_sum' . $count] = $data['consultancy_doctor_commission'];
                $response['operation_admission_invoice' . $count] =  $data['operationInvoice'];
                $response['operation_in_sub_total' . $count] = 0;
                $response['operation_in_paid' . $count] = $data['operation_paid'] + $data['operationInvoice'];
                $response['operation_in_due' . $count] = 0;
                $response['test_invoice_ex_sum' . $count] = $data['doctor_commission_patholgy'];
                $response['operation_ex' . $count] = $data['operation_commission'];
                $response['emergency_expense' . $count] = $data['emergency_doctor_commission'] + $data['emergency_others_cost'];
                $response['ambulance_expense' . $count] = $data['ambulance_fuel_cost'] + $data['ambulance_road_cost'] + $data['ambulance_service_maintanance_cost'];
                $response['doctor_service_commission' . $count] = $data['doctor_service_commission'];
                $response['supplier_payments' . $count] = $data['supplier_payments'];
                $response['expense' . $count] = $data['general_expense'];
                $response['son_expense' . $count] =  $data['sonologistExpense'];
                $response['staffSalary' . $count] = $data['staffSalary'];
                $response['lab_product' . $count] = $data['lab_product'];
                $response['total_paid_amount' . $count] = round($data['total_paid_amount']);
                $response['balance' . $count] = round($data['balance_amount']);
                $response['total_expense_amount' . $count] = round($data['total_expense_amount']);


                $date_from = date("Y-m-d", strtotime("+1 day", strtotime($date_from)));
            }

            // dd($response);
            //var_dump("Called") ; die;
            $response['start_date'] = $start_date;
            $response['end_date'] = $date_to;
            $response['count_it'] = $count;
            // $monthName = date("F", strtotime($month));
            $monthName = date("F", mktime(0, 0, 0, $month, 10));
            $response['page_title'] = "Monthly Cash Report - $monthName, $year";
            $response['redirect'] = base_url('reports/cash_report');
            $response['grand_total_income'] = round($grand_total_income);
            $response['grand_total_expense'] = round($grand_total_expense);
            $response['grand_total_balance'] = round($grand_total_balance);
            $this->load->view('admin/reports/show_total_cash_report', $response);
        } else {
            $data['start_date'] = $start_date;
            $data['end_date'] = $date_to;
            $data['page_title'] = "$report_type Cash Report";
            $data['redirect'] = base_url('reports/cash_report');

            /**B/F**/
            $pathologyWhereBF = array();
            $pathologyWhereBF['date'] = $previous_date;
            $pathologyWhereBF['type'] = 'Test Invoice';
            $operationWhereBF['date'] = $previous_date;
            $operationInvoiceWhereBF['date'] = $previous_date;
            $operationInvoiceWhereBF['type'] = 'Admission';
            $operationWhereBF['type'] = 'Operation';

            $operationDetailsWhereBF = array();
            $operationDetailsWhereBF['operation_date'] = $previous_date;

            $ecgWhereBF['date'] = $previous_date;
            $ecgWhereBF['test_category'] = 'ECG';
            $xrayWhereBF['date'] = $previous_date;
            $xrayWhereBF['test_category'] = '%X-Ray%';
            $ultraWhereBF['date'] = $previous_date;
            $ultraWhereBF['test_category like'] = 'Ultrasonogram';

            $generalIncomeWhereBF = array();
            $generalIncomeWhereBF['date'] = $previous_date;

            $consultancyWhereBF = array();
            $consultancyWhereBF['type'] = 'Appointment';
            $consultancyWhereBF['date'] = $previous_date;

            $commission_patholgyWhereBF = array();
            $commission_patholgyWhereBF['type'] = 'Test Invoice';
            $commission_patholgyWhereBF['date'] = $previous_date;



            $operation_commissionWhereBF = array();
            $operation_commissionWhereBF['operation_date'] = $previous_date;

            $sonologistExpenseWhereBF = array();
            $sonologistExpenseWhereBF['date'] = $previous_date;

            $generalExpenseWhereBF = array();
            $generalExpenseWhereBF['date'] = $previous_date;
            $staffSalaryWhereBF = array();
            $staffSalaryWhereBF['status'] = 'Paid';
            $staffSalaryWhereBF['date'] = $previous_date;

            $dueCollectionWhereBF = array();
            $dueCollectionWhereBF['mr_date'] = $previous_date;


            $salesWhereBF = array();
            $salesWhereBF['sales_from'] = 'Direct';
            $salesWhereBF['sales_date'] = $previous_date;

            $purchaseWhereBF = array();
            $purchaseWhereBF['purchase_date'] = $previous_date;

            $mrWhereBF = array();
            $mrWhereBF['mr_date'] = $previous_date;

            $emergencyWhereBF = array();
            $emergencyWhereBF['type'] = 'Emergency';
            $emergencyWhereBF['date'] = $previous_date;

            $ambulanceWhereBF = array();
            $ambulanceWhereBF['type'] = 'Ambulance';
            $ambulanceWhereBF['date'] = $previous_date;

            $doctorServiceWhereBF = array();
            $doctorServiceWhereBF['type'] = 'Doctor Service';
            $doctorServiceWhereBF['date'] = $previous_date;

            $donorWhereBF = array();
            $donorWhereBF['type'] = 'Donor';
            $donorWhereBF['date'] = $previous_date;

            $supplier_paymentsWhereBF = array();
            $supplier_paymentsWhereBF['payment_date'] = $previous_date;

            $incomeWhereBF = array();
            $incomeWhereBF['income_date'] = $previous_date;
            $expenseWhereBF = [];
            $expenseWhereBF['expense_date'] = $previous_date;

            $labInWhereBF = array();
            $labInWhereBF['in_date'] = $previous_date;



            $data['pathologyBF'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhereBF, 'sub_total');
            $data['pathology_paidBF'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhereBF, 'paid');
            $data['pathology_dueBF'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhereBF, 'due');
            $data['operationBF'] = $this->Common_model->calCulateSum('create_bill', $operationWhereBF, 'sub_total');
            $operation_paidBF = $this->Common_model->calculateSumMultiple('create_bill', $operationWhereBF, array('paid', 'medicine_cost', 'advance'));



            $operationInvoiceBF = $this->Common_model->calculateSumMultiple('create_bill', $operationInvoiceWhereBF, array('sub_total', 'advance'));
            $data['operationInvoiceBF'] = $operationInvoiceBF->sub_total + $operationInvoiceBF->advance;

            $data['operation_paidBF'] = $operation_paidBF->paid;
            $data['operation_dueBF'] = $this->Common_model->calCulateSum('create_bill', $operationWhereBF, 'due');

            $data['ecgBF'] = $this->Common_model->calCulateSum('sales_test', $ecgWhereBF, 'test_price');
            $data['xrayBF'] = $this->Common_model->calCulateSum('sales_test', $xrayWhereBF, 'test_price');
            $data['ultraBF'] = $this->Common_model->calCulateSum('sales_test', $ultraWhereBF, 'test_price');


            $consultancyBF = $this->Common_model->calculateSumMultiple('create_bill', $consultancyWhereBF, array('sub_total', 'paid', 'due', 'doctor_commission'));
            $data['consultancyBF'] = isset($consultancyBF) ?  $consultancyBF->sub_total : 0;
            $data['consultancy_paidBF'] = isset($consultancyBF) ?  $consultancyBF->paid : 0;
            $data['consultancy_dueBF'] = isset($consultancyBF) ?  $consultancyBF->due : 0;
            $data['consultancy_doctor_commissionBF'] = isset($consultancyBF) ?  $consultancyBF->doctor_commission : 0;
            //  $data['doctor_commission_patholgy'] = $this->Common_model->calCulateSum('create_bill',$commission_patholgyWhere,'doctor_commission');
            $doctor_commission_patholgyBF = $this->Common_model->calculateSumMultiple('create_bill', $commission_patholgyWhereBF, array('doctor_commission', 'reference_by_commission'));
            $doctor_commissionBF = isset($doctor_commission_patholgyBF) ? $doctor_commission_patholgyBF->doctor_commission : 0;
            $reference_by_commissionBF = isset($doctor_commission_patholgyBF) ? $doctor_commission_patholgyBF->reference_by_commission : 0;
            $data['doctor_commission_patholgyBF'] = $doctor_commissionBF + $reference_by_commissionBF;


            $operation_commissionBF =  $this->Common_model->calculateSumMultiple('operation_details', $operationDetailsWhereBF, array('surgeon_commission', 'surgeon_assistant_commission', 'anesthesia_commission', 'medicine_cost'));
            $surgeon_commissionBF = isset($operation_commissionBF) ? $operation_commissionBF->surgeon_commission : 0;
            $anesthesia_commissionBF = isset($operation_commissionBF) ? $operation_commissionBF->anesthesia_commission : 0;
            $medicine_costBF = isset($operation_commissionBF) ? $operation_commissionBF->medicine_cost : 0;
            $surgeon_assistant_commissionBF = isset($operation_commissionBF) ? $operation_commissionBF->surgeon_assistant_commission : 0;
            $data['operation_commissionBF'] =  $surgeon_commissionBF + $anesthesia_commissionBF + $medicine_costBF + $surgeon_assistant_commissionBF;

            $data['sonologistExpenseBF'] = $this->Common_model->calCulateSum('sonologist', $sonologistExpenseWhereBF, 'amount');

            $data['staffSalaryBF'] = $this->Common_model->calCulateSum('create_salary_sheet', $staffSalaryWhereBF, 'net_salary');

            $data['dueCollectionBF'] = $this->Common_model->calCulateSum('due_collections', $dueCollectionWhereBF, 'mr_amount');

            $sales_ordersBF = $this->Common_model->calculateSumMultiple('sales_orders', $salesWhereBF, array('grand_net_total', 'paid_amount', 'due_amount'));
            $data['sales_amountBF'] = $sales_ordersBF->grand_net_total;
            $data['sales_paid_amountBF'] = $sales_ordersBF->paid_amount;
            $data['sales_due_amountBF'] = $sales_ordersBF->due_amount;

            $purchase_ordersBF = $this->Common_model->calculateSumMultiple('purchase_orders', $purchaseWhereBF, array('grand_net_total', 'paid_amount', 'due_amount'));
            $data['purchase_amountBF'] = $purchase_ordersBF->grand_net_total;
            $data['purchase_paid_amountBF'] = $purchase_ordersBF->paid_amount;
            $data['purchase_due_amountBF'] = $purchase_ordersBF->due_amount;

            $data['pharmacy_collectionBF'] = $this->Common_model->calCulateSum('mr', $mrWhereBF, 'mr_amount');

            $data['supplier_paymentsBF'] = $this->Common_model->calCulateSum('supplier_payments', $supplier_paymentsWhereBF, 'payment_amount');



            $emergencyBF = $this->Common_model->calculateSumMultiple('create_bill', $emergencyWhereBF, array('sub_total', 'paid', 'doctor_commission', 'others_cost'));
            $data['emergency_totalBF'] = isset($emergencyBF) ? $emergencyBF->sub_total : 0;
            $data['emergency_paidBF'] = isset($emergencyBF) ? $emergencyBF->paid : 0;
            $data['emergency_doctor_commissionBF'] = isset($emergencyBF) ? $emergencyBF->doctor_commission : 0;
            $data['emergency_others_costBF'] = isset($emergencyBF) ? $emergencyBF->others_cost : 0;

            $ambulanceBF = $this->Common_model->calculateSumMultiple('create_bill', $ambulanceWhereBF, array('sub_total', 'paid', 'fuel_cost', 'road_cost', 'service_maintanance_cost'));
            $data['ambulance_totalBF'] = isset($ambulanceBF) ? $ambulanceBF->sub_total : 0;
            $data['ambulance_paidBF'] = isset($ambulanceBF) ? $ambulanceBF->paid : 0;
            $data['ambulance_fuel_costBF'] = isset($ambulanceBF) ? $ambulanceBF->fuel_cost : 0;
            $data['ambulance_road_costBF'] = isset($ambulanceBF) ? $ambulanceBF->road_cost : 0;
            $data['ambulance_service_maintanance_costBF'] = isset($ambulanceBF) ? $ambulanceBF->service_maintanance_cost : 0;

            $doctor_serviceBF = $this->Common_model->calculateSumMultiple('create_bill', $doctorServiceWhereBF, array('sub_total', 'paid', 'due', 'doctor_commission', 'reference_by_commission'));
            $data['doctor_service_totalBF'] = isset($doctor_serviceBF) ? $doctor_serviceBF->sub_total : 0;
            $data['doctor_service_paidBF'] = isset($doctor_serviceBF) ? $doctor_serviceBF->paid : 0;
            $data['doctor_service_reference_by_commissionBF'] = isset($doctor_serviceBF) ? $doctor_serviceBF->reference_by_commission : 0;
            $data['doctor_service_commissionBF'] = isset($doctor_serviceBF) ? $doctor_serviceBF->doctor_commission : 0;
            $data['doctor_service_commissionBF'] = $data['doctor_service_reference_by_commissionBF'] + $data['doctor_service_commissionBF'];
            $data['doctor_service_dueBF'] = isset($doctor_serviceBF) ? $doctor_serviceBF->due : 0;




            $donorBF = $this->Common_model->calculateSumMultiple('create_bill', $donorWhereBF, array('sub_total', 'paid'));
            $data['donor_totalBF'] = isset($donorBF) ? $donorBF->sub_total : 0;
            $data['donor_paidBF'] = isset($donorBF) ? $donorBF->paid : 0;

            $data['general_incomeBF'] = $this->Common_model->calCulateSum('incomes', $incomeWhereBF, 'voucher_amount');
            $data['general_expenseBF'] = $this->Common_model->calCulateSum('expenses', $expenseWhereBF, 'voucher_amount');
            $data['lab_productBF'] = $this->Common_model->calCulateSum('lab_product_in', $labInWhereBF, 'grand_total_price');

            //var_dump($data['consultancy_paidBF']) ; die ;

            if ($report_type == 'Diagnostic') {
                // $data['pathology_paidBF'] = 0 ;
                $data['operation_paidBF'] = 0;
                $data['operationInvoiceBF'] = 0;
                // $data['consultancy_paidBF'] = 0 ;
                //  $data['dueCollectionBF']  = 0 ;
                $data['emergency_paidBF']  = 0;
                $data['ambulance_paidBF'] = 0;
                $data['doctor_service_paidBF'] = 0;
                $data['donor_paidBF'] = 0;
                //  $data['general_incomeBF'] = 0 ;
                $data['sales_paid_amountBF'] = 0;
                $data['pharmacy_collectionBF'] = 0;

                $data['purchase_paid_amountBF'] = 0;
                $data['supplier_paymentsBF'] = 0;

                // $data['doctor_commission_patholgyBF'] = 0 ;
                // $data['consultancy_doctor_commissionBF']  = 0 ;
                // $data['operation_commissionBF'] = 0 ;
                // $data['sonologistExpenseBF'] = 0 ;
                $data['staffSalaryBF'] = 0;
                $data['emergency_doctor_commissionBF'] = 0;
                $data['emergency_others_costBF'] = 0;
                $data['ambulance_fuel_costBF'] = 0;
                $data['ambulance_road_costBF'] = 0;
                $data['ambulance_service_maintanance_costBF'] = 0;
                $data['doctor_service_commissionBF'] = 0;
                $data['general_expenseBF'] = 0;
                $data['lab_productBF'] = 0;
            } elseif ($report_type == 'Hospital') {
                $data['pathology_paidBF'] = 0;
                //$data['operation_paidBF'] = 0 ;
                //$data['operationInvoiceBF'] = 0 ;
                $data['consultancy_paidBF'] = 0;
                // $data['dueCollectionBF']  = 0 ;
                $data['emergency_paidBF']  = 0;
                $data['ambulance_paidBF'] = 0;
                $data['doctor_service_paidBF'] = 0;
                $data['donor_paidBF'] = 0;
                // $data['general_incomeBF'] = 0 ;
                $data['sales_paid_amountBF'] = 0;
                $data['pharmacy_collectionBF'] = 0;
                $data['purchase_paid_amountBF'] = 0;
                $data['supplier_paymentsBF'] = 0;

                $data['doctor_commission_patholgyBF'] = 0;
                $data['consultancy_doctor_commissionBF']  = 0;
                // $data['operation_commissionBF'] = 0 ;
                $data['sonologistExpenseBF'] = 0;
                // $data['staffSalaryBF'] = 0 ;
                $data['emergency_doctor_commissionBF'] = 0;
                $data['emergency_others_costBF'] = 0;
                $data['ambulance_fuel_costBF'] = 0;
                $data['ambulance_road_costBF'] = 0;
                $data['ambulance_service_maintanance_costBF'] = 0;
                $data['doctor_service_commissionBF'] = 0;
                //  $data['general_expenseBF'] = 0 ;
                $data['lab_productBF'] = 0;
            } elseif ($report_type == 'Pharmacy') {
                $data['pathology_paidBF'] = 0;
                $data['operation_paidBF'] = 0;
                $data['operationInvoiceBF'] = 0;
                $data['consultancy_paidBF'] = 0;
                $data['dueCollectionBF']  = 0;
                $data['emergency_paidBF']  = 0;
                $data['ambulance_paidBF'] = 0;
                $data['doctor_service_paidBF'] = 0;
                $data['donor_paidBF'] = 0;
                //  $data['general_incomeBF'] = 0 ;
                //  $data['sales_paid_amountBF'] = 0 ;
                // $data['pharmacy_collectionBF'] = 0 ;

                //$data['purchase_paid_amountBF'] = 0 ;
                //$data['supplier_paymentsBF'] = 0 ;

                $data['doctor_commission_patholgyBF'] = 0;
                $data['consultancy_doctor_commissionBF']  = 0;
                $data['operation_commissionBF'] = 0;
                $data['sonologistExpenseBF'] = 0;
                $data['staffSalaryBF'] = 0;
                $data['emergency_doctor_commissionBF'] = 0;
                $data['emergency_others_costBF'] = 0;
                $data['ambulance_fuel_costBF'] = 0;
                $data['ambulance_road_costBF'] = 0;
                $data['ambulance_service_maintanance_costBF'] = 0;
                $data['doctor_service_commissionBF'] = 0;
                //  $data['general_expenseBF'] = 0 ;
                //  $data['lab_productBF'] = 0  ;

            } elseif ($report_type == 'Service') {
                $data['pathology_paidBF'] = 0;
                $data['operation_paidBF'] = 0;
                $data['operationInvoiceBF'] = 0;
                $data['consultancy_paidBF'] = 0;
                $data['dueCollectionBF']  = 0;
                // $data['emergency_paidBF']  = 0 ;
                // $data['ambulance_paidBF'] = 0 ;
                // $data['doctor_service_paidBF'] = 0 ;
                // $data['donor_paidBF'] = 0 ;
                $data['general_incomeBF'] = 0;
                $data['sales_paid_amountBF'] = 0;
                $data['pharmacy_collectionBF'] = 0;
                $data['purchase_paid_amountBF'] = 0;
                $data['supplier_paymentsBF'] = 0;

                $data['doctor_commission_patholgyBF'] = 0;
                $data['consultancy_doctor_commissionBF']  = 0;
                $data['operation_commissionBF'] = 0;
                $data['sonologistExpenseBF'] = 0;
                $data['staffSalaryBF'] = 0;
                // $data['emergency_doctor_commissionBF'] = 0 ;
                // $data['emergency_others_costBF'] = 0 ;
                // $data['ambulance_fuel_costBF'] = 0 ;
                // $data['ambulance_road_costBF'] = 0 ;
                // $data['ambulance_service_maintanance_costBF'] = 0 ;
                //  $data['doctor_service_commissionBF'] = 0 ;
                $data['general_expenseBF'] = 0;
                $data['lab_productBF'] = 0;
            }

            $data['total_paid_amountBF'] = $data['pathology_paidBF'] +  $data['operation_paidBF'] + $data['operationInvoiceBF'] +  $data['consultancy_paidBF'] + $data['dueCollectionBF']  + $data['emergency_paidBF']  + $data['ambulance_paidBF'] + $data['doctor_service_paidBF'] + $data['donor_paidBF'] + $data['general_incomeBF'] + $data['sales_paid_amountBF'] + $data['pharmacy_collectionBF'];
            $data['total_expense_amountBF'] = $data['doctor_commission_patholgyBF'] + $data['consultancy_doctor_commissionBF']  + $data['operation_commissionBF'] + $data['sonologistExpenseBF'] + $data['staffSalaryBF'] + $data['emergency_doctor_commissionBF'] + $data['emergency_others_costBF'] + $data['ambulance_fuel_costBF'] +  $data['ambulance_road_costBF'] + $data['ambulance_service_maintanance_costBF'] + $data['doctor_service_commissionBF'] + $data['general_expenseBF'] + $data['lab_productBF'] + $data['purchase_paid_amountBF'] + $data['supplier_paymentsBF'];
            $data['balance_amountBF'] = $data['total_paid_amountBF'] - $data['total_expense_amountBF'];

            $grand_total_incomeBF += $data['total_paid_amountBF'];
            $grand_total_expenseBF += $data['total_expense_amountBF'];
            $grand_total_balanceBF += $data['balance_amountBF'];
            $data['grand_total_balanceBF'] = $grand_total_balanceBF;


            // var_dump($grand_total_balanceBF);die;

            /**B/F**/


            $pathologyWhere = array();
            if (!admin()) {
                $pathologyWhere['show_hide'] = "Show";
            }
            $pathologyWhere['date >= '] = $date_from;
            $pathologyWhere['date <= '] = $date_to;
            $pathologyWhere['type'] = 'Test Invoice';
            $operationWhere = array();
            if (!admin()) {
                $operationWhere['show_hide'] = "Show";
            }
            $operationWhere['date >= '] = $date_from;
            $operationWhere['date <= '] = $date_to;
            $operationInvoiceWhere = array();
            if (!admin()) {
                $operationInvoiceWhere['show_hide'] = "Show";
            }
            $operationInvoiceWhere['date >= '] = $date_from;
            $operationInvoiceWhere['date <= '] = $date_to;
            //var_dump($operationInvoiceWhere);die;
            $operationInvoiceWhere['type'] = 'Admission';
            $operationWhere['type'] = 'Operation';

            $operationInvoiceAdvanceWhere = array();
            if (!admin()) {
                $operationInvoiceAdvanceWhere['show_hide'] = "Show";
            }
            $operationInvoiceAdvanceWhere['date >= '] = $date_from;
            $operationInvoiceAdvanceWhere['date <= '] = $date_to;
            $operationInvoiceAdvanceWhere['type'] = 'AdmissionAdvance';

            $operationDetailsWhere = array();
            if (!admin()) {
                $operationDetailsWhere['show_hide'] = "Show";
            }
            $operationDetailsWhere['operation_date'] = $date_from;

            $ecgWhere['date'] = $date_from;
            $ecgWhere['test_category'] = 'ECG';
            $xrayWhere['date >= '] = $date_from;
            $xrayWhere['date <= '] = $date_to;
            $xrayWhere['test_category'] = '%X-Ray%';
            $ultraWhere['date >= '] = $date_from;
            $ultraWhere['date <= '] = $date_to;
            $ultraWhere['test_category like'] = 'Ultrasonogram';

            $generalIncomeWhere = array();
            if (!admin()) {
                $generalIncomeWhere['show_hide'] = "Show";
            }
            $generalIncomeWhere['date >= '] = $date_from;
            $generalIncomeWhere['date <= '] = $date_to;

            $consultancyWhere = array();
            if (!admin()) {
                $consultancyWhere['show_hide'] = "Show";
            }
            $consultancyWhere['date >= '] = $date_from;
            $consultancyWhere['date <= '] = $date_to;
            $consultancyWhere['type'] = 'Appointment';
           
            $consultancycommWhere = array();
            if (!admin()) {
                $consultancycommWhere['show_hide'] = "Show";
            }
            $consultancycommWhere['doctor_visit_payment_date >= '] = $date_from;
            $consultancycommWhere['doctor_visit_payment_date <= '] = $date_to;
            $consultancycommWhere['doctor_visit_payment_status'] = 'Paid';
            $consultancyWhere['type'] = 'Appointment';

            $commission_patholgyWhere = array();
            if (!admin()) {
                $commission_patholgyWhere['show_hide'] = "Show";
            }
            $commission_patholgyWhere['type'] = 'Test Invoice';
            $commission_patholgyWhere['date >= '] = $date_from;
            $commission_patholgyWhere['date <= '] = $date_to;



            $operation_commissionWhere = array();
            if (!admin()) {
                $operation_commissionWhere['show_hide'] = "Show";
            }
            $operation_commissionWhere['payment_status'] = 'Paid';
            $operation_commissionWhere['operation_date >='] = $date_from;
            $operation_commissionWhere['operation_date <='] = $date_to;

            $sonologistExpenseWhere = array();
            if (!admin()) {
                $sonologistExpenseWhere['show_hide'] = "Show";
            }
            if ($report_type) {
                $sonologistExpenseWhere['expense_type'] = $report_type;
            }
            $sonologistExpenseWhere['date >= '] = $date_from;
            $sonologistExpenseWhere['date <= '] = $date_to;

            $generalExpenseWhere = array();
            if (!admin()) {
                $generalExpenseWhere['show_hide'] = "Show";
            }
            $generalExpenseWhere['expense_type != '] = 'Pharmacy';
            $generalExpenseWhere['date >= '] = $date_from;
            $generalExpenseWhere['date <= '] = $date_to;
            $staffSalaryWhere = array();
            if (!admin()) {
                $staffSalaryWhere['show_hide'] = "Show";
            }
            $staffSalaryWhere['status'] = 'Paid';
            $staffSalaryWhere['date >= '] = $date_from;
            $staffSalaryWhere['date <= '] = $date_to;

            $dueCollectionWhere = array();
            if (!admin()) {
                $dueCollectionWhere['show_hide'] = "Show";
            }
            $dueCollectionWhereIn = array();
            if ($report_type == 'Diagnostic') {
                $dueCollectionWhereIn = array('Test Invoice', 'Appointment');
            } elseif ($report_type == 'Hospital') {
                $dueCollectionWhereIn = array('Operation');
            }

            $dueCollectionWhereInColumn = 'invoice_type';
            $dueCollectionWhere['mr_date >= '] = $date_from;
            $dueCollectionWhere['mr_date <= '] = $date_to;


            $salesWhere = array();
            if (!admin()) {
                $salesWhere['show_hide'] = "Show";
            }
            $salesWhere['sales_from'] = 'Direct';
            $salesWhere['sales_date >= '] = $date_from;
            $salesWhere['sales_date <= '] = $date_to;

            $purchaseWhere = array();
            if (!admin()) {
                $purchaseWhere['show_hide'] = "Show";
            }
            $purchaseWhere['purchase_date >= '] = $date_from;
            $purchaseWhere['purchase_date <= '] = $date_to;

            $mrWhere = array();
            if (!admin()) {
                $mrWhere['show_hide'] = "Show";
            }
            $mrWhere['mr_date >= '] = $date_from;
            $mrWhere['mr_date <= '] = $date_to;

            $emergencyWhere = array();
            if (!admin()) {
                $emergencyWhere['emergencys.show_hide'] = "Show";
            }
            $emergencyWhere['date >= '] = $date_from;
            $emergencyWhere['date <= '] = $date_to;

            $ambulanceWhere = array();
            if (!admin()) {
                $ambulanceWhere['ambulance_receipts.show_hide'] = "Show";
            }
            $ambulanceWhere['date >= '] = $date_from;
            $ambulanceWhere['date <= '] = $date_to;

            $donorWhere = array();
            if (!admin()) {
                $donorWhere['blood_donors.show_hide'] = "Show";
            }
            $donorWhere['date >='] = $date_from;
            $donorWhere['date <='] = $date_to;

            $supplier_paymentsWhere = array();
            if (!admin()) {
                $supplier_paymentsWhere['show_hide'] = "Show";
            }
            $supplier_paymentsWhere['payment_date >='] = $date_from;
            $supplier_paymentsWhere['payment_date <= '] = $date_to;

            $incomeWhere = array();
            if (!admin()) {
                $incomeWhere['show_hide'] = "Show";
            }
            $incomeWhere['income_date >= '] = $date_from;
            $incomeWhere['income_date <= '] = $date_to;
            if ($report_type) $incomeWhere['income_type'] = $report_type;
            $expenseWhere = [
                'approval' => 'Approved'
            ];
            if (!admin()) {
                $expenseWhere['show_hide'] = "Show";
            }
            $expenseWhere['expense_date >= '] = $date_from;
            $expenseWhere['expense_date <= '] = $date_to;
            if ($report_type) $expenseWhere['expense_type'] = $report_type;

            $labInWhere = array();
            $labInWhere['approval'] = "Paid";
            if (!admin()) {
                $labInWhere['show_hide'] = "Show";
            }
            $labInWhere['in_date >= '] = $date_from;
            $labInWhere['in_date <= '] = $date_to;



            $data["appointments"] = $this->Common_model->findAll("create_bill", $consultancyWhere, 'record_id', 'asc');
            $data["appointment_commissions"] = $this->Common_model->findAll("create_bill", $consultancycommWhere, 'record_id', 'asc');

            $data["due_collection"] = $this->Common_model->findAllWhereIn("due_collection_details", $dueCollectionWhere, $dueCollectionWhereIn, $dueCollectionWhereInColumn, 'mr_details_id', 'asc');

            $data["sales_test"] = $this->Common_model->findAll("create_bill", $pathologyWhere, "record_id", "asc");
            //var_dump( $pathologyWhere) ;die;
            $data["income_res"] = $this->Common_model->findAll("incomes", $incomeWhere, 'income_id', 'asc');
            $data["expense_res"] = $this->Common_model->findAll("expenses", $expenseWhere, 'expense_id', 'asc');
            $data["son_expense_res"] = $this->Common_model->findAll("sonologist", $sonologistExpenseWhere, 'record_id', 'asc');

            $data['operationDoctorAndAnesthesia'] = $this->Common_model->findAll('operation_details', $operation_commissionWhere, '', 'asc');

            $data['admissionInvoice'] = $this->Common_model->findAll('create_bill', $operationInvoiceWhere, 'record_id', 'asc');

            $data['admissionInvoiceAdvance'] = $this->Common_model->findAll('create_bill', $operationInvoiceAdvanceWhere, 'record_id', 'asc');

            $data['operationIncomes'] = $this->Common_model->findAll('create_bill', $operationWhere, 'record_id', 'asc');
            $data['emergencys'] = $this->Common_model->findAll('emergencys', $emergencyWhere, 'record_id', 'asc');
            $data['ambulance_receipts'] = $this->Common_model->findAll('ambulance_receipts', $ambulanceWhere, 'record_id', 'asc');
            $doctorServiceWhere = array();
            if (!admin()) {
                $doctorServiceWhere['show_hide'] = "Show";
            }
            $doctorServiceWhere['type'] = 'Doctor Service';
            $doctorServiceWhere['date >= '] = $date_from;
            $doctorServiceWhere['date <= '] = $date_to;
            $data['doctor_services'] = $this->Common_model->findAll('create_bill', $doctorServiceWhere, 'record_id', 'desc');

            $options = array(
                'joins' => array(
                    array(
                        'table' => 'doctor',
                        'condition' => 'doctor.record_id = blood_donors.doctor_id',
                        'jointype' => 'LEFT'
                    ), array(
                        'table' => 'designation',
                        'condition' => 'designation.record_id = doctor.designation_id',
                        'jointype' => 'LEFT'
                    ),
                    array(
                        'table' => 'patient',
                        'condition' => 'patient.record_id = blood_donors.patient_id',
                        'jointype' => 'LEFT'
                    ),
                    array(
                        'table' => 'blood_groups',
                        'condition' => 'blood_groups.record_id = blood_donors.blood_group_id',
                        'jointype' => 'LEFT'
                    ), array(
                        'table' => 'test_name',
                        'condition' => 'test_name.record_id = blood_donors.test_id',
                        'jointype' => 'LEFT'
                    ),
                ),
                'select' => 'blood_donors.*,blood_donors.record_id as blood_donor_id,doctor.record_id as doctor_id,doctor.name as doctor_name,doctor.mobile as doctor_mobile,designation.designation as doctor_designation,blood_groups.group_name,patient.*,test_name.test_name',
                'where' => $donorWhere,
                'order' => array(
                    'blood_donors.record_id' => 'desc',
                ),
            );

            $data['blood_donors'] = $this->Common_model->commonJoins("blood_donors", $options);
            $data['sales_orders'] = $this->Common_model->findAll('sales_orders', $salesWhere, 'sales_id', 'asc');
            //var_dump($purchaseWhere);die;
            $data['purchase_orders'] = $this->Common_model->findAll('purchase_orders', $purchaseWhere, 'purchase_id', 'asc');
            $data['mrs'] = $this->Common_model->findAll('mr', $mrWhere, 'mr_id', 'asc');
            $data['supplier_payments'] = $this->Common_model->findAll('supplier_payments', $supplier_paymentsWhere, 'payment_id', 'asc');


            $staffSalaryWhere['date >='] = $date_from;
            $staffSalaryWhere['date <='] = $date_to;

            $data['staffSalary'] = $this->Common_model->findAllGroupBySum('create_salary_sheet', $staffSalaryWhere, 'month', 'net_salary');

            $staffSalaryAdvWhere = array();
            $staffSalaryAdvWhere['date >='] = $date_from;
            $staffSalaryAdvWhere['date <='] = $date_to;
            $data['staffSalaryadvance'] = $this->Common_model->findAllGroupBySum('create_salary_sheet_advanced', $staffSalaryAdvWhere, 'month', 'advanced_amount');

            $data['lab_products'] = $this->Common_model->findAll('lab_product_in', $labInWhere, 'record_id', 'asc');
            // $data['lab_products'] = $this->Common_model->calCulateSum('lab_product_in', $labInWhere, 'grand_total_price');


            $dressingWhere = array();
            if (!admin()) {
                $where['dressing.show_hide'] = "Show";
            }
            $dressingWhere['dressing.date >='] = $date_from;
            $dressingWhere['dressing.date <='] = $date_to;
            $options = array(
                'joins' => array(
                    array(
                        'table' => 'doctor as service',
                        'condition' => 'service.record_id = dressing.service_doctor',
                        'jointype' => 'LEFT'
                    ),
                    array(
                        'table' => 'doctor as referred',
                        'condition' => 'referred.record_id = dressing.referred_doctor',
                        'jointype' => 'LEFT'
                    ),
                    array(
                        'table' => 'designation as service_designation',
                        'condition' => 'service_designation.record_id = service.designation_id',
                        'jointype' => 'LEFT'
                    ),
                    array(
                        'table' => 'designation as referred_designation',
                        'condition' => 'referred_designation.record_id = referred.designation_id',
                        'jointype' => 'LEFT'
                    ),
                    array(
                        'table' => 'patient',
                        'condition' => 'patient.record_id = dressing.patient_id',
                        'jointype' => 'LEFT'
                    ),
                    array(
                        'table' => 'department',
                        'condition' => 'department.record_id = dressing.department_id',
                        'jointype' => 'LEFT'
                    ),
                ),
                'select' => 'dressing.*,dressing.record_id as dressing_id,service.record_id as service_id,service.name as service_doctor,service.mobile as service_doctor_mobile,service_designation.designation as service_doctor_designation,referred.record_id as referred_id ,referred.name as referred_doctor,referred.mobile as referred_doctor_mobile,referred_designation.designation as referred_doctor_designation,department.department,patient.*',
                'where' => $dressingWhere,
                'order' => array(
                    'dressing.record_id' => 'desc',
                ),
            );

            $data['dressing_values'] = $this->Common_model->commonJoins("dressing", $options);
            $data['report_type'] = $report_type;

             // calculate ref commsissions
             $refCommWhere = [];
             $refCommWhere['create_bill.test_invoice_payment_date >='] = $date_from;
             $refCommWhere['create_bill.test_invoice_payment_date <='] = $date_to;
             $refCommWhere['create_bill.type'] = 'Test Invoice';
             $refCommWhere['create_bill.test_invoice_payment_status'] = 'Paid';
 
             $sales_test_ref_commissions = $this->Common_model->getRfCommissionReports($refCommWhere);
             
             $data['ref_by_commissions'] = $sales_test_ref_commissions;

             $bankTransWhare = [
                'date >=' => $date_from, 
                'date <=' => $date_to, 
             ];

             $data['bank_transations'] = $this->Common_model->findAll('bank_transations',$bankTransWhare,'record_id','DESC');

             //dd($data['bank_transations']);

            $this->load->view('admin/reports/show_details_cash_report', $data);
        }
    }


    public function daily_report()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Daily Income/Expense Report';
            $data['page_title'] = 'Daily Income/Expense Report';
            $data['staff'] = $this->Common_model->findAll('staff', array(), 'record_id', 'asc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/reports/daily_report', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function show_daily_income_expense()
    {
        $data['title'] = 'Daily Income/Expense Report';
        $userType = $this->session->userdata('ses_user_type');
        $ses_record_id = $this->session->userdata('ses_record_id');

        $created_by = $this->input->post('created_by');
        //var_dump($created_by) ;die;
        $current_date = $this->input->post('date_from');
        $previous_date =  date_sub(date_create($current_date), date_interval_create_from_date_string("1 days"));
        $previous_date = date_format($previous_date, "Y-m-d");

        /* B/F */

        $pathologyWhereBF = array();
        $pathologyWhereBF['date'] = $previous_date;
        $pathologyWhereBF['type'] = 'Test Invoice';
        // var_dump($pathologyWhereBF);die;
        $operationWhereBF['date'] = $previous_date;
        $operationInvoiceWhereBF['date'] = $previous_date;
        $operationInvoiceWhereBF['type'] = 'Admission';
        $operationWhereBF['type'] = 'Operation';

        $operationDetailsWhereBF = array();
        $operationDetailsWhereBF['operation_date'] = $previous_date;

        // var_dump($pathologyWhereBF);die;

        $ecgWhereBF['date'] = $previous_date;
        $ecgWhereBF['test_category'] = 'ECG';
        $xrayWhereBF['date'] = $previous_date;
        $xrayWhereBF['test_category like'] = '%X-Ray%';
        $ultraWhereBF['date'] = $previous_date;
        $ultraWhereBF['test_category like'] = 'Ultrasonogram';

        $generalIncomeWhereBF = array();
        $generalIncomeWhereBF['date'] = $previous_date;

        $consultancyWhereBF = array();
        $consultancyWhereBF['type'] = 'Appointment';
        $consultancyWhereBF['date'] = $previous_date;

        $commission_patholgyWhereBF = array();
        $commission_patholgyWhereBF['type'] = 'Test Invoice';
        $commission_patholgyWhereBF['date'] = $previous_date;



        $operation_commissionWhereBF = array();
        $operation_commissionWhereBF['operation_date'] = $previous_date;

        $sonologistExpenseWhereBF = array();
        $sonologistExpenseWhereBF['date'] = $previous_date;

        $generalExpenseWhereBF = array();
        $generalExpenseWhereBF['date'] = $previous_date;
        $staffSalaryWhereBF = array();
        $staffSalaryWhereBF['status'] = 'Paid';
        $staffSalaryWhereBF['date'] = $previous_date;

        $dueCollectionWhereBF = array();
        $dueCollectionWhereBF['mr_date'] = $previous_date;


        $salesWhereBF = array();
        $salesWhereBF['sales_from'] = 'Direct';
        $salesWhereBF['sales_date'] = $previous_date;

        $mrWhereBF = array();
        $mrWhereBF['mr_date'] = $previous_date;

        $emergencyWhereBF = array();
        $emergencyWhereBF['type'] = 'Emergency';
        $emergencyWhereBF['date'] = $previous_date;

        $ambulanceWhereBF = array();
        $ambulanceWhereBF['type'] = 'Ambulance';
        $ambulanceWhereBF['date'] = $previous_date;

        $doctorServiceWhereBF = array();
        $doctorServiceWhereBF['type'] = 'Doctor Service';
        $doctorServiceWhereBF['date'] = $previous_date;

        $donorWhereBF = array();
        $donorWhereBF['type'] = 'Donor';
        $donorWhereBF['date'] = $previous_date;

        $dressingWhereBF = array();
        $dressingWhereBF['type'] = 'Dressing';
        $dressingWhereBF['date'] = $previous_date;

        $supplier_paymentsWhereBF = array();
        $supplier_paymentsWhereBF['payment_date'] = $previous_date;

        $incomeWhereBF = array();
        $incomeWhereBF['income_date'] = $previous_date;
        $expenseWhereBF = array();
        $expenseWhereBF['expense_date'] = $previous_date;

        $labInWhereBF = array();
        $labInWhereBF['in_date'] = $previous_date;

        if (!empty($created_by)) {
            $pathologyWhereBF['created_by'] = $created_by;
            $operationWhereBF['created_by'] = $created_by;
            $operationInvoiceWhereBF['created_by'] = $created_by;
            $operationDetailsWhereBF['created_by'] = $created_by;
            $ecgWhereBF['created_by'] = $created_by;
            $xrayWhereBF['created_by'] = $created_by;
            $ultraWhere['created_by'] = $created_by;
            $generalIncomeWhereBF['created_by'] = $created_by;
            $consultancyWhereBF['created_by'] = $created_by;
            $commission_patholgyWhereBF['created_by'] = $created_by;
            $operation_commissionWhereBF['created_by'] = $created_by;
            $generalExpenseWhereBF['created_by'] = $created_by;
            $staffSalaryWhereBF['created_by'] = $created_by;
            $dueCollectionWhereBF['created_by'] = $created_by;
            $salesWhereBF['created_by'] = $created_by;
            $emergencyWhereBF['created_by'] = $created_by;
            $ambulanceWhereBF['created_by'] = $created_by;
            $doctorServiceWhereBF['created_by'] = $created_by;
            $donorWhereBF['created_by'] = $created_by;
            $dressingWhereBF['created_by'] = $created_by;
            $supplier_paymentsWhereBF['created_by'] = $created_by;
            $incomeWhereBF['created_by'] = $created_by;
            $expenseWhereBF['created_by'] = $created_by;
            $labInWhereBF['created_by'] = $created_by;
        }

        $data['pathologyBF'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhereBF, 'sub_total');
        $data['pathology_paidBF'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhereBF, 'paid');
        $data['pathology_dueBF'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhereBF, 'due');
        // var_dump($data['pathology_paidBF']);die;
        $data['operationBF'] = $this->Common_model->calCulateSum('create_bill', $operationWhereBF, 'sub_total');
        $operation_paidBF = $this->Common_model->calculateSumMultiple('create_bill', $operationWhereBF, array('paid', 'medicine_cost'));
        $data['operation_paidBF'] = $operation_paidBF->paid; // + $operation_paid->medicine_cost ; //+ $operation_paid->advance ;
        $data['operation_dueBF'] = $this->Common_model->calCulateSum('create_bill', $operationWhereBF, 'due');


        $operationInvoiceBF = $this->Common_model->calculateSumMultiple('create_bill', $operationInvoiceWhereBF, array('sub_total', 'advance'));
        $data['operationInvoiceBF'] = $operationInvoiceBF->sub_total + $operationInvoiceBF->advance;

        $data['ecgBF'] = $this->Common_model->calCulateSum('sales_test', $ecgWhereBF, 'test_price');
        $data['xrayBF'] = $this->Common_model->calCulateSum('sales_test', $xrayWhereBF, 'test_price');
        $data['ultraBF'] = $this->Common_model->calCulateSum('sales_test', $ultraWhereBF, 'test_price');


        $consultancyBF = $this->Common_model->calculateSumMultiple('create_bill', $consultancyWhereBF, array('sub_total', 'paid', 'due', 'doctor_commission'));
        //var_dump($consultancy);die;
        $data['consultancyBF'] = isset($consultancyBF) ?  $consultancyBF->sub_total : 0;
        $data['consultancy_paidBF'] = isset($consultancyBF) ?  $consultancyBF->paid : 0;
        $data['consultancy_dueBF'] = isset($consultancyBF) ?  $consultancyBF->due : 0;
        $data['consultancy_doctor_commissionBF'] = isset($consultancyBF) ?  $consultancyBF->doctor_commission : 0;
        $doctor_commission_patholgyBF = $this->Common_model->calculateSumMultiple('create_bill', $commission_patholgyWhereBF, array('doctor_commission', 'reference_by_commission'));
        $doctor_commissionBF = isset($doctor_commission_patholgyBF) ? $doctor_commission_patholgyBF->doctor_commission : 0;
        $reference_by_commissionBF = isset($doctor_commission_patholgyBF) ? $doctor_commission_patholgyBF->reference_by_commission : 0;
        $data['doctor_commission_patholgyBF'] = $doctor_commissionBF + $reference_by_commissionBF;

        $operation_commissionBF =  $this->Common_model->calculateSumMultiple('operation_details', $operationDetailsWhereBF, array('surgeon_commission', 'surgeon_assistant_commission', 'anesthesia_commission', 'medicine_cost'));
        $surgeon_commissionBF = isset($operation_commissionBF) ? $operation_commissionBF->surgeon_commission : 0;
        $anesthesia_commissionBF = isset($operation_commissionBF) ? $operation_commissionBF->anesthesia_commission : 0;
        $medicine_costBF = isset($operation_commissionBF) ? $operation_commissionBF->medicine_cost : 0;
        $surgeon_assistant_commissionBF = isset($operation_commissionBF) ? $operation_commissionBF->surgeon_assistant_commission : 0;
        $data['operation_commissionBF'] =  $surgeon_commissionBF + $anesthesia_commissionBF + $medicine_costBF + $surgeon_assistant_commissionBF;

        $data['sonologistExpenseBF'] = $this->Common_model->calCulateSum('sonologist', $sonologistExpenseWhereBF, 'amount');

        $data['staffSalaryBF'] = $this->Common_model->calCulateSum('create_salary_sheet', $staffSalaryWhereBF, 'net_salary');

        $data['dueCollectionBF'] = $this->Common_model->calCulateSum('due_collections', $dueCollectionWhereBF, 'mr_amount');

        $sales_ordersBF = $this->Common_model->calculateSumMultiple('sales_orders', $salesWhereBF, array('grand_net_total', 'paid_amount', 'due_amount'));
        $data['sales_amountBF'] = $sales_ordersBF->grand_net_total;
        $data['sales_paid_amountBF'] = $sales_ordersBF->paid_amount;
        $data['sales_due_amountBF'] = $sales_ordersBF->due_amount;
        $data['pharmacy_collectionBF'] = $this->Common_model->calCulateSum('mr', $mrWhereBF, 'mr_amount');

        $data['supplier_paymentsBF'] = $this->Common_model->calCulateSum('supplier_payments', $supplier_paymentsWhereBF, 'payment_amount');



        $emergencyBF = $this->Common_model->calculateSumMultiple('create_bill', $emergencyWhereBF, array('sub_total', 'paid', 'doctor_commission', 'others_cost'));
        $data['emergency_totalBF'] = isset($emergencyBF) ? $emergencyBF->sub_total : 0;
        $data['emergency_paidBF'] = isset($emergencyBF) ? $emergencyBF->paid : 0;
        $data['emergency_doctor_commissionBF'] = isset($emergencyBF) ? $emergencyBF->doctor_commission : 0;
        $data['emergency_others_costBF'] = isset($emergencyBF) ? $emergencyBF->others_cost : 0;

        $ambulanceBF = $this->Common_model->calculateSumMultiple('create_bill', $ambulanceWhereBF, array('sub_total', 'paid', 'fuel_cost', 'road_cost', 'service_maintanance_cost'));
        $data['ambulance_totalBF'] = isset($ambulanceBF) ? $ambulanceBF->sub_total : 0;
        $data['ambulance_paidBF'] = isset($ambulanceBF) ? $ambulanceBF->paid : 0;
        $data['ambulance_fuel_costBF'] = isset($ambulanceBF) ? $ambulanceBF->fuel_cost : 0;
        $data['ambulance_road_costBF'] = isset($ambulanceBF) ? $ambulanceBF->road_cost : 0;
        $data['ambulance_service_maintanance_costBF'] = isset($ambulanceBF) ? $ambulanceBF->service_maintanance_cost : 0;

        $doctor_serviceBF = $this->Common_model->calculateSumMultiple('create_bill', $doctorServiceWhereBF, array('sub_total', 'paid', 'due', 'doctor_commission', 'reference_by_commission'));
        $data['doctor_service_totalBF'] = isset($doctor_serviceBF) ? $doctor_serviceBF->sub_total : 0;
        $data['doctor_service_paidBF'] = isset($doctor_serviceBF) ? $doctor_serviceBF->paid : 0;
        $data['doctor_service_reference_by_commissionBF'] = isset($doctor_serviceBF) ? $doctor_serviceBF->reference_by_commission : 0;
        $data['doctor_service_commissionBF'] = isset($doctor_serviceBF) ? $doctor_serviceBF->doctor_commission : 0;
        $data['doctor_service_commissionBF'] = $data['doctor_service_reference_by_commissionBF'] + $data['doctor_service_commissionBF'];
        $data['doctor_service_dueBF'] = isset($doctor_serviceBF) ? $doctor_serviceBF->due : 0;


        $donorBF = $this->Common_model->calculateSumMultiple('create_bill', $donorWhereBF, array('sub_total', 'paid'));
        $data['donor_totalBF'] = isset($donorBF) ? $donorBF->sub_total : 0;
        $data['donor_paidBF'] = isset($donorBF) ? $donorBF->paid : 0;

        $dressingBF = $this->Common_model->calculateSumMultiple('create_bill', $dressingWhereBF, array('sub_total', 'paid', 'doctor_commission'));
        $data['dressing_totalBF'] = isset($dressingBF) ? $dressingBF->sub_total : 0;
        $data['dressing_paidBF'] = isset($dressingBF) ? $dressingBF->paid : 0;
        $data['dressing_doctor_commissionBF'] = isset($dressingBF) ? $dressingBF->doctor_commission : 0;


        $data['general_incomeBF'] = $this->Common_model->calCulateSum('incomes', $incomeWhereBF, 'voucher_amount');
        $data['general_expenseBF'] = $this->Common_model->calCulateSum('expenses', $expenseWhereBF, 'voucher_amount');
        $data['lab_productBF'] = $this->Common_model->calCulateSum('lab_product_in', $labInWhereBF, 'grand_total_price');
        $data['total_paid_amountBF'] = $data['pathology_paidBF'] +  $data['operation_paidBF'] + $data['operationInvoiceBF'] +  $data['consultancy_paidBF'] + $data['dueCollectionBF']  + $data['emergency_paidBF']  + $data['ambulance_paidBF'] + $data['doctor_service_paidBF'] +  $data['general_incomeBF'] + $data['donor_paidBF'] + $data['dressing_paidBF'] + $data['sales_paid_amountBF'];
        $data['total_expense_amountBF'] = $data['doctor_commission_patholgyBF'] + $data['consultancy_doctor_commissionBF']  + $data['operation_commissionBF'] + $data['sonologistExpenseBF'] + $data['staffSalaryBF']  + $data['emergency_doctor_commissionBF'] + $data['emergency_others_costBF'] + $data['ambulance_fuel_costBF'] +  $data['ambulance_road_costBF'] + $data['ambulance_service_maintanance_costBF'] + $data['doctor_service_commissionBF'] + $data['general_expenseBF'] + $data['lab_productBF'] + $data['dressing_doctor_commissionBF'] + $data['supplier_paymentsBF'];
        $data['balance_amountBF'] = $data['total_paid_amountBF'] - $data['total_expense_amountBF'];

        /* B/F */

        $pathologyWhere = array();
        if (!admin()) {
            $pathologyWhere['show_hide'] = "Show";
        }
        $pathologyWhere['date'] = $current_date;
        $pathologyWhere['type'] = 'Test Invoice';
        $operationWhere = array();
        if (!admin()) {
            $operationWhere['show_hide'] = "Show";
        }
        $operationWhere['date'] = $current_date;
        $operationInvoiceWhere = array();
        if (!admin()) {
            $operationInvoiceWhere['show_hide'] = "Show";
        }
        $operationInvoiceWhere['date'] = $current_date;
        $operationInvoiceWhere['type'] = 'Admission';
        $operationAdmissionAdvanceInvoiceWhere = array();
        if (!admin()) {
            $operationAdmissionAdvanceInvoice['show_hide'] = "Show";
        }
        $operationAdmissionAdvanceInvoiceWhere['date'] = $current_date;
        $operationAdmissionAdvanceInvoiceWhere['type'] = 'AdmissionAdvance';
        $operationWhere['type'] = 'Operation';

        $operationDetailsWhere = array();
        if (!admin()) {
            $operationDetailsWhere['show_hide'] = "Show";
        }
        $operationDetailsWhere['payment_status'] = 'Paid';
        $operationDetailsWhere['operation_date'] = $current_date;

        $ecgWhere['date'] = $current_date;
        $ecgWhere['test_category'] = 'ECG';
        $xrayWhere['date'] = $current_date;
        $xrayWhere['test_category like'] = '%X-Ray%';
        $ultraWhere['date'] = $current_date;
        $ultraWhere['test_category like'] = 'Ultrasonogram';

        $generalIncomeWhere = array();
        if (!admin()) {
            $generalIncomeWhere['show_hide'] = "Show";
        }
        $generalIncomeWhere['date'] = $current_date;

        $consultancyWhere = array();
        if (!admin()) {
            $consultancyWhere['show_hide'] = "Show";
        }
        $consultancyWhere['type'] = 'Appointment';
        $consultancyWhere['doctor_visit_payment_date'] = $current_date;
        $consultancyWhere['doctor_visit_payment_status'] = 'Paid';

        $consultancypayWhere = array();
        if (!admin()) {
            $consultancypayWhere['show_hide'] = "Show";
        }
        $consultancypayWhere['type'] = 'Appointment';
        $consultancypayWhere['date'] = $current_date;

        $commission_patholgyWhere = array();
        if (!admin()) {
            $commission_patholgyWhere['show_hide'] = "Show";
        }
        $commission_patholgyWhere['test_invoice_payment_status'] = 'Paid';
        $commission_patholgyWhere['type'] = 'Test Invoice';
        $commission_patholgyWhere['test_invoice_payment_date'] = $current_date;




        $operation_commissionWhere = array();
        if (!admin()) {
            $operation_commissionWhere['show_hide'] = "Show";
        }
        $operation_commissionWhere['operation_date'] = $current_date;

        $sonologistExpenseWhere = array();
        if (!admin()) {
            $sonologistExpenseWhere['show_hide'] = "Show";
        }
        $sonologistExpenseWhere['date'] = $current_date;

        $generalExpenseWhere = array();
        if (!admin()) {
            $generalExpenseWhere['show_hide'] = "Show";
        }
        $generalExpenseWhere['date'] = $current_date;
        $staffSalaryWhere = array();
        if (!admin()) {
            $staffSalaryWhere['show_hide'] = "Show";
        }
        $staffSalaryWhere['status'] = 'Paid';
        $staffSalaryWhere['date'] = $current_date;
        $staffSalaryAdvWhere = array();
        $staffSalaryAdvWhere['date'] = $current_date;

        $dueCollectionWhere = array();
        if (!admin()) {
            $dueCollectionWhere['show_hide'] = "Show";
        }
        $dueCollectionWhere['mr_date'] = $current_date;


        $salesWhere = array();
        if (!admin()) {
            $salesWhere['show_hide'] = "Show";
        }
        $salesWhere['sales_from'] = 'Direct';
        $salesWhere['sales_date'] = $current_date;

        $mrWhere = array();
        if (!admin()) {
            $mrWhere['show_hide'] = "Show";
        }
        $mrWhere['mr_date'] = $current_date;

        $emergencyWhere = array();
        if (!admin()) {
            $emergencyWhere['show_hide'] = "Show";
        }
        $emergencyWhere['type'] = 'Emergency';
        $emergencyWhere['date'] = $current_date;

        $ambulanceWhere = array();
        if (!admin()) {
            $ambulanceWhere['show_hide'] = "Show";
        }
        $ambulanceWhere['type'] = 'Ambulance';
        $ambulanceWhere['date'] = $current_date;

        $doctorServiceWhere = array();
        if (!admin()) {
            $doctorServiceWhere['show_hide'] = "Show";
        }
        $doctorServiceWhere['type'] = 'Doctor Service';
        $doctorServiceWhere['date'] = $current_date;

        $donorWhere = array();
        if (!admin()) {
            $donorWhere['show_hide'] = "Show";
        }
        $donorWhere['type'] = 'Donor';
        $donorWhere['date'] = $current_date;

        $dressingWhere = array();
        if (!admin()) {
            $dressingWhere['show_hide'] = "Show";
        }
        $dressingWhere['type'] = 'Dressing';
        $dressingWhere['date'] = $current_date;

        $supplier_paymentsWhere = array();
        if (!admin()) {
            $supplier_paymentsWhere['show_hide'] = "Show";
        }
        $supplier_paymentsWhere['payment_date'] = $current_date;

        $incomeWhere = array();
        if (!admin()) {
            $incomeWhere['show_hide'] = "Show";
        }
        $incomeWhere['income_date'] = $current_date;
        $expenseWhere = [
            'approval'=>'Approved'
        ];
        if (!admin()) {
            $expenseWhere['show_hide'] = "Show";
        }
        $expenseWhere['expense_date'] = $current_date;

        $labInWhere = array();
        $labInWhere['approval'] = 'Paid';
        if (!admin()) {
            $labInWhere['show_hide'] = "Show";
        }
        $labInWhere['in_date'] = $current_date;
        //var_dump($labInWhere) ; die ;
        if (!empty($created_by)) {
            $pathologyWhere['created_by'] = $created_by;
            $operationWhere['created_by'] = $created_by;
            $operationInvoiceWhere['created_by'] = $created_by;
            $operationAdmissionAdvanceInvoiceWhere['created_by'] = $created_by;
            $operationDetailsWhere['created_by'] = $created_by;
            $ecgWhere['created_by'] = $created_by;
            $xrayWhere['created_by'] = $created_by;
            $ultraWhere['created_by'] = $created_by;
            $generalIncomeWhere['created_by'] = $created_by;
            $consultancyWhere['created_by'] = $created_by;
            $consultancypayWhere['created_by'] = $created_by;
            $commission_patholgyWhere['created_by'] = $created_by;
            $operation_commissionWhere['created_by'] = $created_by;
            $generalExpenseWhere['created_by'] = $created_by;
            $staffSalaryWhere['created_by'] = $created_by;
            $staffSalaryAdvWhere['created_by'] = $created_by;
            $dueCollectionWhere['created_by'] = $created_by;
            $salesWhere['created_by'] = $created_by;
            $emergencyWhere['created_by'] = $created_by;
            $ambulanceWhere['created_by'] = $created_by;
            $doctorServiceWhere['created_by'] = $created_by;
            $donorWhere['created_by'] = $created_by;
            $dressingWhere['created_by'] = $created_by;
            $supplier_paymentsWhere['created_by'] = $created_by;
            $incomeWhere['created_by'] = $created_by;
            $expenseWhere['created_by'] = $created_by;
            $labInWhere['created_by'] = $created_by;
        }

        $data['pathology'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhere, 'sub_total');
        $data['pathology_paid'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhere, 'paid');
        $data['pathology_due'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhere, 'due');
        //var_dump($data['pathology_paid']);die;
        $data['operation'] = $this->Common_model->calCulateSum('create_bill', $operationWhere, 'sub_total');
        $operation_paid = $this->Common_model->calculateSumMultiple('create_bill', $operationWhere, array('paid', 'medicine_cost'));
        $data['operation_paid'] = $operation_paid->paid; // + $operation_paid->medicine_cost ; //+ $operation_paid->advance ;
        $data['operation_due'] = $this->Common_model->calCulateSum('create_bill', $operationWhere, 'due');


        $operationInvoice = $this->Common_model->calculateSumMultiple('create_bill', $operationInvoiceWhere, array('sub_total', 'advance'));
        $data['operationInvoice'] = $operationInvoice->sub_total + $operationInvoice->advance;

        $operationAdmissionAdvanceInvoice = $this->Common_model->calculateSum('create_bill', $operationAdmissionAdvanceInvoiceWhere, 'sub_total');
        $data['operationAdmissionAdvanceInvoice'] = isset($operationAdmissionAdvanceInvoice) ? $operationAdmissionAdvanceInvoice : 0;

        $data['ecg'] = $this->Common_model->calCulateSum('sales_test', $ecgWhere, 'test_price');
        $data['xray'] = $this->Common_model->calCulateSum('sales_test', $xrayWhere, 'test_price');
        $data['ultra'] = $this->Common_model->calCulateSum('sales_test', $ultraWhere, 'test_price');


        $consultancy = $this->Common_model->calculateSumMultiple('create_bill', $consultancyWhere, array('sub_total', 'paid', 'due', 'doctor_commission'));
        $consultancy_payment = $this->Common_model->calculateSumMultiple('create_bill', $consultancypayWhere, array('sub_total', 'paid', 'due', 'doctor_commission'));
        //var_dump($consultancy);die;
        $data['consultancy'] = isset($consultancy) ?  $consultancy->sub_total : 0;
        $data['consultancy_paid'] = isset($consultancy_payment) ?  $consultancy_payment->paid : 0;
        $data['consultancy_due'] = isset($consultancy) ?  $consultancy->due : 0;
        $data['consultancy_doctor_commission'] = isset($consultancy) ?  $consultancy->doctor_commission : 0;
        //$doctor_commission_patholgy = $this->Common_model->calculateSumMultiple('create_bill', $commission_patholgyWhere, array('discount', 'doctor_commission', 'reference_by_commission'));
        //$test_invoice_discount = isset($doctor_commission_patholgy) ? $doctor_commission_patholgy->discount : 0;
        //$doctor_commission = isset($doctor_commission_patholgy) ? $doctor_commission_patholgy->doctor_commission : 0;
        //$reference_by_commission = isset($doctor_commission_patholgy) ? $doctor_commission_patholgy->reference_by_commission : 0;
        //$data['doctor_commission_patholgy'] = $doctor_commission + $reference_by_commission - $test_invoice_discount;
       
         // calculate ref commsissions
         $refCommWhere = [];
         if (!admin()) {
             $refCommWhere['show_hide'] = "Show";
         }
         $refCommWhere['test_invoice_payment_date'] = $current_date;
         $refCommWhere['type'] = 'Test Invoice';
         $refCommWhere['test_invoice_payment_status'] = 'Paid';
         if (!empty($created_by)) {
         $refCommWhere['created_by'] = $created_by;
         }

         $refCommWdishere = [];
         if (!admin()) {
            $refCommWdishere['show_hide'] = "Show";
         }
         $refCommWdishere['test_invoice_payment_date'] = $current_date;
         $refCommWdishere['type'] = 'Test Invoice';
         $refCommWdishere['test_invoice_payment_status'] = 'Paid';
         $refCommWdishere['reference_by_commission >'] = 0;
         if (!empty($created_by)) {
            $refCommWdishere['created_by'] = $created_by;
         }
 
         $reference_by_commission = $this->Common_model->calCulateSum('create_bill', $refCommWhere, 'reference_by_commission');
         $test_invoice_discount = $this->Common_model->calCulateSum('create_bill', $refCommWdishere, 'discount');
 
         //$test_invoice_discount = isset($doctor_commission_patholgy) ? $doctor_commission_patholgy->discount : 0;
         //$doctor_commission = isset($doctor_commission_patholgy) ? $doctor_commission_patholgy->doctor_commission : 0;
        //  dd($test_invoice_discount);
        
        //  $data['doctor_commission_patholgy'] = $reference_by_commission-$test_invoice_discount;
         $data['doctor_commission_patholgy'] = $reference_by_commission;

        $operation_commission =  $this->Common_model->calculateSumMultiple('operation_details', $operationDetailsWhere, array('surgeon_commission', 'surgeon_assistant_commission', 'anesthesia_commission', 'medicine_cost', 'service_fee', 'reference_by_payment'));
        $surgeon_commission = isset($operation_commission) ? $operation_commission->surgeon_commission : 0;
        $surgeon_commission = isset($operation_commission) ? $operation_commission->surgeon_commission : 0;
        $anesthesia_commission = isset($operation_commission) ? $operation_commission->anesthesia_commission : 0;
        $medicine_cost = isset($operation_commission) ? $operation_commission->medicine_cost : 0;
        $service_fee = isset($operation_commission) ? $operation_commission->service_fee : 0;
        $reference_by_payment = isset($operation_commission) ? $operation_commission->reference_by_payment : 0;
        $surgeon_assistant_commission = isset($operation_commission) ? $operation_commission->surgeon_assistant_commission : 0;
        $data['operation_commission'] =  $surgeon_commission + $anesthesia_commission + $medicine_cost + $surgeon_assistant_commission  + $service_fee + $reference_by_payment;

        $data['sonologistExpense'] = $this->Common_model->calCulateSum('sonologist', $sonologistExpenseWhere, 'amount');

        $data['staffSalary'] = $this->Common_model->calCulateSum('create_salary_sheet', $staffSalaryWhere, 'net_salary');
        $data['staffSalaryAdv'] = $this->Common_model->calCulateSum('create_salary_sheet_advanced', $staffSalaryAdvWhere, 'advanced_amount');

        $data['dueCollection'] = $this->Common_model->calCulateSum('due_collections', $dueCollectionWhere, 'mr_amount');

        $sales_orders = $this->Common_model->calculateSumMultiple('sales_orders', $salesWhere, array('grand_net_total', 'paid_amount', 'due_amount'));
        $data['sales_amount'] = $sales_orders->grand_net_total;
        $data['sales_paid_amount'] = $sales_orders->paid_amount;
        $data['sales_due_amount'] = $sales_orders->due_amount;
        $data['pharmacy_collection'] = $this->Common_model->calCulateSum('mr', $mrWhere, 'mr_amount');

        $data['supplier_payments'] = $this->Common_model->calCulateSum('supplier_payments', $supplier_paymentsWhere, 'payment_amount');



        $emergency = $this->Common_model->calculateSumMultiple('create_bill', $emergencyWhere, array('sub_total', 'paid', 'doctor_commission', 'others_cost'));
        $data['emergency_total'] = isset($emergency) ? $emergency->sub_total : 0;
        $data['emergency_paid'] = isset($emergency) ? $emergency->paid : 0;
        $data['emergency_doctor_commission'] = isset($emergency) ? $emergency->doctor_commission : 0;
        $data['emergency_others_cost'] = isset($emergency) ? $emergency->others_cost : 0;

        $ambulance = $this->Common_model->calculateSumMultiple('create_bill', $ambulanceWhere, array('sub_total', 'paid', 'fuel_cost', 'road_cost', 'service_maintanance_cost'));
        $data['ambulance_total'] = isset($ambulance) ? $ambulance->sub_total : 0;
        $data['ambulance_paid'] = isset($ambulance) ? $ambulance->paid : 0;
        $data['ambulance_fuel_cost'] = isset($ambulance) ? $ambulance->fuel_cost : 0;
        $data['ambulance_road_cost'] = isset($ambulance) ? $ambulance->road_cost : 0;
        $data['ambulance_service_maintanance_cost'] = isset($ambulance) ? $ambulance->service_maintanance_cost : 0;

        $doctor_service = $this->Common_model->calculateSumMultiple('create_bill', $doctorServiceWhere, array('sub_total', 'paid', 'due', 'doctor_commission', 'reference_by_commission'));
        $data['doctor_service_total'] = isset($doctor_service) ? $doctor_service->sub_total : 0;
        $data['doctor_service_paid'] = isset($doctor_service) ? $doctor_service->paid : 0;
        $data['doctor_service_reference_by_commission'] = isset($doctor_service) ? $doctor_service->reference_by_commission : 0;
        $data['doctor_service_commission'] = isset($doctor_service) ? $doctor_service->doctor_commission : 0;
        $data['doctor_service_commission'] = $data['doctor_service_reference_by_commission'] + $data['doctor_service_commission'];
        $data['doctor_service_due'] = isset($doctor_service) ? $doctor_service->due : 0;


        $donor = $this->Common_model->calculateSumMultiple('create_bill', $donorWhere, array('sub_total', 'paid'));
        $data['donor_total'] = isset($donor) ? $donor->sub_total : 0;
        $data['donor_paid'] = isset($donor) ? $donor->paid : 0;

        $dressing = $this->Common_model->calculateSumMultiple('create_bill', $dressingWhere, array('sub_total', 'paid', 'doctor_commission'));
        $data['dressing_total'] = isset($dressing) ? $dressing->sub_total : 0;
        $data['dressing_paid'] = isset($dressing) ? $dressing->paid : 0;
        $data['dressing_doctor_commission'] = isset($dressing) ? isset($dressing->doctor_commission) ? $dressing->doctor_commission : 0 : 0;

        $data['general_income'] = $this->Common_model->calCulateSum('incomes', $incomeWhere, 'voucher_amount');
        $data['general_expense'] = $this->Common_model->calCulateSum('expenses', $expenseWhere, 'voucher_amount');
        $data['lab_product'] = $this->Common_model->calCulateSum('lab_product_in', $labInWhere, 'grand_total_price');
        $bankWhere = [
            'date' => $current_date
        ];

        $bankDepositWhere =  $bankWhere;
        $bankDepositWhere['transation_type'] = 'Deposit';
        $bankWithdrawWhere = $bankWhere;
        $bankWithdrawWhere['transation_type'] = 'Withdraw';
        

        $data['bankDeposit'] = $this->Common_model->calCulateSum('bank_transations',  $bankDepositWhere, 'amount');
        $data['bankWithdraw'] = $this->Common_model->calCulateSum('bank_transations',  $bankWithdrawWhere, 'amount');
        



        $data['total_paid_amount'] = $data['pathology_paid'] +  $data['operation_paid'] + $data['operationInvoice'] +  $data['consultancy_paid'] + $data['dueCollection']  + $data['emergency_paid']  + $data['ambulance_paid'] + $data['doctor_service_paid'] +  $data['general_income'] + $data['donor_paid'] + $data['dressing_paid'] + $data['operationAdmissionAdvanceInvoice']+$data['bankWithdraw'];
        $data['total_expense_amount'] = $data['doctor_commission_patholgy'] + $data['consultancy_doctor_commission']  + $data['operation_commission'] + $data['sonologistExpense'] + $data['staffSalary'] + $data['staffSalaryAdv']  + $data['emergency_doctor_commission'] + $data['emergency_others_cost'] + $data['ambulance_fuel_cost'] +  $data['ambulance_road_cost'] + $data['ambulance_service_maintanance_cost'] + $data['doctor_service_commission'] + $data['general_expense'] + $data['lab_product'] + $data['dressing_doctor_commission'] +$data['bankDeposit'];
        $data['balance_amount'] = $data['total_paid_amount'] - $data['total_expense_amount'];

        $cash_in_hand = $this->Common_model->calCulateSum('balance_transfer', array('date' => $current_date, 'particular_id' => 1), 'transfer_amount');
        $data['cash_in_hand'] = isset($cash_in_hand) ? $cash_in_hand : 0;
        $cash_in_bank = $this->Common_model->calCulateSum('balance_transfer', array('date' => $current_date, 'particular_id' => 2), 'transfer_amount');
        $data['cash_in_bank'] = isset($cash_in_bank) ? $cash_in_bank : 0;
        // dd($current_date);


        $data['redirect'] = base_url('reports/daily_report');
        $this->load->view('admin/reports/show_daily_income_expense', $data);
    }


    public function expired_medicine_product()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Expired Medicine/Product';
            $data['page_title'] = 'Expired Medicine/Product';
            $data['info_header'] = 'Expired Medicine/Product';

            // $where1 = array();
            // $options1 = array(
            //     'joins' => array(
            //         array(
            //             'table' => 'units',
            //             'condition' => 'units.record_id = product_name.unit_id',
            //             'jointype' => 'LEFT'
            //         ),
            //         array(
            //             'table' => 'generic_names',
            //             'condition' => 'generic_names.record_id = product_name.product_category_generic_name_id',
            //             'jointype' => 'LEFT'
            //         ),
            //     ),
            //     'select' => 'product_name.*,units.unit_short_name,generic_names.generic_name',
            //     'where' => $where1,
            //     'order' => array(
            //         'product_name.product_name' => 'asc',
            //     ),
            // );
            // $data['products'] = $this->Common_model->commonJoins("product_name", $options1);



            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $product_id = $this->input->get('product_id');
            $type = $this->input->get('type') === 'optic' ? 'optic' : 'medicine';
            $supplier_id = $this->input->get('supplier_id');


            $where = array();

            // if (!isset($from_date) && !isset($to_date) && !isset($product_id)) {
            //     //$where['expired_date <='] = date('Y-m-d');
            //     $where['expired_date <= '] = date("Y-m-d", strtotime("+6 months"));
            // }
             if ($product_id) $where['product_id'] = $product_id;
             if ($supplier_id) $where['purchase_orders.supplier_id'] = $supplier_id;

            // if (!empty($from_date) && !empty($to_date)) {
            //     $where['expired_date >= '] = $from_date;
            //     $where['expired_date <= '] = $to_date;
            // } elseif (!empty($from_date) && empty($to_date)) {
            //     $where['expired_date'] = $from_date;
            // } elseif (empty($from_date) && !empty($to_date)) {
            //     $where['expired_date'] = $to_date;
            // }
            $where['expired_date <= '] = date("Y-m-d", strtotime("+6 months"));
            $where['expired_date!='] = '0000-00-00';
            $where['product_stock >'] = 0;
            $where['drug_medicine.type'] = $type;
            $options = array(
                'joins' => array(
                    array(
                        'table' => 'purchase_orders',
                        'condition' => 'purchase_orders.purchase_id = purchase_order_details.purchase_order_id',
                        'jointype' => 'LEFT'
                    ),
                    array(
                        'table' => 'drug_manufacturer',
                        'condition' => 'drug_manufacturer.record_id = purchase_orders.supplier_id',
                        'jointype' => 'LEFT'
                    ),
                    array(
                        'table' => 'drug_medicine',
                        'condition' => 'drug_medicine.record_id = purchase_order_details.product_id',
                        'jointype' => 'LEFT'
                    ),
                    // array(
                    //     'table' => 'generic_names',
                    //     'condition' => 'generic_names.record_id = product_name.product_category_generic_name_id',
                    //     'jointype' => 'LEFT'
                    // ),
                ),
                // 'select' => 'purchase_orders.purchase_date,product_name.record_id as product_id,product_name.product_name,product_name.strength,suppliers.supplier_name,suppliers.record_id as supplier_id,product_name.product_category,generic_names.generic_name,expired_date, purchase_order_details.purchase_type',
                'select' => 'purchase_order_details.*, purchase_orders.purchase_date, purchase_orders.supplier_id, drug_medicine.product_stock, drug_manufacturer.manufacturer_name',
                'where' => $where,
                'order' => array(
                    'purchase_order_details.purchase_order_details_id' => 'asc',
                ),
            );


            $data['values'] = $this->Common_model->commonJoins("purchase_order_details", $options);
            // dd(  $data['values']);


            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;
            $data['type'] = $type;
            $data['product_id'] = $product_id;
            $data['supplier_id'] = $supplier_id;

            $this->load->view('admin/layouts/header');
            $this->load->view('admin/reports/expired_medicine_product', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login', $data);
        }
    }

    public function lab_product()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'All Stock Report';
            $data['page_title'] = 'All Stock Report';
            $data['info_header'] = 'All Stock Report';

            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $product_id = $this->input->get('product_id');
            $transaction_type = $this->input->get('transaction_type');
            $category_id = $this->input->get('category_id');

            $where = array();

            if (!isset($from_date) && !isset($to_date) && !isset($product_id) && !isset($transaction_type)) {
                // $where['in_date'] = date('Y-m-d');
            }

            if ($product_id) $where['product_id'] = $product_id;
            if ($category_id) $where['category_id'] = $category_id;

            if (!empty($from_date) && !empty($to_date)) {
                $where['in_date >= '] = $from_date;
                $where['in_date <= '] = $to_date;
            } elseif (!empty($from_date) && empty($to_date)) {
                $where['in_date'] = $from_date;
            } elseif (empty($from_date) && !empty($to_date)) {
                $where['in_date'] = $to_date;
            }

            
            // dd($where);
            $data['values'] = $this->Common_model->findAllGroupBySum('lab_product_in_details', $where, 'product_id', 'quantity');
            // echo "<pre>";
            // var_dump($data['values']);
            // exit;
            $data['from_date'] = (strlen($from_date) > 0) ? $from_date : '';
            $data['to_date'] = (strlen($to_date) > 0) ? $to_date : '';
            $data['product_id'] = $product_id;
            $data['transaction_type'] = $transaction_type;
            $data['category_id'] = $category_id;
            $data['redirect'] = base_url("reports/lab_product");
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/reports/lab_product', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function re_agent_stock()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Re-Agent Stock Report';
            $data['page_title'] = 'Re-Agent Stock Report';
            $data['info_header'] = 'Re-Agent Stock Report';

            $staff_id = $this->input->get('staff_id');
            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $product_id = $this->input->get('product_id');
            $transaction_type = $this->input->get('transaction_type');

            $where = array();

            if (!isset($staff_id) && !isset($from_date) && !isset($to_date) && !isset($product_id) && !isset($transaction_type)) {
                $where['in_date'] = date('Y-m-d');
            }

            if ($product_id) $where['product_id'] = $product_id;
            if ($staff_id) $where['staff_id'] = $staff_id;

            if (!empty($from_date) && !empty($to_date)) {
                $where['in_date >= '] = $from_date;
                $where['in_date <= '] = $to_date;
            } elseif (!empty($from_date) && empty($to_date)) {
                $where['in_date'] = $from_date;
            } elseif (empty($from_date) && !empty($to_date)) {
                $where['in_date'] = $to_date;
            }
            if($staff_id){
            $data['values'] = $this->Common_model->findAllGroupBySum('re_agent_in_details', $where, 'product_id', 'quantity');
            }else{
                $data['values'] ="";
            }
            // echo "<pre>";
            // var_dump($data['values']);
            // exit;
            $data['from_date'] = (strlen($from_date) > 0) ? $from_date : date("Y-m-d");
            $data['to_date'] = (strlen($to_date) > 0) ? $to_date : date("Y-m-d");
            $data['product_id'] = $product_id;
            $data['staff_id'] = $staff_id;
            $data['transaction_type'] = $transaction_type;
            $data['redirect'] = base_url("reports/lab_product");
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/reports/re_agent_stock', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function daily_income_report()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Daily Income Report';
            $data['page_title'] = 'Daily Income Report';
            $data['staff'] = $this->Common_model->findAll('staff', array(), 'record_id', 'asc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/reports/daily_income_report', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function show_daily_income_report()
    {
        $data['title'] = 'Daily Income Report';
        $userType = $this->session->userdata('ses_user_type');
        $ses_record_id = $this->session->userdata('ses_record_id');

        $created_by = $this->input->post('created_by');
        $current_date = $this->input->post('date_from');
        $data['current_date'] = $current_date;
        $previous_date =  date_sub(date_create($current_date), date_interval_create_from_date_string("1 days"));
        $previous_date = date_format($previous_date, "Y-m-d");

        /**B/F**/
        $whereBF = array();
        $incomeWhereBF = array();
        $whereBF['date'] = $previous_date;
        $incomeWhereBF['income_date'] = $previous_date;
        if (!empty($created_by)) {
            $whereBF['created_by'] = $created_by;
            $incomeWhereBF['created_by'] = $created_by;
        }
        $patient_idsBF = array();
        $service_patient_idsBF = $this->Common_model->columns('create_bill', $whereBF, 'patient_id');
        $income_patient_idsBF = $this->Common_model->columns('incomes', $incomeWhereBF, 'patient_id');
        $patient_idsBF = array_unique(array_merge($service_patient_idsBF, $income_patient_idsBF));
        if (count($patient_idsBF) == 0) {
            $patient_idsBF[] = -1;
        }
        $patientsBF = $this->Common_model->findAllWhereIn('patient', array(), $patient_idsBF, 'record_id', 'record_id', 'desc');

        $valuesBF = array();
        $sub_totalBF = 0;
        $grand_totalBF = 0;
        $total_dr_visitBF = 0;
        $total_ultrasonogramBF = 0;
        $total_ecgBF = 0;
        $total_xrayBF = 0;
        $total_pathologyBF = 0;
        $total_othersBF = 0;
        $total_admission_feeBF = 0;
        $total_admissionBF = 0;
        $total_operationBF = 0;
        $total_collectionBF = 0;
        $total_emergencysBF = 0;
        $total_doctor_serviceBF = 0;
        $total_donorBF = 0;
        $total_dressingBF = 0;
        $total_ambulanceBF = 0;


        foreach ($patientsBF as $key => $value) {
            $sub_totalBF = 0;
            $obj = new stdClass;
            $obj->patient_id = $value->record_id;
            $obj->patient_name = $value->name;
            $obj->patient_age = $value->age;
            $obj->patient_gender = $value->gender;
            $obj->patient_mobile = $value->mobile;

            /*  $drVisitWhere = array() ;
            $drVisitWhere['income_head_id'] = 3 ; // 3 = dr.visit income head 
            $drVisitWhere['patient_id'] = $value->record_id ;
            $drVisitWhere['income_date'] = $previous_date ;
            $drVisit = $this->Common_model->calCulateSum('income_details',$drVisitWhere,'income_amount');
            $obj->dr_visit = isset($drVisit)?$drVisit:0 ;
            $total_dr_visitBF += $obj->dr_visit ;
            $sub_totalBF += $obj->dr_visit ;
*/

            $drVisitWhere = array();
            $drVisitWhere['patient_id'] = $value->record_id;
            $drVisitWhere['date'] = $previous_date;
            $drVisit = $this->Common_model->calculateSumMultiple('appointments', $drVisitWhere, array('sub_total', 'paid', 'doctor_commission'));
            $dr_visit_sub_total = isset($drVisit) ? $drVisit->sub_total : 0;
            $dr_visit_paid = isset($drVisit) ? $drVisit->paid : 0;
            $dr_visit_doctor_commission = isset($drVisit) ? $drVisit->doctor_commission : 0;
            $obj->dr_visit = $dr_visit_paid - $dr_visit_doctor_commission;
            $total_dr_visitBF += $obj->dr_visit;
            $sub_totalBF += $obj->dr_visit;


            $salesTestWhere = array();
            $salesTestWhere['patient_id'] = $value->record_id;
            $salesTestWhere['date'] = $previous_date;



            $salesTest = $this->Common_model->findAll('sales_test', $salesTestWhere, 'record_id', 'asc');
            //var_dump($salesTest);die;
            $pathology_amount = 0;
            $xray_amount = 0;
            $ultra_amount = 0;
            $ecg_amount = 0;

            foreach ($salesTest as $key1 => $value1) {
                $invoice = $this->Common_model->findById('create_bill', array('record_id' => $value1->invoice_no));
                $paid_amount = isset($invoice) ? $invoice->paid : 0;
                $invoice_qty = $this->Common_model->countAll('sales_test', array('invoice_no' => $value1->invoice_no));
                $invoice_qty = isset($invoice_qty) ? $invoice_qty : 0;
                $paid_per_item = $paid_amount / $invoice_qty;
                if ($value1->test_category_id == 11) {
                    $ultra_amount += $paid_per_item;
                } elseif ($value1->test_category_id == 12) {
                    $xray_amount += $paid_per_item;
                } elseif ($value1->test_category_id == 13) {
                    $ecg_amount += $paid_per_item;
                } else {
                    $pathology_amount += $paid_per_item;
                }
            }

            $obj->ultrasonogram = round($ultra_amount, 2);
            $total_ultrasonogramBF += $obj->ultrasonogram;
            $sub_totalBF += $obj->ultrasonogram;

            $obj->ecg = round($ecg_amount, 2);
            $total_ecgBF += $obj->ecg;
            $sub_totalBF += $obj->ecg;

            $obj->xray = round($xray_amount, 2);
            $total_xrayBF += $obj->xray;
            $sub_totalBF += $obj->xray;

            $obj->pathology = round($pathology_amount, 2);
            $total_pathologyBF += $obj->pathology;
            $sub_totalBF += $obj->pathology;

            $othersWhere = array();
            $othersWhere['income_head_id != '] = 3; // 3 = dr.visit income head 
            $othersWhere['patient_id'] = $value->record_id;
            $othersWhere['income_date'] = $previous_date;
            $others = $this->Common_model->calCulateSum('income_details', $othersWhere, 'income_amount');
            $obj->others = isset($others) ? $others : 0;
            $total_othersBF += $obj->others;
            $sub_totalBF += $obj->others;

            $admissionWhere = array();
            $admissionWhere['patient_id'] = $value->record_id;
            $admissionWhere['admission_date'] = $previous_date;
            $admission = $this->Common_model->calculateSumMultiple('admission_fee_invoice', $admissionWhere, array('admission_fee', 'advance_amount'));
            $obj->admission = isset($admission) ? isset($admission->advance_amount) ? $admission->advance_amount : 0 : 0;
            $obj->admission_fee = isset($admission) ? isset($admission->admission_fee) ? $admission->admission_fee : 0 : 0;
            $total_admission_feeBF += $obj->admission_fee;
            $total_admissionBF += $obj->admission;
            $sub_totalBF += $obj->admission_fee;
            $sub_totalBF += $obj->admission;

            $operationWhere = array();
            $operationWhere['patient_id'] = $value->record_id;
            $operationWhere['operation_date'] = $previous_date;
            $operation = $this->Common_model->calculateSum('operation_details', $operationWhere, 'paid_amount');
            $obj->operation = isset($operation) ? $operation : 0;
            $total_operationBF += $obj->operation;
            $sub_totalBF += $obj->operation;

            $collectionWhere = array();
            $collectionWhere['patient_id'] = $value->record_id;
            $collectionWhere['mr_date'] = $previous_date;
            $collection = $this->Common_model->calculateSum('due_collections', $collectionWhere, 'mr_amount');
            $obj->collection = isset($collection) ? $collection : 0;
            $total_collectionBF += $obj->collection;
            $sub_totalBF += $obj->collection;


            $emergencysWhere = array();
            $emergencysWhere['patient_id'] = $value->record_id;
            $emergencysWhere['type'] = 'Emergency';
            $emergencysWhere['date'] = $previous_date;
            $emergencys = $this->Common_model->calculateSum('create_bill', $emergencysWhere, 'paid');
            $obj->emergencys = isset($emergencys) ? $emergencys : 0;
            $total_emergencysBF += $obj->emergencys;
            $sub_totalBF += $obj->emergencys;

            $doctorServiceWhere = array();
            $doctorServiceWhere['patient_id'] = $value->record_id;
            $doctorServiceWhere['type'] = 'Doctor Service';
            $doctorServiceWhere['date'] = $previous_date;
            $doctor_service = $this->Common_model->calculateSum('create_bill', $doctorServiceWhere, 'paid');
            $obj->doctor_service = isset($doctor_service) ? $doctor_service : 0;
            $total_doctor_serviceBF += $obj->doctor_service;
            $sub_totalBF += $obj->doctor_service;

            $donorWhere = array();
            $donorWhere['patient_id'] = $value->record_id;
            $donorWhere['type'] = 'Donor';
            $donorWhere['date'] = $previous_date;
            $donor = $this->Common_model->calculateSum('create_bill', $donorWhere, 'paid');
            $obj->donor = isset($donor) ? $donor : 0;
            $total_donorBF += $obj->donor;
            $sub_totalBF += $obj->donor;

            $dressingWhere = array();
            $dressingWhere['patient_id'] = $value->record_id;
            $dressingWhere['type'] = 'Dressing';
            $dressingWhere['date'] = $previous_date;
            $dressing = $this->Common_model->calculateSum('create_bill', $dressingWhere, 'paid');
            $obj->dressing = isset($dressing) ? $dressing : 0;
            $total_dressingBF += $obj->dressing;
            $sub_totalBF += $obj->dressing;

            $ambulanceWhere = array();
            $ambulanceWhere['patient_id'] = $value->record_id;
            $ambulanceWhere['type'] = 'Ambulance';
            $ambulanceWhere['date'] = $previous_date;
            $ambulance = $this->Common_model->calculateSumMultiple('create_bill', $ambulanceWhere, array('paid', 'fuel_cost', 'road_cost', 'service_maintanance_cost'));
            $ambulance_paid = isset($ambulance) ? $ambulance->paid : 0;
            $ambulance_fuel_cost = isset($ambulance) ? $ambulance->fuel_cost : 0;
            $ambulance_road_cost = isset($ambulance) ? $ambulance->road_cost : 0;
            $ambulance_service_maintanance_cost = isset($ambulance) ? $ambulance->service_maintanance_cost : 0;
            $obj->ambulance = $ambulance_paid - ($ambulance_fuel_cost + $ambulance_road_cost + $ambulance_service_maintanance_cost);
            $total_ambulanceBF += $obj->ambulance;
            $sub_totalBF += $obj->ambulance;

            $obj->sub_total = $sub_totalBF;
            $grand_totalBF += $sub_totalBF;
            $valuesBF[] = $obj;
        }

        $data['grand_totalBF'] = $grand_totalBF;
        $data['total_dr_visitBF'] = $total_dr_visitBF;
        $data['total_ultrasonogramBF'] = $total_ultrasonogramBF;
        $data['total_ecgBF'] = $total_ecgBF;
        $data['total_xrayBF'] = $total_xrayBF;
        $data['total_pathologyBF'] = $total_pathologyBF;
        $data['total_othersBF'] = $total_othersBF;
        $data['total_admission_feeBF'] = $total_admission_feeBF;
        $data['total_admissionBF'] = $total_admissionBF;
        $data['total_operationBF'] = $total_operationBF;
        $data['total_emergencysBF'] = $total_emergencysBF;
        $data['total_doctor_serviceBF'] = $total_doctor_serviceBF;
        $data['total_donorBF'] = $total_donorBF;
        $data['total_dressingBF'] = $total_dressingBF;
        $data['total_ambulanceBF'] = $total_ambulanceBF;
        $data['total_collectionBF'] = $total_collectionBF;

        /**B/F**/

        $where = array();
        if (!admin()) {
            $where['show_hide'] = "Show";
        }
        $incomeWhere = array();
        if (!admin()) {
            $incomeWhere['show_hide'] = "Show";
        }
        $where['date'] = $current_date;
        $incomeWhere['income_date'] = $current_date;
        if (!empty($created_by)) {
            $where['created_by'] = $created_by;
            $incomeWhere['created_by'] = $created_by;
        }
        $patient_ids = array();
        $service_patient_ids = $this->Common_model->columns('create_bill', $where, 'patient_id');
        $income_patient_ids = $this->Common_model->columns('incomes', $incomeWhere, 'patient_id');
        $patient_ids = array_unique(array_merge($service_patient_ids, $income_patient_ids));
        if (count($patient_ids) == 0) {
            $patient_ids[] = -1;
        }
        $patients = $this->Common_model->findAllWhereIn('patient', array(), $patient_ids, 'record_id', 'record_id', 'desc');

        $values = array();
        $sub_total = 0;
        $grand_total = 0;
        $total_dr_visit = 0;
        $total_ultrasonogram = 0;
        $total_ecg = 0;
        $total_xray = 0;
        $total_echo = 0;
        $total_pathology = 0;
        $total_others = 0;
        $total_admission_fee = 0;
        $total_admission = 0;
        $total_operation = 0;
        $total_collection = 0;
        $total_emergencys = 0;
        $total_doctor_service = 0;
        $total_donor = 0;
        $total_dressing = 0;
        $total_ambulance = 0;


        foreach ($patients as $key => $value) {
            $sub_total = 0;
            $obj = new stdClass;
            $obj->patient_id = $value->record_id;
            $obj->patient_name = $value->name;
            $obj->patient_age = $value->age;
            $obj->patient_gender = $value->gender;
            $obj->patient_mobile = $value->mobile;

            /* $drVisitWhere = array() ;
            $drVisitWhere['income_head_id'] = 3 ; 
            $drVisitWhere['patient_id'] = $value->record_id ;
            $drVisitWhere['income_date'] = $current_date ;
            $drVisit = $this->Common_model->calCulateSum('income_details',$drVisitWhere,'income_amount');
            $obj->dr_visit = isset($drVisit)?$drVisit:0 ;
            $total_dr_visit += $obj->dr_visit ;
            $sub_total += $obj->dr_visit ;*/

            $drVisitWhere = array();
            $drVisitWhere['patient_id'] = $value->record_id;
            $drVisitWhere['date'] = $current_date;
            $drVisit = $this->Common_model->calculateSumMultiple('appointments', $drVisitWhere, array('sub_total', 'paid', 'doctor_commission'));
            $dr_visit_sub_total = isset($drVisit) ? $drVisit->sub_total : 0;
            $dr_visit_paid = isset($drVisit) ? $drVisit->paid : 0;
            $dr_visit_doctor_commission = isset($drVisit) ? $drVisit->doctor_commission : 0;
            $obj->dr_visit = $dr_visit_paid ;// - $dr_visit_doctor_commission;
            $total_dr_visit += $obj->dr_visit;
            $sub_total += $obj->dr_visit;


            $salesTestWhere = array();
            $salesTestWhere['patient_id'] = $value->record_id;
            $salesTestWhere['date'] = $current_date;



            $salesTest = $this->Common_model->findAll('sales_test', $salesTestWhere, 'record_id', 'asc');
            // var_dump($salesTestWhere);die;
            $pathology_amount = 0;
            $xray_amount = 0;
            $ultra_amount = 0;
            $ecg_amount = 0;
            $echo_amount = 0;

            foreach ($salesTest as $key1 => $value1) {
                $invoice = $this->Common_model->findById('create_bill', array('record_id' => $value1->invoice_no));
                $accessories_amount = isset($invoice) ? $invoice->accessories_amount : 0;
                $total_amount = isset($invoice) ? $invoice->amount ? $invoice->amount : 0 : 0;
                $total_amount -= $accessories_amount;
                $sub_total_amount = isset($invoice) ? $invoice->sub_total ? $invoice->sub_total : 0 : 0;
                $sub_total_amount -= $accessories_amount;
                $paid_amount = isset($invoice) ? $invoice->paid : 0;
                $discount_amount = isset($invoice) ? $invoice->discount : 0;
                $vat_amount = isset($invoice) ? $invoice->vat : 0;
                $invoice_qty = $this->Common_model->countAll('sales_test', array('invoice_no' => $value1->invoice_no));

                $per_test_vat_amount = $vat_amount / $invoice_qty;
                $test_sales_price = $value1->test_price + $per_test_vat_amount;
                $percentage_discount = ($test_sales_price * $discount_amount) / $total_amount;
                $with_discount_test_sales_price = $test_sales_price - $percentage_discount;
                if ($sub_total_amount) {
                    $with_discount_paid_amount = ($with_discount_test_sales_price * $paid_amount) / $sub_total_amount;
                } else {
                    $with_discount_paid_amount = 0;
                }
                // var_dump($with_discount_paid_amount);die;

                // $invoice_qty = isset($invoice_qty) ? $invoice_qty : 0;
                //  $paid_per_item = $paid_amount / $invoice_qty;
                if ($value1->test_category_id == 11) {
                    $ultra_amount += $with_discount_paid_amount;
                } elseif ($value1->test_category_id == 12) {
                    $xray_amount += $with_discount_paid_amount;
                } elseif ($value1->test_category_id == 13) {
                    $ecg_amount += $with_discount_paid_amount;
                } elseif ($value1->test_category_id == 19) {
                    $echo_amount += $with_discount_paid_amount;
                } else {
                    $pathology_amount += $with_discount_paid_amount;
                }
            }

            $obj->ultrasonogram = round($ultra_amount, 2);
            $total_ultrasonogram += $obj->ultrasonogram;
            $sub_total += $obj->ultrasonogram;

            $obj->ecg = round($ecg_amount, 2);
            $total_ecg += $obj->ecg;
            $sub_total += $obj->ecg;

            $obj->xray = round($xray_amount, 2);
            $total_xray += $obj->xray;
            $sub_total += $obj->xray;

            $obj->echo = round($echo_amount, 2);
            $total_echo += $obj->echo;
            $sub_total += $obj->echo;

            $obj->pathology = round($pathology_amount, 2);
            $total_pathology += $obj->pathology;
            $sub_total += $obj->pathology;

            $othersWhere = array();
            $othersWhere['income_head_id != '] = 3; // 3 = dr.visit income head 
            $othersWhere['patient_id'] = $value->record_id;
            $othersWhere['income_date'] = $current_date;
            $others = $this->Common_model->calCulateSum('income_details', $othersWhere, 'income_amount');
            $obj->others = isset($others) ? $others : 0;
            $total_others += $obj->others;
            $sub_total += $obj->others;

            $admissionWhere = array();
            $admissionWhere['patient_id'] = $value->record_id;
            $admissionWhere['admission_date'] = $current_date;
            $admission = $this->Common_model->calculateSumMultiple('admission_fee_invoice', $admissionWhere, array('admission_fee', 'advance_amount'));
            $obj->admission = isset($admission) ? isset($admission->advance_amount) ? $admission->advance_amount : 0 : 0;
            $obj->admission_fee = isset($admission) ? isset($admission->admission_fee) ? $admission->admission_fee : 0 : 0;
            $total_admission_fee += $obj->admission_fee;

            $sub_total += $obj->admission_fee;
            //$sub_total += $obj->admission ;

            $admissionAdvanceWhere = array();
            $admissionAdvanceWhere['patient_id'] = $value->record_id;
            $admissionAdvanceWhere['advance_date'] = $current_date;
            $advance_amount = $this->Common_model->calculateSum('admission_advance_invoice', $admissionAdvanceWhere, 'advance_amount');
            $advance_amount = isset($advance_amount) ? $advance_amount : 0;
            $obj->admission += $advance_amount;
            $sub_total += $obj->admission;
            $total_admission += $obj->admission;

            $operationWhere = array();
            $operationWhere['patient_id'] = $value->record_id;
            $operationWhere['operation_date'] = $current_date;
            $operation = $this->Common_model->calculateSum('operation_details', $operationWhere, 'paid_amount');
            $obj->operation = isset($operation) ? $operation : 0;
            $total_operation += $obj->operation;
            $sub_total += $obj->operation;

            $collectionWhere = array();
            $collectionWhere['patient_id'] = $value->record_id;
            $collectionWhere['mr_date'] = $current_date;
            $collection = $this->Common_model->calculateSum('due_collections', $collectionWhere, 'mr_amount');
            $obj->collection = isset($collection) ? $collection : 0;
            $total_collection += $obj->collection;
            $sub_total += $obj->collection;


            $emergencysWhere = array();
            $emergencysWhere['patient_id'] = $value->record_id;
            $emergencysWhere['type'] = 'Emergency';
            $emergencysWhere['date'] = $current_date;
            $emergencys = $this->Common_model->calculateSumMultiple('create_bill', $emergencysWhere, array('paid', 'doctor_commission', 'others_cost'));
            $emergencys_paid = isset($emergencys) ? $emergencys->paid : 0;
            $doctor_commission = isset($emergencys) ? $emergencys->doctor_commission : 0;
            $others_cost = isset($emergencys) ? $emergencys->others_cost : 0;
            $emergencys_income =  $emergencys_paid; // - ($doctor_commission + $others_cost ) ;
            $obj->emergencys = $emergencys_income;
            $total_emergencys += $obj->emergencys;
            $sub_total += $obj->emergencys;

            $doctorServiceWhere = array();
            $doctorServiceWhere['patient_id'] = $value->record_id;
            $doctorServiceWhere['type'] = 'Doctor Service';
            $doctorServiceWhere['date'] = $current_date;
            $doctor_service = $this->Common_model->calculateSum('create_bill', $doctorServiceWhere, 'paid');
            $obj->doctor_service =  isset($doctor_service) ? $doctor_service : 0;
            $total_doctor_service += $obj->doctor_service;
            $sub_total += $obj->doctor_service;

            $donorWhere = array();
            $donorWhere['patient_id'] = $value->record_id;
            $donorWhere['type'] = 'Donor';
            $donorWhere['date'] = $current_date;
            $donor = $this->Common_model->calculateSum('create_bill', $donorWhere, 'paid');
            $obj->donor = isset($donor) ? $donor : 0;
            $total_donor += $obj->donor;
            $sub_total += $obj->donor;

            $dressingWhere = array();
            $dressingWhere['patient_id'] = $value->record_id;
            $dressingWhere['type'] = 'Dressing';
            $dressingWhere['date'] = $current_date;
            $dressing = $this->Common_model->calculateSumMultiple('create_bill', $dressingWhere, array('paid', 'doctor_commission'));
            $dressing_paid = isset($dressing) ? $dressing->paid : 0;
            $dressing_doctor_commission = isset($dressing) ? $dressing->doctor_commission : 0;
            $obj->dressing = $dressing_paid; // - $dressing_doctor_commission;
            $total_dressing += $obj->dressing;
            $sub_total += $obj->dressing;

            $ambulanceWhere = array();
            $ambulanceWhere['patient_id'] = $value->record_id;
            $ambulanceWhere['type'] = 'Ambulance';
            $ambulanceWhere['date'] = $current_date;
            $ambulance = $this->Common_model->calculateSumMultiple('create_bill', $ambulanceWhere, array('paid', 'fuel_cost', 'road_cost', 'service_maintanance_cost'));
            $ambulance_paid = isset($ambulance) ? $ambulance->paid : 0;
            $ambulance_fuel_cost = isset($ambulance) ? $ambulance->fuel_cost : 0;
            $ambulance_road_cost = isset($ambulance) ? $ambulance->road_cost : 0;
            $ambulance_service_maintanance_cost = isset($ambulance) ? $ambulance->service_maintanance_cost : 0;
            $obj->ambulance = $ambulance_paid; // - ($ambulance_fuel_cost + $ambulance_road_cost + $ambulance_service_maintanance_cost);
            $total_ambulance += $obj->ambulance;
            $sub_total += $obj->ambulance;


            $obj->sub_total = $sub_total;
            $grand_total += $sub_total;
            $values[] = $obj;
        }

        $data['grand_total'] = $grand_total;
        $data['total_dr_visit'] = $total_dr_visit;
        $data['total_ultrasonogram'] = $total_ultrasonogram;
        $data['total_ecg'] = $total_ecg;
        $data['total_xray'] = $total_xray;
        $data['total_echo'] = $total_echo;
        $data['total_pathology'] = $total_pathology;
        $data['total_others'] = $total_others;
        $data['total_admission_fee'] = $total_admission_fee;
        $data['total_admission'] = $total_admission;
        $data['total_operation'] = $total_operation;
        $data['total_emergencys'] = $total_emergencys;
        $data['total_doctor_service'] = $total_doctor_service;
        $data['total_donor'] = $total_donor;
        $data['total_ambulance'] = $total_ambulance;
        $data['total_dressing'] = $total_dressing;
        $data['total_collection'] = $total_collection;
        $data['values'] = $values;
        $data['redirect'] = base_url('reports/daily_income_report');
        $this->load->view('admin/reports/show_daily_income_report', $data);
    }
    public function indoor_balance_sheet()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'IPD Collection Report';
            $data['page_title'] =  $data['title'];
            $data['info_header'] = '';

            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $created_by = $this->input->get('created_by');


            $operationWhere = array();
            if (!admin()) {
                $operationWhere['show_hide'] = "Show";
            }
            $collectionWhere = array();
            if (!admin()) {
                $collectionWhere['show_hide'] = "Show";
            }
            $expenseWhere = array();
            if (!admin()) {
                $expenseWhere['show_hide'] = "Show";
            }
            $incomeWhere = array();
            if (!admin()) {
                $incomeWhere['show_hide'] = "Show";
            }

            $where_in = array('Admission', 'AdmissionAdvance', 'Operation');
            $where_in_column = 'type';
            $collection_where_in = array('Admission', 'Operation');
            $collection_where_in_column = 'invoice_type';

            $expenseWhere['expense_type'] = 'Hospital';
            $incomeWhere['income_type'] = 'Hospital';
            $today = date('Y-m-d');

            if (!isset($created_by) && !isset($from_date) && !isset($to_date)) {
                $operationWhere['date'] = $today;
                $collectionWhere['mr_date'] = $today;
                $expenseWhere['expense_date'] = $today;
                $incomeWhere['income_date'] = $today;
            }
            if (!empty($created_by)) {
                $operationWhere['created_by'] = $created_by;
                $collectionWhere['created_by'] = $created_by;
                $expenseWhere['created_by'] = $created_by;
                $incomeWhere['created_by'] = $created_by;
            }
            if (!empty($from_date) && !empty($to_date)) {
                $operationWhere['date >= '] = $from_date;
                $operationWhere['date <= '] = $to_date;
                $collectionWhere['mr_date >= '] = $from_date;
                $collectionWhere['mr_date <= '] = $to_date;
                $expenseWhere['expense_date >= '] = $from_date;
                $expenseWhere['expense_date <= '] = $to_date;
                $incomeWhere['income_date >= '] = $from_date;
                $incomeWhere['income_date <= '] = $to_date;
            } else if (!empty($from_date) && empty($to_date)) {
                $operationWhere['date'] = $from_date;
                $collectionWhere['mr_date'] = $from_date;
                $expenseWhere['expense_date'] = $from_date;
                $incomeWhere['income_date'] = $from_date;
            } else if (empty($from_date) && !empty($to_date)) {
                $operationWhere['date'] = $to_date;
                $collectionWhere['mr_date'] = $to_date;
                $expenseWhere['expense_date'] = $to_date;
                $incomeWhere['income_date'] = $to_date;
            }
            $data['admissionAndOperation'] = $this->Common_model->findAllWhereIn('create_bill', $operationWhere, $where_in, $where_in_column, 'record_id', 'desc');
            $data['indoor_collections'] = $this->Common_model->findAllWhereIn('due_collection_details', $collectionWhere, $collection_where_in, $collection_where_in_column, 'mr_details_id', 'desc');
            $data['indoor_expense'] = $this->Common_model->findAll('expenses', $expenseWhere, 'expense_id', 'desc');
            $data['indoor_income'] = $this->Common_model->findAll('incomes', $incomeWhere, 'income_id', 'desc');

            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;
            $data['created_by'] = $created_by;
            $data['redirect'] = base_url('reports/indoor_balance_sheet');
            $data['signatureType'] = 'Staff';
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/reports/indoor_balance_sheet', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    
    public function outdoor_balance_sheet()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'OPD Collection Report';
            $data['page_title'] =  $data['title'];
            $data['info_header'] = '';

            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $created_by = $this->input->get('created_by');

            $appointmentWhere = array();
            if (!admin()) {
                $appointmentWhere['show_hide'] = "Show";
            }
            $collectionWhere = array();
            if (!admin()) {
                $collectionWhere['show_hide'] = "Show";
            }
            $expenseWhere = array();
            if (!admin()) {
                $expenseWhere['show_hide'] = "Show";
            }
            $incomeWhere = array();
            if (!admin()) {
                $incomeWhere['show_hide'] = "Show";
            }
            $where_in = array('Appointment', 'Test Invoice','Emergency','Donor','Dressing');
            $where_in_column = 'type';
            $collection_where_in = array('Appointment', 'Test Invoice','Emergency','Donor','Dressing');
            $collection_where_in_column = 'invoice_type';
            $expenseWhere['expense_type'] = 'Diagnostic';
            $incomeWhere['income_type'] = 'Diagnostic';

            $sonologistExpenseWhere = array();


            $today = date('Y-m-d');
            if (!isset($created_by) && !isset($from_date) && !isset($to_date)) {
                $from_date = $to_date = $today;
                $appointmentWhere['date'] = $today;
                $collectionWhere['mr_date'] = $today;
                $expenseWhere['expense_date'] = $today;
                $incomeWhere['income_date'] = $today;
                $sonologistExpenseWhere['date'] = $today;
            }
            if (!empty($created_by)) {
                $appointmentWhere['created_by'] = $created_by;
                $collectionWhere['created_by'] = $created_by;
                $expenseWhere['created_by'] = $created_by;
                $incomeWhere['created_by'] = $created_by;
                $sonologistExpenseWhere['created_by'] = $created_by;
            }
            if (!empty($from_date) && !empty($to_date)) {
                $appointmentWhere['date >= '] = $from_date;
                $appointmentWhere['date <= '] = $to_date;
                $collectionWhere['mr_date >= '] = $from_date;
                $collectionWhere['mr_date <= '] = $to_date;
                $expenseWhere['expense_date >= '] = $from_date;
                $expenseWhere['expense_date <= '] = $to_date;
                $incomeWhere['income_date >= '] = $from_date;
                $incomeWhere['income_date <= '] = $to_date;
                $sonologistExpenseWhere['date >= '] = $from_date;
                $sonologistExpenseWhere['date <= '] = $to_date;
            } else if (!empty($from_date) && empty($to_date)) {
                $appointmentWhere['date'] = $from_date;
                $collectionWhere['mr_date'] = $from_date;
                $expenseWhere['expense_date'] = $from_date;
                $incomeWhere['income_date'] = $from_date;
                $sonologistExpenseWhere['date'] = $from_date;
            } else if (empty($from_date) && !empty($to_date)) {
                $appointmentWhere['date'] = $to_date;
                $collectionWhere['mr_date'] = $to_date;
                $expenseWhere['expense_date'] = $to_date;
                $incomeWhere['income_date'] = $to_date;
                $sonologistExpenseWhere['date'] = $to_date;
            }
            // $appointmentWhere['test_invoice_payment_status'] = 'Paid';
            $data['appointmentsAndTest_invoices'] = $this->Common_model->findAllWhereIn('create_bill', $appointmentWhere, $where_in, $where_in_column, 'record_id', 'desc');
            // dd($data['appointmentsAndTest_invoices']);
            $data['outdoor_collections'] = $this->Common_model->findAllWhereIn('due_collection_details', $collectionWhere, $collection_where_in, $collection_where_in_column, 'mr_details_id', 'desc');
            $data['outdoor_expense'] = $this->Common_model->findAll('expenses', $expenseWhere, 'expense_id', 'desc');
            $data['outdoor_income'] = $this->Common_model->findAll('incomes', $incomeWhere, 'income_id', 'desc');
            $data['sonologist_expenses'] = $this->Common_model->findAll('sonologist', $sonologistExpenseWhere, 'record_id', 'asc');

            //  var_dump($data['outdoor_expense']);die;

            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;
            $data['created_by'] = $created_by;
            $data['redirect'] = base_url('reports/outdoor_balance_sheet');
            $data['signatureType'] = 'Staff';
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/reports/outdoor_balance_sheet', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }


    private function stockReportSum($data){
        $totals = array_reduce($data, function ($carry, $product) {
            $opening_balance = $product->opening_qty;
            
            // Closing Balance calculation
             $closing_balance = ($opening_balance + $product->purchase_qty +$product->sales_return_qty) - ($product->purchase_return_qty+$product->sales_qty);
        
            // Handle negative stock
            $opening_balance   =  $opening_balance;
            $purchaseQty       =  $product->purchase_qty;
            $saleseQty         =  $product->sales_qty;
            $returnQty         =  $product->purchase_return_qty;
            $salesReturnQty    =  $product->sales_return_qty;
            $closing_balance   = $closing_balance;
            $stockValue        = $product->unit_price * $closing_balance;
        
            // Accumulate totals
            $carry['totalOpeningBalance']  += $opening_balance;
            $carry['totalPurchaseQty']     += $purchaseQty;
            $carry['totalSalesQty']        += $saleseQty;
            $carry['totalPurchasePeturn']  += $returnQty;
            $carry['totalSalesReturn']     += $salesReturnQty;
            $carry['totalClosingBalance']  += $closing_balance;
            $carry['totalStockValue']      += $stockValue;
        
            return $carry;
        }, [
            'totalOpeningBalance' => 0,
            'totalPurchaseQty'    => 0,
            'totalSalesQty'       => 0,
            'totalPurchasePeturn' => 0,
            'totalSalesReturn'    => 0,
            'totalClosingBalance' => 0,
            'totalStockValue'     => 0,
        ]);

        return (object)$totals;
        
    }

    public function stock_report($page = 1)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title']          = 'All Product Stock Report';
            $data['page_title']     = $data['title'];
            $data['info_header']    = $data['title'];

            $monthYear      = $this->input->get('month');
            $shelf          = $this->input->get('shelf_location');
            $product_id     = $this->input->get('product_id');
            $supplier_id    = $this->input->get('supplier_id');
            $type           = $this->input->get('type') === 'optic' ? 'optic' : 'medicine';

            $page = (isset($_GET['page']) && $_GET['page'] > 0) ? $_GET['page'] : 1;
        

            if (!isset($monthYear)) {
                $monthYear = date('Y-m');
            }

            $fromDate   = date('Y-m-01', strtotime($monthYear));
            $toDate     = date('Y-m-t', strtotime($monthYear));

            $data['from_date']      = $fromDate;
            $data['to_date']        = $toDate;
            $data['product_id']     = $product_id;
            $data['shelf_location'] = $shelf;
            $data['supplier_id']    = $supplier_id;
            $data['page']           = $page;
            $data['monthYear']      = $monthYear;
            $data['type']           = $type;

            $limit = 100;
            $offset = ($page - 1) * $limit;

            $productsStocks = [];
            if ($fromDate ){
                $productsStocks= $this->Common_model->productStockBalanceSheet($fromDate, $product_id, $supplier_id, $shelf, $type);
        
            }
            // dd($productsStocks);
            $paginateProduct = array_slice( $productsStocks, $offset, $limit);
           
            $totalStockSum = $this->stockReportSum($productsStocks); 
            
        

            $data['productsStocks']  = $paginateProduct;
            $data['totalStockSum']     = $totalStockSum;
           
            $data['onset']          = $offset;
            $config['base_url']     = base_url('reports/stock_report');
            $config['total_rows']   = count($productsStocks);
            $config['uri_segment']  = 3;
            $config['per_page']     = 100;
            $config['num_links']    = 10;
            $config['first_link']   = FALSE;
            $config['last_link']    = FALSE;
            $config['prev_link']    = 'Prev';
            $config['next_link']    = 'Next';
            $config['full_tag_open'] = '<ul class="pagination">';
            $config['full_tag_close'] = '</ul>';
            $config['prev_link'] = '&laquo;';
            $config['prev_tag_open'] = '<li>';
            $config['prev_tag_close'] = '</li>';
            $config['next_tag_open'] = '<li>';
            $config['next_tag_close'] = '</li>';
            $config['cur_tag_open'] = '<li class="active"><a href="#">';
            $config['cur_tag_close'] = '</a></li>';
            $config['num_tag_open'] = '<li>';
            $config['num_tag_close'] = '</li>';
            $this->pagination->initialize($config);
            $data['report_title'] = 'All Product Stock Report of '.date('F Y', strtotime($monthYear));
            $data['pagination']['pages'] = ceil(count($productsStocks) / $limit);
            $data['pagination']['current_page'] = $page;

            $start =  (($config['per_page']*$page)+1)-$config['per_page'];
            $end = $start+$config['per_page']-1;
            $end = $end>$config['total_rows']?$config['total_rows']:$end;
            $data['paginationMessage'] = "Showing $start to $end of " . $config['total_rows'] . " entries";
            
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/reports/stock_report', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login', $data);
        }
    }

    public function stock_shortage($onset = 0)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Shortage List';
            $data['page_title'] = 'Shortage List';
            $data['info_header'] = 'Shortage List';
            $record_id = $this->input->post("record_id");
            $where = array();
            $where['opening_qty > '] = 0;
            if ($record_id) $where['record_id'] = $record_id;
            $opening_product_ids = $this->Common_model->columns('product_name', $where, "record_id");
            $where = array();
            if ($record_id) $where['product_id'] = $record_id;
            $purchase_product_ids = $this->Common_model->columns('purchase_order_details', $where, "product_id");
            $product_ids = array_merge($opening_product_ids, $purchase_product_ids);
            if (!count($product_ids)) {
                $product_ids = array(-1);
            }
            $where_in = $product_ids;
            $where_in_column = 'record_id';
            $where = array();
            if ($record_id) $where['record_id'] = $record_id;
            /* $data['onset']          = $onset;
            $config['base_url']     = base_url('reports/stock_shortage');
            $config['total_rows']   = $this->Common_model->countAll('product_name', $where, $where_in, $where_in_column);
            $config['uri_segment']  = 3;
            $config['per_page']     = 100;
            $config['num_links']    = 50;
            $config['first_link']   = TRUE;
            $config['last_link']    = TRUE;
            $config['prev_link']    = 'Prev';
            $config['next_link']    = 'Next';
            //$config['use_page_numbers'] = TRUE;
            $config['full_tag_open'] = '<ul class="pagination">';
            $config['full_tag_close'] = '</ul>';
            //$config['prev_link'] = '&laquo;';
            $config['prev_tag_open'] = '<li>';
            $config['prev_tag_close'] = '</li>';
            $config['next_tag_open'] = '<li>';
            $config['next_tag_close'] = '</li>';
            $config['cur_tag_open'] = '<li class="active"><a href="#">';
            $config['cur_tag_close'] = '</a></li>';
            $config['num_tag_open'] = '<li>';
            $config['num_tag_close'] = '</li>';
            $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
            $products = $this->Common_model->findAllForPagination('product_name', $where, 'record_id', 'desc', $page, $config["per_page"], $where_in, $where_in_column);
            $this->pagination->initialize($config);
            $data["links"] = $this->pagination->create_links();*/
            $products = $this->Common_model->findAllWhereIn('product_name', $where, $where_in, $where_in_column, 'record_id', 'desc');
            $values = array();
            $balance = 0;
            $shortage = 0;
            $product_ids = array();
            foreach ($products as $key => $value) {
                $reorder_level = $value->reorder_level;
                $balance = $this->Common_model->item_balance($value->record_id);
                if ($balance <= $reorder_level) {
                    ++$shortage;
                    $value->balance = $balance;
                    $values[] = $value;
                }
            }
            $data['values'] = $values;
            $data['onset'] = $onset;
            $data['record_id'] = $record_id;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/reports/stock_shortage', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function lab_stock_shortage($onset = 0)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Shortage List';
            $data['page_title'] = 'Shortage List';
            $data['info_header'] = 'Shortage List';
            $record_id = $this->input->post("record_id");
            $where = array();
            $where['opening_qty > '] = 0;
            if ($record_id) $where['record_id'] = $record_id;
            $opening_product_ids = $this->Common_model->columns('product_name', $where, "record_id");
            $where = array();
            if ($record_id) $where['product_id'] = $record_id;
            $purchase_product_ids = $this->Common_model->columns('lab_product_in_details', $where, "product_id");
            $product_ids = array_merge($opening_product_ids, $purchase_product_ids);
            if (!count($product_ids)) {
                $product_ids = array(-1);
            }
            $where_in = $product_ids;
            $where_in_column = 'record_id';
            $where = array();
            if ($record_id) $where['record_id'] = $record_id;
            /* $data['onset']          = $onset;
            $config['base_url']     = base_url('reports/stock_shortage');
            $config['total_rows']   = $this->Common_model->countAll('product_name', $where, $where_in, $where_in_column);
            $config['uri_segment']  = 3;
            $config['per_page']     = 100;
            $config['num_links']    = 50;
            $config['first_link']   = TRUE;
            $config['last_link']    = TRUE;
            $config['prev_link']    = 'Prev';
            $config['next_link']    = 'Next';
            //$config['use_page_numbers'] = TRUE;
            $config['full_tag_open'] = '<ul class="pagination">';
            $config['full_tag_close'] = '</ul>';
            //$config['prev_link'] = '&laquo;';
            $config['prev_tag_open'] = '<li>';
            $config['prev_tag_close'] = '</li>';
            $config['next_tag_open'] = '<li>';
            $config['next_tag_close'] = '</li>';
            $config['cur_tag_open'] = '<li class="active"><a href="#">';
            $config['cur_tag_close'] = '</a></li>';
            $config['num_tag_open'] = '<li>';
            $config['num_tag_close'] = '</li>';
            $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
            $products = $this->Common_model->findAllForPagination('product_name', $where, 'record_id', 'desc', $page, $config["per_page"], $where_in, $where_in_column);
            $this->pagination->initialize($config);
            $data["links"] = $this->pagination->create_links();*/
            $products = $this->Common_model->findAllWhereIn('product_name', $where, $where_in, $where_in_column, 'record_id', 'desc');
            $values = array();
            $balance = 0;
            $shortage = 0;
            $product_ids = array();
            foreach ($products as $key => $value) {
                $reorder_level = $value->reorder_level;
                $balance = $this->Common_model->item_balance_lab($value->record_id);
                if ($balance <= $reorder_level) {
                    ++$shortage;
                    $value->balance = $balance;
                    $values[] = $value;
                }
            }
            $data['values'] = $values;
            $data['onset'] = $onset;
            $data['record_id'] = $record_id;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/reports/stock_shortage_lab', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function profit_distribution()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['report_type'] = 'total';
            $data['title'] = 'Profit Distribution';
            $data['page_title'] = 'Profit Distribution';
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/reports/profit_distribution', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function financial_year_balance()
    {
        $financial_year_id = $this->input->post('financial_year_id');
        $from_date = $this->input->post('from_date');
        $to_date = $this->input->post('to_date');

        $pathologyWhere = array();
        $pathologyWhere['date >= '] = $from_date;
        $pathologyWhere['date <= '] = $to_date;
        $pathologyWhere['type'] = 'Test Invoice';
        $operationWhere['date >= '] = $from_date;
        $operationWhere['date <= '] = $to_date;
        $operationInvoiceWhere['date >= '] = $from_date;
        $operationInvoiceWhere['date <= '] = $to_date;
        $operationInvoiceWhere['type'] = 'Admission';
        $operationInvoiceAdvanceWhere['date >= '] = $from_date;
        $operationInvoiceAdvanceWhere['date <= '] = $to_date;
        $operationInvoiceAdvanceWhere['type'] = 'AdmissionAdvance';
        $operationWhere['type'] = 'Operation';
        $operationDetailsWhere = array();
        $operationDetailsWhere['operation_date >= '] = $from_date;
        $operationDetailsWhere['operation_date <= '] = $to_date;

        $ecgWhere['date >= '] = $from_date;
        $ecgWhere['date <= '] = $to_date;
        $ecgWhere['test_category'] = 'ECG';
        $xrayWhere['date >= '] = $from_date;
        $xrayWhere['date <= '] = $to_date;
        $xrayWhere['test_category'] = '%X-Ray%';
        $ultraWhere['date >= '] = $from_date;
        $ultraWhere['date <= '] = $to_date;
        $ultraWhere['test_category like'] = 'Ultrasonogram';

        $generalIncomeWhere = array();
        $generalIncomeWhere['date >= '] = $from_date;
        $generalIncomeWhere['date <= '] = $to_date;

        $consultancyWhere = array();
        $consultancyWhere['type'] = 'Appointment';
        $consultancyWhere['date >= '] = $from_date;
        $consultancyWhere['date <= '] = $to_date;

        $commission_patholgyWhere = array();
        $commission_patholgyWhere['type'] = 'Test Invoice';
        $commission_patholgyWhere['date >= '] = $from_date;
        $commission_patholgyWhere['date <= '] = $to_date;



        $operation_commissionWhere = array();
        $operation_commissionWhere['operation_date >= '] = $from_date;
        $operation_commissionWhere['operation_date <= '] = $to_date;

        $sonologistExpenseWhere = array();
        $sonologistExpenseWhere['date >='] = $from_date;
        $sonologistExpenseWhere['date <='] = $to_date;

        $generalExpenseWhere = array();
        $generalExpenseWhere['date >= '] = $from_date;
        $generalExpenseWhere['date <= '] = $to_date;
        $staffSalaryWhere = array();
        $staffSalaryWhere['status'] = 'Paid';
        $staffSalaryWhere['date >= '] = $from_date;
        $staffSalaryWhere['date <= '] = $to_date;

        $dueCollectionWhere = array();
        $dueCollectionWhere['mr_date >= '] = $from_date;
        $dueCollectionWhere['mr_date <= '] = $to_date;


        $salesWhere = array();
        $salesWhere['sales_from'] = 'Direct';
        $salesWhere['sales_date <= '] = $from_date;
        $salesWhere['sales_date >= '] = $to_date;

        $mrWhere = array();
        $mrWhere['mr_date <= '] = $from_date;
        $mrWhere['mr_date >= '] = $to_date;

        $emergencyWhere = array();
        $emergencyWhere['type'] = 'Emergency';
        $emergencyWhere['date >= '] = $from_date;
        $emergencyWhere['date <= '] = $to_date;

        $ambulanceWhere = array();
        $ambulanceWhere['type'] = 'Ambulance';
        $ambulanceWhere['date >= '] = $from_date;
        $ambulanceWhere['date <= '] = $to_date;

        $doctorServiceWhere = array();
        $doctorServiceWhere['type'] = 'Doctor Service';
        $doctorServiceWhere['date >= '] = $from_date;
        $doctorServiceWhere['date >= '] = $to_date;

        $donorWhere = array();
        $donorWhere['type'] = 'Donor';
        $donorWhere['date >= '] = $from_date;
        $donorWhere['date <= '] = $to_date;

        $dressingWhere = array();
        $dressingWhere['type'] = 'Dressing';
        $dressingWhere['date >= '] = $from_date;
        $dressingWhere['date <= '] = $to_date;

        $supplier_paymentsWhere = array();
        $supplier_paymentsWhere['payment_date >= '] = $from_date;
        $supplier_paymentsWhere['payment_date <= '] = $to_date;

        $incomeWhere = array();
        // $incomeWhere['income_type != '] = 'Pharmacy' ;
        $incomeWhere['income_date >= '] = $from_date;
        $incomeWhere['income_date <= '] = $to_date;
        $expenseWhere = array();
        //  $expenseWhere['approval'] = 'Approved' ;
        // $expenseWhere['expense_type != '] = 'Pharmacy' ;
        $expenseWhere['expense_date >= '] = $from_date;
        $expenseWhere['expense_date <= '] = $to_date;

        $labInWhere = array();
        $labInWhere['in_date >= '] = $from_date;
        $labInWhere['in_date <= '] = $to_date;

        $dressingWhere = array();
        $dressingWhere['type'] = 'Dressing';
        $dressingWhere['date >='] = $from_date;
        $dressingWhere['date <= '] = $to_date;





        $data['pathology'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhere, 'sub_total');
        $data['pathology_paid'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhere, 'paid');
        //var_dump($pathologyWhere);die;
        $data['pathology_due'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhere, 'due');
        $data['operation'] = $this->Common_model->calCulateSum('create_bill', $operationWhere, 'sub_total');
        $operation_paid = $this->Common_model->calculateSumMultiple('create_bill', $operationWhere, array('paid', 'medicine_cost', 'advance'));



        $operationInvoice = $this->Common_model->calculateSumMultiple('create_bill', $operationInvoiceWhere, array('sub_total', 'advance'));
        $data['operationInvoice'] = $operationInvoice->sub_total + $operationInvoice->advance;

        $operationAdvanceInvoice = $this->Common_model->calculateSum('create_bill', $operationInvoiceAdvanceWhere, 'sub_total');
        $data['operationAdvanceInvoice'] = isset($operationAdvanceInvoice) ? $operationAdvanceInvoice : 0;
        //var_dump($data['operationInvoice'] );die;

        $data['operation_paid'] = $operation_paid->paid;
        $data['operation_due'] = $this->Common_model->calCulateSum('create_bill', $operationWhere, 'due');

        $data['ecg'] = $this->Common_model->calCulateSum('sales_test', $ecgWhere, 'test_price');
        $data['xray'] = $this->Common_model->calCulateSum('sales_test', $xrayWhere, 'test_price');
        $data['ultra'] = $this->Common_model->calCulateSum('sales_test', $ultraWhere, 'test_price');


        $consultancy = $this->Common_model->calculateSumMultiple('create_bill', $consultancyWhere, array('sub_total', 'paid', 'due', 'doctor_commission'));
        $data['consultancy'] = isset($consultancy) ?  $consultancy->sub_total : 0;
        $data['consultancy_paid'] = isset($consultancy) ?  $consultancy->paid : 0;
        $data['consultancy_due'] = isset($consultancy) ?  $consultancy->due : 0;
        $data['consultancy_doctor_commission'] = isset($consultancy) ?  $consultancy->doctor_commission : 0;
        //  $data['doctor_commission_patholgy'] = $this->Common_model->calCulateSum('create_bill',$commission_patholgyWhere,'doctor_commission');
        $doctor_commission_patholgy = $this->Common_model->calculateSumMultiple('create_bill', $commission_patholgyWhere, array('doctor_commission', 'reference_by_commission', 'discount'));
        $total_discount = isset($doctor_commission_patholgy) ? $doctor_commission_patholgy->discount : 0;
        $doctor_commission = isset($doctor_commission_patholgy) ? $doctor_commission_patholgy->doctor_commission : 0;
        $reference_by_commission = isset($doctor_commission_patholgy) ? $doctor_commission_patholgy->reference_by_commission : 0;
        $data['doctor_commission_patholgy'] = $doctor_commission + $reference_by_commission - $total_discount;


        $operation_commission =  $this->Common_model->calculateSumMultiple('operation_details', $operationDetailsWhere, array('surgeon_commission', 'surgeon_assistant_commission', 'surgeon_team_commission', 'anesthesia_commission', 'medicine_cost', 'service_fee'));
        $surgeon_commission = isset($operation_commission) ? $operation_commission->surgeon_commission : 0;
        $anesthesia_commission = isset($operation_commission) ? $operation_commission->anesthesia_commission : 0;
        $medicine_cost = isset($operation_commission) ? $operation_commission->medicine_cost : 0;
        $surgeon_assistant_commission = isset($operation_commission) ? $operation_commission->surgeon_assistant_commission : 0;
        $surgeon_team_commission = isset($operation_commission) ? $operation_commission->surgeon_team_commission : 0;
        $service_fee = isset($operation_commission) ? $operation_commission->service_fee : 0;
        $data['operation_commission'] =  $surgeon_commission + $anesthesia_commission + $medicine_cost + $surgeon_assistant_commission + $surgeon_team_commission + $service_fee;

        $data['sonologistExpense'] = $this->Common_model->calCulateSum('sonologist', $sonologistExpenseWhere, 'amount');

        $data['staffSalary'] = $this->Common_model->calCulateSum('create_salary_sheet', $staffSalaryWhere, 'net_salary');

        $data['dueCollection'] = $this->Common_model->calCulateSum('due_collections', $dueCollectionWhere, 'mr_amount');
        // var_dump($data['dueCollection']);die;

        $sales_orders = $this->Common_model->calculateSumMultiple('sales_orders', $salesWhere, array('grand_net_total', 'paid_amount', 'due_amount'));
        $data['sales_amount'] = $sales_orders->grand_net_total;
        $data['sales_paid_amount'] = $sales_orders->paid_amount;
        $data['sales_due_amount'] = $sales_orders->due_amount;
        $data['pharmacy_collection'] = $this->Common_model->calCulateSum('mr', $mrWhere, 'mr_amount');

        $data['supplier_payments'] = $this->Common_model->calCulateSum('supplier_payments', $supplier_paymentsWhere, 'payment_amount');



        $emergency = $this->Common_model->calculateSumMultiple('create_bill', $emergencyWhere, array('sub_total', 'paid', 'doctor_commission', 'others_cost'));
        $data['emergency_total'] = isset($emergency) ? $emergency->sub_total : 0;
        $data['emergency_paid'] = isset($emergency) ? $emergency->paid : 0;
        $data['emergency_doctor_commission'] = isset($emergency) ? $emergency->doctor_commission : 0;
        $data['emergency_others_cost'] = isset($emergency) ? $emergency->others_cost : 0;
        $ambulance = $this->Common_model->calculateSumMultiple('create_bill', $ambulanceWhere, array('sub_total', 'paid', 'fuel_cost', 'road_cost', 'service_maintanance_cost'));
        $data['ambulance_total'] = isset($ambulance) ? $ambulance->sub_total : 0;
        $data['ambulance_paid'] = isset($ambulance) ? $ambulance->paid : 0;
        $data['ambulance_fuel_cost'] = isset($ambulance) ? $ambulance->fuel_cost : 0;
        $data['ambulance_road_cost'] = isset($ambulance) ? $ambulance->road_cost : 0;
        $data['ambulance_service_maintanance_cost'] = isset($ambulance) ? $ambulance->service_maintanance_cost : 0;

        $doctor_service = $this->Common_model->calculateSumMultiple('create_bill', $doctorServiceWhere, array('sub_total', 'paid', 'due', 'doctor_commission', 'reference_by_commission'));
        $data['doctor_service_total'] = isset($doctor_service) ? $doctor_service->sub_total : 0;
        $data['doctor_service_paid'] = isset($doctor_service) ? $doctor_service->paid : 0;
        $data['doctor_service_reference_by_commission'] = isset($doctor_service) ? $doctor_service->reference_by_commission : 0;
        $data['doctor_service_commission'] = isset($doctor_service) ? $doctor_service->doctor_commission : 0;
        $data['doctor_service_commission'] = $data['doctor_service_reference_by_commission'] + $data['doctor_service_commission'];
        $data['doctor_service_due'] = isset($doctor_service) ? $doctor_service->due : 0;




        $donor = $this->Common_model->calculateSumMultiple('create_bill', $donorWhere, array('sub_total', 'paid'));
        $data['donor_total'] = isset($donor) ? $donor->sub_total : 0;
        $data['donor_paid'] = isset($donor) ? $donor->paid : 0;

        // var_dump($donor) ; die ;

        $dressing = $this->Common_model->calculateSumMultiple('create_bill', $dressingWhere, array('sub_total', 'paid', 'doctor_commission'));
        $data['dressing_total'] = isset($dressing) ? $dressing->sub_total : 0;
        $data['dressing_paid'] = isset($dressing) ? $dressing->paid : 0;
        $data['dressing_cost'] = isset($dressing) ? $dressing->doctor_commission : 0;
        //var_dump($data['dressing_cost'] ) ; die ;

        $data['general_income'] = $this->Common_model->calCulateSum('incomes', $incomeWhere, 'voucher_amount');
        $data['general_expense'] = $this->Common_model->calCulateSum('expenses', $expenseWhere, 'voucher_amount');
        // var_dump($expenseWhere);die;
        $data['lab_product'] = $this->Common_model->calCulateSum('lab_product_in', $labInWhere, 'grand_total_price');

        $data['total_paid_amount'] = $data['pathology_paid'] +  $data['operation_paid'] + $data['operationInvoice'] +  $data['consultancy_paid'] + $data['dueCollection']  + $data['emergency_paid']  + $data['ambulance_paid'] + $data['doctor_service_paid'] + $data['donor_paid'] + $data['dressing_paid'] + $data['general_income'] + $data['operationAdvanceInvoice']; // + $data['sales_paid_amount'] + $data['pharmacy_collection'] ;
        $data['total_expense_amount'] = $data['doctor_commission_patholgy'] + $data['consultancy_doctor_commission'] + $data['operation_commission'] + $data['sonologistExpense'] + $data['staffSalary'] + $data['emergency_doctor_commission'] + $data['emergency_others_cost'] + $data['ambulance_fuel_cost'] +  $data['ambulance_road_cost'] + $data['ambulance_service_maintanance_cost'] + $data['doctor_service_commission'] + $data['general_expense']  + $data['dressing_cost'] + $data['lab_product'];
        $data['balance_amount'] = $data['total_paid_amount'] - $data['total_expense_amount']; //  + $data['supplier_payments'] ;
        //var_dump($data['total_paid_amount'].' ' . $data['total_expense_amount'] );die;
        $grand_total_income = round($data['total_paid_amount']);
        $grand_total_expense = round($data['total_expense_amount']);
        $grand_total_balance = round($data['balance_amount']);
        $data['grand_total_balance'] = $grand_total_balance;
        $partner_ids = $this->Common_model->columns('investments', array('financial_year_id' => $financial_year_id), 'partner_id');
        $partner_ids = array_unique($partner_ids);
        if (!count($partner_ids)) {
            $partner_ids[] = -1;
        }
        $data['financial_year_id'] = $financial_year_id;
        $data['partners'] = $this->Common_model->findAllWhereIn('partners', array(), $partner_ids, 'record_id', 'record_id', 'asc');

        $development_cost = $this->Common_model->calCulateSum('development_costs', array('financial_year_id' => $financial_year_id), 'amount');
        $development_cost = isset($development_cost) ? $development_cost : 0;
        $data['development_cost'] = $development_cost;

        $this->load->view('admin/reports/show_profit_distribution', $data);
    }
    public function set_development_cost()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['report_type'] = 'total';
            $data['title'] = 'Development Cost';
            $data['page_title'] = 'Development Cost';
            $data['info_header'] = 'Development Cost List';
            $data['development_costs'] = $this->Common_model->findAll('development_costs', array(), 'record_id', 'desc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/reports/set_development_cost', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function show_development_cost()
    {
        $financial_year_id = $this->input->post('financial_year_id');
        $from_date = $this->input->post('from_date');
        $to_date = $this->input->post('to_date');

        $pathologyWhere = array();
        $pathologyWhere['date >= '] = $from_date;
        $pathologyWhere['date <= '] = $to_date;
        $pathologyWhere['type'] = 'Test Invoice';
        $operationWhere['date >= '] = $from_date;
        $operationWhere['date <= '] = $to_date;
        $operationInvoiceWhere['date >= '] = $from_date;
        $operationInvoiceWhere['date <= '] = $to_date;
        $operationInvoiceWhere['type'] = 'Admission';
        $operationInvoiceAdvanceWhere['date >= '] = $from_date;
        $operationInvoiceAdvanceWhere['date <= '] = $to_date;
        $operationInvoiceAdvanceWhere['type'] = 'AdmissionAdvance';
        $operationWhere['type'] = 'Operation';
        $operationDetailsWhere = array();
        $operationDetailsWhere['operation_date >= '] = $from_date;
        $operationDetailsWhere['operation_date <= '] = $to_date;

        $ecgWhere['date >= '] = $from_date;
        $ecgWhere['date <= '] = $to_date;
        $ecgWhere['test_category'] = 'ECG';
        $xrayWhere['date >= '] = $from_date;
        $xrayWhere['date <= '] = $to_date;
        $xrayWhere['test_category'] = '%X-Ray%';
        $ultraWhere['date >= '] = $from_date;
        $ultraWhere['date <= '] = $to_date;
        $ultraWhere['test_category like'] = 'Ultrasonogram';

        $generalIncomeWhere = array();
        $generalIncomeWhere['date >= '] = $from_date;
        $generalIncomeWhere['date <= '] = $to_date;

        $consultancyWhere = array();
        $consultancyWhere['type'] = 'Appointment';
        $consultancyWhere['date >= '] = $from_date;
        $consultancyWhere['date <= '] = $to_date;

        $commission_patholgyWhere = array();
        $commission_patholgyWhere['type'] = 'Test Invoice';
        $commission_patholgyWhere['date >= '] = $from_date;
        $commission_patholgyWhere['date <= '] = $to_date;



        $operation_commissionWhere = array();
        $operation_commissionWhere['operation_date >= '] = $from_date;
        $operation_commissionWhere['operation_date <= '] = $to_date;

        $sonologistExpenseWhere = array();
        $sonologistExpenseWhere['date >='] = $from_date;
        $sonologistExpenseWhere['date <='] = $to_date;

        $generalExpenseWhere = array();
        $generalExpenseWhere['date >= '] = $from_date;
        $generalExpenseWhere['date <= '] = $to_date;
        $staffSalaryWhere = array();
        $staffSalaryWhere['status'] = 'Paid';
        $staffSalaryWhere['date >= '] = $from_date;
        $staffSalaryWhere['date <= '] = $to_date;

        $dueCollectionWhere = array();
        $dueCollectionWhere['mr_date >= '] = $from_date;
        $dueCollectionWhere['mr_date <= '] = $to_date;


        $salesWhere = array();
        $salesWhere['sales_from'] = 'Direct';
        $salesWhere['sales_date <= '] = $from_date;
        $salesWhere['sales_date >= '] = $to_date;

        $mrWhere = array();
        $mrWhere['mr_date <= '] = $from_date;
        $mrWhere['mr_date >= '] = $to_date;

        $emergencyWhere = array();
        $emergencyWhere['type'] = 'Emergency';
        $emergencyWhere['date >= '] = $from_date;
        $emergencyWhere['date <= '] = $to_date;

        $ambulanceWhere = array();
        $ambulanceWhere['type'] = 'Ambulance';
        $ambulanceWhere['date >= '] = $from_date;
        $ambulanceWhere['date <= '] = $to_date;

        $doctorServiceWhere = array();
        $doctorServiceWhere['type'] = 'Doctor Service';
        $doctorServiceWhere['date >= '] = $from_date;
        $doctorServiceWhere['date >= '] = $to_date;

        $donorWhere = array();
        $donorWhere['type'] = 'Donor';
        $donorWhere['date >= '] = $from_date;
        $donorWhere['date <= '] = $to_date;

        $dressingWhere = array();
        $dressingWhere['type'] = 'Dressing';
        $dressingWhere['date >= '] = $from_date;
        $dressingWhere['date <= '] = $to_date;

        $supplier_paymentsWhere = array();
        $supplier_paymentsWhere['payment_date >= '] = $from_date;
        $supplier_paymentsWhere['payment_date <= '] = $to_date;

        $incomeWhere = array();
        // $incomeWhere['income_type != '] = 'Pharmacy' ;
        $incomeWhere['income_date >= '] = $from_date;
        $incomeWhere['income_date <= '] = $to_date;
        $expenseWhere = array();
        //  $expenseWhere['approval'] = 'Approved' ;
        // $expenseWhere['expense_type != '] = 'Pharmacy' ;
        $expenseWhere['expense_date >= '] = $from_date;
        $expenseWhere['expense_date <= '] = $to_date;

        $labInWhere = array();
        $labInWhere['in_date >= '] = $from_date;
        $labInWhere['in_date <= '] = $to_date;

        $dressingWhere = array();
        $dressingWhere['type'] = 'Dressing';
        $dressingWhere['date >='] = $from_date;
        $dressingWhere['date <= '] = $to_date;





        $data['pathology'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhere, 'sub_total');
        $data['pathology_paid'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhere, 'paid');
        //var_dump($pathologyWhere);die;
        $data['pathology_due'] = $this->Common_model->calCulateSum('create_bill', $pathologyWhere, 'due');
        $data['operation'] = $this->Common_model->calCulateSum('create_bill', $operationWhere, 'sub_total');
        $operation_paid = $this->Common_model->calculateSumMultiple('create_bill', $operationWhere, array('paid', 'medicine_cost', 'advance'));



        $operationInvoice = $this->Common_model->calculateSumMultiple('create_bill', $operationInvoiceWhere, array('sub_total', 'advance'));
        $data['operationInvoice'] = $operationInvoice->sub_total + $operationInvoice->advance;

        $operationAdvanceInvoice = $this->Common_model->calculateSum('create_bill', $operationInvoiceAdvanceWhere, 'sub_total');
        $data['operationAdvanceInvoice'] = isset($operationAdvanceInvoice) ? $operationAdvanceInvoice : 0;

        $data['operation_paid'] = $operation_paid->paid;
        $data['operation_due'] = $this->Common_model->calCulateSum('create_bill', $operationWhere, 'due');

        $data['ecg'] = $this->Common_model->calCulateSum('sales_test', $ecgWhere, 'test_price');
        $data['xray'] = $this->Common_model->calCulateSum('sales_test', $xrayWhere, 'test_price');
        $data['ultra'] = $this->Common_model->calCulateSum('sales_test', $ultraWhere, 'test_price');


        $consultancy = $this->Common_model->calculateSumMultiple('create_bill', $consultancyWhere, array('sub_total', 'paid', 'due', 'doctor_commission'));
        $data['consultancy'] = isset($consultancy) ?  $consultancy->sub_total : 0;
        $data['consultancy_paid'] = isset($consultancy) ?  $consultancy->paid : 0;
        $data['consultancy_due'] = isset($consultancy) ?  $consultancy->due : 0;
        $data['consultancy_doctor_commission'] = isset($consultancy) ?  $consultancy->doctor_commission : 0;
        //  $data['doctor_commission_patholgy'] = $this->Common_model->calCulateSum('create_bill',$commission_patholgyWhere,'doctor_commission');
        $doctor_commission_patholgy = $this->Common_model->calculateSumMultiple('create_bill', $commission_patholgyWhere, array('doctor_commission', 'reference_by_commission', 'discount'));
        $total_discount = isset($doctor_commission_patholgy) ? $doctor_commission_patholgy->discount : 0;
        $doctor_commission = isset($doctor_commission_patholgy) ? $doctor_commission_patholgy->doctor_commission : 0;
        $reference_by_commission = isset($doctor_commission_patholgy) ? $doctor_commission_patholgy->reference_by_commission : 0;
        $data['doctor_commission_patholgy'] = $doctor_commission + $reference_by_commission - $total_discount;


        $operation_commission =  $this->Common_model->calculateSumMultiple('operation_details', $operationDetailsWhere, array('surgeon_commission', 'surgeon_assistant_commission', 'surgeon_team_commission', 'anesthesia_commission', 'medicine_cost', 'service_fee'));
        $surgeon_commission = isset($operation_commission) ? $operation_commission->surgeon_commission : 0;
        $anesthesia_commission = isset($operation_commission) ? $operation_commission->anesthesia_commission : 0;
        $medicine_cost = isset($operation_commission) ? $operation_commission->medicine_cost : 0;
        $surgeon_assistant_commission = isset($operation_commission) ? $operation_commission->surgeon_assistant_commission : 0;
        $surgeon_team_commission = isset($operation_commission) ? $operation_commission->surgeon_team_commission : 0;
        $service_fee = isset($operation_commission) ? $operation_commission->service_fee : 0;
        $data['operation_commission'] =  $surgeon_commission + $anesthesia_commission + $medicine_cost + $surgeon_assistant_commission + $surgeon_team_commission + $service_fee;

        $data['sonologistExpense'] = $this->Common_model->calCulateSum('sonologist', $sonologistExpenseWhere, 'amount');

        $data['staffSalary'] = $this->Common_model->calCulateSum('create_salary_sheet', $staffSalaryWhere, 'net_salary');

        $data['dueCollection'] = $this->Common_model->calCulateSum('due_collections', $dueCollectionWhere, 'mr_amount');

        $sales_orders = $this->Common_model->calculateSumMultiple('sales_orders', $salesWhere, array('grand_net_total', 'paid_amount', 'due_amount'));
        $data['sales_amount'] = $sales_orders->grand_net_total;
        $data['sales_paid_amount'] = $sales_orders->paid_amount;
        $data['sales_due_amount'] = $sales_orders->due_amount;
        $data['pharmacy_collection'] = $this->Common_model->calCulateSum('mr', $mrWhere, 'mr_amount');

        $data['supplier_payments'] = $this->Common_model->calCulateSum('supplier_payments', $supplier_paymentsWhere, 'payment_amount');



        $emergency = $this->Common_model->calculateSumMultiple('create_bill', $emergencyWhere, array('sub_total', 'paid', 'doctor_commission', 'others_cost'));
        $data['emergency_total'] = isset($emergency) ? $emergency->sub_total : 0;
        $data['emergency_paid'] = isset($emergency) ? $emergency->paid : 0;
        $data['emergency_doctor_commission'] = isset($emergency) ? $emergency->doctor_commission : 0;
        $data['emergency_others_cost'] = isset($emergency) ? $emergency->others_cost : 0;

        $ambulance = $this->Common_model->calculateSumMultiple('create_bill', $ambulanceWhere, array('sub_total', 'paid', 'fuel_cost', 'road_cost', 'service_maintanance_cost'));
        $data['ambulance_total'] = isset($ambulance) ? $ambulance->sub_total : 0;
        $data['ambulance_paid'] = isset($ambulance) ? $ambulance->paid : 0;
        $data['ambulance_fuel_cost'] = isset($ambulance) ? $ambulance->fuel_cost : 0;
        $data['ambulance_road_cost'] = isset($ambulance) ? $ambulance->road_cost : 0;
        $data['ambulance_service_maintanance_cost'] = isset($ambulance) ? $ambulance->service_maintanance_cost : 0;

        $doctor_service = $this->Common_model->calculateSumMultiple('create_bill', $doctorServiceWhere, array('sub_total', 'paid', 'due', 'doctor_commission', 'reference_by_commission'));
        $data['doctor_service_total'] = isset($doctor_service) ? $doctor_service->sub_total : 0;
        $data['doctor_service_paid'] = isset($doctor_service) ? $doctor_service->paid : 0;
        $data['doctor_service_reference_by_commission'] = isset($doctor_service) ? $doctor_service->reference_by_commission : 0;
        $data['doctor_service_commission'] = isset($doctor_service) ? $doctor_service->doctor_commission : 0;
        $data['doctor_service_commission'] = $data['doctor_service_reference_by_commission'] + $data['doctor_service_commission'];
        $data['doctor_service_due'] = isset($doctor_service) ? $doctor_service->due : 0;




        $donor = $this->Common_model->calculateSumMultiple('create_bill', $donorWhere, array('sub_total', 'paid'));
        $data['donor_total'] = isset($donor) ? $donor->sub_total : 0;
        $data['donor_paid'] = isset($donor) ? $donor->paid : 0;

        $dressing = $this->Common_model->calculateSumMultiple('create_bill', $dressingWhere, array('sub_total', 'paid', 'doctor_commission'));
        $data['dressing_total'] = isset($dressing) ? $dressing->sub_total : 0;
        $data['dressing_paid'] = isset($dressing) ? $dressing->paid : 0;
        $data['dressing_cost'] = isset($dressing) ? $dressing->doctor_commission : 0;

        $data['general_income'] = $this->Common_model->calCulateSum('incomes', $incomeWhere, 'voucher_amount');
        $data['general_expense'] = $this->Common_model->calCulateSum('expenses', $expenseWhere, 'voucher_amount');
        // var_dump($expenseWhere);die;
        $data['lab_product'] = $this->Common_model->calCulateSum('lab_product_in', $labInWhere, 'grand_total_price');

        $data['total_paid_amount'] = $data['pathology_paid'] +  $data['operation_paid'] + $data['operationInvoice'] +  $data['consultancy_paid'] + $data['dueCollection']  + $data['emergency_paid']  + $data['ambulance_paid'] + $data['doctor_service_paid'] + $data['donor_paid'] + $data['dressing_paid'] + $data['general_income'] + $data['operationAdvanceInvoice']; // + $data['sales_paid_amount'] + $data['pharmacy_collection'] ;
        $data['total_expense_amount'] = $data['doctor_commission_patholgy'] + $data['consultancy_doctor_commission']  + $data['operation_commission'] + $data['sonologistExpense'] + $data['staffSalary'] + $data['emergency_doctor_commission'] + $data['emergency_others_cost'] + $data['ambulance_fuel_cost'] +  $data['ambulance_road_cost'] + $data['ambulance_service_maintanance_cost'] + $data['doctor_service_commission'] + $data['general_expense'] + $data['dressing_cost'] + $data['lab_product'];
        $data['balance_amount'] = $data['total_paid_amount'] - $data['total_expense_amount']; //  + $data['supplier_payments'] ;

        $grand_total_income = round($data['total_paid_amount']);
        $grand_total_expense = round($data['total_expense_amount']);
        $grand_total_balance = round($data['balance_amount']);

        $partner_ids = $this->Common_model->columns('investments', array('financial_year_id' => $financial_year_id), 'partner_id');
        $partner_ids = array_unique($partner_ids);
        if (!count($partner_ids)) {
            $partner_ids[] = -1;
        }
        $data['financial_year_id'] = $financial_year_id;
        $data['partners'] = $this->Common_model->findAllWhereIn('partners', array(), $partner_ids, 'record_id', 'record_id', 'asc');

        $development_cost = $this->Common_model->calCulateSum('development_costs', array('financial_year_id' => $financial_year_id), 'amount');
        $development_cost = isset($development_cost) ? $development_cost : 0;

        $data['grand_total_balance'] = $grand_total_balance - $development_cost;

        $this->load->view('admin/reports/show_development_cost', $data);
    }

    public function saveOrUpdateDevepmentCost()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST;
            $update_id = $input['update_id'];
            unset($input['update_id']);

            $record_id = 0;
            if ($update_id == 0 || empty($update_id)) {
                $insert = $this->Common_model->saveData('development_costs', $input);
                if ($insert) {
                    $this->session->set_flashdata('message', INSERT_MSG);
                } else {
                    $this->session->set_flashdata('message', INSERT_ERROR_MSG);
                }
            } else {
                $update = $this->Common_model->updateData('development_costs', $input, array('record_id' => $update_id));
                if ($update) {
                    $this->session->set_flashdata('message', UPDATE_MSG);
                } else {
                    $this->session->set_flashdata('message', UPDATE_ERROR_MSG);
                }
            }
            redirect('reports/set_development_cost');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function deleteDevelopmentCost($id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if ($this->Common_model->delete_info('record_id', $id, 'development_costs')) {
                $this->session->set_flashdata('message', DELETE_MSG);
            } else {
                $this->session->set_flashdata('message', DELETE_ERROR_MSG);
            }
            redirect('reports/set_development_cost', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function reference_wise_report_outdoor()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['section'] = 'outdoor';
            $data['title'] = 'R.F / Dr. Wise Report';
            $data['page_title'] = 'R.F / Dr. Wise Report';
            $data['info_header'] = 'R.F / Dr. Wise Report';

            $data['references'] = $this->Common_model->findAll("reference_by", array(), "record_id", "desc");
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/reports/reference_wise_report', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function reference_wise_report_indoor()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['section'] = 'indoor';
            $data['title'] = 'R.F / Dr. Wise Report';
            $data['page_title'] = 'R.F / Dr. Wise Report';
            $data['info_header'] = 'R.F / Dr. Wise Report';

            $data['references'] = $this->Common_model->findAll("reference_by", array(), "record_id", "desc");
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/reports/reference_wise_report', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function show_reference_wise_commossion_report()
    {
        $section = $this->input->post('section');
        $from_date = $this->input->post('from_date');
        $to_date = $this->input->post('to_date');
        $discount_type = $this->input->post('discount_type');
        $where_in = array();
        $where_in_column = 'discount_type';
        if ($discount_type == 1) {
            $where_in = array(1, 4);
        }
        if ($discount_type == 2) {
            $where_in = array(2, 5);
        }
        $reference_by = $this->input->post('reference_by');
        $where = array();
        if ($section == 'outdoor') {
            $where['type'] = 'Test Invoice';
        } elseif ($section == 'indoor') {
            $where['type'] = 'Operation';
        }
        if (!empty($from_date) && !empty($to_date)) {
            $where['date >= '] = $from_date;
            $where['date <= '] = $to_date;
        }
        // $where['discount_type'] = $discount_type;
        $where['reference_by'] = $reference_by;
        $reference_name = '';
        $reference_label = '';
        if ($discount_type == 1 or $discount_type == 4) {
            $reference = $this->Common_model->findById('reference_by', array('record_id' => $reference_by));
            $reference_name = isset($reference) ? $reference->reference_name . "[$reference->reference_prefix$reference->reference_no]" : "";
            $reference_label = "Reference (R.F)";
        } elseif ($discount_type == 2 or $discount_type == 5) {
            $doctor = $this->Common_model->findById('doctor', array('record_id' => $reference_by));
            $reference_name = isset($doctor) ? $doctor->name . "[$doctor->doctor_prefix$doctor->doctor_no]" : "";
            $reference_label = "Doctor (Dr.)";
        } elseif ($discount_type == 3) {
            $reference_name = "Hospital";
            $reference_label = "";
        }
        $data['reference_label'] = $reference_label;
        $data['reference_name'] = $reference_name;
        $data['section'] = $section;
        $data['values'] = $this->Common_model->findAllWhereIn('create_bill', $where, $where_in, $where_in_column, 'record_id', 'desc');
        $this->load->view("admin/reports/show_reference_wise_commission_report", $data);
    }
    public function patient_status()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Patient Status';
            $data['page_title'] = 'Patient Status';
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/reports/patient_status_report_index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function show_patient_status()
    {
        $from_date = $this->input->post('from_date');
        $to_date = $this->input->post('to_date');
        $report_type = $this->input->post('report_type');
        $where = array();
        $where['date >= '] = $from_date;
        $where['date <= '] = $to_date;
        $invoices = $this->Common_model->findAll('create_bill', $where, "record_id", "asc");
        $outdoor = array('Appointment', 'Test Invoice');
        $indoor = array('Admission');
        $service = array('Emergency', 'Dressing', 'Donor');
        $values = array();
        $outdoor_patient = 0;
        $indoor_patient = 0;
        $service_patient = 0;
        foreach ($invoices as $key => $value) {
            if (in_array($value->type, $outdoor)) {
                ++$outdoor_patient;
            } elseif (in_array($value->type, $indoor)) {
                ++$indoor_patient;
            } elseif (in_array($value->type, $service)) {
                ++$service_patient;
            }
        }
        if ($report_type == 'Outdoor') {
           // $outdoor_patient = 0;
            $indoor_patient = 0;
            $service_patient = 0;
        } elseif ($report_type == "Indoor") {
            $outdoor_patient = 0;
           // $indoor_patient = 0;
            $service_patient = 0;
        } elseif ($report_type == "Service") {
            $outdoor_patient = 0;
            $indoor_patient = 0;
           // $service_patient = 0;
        }
        $data['from_date'] = $from_date ;
        $data['to_date'] = $to_date ;
        $data['outdoor_patient'] = $outdoor_patient;
        $data['indoor_patient'] = $indoor_patient;
        $data['service_patient'] = $service_patient;
        $data['total_patient'] = $outdoor_patient + $indoor_patient + $service_patient;
        $this->load->view('admin/reports/patient_status_report_show', $data);
    }
    public function show_details_patient_status()
    {
        $user_type = $this->session->ses_user_type;
        $type = $this->input->get('type') ;
        $from_date = $this->input->get('from_date');
        $to_date = $this->input->get('to_date');
        $where = array();
        $where['date >= '] = $from_date;
        $where['date <= '] = $to_date; 
        $where_in = array() ;
        $where_in_column = 'type' ;
        if($type == 'Outdoor'){
            $where_in = array('Appointment', 'Test Invoice');
        }elseif($type == 'Indoor'){
            $where_in = array('Admission');
        }elseif($type == 'Service'){
            $where_in = array('Emergency', 'Dressing', 'Donor');
        }
        $data['from_date'] = $from_date ;
        $data['to_date'] = $to_date ;
        $data['title'] = 'Patient Status';
        $data['page_title'] = 'Patient Status';
        $data['values'] = $this->Common_model->findAllWhereIn('create_bill',$where,$where_in,$where_in_column,'created_at','asc') ;
        $this->load->view('admin/layouts/header');
        $this->load->view('admin/reports/patient_status_report_show_details', $data);
        $this->load->view('admin/layouts/footer');
    }

    public function purchase_discount_list()
    {
        
        $from_date = $this->input->post('from_date');
        $to_date = $this->input->post('to_date');
        if (!isset($from_date) && !isset($to_date)) {
            $from_date = $to_date = date('Y-m-d');
        }
        $where = array();
        
        if (!empty($from_date) && !empty($to_date)) {
            $where['purchase_date >= '] = $from_date;
            $where['purchase_date <= '] = $to_date;
        } elseif (!empty($from_date) && empty($to_date)) {
            $where['purchase_date'] = $from_date;
        } elseif (empty($from_date) && !empty($to_date)) {
            $where['purchase_date'] = $to_date;
        }

        $where['order_discount_amount >'] = 0;

        $type = $this->input->get('type') === 'optic' ? 'optic' : 'medicine';
        $where['type'] = $type;
        
        
        $data['type'] = $type ;
        $data['from_date'] = $from_date ;
        $data['to_date'] = $to_date ;
        $data['report_title'] = "Purchase Discount Report From ". $from_date." To ".$to_date ;
        $data['title'] = 'Medicine/Product Purchase Discount List';
        $data['page_title'] = 'Medicine/Product Purchase Discount List';

        $data['values'] = $this->Common_model->findAll('purchase_orders', $where, 'purchase_id', 'desc');

        
        $this->load->view('admin/layouts/header');
        $this->load->view('admin/reports/purchase_discount_list', $data);
        $this->load->view('admin/layouts/footer');
    }


    public function stock_report_product_search(){

        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Medicine History Report';
            $data['page_title'] = 'Medicine History Report';
            // $where = array('type'=>'Product', 'type'=>'Product');
            $where = array();
            $where_in = array('Medicine');
            $options = array(
                'joins' => array(
                    array(
                        'table' => 'units',
                        'condition' => 'units.record_id = product_name.unit_id',
                        'jointype' => 'LEFT'
                    ),
                    array(
                        'table' => 'generic_names',
                        'condition' => 'generic_names.record_id = product_name.product_category_generic_name_id',
                        'jointype' => 'LEFT'
                    ),
                    array(
                        'table' => 'types_of_medicine',
                        'condition' => 'types_of_medicine.record_id = product_name.medicine_type_id',
                        'jointype' => 'LEFT'
                    ),
                ),
                'select' => 'product_name.*,units.unit_short_name,generic_names.generic_name,type_name',
                'where' => $where,
                'order' => array(
                    'product_name.record_id' => 'asc',
                ),
            );
            // $data['products'] = $this->Common_model->commonJoins("product_name", $options, $where_in, 'product_name.type');
            // ddd($this->db->last_query());
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/reports/medicine_history_report',$data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }

    }

    public function show_medicine_history() {
        $date_from = $this->input->post('date_from');
        $date_to = $this->input->post('date_to');
        $product_name = $this->input->post('product_name');
        $product_type = $this->input->post('ptype');
        $data['from_date'] = $date_from;
        $data['to_date'] = $date_to;
        $data['product_name'] = $product_name;
        if($product_type == 'Product'){
            $data['product_info'] = $this->Common_model->findById('product_name', array('record_id'=>$product_name));
            $data['product'] = $data['product_info']->product_name;
        }else{
            $data['product_info'] = $this->drug_model->findById(array('drug_medicine.record_id'=>$product_name));
            $data['product'] = $data['product_info']->brand_name. ' - '.$data['product_info']->strength;
        }

        $where = [];
        $where['purchase_date>='] = $date_from;
        $where['purchase_date<='] = $date_to;
        $where['product_id'] = $product_name;
        $groupByColumn = 'purchase_date';

        $productPurchases = $this->Common_model->getMedicineDateToDatePurchaseOrders($date_from, $date_to, $product_name, $product_type);

        $productSales = $this->Common_model->getMedicineDateToDateSalesOrders($date_from, $date_to, $product_name, $product_type);

        $productAccountsArr = [];

        foreach($productPurchases as $row){
            $productAccountsArr[$row->purchase_date] = new stdClass();
            $productAccountsArr[$row->purchase_date]->purchase = $row;
        }

        foreach($productSales as $row){
            if(!isset($productAccountsArr[$row->sales_date])){
                $productAccountsArr[$row->sales_date] = new stdClass();
            }
           
            $productAccountsArr[$row->sales_date]->sale = $row;
        }

        $productPurchasesReturn = $this->Common_model->getMedicineDateToDatePurchaseReturns($date_from, $date_to, $product_name, $product_type);

        foreach($productPurchasesReturn as $row){
            if(!isset($productAccountsArr[$row->return_date])){
                $productAccountsArr[$row->return_date] = new stdClass();
            }
           
            $productAccountsArr[$row->return_date]->preturn = $row;
        }

        $productSalesReturn = $this->Common_model->getMedicineDateToDateSalesReturns($date_from, $date_to, $product_name, $product_type);

        foreach($productSalesReturn as $row){
            if(!isset($productAccountsArr[$row->return_date])){
                $productAccountsArr[$row->return_date] = new stdClass();
            }
        
            $productAccountsArr[$row->return_date]->sreturn = $row;
        }
        

        ksort($productAccountsArr);
        
        $data['product_records'] = $productAccountsArr;
        $data['closing_balance'] = $this->Common_model->getToDateProductBalance($product_name, $date_from, $product_type);
        
        $this->load->view('admin/reports/show_medicine_history_new', $data);

    }

    public function getToDateProductBalance($productID, $toDate, $product_type){

        $this->db->select("sum(purchase_order_details.order_qty + purchase_order_details.free_qty) as total");
        $this->db->from('purchase_order_details');
        $this->db->join('purchase_orders', 'purchase_orders.purchase_id = purchase_order_details.purchase_order_id');
        $this->db->where('purchase_orders.purchase_date<', $toDate);
        $this->db->where('purchase_order_details.product_id', $productID);
        $this->db->where('purchase_order_details.purchase_type', $product_type);
        $this->db->where('purchase_order_details.status','Active');
        $purchase_query = $this->db->get()->row();
        $purchase_qty = ($purchase_query->total > 0) ?  $purchase_query->total : 0;

        $this->db->select("sum(sales_order_details.order_qty + sales_order_details.free_qty) as total");
        $this->db->from('sales_order_details');
        $this->db->join('sales_orders', 'sales_orders.sales_id = sales_order_details.sales_order_id');
        $this->db->where('sales_orders.sales_date<', $toDate);
        $this->db->where('sales_order_details.product_id',$productID);
        $this->db->where('sales_order_details.sales_type', $product_type);
        $this->db->where('sales_order_details.status','Active');
        $sales_query = $this->db->get()->row();
        $sales_qty = ($sales_query->total > 0) ? $sales_query->total: 0 ;

        $this->db->select("sum(return_qty) as return_qty");
        $this->db->from('return_details');
        $this->db->where('product_id',$productID);
        $this->db->where('return_type', $product_type);
        $this->db->where('status','Active');
        $this->db->where('created_at<', $toDate);
        $supplier_return_query = $this->db->get()->row();
        $supplier_return_qty = ($supplier_return_query->return_qty > 0) ?$supplier_return_query->return_qty:0 ;

        $this->db->select("sum(return_qty) as return_qty");
        $this->db->from('customer_return_details');
        $this->db->where('product_id',$productID);
        $this->db->where('return_type', $product_type);
        $this->db->where('status','Active');
        $this->db->where('created_at<', $toDate);
        $customer_return_query = $this->db->get()->row();
        $customer_return_qty = ($customer_return_query->return_qty > 0)?$customer_return_query->return_qty:0 ;
        $balance = $purchase_qty + $customer_return_qty - $sales_qty - $supplier_return_qty;

        $response = new stdClass;
        $response->purchase_qty = $purchase_qty ;
        $response->sales_qty = $sales_qty ;
        $response->supplier_return_qty = $supplier_return_qty ;
        $response->customer_return_qty = $customer_return_qty ;
        $response->balance = $balance ;
        return $response ;

    }

    public function getMedicineDateToDatePurchaseOrders($fromDate, $toDate, $productID, $product_type){

        $this->db->select('
                        purchase_orders.purchase_date, 
                        SUM(purchase_order_details.order_qty + purchase_order_details.free_qty) as total,
                        purchase_order_details.product_id
                        ')
                 ->from('purchase_order_details')
                 ->join('purchase_orders', 'purchase_order_details.purchase_order_id = purchase_orders.purchase_id')
                 ->where('purchase_orders.purchase_date>=', $fromDate)
                 ->where('purchase_orders.purchase_date<=', $toDate)
                 ->where('purchase_order_details.product_id', $productID)
                 ->where('purchase_order_details.purchase_type', $product_type)
                 ->group_by('purchase_orders.purchase_date')
                 ->order_by('purchase_orders.purchase_date', "ASC");

        return $this->db->get()->result();
    }

    public function sales_profit_loss_report()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'All Product Profit-Loss Report';
            $data['page_title'] = 'All Product Profit-Loss Report';
            $data['info_header'] = 'All Product Profit-Loss Report';
            $from_date = $this->input->get('date_from');
            $to_date = $this->input->get('date_to');
            $product_id = $this->input->get('product_id');
            if (!isset($from_date) && !isset($to_date)) {
                $from_date = $to_date = date('Y-m-d');
            }

            if(empty($product_id)){
                $productId = 0;
            }else{
                $productId = intval($product_id);
            }

            
            $type = $this->input->get('type') === 'optic' ? 'optic' : 'medicine';

            $data['product_id'] = $product_id;
            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;
            $data['type'] = $type;

            
        
            $data['products'] = $this->Common_model->selseMDrugList($from_date, $to_date, $productId, $type);
             //ddd($data['products']);
        
            $data['report_title'] = 'All Product Profit-Loss Report from '.$from_date.' to '.$to_date;

            $salesDiscount = $this->Common_model->getSalesDiscount($from_date, $to_date, $productId);
            
             $data['sales_discount'] = $salesDiscount;
            
           
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/reports/sales_profit_loss_report', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
