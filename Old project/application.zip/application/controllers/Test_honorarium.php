<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Test_honorarium extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Test Commission Info';
            $data['page_title'] = 'Test Commission Info';
            $data['info_header'] = 'All Test Commission List';

            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $doctor_id = $this->input->get('doctor_id');
            $reference_by = $this->input->get('reference_by');

            $where = array() ;
            if (!admin()) {
                $where['show_hide'] = 'Show';
            }
            $where['type'] = 'Test Invoice';

            if(!isset($from_date) && !isset($to_date) && !isset($doctor_id)){
                $where['date'] = date('Y-m-d') ;
            }
            if($doctor_id) $where['doctor_id'] = $doctor_id ;
            if($reference_by) $where['reference_by'] = $reference_by ;

            if(!empty($from_date) && !empty($to_date)){
                $where['date >= '] = $from_date ;
                $where['date <= '] = $to_date ;
            }elseif(!empty($from_date) && empty($to_date)){
                $where['date'] = $from_date ;
            }elseif(empty($from_date) && !empty($to_date)){
                $where['date'] = $to_date ;
            }
            $data['from_date'] = $from_date ;
            $data['to_date'] = $to_date ;
            $data['doctor_id'] = $doctor_id;
            $data['reference_by'] = $reference_by;
            $data['values'] = $this->Common_model->findAll('create_bill',$where,'record_id','desc');

            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_honorarium/test_honorariun', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
     public function appointment() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Doctor Payment Info';
            $data['page_title'] = 'Doctor Payment Info';
            $data['info_header'] = 'All Doctor Payment List ';

            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $doctor_id = $this->input->get('doctor_id');
            $reference_by = $this->input->get('reference_by');

            $where = array() ;
            if (!admin()) {
                $where['show_hide'] = 'Show';
            }
            $where['type'] = 'Appointment';

            if(!isset($from_date) && !isset($to_date) && !isset($doctor_id)){
                $where['date'] = date('Y-m-d') ;
            }
            if($doctor_id) $where['doctor_id'] = $doctor_id ;

            if(!empty($from_date) && !empty($to_date)){
                $where['date >= '] = $from_date ;
                $where['date <= '] = $to_date ;
            }elseif(!empty($from_date) && empty($to_date)){
                $where['date'] = $from_date ;
            }elseif(empty($from_date) && !empty($to_date)){
                $where['date'] = $to_date ;
            }
            $data['from_date'] = $from_date ;
            $data['to_date'] = $to_date ;
            $data['doctor_id'] = $doctor_id;
            $data['values'] = $this->Common_model->findAll('create_bill',$where,'record_id','asc');

            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_honorarium/appointment_honorarium', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    // public function change_test_invoice_payment_status($record_id){
    //     $bill = $this->Common_model->findById('create_bill',array('record_id'=>$record_id));
    //     if(isset($bill)){
    //         $payment_status = '';
    //         if($bill->test_invoice_payment_status == 'Paid'){
    //             $payment_status = 'Unpaid';
    //         }else{
    //             $payment_status = 'Paid' ;
    //         }
    //         $this->Common_model->updateData('create_bill',array('test_invoice_payment_status'=>$payment_status),array('record_id'=>$record_id)) ;
    //         $this->session->set_flashdata('message',UPDATE_MSG);
    //     }else{
    //         $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
    //     }
    //     redirect($_SERVER['HTTP_REFERER']);
    // }   
    
    public function change_test_invoice_payment_status($record_id){
        $bill = $this->Common_model->findById('create_bill',array('record_id'=>$record_id));
        if(isset($bill)){
            $payment_status = '';
            if($bill->test_invoice_payment_status == 'Paid'){
                $payment_status = 'Unpaid';
                $test_invoice_payment_date = NULL;
            }else{
                $payment_status = 'Paid' ;
                $test_invoice_payment_date = date("Y-m-d");
            }
           // var_dump($payment_status);die;
            $this->Common_model->updateData('create_bill',array('test_invoice_payment_status'=>$payment_status, 'test_invoice_payment_date' => $test_invoice_payment_date),array('record_id'=>$record_id)) ;
            $this->session->set_flashdata('message',UPDATE_MSG);
        }else{
            $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
        }
      //  redirect('test_honorarium', 'refresh');
        redirect($_SERVER['HTTP_REFERER']);
    } 
    public function change_doctor_visit_payment_status($record_id){
        $bill = $this->Common_model->findById('create_bill',array('record_id'=>$record_id));
        if(isset($bill)){
            $payment_status = '';
            if($bill->doctor_visit_payment_status == 'Paid'){
                $payment_status = 'Unpaid';
                $doctor_visit_payment_date = NULL;
            }else{
                $payment_status = 'Paid' ;
                $doctor_visit_payment_date = date("Y-m-d");
            }
            $this->Common_model->updateData('create_bill',array('doctor_visit_payment_status'=>$payment_status, 'doctor_visit_payment_date' => $doctor_visit_payment_date),array('record_id'=>$record_id)) ;
            $this->session->set_flashdata('message',UPDATE_MSG);
        }else{
            $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
        }
       // redirect('test_honorarium/appointment', 'refresh');
        redirect($_SERVER['HTTP_REFERER']);
    }
}
