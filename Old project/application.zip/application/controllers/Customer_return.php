<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Customer_return extends MY_Controller {

    private $type;
    private $tBUrl;

  public function __construct() {
    parent::__construct();
    $this->loadModel('CustomerReturn_model');
    $this->title    = 'Customer Return';
    $this->bUrl     = 'customer_return';
    $this->tBUrl    = $this->bUrl.'?type='.$this->type;

    $this->load->model(['SalesOrder_model'=>'soM']);
  }


   public function index()
    {
        $this->data = [
            'title'     => $this->title.' List',
            'values'    => $this->model->order_by('return_id', 'DESC')->where(["status"=>"Active"])->all(),
            'type'      => $this->type
        ];
        
        $this->render('admin/customer_return/index');
    }

    public function create()
    {


      $this->data = [
       'title'      => $this->title,
			 'type'      	=> $this->type,
			 'invoices'		=> $this->soM->order_by('sales_id', 'DESC')->where(["status != "=>"Delete"])->all()
        ];
		
        $this->render('admin/customer_return/create');
    }

  public function saveOrUpdate()
  {
      $input			  = $this->input->post();
      $update_id		= $input['update_id'];
			$date 			  = $input['return_date'];
			$prefix       = date('Ymd', strtotime($date));
      $order_qtys   = $input['order_qty'];
      $total_order_qty = array_sum($order_qtys);
      $input['total_order_qty'] = $total_order_qty ;

      $this->db->trans_start();
      if($update_id){
          $requrnQuery       	  = $this->model->select_max('return_no')->where('prefix', $prefix)->first();
          $return_no          	= (int) ($requrnQuery->return_no ?? 0) + 1;
          $input['return_no'] 	= $return_no;
      }
      $input['prefix']    = $prefix;

      $data   = $this->model->filterTableData($input);
      
      $id     = $this->model->updateOrInsert($data, $update_id);


      foreach ($input['product_id'] as $key => $value) {
        
        if( $input['return_qty'][$key] >0){
          $returnDetails = [
                'return_id'             => $id,
                'return_date'           => $date,
                'sales_order_id'        => $input['sales_order_id'][$key],
                'sales_order_details_id'=> $input['sales_order_details_id'][$key],
                'return_type'           => $input['item_return_type'][$key],
                'product_id'            => $value,
                'unit_id'               => $input['unit_id'][$key],
                'unit_name'             => $input['unit_name'][$key],
                'sales_price'           => $input['sales_price'][$key],
                'return_price'          => $input['return_price'][$key],
                'order_qty'             => $order_qtys[$key],
                'return_qty'            => $input['return_qty'][$key],
                'vat_amount'            => $input['vat_amount'][$key],
                'discount_per_product'  => $input['discount_per_product'][$key],
                'discount_amount'       => $input['discount_amount'][$key],
                'sub_total'             => $input['sub_total'][$key],
                'net_total'             => $input['net_total'][$key],
                'return_amount'         => $input['return_amount'][$key],
                'purchase_price'        => $input['purchase_price'][$key],
          ];

            $detailId = $this->Common_model->saveData('customer_return_details',$returnDetails);
            $this->updateStock($value, $order_qtys[$key], $date, $detailId, $input['purchase_price'][$key], $input['sales_price'][$key]);
        }

      }

      $this->db->trans_complete();

      $this->crudAlertMessage($update_id, $this->tBUrl); 
  }




  public function load_invoice_products(){
    $sales_id = $this->input->post('sales_id');
    
    $data['value'] = $this->Common_model->findById('sales_orders',array('sales_id'=>$sales_id));
    $data['customer'] = $this->Common_model->findById('patient',array('record_id'=>$data['value']->customer_id));

    $where = array('sales_order_details.sales_order_id '=>$sales_id);
    $options = array(
      'joins' => array(
        array(
          'table' => 'product_name',
          'condition' => 'product_name.record_id = sales_order_details.product_id',
          'jointype' => 'LEFT'
        ),
        array(
          'table' => 'generic_names',
          'condition' => 'generic_names.record_id = product_name.product_category_generic_name_id',
          'jointype' => 'LEFT'
        ),
        array(
          'table' => 'units',
          'condition' => 'units.record_id = sales_order_details.unit_id',
          'jointype' => 'LEFT'
        ),

      ),
      'select' => 'sales_order_details.*,product_name.product_name,product_name.product_category,units.unit_short_name,generic_names.generic_name',
      'where' => $where,
      'order' => array(
        'sales_order_details.sales_order_details_id' => 'asc',
      ),
    );
    $data['values'] = $this->Common_model->commonJoins("sales_order_details", $options);
    // dd(  $data['values'] );

    $this->load->view('admin/customer_return/product_list',$data);
  }

  public function delete($id) {

    $this->deleteStock($id);
		$this->model->getDelete($id, 'return_id');
		$this->Common_model->delete_info('return_id', $id, 'customer_return_details');
		$this->crudAlertMessage($id, $this->tBUrl, true); 
  }

  public function view($id)
	{
		$value = $this->model->find($id);
		 $this->data = [
      'title'       => $this->title.' Invoice',
      'type'      	=> $this->type,
      'value'		    => $value,
      'values'    	=> $this->Common_model->findAll('customer_return_details',array('return_id'=>$id),'return_details_id','asc'),
      'redirect'    => base_url($this->bUrl.'/create?type='. $this->type)
    ];

    $this->render('admin/customer_return/view');

	}

  public function delete_sales_return_stock($id)
	{
	$return_details = $this->Common_model->findAll('customer_return_details',array('return_id'=>$id),'return_details_id','asc');
			foreach($return_details as $detail){
				$stock_info = $this->Common_model->findById('drug_medicine', array('record_id' => $detail->product_id));
				$new_stock = $stock_info->product_stock-$detail->return_qty;
				$this->Common_model->updateData('drug_medicine', array('product_stock' => $new_stock), array('record_id' => $stock_info->record_id));

				$stock_history = $this->Common_model->findById('product_stock_history', array('product_id' => $stock_info->record_id, 'stock_date' =>$detail->return_date));
					$history = array(
						'stock_qty' => $new_stock,
						'sales_return_qty' => $stock_history->sales_return_qty-$detail->return_qty
					);
					$this->Common_model->updateData('product_stock_history', $history, array('record_id' => $stock_history->record_id));

			}
    }

  private function updateStock($product_id, $qty, $date, $detailId, $price=0, $salePrice=0){
		updateStock($product_id,$detailId, $qty, $date,'sales_return',$price, $salePrice);
	}

	private function deleteStock($id){
		$purchase_order_details = $this->Common_model->findAll('customer_return_details',['return_id'=>$id, 'return_type'=>'Medicine'],'return_details_id','asc');
		foreach($purchase_order_details as $detail){
			deleteStock($detail->return_details_id, $detail->product_id, 'sales_return');
		}
		
	}

}
