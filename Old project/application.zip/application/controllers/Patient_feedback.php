<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Patient_feedback extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
        
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Insert Patient Feedback';
            $data['page_title'] = 'Insert Patient Feedback';
            $data['info_header'] = 'Patient Feedback List';
            $data['values'] = $this->Common_model->findAll('patient_feedback',array(),'record_id','desc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/patient_feedback/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }    
   
    public function saveOrUpdatePatientFeedback() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            unset($input['update_id']);
            $popup = $this->input->post('popup');
            if(isset($popup)){
                unset($input['popup']);
            }
            $record_id = 0 ; 
            if($update_id == 0 || empty($update_id)){     
                $insert = $this->Common_model->saveData('patient_feedbacks', $input);
                $record_id = $insert ;
                $update_id = $insert ;
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $record_id = $update_id ;
                $update = $this->Common_model->updateData('patient_feedbacks', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
        if(isset($popup)){
                $patient_feedback = $this->Common_model->findById('patient_feedbacks',array('record_id'=>$record_id));
                echo json_encode($patient_feedback);
                exit;
            }    
            redirect('patient_feedback');
            
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $id, 'patient_feedback')){
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
           // redirect("crud/previousPage");
            redirect('patient_feedback', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
