<?php

/**
 * 
 */
class Expenditure extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		$data['title'] = 'Indoor Expenditure List';
		$data['page_title'] = 'Indoor Expenditure List';
		$data['info_header'] = 'Indoor Expenditure Liste';
		$where = array();
		//  $where['patient_status'] = 'New';
		if (!admin()) {
			$where['show_hide'] = 'Show';
		  }
		$data['values'] = $this->Common_model->findAll('operation_expenditure', $where, 'record_id', 'desc');
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/expenditure/index', $data);
		$this->load->view('admin/layouts/footer');
	}
	public function create()
	{
		$data['title'] = 'Indoor Expenditure';
		$data['page_title'] = 'Indoor Expenditure';
		$data['info_header'] = '';
		$where = array() ;
		$data['admissionInvoice'] = $this->Common_model->findAll("admission_fee_invoice",$where,"record_id","desc");

		$this->load->view('admin/layouts/header');
		$this->load->view('admin/expenditure/create', $data);
		$this->load->view('admin/layouts/footer');
	}
	public function edit($record_id)
	{
		$data['title'] = 'Edit Indoor Expenditure';
		$data['page_title'] = 'Edit Indoor Expenditure';
		$data['info_header'] = '';
		$data['value'] = $this->Common_model->findById('operation_expenditure', array('record_id' => $record_id));
		$data['values'] = $this->Common_model->findAll('operation_expenditure_details', array('operation_expendture_id' => $record_id),"record_id","asc");
		$data['patient'] = $this->Common_model->findById('patient', array('record_id' => $data['value']->patient_id));
		$where = array() ;
		$where['record_id'] = $data['value']->admission_id ;
		$data['admissionInvoice'] = $this->Common_model->findAll("admission_fee_invoice",$where,"record_id","desc");
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/expenditure/create', $data);
		$this->load->view('admin/layouts/footer');
	}
	public function saveOrUpdate()
	{
		$input = $_POST;
		$update_id = $input['update_id'];
		$expenditure_date = $input['expenditure_date'];
		$admission_id = $input['admission_id'];
		$patient_id = $input['patient_id'];
		unset($input['update_id']);
		$record_ids = array();
		$expenditure_ids = array();
		$expenditure_rates = array();
		$no_of_qtys = array();
		$total_amounts = array();
		if (array_key_exists('record_id', $input)) {
			$record_ids = $input['record_id'];
			$expenditure_ids = $input['expenditure_id'];
			$expenditure_rates = $input['expenditure_rate'];
			$no_of_qtys = $input['no_of_qty'];
			$total_amounts = $input['total_amount'];
			unset($input['record_id']);
			unset($input['expenditure_id']);
			unset($input['expenditure_rate']);
			unset($input['no_of_qty']);
			unset($input['total_amount']);
		}
		$total_amount = array_sum($total_amounts);
		$input['total_amount'] = $total_amount;
		if ($update_id == 0 || empty($update_id)) {
			$insert = $this->Common_model->saveData('operation_expenditure', $input);
			foreach ($record_ids as $key => $value) {
				$details = array(
					'operation_expendture_id' => $insert,
					'expenditure_date' => $expenditure_date,
					'admission_id' => $admission_id,
					'patient_id' => $patient_id,
					'expenditure_id' => $expenditure_ids[$key],
					'expenditure_rate' => $expenditure_rates[$key],
					'no_of_qty' => $no_of_qtys[$key],
					'total_amount' => $total_amounts[$key],
				);
				$this->Common_model->saveData('operation_expenditure_details', $details);
			}
			$update_id = $insert;
			if ($insert) {
				$this->session->set_flashdata('message', INSERT_MSG);
			} else {
				$this->session->set_flashdata('message', INSERT_ERROR_MSG);
			}
		} else {
			$update = $this->Common_model->updateData('operation_expenditure', $input, array('record_id' => $update_id));
			if ($update) {
				foreach ($record_ids as $key => $value) {
					$details = array(
						'operation_expendture_id' => $update_id,
						'expenditure_date' => $expenditure_date,
						'admission_id' => $admission_id,
						'patient_id' => $patient_id,
						'expenditure_id' => $expenditure_ids[$key],
						'expenditure_rate' => $expenditure_rates[$key],
						'no_of_qty' => $no_of_qtys[$key],
						'total_amount' => $total_amounts[$key],
					);
					if ($value) {
						$this->Common_model->updateData('operation_expenditure_details', $details,array('record_id'=>$value));
					} else {
						$this->Common_model->saveData('operation_expenditure_details', $details);
					}
				}
				$this->session->set_flashdata('message', UPDATE_MSG);
			} else {
				$this->session->set_flashdata('message', UPDATE_ERROR_MSG);
			}
			//redirect("expenditure/view2/$update_id");
		}
		redirect("expenditure");
	}

	public function view($record_id)
	{
		$data['title'] = 'View Indoor Expenditure';
		$data['page_title'] = 'View Indoor Expenditure';
		$data['info_header'] = '';
		$data['redirect'] =  base_url('expenditure/create');
		$data['value'] = $this->Common_model->findById('operation_expenditure', array('record_id' => $record_id));
		$data['values'] = $this->Common_model->findAll('operation_expenditure_details', array('operation_expendture_id' => $record_id),"record_id","asc");
		$data['patient'] = $this->Common_model->findById('patient', array('record_id' => $data['value']->patient_id));
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/expenditure/view', $data);
		$this->load->view('admin/layouts/footer');
	}
	public function view2($record_id)
	{
		$data['title'] = 'View Indoor Expenditure';
		$data['page_title'] = 'View Indoor Expenditure';
		$data['info_header'] = '';
		$data['redirect'] =  base_url('expenditure');
		$data['value'] = $this->Common_model->findById('operation_expenditure', array('record_id' => $record_id));
		$data['values'] = $this->Common_model->findAll('operation_expenditure_details', array('operation_expendture_id' => $record_id),'record_id','asc');
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/expenditure/view', $data);
		$this->load->view('admin/layouts/footer');
	}

	public function delete($id)
	{
		$user_type = $this->session->ses_user_type;
		if ($user_type == "admin"  || $user_type == "staff") {
			if ($this->Common_model->delete_info('record_id', $id, 'operation_expenditure')) {
				$this->session->set_flashdata('message', DELETE_MSG);
			} else {
				$this->session->set_flashdata('message', DELETE_ERROR_MSG);
			}
			redirect('expenditure', 'refresh');
		} else {
			$data['wrong_msg'] = "";
			$this->load->view('website/login_check', $data);
		}
	}
}
