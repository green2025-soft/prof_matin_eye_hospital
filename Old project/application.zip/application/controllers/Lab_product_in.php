<?php

defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Lab_product_in extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
    }
    public function index()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'All Product In';
            $data['page_title'] = 'Product In';
            $data['info_header'] = 'All Product In';

            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            if (!isset($from_date) && !isset($to_date)) {
                $from_date = $to_date = date('Y-m-d');
            }
            $where = array();
            if (!admin()) {
                $where['show_hide'] = 'Show';
            }
            if (!empty($from_date) && !empty($to_date)) {
                $where['in_date >= '] = $from_date;
                $where['in_date <= '] = $to_date;
            } elseif (!empty($from_date) && empty($to_date)) {
                $where['in_date'] = $from_date;
            } elseif (empty($from_date) && !empty($to_date)) {
                $where['in_date'] = $to_date;
            }
            $data['values'] = $this->Common_model->findAll("lab_product_in", $where, "record_id", "desc");
            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/lab_product_in/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function create()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Product In';
            $data['page_title'] = 'Product In';
            $data['info_header'] = 'All Product In';
            $data['in_values'] = $this->Common_model->findAll('lab_product_in', array(), 'record_id', 'desc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/lab_product_in/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function edit($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Product In';
            $data['page_title'] = 'Product In';
            $data['info_header'] = 'All Product In';
            $data['value'] = $this->Common_model->findById('lab_product_in', array('record_id' => $record_id));
            $data['supplier'] = $this->Common_model->findById('suppliers', array('record_id' => $data['value']->supplier_id));
            $data['values'] = $this->Common_model->findAll('lab_product_in_details', array('lab_product_in_id' => $record_id), 'record_id', 'asc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/lab_product_in/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function view($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Product In';
            $data['page_title'] = 'Product In';
            $data['info_header'] = 'All Product In';
            $data['redirect'] = base_url('lab_product_in/create');
            $data['signatureType'] = "Staff";
            $data['value'] = $this->Common_model->findById('lab_product_in', array('record_id' => $record_id));
            $data['supplier'] = $this->Common_model->findById('suppliers', array('record_id' => $data['value']->supplier_id));
            $data['values'] = $this->Common_model->findAll('lab_product_in_details', array('lab_product_in_id' => $record_id), 'record_id', 'asc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/lab_product_in/invoice', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function view2($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Product In';
            $data['page_title'] = 'Product In';
            $data['info_header'] = 'All Product In';
            $data['redirect'] = base_url('lab_product_in');
            $data['signatureType'] = "Staff";
            $data['value'] = $this->Common_model->findById('lab_product_in', array('record_id' => $record_id));
            $data['supplier'] = $this->Common_model->findById('suppliers', array('record_id' => $data['value']->supplier_id));
            $data['values'] = $this->Common_model->findAll('lab_product_in_details', array('lab_product_in_id' => $record_id), 'record_id', 'asc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/lab_product_in/invoice', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST;
            $update_id = $input['update_id'];
           // $purchase_request_id = $input['purchase_request_id'];
            $record_ids = $input['record_id'];
            $product_ids = $input['product_id'];
            $quantitys = $input['quantity'];
            $unit_prices = $input['unit_price'];
            $total_prices = $input['total_price'];
            $category_id = $input['category_id'] ;

            unset($input['update_id']);
            unset($input['record_id']);
            unset($input['product_id']);
            unset($input['quantity']);
            unset($input['unit_price']);
            unset($input['total_price']);
            unset($input['product_category']);
            unset($input['category_id']);

            $in_date = $input['in_date'];

            $prefix = str_replace('-', '', $in_date);

            $max = $this->Common_model->findMax('lab_product_in', array('prefix' => $prefix), 'in_no');
            $in_no = isset($max) ? $max->in_no + 1 : 1;

            $input['prefix'] = $prefix;
            $input['in_no'] = $in_no;

            if ($update_id == 0 || empty($update_id)) {
                $insert = $this->Common_model->saveData('lab_product_in', $input);
                //$this->Common_model->updateData('purchase_request', array('status' => "Purchase"), array('record_id' => $purchase_request_id));
               // $this->Common_model->updateData('purchase_request_details', array('status' => "Purchase"), array('purchase_request_id' => $purchase_request_id));
                if ($insert) {
                    foreach ($record_ids as $key => $value) {
                        $data = array(
                           // 'purchase_request_id' => $purchase_request_id,
                            'lab_product_in_id' => $insert,
                            'in_date' => $in_date,
                            'product_id' => $product_ids[$key],
                            'quantity' => $quantitys[$key],
                            'unit_price' => $unit_prices[$key],
                            'total_price' => $total_prices[$key],
                            'category_id'=>$category_id[$key]
                        );
                        $this->Common_model->saveData('lab_product_in_details', $data);
                    }
                    $this->session->set_flashdata('message', INSERT_MSG);
                } else {
                    $this->session->set_flashdata('message', INSERT_ERROR_MSG);
                }
            } else {
                $info = $this->Common_model->findById('lab_product_in', array('record_id' => $update_id));
                if ($info->in_date == $in_date) {
                    $input['in_no'] = $info->in_no;
                }
                $update = $this->Common_model->updateData('lab_product_in', $input, array('record_id' => $update_id));
                if ($update) {
                    foreach ($record_ids as $key => $value) {
                        $data = array(
                           // 'purchase_request_id' => $purchase_request_id,
                            'lab_product_in_id' => $update_id,
                            'in_date' => $in_date,
                            'product_id' => $product_ids[$key],
                            'quantity' => $quantitys[$key],
                            'unit_price' => $unit_prices[$key],
                            'total_price' => $total_prices[$key],
                            'category_id'=>$category_id[$key]
                        );
                        if ($value) {
                            $this->Common_model->updateData('lab_product_in_details', $data, array('record_id' => $value));
                        } else {
                            $this->Common_model->saveData('lab_product_in_details', $data);
                        }
                    }

                    $this->session->set_flashdata('message', UPDATE_MSG);
                } else {
                    $this->session->set_flashdata('message', UPDATE_ERROR_MSG);
                }
            }
            redirect('lab_product_in', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function in_out()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Product In/Out';
            $data['page_title'] = 'Product In/Out';
            $data['info_header'] = 'All Product In/Out';

            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $product_id = $this->input->get('product_id');
            $transaction_type = $this->input->get('transaction_type');

            $where = array();

            if (!isset($from_date) && !isset($to_date) && !isset($product_id) && !isset($transaction_type)) {
                $where['date'] = date('Y-m-d');
            }

            if ($product_id) $where['record_id'] = $product_id;

            if (!empty($from_date) && !empty($to_date)) {
                $where['date >= '] = $from_date;
                $where['date <= '] = $to_date;
            } elseif (!empty($from_date) && empty($to_date)) {
                $where['date'] = $from_date;
            } elseif (empty($from_date) && !empty($to_date)) {
                $where['date'] = $to_date;
            }

            $data['values'] = $this->Common_model->findAllGroupBySum('lab_product_use_in', $where, 'product_id', 'qty');
            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;
            $data['product_id'] = $product_id;
            $data['transaction_type'] = $transaction_type;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/lab_product/in_out', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            $lab_product_id = $this->Common_model->findById('lab_product_in', array('record_id' => $id));
            if ($this->Common_model->delete_info('record_id', $id, 'lab_product_in')) {
                $this->Common_model->delete_info('lab_product_in_id', $id, 'lab_product_in_details');
                $this->Common_model->updateData('purchase_request', array('status' => "Approved"), array('record_id' => $lab_product_id->purchase_request_id));
                $this->Common_model->updateData('purchase_request_details', array('status' => "Approved"), array('purchase_request_id' => $lab_product_id->purchase_request_id));
                $this->session->set_flashdata('message', DELETE_MSG);
            } else {
                $this->session->set_flashdata('message', DELETE_ERROR_MSG);
            }
            redirect('lab_product_in', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function load_products()
    {
        $purchase_request_id = $this->input->post('purchase_request_id');
        $data['value'] = $this->Common_model->findById('purchase_request', array('record_id' => $purchase_request_id));
        $data['values'] = $this->Common_model->findAll('purchase_request_details', array('purchase_request_id' => $purchase_request_id), "record_id", "asc");
        $this->load->view("admin/lab_product_in/product_list", $data);
    }

    public function approved($record_id)
    {
        $bill = $this->Common_model->findById('lab_product_in', array('record_id' => $record_id));
        if (isset($bill)) {
            $status = '';
            if ($bill->approval == 'Unpaid') {
                $status = 'paid';
            } else {
                $status = 'Unpaid';
            }
            $this->Common_model->updateData('lab_product_in', array('approval' => $status), array('record_id' => $record_id));
            $this->Common_model->updateData('lab_product_in_details', array('approval' => $status), array('purchase_request_id' => $record_id));
            $this->session->set_flashdata('message', UPDATE_MSG);
        } else {
            $this->session->set_flashdata('message', UPDATE_ERROR_MSG);
        }
        // redirect('test_honorarium/appointment', 'refresh');
        redirect($_SERVER['HTTP_REFERER']);
    }
}
