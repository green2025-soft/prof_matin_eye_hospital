<?php

/**
 * 
 */
class Operation_payment extends CI_Controller
{
	
	public function __construct()
	{
		parent::__construct();
	}
	public function index(){
		$data['title'] = "Operation Payment List";
		$data['page_title'] = "Operation Payment List";
		$data['info_header'] = "";


		$from_date = $this->input->get('from_date');
		$to_date = $this->input->get('to_date');
		$doctor_id = $this->input->get('doctor_id');
		$anesthesia_id = $this->input->get('anesthesia_id');
		$reference_by = $this->input->get('reference_by');

		$where = array() ;
		if (!admin()) {
			$where['operation_details.show_hide'] = 'Show';
		}
		if($doctor_id) $where['doctor_id'] = $doctor_id;
		if($anesthesia_id) $where['anesthesia_id'] = $anesthesia_id ;
		if($reference_by) $where['reference_by'] = $reference_by ;
		if(!empty($from_date) && !empty($to_date)){
			$where['operation_date >= '] = $from_date;
			$where['operation_date <= '] = $to_date;
		}elseif (!empty($from_date) && empty($to_date)) {
			$where['operation_date'] = $from_date;
		}elseif (empty($from_date) && !empty($to_date)) {
			$where['operation_date'] = $to_date;
		}
		$options = array(
			'joins' => array(
				array(
					'table' => 'patient',
					'condition' => 'patient.record_id = operation_details.patient_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor sergeon',
					'condition' => 'sergeon.record_id = operation_details.doctor_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor anesthesia',
					'condition' => 'anesthesia.record_id = operation_details.anesthesia_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation sergeon_designation',
					'condition' => 'sergeon_designation.record_id = sergeon.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'designation anesthesia_designation',
					'condition' => 'anesthesia_designation.record_id = anesthesia.designation_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_category',
					'condition' => 'operation_category.record_id = operation_details.category_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_name',
					'condition' => 'operation_name.record_id = operation_details.operation_id',
					'jointype' => 'LEFT'
				),array(
					'table' => 'beds',
					'condition' => 'beds.record_id = operation_details.bed_id',
					'jointype' => 'LEFT'
				),
			),
			'select' => 'operation_details.*,operation_details.record_id as operation_details_id,operation_details.advance_amount as adv_amount,patient.*,patient.record_id as patient_id,sergeon.record_id as sergeon_id,sergeon.name as sergeon_name,sergeon_designation.designation as sergeon_designation,anesthesia.record_id as anesthesia_id,anesthesia.name as anesthesia_name,anesthesia_designation.designation as anesthesia_designation,operation_category.record_id as operation_category_id,operation_category.category_name,operation_name.record_id as operation_name_id,operation_name.operation_name,beds.*',
			'where' => $where,
			'order' => array(
				'operation_details.record_id' => 'desc',
			),
		);
		$data['values'] = $this->Common_model->commonJoins("operation_details", $options);
		$data['doctor_id'] = $doctor_id;
		$data['anesthesia_id'] = $anesthesia_id;
		$data['reference_by'] = $reference_by;
		$data['from_date'] = $from_date;
		$data['to_date'] = $to_date ;
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/operation_payment/index',$data);
		$this->load->view('admin/layouts/footer');	
	}

	public function create(){
		$data['title'] = "Add Operation Details";
		$data['page_title'] = "Add Operation Details";
		$data['info_header'] = "";
		$admission_invoices = $this->Common_model->findAll('admission_fee_invoice',array('patient_status'=>'Admitted'),'record_id','asc');
		$patient_ids = array() ;
		foreach ($admission_invoices as $key1 => $value1) {
			$patient_ids[] = $value1->patient_id ;
		}
		$data['patient_list'] = $this->Common_model->findAllWhereIn('patient',array(),$patient_ids,'record_id','record_id','asc') ;
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/operation_bill/create',$data);
		$this->load->view('admin/layouts/footer');		
	}


	public function edit($record_id){
		$data['title'] = "Edit Operation Details";
		$data['page_title'] = "Edit Operation Details";
		$data['info_header'] = "";
		$admission_invoices = $this->Common_model->findAll('admission_fee_invoice',array('patient_status'=>'Admitted'),'record_id','asc');
		foreach ($admission_invoices as $key1 => $value1) {
			$patient_ids[] = $value1->patient_id ;
		}
		$data['patient_list'] = $this->Common_model->findAllWhereIn('patient',array(),$patient_ids,'record_id','record_id','asc') ;
		$data['value'] = $this->Common_model->findById('operation_details',array('record_id'=>$record_id)) ;

		//var_dump($data['value']);die;
		$data['bed'] = $this->Common_model->findById('beds',array('record_id'=>$data['value']->bed_id)) ;

		$data['expenditures'] = $this->Common_model->findAll('operation_equipment',array('operation_details_id'=>$record_id),'record_id','asc');
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/operation_bill/create',$data);
		$this->load->view('admin/layouts/footer');		
	}

	public function view($record_id){
		$data['title'] = "Edit Operation Details";
		$data['page_title'] = "Edit Operation Details";
		$data['info_header'] = "";
		
	//	$data['value'] = $this->Common_model->findById('operation_details',array('record_id'=>$record_id)) ;

	//	$data['bed'] = $this->Common_model->findById('beds',array('record_id'=>$data['value']->bed_id)) ;

		$data['equipments'] = $this->Common_model->findAll('operation_equipment',array('operation_details_id'=>$record_id),'record_id','asc');


		$where = array('operation_details.record_id'=>$record_id);
		$options = array(
			'joins' => array(
				array(
					'table' => 'patient',
					'condition' => 'patient.record_id = operation_details.patient_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor sergeon',
					'condition' => 'sergeon.record_id = operation_details.doctor_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor anesthesia',
					'condition' => 'anesthesia.record_id = operation_details.anesthesia_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_category',
					'condition' => 'operation_category.record_id = operation_details.category_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_name',
					'condition' => 'operation_name.record_id = operation_details.operation_id',
					'jointype' => 'LEFT'
				),array(
					'table' => 'beds',
					'condition' => 'beds.record_id = operation_details.bed_id',
					'jointype' => 'LEFT'
				),
			),
			'select' => 'operation_details.*,operation_details.record_id as operation_details_id,patient.*,patient.record_id as patient_id,sergeon.record_id as sergeon_id,sergeon.name as sergeon_name,sergeon.designation as sergeon_designation,anesthesia.record_id as anesthesia_id,anesthesia.name as anesthesia_name,anesthesia.designation as anesthesia_designation,operation_category.record_id as operation_category_id,operation_category.category_name,operation_name.record_id as operation_name_id,operation_name.operation_name,beds.*',
			'where' => $where,
			'order' => array(
				'operation_details.record_id' => 'desc',
			),
		);
		$data['value'] = $this->Common_model->commonJoinsRow("operation_details", $options);

		$data['bill'] = $this->Common_model->findById('create_bill',array('record_id'=>$data['value']->invoice_id));
		$data['signatureType'] = 'Patient';
		$data['redirect'] = base_url('operation_bill') ;

		$this->load->view('admin/layouts/header');
		$this->load->view('admin/operation_bill/view',$data);
		$this->load->view('admin/layouts/footer');		
	}

	public function get_admissiom(){
		$admission_id = $this->input->post('admission_id') ;
		$where = array('operation_invoice.record_id'=>$admission_id);
		$options = array(
			'joins' => array(
				array(
					'table' => 'patient',
					'condition' => 'patient.record_id = operation_invoice.patient_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor sergeon',
					'condition' => 'sergeon.record_id = operation_invoice.sergeon_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'doctor anesthesia',
					'condition' => 'anesthesia.record_id = operation_invoice.anesthesia_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_category',
					'condition' => 'operation_category.record_id = operation_invoice.operation_category_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'operation_name',
					'condition' => 'operation_name.record_id = operation_invoice.operation_name_id',
					'jointype' => 'LEFT'
				),array(
					'table' => 'beds',
					'condition' => 'beds.record_id = operation_invoice.bed_id',
					'jointype' => 'LEFT'
				),
			),
			'select' => 'operation_invoice.*,operation_invoice.record_id as operation_invoice_record_id,patient.*,patient.record_id as patient_id,sergeon.record_id as sergeon_id,sergeon.name as sergeon_name,sergeon.designation as sergeon_designation,anesthesia.record_id as anesthesia_id,anesthesia.name as anesthesia_name,anesthesia.designation as anesthesia_designation,operation_category.record_id as operation_category_id,operation_category.category_name,operation_name.record_id as operation_name_id,operation_name.operation_name,beds.*',
			'where' => $where,
			'order' => array(
				'operation_invoice.record_id' => 'asc',
			),
		);
		$admission = $this->Common_model->commonJoinsRow("operation_invoice", $options);

		$advance_amount = $this->Common_model->calCulateSum('admission_fee_invoice',array('patient_id'=>$admission->patient_id),'advance_amount');
		$admission->advance_amount = $advance_amount ;

		$medicine_cost = $this->Common_model->calCulateSum('sales_orders',array('customer_id'=>$admission->patient_id,'sales_from'=>'Requisition','requisition_status'=>'Delivered'),'grand_net_total');
		$admission->medicine_cost = isset($medicine_cost)?$medicine_cost:0 ;




	//	$paid_amount = $this->Common_model->calCulateSum('create_bill',array('patient_id'=>$admission->patient_id,'type'=>'Collection'),'paid');
		//$balance = 

		echo json_encode($admission);
		exit;
	}

	public function getOperationName(){
		$category_id = $this->input->post('category_id');
		$names = $this->Common_model->get_all_info_by_array('operation_name',['category_id' => $category_id]);
		$data = "<option value=''>-- Select --</option>";
		foreach($names as $name){
			$data .= "<option value='$name->record_id'>$name->operation_name</option>";	
		}                              
		echo json_encode($data);
	}

	public function saveOrUpdate(){
		$input = $_POST ;
		//var_dump($input);die;
		$update_id = $input['update_id'];
		$operation_date = $input['operation_date'];
		$expenditure_ids = array() ;
		$expenditure_prices = array() ;
		if(array_key_exists('expenditure_id', $input)){
			$expenditure_ids = $input['expenditure_id'];
			$expenditure_prices = $input['expenditure_price'];
			unset($input['expenditure_id']);
			unset($input['expenditure_price']);
		}
		
		unset($input['update_id']);
		
		
	//	var_dump($input);die;
		

		$prefix = 'Ope'. date("Ymd",strtotime($operation_date));
		$maxInvoice = $this->Common_model->findMax('create_bill',array('prefix'=>$prefix,'type'=>'Operation'),'invoice_no');
		$invoice_no = isset($maxInvoice)?$maxInvoice->invoice_no + 1 : 1 ;

		$paid = $input['paid_amount'];
		$medicine_cost = $input['medicine_cost'] ;
		if($paid > $medicine_cost){
			$paid = $paid - $medicine_cost ;
		}

		$invoice_data = array(
			'date' => $operation_date,
			'prefix' => $prefix,
			'invoice_no' => $invoice_no,
			'type' => 'Operation',
			'particular' => "Operation Details Information",
			'patient_id' => $input['patient_id'],
			'amount' => $input['payable_amount'],
			'sub_total' => $input['sub_total'],
			'paid' => $paid ,
			'medicine_cost' => $input['medicine_cost'],
			'due' => $input['due_amount'],
			'advance' => $input['advance_amount'],
			'return_amount' => $input['return_amount'],
		);

		if($update_id == 0 || empty($update_id)){
			$invoice_id = $this->Common_model->saveData('create_bill', $invoice_data);
			$input['invoice_id'] = $invoice_id ;
			$operation_details_id = $this->Common_model->saveData('operation_details', $input);
			$update_id = $operation_details_id ;
			$this->Common_model->updateData('operation_invoice', array('operation_status'=>'Complete'),array('record_id'=>$input['admission_id']));

			foreach ($expenditure_ids as $key => $value) {
				$ex = array(
					'operation_details_id'=> $operation_details_id ,
					'expenditure_id'=> $expenditure_ids[$key],
					'expenditure_price'=> $expenditure_prices[$key],
				);
				$this->Common_model->saveData('operation_equipment',$ex);
			}
			$this->session->set_flashdata('message',INSERT_MSG);
		}else{
			$operation_details = $this->Common_model->findById('operation_details',array('record_id'=>$update_id));
			if($operation_details->operation_date == $operation_date){
				$bill = $this->Common_model->findById('create_bill',array('record_id'=>$operation_details->invoice_id));
				$invoice_data['invoice_no'] = $bill->invoice_no ;
			}

			$this->Common_model->updateData('create_bill', $invoice_data,array('record_id'=>$operation_details->invoice_id));
			$this->Common_model->updateData('operation_details', $input,array('record_id'=>$update_id));
			$this->Common_model->delete_info('operation_details_id', $update_id, 'operation_equipment');
			foreach ($expenditure_ids as $key => $value) {
				$ex = array(
					'operation_details_id'=> $update_id ,
					'expenditure_id'=> $expenditure_ids[$key],
					'expenditure_price'=> $expenditure_prices[$key],
				);
				$this->Common_model->saveData('operation_equipment',$ex);
			}
			$this->session->set_flashdata('message',UPDATE_MSG);
		}
		
		redirect("operation_bill/view/$update_id");	
	}
	public function paid_unpaid($id){
		$user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            $operation_details = $this->Common_model->findById('operation_details',array('record_id'=>$id));
            if($operation_details->payment_status == 'Paid'){
                $payment_status = 'Unpaid';
            }else{
            	$payment_status = 'Paid';
            }
            $this->session->set_flashdata('message',UPDATE_MSG);
            $this->Common_model->updateData('operation_details',array('payment_status'=>$payment_status),array('record_id'=>$id));
            //redirect('operation_payment', 'refresh');
            redirect($_SERVER['HTTP_REFERER']);
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
	}
	public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            $operation_details = $this->Common_model->findById('operation_details',array('record_id'=>$id));
            if($this->Common_model->delete_info('record_id', $id, 'operation_details')){
                $this->Common_model->delete_info('record_id', $operation_details->invoice_id, 'create_bill') ;
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
            redirect('operation_bill', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
?>