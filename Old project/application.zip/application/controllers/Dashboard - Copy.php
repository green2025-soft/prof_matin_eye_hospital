<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Dashboard extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
    }
    public function index() {
        $this->load->model('Common_model');
        //Getting Counter Info        
        $this->load->model('Counter_model');
        $counter_value=$this->Counter_model->get_counter_value();
        foreach($counter_value as $value){
           $total=$value->count;
           if($total == 0){
                $this->Counter_model->update_counter_value(1);
                $sescounter = array('hit_counter' => $total);
                $this->session->set_userdata($sescounter);
           }
           else{
                $one_count=$total+1;
                $sescounter = array('hit_counter' => $total);
                $this->session->set_userdata($sescounter);
                $this->Counter_model->update_counter_value($one_count);
           } 
        } 
        $data['all_photo'] = $this->Common_model->get_all_info('photo_gallery');
        $data['all_value']=$this->Common_model->get_all_info('single_page_content');
        $data['serviceList']=$this->Common_model->get_all_info_limit('test_price',4);
        $this->load->view('website/header');
        $this->load->view('website/home', $data);
        $this->load->view('website/footer');
    }
    public function stock_shortage(){
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Product Name';
            $data['page_title'] = 'Product Name';
            $data['info_header'] = 'All Product Name Info.';

            $products = $this->Common_model->findAll('product_name',array(),'record_id','desc') ;

            $values = array();
            $balance = 0 ;
            $shortage = 0 ;
            $product_ids = array() ;
            foreach ($products as $key => $value) {
                $reorder_level = $value->reorder_level ;
                $balance = $this->Common_model->item_balance($value->record_id) ;
                if($balance <= $reorder_level){
                    ++$shortage;
                    $value->balance = $balance ;
                    $values[] = $value ;
                }
            }
            $data['values'] = $values ; 
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/dashboard/stock_shortage', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
