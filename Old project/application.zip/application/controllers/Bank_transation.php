<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Bank_transation extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->title    = 'Bank Transation';
        $this->bUrl     = 'bank_transation';

        $this->loadModel('BankTransation_model');

    }
        
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Bank/Partner Deposit & Withdraw List';
            $data['page_title'] = $data['title'];
            $data['info_header'] = $data['title'];
            $data['values'] = $this->Common_model->findAll('bank_transations',array(),'record_id','desc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/bank_transation/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function bank_statement() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Bank/Partner Statement';
            $data['page_title'] = $data['title'];
            $data['info_header'] = $data['title'];

            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $bank_id = $this->input->get('bank_id');
            $transation_type = $this->input->get('transation_type');
            $today = date('Y-m-d');
            $where = array() ;
            if(!isset($from_date) && !isset($to_date) && !isset($bank_id) && !isset($transation_type)){
                $where['record_id'] = -1 ;
            }

            

            $range = '' ;

            if(!empty($from_date) && !empty($to_date)){
                $where['date >= '] = $from_date ;
                $where['date <= '] = $to_date ;
                $range = $from_date . ' to '. $to_date ;
            }elseif(!empty($from_date) && empty($to_date)){
                $where['date'] = $from_date ;
                $range = $from_date  ;
            }elseif(empty($from_date) && !empty($to_date)){
                $where['date'] = $to_date ;
                $range = $to_date ;
            }


            if(!empty($bank_id)) $where['bank_id'] = $bank_id ;
            if(!empty($transation_type)) $where['transation_type'] = $transation_type ;
            
               //  var_dump($where);die;
            $data['values'] = $this->Common_model->findAll('bank_transations',$where,'record_id','asc') ;

            $openingBalance = 0;
            if ($from_date){
              $this->db->select("
                    COALESCE(SUM(
                        CASE
                            WHEN transation_type = 'Deposit' THEN amount
                            WHEN transation_type = 'Withdraw' THEN -amount
                            ELSE 0
                        END
                    ), 0) AS opening_balance
                ", false);

                $this->db->from('bank_transations');
                if ($bank_id){
                    $this->db->where('bank_id', $bank_id);
                }
                if ($transation_type){
                  $this->db->where('transation_type', $transation_type);  
                }
                $this->db->where('date <', $from_date);
            
                $query = $this->db->get();
                $openingBalance = $query->row()->opening_balance;
            }

            
           // var_dump($data['values']);die;
            $data['from_date'] = $from_date ;
            $data['to_date'] = $to_date ;
            $data['bank_id'] = $bank_id ;
            $data['range'] = $range ;
            $data['transation_type'] = $transation_type;
            $data['openingBalance'] = $openingBalance;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/bank_transation/statement', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }    
    public function create() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Bank/Partner Deposit & Withdraw';
            $data['page_title'] = $data['title'];
            $data['info_header'] = '';
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/bank_transation/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function edit($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Bank/Partner Deposit & Withdraw';
            
            $data['page_title'] = $data['title'];
            $data['info_header'] = '';
            $data['value'] = $this->Common_model->findById('bank_transations',array('record_id'=>$record_id));
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/bank_transation/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            unset($input['update_id']);
            if($update_id == 0 || empty($update_id)){     
                $insert = $this->Common_model->saveData('bank_transations', $input);
                $update_id = $insert ;
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $update = $this->Common_model->updateData('bank_transations', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            redirect('bank_transation/create', 'refresh');
            
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function view($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Create Ambulance Receipt';
            $data['page_title'] = 'Create Ambulance Receipt';
            $data['info_header'] = '';
            $data['signatureType'] = 'Patient';
            $data['redirect'] = base_url('ambulance_receipt/create');
            $data['value'] = $this->Common_model->findById('ambulance_receipts',array('record_id'=>$record_id));
            $data['patient'] = $this->Common_model->findById('patient',array('record_id'=>$data['value']->patient_id));
            $data['ambulance'] = $this->Common_model->findById('ambulance',array('record_id'=>$data['value']->ambulance_id));
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/ambulance_receipt/view', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    } 
    public function view2($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Create Ambulance Receipt';
            $data['page_title'] = 'Create Ambulance Receipt';
            $data['info_header'] = '';
            $data['signatureType'] = 'Patient';
            $data['redirect'] = base_url('ambulance_receipt');
            $data['value'] = $this->Common_model->findById('ambulance_receipts',array('record_id'=>$record_id));
            $data['patient'] = $this->Common_model->findById('patient',array('record_id'=>$data['value']->patient_id));
            $data['ambulance'] = $this->Common_model->findById('ambulance',array('record_id'=>$data['value']->ambulance_id));
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/ambulance_receipt/view', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function get_bank_account_balance(){
        $bank_id = $this->input->post('bank_id');
        $where = array();
        $where['bank_id'] = $bank_id ;
        $where['transation_type'] = 'Deposit' ;
        $deposit = $this->Common_model->calCulateSum('bank_transations',$where,'amount');
        $deposit_money = isset($deposit)?$deposit:0 ;

        $where = array();
        $where['bank_id'] = $bank_id ;
        $where['transation_type'] = 'Withdraw' ;
        $withdraw = $this->Common_model->calCulateSum('bank_transations',$where,'amount');
        $withdraw_money = isset($withdraw)?$withdraw:0 ;
        $balance = $deposit_money - $withdraw_money ;
        echo $balance;
        exit;
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            
            if($this->Common_model->delete_info('record_id', $id, 'bank_transations')){
                
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
            redirect('bank_transations', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
