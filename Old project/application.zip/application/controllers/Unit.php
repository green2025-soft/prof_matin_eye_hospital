<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Unit extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Unit';
            $data['page_title'] = 'Unit';
            $data['info_header'] = 'All Unit';
            $data['values'] = $this->Common_model->findAll('units',array(),'record_id','desc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/unit/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            unset($input['update_id']);
            $unit_short_name = $input['unit_short_name'];
            if($update_id == 0 || empty($update_id)){       
                $getRow = $this->Common_model->findById('units',array('unit_short_name'=>$unit_short_name));
                if(isset($getRow)){
                    $this->session->set_flashdata('message', EXIST_MSG);
                    redirect('unit', 'refresh');
                }
                $insert = $this->Common_model->saveData('units', $input);
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $update = $this->Common_model->updateData('units', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            redirect('unit', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $id, 'units')){
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
           // redirect("crud/previousPage");
            redirect('unit', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
