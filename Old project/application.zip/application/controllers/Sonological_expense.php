<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Sonological_expense extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Ultra (USG)  Expense List';
            $data['page_title'] = 'Ultra (USG) Expense List';
            $data['info_header'] = 'Ultra (USG) Expense List';

            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $doctor_id = $this->input->get('doctor_id');


            if(!isset($from_date) && !isset($to_date) && !isset($doctor_id)){
                $from_date = $to_date = date('Y-m-d');
            }

            $where = array() ;
            if($doctor_id) $where['doctor_id'] = $doctor_id ;
            if(!empty($from_date) && !empty($to_date)){
                $where['date >= '] = $from_date;
                $where['date <= '] = $to_date;
            }elseif(!empty($from_date) && empty($to_date)){
                $where['date'] = $from_date;
            }elseif(empty($from_date) && !empty($to_date)){
                $where['date'] = $to_date;
            }


            $data['values'] = $this->Common_model->findAll('sonologist',$where,'record_id','desc') ;
            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;
            $data['doctor_id'] = $doctor_id;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/sonological_expense/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function create($record_id = '') {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Ultra (USG) Expense';
            $data['page_title'] = 'Ultra (USG) Expense';
            $data['info_header'] = 'All Ultra (USG) Expense';
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/sonological_expense/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $doctor_id = $input['doctor_id'] ;
            $doctorObj = $this->Common_model->findById('doctor', array('record_id'=>$doctor_id));
            $input['doctor'] = $doctorObj->name.' - '.$doctorObj->designation ;
            $update_id = $input['update_id'] ;
            unset($input['update_id']);
            if($update_id == 0 || empty($update_id)){       
                $insert = $this->Common_model->saveData('sonologist', $input);
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $update = $this->Common_model->updateData('sonologist', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            redirect('sonological_expense', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function edit($record_id = '') {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Ultra (USG) Expense';
            $data['page_title'] = 'Ultra (USG) Expense';
            $data['info_header'] = 'Ultra (USG) Expense';
            if(!empty($record_id))
            $data['value'] = $this->Common_model->findById('sonologist',array('record_id'=>$record_id)) ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/sonological_expense/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $id, 'sonologist')){
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
            redirect('sonological_expense', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

}
