<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Investment extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
        
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Investment List';
            $data['page_title'] = 'Investment List';
            $data['info_header'] = 'All Investment List';
            $data['values'] = $this->Common_model->findAll('investments',array(),'record_id','desc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/investment/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }   
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            unset($input['update_id']);
            if($update_id == 0 || empty($update_id)){     
                $insert = $this->Common_model->saveData('investments', $input);
                $update_id = $insert ;
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $update = $this->Common_model->updateData('investments', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            redirect('investment', 'refresh');
            
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function investment_balance()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Invest & Share';
            $data['page_title'] = 'Invest & Share';
            $data['info_header'] = 'All Invest & Share';
            $data['values'] = $this->Common_model->findAllGroupBy('investments',array(),array('financial_year_id','partner_id'),'record_id','desc') ;
            //var_dump($data['values']) ; die;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/investment/investment_balance', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function rest_investment()
    {
        $partner_id = $this->input->post('partner_id');
        $financial_year_id = $this->input->post('financial_year_id');
        $where = array() ;
        $where['financial_year_id'] = $financial_year_id ;
        if(isset($partner_id)) $where['partner_id'] = $partner_id ;
        $investment_amount = $this->Common_model->calCulateSum('investments', $where, 'investment_amount');
        $investment_amount = isset($investment_amount) ? $investment_amount : 0;
        $withdraw_amount = $this->Common_model->calCulateSum('investment_withdraws', $where, 'withdraw_amount');
        $withdraw_amount = isset($withdraw_amount) ? $withdraw_amount : 0;
        $balance = $investment_amount - $withdraw_amount ;

        $financial_year = $this->Common_model->findById('financial_years',array('record_id'=>$financial_year_id)) ;
        $year_value = $financial_year->total_capital ;
        echo ($year_value - $balance);
        exit;
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            
            if($this->Common_model->delete_info('record_id', $id, 'investments')){
                
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
            redirect('investment', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
