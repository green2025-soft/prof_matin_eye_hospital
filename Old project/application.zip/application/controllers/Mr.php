<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Mr extends MY_Controller {

    private $type;
    private $tBUrl;

    public function __construct() {
        parent::__construct();
         $this->loadModel('CustomerMr_model');
         $this->title     = 'Customer Due Collection';
         $this->bUrl      = 'mr';
         $this->type      = $this->input->get('type') === 'optic' ? 'optic' : 'medicine';
         $this->tBUrl     = $this->bUrl.'?type='.$this->type;
    }


    public function index()
    {
        $this->data = [
            'title'     => $this->title.' List',
            'values'    => $this->model->order_by('mr_id', 'DESC')->all(),
            'type'      => $this->type
        ];
        
        $this->render('admin/mr/index');
    }
    
    public function create()
    {
      $customerDues = $this->model->customerDueLists();
    
      $this->data = [
        'title'         => $this->title,
        'type'          => $this->type,
        'customerDues'  => $customerDues,
      ];
		
      $this->render('admin/mr/create');
    }

    public function saveOrUpdate()
  {
        $input		    = $this->input->post();
        $update_id		= $input['update_id']??'';
        $date 		    = $input['mr_date'];
        
        $prefix         = date('Ymd', strtotime($date));
        $current_collections = $input['current_collection'];

      $this->db->trans_start();
      if(!$update_id){
          $mrQuery          = $this->model->select_max('mr_no')->where('prefix', $prefix)->first();
          $mr_no          	= (int) ($mrQuery->mr_no ?? 0) + 1;
          $input['mr_no'] 	= $mr_no;
      }
      $input['prefix']      = $prefix;
      $input['mr_amount']   = array_sum($current_collections);
      $data   = $this->model->filterTableData($input);
      $id     = $this->model->updateOrInsert($data, $update_id);

      foreach ($current_collections as $key => $value) {
        $discount     = $input['discount_amount'][$key];
        $totalAmount  = $discount + $value;
          if($totalAmount > 0){
          $mrDetails = [
                'mr_id'             => $id,
                'mr_date'           => $date,
                'collection_type'   => $input['collection_type'],
                'customer_id'       => $input['customer_id'],
                'sales_id'          => $input['sales_id'][$key],
                'sales_amount'      => $input['sales_amount'][$key],
                'current_collection'=> $value,
                'discount_amount'   => $discount,
        
          ];

         $this->Common_model->saveData('mr_details',$mrDetails);
        }

      }

      $this->db->trans_complete();

      $this->crudAlertMessage($update_id, $this->bUrl."/view/$id?type=$this->type"); 
  }
   

public function load_customer(){
    $customer_id = $this->input->post('customer_id');
    $where['customer_id'] = $customer_id ;
    $data['values'] = $this->Common_model->findAll('sales_orders',$where,'sales_id','asc') ;
    $this->load->view('admin/mr/invoice_list',$data);
}

public function view($mr_id)
  {
    $data['title'] = "View Collection";
    $data['page_title'] = "View Collection";
    $data['info_header'] = "";
    $data['signatureType'] = 'Staff';
    $data['redirect'] = base_url('mr/create');
    $data['value'] = $this->Common_model->findById('mr',array('mr_id'=>$mr_id));
    $data['patient'] = $this->Common_model->findById('patient',array('record_id'=>$data['value']->customer_id));

    $where = array('mr_details.mr_id '=>$mr_id);
    $options = array(
      'joins' => array(
        array(
          'table' => 'sales_orders',
          'condition' => 'sales_orders.sales_id = mr_details.sales_id',
          'jointype' => 'LEFT'
        )
      ),
      'select' => 'mr_details.*,sales_orders.prefix,sales_orders.sales_no,sales_orders.grand_net_total',
      'where' => $where,
      'order' => array(
        'mr_details.mr_details_id' => 'asc',
      ),
    );
    $data['values'] = $this->Common_model->commonJoins("mr_details", $options);

        $this->load->view('admin/layouts/header');
        $this->load->view('admin/mr/invoice', $data);
        $this->load->view('admin/layouts/footer');
  }


  public function delete($id) {

		$this->model->getDelete($id, 'mr_id');
		$this->Common_model->delete_info('mr_id', $id, 'mr_details');
		$this->crudAlertMessage($id, $this->tBUrl, true); 
  }
}
