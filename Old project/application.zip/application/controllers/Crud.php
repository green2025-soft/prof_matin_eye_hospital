<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud extends CI_Controller {

	const Title	 = '';
	const deleteMessage	 = 'Delete_Data Delete Successfully';
		
	public function __construct(){
		parent::__construct();
		$this->load->database();
		$this->load->library(array('session','user_agent'));
		$this->load->helper('date');
		date_default_timezone_set('Asia/Dhaka');
		//isAuthenticate();
	}
	
	
	public function show_hide($table, $record_id,$value) 
    {
		$invoice_table = array('admission_advance_invoice','admission_fee_invoice','ambulance_receipts','appointments','blood_donors','doctor_services','emergencys','dressing','operation_details');
		if($record_id){
			$data = $this->Common_model->findById($table, array($record_id => $value));
			if(property_exists($data,"invoice_id")){
				$show_hide = '' ;
				$bill = $this->Common_model->findById("create_bill", array('record_id' => $data->invoice_id));
				$show_hide = $bill->show_hide ;
				if($show_hide == "Show"){
					$show_hide = "Hide" ;
				}else{
					$show_hide = "Show" ;
				}
				$this->db->update('create_bill', array("show_hide"=>$show_hide),array('record_id' => $data->invoice_id));
			}
			$show_hide = '' ;
			if(isset($data)){
				$show_hide = $data->show_hide ;
				if($show_hide == "Show"){
					$show_hide = "Hide" ;
				}else{
					$show_hide = "Show" ;
				}
			}
			$result		=  $this->db->update($table, array("show_hide"=>$show_hide),array($record_id => $value));
			if(in_array($table,$invoice_table)){
				$invoiceTable = $this->Common_model->findById($table, array('record_id' => $value));
				if(isset($invoiceTable)){
					if(property_exists($invoiceTable,"invoice_id")){
						$this->db->update('create_bill', array("show_hide"=>$show_hide),array('record_id' => $invoiceTable->invoice_id));
					}
				}
			}
			if($table == 'create_bill'){
				$this->db->update('sales_test', array("show_hide"=>$show_hide),array('invoice_no' => $data->record_id));
				$this->db->update('sonologist', array("show_hide"=>$show_hide),array('invoice_id' => $data->record_id));
			}
			elseif($table == 'due_collections'){
				$this->db->update('due_collection_details', array("show_hide"=>$show_hide),array('mr_id' => $value));
			}
			elseif($table == 'mr'){
				$this->db->update('mr_details', array("show_hide"=>$show_hide),array('mr_id' => $value));
			}
			elseif($table == 'supplier_payments'){
				$this->db->update('supplier_payment_details', array("show_hide"=>$show_hide),array('payment_id' => $value));
			}
			elseif($table == 'emergencys'){
				$this->db->update('emergency_details', array("show_hide"=>$show_hide),array('emergency_id' => $value));
			}
			elseif($table == 'dressing'){
				$this->db->update('dressing_details', array("show_hide"=>$show_hide),array('dressing_id' => $value));
			}
			elseif($table == 'purchase_orders'){
				$this->db->update('purchase_order_details', array("show_hide"=>$show_hide),array('purchase_order_id' => $value));
			}
			elseif($table == 'sales_orders'){
				$this->db->update('sales_order_details', array("show_hide"=>$show_hide),array('sales_order_id' => $value));
			}
			elseif($table == 'expenses'){
				$this->db->update('expense_details', array("show_hide"=>$show_hide),array('expense_id' => $value));
			}
			elseif($table == 'incomes'){
				$this->db->update('income_details', array("show_hide"=>$show_hide),array('income_id' => $value));
			}
			elseif($table == 'lab_product_in'){
				$this->db->update('lab_product_in_details', array("show_hide"=>$show_hide),array('lab_product_in_id' => $value));
			}
			elseif($table == 'lab_product_out'){
				$this->db->update('lab_product_out_details', array("show_hide"=>$show_hide),array('lab_product_out_id' => $value));
			}
			if($result){
				$this->session->set_flashdata('message', UPDATE_MSG);
			}else{
				$this->session->set_flashdata('message', UPDATE_ERROR_MSG);
			}
			echo 1 ;
			exit;
		}else{
			echo 0 ;
			exit;
		}
	}

	public function edit($table, $field) 
    {
		$dataID		= $this->input->post('id');
		$result		=  $this->Common_model->findById($table, $where = array($field => $dataID));
		echo json_encode($result);
		
	}	

	
	public function delete($table, $field, $dataID,  $folder = '', $imgField = '')
	{
		if($folder != '' && $imgField != '') {
			$info = $this->Common_model->findById($table, array($field => $dataID)); 
			if(!empty($info->$imgField)) {
				unlink('./resource/'.$folder.'/'.$info->$imgField);
			}
		}	
		
		$this->db->delete($table,  array($field => $dataID));
		$this->session->set_userdata(array('alertMsg' => DELETE_MSG));
		$previousPage	=  $this->agent->referrer();
		redirect($previousPage,'refresh');
	}	
	public function deleteJson()
	{

		$table = $this->input->post('table');
		$field = $this->input->post('field');
		$folder = $this->input->post('folder');
		$dataID = $this->input->post('id');
		$imgField = $this->input->post('imgField');
		if($folder != '' && $imgField != '') {
			$info = $this->Common_model->findById($table, array($field => $dataID)); 
			if(!empty($info->$imgField)) {
				unlink('./resource/'.$folder.'/'.$info->$imgField);
			}
		}	
		$this->db->delete($table,  array($field => $dataID));
		$msg =  DELETE_MSG;
		echo $msg;
		exit;
	}
	
	
	public function deleteTemp($table, $field, $dataID,  $folder = '', $imgField = '')
	{
		if($folder != '' && $imgField != '') {
			$info = $this->Common_model->findById($table, array($field => $dataID)); 
			if(!empty($info->$imgField)) {
				unlink('./resource/'.$folder.'/'.$info->$imgField);
			}
		}	
		$data['status'] 	   = 'delete';
		$this->db->update($table, $data,  array($field => $dataID));
		$this->session->set_userdata(array('alertMsg' => DELETE_MSG));
	}
	
	
	
	public function changeSkin() 
	{
		$dataColor		= $this->input->post('dataColor');
		if($dataColor == "#438EB9") {
			$skinClass	= 'no-skin';
		} else if($dataColor == "#222A2D") {
			$skinClass	= 'skin-1';
		} else if($dataColor == "#C6487E") {
			$skinClass	= 'skin-2';
		} else  {
			$skinClass	= 'skin-3';
		}
		//echo $skinClass;
		$this->session->set_userdata(array('skinClass' => $skinClass));			
					
	}
	
	 public function previousPage() 
	 {
	 	$previousPage	=  $this->agent->referrer();
		redirect($previousPage,'refresh');
	 }

	 public function item_balance(){
	 	$product_id = $this->input->post('product_id');
	 	$item_balance = $this->Common_model->item_balance($product_id) ;
	 	echo $item_balance ;
	 	exit;
	 }
	 public function average_purchase(){
		$product_id = $this->input->post('product_id');
		$avg_price = $this->Common_model->average_purchase($product_id);
		echo $avg_price;
		exit ;
	}
	public function exist()
	{
		$username = $this->input->post('username') ;
		$update_id = $this->input->post('update_id') ;
		$where = array() ;
		$where['name'] = $username ;
		if(!empty($update_id) || $update_id != 0)
		$where['record_id != '] = $update_id ;

		$where2 = array() ;
		$where2['username'] = $username ;
		if(!empty($update_id) || $update_id != 0)
		$where2['record_id != '] = $update_id ;

		$admin = $this->Common_model->findById('admin',$where) ;
		$doctor = $this->Common_model->findById('doctor',$where2) ;
		$staff = $this->Common_model->findById('staff',$where2) ;
		if(isset($admin))
		{
			$response['key'] = 1 ;
			$response['msg'] = "This Username already has been taken!." ;
		}elseif(isset($doctor)){
			$response['key'] = 1 ;
			$response['msg'] = "This Username already has been taken!." ;
		}elseif(isset($staff)){
			$response['key'] = 1 ;
			$response['msg'] = "This Username already has been taken!." ;
		}else{
			$response['key'] = 0 ;
			$response['msg'] = "" ;
		}
		echo json_encode($response); exit ;
	}
	public function sendSms()
	{
		techno_bulk_sms('01855996632','test');
	}
}
