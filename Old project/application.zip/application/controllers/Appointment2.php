<?php

defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Appointment extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
    }
    public function index()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Doctor Visit List';
            $data['page_title'] = 'Doctor Visit List';
            $where = array();
            $where['invoice_status '] = 'Created';
            if (!admin()) {
                $where['show_hide'] = "Show";
            }
            $data['values'] = $this->Common_model->findAll('appointments', $where, 'record_id', 'desc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/appointment/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function create()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Doctor Visit';
            $data['page_title'] = 'Doctor Visit';
            $current_date = closing_date(date('Y-m-d'));
            $prefix = date('Ymd', strtotime($current_date));
            $max = $this->Common_model->findMax('appointments', array('prefix' => $prefix), 'serial_no');
            $serial_no =  isset($max) ? $max->serial_no + 1 : 1;
            $data['serial_no'] = $prefix . '-' . $serial_no; //str_pad($serial_no,4,0,STR_PAD_LEFT ); 
            $data['specialists'] = $this->Common_model->findAll('specialists', array(), 'specialists', 'asc');
            // var_dump($data['specialists']);die;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/appointment/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function edit($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Edit Doctor Visit';
            $data['page_title'] = 'Edit Doctor Visit';
            $data['value'] = $this->Common_model->findById('appointments', array('record_id' => $record_id));
            $data['patient'] = $this->Common_model->findById('patient', array('record_id' => $data['value']->patient_id));
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/appointment/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST;
            $serial_id = $input['serial_id'];
            $invoice_status = $input['invoice_status'];
            unset($input['serial_id']) ;
            unset($input['invoice_status']) ;
            
            $date = $input['date'];
            $serial_no = $input['serial_no'];
            $doctor_fee = $input['doctor_fee'];
            $appointment_time = $input['appointment_time'];
            // var_dump($appointment_time);die;
            $update_id = $input['update_id'];
            unset($input['update_id']);
            unset($input['serial_status']);
            unset($input['serial_no']);
            unset($input['doctor_fee']);
            unset($input['appointment_time']);
            $prefix1 = date("Ymd", strtotime($date));
            $max = $this->Common_model->findMax('appointments', array('prefix' => $prefix1), 'serial_no');
            $serial_no =  isset($max) ? $max->serial_no + 1 : 1;
            $data['serial_no'] = $prefix1 . $serial_no;

            $prefix = 'App' . date("Ymd", strtotime($date));
            $maxSalesTest = $this->Common_model->findMax('create_bill', array('prefix' => $prefix, 'type' => 'Appointment'), 'invoice_no');
            $invoice_no = isset($maxSalesTest) ? $maxSalesTest->invoice_no + 1 : 1;
            
            $input['prefix'] = $prefix;
            $input['invoice_no'] = $invoice_no;
            $input['type'] = 'appointment';
            $input['particular'] = "Doctor Visit";

           // var_dump($input) ; die ;



            if ($update_id == 0 || empty($update_id)) {
                $invoice_id = $this->Common_model->saveData('create_bill', $input);
                $data = array(
                    'prefix' => $prefix1,
                    'serial_no' => $serial_no,
                    'invoice_id' => $invoice_id,
                    'date' => $date,
                    'patient_id' => $input['patient_id'],
                    'doctor_id' => $input['doctor_id'],
                    'doctor_fee' => $doctor_fee,
                    'discount' => $input['discount'],
                    'discount_percentage' => $input['discount_percentage'],
                    'reference_by' => $input['reference_by'],
                    'sub_total' => $input['sub_total'],
                    'paid' => $input['paid'],
                    'due' => $input['due'],
                    'doctor_commission' => $input['doctor_commission'],
                    'company_commission' => $input['paid'] - $input['doctor_commission'],
                    'appointment_time' => $appointment_time,
                    'comments' => $input['comments'],
                );
                $data['invoice_status'] = 'Created' ;
                if(empty($serial_id)){
                    $data['serial_status'] = 'Direct';
                }
                if ($serial_id) {
                    unset($data['prefix']);
                    unset($data['serial_no']);
                    unset($data['date']);
                    $data['serial_id'] = $serial_id ;
                    $this->Common_model->updateData('appointments', $data, array('record_id' => $serial_id));
                  //  var_dump($data) ; die ;
                    $insert =  $update_id = $serial_id;
                } else {
                    $insert = $this->Common_model->saveData('appointments', $data);
                    $update_id = $insert;
                }
                if ($insert) {
                    $this->session->set_flashdata('message', INSERT_MSG);
                } else {
                    $this->session->set_flashdata('message', INSERT_ERROR_MSG);
                }
                redirect("appointment/view/$update_id", 'refresh');
            } else {
                $appointment = $this->Common_model->findById('appointments', array('record_id' => $update_id));
                $bill = $this->Common_model->findById('create_bill', array('record_id' => $appointment->invoice_id));
                if ($bill->date == $date) {
                    $input['invoice_no'] = $bill->invoice_no;
                    $serial_no = $appointment->serial_no;
                    $prefix1 = $appointment->prefix;
                }
                $this->Common_model->updateData('create_bill', $input, array('record_id' => $bill->record_id));

                $data = array(
                    'prefix' => $prefix1,
                    'serial_no' => $serial_no,
                    'invoice_id' => $bill->record_id,
                    'date' => $date,
                    'patient_id' => $input['patient_id'],
                    'doctor_id' => $input['doctor_id'],
                    'doctor_fee' => $doctor_fee,
                    'discount_percentage' => $input['discount_percentage'],
                    'discount' => $input['discount'],
                    'reference_by' => $input['reference_by'],
                    'sub_total' => $input['sub_total'],
                    'paid' => $input['paid'],
                    'due' => $input['due'],
                    'doctor_commission' => $input['doctor_commission'],
                    'appointment_time' => $appointment_time,
                );

                $update = $this->Common_model->updateData('appointments', $data, array('record_id' => $update_id));

                if ($update) {
                    $this->session->set_flashdata('message', UPDATE_MSG);
                } else {
                    $this->session->set_flashdata('message', UPDATE_ERROR_MSG);
                }
                redirect("appointment/view2/$update_id", 'refresh');
            }



            $patient = $this->Common_model->findById('patient', array('record_id' => $input['patient_id']));
            $doctor = $this->Common_model->findById('doctor', array('record_id' => $input['doctor_id']));
            $contact = $this->Common_model->findById('contact', array('id' => 1));

            $patient_id = isset($patient) ? $patient->record_id : 0;
            $patient_name = isset($patient) ? $patient->name : '';
            $mobile = isset($patient) ? $patient->mobile : '';
            $visit_serial = $prefix1 . $serial_no;
            $visit_hour = $appointment_time;
            $doctor_name = isset($doctor) ? $doctor->name : '';
            $app_name = isset($contact) ? $contact->c_name : '';
            $app_address = isset($contact) ? $contact->address : '';

            // var_dump("Called");die;

            if (strlen($mobile) == 11) {
                $sms_body = "P.Name : $patient_name,\nSerial : $visit_serial,\nDr. Name  : $doctor_name,\nV.H : $visit_hour,\n$app_name , $app_address";
                $sms_qty = ceil(strlen(utf8_decode($sms_body)) / 160);
                $send_sms_qty = 1 * $sms_qty;

                $data = array(
                    'sms_id' => 0,
                    'sms_title' => 'Doctor Visit',
                    'send_date' => date('Y-m-d'),
                    'sms_body' => $sms_body,
                    'sms_person' => 1,
                    'send_sms_qty' => $send_sms_qty,
                );
                $logId = $this->Common_model->saveData('sms_log', $data);

                $reserveSmsObj = $this->Common_model->findById('load_sms', array('load_sms_id' => 1));
                $reserveSms = isset($reserveSmsObj) ? $reserveSmsObj->sms_qty : 0;
                if ($reserveSms >= $sms_qty) {
                    $smsDetails = array(
                        'sms_log_id' => $logId,
                        'send_date' => date('Y-m-d'),
                        'patient_id' => $patient_id,
                    );
                    $this->Common_model->saveData('sms_log_details', $smsDetails);
                    techno_bulk_sms($mobile, $sms_body);
                    $balance_sms = $reserveSms - (1 * $sms_qty);
                    $this->Common_model->updateData('load_sms', array('sms_qty' => $balance_sms), array('load_sms_id' => 1));
                }
            }
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function view($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Doctor Visit Invoice';
            $data['page_title'] = 'Doctor Visit Invoice';
            $data['value'] = $this->Common_model->findById('appointments', array('record_id' => $record_id));
            $data['patient'] = $this->Common_model->findById('patient', array('record_id' => $data['value']->patient_id));
            $data['doctor'] = $this->Common_model->findById('doctor', array('record_id' => $data['value']->doctor_id));
            $data['redirect'] = base_url('appointment/create');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/appointment/invoice', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function view2($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Doctor Visit Invoice';
            $data['page_title'] = 'Doctor Visit Invoice';
            $data['value'] = $this->Common_model->findById('appointments', array('record_id' => $record_id));
            $data['patient'] = $this->Common_model->findById('patient', array('record_id' => $data['value']->patient_id));
            $data['doctor'] = $this->Common_model->findById('doctor', array('record_id' => $data['value']->doctor_id));
            $data['redirect'] = base_url('appointment');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/appointment/invoice', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function get_doctor_fee()
    {
        $doctor_id = $this->input->post('doctor_id');
        $patient_id = $this->input->post('patient_id');
        $doctor = $this->Common_model->findById('doctor', array('record_id' => $doctor_id));
        $current_date = date('Y-m-d');
        $doctor_fee = isset($doctor) ? $doctor->frees : 0;
        $follow_up_fee = isset($doctor) ? $doctor->follow_up_fee : 0;
        $commission_fee = isset($doctor) ? $doctor->commission_fee : 0;
        $follow_up_commission = isset($doctor) ? $doctor->follow_up_commission : 0;


        $where['patient_id'] = $patient_id;
        $where['doctor_id'] = $doctor_id;
        $appointment = $this->Common_model->findFirstOrLast('appointments', $where, 'record_id', 'desc');

        //   var_dump($appointment);die;

        if (isset($appointment)) {
            $lastConsultency = $appointment->date;
            $date1 = date_create($current_date);
            $date2 = date_create($lastConsultency);
            $diff = date_diff($date1, $date2);
            $month = intval($diff->format("%m"));
            $day = intval($diff->format("%d"));
            $visit = ($month * 30) + $day;
            // var_dump($visit);die;
            if ($visit <= 30) {
                $doctor_fee = $follow_up_fee;
                $commission_fee = $follow_up_commission;
            }
        }

        $data = array(
            'doctor_fee' => $doctor_fee,
            'commission_fee' => $commission_fee,
        );
        echo json_encode($data);
    }

    public function delete($id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            $appointment = $this->Common_model->findById('appointments', array('record_id' => $id));
            if ($appointment) {
                $this->Common_model->delete_info('record_id', $id, 'appointments');
                $this->Common_model->delete_info('record_id', $appointment->invoice_id, 'create_bill');
                $this->session->set_flashdata('message', DELETE_MSG);
            } else {
                $this->session->set_flashdata('message', DELETE_ERROR_MSG);
            }
            // redirect("crud/previousPage");
            redirect('appointment', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
