<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Basic_information extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('upload');
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Basic Information';
            $data['page_title'] = 'Basic Information';
            $data['info_header'] = 'All Basic Information';
            $data['values'] = $this->Common_model->findAll('single_page_content',array(),'record_id','desc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/basic_information/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            unset($input['update_id']);

          $config['upload_path']      = 'assets/img/single_page_content/';
          $config['allowed_types']    = '*';
          $config['max_size']         = '0';
          //$config['file_name']      = time(); 
          $file_field                 = "image";
          $this->upload->initialize($config);
            if($update_id == 0 || empty($update_id)){     

                if(!empty($_FILES[$file_field]["name"])){
                    if($this->upload->do_upload($file_field)) {
                        $uploadData = $this->upload->data();
                        $input['image'] =   $config['upload_path'] . $uploadData['file_name'];
                    }
                }

                $insert = $this->Common_model->saveData('single_page_content', $input);
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $info = $this->Common_model->findById('single_page_content',array('record_id'=>$update_id));
                if(!empty($_FILES[$file_field]["name"])){
                    if(file_exists($info->image) && !empty($info->image)) {
                        unlink('./'.$info->image);
                    }
                    if($this->upload->do_upload($file_field)) {
                            $uploadData = $this->upload->data();
                            $input['image'] =   $config['upload_path'] . $uploadData['file_name'];
                    }
                }
                $update = $this->Common_model->updateData('single_page_content', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            redirect('basic_information', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            $info = $this->Common_model->findById('single_page_content',array('record_id'=>$id)) ;
                if($info){
                    if(file_exists($info->image) && !empty($info->image)) {
                    unlink('./'.$info->image);
                }
                $this->Common_model->delete_info('record_id', $id, 'single_page_content');
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
            redirect('basic_information', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
