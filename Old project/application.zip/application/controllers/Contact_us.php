<?php

defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Contact_us extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('upload');
    }
    public function index()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Contact Us';
            $data['page_title'] = 'Contact Us';
            $data['info_header'] = 'All Contact Us';
            $data['contact'] = $this->Common_model->findById('contact', array('id' => 1));
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/contact_us/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST;
            $update_id = $input['update_id'];
            unset($input['files']);
            unset($input['update_id']);
            $config['upload_path']      = 'assets/img/logo/';
            $config['allowed_types']    = '*';
            $config['max_size']         = '0';
            //$config['file_name']      = 'logo';
            $this->upload->initialize($config);
            $file_field1                 = "logo";
            $file_field2                 = "frontend_logo";
            if ($update_id == 0 || empty($update_id)) {
                if (!empty($_FILES[$file_field1]["name"])) {
                    if ($this->upload->do_upload($file_field1)) {
                        $uploadData = $this->upload->data();
                        $input['logo'] =   $config['upload_path'] . $uploadData['file_name'];
                    }
                }
                if (!empty($_FILES[$file_field2]["name"])) {
                    if ($this->upload->do_upload($file_field2)) {
                        $uploadData = $this->upload->data();
                        $input['frontend_logo'] =   $config['upload_path'] . $uploadData['file_name'];
                    }
                }
                $insert = $this->Common_model->saveData('contact', $input);
                if ($insert) {
                    $this->session->set_flashdata('message', INSERT_MSG);
                } else {
                    $this->session->set_flashdata('message', INSERT_ERROR_MSG);
                }
            } else {
                $info = $this->Common_model->findById('contact', array('id' => $update_id));
                if (!empty($_FILES[$file_field1]["name"])) {
                    if (file_exists($info->logo) && !empty($info->logo)) {
                        unlink('./' . $info->logo);
                    }
                    if ($this->upload->do_upload($file_field1)) {
                        $uploadData = $this->upload->data();
                        $input['logo'] =   $config['upload_path'] . $uploadData['file_name'];
                    }
                }
               // var_dump($_FILES[$file_field2]["name"]);die;
                if (!empty($_FILES[$file_field2]["name"])) {
                    if (file_exists($info->frontend_logo) && !empty($info->frontend_logo)) {
                        unlink('./' . $info->frontend_logo);
                    }
                    if ($this->upload->do_upload($file_field2)) {
                        $uploadData = $this->upload->data();
                        $input['frontend_logo'] =   $config['upload_path'] . $uploadData['file_name'];
                    }
                }
               // var_dump($input);die;
                $update = $this->Common_model->updateData('contact', $input, array('id' => $update_id));
                if ($update) {
                    $this->session->set_flashdata('message', UPDATE_MSG);
                } else {
                    $this->session->set_flashdata('message', UPDATE_ERROR_MSG);
                }
            }
            redirect('contact_us', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            $info = $this->Common_model->findById('single_page_content', array('record_id' => $id));
            if ($info) {
                if (file_exists($info->image) && !empty($info->image)) {
                    unlink('./' . $info->image);
                }
                $this->Common_model->delete_info('record_id', $id, 'single_page_content');
                $this->session->set_flashdata('message', DELETE_MSG);
            } else {
                $this->session->set_flashdata('message', DELETE_ERROR_MSG);
            }
            redirect('basic_information', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
