<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Blood_donor extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
        
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Blood Donation List';
            $data['page_title'] = 'Blood Donation List';
            $data['info_header'] = 'Blood Donation List';
            $where = array();
             $options = array(
                'joins' => array(
                    array(
                        'table' => 'doctor',
                        'condition' => 'doctor.record_id = blood_donors.doctor_id',
                        'jointype' => 'LEFT'
                    ),
                    array(
                        'table' => 'patient',
                        'condition' => 'patient.record_id = blood_donors.patient_id',
                        'jointype' => 'LEFT'
                    ),
                    array(
                        'table' => 'blood_groups',
                        'condition' => 'blood_groups.record_id = blood_donors.blood_group_id',
                        'jointype' => 'LEFT'
                    ),array(
                        'table' => 'test_name',
                        'condition' => 'test_name.record_id = blood_donors.test_id',
                        'jointype' => 'LEFT'
                    ),
                ),
                'select' => 'blood_donors.*,blood_donors.record_id as blood_donor_id,doctor.record_id as doctor_id,doctor.name as doctor_name,doctor.mobile as doctor_mobile,doctor.designation as doctor_designation,blood_groups.group_name,patient.*,test_name.test_name',
                'where' => $where,
                'order' => array(
                    'blood_donors.record_id' => 'desc',
                ),
            );

            $data['values'] = $this->Common_model->commonJoins("blood_donors", $options);

            $this->load->view('admin/layouts/header');
            $this->load->view('admin/blood_donor/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }    
    public function create() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Blood Donation';
            $data['page_title'] = 'Blood Donation';
            $data['info_header'] = '';
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/blood_donor/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function edit($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Edit Blood Donor';
            $data['page_title'] = 'Edit Blood Donor';
            $data['info_header'] = '';
            $data['value'] = $this->Common_model->findById('blood_donors',array('record_id'=>$record_id));
          //  var_dump($data['value']);die;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/blood_donor/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            unset($input['update_id']);

            $date = $input['date'];
            $prefix = 'Blo'. str_replace('-', '', $date) ;
            $max = $this->Common_model->findMax('create_bill',array('prefix'=>$prefix),'invoice_no') ;
            $invoice_no = isset($max)?$max->invoice_no + 1 : 1;

            $others_cost = $input['others_cost']?$input['others_cost']:0 ;
                
            $data = array(
                'type'=>'Donor',
                'prefix'=>$prefix,
                'invoice_no'=>$invoice_no,
                'date'=>$date,
                'particular'=>'Donor',
                'patient_id'=>$input['patient_id'],
                'doctor_id'=>$input['doctor_id'],
                'amount'=>$input['test_price'] + $others_cost,
                'discount'=>$input['discount_amount'],
                'sub_total'=>$input['sub_total_amount'],
                'paid'=>$input['paid_amount'],
                'due'=>$input['due_amount'],
                'comments'=>$input['comments']
            );
           // var_dump($data);die;
            if($update_id == 0 || empty($update_id)){     
                $invoice_id = $this->Common_model->saveData('create_bill', $data);  
                $input['invoice_id'] = $invoice_id ;
                $insert = $this->Common_model->saveData('blood_donors', $input);
                $update_id = $insert ;
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
                 redirect("blood_donor/view/$insert", 'refresh');
            }else{
                $insert = $update_id ;
                $blood_donor = $this->Common_model->findById('blood_donors',array('record_id'=>$update_id));
                if($date == $blood_donor->date){
                    $bill = $this->Common_model->findById('create_bill',array('record_id'=>$blood_donor->invoice_id));
                    $data['invoice_no'] = $bill->invoice_no ;
                } 
                $this->Common_model->updateData('create_bill', $data,array('record_id'=>$blood_donor->invoice_id));
                $update = $this->Common_model->updateData('blood_donors', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
                $data['redirect'] = base_url('blood_donor');
                redirect("blood_donor/view2/$insert", 'refresh');
            }
           
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function view($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Blood Donor Invoice';
            $data['page_title'] = 'Blood Donor Invoice';
            $data['info_header'] = '';
            $data['signatureType'] = 'Patient';
            $data['redirect'] = base_url('blood_donor/create');
            $where = array('blood_donors.record_id'=>$record_id);
            $options = array(
                'joins' => array(
                    array(
                        'table' => 'doctor',
                        'condition' => 'doctor.record_id = blood_donors.doctor_id',
                        'jointype' => 'LEFT'
                    ),
                    array(
                        'table' => 'patient',
                        'condition' => 'patient.record_id = blood_donors.patient_id',
                        'jointype' => 'LEFT'
                    ),
                    array(
                        'table' => 'blood_groups',
                        'condition' => 'blood_groups.record_id = blood_donors.blood_group_id',
                        'jointype' => 'LEFT'
                    ),
                    array(
                        'table' => 'test_name',
                        'condition' => 'test_name.record_id = blood_donors.test_id',
                        'jointype' => 'LEFT'
                    ),
                ),
                'select' => 'blood_donors.*,blood_donors.record_id as blood_donor_id,doctor.record_id as doctor_id,doctor.name as doctor_name,doctor.mobile as doctor_mobile,doctor.designation as doctor_designation,blood_groups.group_name,patient.*,patient.record_id as patient_id,test_name.test_name',
                'where' => $where,
                'order' => array(
                    'blood_donors.record_id' => 'desc',
                ),
            );
            $data['value'] = $this->Common_model->commonJoinsRow("blood_donors", $options);
            $invoice = $this->Common_model->findById('create_bill',array('record_id'=>$data['value']->invoice_id));
            $invoice_no = isset($invoice)?$invoice->prefix.$invoice->invoice_no:'';
            $data['value']->invoice_no = $invoice_no ;
           // var_dump($data['value']);die;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/blood_donor/view', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function view2($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Blood Donor Invoice';
            $data['page_title'] = 'Blood Donor Invoice';
            $data['info_header'] = '';
            $data['signatureType'] = 'Patient';
            $data['redirect'] = base_url('blood_donor');
            $where = array('blood_donors.record_id'=>$record_id);
            $options = array(
                'joins' => array(
                    array(
                        'table' => 'doctor',
                        'condition' => 'doctor.record_id = blood_donors.doctor_id',
                        'jointype' => 'LEFT'
                    ),
                    array(
                        'table' => 'patient',
                        'condition' => 'patient.record_id = blood_donors.patient_id',
                        'jointype' => 'LEFT'
                    ),
                    array(
                        'table' => 'blood_groups',
                        'condition' => 'blood_groups.record_id = blood_donors.blood_group_id',
                        'jointype' => 'LEFT'
                    ),
                    array(
                        'table' => 'test_name',
                        'condition' => 'test_name.record_id = blood_donors.test_id',
                        'jointype' => 'LEFT'
                    ),
                ),
                'select' => 'blood_donors.*,blood_donors.record_id as blood_donor_id,doctor.record_id as doctor_id,doctor.name as doctor_name,doctor.mobile as doctor_mobile,doctor.designation as doctor_designation,blood_groups.group_name,patient.*,patient.record_id as patient_id,test_name.test_name',
                'where' => $where,
                'order' => array(
                    'blood_donors.record_id' => 'desc',
                ),
            );
            $data['value'] = $this->Common_model->commonJoinsRow("blood_donors", $options);
            $invoice = $this->Common_model->findById('create_bill',array('record_id'=>$data['value']->invoice_id));
            $invoice_no = isset($invoice)?$invoice->prefix.$invoice->invoice_no:'';
            $data['value']->invoice_no = $invoice_no ;
           // var_dump($data['value']);die;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/blood_donor/view', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $id, 'blood_donors')){
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
            redirect('blood_donor', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
