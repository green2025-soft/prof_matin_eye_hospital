<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Ambulance_receipt extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
        
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Ambulance Receipt List';
            $data['page_title'] = 'Ambulance Receipt List';
            $data['info_header'] = 'All Ambulance Receipt List';
            $data['values'] = $this->Common_model->findAll('ambulance_receipts',array(),'record_id','asc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/ambulance_receipt/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }    
    public function create() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Create Ambulance Receipt';
            $data['page_title'] = 'Create Ambulance Receipt';
            $data['info_header'] = '';
            $max = $this->Common_model->findMax('ambulance_receipts',array(),'trip_no') ;
            $trip_no = isset($max)?$max->trip_no + 1 : 1;
            $data['trip_no'] = str_pad($trip_no,4,0,STR_PAD_LEFT );
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/ambulance_receipt/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function edit($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Create Ambulance Receipt';
            $data['page_title'] = 'Create Ambulance Receipt';
            $data['info_header'] = '';
            $data['value'] = $this->Common_model->findById('ambulance_receipts',array('record_id'=>$record_id));
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/ambulance_receipt/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            unset($input['update_id']);

            $date = $input['date'];
            $prefix = 'Amb'. str_replace('-', '', $date) ;
            $max = $this->Common_model->findMax('create_bill',array('prefix'=>$prefix),'invoice_no') ;
            $invoice_no = isset($max)?$max->invoice_no + 1 : 1;
                
            $data = array(
                'type'=>'Ambulance',
                'prefix'=>$prefix,
                'invoice_no'=>$invoice_no,
                'date'=>$date,
                'particular'=>'Ambulance Receipt',
                'patient_id'=>$input['patient_id'],
                'amount'=>$input['total_receive'],
                'discount'=>0,
                'sub_total'=>$input['total_receive'],
                'paid'=>$input['total_receive'],
                'road_cost'=>$input['road_cost'],
                'fuel_cost'=>$input['fuel_cost'],
                'service_maintanance_cost'=>$input['service_maintanance_cost'],
                'comments'=>$input['comments'],
            );
               

            if($update_id == 0 || empty($update_id)){     
                $invoice_id = $this->Common_model->saveData('create_bill', $data);  
                $input['invoice_id'] = $invoice_id ;
                $insert = $this->Common_model->saveData('ambulance_receipts', $input);
                $update_id = $insert ;
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $ambulance_receipt = $this->Common_model->findById('ambulance_receipts',array('record_id'=>$update_id));
                if($date == $ambulance_receipt->date){
                    $bill = $this->Common_model->findById('create_bill',array('record_id'=>$ambulance_receipt->invoice_id));
                    $data['invoice_no'] = $bill->invoice_no ;
                }
                $this->Common_model->updateData('create_bill', $data,array('record_id'=>$ambulance_receipt->invoice_id));
                $update = $this->Common_model->updateData('ambulance_receipts', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            redirect("ambulance_receipt/view2/$update_id", 'refresh');
            }
            redirect("ambulance_receipt/view/$update_id", 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function view($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Create Ambulance Receipt';
            $data['page_title'] = 'Create Ambulance Receipt';
            $data['info_header'] = '';
            $data['signatureType'] = 'Patient';
            $data['redirect'] = base_url('ambulance_receipt/create');
            $data['value'] = $this->Common_model->findById('ambulance_receipts',array('record_id'=>$record_id));
            $data['patient'] = $this->Common_model->findById('patient',array('record_id'=>$data['value']->patient_id));
            $data['ambulance'] = $this->Common_model->findById('ambulance',array('record_id'=>$data['value']->ambulance_id));
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/ambulance_receipt/view', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function view2($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Create Ambulance Receipt';
            $data['page_title'] = 'Create Ambulance Receipt';
            $data['info_header'] = '';
            $data['signatureType'] = 'Patient';
            $data['redirect'] = base_url('ambulance_receipt');
            $data['value'] = $this->Common_model->findById('ambulance_receipts',array('record_id'=>$record_id));
            $data['patient'] = $this->Common_model->findById('patient',array('record_id'=>$data['value']->patient_id));
            $data['ambulance'] = $this->Common_model->findById('ambulance',array('record_id'=>$data['value']->ambulance_id));
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/ambulance_receipt/view', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            $ambulance_receipt = $this->Common_model->findById('ambulance_receipts',array('record_id'=>$id));
            if($this->Common_model->delete_info('record_id', $id, 'ambulance_receipts')){
                $this->Common_model->delete_info('record_id', $ambulance_receipt->invoice_id, 'create_bill') ;
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
            redirect('ambulance_receipt', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
