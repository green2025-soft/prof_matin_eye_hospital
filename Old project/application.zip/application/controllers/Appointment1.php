<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Appointment extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Doctor Visit List';
            $data['page_title'] = 'Doctor Visit List';
            $data['values'] = $this->Common_model->findAll('appointments',array(),'record_id','desc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/appointment/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function create() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Doctor Visit';
            $data['page_title'] = 'Doctor Visit';
            $max = $this->Common_model->findMax('appointments',array(),'serial_no') ;
            $serial_no = isset($max)?$max->serial_no + 1 : 1;
            $data['serial_no'] = str_pad($serial_no,4,0,STR_PAD_LEFT ); 
            $data['specialists'] = $this->Common_model->findAll('specialists',array(),'specialists','asc');
           // var_dump($data['specialists']);die;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/appointment/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function edit($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Edit Doctor Visit List';
            $data['page_title'] = 'Edit Doctor Visit List';
            $data['value'] = $this->Common_model->findById('appointments',array('record_id'=>$record_id)) ;
            $data['patient'] = $this->Common_model->findById('patient',array('record_id'=>$data['value']->patient_id)) ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/appointment/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $date = $input['date'] ; 
            $serial_no = $input['serial_no'] ; 
            $doctor_fee = $input['doctor_fee'] ; 
            $appointment_time = $input['appointment_time'] ; 
            $update_id = $input['update_id'] ;
            unset($input['update_id']);
            unset($input['serial_no']);
            unset($input['doctor_fee']);
            unset($input['appointment_time']);
            $prefix = 'App'. date("Ymd",strtotime($date));
            $maxSalesTest = $this->Common_model->findMax('create_bill',array('prefix'=>$prefix,'type'=>'Appointment'),'invoice_no');
            $invoice_no = isset($maxSalesTest)?$maxSalesTest->invoice_no + 1 : 1 ;
            $input['prefix'] = $prefix ;
            $input['invoice_no'] = $invoice_no ;
            $input['type'] = 'appointment';
            $input['particular'] = "Appointment Booking";

            if($update_id == 0 || empty($update_id)){       
                $invoice_id = $this->Common_model->saveData('create_bill', $input);
                $data = array(
                    'serial_no'=>$serial_no,
                    'invoice_id'=>$invoice_id,
                    'date'=>$date,
                    'patient_id'=>$input['patient_id'],
                    'doctor_id'=>$input['doctor_id'],
                    'doctor_fee'=>$doctor_fee,
                    'discount'=>$input['discount'],
                    'reference_by'=>$input['reference_by'],
                    'sub_total'=>$input['sub_total'],
                    'paid'=>$input['paid'],
                    'due'=>$input['due'],
                    'doctor_commission'=>$input['doctor_commission'],
                    'company_commission'=>$input['paid'] - $input['doctor_commission'],
                    'appointment_time'=>$appointment_time,
                    'comments'=>$input['comments'],
                );
                $insert = $this->Common_model->saveData('appointments', $data);
                $update_id = $insert ;
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $appointment = $this->Common_model->findById('appointments',array('record_id'=>$update_id));
                $bill = $this->Common_model->findById('create_bill',array('record_id'=>$appointment->invoice_id));
                if($bill->date == $date){
                    $input['invoice_no'] = $bill->invoice_no ;
                }

               // var_dump($bill);die;
                $this->Common_model->updateData('create_bill', $input,array('record_id'=>$bill->record_id));

                $data = array(
                    'serial_no'=>$serial_no,
                    'invoice_id'=>$bill->record_id,
                    'date'=>$date,
                    'patient_id'=>$input['patient_id'],
                    'doctor_id'=>$input['doctor_id'],
                    'doctor_fee'=>$doctor_fee,
                    'discount'=>$input['discount'],
                    'reference_by'=>$input['reference_by'],
                    'sub_total'=>$input['sub_total'],
                    'paid'=>$input['paid'],
                    'due'=>$input['due'],
                    'doctor_commission'=>$input['doctor_commission'],
                    'appointment_time'=>$appointment_time,
                );

              //  var_dump($data);die;

                $update = $this->Common_model->updateData('appointments', $data,array('record_id'=>$update_id));

                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            redirect("appointment/view/$update_id", 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function view($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Appointment Invoice';
            $data['page_title'] = 'Appointment Invoice';
            $data['value'] = $this->Common_model->findById('appointments',array('record_id'=>$record_id)) ;
            $data['patient'] = $this->Common_model->findById('patient',array('record_id'=>$data['value']->patient_id)) ;
            $data['doctor'] = $this->Common_model->findById('doctor',array('record_id'=>$data['value']->doctor_id)) ;
            $data['redirect'] = base_url('appointment/create') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/appointment/invoice', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }    
    public function view2($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Appointment Invoice';
            $data['page_title'] = 'Appointment Invoice';
            $data['value'] = $this->Common_model->findById('appointments',array('record_id'=>$record_id)) ;
            $data['patient'] = $this->Common_model->findById('patient',array('record_id'=>$data['value']->patient_id)) ;
            $data['doctor'] = $this->Common_model->findById('doctor',array('record_id'=>$data['value']->doctor_id)) ;
            $data['redirect'] = base_url('appointment') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/appointment/invoice', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function get_doctor_fee() {
        $doctor_id = $this->input->post('doctor_id');
        $patient_id = $this->input->post('patient_id');
        $doctor = $this->Common_model->findById('doctor', array('record_id'=> $doctor_id));
        $current_date = date('Y-m-d') ; 
        $doctor_fee = isset($doctor)?$doctor->frees:0;
        $follow_up_fee = isset($doctor)?$doctor->follow_up_fee:0;
        $commission_fee = isset($doctor)?$doctor->commission_fee:0;
        $follow_up_commission = isset($doctor)?$doctor->follow_up_commission:0;


        $where['patient_id'] = $patient_id ;
        $where['doctor_id'] = $doctor_id ;
        $appointment = $this->Common_model->findFirstOrLast('appointments',$where,'record_id','desc');

     //   var_dump($appointment);die;

        if(isset($appointment)){
            $lastConsultency = $appointment->date ;
            $date1=date_create($current_date );
            $date2=date_create($lastConsultency);
            $diff=date_diff($date1,$date2);
            $month = intval($diff->format("%m"));
            $day = intval($diff->format("%d"));
            $visit = ($month * 30) + $day;
           // var_dump($visit);die;
            if($visit <= 30){
                 $doctor_fee = $follow_up_fee;
                 $commission_fee = $follow_up_commission;
            }
        }

        $data = array(
            'doctor_fee'=>$doctor_fee,
            'commission_fee'=>$commission_fee,
        );
        echo json_encode($data);
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            $appointment = $this->Common_model->findById('appointments',array('record_id'=>$id));
            if($appointment){
                $this->Common_model->delete_info('record_id', $id, 'appointments');
                $this->Common_model->delete_info('record_id', $appointment->invoice_id, 'create_bill');
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
           // redirect("crud/previousPage");
            redirect('appointment', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
