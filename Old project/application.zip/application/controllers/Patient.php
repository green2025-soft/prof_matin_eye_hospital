<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Patient extends MY_Controller {

    public function __construct() {
        $this->title = 'Customer Information';
        parent::__construct();
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = $this->title;
            $data['page_title'] = $this->title;
            $data['values'] = $this->Common_model->findAll('patient',array(),'record_id','desc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/patient/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function create() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Insert '.$this->title;
            $data['page_title'] = 'Insert '.$this->title;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/patient/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function edit($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Edit '.$this->title;
            $data['page_title'] = 'Edit '.$this->title;
            $data['value'] = $this->Common_model->findById('patient',array('record_id'=>$record_id)) ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/patient/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $age_year  = $this->input->post('age_year');
            $age_month = $this->input->post('age_month');
            $age_day   = $this->input->post('age_day');

            

            $dob = new DateTime();
            $dob->modify("-{$age_day} days");
            $dob->modify("-{$age_month} months");
            $dob->modify("-{$age_year} years");
            $dob = $dob->format('Y-m-d');
            $input['dob'] = $dob;

            $update_id = $input['update_id'] ;
            unset($input['update_id']);
            if($update_id == 0 || empty($update_id)){       
                $popup = $this->input->post('popup');
                if(isset($popup)){
                    unset($input['popup']);
                }
                $insert = $this->Common_model->saveData('patient', $input);
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
                if(isset($popup)){
                    $patient = $this->Common_model->findById('patient',array('record_id'=>$insert));
                    $patientAge             = calculateCurrentAge($patient);
                    $patient->patient_age   = $patientAge;
                    echo json_encode($patient);
                    exit(0);
                }
            }else{
                $update = $this->Common_model->updateData('patient', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            redirect('patient', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $id, 'patient')){
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
            redirect('patient', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
