<?php

defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Test_invoice extends MY_Controller
{
    
    

    static $helper   = array('utility');
    public function __construct()
    {
        parent::__construct();
        $this->title    = 'Invoice';
        $this->bUrl     = 'test_invoice';

        $this->loadModel('CreateBill_model');
        $this->load->model(['Common_model', 'SaleTest_model'=> 'saleModel']);
        $this->load->helper(self::$helper);
    }
    public function index()
    {
            $data['title']          = 'All '.$this->title;
            $request                = $this->input->get();
           
            $from_date              = $request['from_date']??date('Y-m-d');
            $to_date                = $request['to_date']??date('Y-m-d');
        
            $created_by             = $request['created_by'];
            $marketing_staff        = $request['marketing_staff'];
            $doctor_id              = $request['doctor_id'];
            $reference_by           = $request['reference_by'];

            $where = [
                'type' => 'Test Invoice',
                'date >=' => $from_date,
                'date <=' => $to_date,
            ];
            if (!admin()) {
                $where['show_hide'] = 'Show';
            }
            
            
            if ($created_by) $where['created_by'] = $created_by;
            if ($marketing_staff) $where['marketing_staff'] = $marketing_staff;
            if ($doctor_id) $where['doctor_id'] = $doctor_id;
            if ($reference_by) $where['reference_by'] = $reference_by;

     
            $this->data = [
                'title'             => 'All '.$this->title,
                'values'            => $this->model->where($where)->order_by('record_id', 'DESC')->all(),
                'marketing'         => $this->Common_model->findAll('staff', array(), 'record_id', 'desc'),
                'marketing_staff'   => $marketing_staff,
                'from_date'         => $from_date,
                'to_date'           => $to_date,
                'created_by'        => $created_by,
                'doctor_id'         => $doctor_id,
                'reference_by'      => $reference_by,
            ];


            $this->render('admin/test_invoice/index');
    }

    public function create()
    {

        $today = date('Y-m-d');
        $where = array();
        $where['date'] = $today;
        $where['type'] = 'Test Invoice';

        $this->data = [
             'title'                => 'Create '.$this->title,
             'test_names'           => $this->Common_model->findAll('test_name', array(), 'record_id', 'asc'),
             'invoice_list'         => $this->Common_model->findAll('create_bill', $where, 'record_id', 'desc'),
        ];

        $this->render('admin/test_invoice/create');

       
    }
    public function edit($record_id)
    {

        $today = date('Y-m-d');
        $where = array();
        $where['date'] = $today;
        $where['type'] = 'Test Invoice';
        if ($record_id) $where['record_id'] = $record_id;


        $this->data = [
             'title'                => 'Edit '.$this->title,
             'value'                => $this->model->find($record_id),
             'values'               => $this->saleModel->where('invoice_no', $record_id)->order_by('record_id', 'asc')->all(),
             'test_names'           => $this->Common_model->findAll('test_name', array(), 'record_id', 'asc'),
             'invoice_list'         => $this->Common_model->findAll('create_bill', $where, 'record_id', 'desc'),
        ];

        $this->render('admin/test_invoice/create');

    }
    public function saveOrUpdate()
    {
            $input = $this->input->post();
            $update_id = $input['update_id'];
            $this->db->trans_start();
            $invoiceId = $this->model->saveTestInvoice();
            $this->saleModel->saveBatch($invoiceId);
            $this->db->trans_complete();
            $url = $this->bUrl;
            if(!$update_id) $url .= "/view/$invoiceId";
            $this->crudAlertMessage($update_id, $url);
    }

    public function view($record_id)
    {
        $value = $this->model->find($record_id);
        $this->data = [
            'signatureType' => 'Patient',
            'recordID'      => $record_id,
            'redirect'      => base_url($this->bUrl.'/create'),
            'value'         =>  $value,
            'values'        => $this->saleModel->where('invoice_no', $record_id)->order_by('record_id', 'asc')->all(),
            'patient'       => $this->Common_model->findById('patient', ['record_id' => $value->patient_id]),
            'doctor'        => $this->Common_model->findById('doctor', ['record_id' => $value->doctor_id]),
        ];

        $this->render('admin/test_invoice/invoice');
    }
    public function view2($record_id)
    {
        redirect($this->bUrl."/view/$record_id", 'refresh'); 
    }
    
    public function patient_label($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Invoice';
            $data['page_title'] = 'Invoice';
            $data['info_header'] = '';
            $data['signatureType'] = 'Patient';
            $data['redirect'] =  base_url('test_invoice');
            $data['value'] = $this->Common_model->findById('create_bill', array('record_id' => $record_id));
            $data['values'] = $this->Common_model->findAll('sales_test', array('invoice_no' => $record_id), 'record_id', 'asc');
            if (isset($data['value'])) {
                $data['patient'] = $this->Common_model->findById('patient', array('record_id' => $data['value']->patient_id));
                $data['doctor'] = $this->Common_model->findById('doctor', array('record_id' => $data['value']->doctor_id));
            }
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_invoice/patient_label', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function patient_label2($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Invoice';
            $data['page_title'] = 'Invoice';
            $data['info_header'] = '';
            $data['signatureType'] = 'Patient';
            $data['redirect'] =  base_url('test_invoice/create');
            $data['value'] = $this->Common_model->findById('create_bill', array('record_id' => $record_id));
            $data['values'] = $this->Common_model->findAll('sales_test', array('invoice_no' => $record_id), 'record_id', 'asc');
            if (isset($data['value'])) {
                $data['patient'] = $this->Common_model->findById('patient', array('record_id' => $data['value']->patient_id));
                $data['doctor'] = $this->Common_model->findById('doctor', array('record_id' => $data['value']->doctor_id));
            }
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_invoice/patient_label', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function print_barcode($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Invoice';
            $data['page_title'] = 'Invoice';
            $data['redirect'] =  base_url('test_invoice');
            $data['record_id'] = $record_id;

            $testDetails = $this->db->select('create_bill.record_id, create_bill.date, patient.name, patient.gender, patient.age')->from('create_bill')->join('patient', 'patient.record_id = create_bill.patient_id')->where('create_bill.record_id', $record_id)->get()->row();

            $quantity = $this->input->post('quantity');
            if (isset($quantity)) {
                $barcodeList = array();
                $barcode = "assets/img/barcode/$record_id.jpg";;
                for ($i = 0; $i < $quantity; $i++) {
                    $obj = new stdClass;
                    $obj->barcode = base_url($barcode);
                    $barcodeList[] = $obj;
                }
                $data['values'] = $barcodeList;
            }
            $data['quantity'] = $quantity;
            $data['testDetails'] = $testDetails;

            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_invoice/print_barcode', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function generate_barcode()
    {
        $record_id = $this->input->post('record_id');

        $data['record_id'] = $record_id;
    }

    public function delete($id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if ($this->Common_model->delete_info('record_id', $id, 'create_bill')) {
                $this->Common_model->delete_info('invoice_no', $id, 'sales_test');
                $this->Common_model->deleteData('sales_accessories',array('invoice_id'=>$id));
                $info       = $this->Common_model->findById('lab_product_out',array('invoice_id'=>$id));
                $infoId     = ($info &&  $info->record_id)?$info->record_id:'';
                if($infoId){
                     $this->Common_model->delete_info('record_id', $infoId, 'lab_product_out');
                     $this->Common_model->delete_info('lab_product_out_id',$infoId, 'lab_product_out_details');
                }
                $code_no = $id;
                $barcode = "assets/img/barcode/$code_no.jpg";
                if (file_exists($barcode)) {
                    unlink('./' . $barcode);
                }
                $this->session->set_flashdata('message', DELETE_MSG);
            } else {
                $this->session->set_flashdata('message', DELETE_ERROR_MSG);
            }

            
            // redirect("crud/previousPage");
            // redirect('test_invoice', 'refresh');
            redirect($_SERVER['HTTP_REFERER']);
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function delete_sale_test()
    {
        $user_type = $this->session->ses_user_type;
        $record_id = $this->input->post('record_id');
        if ($user_type == "admin"  || $user_type == "staff") {
            $sales_test = $this->Common_model->findById('sales_test', array('record_id' => $record_id));
            if ($this->Common_model->delete_info('record_id', $record_id, 'sales_test')) {
                $sonologist = $this->Common_model->findById('sonologist', array('invoice_id' => $sales_test->invoice_no, 'test_category_id' => $sales_test->test_category_id, 'test_id' => $sales_test->test_id));
                if (isset($sonologist)) {
                    $this->Common_model->delete_info('record_id', $sonologist->record_id, 'sonologist');
                }
                $this->session->set_flashdata('message', DELETE_MSG);
                echo 1;
            } else {
                echo 0;
            }
            exit;
        } else {
            echo 0;
            exit;
        }
    }
    public function load_discount_type()
    {
        $discount_type = $this->input->post('discount_type');
        $options = "<option value=''>--Select--</option>";
        if ($discount_type == 1 or $discount_type == 4) {
            $references = $this->Common_model->findAll('reference_by', array(), 'record_id', 'asc');
            foreach ($references as $key => $value) {
                $staff = $this->Common_model->findById('staff', array('record_id' => $value->staff_id));
                $staff_name = isset($staff)?$staff->name:'';
                $options .= "<option value='$value->record_id' 
                    data-ultraxray='$value->ultraxray'  
                    data-xray='$value->xray'  
                    data-echo_cardiogram='$value->echo_cardiogram'  
                    data-endoscopy='$value->endoscopy' 
                    data-mri='$value->mri' 
                    data-ct_scan='$value->ct_scan' 
                    data-ecg='$value->ecg' 
                    data-hormone='$value->hormone'  
                    data-commission='$value->commission'
                    data-cbc='$value->cbc'
                    data-troponin='$value->troponin'
                    data-electrolyte='$value->electrolyte'
                    data-staff_id='$staff_name'   
                    >$value->reference_prefix$value->reference_no - $value->reference_name
                    
                </option>";
            }
        } elseif ($discount_type == 2 or $discount_type == 5) {
            $doctors = $this->Common_model->findAll('doctor', array(), 'record_id', 'asc');
            foreach ($doctors as $key => $value) {
                $options .= "<option value='$value->record_id'>$value->doctor_prefix$value->doctor_no - $value->name</option>";
            }
        } elseif ($discount_type == 3) {
            $options = "<option value='0'  data-ultraxray='0' data-xray='0'  data-echo_cardiogram='0'  data-endoscopy='0' data-commission='0' >Diagnostic</option>";
        }
        echo $options;
        exit;
    }

    public function generate_barcode_image($code_no) {
        $number = str_pad($code_no, 6, '0', STR_PAD_LEFT);
        $this->zend->load('Zend/Barcode');
        Zend_Barcode::render('code128', 'image', array('text'=>$number, 'drawText' => false, 'barHeight' => 30, 'withQuietZones' => false), array());
    }

    public function getAccessories(){

        $this->db->select("
            pn.*,
            COALESCE(in_qty.total_in,0) AS total_in,
            COALESCE(out_qty.total_out,0) AS total_out,
            (COALESCE(in_qty.total_in,0) - COALESCE(out_qty.total_out,0)) AS available_qty
        ");
        $this->db->from('product_name pn');
         $this->db->join(
        '(SELECT product_id, SUM(quantity) AS total_in
        FROM lab_product_in_details
        GROUP BY product_id) AS in_qty',
        'in_qty.product_id = pn.record_id',
        'left'
    );

    $this->db->join(
        '(SELECT product_id, SUM(quantity) AS total_out
        FROM lab_product_out_details
        GROUP BY product_id) AS out_qty',
        'out_qty.product_id = pn.record_id',
        'left'
    );

    $where = [
        'pn.type'=>'Product',
        'pn.warehouse'=>'Lab',
        'pn.product_category_generic_name_id'=>3,
    ];

        $this->db->where( $where);
        $this->db->having('available_qty >', 0);

        $query = $this->db->get();
        

        return $query->result();
    }

    private function labProductOut($invoiceId){
        $request    = $this->input->post();
        $grandQty   = isset($request['accessories_qty'])? array_sum($request['accessories_qty']): 0;
        $info       = $this->Common_model->findById('lab_product_out',array('invoice_id'=>$invoiceId));
        $infoId     = ($info &&  $info->record_id)?$info->record_id:'';
    
        if ($infoId){
            if ($grandQty <1){
                $this->Common_model->delete_info('record_id', $infoId, 'lab_product_out');
                return false;
            }
            $this->Common_model->delete_info('lab_product_out_id',$infoId, 'lab_product_out_details');
        }
        if($grandQty <1){
            return false;
        }
        $out_date   = $request['date'];
        $prefix     = str_replace('-', '', $out_date);
        $max        = $this->Common_model->findMax('lab_product_out',array('prefix'=>$prefix),'out_no');
        $out_no     = isset($max)?$max->out_no + 1 : 1 ; 

        $outData = [
            'out_date'          => $out_date, 
            'prefix'            => $prefix, 
            'patient_id'        => $request['patient_id'], 
            'invoice_id'        => $invoiceId,
            'grand_quantity'    =>  $grandQty,
            'grand_total_price' => array_sum($request['accessories_total_price']??[])??0,
        ];
        
        if(!$infoId){
            $outData['out_no'] = $out_no;
            $infoId = $this->Common_model->saveData('lab_product_out', $outData);     
        }else{
           $this->Common_model->updateData('lab_product_out', $outData,['record_id'=>$infoId]);
        }
        $record_ids = $request['accessories_id'];
        $accessoriesList = [];

        if($infoId){
            foreach ($record_ids as $key => $value) {
                if (empty($value)) {
                    continue;
                }
                 $accessoriesList[] = [
                    'lab_product_out_id'    => $infoId,
                    'out_date'              => $out_date,
                    'product_id'            => $value,
                    'quantity'              => $request['accessories_qty'][$key],
                    'unit_price'            => $request['accessories_price'][$key],
                    'total_price'           => $request['accessories_total_price'][$key],
                    'category_id'           => $request['accessories_category_id'][$key],
                 ];
            }
            $this->Common_model->save_batch('lab_product_out_details',$accessoriesList) ;

        }

    }

        public function test_wise_search()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Monthly Test Info';
            $data['page_title'] = 'Monthly Test Info';
            $data['info_header'] = 'Monthly Test Info';

            $test_type = $this->input->get('test_type');
            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $doctor_id = $this->input->get('doctor_id');
            $test_category_id = $this->input->get('test_category_id');
            $test_id = $this->input->get('test_id');

            if (!isset($from_date) && !isset($to_date) && !isset($doctor_id) && !isset($test_id)) {
                $from_date = $to_date = date('Y-m-d');
            }

            $where = array();
            if (!admin()) {
                $where['show_hide'] = 'Show';
            }
            if ($doctor_id) $where['doctor_id'] = $doctor_id;
            if ($test_category_id) $where['test_category_id'] = $test_category_id;
            if ($test_id) $where['test_id'] = $test_id;
            if (!empty($from_date) && !empty($to_date)) {
                $where['date >= '] = $from_date;
                $where['date <= '] = $to_date;
            } elseif (!empty($from_date) && empty($to_date)) {
                $where['date'] = $from_date;
            } elseif (empty($from_date) && !empty($to_date)) {
                $where['date'] = $to_date;
            }

            $data['values'] = $this->Common_model->findAllGroupByCount('sales_test', $where, 'doctor_id', 'test_id', 'record_id', 'desc');
            // dd( $data['values']);
            // var_dump($data['values']);die;
            $data['date_range'] = date('d F, Y', strtotime($from_date)) . ' to ' . date('d F, Y', strtotime($to_date));
            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;
            $data['doctor_id'] = $doctor_id;
            $data['test_category_id'] = $test_category_id;
            $data['test_id'] = $test_id;
            $data['test_type'] = $test_type;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_invoice/test_wise_search', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function dr_wise_ultra_info()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Dr wise Test Info';
            $data['page_title'] = 'Dr wise Test Info';
            $data['info_header'] = 'Dr wise Test Info';

            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $doctor_id = $this->input->get('doctor_id');
            $test_category_id = $this->input->get('test_category_id');
            $reference_by = $this->input->get('reference_by');

            if (!isset($from_date) && !isset($to_date) && !isset($doctor_id) && !isset($test_id) && !isset($reference_by)) {
                $from_date = $to_date = date('Y-m-d');
            }

            $where = array();
            if (!admin()) {
                $where['show_hide'] = 'Show';
            }
            if ($doctor_id) $where['doctor_id'] = $doctor_id;
            if ($test_category_id) $where['test_category_id'] = $test_category_id;
            if ($reference_by) $where['reference_by'] = $reference_by;
            if (!empty($from_date) && !empty($to_date)) {
                $where['date >= '] = $from_date;
                $where['date <= '] = $to_date;
            } elseif (!empty($from_date) && empty($to_date)) {
                $where['date'] = $from_date;
            } elseif (empty($from_date) && !empty($to_date)) {
                $where['date'] = $to_date;
            }

            $data['values'] = $this->Common_model->findAll('sales_test', $where, 'record_id', 'desc');
            // var_dump($data['values']);die;
            $data['date_range'] = date('d F, Y', strtotime($from_date)) . ' to ' . date('d F, Y', strtotime($to_date));
            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;
            $data['doctor_id'] = $doctor_id;
            $data['test_category_id'] = $test_category_id;
            $data['reference_by'] = $reference_by;
            $data['doctor'] = $this->Common_model->findById('doctor', array('record_id' => $doctor_id));
            $data['test_category'] = $this->Common_model->findById('test_category', array('record_id' => $test_category_id));
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_invoice/dr_wise_ultra_info', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }


    public function qrcode_image($record_id)
    {
        $invoice = $this->model->find($record_id);
        $patient = $this->Common_model->findById('patient', array('record_id' =>  $invoice->patient_id));
      
        $contact = $this->Common_model->findById('contact', array('id' => 1));
        
        
        $qr_message = $contact->c_name."\n"
        .'Inv-'.$invoice->invoice_no."\n"
        .$invoice->date."\n"
        .$patient->name."\n"
        .$patient->mobile."\n"
        .calculateCurrentAge($patient)."\n";
        
        $this->load->library('ciqrcode');
        header("Content-Type: image/png");
        $params['data'] = $qr_message;
        $params['level'] = 'H';
        $params['size'] = 3;
        $this->ciqrcode->generate($params);

    }
}
