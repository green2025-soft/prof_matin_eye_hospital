<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Product_category extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Common_model');
        $this->load->library('user_agent');
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Product Category';
            $data['page_title'] = 'Product Category';
            $data['info_header'] = 'All Product Category';
            $data['values'] = $this->Common_model->findAll('types_of_product',array(),'types_of_product','asc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/product_category/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            unset($input['update_id']);
            $types_of_product = $input['types_of_product'];
            if($update_id == 0 || empty($update_id)){       
                $getRow = $this->Common_model->findById('types_of_product',array('types_of_product'=>$types_of_product));
                if(isset($getRow)){
                    $this->session->set_flashdata('message', EXIST_MSG);
                    redirect('product_category', 'refresh');
                }
                $insert = $this->Common_model->saveData('types_of_product', $input);
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $update = $this->Common_model->updateData('types_of_product', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            redirect('product_category', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $id, 'types_of_product')){
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
           // redirect("crud/previousPage");
            redirect('product_category', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
