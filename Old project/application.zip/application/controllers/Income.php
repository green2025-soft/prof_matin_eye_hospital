<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Income extends CI_Controller
{

	static $library 	 = array('Numbertowords');
	public function __construct()
	{
		parent::__construct();
		$this->load->library(self::$library);
	}
	public function index()
	{
		$data['title'] = "Income List";
		$data['page_title'] = "Income List";
		$where = array();
		$where['status != '] = "Delete";
		$where['income_type != '] = 'Pharmacy';
		if (!admin()) {
			$where['show_hide'] = 'Show';
		}
		$data['values'] = $this->Common_model->findAll("incomes", $where, "income_date", "desc");
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/income/index', $data);
		$this->load->view('admin/layouts/footer');
	}
	public function create()
	{
		$data['title'] = "Income Entry";
		$data['page_title'] = "Income Entry";
		$data['income_heads'] = $this->Common_model->findAll('income_head', array(), 'head', 'asc');
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/income/create', $data);
		$this->load->view('admin/layouts/footer');
	}



	public function saveOrUpdate()
	{
		$update_id = $this->input->post('update_id');
		$income_type = $this->input->post('income_type');
		$patient_id = $this->input->post('patient_id');
		$income_date = $this->input->post('income_date');
		$voucher_no = $this->input->post('voucher_no');
		$comments = $this->input->post('comments');
		$income_details_ids = $this->input->post('income_details_id');

		$income_head_ids =  $this->input->post('income_head_id');
		$income_titles = $this->input->post('income_title');
		$income_amounts = $this->input->post('income_amount');
		$voucher_amount = array_sum($income_amounts);
		if (empty($update_id) || $update_id == 0) {
			$prefix  = str_replace('-', '', $income_date);
			$maxIncome = $this->Common_model->findMax('incomes', array('prefix' => $prefix), 'income_no');
			$income_no = isset($maxIncome) ? $maxIncome->income_no + 1 : 1;

			$incomeData = array(
				'income_type' => $income_type,
				'patient_id' => $patient_id,
				'prefix' => $prefix,
				'income_no' => $income_no,
				'voucher_no' => $voucher_no,
				'income_date' => $income_date,
				'voucher_amount' => $voucher_amount,
				'comments' => $comments,
			);

			$income_id = $this->Common_model->saveData('incomes', $incomeData);

			if ($income_id) {
				foreach ($income_amounts as $key => $value) {
					if ($value > 0) {
						$data = array(
							'income_id' => $income_id,
							'income_type' => $income_type,
							'income_date' => $income_date,
							'income_head_id' => $income_head_ids[$key],
							'patient_id' => $patient_id,
							'income_title' => $income_titles[$key],
							'income_amount' => $value,
						);
						$this->Common_model->saveData('income_details', $data);
					}
				}
			}
		} else {
			$income = $this->Common_model->findById('incomes', array('income_id' => $update_id));
			if ($income->income_date != $income_date) {
				$prefix  = str_replace('-', '', $income_date);
				$maxIncome = $this->Common_model->findMax('incomes', array('prefix' => $prefix), 'income_no');
				$income_no = isset($maxIncome) ? $maxIncome->income_no + 1 : 1;
			}

			$incomeData = array(
				'income_type' => $income_type,
				'patient_id' => $patient_id,
				'voucher_no' => $voucher_no,
				'income_date' => $income_date,
				'voucher_amount' => $voucher_amount,
				'comments' => $comments,
			);

			$this->Common_model->updateData('incomes', $incomeData, array('income_id' => $update_id));
			$income_id = $update_id;
			if ($income_id) {
				foreach ($income_amounts as $key => $value) {
					if ($value > 0) {
						$income_details_id = $income_details_ids[$key];
						$data = array(
							'income_id' => $income_id,
							'income_type' => $income_type,
							'income_date' => $income_date,
							'patient_id' => $patient_id,
							'income_head_id' => $income_head_ids[$key],
							'income_title' => $income_titles[$key],
							'income_amount' => $value,
						);
						if ($income_details_id) {
							$this->Common_model->updateData('income_details', $data, array('income_details_id' => $income_details_id));
						} else {
							$this->Common_model->saveData('income_details', $data);
						}
					}
				}
			}
			redirect("income/view2/$income_id");
		}
		redirect("income/view/$income_id");
	}

	public function view($income_id)
	{
		$data['title'] = "View Income";
		$data['page_title'] = "View Income";
		$data['signatureType'] = 'Staff';
		$data['redirect'] = base_url('income/create');
		$data['value'] = $this->Common_model->findById("incomes", array('income_id' => $income_id));
		$data['values'] = $this->Common_model->findAll('income_details', array('income_id' => $income_id), 'income_details_id', 'asc');
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/income/voucher', $data);
		$this->load->view('admin/layouts/footer');
	}
	public function view2($income_id)
	{
		$data['title'] = "View Income";
		$data['page_title'] = "View Income";
		$data['signatureType'] = 'Staff';
		$data['redirect'] = base_url('income');
		$data['value'] = $this->Common_model->findById("incomes", array('income_id' => $income_id));
		$data['values'] = $this->Common_model->findAll('income_details', array('income_id' => $income_id), 'income_details_id', 'asc');
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/income/voucher', $data);
		$this->load->view('admin/layouts/footer');
	}
	public function edit($income_id)
	{
		$data['title'] = "Edit Income";
		$data['page_title'] = "Edit Income";
		$data['income_heads'] = $this->Common_model->findAll('income_head', array(), 'head', 'asc');
		$data['value'] = $this->Common_model->findById('incomes', array('income_id' => $income_id));
		$data['values'] = $this->Common_model->findAll('income_details', array('income_id' => $income_id, 'status' => 'Active'), 'income_details_id', 'asc');
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/income/create', $data);
		$this->load->view('admin/layouts/footer');;
	}
	public function delete($id)
	{
		$user_type = $this->session->ses_user_type;
		if ($user_type == "admin"  || $user_type == "staff") {
			$income = $this->Common_model->findById('incomes', array('income_id' => $id));
			if (isset($income)) {
				$this->Common_model->delete_info('income_id', $id, 'incomes');
				$this->Common_model->delete_info('income_id', $id, 'income_details');
				$this->session->set_flashdata('message', DELETE_MSG);
			} else {
				$this->session->set_flashdata('message', DELETE_ERROR_MSG);
			}
			redirect('income', 'refresh');
		} else {
			$data['wrong_msg'] = "";
			$this->load->view('website/login_check', $data);
		}
	}
	public function pharmacy_income_list()
	{
		$data['title'] = "Income List";
		$data['page_title'] = "Income List";
		
		$where = array() ;
		if (!admin()) {
			$where['show_hide'] = 'Show';
		  }
		$where['status != '] = 'Delete';
		$where['income_type'] = 'Pharmacy';
		$data['income_type'] = 'Pharmacy';
		$data['values'] = $this->Common_model->findAll("incomes",$where,"income_id","desc");
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/income/index', $data);
		$this->load->view('admin/layouts/footer');
	}
	public function create_pharmacy_income()
	{
		$data['income_type'] = 'Pharmacy';
		$data['title'] = "Income Entry";
		$data['page_title'] = "Income Entry";
		$data['income_heads'] = $this->Common_model->findAll('income_head', array(),'head','asc');
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/income/create', $data);
		$this->load->view('admin/layouts/footer');
	}
}
