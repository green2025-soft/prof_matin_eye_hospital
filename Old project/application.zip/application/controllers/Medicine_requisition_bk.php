<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Medicine_requisition extends CI_Controller {
	
	static $library 	 = array('user_agent','Numbertowords');
	static $model 	 = array('Common_model');
	static $helper 	 = array('utility');

	public function __construct(){
		parent::__construct();
		$this->load->model(self::$model);
		$this->load->library(self::$library);
		$this->load->helper(self::$helper);
	}
	public function request()
	{
		$data['title'] = "Requisition Request List";
		$data['page_title'] = "Requisition Request List";
		$data['info_header'] = "";
		$data['requisition_status'] = 'request';
		$data['values'] = $this->Common_model->findAll("medicine_requisitions",array("status != "=>"Delete"),"medicine_requisition_id","desc");
		$this->load->view('admin/layouts/header');
        $this->load->view('admin/medicine_requisition/index', $data);
        $this->load->view('admin/layouts/footer');
	}

	public function approved()
	{
		$data['title'] = "Requisition Request List";
		$data['page_title'] = "Requisition Request List";
		$data['info_header'] = "";
		$data['requisition_status'] = 'approved';
		$data['values'] = $this->Common_model->findAll("medicine_requisitions",array("status != "=>"Delete"),"medicine_requisition_id","desc");
		$this->load->view('admin/layouts/header');
        $this->load->view('admin/medicine_requisition/index', $data);
        $this->load->view('admin/layouts/footer');
	}

	public function create()
	{
		$data['title'] = "Requisition Request";
		$data['page_title'] = "Requisition Request";
		$data['info_header'] = "";
		$where = array('type'=>'Medicine');
		$options = array(
			'joins' => array(
				array(
					'table' => 'units',
					'condition' => 'units.record_id = product_name.unit_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'generic_names',
					'condition' => 'generic_names.record_id = product_name.product_category_generic_name_id',
					'jointype' => 'LEFT'
				),
			),
			'select' => 'product_name.*,units.unit_short_name,generic_names.generic_name',
			'where' => $where,
			'order' => array(
				'product_name.product_name' => 'asc',
			),
		);
		$data['products'] = $this->Common_model->commonJoins("product_name", $options);
		//var_dump($data['products']);die;
		$this->load->view('admin/layouts/header');
        $this->load->view('admin/medicine_requisition/create', $data);
        $this->load->view('admin/layouts/footer');
	}
	public function saveOrUpdate()
	{
		$data = $_POST;

		$update_id = $data['update_id'];
		$medicine_requisition_details_ids = $data['medicine_requisition_details_id'];
		$requisition_date = $data['requisition_date'];
		$product_ids = $data['product_id'];
		$order_qtys = $data['order_qty'];
		$sales_prices = $data['sales_price'];
		$purchase_prices = $data['purchase_price'];
		$unit_ids = $data['unit_id'];
		$unit_names = $data['unit_name'];
		$sub_totals = $data['sub_total'];
		$net_totals = $data['net_total'];
		unset($data['update_id']);
		unset($data['medicine_requisition_details_id']);
		unset($data['product_id']);
		unset($data['sales_price']);
		unset($data['purchase_price']);
		unset($data['order_qty']);
		unset($data['unit_id']);
		unset($data['unit_name']);
		unset($data['sub_total']);
		unset($data['net_total']);
		//var_dump($data);die;
		if($update_id == 0){
			$prefix = str_replace('-', '', $requisition_date);
			$maxMedicineRequisition = $this->Common_model->findMax('medicine_requisitions',array('prefix'=>$prefix),'requisition_no');
			$data['prefix'] = $prefix ;
			$requisition_no = isset($maxMedicineRequisition)?$maxMedicineRequisition->requisition_no + 1 : 1 ;
			$data['requisition_no'] = $requisition_no ;
			$insert = $this->Common_model->saveData('medicine_requisitions',$data);
			if($insert){
				foreach ($product_ids as $key => $value) {
					$purchaseDetails = array(
						'medicine_requisition_id'=>$insert,
						'requisition_type'=>$data['requisition_type'],
						'product_id'=>$product_ids[$key],
						'unit_id'=>$unit_ids[$key],
						'unit_name'=>$unit_names[$key],
						'sales_price'=>$sales_prices[$key],
						'purchase_price'=>$purchase_prices[$key],
						'order_qty'=>$order_qtys[$key],
						'sub_total'=>$sub_totals[$key],
						'net_total'=>$net_totals[$key],
					);
					$this->Common_model->saveData('medicine_requisition_details',$purchaseDetails);
				}
				$this->session->set_userdata('alertMsg',INSERT_MSG);
			}else{
				$this->session->set_userdata('alertMsg',INSERT_ERROR_MSG);
			}
		}else{
			$requisition = $this->Common_model->findById('medicine_requisitions',array('medicine_requisition_id'=>$update_id));
			$prefix = str_replace('-', '', $requisition_date);
			$maxMedicineRequisition = $this->Common_model->findMax('medicine_requisitions',array('prefix'=>$prefix),'requisition_no');
			$data['prefix'] = $prefix ;
			$requisition_no = isset($maxMedicineRequisition)?$maxMedicineRequisition->requisition_no + 1 : 1 ;
			if($requisition->requisition_date == $requisition_date){
				$data['requisition_no'] = $requisition->requisition_no ;
			}else{
				$data['requisition_no'] = $requisition_no ;
			}
			$update = $this->Common_model->updateData('medicine_requisitions',$data,array('medicine_requisition_id'=>$update_id));
			if($update){
				foreach ($product_ids as $key => $value) {
					$purchaseDetails = array(
						'medicine_requisition_id'=>$update_id,
						'product_id'=>$product_ids[$key],
						'unit_id'=>$unit_ids[$key],
						'unit_name'=>$unit_names[$key],
						'sales_price'=>$sales_prices[$key],
						'purchase_price'=>$purchase_prices[$key],
						'order_qty'=>$order_qtys[$key],
						'sub_total'=>$sub_totals[$key],
						'net_total'=>$net_totals[$key],
					);
					$medicine_requisition_details_id = $medicine_requisition_details_ids[$key];
					if($medicine_requisition_details_id){
						$this->Common_model->updateData('medicine_requisition_details',$purchaseDetails,array('medicine_requisition_details_id'=>$medicine_requisition_details_id));
					}else{
						$this->Common_model->saveData('medicine_requisition_details',$purchaseDetails);
					}
				}
				if($update){
					$this->session->set_userdata('alertMsg',UPDATE_MSG);
				}else{
					$this->session->set_userdata('alertMsg',UPDATE_ERROR_MSG);
				}
			}
		}
		redirect("medicine_requisition");
	}

	public function edit($medicine_requisition_id)
	{
		$data['title'] = "Requisition Request Requisition";
		$data['page_title'] = "Requisition Request Requisition";
		$data['info_header'] = "";
		$where = array();
		$options1 = array(
			'joins' => array(
				array(
					'table' => 'units',
					'condition' => 'units.record_id = product_name.unit_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'generic_names',
					'condition' => 'generic_names.record_id = product_name.product_category_generic_name_id',
					'jointype' => 'LEFT'
				),
			),
			'select' => 'product_name.*,units.unit_short_name,generic_names.generic_name',
			'where' => $where,
			'order' => array(
				'product_name.product_name' => 'asc',
			),
		);
		$data['products'] = $this->Common_model->commonJoins("product_name", $options1);

		$data['value'] = $this->Common_model->findById('medicine_requisitions',array('medicine_requisition_id'=>$medicine_requisition_id));
		$data['patient'] = $this->Common_model->findById('patient',array('record_id'=>$data['value']->patient_id));
        //var_dump($data['value']);die;
		$where = array('medicine_requisition_details.medicine_requisition_id '=>$medicine_requisition_id);
		$options = array(
			'joins' => array(
				array(
					'table' => 'product_name',
					'condition' => 'product_name.record_id = medicine_requisition_details.product_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'units',
					'condition' => 'units.record_id = medicine_requisition_details.unit_id',
					'jointype' => 'LEFT'
				),
			),
			'select' => 'medicine_requisition_details.*,product_name.product_name,units.unit_short_name',
			'where' => $where,
			'order' => array(
				'medicine_requisition_details.medicine_requisition_details_id' => 'asc',
			),
		);
		$data['values'] = $this->Common_model->commonJoins("medicine_requisition_details", $options);
		$this->load->view('admin/layouts/header');
        $this->load->view('admin/medicine_requisition/create', $data);
        $this->load->view('admin/layouts/footer');
	}
	public function view($medicine_requisition_id)
	{
		$data['title'] = "View Requisition";
		$data['page_title'] = "View Requisition";
		$data['info_header'] = "";
		$data['signatureType'] = 'Patient';
		$data['redirect'] = base_url('medicine_requisition');
		$data['value'] = $this->Common_model->findById('medicine_requisitions',array('medicine_requisition_id'=>$medicine_requisition_id));
		$data['patient'] = $this->Common_model->findById('patient',array('record_id'=>$data['value']->patient_id));

		$where = array('medicine_requisition_details.medicine_requisition_id '=>$medicine_requisition_id);
		$options = array(
			'joins' => array(
				array(
					'table' => 'product_name',
					'condition' => 'product_name.record_id = medicine_requisition_details.product_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'generic_names',
					'condition' => 'generic_names.record_id = product_name.product_category_generic_name_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'units',
					'condition' => 'units.record_id = medicine_requisition_details.unit_id',
					'jointype' => 'LEFT'
				),

			),
			'select' => 'medicine_requisition_details.*,product_name.product_name,product_name.product_category,units.unit_short_name,generic_names.generic_name',
			'where' => $where,
			'order' => array(
				'medicine_requisition_details.medicine_requisition_details_id' => 'asc',
			),
		);
		$data['values'] = $this->Common_model->commonJoins("medicine_requisition_details", $options);
		$this->load->view('admin/layouts/header');
        $this->load->view('admin/medicine_requisition/invoice', $data);
        $this->load->view('admin/layouts/footer');
	}

	public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('medicine_requisition_id', $id, 'medicine_requisitions')){
            	$this->Common_model->delete_info('medicine_requisition_id',$id,'medicine_requisition_details');
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
            redirect('medicine_requisition', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function checked($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->updateData('medicine_requisitions', array('requisition_status'=>'Delivered'), array('medicine_requisition_id'=>$id))){
                $this->session->set_flashdata('message',UPDATE_MSG);
            }else{
                $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
            }
            redirect('medicine_requisition/approved', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function load_product(){
    	$requisition_type = $this->input->post('requisition_type');
    	//$products = $this->Common_model->findAll('product_name',array('type'=>$purchase_type),'product_name','asc');

    	$where = array();
    	$where['type'] = $requisition_type ;
		$options = array(
			'joins' => array(
				array(
					'table' => 'units',
					'condition' => 'units.record_id = product_name.unit_id',
					'jointype' => 'LEFT'
				),
				array(
					'table' => 'generic_names',
					'condition' => 'generic_names.record_id = product_name.product_category_generic_name_id',
					'jointype' => 'LEFT'
				),
			),
			'select' => 'product_name.*,units.unit_short_name,generic_names.generic_name',
			'where' => $where,
			'order' => array(
				'product_name.product_name' => 'asc',
			),
		);
		$products = $this->Common_model->commonJoins("product_name", $options);

    	$option = "<option value=''>--Select $requisition_type--</option>";

    	foreach ($products as $key => $value) {
    		$product_category = !empty($value->product_category)?' - '.$value->product_category:'' ;
    		$generic_name = !empty($value->generic_name)?' - '.$value->generic_name:'' ;
			$option .= '<option value='.$value->record_id.' data-purchase_price='.$value->purchase_price.' data-sales_price='.$value->sales_price.' data-unit_id='.$value->unit_id.' data-unit_name='.$value->unit_short_name.' data-product_name='.$value->product_name.'>'.$value->product_name.$product_category.$generic_name.'</option>';    		
    	}
    	echo $option ;
    	exit;
    }


}


