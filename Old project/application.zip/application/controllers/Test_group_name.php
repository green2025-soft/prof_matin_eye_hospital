<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Test_group_name extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Test Group Name';
            $data['page_title'] = 'Test Group Name';
            $data['info_header'] = 'All Test Group Name';
            $data['values'] = $this->Common_model->findAll('test_group_name',array(),array('group_name'),'asc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_group_name/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            $is_popup = $input['is_popup'] ;
            unset($input['update_id']);
            unset($input['is_popup']);
            $group_name = $input['group_name'];
            if($update_id == 0 || empty($update_id)){       
                $getRow = $this->Common_model->findById('test_group_name',array('group_name'=>$group_name));
                if(isset($getRow)){
                    $this->session->set_flashdata('message', EXIST_MSG);
                    redirect('test_group_name', 'refresh');
                }
                $insert = $this->Common_model->saveData('test_group_name', $input);
                if($is_popup == 1){
                    echo $insert;
                    exit;
                }
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $update = $this->Common_model->updateData('test_group_name', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            redirect('test_group_name', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $id, 'test_group_name')){
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
           // redirect("crud/previousPage");
            redirect('test_group_name', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function getAll(){

        $values = $this->Common_model->findAll('test_group_name',[],"record_id","asc") ;
        $options = "<option value=''>--Select--</option>" ;
        foreach ($values as $key => $value) {
            $options .= "<option value='$value->record_id'>$value->record_id - $value->group_name</option>" ;
        }
        echo $options ;
        exit;
    }
}
