<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Test_field extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }

    public function index($test_cat_id = 0, $test_name_id = 0) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Test Name';
            $data['page_title'] = 'Test Field';
            $data['info_header'] = 'All Test Fields';
            $where = [];
            if($test_name_id > 0){
                $where['test_name_id'] = $test_name_id;
            }
            if($test_cat_id > 0){
                $where['test_cat_id'] = $test_cat_id;
            }
            $lastValue = $this->Common_model->findFirstOrLast('test_fields', array(), 'record_id', 'desc');
            $data['last_category'] = isset($lastValue->test_category_id) ? $lastValue->test_category_id : 0;
            $data['last_test_name_id'] = isset($lastValue->test_name_id) ? $lastValue->test_name_id : 0;
            $data['last_test_group_id'] = isset($lastValue->test_group_id) ? $lastValue->test_group_id : 0;
            // $data['values'] = $this->Common_model->findAll('test_fields', $where, array('field_name'),'asc') ;
            $data['values'] = $this->Common_model->getTestFields($test_cat_id, $test_name_id) ;
            // ddd($data['values']);
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_field/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST;
            // ddd($_POST);
            $update_id = $input['update_id'] ;
            unset($input['update_id']);
            $field_name = $input['field_name'];
            $test_category_id = $input['test_category_id'];
            $test_name_id = $input['test_name_id'];
            if($update_id == 0 || empty($update_id)){       
                $getRow = $this->Common_model->findById('test_fields',array('field_name'=>$field_name,  'test_name_id'=> $test_name_id, 'test_category_id'=>$test_category_id));
                if(isset($getRow)){
                    $this->session->set_flashdata('message', EXIST_MSG);
                    redirect('test_field', 'refresh');
                }
                $insert = $this->Common_model->saveData('test_fields', $input);
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $update = $this->Common_model->updateData('test_fields', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            redirect('test_field', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $id, 'test_fields')){
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
           // redirect("crud/previousPage");
            redirect('test_field', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function get_testName_by_category()
    {
        $test_category_id = $this->input->post('test_category_id');
        $values = $this->Common_model->findAll('test_name',array('test_category_id'=>$test_category_id),"record_id","asc") ;
        $options = "<option value=''>--Select--</option>" ;
        foreach ($values as $key => $value) {
            $options .= "<option value='$value->record_id'>$value->record_id - $value->test_name</option>" ;
        }
        echo $options ;
        exit;
    }
}
