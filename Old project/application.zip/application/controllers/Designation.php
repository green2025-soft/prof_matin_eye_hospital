<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Designation extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Designation/Degree';
            $data['page_title'] = 'Designation/Degree';
            $data['info_header'] = 'All Designation/Degree';
            $data['values'] = $this->Common_model->findAll('designation',array(),'designation','asc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/designation/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $popup = $this->input->post('popup');
            if(isset($popup)){
                unset($input['popup']);
            }
            $update_id = $input['update_id'] ;
            unset($input['update_id']);
            $designation = $input['designation'];
            if($update_id == 0 || empty($update_id)){       
                $getRow = $this->Common_model->findById('designation',array('designation'=>$designation));
                if(isset($getRow)){
                    $this->session->set_flashdata('message', EXIST_MSG);
                    if(isset($popup)){
                        echo 0;
                        exit;
                    }
                    redirect('designation', 'refresh');
                }
                $insert = $this->Common_model->saveData('designation', $input);
                $record_id = $insert;
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $update = $this->Common_model->updateData('designation', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            if(isset($popup)){
                $designation = $this->Common_model->findById('designation',array('record_id'=>$record_id));
                echo json_encode($designation);
                exit;
            }
            redirect('designation', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $id, 'designation')){
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
           // redirect("crud/previousPage");
            redirect('designation', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
