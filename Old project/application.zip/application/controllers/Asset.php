<?php

defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Asset extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
    }
    public function index()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'All Asset';
            $data['page_title'] = 'Asset';
            $data['info_header'] = 'All Asset';

            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $item_id = $this->input->get('item_id');
            if (!isset($from_date) && !isset($to_date)) {
                $from_date = $to_date = date('Y-m-d');
            }
            $where = array();
            if (!admin()) {
                $where['show_hide'] = 'Show';
            }
            if($item_id) $where['item_id'] = $item_id ;
            if (!empty($from_date) && !empty($to_date)) {
                $where['date >= '] = $from_date;
                $where['date <= '] = $to_date;
            } elseif (!empty($from_date) && empty($to_date)) {
                $where['date'] = $from_date;
            } elseif (empty($from_date) && !empty($to_date)) {
                $where['date'] = $to_date;
            }
            $data['values'] = $this->Common_model->findAll("assets", $where, "record_id", "desc");
            $data['item_id'] = $item_id;
            $data['from_date'] = $from_date;
            $data['to_date'] = $to_date;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/assets/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function create()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Asset';
            $data['page_title'] = 'Asset';
            $data['info_header'] = 'All Asset';
            $data['in_values'] = $this->Common_model->findAll('assets', array(), 'record_id', 'desc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/assets/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function edit($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Asset';
            $data['page_title'] = 'Asset';
            $data['info_header'] = 'All Asset';
            $data['value'] = $this->Common_model->findById('assets', array('record_id' => $record_id));
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/assets/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function view($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Asset';
            $data['page_title'] = 'Asset';
            $data['info_header'] = 'All Asset';
            $data['redirect'] = base_url('assets/create');
            $data['signatureType'] = "Staff";
            $data['value'] = $this->Common_model->findById('assets', array('record_id' => $record_id));
            $data['supplier'] = $this->Common_model->findById('suppliers', array('record_id' => $data['value']->supplier_id));
            $data['values'] = $this->Common_model->findAll('assets_details', array('assets_id' => $record_id), 'record_id', 'asc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/assets/invoice', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function view2($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Asset';
            $data['page_title'] = 'Asset';
            $data['info_header'] = 'All Asset';
            $data['redirect'] = base_url('assets');
            $data['signatureType'] = "Staff";
            $data['value'] = $this->Common_model->findById('assets', array('record_id' => $record_id));
            $data['supplier'] = $this->Common_model->findById('suppliers', array('record_id' => $data['value']->supplier_id));
            $data['values'] = $this->Common_model->findAll('assets_details', array('assets_id' => $record_id), 'record_id', 'asc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/assets/invoice', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST;
            $update_id = $input['update_id'];
            unset($input['update_id']);
            if ($update_id == 0 || empty($update_id)) {
                $insert = $this->Common_model->saveData('assets', $input);
                $this->session->set_flashdata('message', INSERT_MSG);
            } else {
                //$info = $this->Common_model->findById('assets', array('record_id' => $update_id));
                $update = $this->Common_model->updateData('assets', $input, array('record_id' => $update_id));
                $this->session->set_flashdata('message', UPDATE_MSG);
            }
            redirect('asset', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }


    public function delete($id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if ($this->Common_model->delete_info('record_id', $id, 'assets')) {
                $this->session->set_flashdata('message', DELETE_MSG);
            } else {
                $this->session->set_flashdata('message', DELETE_ERROR_MSG);
            }
            redirect('asset', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function load_products()
    {
        $purchase_request_id = $this->input->post('purchase_request_id');
        $data['value'] = $this->Common_model->findById('purchase_request', array('record_id' => $purchase_request_id));
        $data['values'] = $this->Common_model->findAll('purchase_request_details', array('purchase_request_id' => $purchase_request_id), "record_id", "asc");
        $this->load->view("admin/assets/product_list", $data);
    }

    public function approved($record_id)
    {
        $bill = $this->Common_model->findById('assets', array('record_id' => $record_id));
        if (isset($bill)) {
            $status = '';
            if ($bill->approval == 'Unpaid') {
                $status = 'paid';
            } else {
                $status = 'Unpaid';
            }
            $this->Common_model->updateData('assets', array('approval' => $status), array('record_id' => $record_id));
            $this->Common_model->updateData('assets_details', array('approval' => $status), array('purchase_request_id' => $record_id));
            $this->session->set_flashdata('message', UPDATE_MSG);
        } else {
            $this->session->set_flashdata('message', UPDATE_ERROR_MSG);
        }
        // redirect('test_honorarium/appointment', 'refresh');
        redirect($_SERVER['HTTP_REFERER']);
    }
}
