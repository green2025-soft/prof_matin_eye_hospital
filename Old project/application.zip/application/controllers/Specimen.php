<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Specimen extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Specimen Collection';
            $data['page_title'] = 'Specimen Collection';
            $data['info_header'] = 'All Specimen Collection';
            $data['values'] = $this->Common_model->findAll('specimens',array(),'record_id','desc');
            $data['invoices'] = $this->getInvoiceData();
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/specimen/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST;
            $update_id = $input['update_id'];
            // ddd($_POST);
            unset($input['update_id']);
            if($update_id == 0 || empty($update_id)){       
                // $insert = $this->Common_model->saveData('specimens', $input);
                foreach($_POST['sales_test_id'] as $test_id){
                    $sales_test = $this->Common_model->findById('sales_test',array('record_id '=>$test_id));
                    $insertArr[] = [
                        "invoice_id" => $_POST['invoice_id'],
                        "sales_test_id" => $test_id,
                        'test_category_id'=> $sales_test->test_category_id,
                        "patient_id" => $_POST['patient_id'],
                        "status" => $_POST['status'],
                        "specimen" => $_POST['specimen'],
                    ];
                }

                $res = $this->db->insert_batch('specimens', $insertArr);

                if($res){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{

                $input['sales_test_id'] = $_POST['sales_test_id'][0];

                $update = $this->Common_model->updateData('specimens', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            redirect('specimen', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $id, 'specimens')){
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
           // redirect("crud/previousPage");
            redirect('specimen', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function load_invoice_tests()
    {
        $invoice_id = $this->input->post('invoice_id') ;
        $where = array();
        // $where['type'] = 'Test';
        $where['invoice_no'] = $invoice_id ;
        $sales_test = $this->Common_model->findAll('sales_test',$where,'record_id','asc');
        $str = '<option value="">--Select--</option>';
        foreach ($sales_test as $key => $value) {
            $str .= '<option value="'.$value->record_id.'">'.$value->test_name.'</option>';
        }
        echo $str ;
        exit ;
    }

    private function getInvoiceData(){

        $this->db->select('create_bill.record_id,invoice_no, create_bill.patient_id, patient.name as patient_name')
                 ->from('create_bill')->join('patient', 'patient.record_id = create_bill.patient_id')
                 ->where('create_bill.type', 'Test Invoice')
                 ->order_by('create_bill.record_id', 'desc');

        $invoiceData = $this->db->get()->result();

        $invoiceOptions = '<option value="">Select Invoice</option>';

        foreach($invoiceData as $row){
            $invoiceOptions.="<option value='$row->record_id' data-patient_id='$row->patient_id'>$row->invoice_no - $row->patient_name</option>";
        }

        return $invoiceOptions;

    }

    public function test_barcode($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['value'] = $this->Common_model->findById('specimens',array('record_id'=>$record_id));
            $this->load->view('admin/specimen/test_barcode', $data);
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
        
    }

   
}
