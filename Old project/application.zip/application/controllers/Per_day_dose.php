<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Per_day_dose extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff" || $user_type == "doctor") {
            $data['title'] = 'Per Day Dose';
            $data['page_title'] = 'Per Day Dose';
            $data['info_header'] = 'All Per Day Dose';
            $data['values'] = $this->Common_model->findAll('per_day_dosages',array(),'record_id','desc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/per_day_dose/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff" || $user_type == "doctor") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            unset($input['update_id']);
            $popup = $this->input->post('popup');
            if(isset($popup)){
                unset($input['popup']);     
            }
            $name = $input['name'];
            if($update_id == 0 || empty($update_id)){       
                $getRow = $this->Common_model->findById('per_day_dosages',array('name'=>$name));
                if(isset($getRow)){
                    $this->session->set_flashdata('message', EXIST_MSG);
                    redirect('meal_type', 'refresh');
                }
                $insert = $this->Common_model->saveData('per_day_dosages', $input);
                $record_id = $insert ;
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $update = $this->Common_model->updateData('per_day_dosages', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            if(isset($popup)){
                $meal_type = $this->Common_model->findById('per_day_dosages',array('record_id'=>$record_id));
                echo json_encode($meal_type);
                exit;
            }
            redirect('per_day_dose', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff" || $user_type == "doctor") {
            if($this->Common_model->delete_info('record_id', $id, 'per_day_dosages')){
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
           // redirect("crud/previousPage");
            redirect('per_day_dose', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
