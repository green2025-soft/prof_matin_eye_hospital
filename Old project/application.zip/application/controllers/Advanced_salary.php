<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Advanced_salary extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Advanced Salary List';
            $data['page_title'] = 'Advanced Salary List';
            $data['info_header'] = '';

            $where = array() ;

            $month = $this->input->get('month');
            $year = $this->input->get('year');
          ///  $date = $this->input->get('date');
            $employee_id = $this->input->get('employee_id');

            if(!isset($month) && !isset($year)  && !isset($employee_id)){
                $date = date('Y-m-d');
            }

            if($year) $where['year'] = $year ;
            if($month) $where['month'] = $month ;
          //  if($date) $where['date'] = $date ;
            if($employee_id) $where['employee_id'] = $employee_id ;

          //  var_dump($where);die;
            $data['values'] = $this->Common_model->findAll('create_salary_sheet_advanced',$where,'record_id','asc');
            $data['year'] = $year;
            $data['month'] = $month;
            $data['date'] = $date;
            $data['employee_id'] = $employee_id;
            $month_year = '' ;
            if(!empty($month) && !empty($year)){
                $monthNum  = $month;
                $monthName = date('F', mktime(0, 0, 0, $monthNum)); 
                $month_year = $monthName .' , '. $year ;
            }elseif(!empty($month) && empty($year)){
                $monthNum  = $month;
                $monthName = date('F', mktime(0, 0, 0, $monthNum)); 
                $month_year = $monthName ; 
            }elseif(empty($month) && !empty($year)){
                $month_year = $year ; 
            }
            
            $data['month_year'] = $month_year ; 
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/salary_payment_advanced/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function payment() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Advance Salary';
            $data['page_title'] = 'Advance Salary';
            $data['info_header'] = '';
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/salary_payment_advanced/payment', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $salary_ids = $this->input->post('advanced_id');
            $employee_ids = $this->input->post('employee_id');
            
            $insert = 0 ;
            $month = $this->input->post('month');
            $month_name = $this->input->post('month_name');
            $date = $this->input->post('date');
            $year = $this->input->post('year');
            $advanced_amounts = $this->input->post('advanced_amount');
           // var_dump($salary_ids) ;die ;
            foreach ($salary_ids as $key => $value) {
                    $insert_data = array(
                        'date' => $date,
                        'employee_id' => $employee_ids[$key],
                        'month_name' => $month_name,
                        'month' => $month,
                        'year' => $year,
                        'advanced_amount' => $advanced_amounts[$key],
                );
              if($value){
                 $this->Common_model->updateData('create_salary_sheet_advanced', $insert_data,array('record_id'=>$value));
                 $insert = 1 ;
               }else{
                   $insert =  $this->Common_model->saveData('create_salary_sheet_advanced', $insert_data);
               }
            }
            if($insert){
                $this->session->set_flashdata('message',INSERT_MSG);
            }else{
                $this->session->set_flashdata('message',INSERT_ERROR_MSG);
            }
            
            redirect('advanced_salary');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function staff_information() {
        $employee_id = $this->input->post('employee_id');
        $data['month'] = $this->input->post('month');
        $data['year'] = $this->input->post('year');
        //var_dump($data['year']) ; die;
        $where = array() ;
        if(!empty($employee_id)) $where['record_id'] = $employee_id ;
        $data['all_staff'] = $this->Common_model->findAll('staff',$where,'record_id','asc');
        $this->load->view('admin/salary_payment_advanced/staff_information', $data);
    }

    public function approved_reject_salary_sheet(){
        $salary_sheet_ids = $this->input->post('salary_sheet_id');
        foreach ($salary_sheet_ids as $key => $value) {
            $data = array(
                'status' => 'Paid'
            );
            $this->Common_model->updateData('create_salary_sheet_advanced',$data,array('record_id'=>$value));
        }
        $this->session->set_flashdata('message',"success_Approved Successful.");
        redirect($_SERVER['HTTP_REFERER']);
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $id, 'create_salary_sheet_advanced')){
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
            redirect($_SERVER['HTTP_REFERER']);
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
