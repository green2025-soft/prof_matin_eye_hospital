<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Sales_test extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Sales Test';
            $data['page_title'] = 'Sales Test';
            $data['info_header'] = 'All Sales Test';

            $from_date = $this->input->get('from_date');
            $to_date = $this->input->get('to_date');
            $patient_id = $this->input->get('patient_id');

            $where = array() ;
            $today = date('Y-m-d');
            if(!isset($patient_id) && !isset($from_date) && !isset($to_date)){
                $where['date'] = $today ;
            }

            $where['type'] = "Test Invoice" ;
            if(!empty($patient_id)) $where['patient_id'] = $patient_id ;
            if(!empty($from_date) && !empty($to_date)){
                $where['date >= '] = $from_date ;
                $where['date <= '] = $to_date ;
            }else if(!empty($from_date) && empty($to_date)){
                $where['date'] = $from_date ;
            }else if(empty($from_date) && !empty($to_date)){
                $where['date'] = $to_date ;
            }
            $data['values'] = $this->Common_model->findAll('create_bill',$where,'record_id','desc') ;
            $data['from_date'] = $from_date ;
            $data['to_date'] = $to_date ;
            $data['patient_id'] = $patient_id ;
            //var_dump($where);die;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/sales_test/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function view($record_id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Test Invoice';
            $data['page_title'] = 'Test Invoice';
            $data['signatureType'] = 'Patient';
            $data['redirect'] = base_url("sales_test");
            $data['value'] = $this->Common_model->findById('create_bill',array('record_id'=>$record_id));
            $data['values'] = $this->Common_model->findAll('sales_test',array('invoice_no'=>$record_id),'record_id','asc');
            if(isset($data['value'])){
                $data['patient'] = $this->Common_model->findById('patient',array('record_id'=>$data['value']->patient_id));
                $data['doctor'] = $this->Common_model->findById('doctor',array('record_id'=>$data['value']->doctor_id));
            }
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/test_invoice/invoice', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
	
	public function generate_barcode_image($code_no) {
        $number = str_pad($code_no, 6, '0', STR_PAD_LEFT);
        $this->zend->load('Zend/Barcode');
        Zend_Barcode::render('code128', 'image', array('text'=>$number, 'drawText' => TRUE), array());

        
    }
}
