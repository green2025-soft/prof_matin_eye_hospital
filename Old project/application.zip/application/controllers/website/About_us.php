<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class About_us extends CI_Controller
{
    public function __construct() {
        parent::__construct();
    }
    public function index()
    {
        $data['title'] = "About Us";
        $data['active'] = 'About Us';
        $output['page_title'] = "About Us";
        $output['value'] = $this->Common_model->findById('contact',array());
        $data['content'] = $this->load->view('website/about_us/index',$output,TRUE);
        $this->load->view("website/layouts/master",$data);
    }
}
