<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class News extends CI_Controller
{
    public function __construct() {
        parent::__construct();
        $this->load->helper('text');
    }
    public function index()
    {
        $data['title'] = "Our News";
        $data['active'] = 'News';
        $output['page_title'] = "Our News";
        $output['values'] = $this->Common_model->findAll('news',array(),'record_id','asc');
        $data['content'] = $this->load->view('website/news/index',$output,TRUE);
        $this->load->view("website/layouts/master",$data);
    }
    public function details($record_id)
    {
        $data['title'] = "News Details";
        $data['active'] = 'News';
        $output['page_title'] = "News Details";
        $output['value'] = $this->Common_model->findById('news',array('record_id'=>$record_id));
        $data['content'] = $this->load->view('website/news/details',$output,TRUE);
        $this->load->view("website/layouts/master",$data);
    }
}
