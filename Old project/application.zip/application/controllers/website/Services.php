<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Services extends CI_Controller
{
    public function __construct() {
        parent::__construct();
    }
    public function index()
    {
        $data['title'] = "Our Services";
        $data['active'] = 'Services';
        $output['page_title'] = "Our Services";
        $output['services'] = $this->Common_model->findAll('services',array(),'record_id','asc');
        $data['content'] = $this->load->view('website/services/index',$output,TRUE);
        $this->load->view("website/layouts/master",$data);
    }
    public function details($record_id)
    {
        $data['title'] = "Our Services Details";
        $data['active'] = 'Services';
        $output['page_title'] = "Our Services Details";
        $output['value'] = $this->Common_model->findById('services',array('record_id'=>$record_id));
        $data['content'] = $this->load->view('website/services/details',$output,TRUE);
        $this->load->view("website/layouts/master",$data);
    }
}
