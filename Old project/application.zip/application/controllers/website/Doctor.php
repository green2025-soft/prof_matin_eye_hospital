<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Doctor extends CI_Controller
{
    public function __construct() {
        parent::__construct();
        $this->load->helper('text');
    }
    public function index()
    {
        $data['title'] = "Our Doctors";
        $data['active'] = 'Doctors';
        $output['page_title'] = "Our Doctors";
        $output['values'] = $this->Common_model->findAllGroupBy('doctor',array('department != '=>''),'department','record_id','asc');
        //var_dump($output['values']) ; die;
        $data['content'] = $this->load->view('website/doctor/index',$output,TRUE);
        $this->load->view("website/layouts/master",$data);
    }
}
