<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Appointment extends CI_Controller
{
    public function __construct() {
        parent::__construct();
    }
    public function index()
    {
        $data['title'] = "Appointment";
        $data['active'] = 'Appointment';
        $output['page_title'] = "Appointment";
        $output['doctors'] = $this->Common_model->findAll('doctor',array(),'record_id','asc');
        $data['content'] = $this->load->view('website/appointment/index',$output,TRUE);
        $this->load->view("website/layouts/master",$data);
    }

    public function saveOrUpdate()
    {
        $mobile_no = $this->input->post("mobile_no");
        $update_id = $this->input->post("update_id");
        $approval = $this->input->post("approval");
        $serial_status = $this->input->post("serial_status");
        $patient_id = $this->input->post("patient_id");
        $name = $this->input->post("name");
        $age = $this->input->post("age");
        $gender = $this->input->post("gender");
        $address = $this->input->post("address");
        $patient_status = $this->input->post("patient_status");
        $doctor_id = $this->input->post("doctor_id");
        $date = $this->input->post("date");
        $remarks = $this->input->post("remarks");
        
        if(!$patient_id){
            $patientData = array(
                'name' => $name,
                'mobile'=>$mobile_no,
                'age'=>$age,
                'address'=>$address,
                'gender'=>$gender
            );
            $patient_id = $this->Common_model->saveData("patient",$patientData);
        }



        $data = array() ;
        $data['date'] = $date ;
        $prefix = date("Ymd",strtotime($date));
        $max = $this->Common_model->findMax('appointments',array('prefix'=>$prefix),'serial_no') ;
        $serial_no =  isset($max)?$max->serial_no + 1 : 1;
        $data['prefix'] = $prefix ;
        $data['serial_no'] = $serial_no ;
        $data['doctor_id'] = $doctor_id;
        $data['patient_id'] = $patient_id;
        $data['comments'] = $remarks;
        $data['serial_status'] = $serial_status;
        $data['approval'] = $approval;
        if($update_id == 0 || empty($patient_id)){       
            $insert = $this->Common_model->saveData('appointments', $data);
            if($insert){
                $this->session->set_flashdata('message',INSERT_MSG);
            }else{
                $this->session->set_flashdata('message',INSERT_ERROR_MSG);
            }
        }else{
            $doctor_serial = $this->Common_model->findById('appointments',array('record_id'=>$update_id));
            if($doctor_serial->date == $date){
                $data['serial_no'] = $doctor_serial->serial_no ;
                $data['prefix'] = $doctor_serial->prefix ;
            }
            $update = $this->Common_model->updateData('appointments', $data,array('record_id'=>$update_id));
            if($update){
                $this->session->set_flashdata('message',UPDATE_MSG);
            }else{
                $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
            }
        }
        redirect('website/appointment/', 'refresh');
    }

    public function get_doctor_serial()
    {
        $mobile_no = $this->input->post("mobile_no") ;
        $patient = $this->Common_model->findById("patient",array("mobile"=>$mobile_no));
        echo json_encode($patient) ;
        exit;
    }
}
