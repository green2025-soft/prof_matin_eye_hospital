<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Contact_us extends CI_Controller
{
    public function __construct() {
        parent::__construct();
    }
    public function index()
    {
        $data['title'] = "Contact Us";
        $data['active'] = 'Contact Us';
        $output['page_title'] = "Our Contact Us";
        //$output['values'] = $this->Common_model->findAll('doctor',array(),'record_id','desc');
        $data['content'] = $this->load->view('website/contact_us/index',$output,TRUE);
        $this->load->view("website/layouts/master",$data);
    }
}
