<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Patient_feedback extends CI_Controller
{
    public function __construct() {
        parent::__construct();
    }
    public function index()
    {
        $data['title'] = "Patient Feedback";
        $data['active'] = 'Patient Feedback';
        $output['page_title'] = "Patient Feedback";
        $doctor_id = $this->input->get('doctor_id') ;
        $output['doctor_id'] = $doctor_id ;
        $output['doctors'] = $this->Common_model->findAll('doctor',array(),'record_id','desc');
        $data['content'] = $this->load->view('website/patient_feedback/index',$output,TRUE);
        $this->load->view("website/layouts/master",$data);
    }

    public function saveOrUpdate()
    {
        $data = $_POST ;
       $update_id = 0 ;
        if($update_id == 0 || empty($patient_id)){       
            $insert = $this->Common_model->saveData('patient_feedback', $data);
            if($insert){
                $this->session->set_flashdata('message',INSERT_MSG);
                echo "Send Your Feedback Successful.";
                exit;
            }else{
                $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                echo "Send Your Feedback Successful.";
                exit;
            }
        }else{
            $doctor_serial = $this->Common_model->findById('patient_feedback',array('record_id'=>$update_id));
            $update = $this->Common_model->updateData('patient_feedback', $data,array('record_id'=>$update_id));
            if($update){
                $this->session->set_flashdata('message',UPDATE_MSG);
            }else{
                $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
            }
        }
        redirect('website/patient_feedback/', 'refresh');
    }

    public function get_doctor_serial()
    {
        $mobile_no = $this->input->post("mobile_no") ;
        $patient = $this->Common_model->findById("patient",array("mobile"=>$mobile_no));
        echo json_encode($patient) ;
        exit;
    }
}
