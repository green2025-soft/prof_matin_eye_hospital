<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Photo_gallery extends CI_Controller
{
    public function __construct() {
        parent::__construct();
    }
    public function index()
    {
        $data['title'] = "Photo Gallery";
        $data['active'] = 'Photo Gallery';
        $output['page_title'] = "Photo Gallery";
        $output['photo_galleries'] = $this->Common_model->findAll('photo_gallery',array(),'record_id','asc');
        $data['content'] = $this->load->view('website/photo_gallery/index',$output,TRUE);
        $this->load->view("website/layouts/master",$data);
    }
}
