<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Video_gallery extends CI_Controller
{
    public function __construct() {
        parent::__construct();
    }
    public function index()
    {
        $data['title'] = "Video Gallery";
        $data['active'] = 'Video Gallery';
        $output['page_title'] = "Video Gallery";
        //$output['values'] = $this->Common_model->findAll('news',array(),'record_id','desc');
        $data['content'] = $this->load->view('website/video_gallery/index',$output,TRUE);
        $this->load->view("website/layouts/master",$data);
    }
}
