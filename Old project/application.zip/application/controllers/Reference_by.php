<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Reference_by extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Reference';
            $data['page_title'] = 'Reference';
            $data['info_header'] = 'All Reference';
            $data['values'] = $this->Common_model->findAll('reference_by',array(),'record_id','asc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/reference_by/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            unset($input['update_id']);
            $popup = $this->input->post('popup');
            if(isset($popup)){
                unset($input['popup']);
            }
            if($update_id == 0 || empty($update_id)){       
                /*$getRow = $this->Common_model->findById('reference',array('reference'=>$reference));
                if(isset($getRow)){
                    $this->session->set_flashdata('message', EXIST_MSG);
                    redirect('reference', 'refresh');
                }*/
                $max = $this->Common_model->findMax("reference_by",array(),"reference_no");
                $reference_no = isset($max)?$max->reference_no + 1 : 1 ;
                $input['reference_no'] = $reference_no ;
                $insert = $this->Common_model->saveData('reference_by', $input);
                if(isset($popup)){
                    $reference = $this->Common_model->findById('reference_by',array('record_id'=>$insert));
                    echo json_encode($reference);
                    exit;
                }
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $update = $this->Common_model->updateData('reference_by', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            redirect('reference_by', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $id, 'reference_by')){
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
            redirect('reference_by', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
