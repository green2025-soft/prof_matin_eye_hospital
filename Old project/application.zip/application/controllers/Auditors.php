<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Auditors extends MY_Controller {

    public function __construct() {
        parent::__construct();
         $this->title    = 'Auditors';
          $this->loadModel('Auditor_model');
    }
    public function index() {
        $request                = $this->input->get();
        $from_date              = $request['from_date']??date('Y-m-d');
        $to_date                = $request['to_date']??date('Y-m-d');
        $where = [
            'action_date_time >=' => $from_date. ' 00:00:00',
            'action_date_time <=' => $to_date . ' 23:59:59',
        ];


        $this->data = [
            'title'             => 'All '.$this->title,
            'values'            => $this->model->where($where)->order_by('record_id', 'DESC')->all(),
            'from_date'         => $from_date,
            'to_date'           => $to_date,
        ];

        $this->render('admin/auditors/index');
           
    }
    public function uri_segment(){
        $segment = $this->uri->segment_array() ;
        $segment = implode('/', $segment) ;
        $menu = $this->Common_model->findById('menu_list',array('menu_link'=>$segment));
        var_dump($menu) ; die;
    }
}
