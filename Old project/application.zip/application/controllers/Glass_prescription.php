<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Glass_prescription extends MY_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->title    = 'Glass Prescription';
        $this->bUrl     = 'glass_prescription';

        $this->loadModel('GlassPrescription_model');
        $this->load->model(['GlassPrescriptionDetails_model'=> 'gpdModel']);
    }

    public function index()
    {
        $this->data = [
            'title'     => 'All '.$this->title,
            'values'    => $this->model->with(['patient', 'doctor'])->order_by('id', 'DESC')->all()
        ];
        // dd($this->data);
        $this->render('admin/glass_prescription/index');
    }

    public function create()
    {
        $this->data = [
            'title'         => 'Create '.$this->title,
        ];

        $this->render('admin/glass_prescription/create');
    }

    public function edit($record_id)
    {
         $value = $this->model->with(['patient'])->find($record_id);
         $this->data = [
            'title'     => 'Edit '.$this->title,
            'value'     => $value,
            'patient'   => $value->patient??[],
            'values'    => $this->gpdModel->where('gp_id', $record_id)->all(),
        ];
        
        $this->render('admin/glass_prescription/create');

    }


    public function saveOrUpdate()
    {
            $input      = $this->input->post();
            $update_id  = $input['update_id'];
            $this->db->trans_start();
            $ipd = $input["ipd"];
            $date = $input['date']??date('Y-m-d');
            
            if(isset($ipd)){
                $input['ipd'] = implode(",", $ipd);
            }
            $prefix         = date('Ymd', strtotime($date));
            if($update_id){
                $prescription               = $this->model->select_max('prescription_no')->first();
                $prescription_no            = (int) ($prescription->prescription_no ?? 0) + 1;
                $input['prescription_no']   = $prescription_no;
            }

            $input['prefix']    = $prefix;
            $input['date']      =  $date;
            
            $data       = $this->model->filterTableData($input);
            $id         = $this->model->updateOrInsert($data, $update_id);
            if($update_id){
                $this->gpdModel->getDelete($update_id, 'gp_id');
            }
            

            
            $rows        = [];
            $rows[] = [
                'gp_id'         =>  $id,
                'vision_type'   =>  'DV',
                'eye_position'  =>  'Left',
                'sphere'        =>  $input['l_sphere_dv'],
                'cylinder'      =>  $input['l_cylinder_dv'],
                'axis'          =>  $input['l_axis_dv'],
                'acuity'        =>  $input['l_acuity_dv'],
            ];

            $rows[] = [
                'gp_id'         =>  $id,
                'vision_type'   =>  'NV',
                'eye_position'  =>  'Left',
                'sphere'        =>  $input['l_sphere_nv'],
                'cylinder'      =>  $input['l_cylinder_nv'],
                'axis'          =>  $input['l_axis_nv'],
                'acuity'        =>  $input['l_acuity_nv'],
            ];

            $rows[] = [
                'gp_id'         =>  $id,
                'vision_type'   =>  'DV',
                'eye_position'  =>  'Right',
                'sphere'        =>  $input['r_sphere_dv'],
                'cylinder'      =>  $input['r_cylinder_dv'],
                'axis'          =>  $input['r_axis_dv'],
                'acuity'        =>  $input['r_acuity_dv'],
            ];
             $rows[] = [
                'gp_id'         =>  $id,
                'vision_type'   =>  'NV',
                'eye_position'  =>  'Right',
                'sphere'        =>  $input['r_sphere_nv'],
                'cylinder'      =>  $input['r_cylinder_nv'],
                'axis'          =>  $input['r_axis_nv'],
                'acuity'        =>  $input['r_acuity_nv'],
            ];
          
            $this->gpdModel->insertBatch($rows);
            $this->db->trans_complete();
            
            $this->crudAlertMessage($update_id, $this->bUrl);
    }

    public function view($record_id)
    {
        $value = $this->model->with(['patient', 'doctor'])->find($record_id);
        $this->data = [
            'recordID'      => $record_id,
            'value'         => $value,
            'values'        => $this->gpdModel->where('gp_id', $record_id)->order_by('id', 'asc')->all(),
            'patient'       => $value->patient,
            'doctor'        => $value->doctor,
        ];

        $this->render('admin/glass_prescription/view');
    }
   

    public function delete($id) {
        $this->model->getDelete($id);
        $this->gpdModel->getDelete($id, 'gp_id');
        $this->crudAlertMessage($id, $this->bUrl, true); 
    }
}
