<?php

defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Doctor_serial extends CI_Controller
{

    static $helper   = array('utility');
    public function __construct()
    {
        parent::__construct();
    }
    public function index()
    {
        $user_type = $this->session->ses_user_type;
        $record_id = $this->session->ses_record_id;
        if ($user_type == "admin" || $user_type == "staff" || $user_type == "doctor") {
            $data['title'] = 'Doctor Serial List';
            $data['page_title'] = 'Doctor Serial List';
            $where = array();
            $where['serial_status != '] = 'Direct';
            if(!admin()){
                $where['show_hide'] = 'Show' ;
            }
            if ($user_type == 'doctor') {
                $where['doctor_id'] = $record_id;
            }
            $data['values'] = $this->Common_model->findAll('appointments', $where, 'record_id', 'desc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/doctor_serial/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function create()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff" || $user_type == "doctor") {
            $data['title'] = 'Insert Doctor Serial';
            $data['page_title'] = 'Insert Doctor Serial';
            $current_date = closing_date(date('Y-m-d'));
            $prefix = date('Ymd', strtotime($current_date));
            $max = $this->Common_model->findMax('appointments', array('prefix' => $prefix), 'serial_no');
            $serial_no =  isset($max) ? $max->serial_no + 1 : 1;
            $data['serial_no'] = $prefix . '-' . $serial_no; //str_pad($serial_no,4,0,STR_PAD_LEFT ); 
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/doctor_serial/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function edit($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff" || $user_type == "doctor") {
            $data['title'] = 'Edit Doctor Serial';
            $data['page_title'] = 'Edit Doctor Serial';
            $data['value'] = $this->Common_model->findById('appointments', array('record_id' => $record_id));
            $data['patient'] = $this->Common_model->findById('patient', array('record_id' => $data['value']->patient_id));
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/doctor_serial/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff" || $user_type == "doctor") {
            $input = $_POST;
            $update_id = $input['update_id'];
            unset($input['update_id']);
            $date = $input['date'];
            $prefix = date("Ymd", strtotime($date));
            $max = $this->Common_model->findMax('appointments', array('prefix' => $prefix), 'serial_no');
            $serial_no =  isset($max) ? $max->serial_no + 1 : 1;
            $input['prefix'] = $prefix;
            $input['serial_no'] = $serial_no;
            //$input['serial_status'] = 'Hospital';

            if ($update_id == 0 || empty($update_id)) {
                $insert = $this->Common_model->saveData('appointments', $input);
                if ($insert) {
                    $this->session->set_flashdata('message', INSERT_MSG);
                } else {
                    $this->session->set_flashdata('message', INSERT_ERROR_MSG);
                }
            } else {
                $doctor_serial = $this->Common_model->findById('appointments', array('record_id' => $update_id));
                if ($doctor_serial->date == $date) {
                    $input['serial_no'] = $doctor_serial->serial_no;
                    $input['prefix'] = $doctor_serial->prefix;
                }
                $update = $this->Common_model->updateData('appointments', $input, array('record_id' => $update_id));
                if ($update) {
                    $this->session->set_flashdata('message', UPDATE_MSG);
                } else {
                    $this->session->set_flashdata('message', UPDATE_ERROR_MSG);
                }
            }
            redirect('doctor_serial', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff" || $user_type == "doctor") {
            if ($this->Common_model->delete_info('record_id', $id, 'appointments')) {
                $this->session->set_flashdata('message', DELETE_MSG);
            } else {
                $this->session->set_flashdata('message', DELETE_ERROR_MSG);
            }
            redirect('doctor_serial', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function approved($record_id)
    {
        if ($record_id) {
            $this->Common_model->updateData("appointments", array("approval" => "Approved"), array("record_id" => $record_id));
            $sms_body = "Your appointment are accepted.";
            $sms_id = 0;
            $sms_title = "Doctor Serial" ;
            $send_date = date("Y-m-d");
            $sms_qty = ceil(strlen(utf8_decode($sms_body)) / 159);

            $sms_person = 0;
            $send_sms_qty = 0;

            $reserveSmsObj = $this->Common_model->findById('load_sms', array('load_sms_id' => 1));

            if ($reserveSmsObj->sms_qty > 1) {
                $data = array(
                    'sms_id' => $sms_id,
                    'sms_title' => $sms_title,
                    'send_date' => $send_date,
                    'sms_body' => $sms_body,
                    'sms_person' => $sms_person,
                    'send_sms_qty' => $send_sms_qty,
                );
                $insert = $this->Common_model->saveData('sms_log', $data);
                $person = 0;
                $info = $this->Common_model->findById("appointments", array("record_id" => $record_id));
                if (isset($info)) {
                    $patient = $this->Common_model->findById("patient", array("record_id" => $info->patient_id));
                    $mobile = $patient->mobile;
                    if (!empty($mobile) && strlen($mobile) == 11) {
                        $reserveSmsObj = $this->Common_model->findById('load_sms', array('load_sms_id' => 1));
                        $reserveSms = isset($reserveSmsObj) ? $reserveSmsObj->sms_qty : 0;
                        if ($reserveSms >= $sms_qty) {
                            ++$person;
                            $smsDetails = array(
                                'sms_log_id' => $insert,
                                'send_date' => $send_date,
                                'patient_id' => $patient->record_id,
                            );
                            $this->Common_model->saveData('sms_log_details', $smsDetails);
                            techno_bulk_sms($mobile, $sms_body);
                            $balance_sms = $reserveSms - ($person * $sms_qty);
                            $this->Common_model->updateData('load_sms', array('sms_qty' => $balance_sms), array('load_sms_id' => 1));
                        }
                    }
                }
            }
            $this->session->set_flashdata('message', UPDATE_MSG);
        } else {
            $this->session->set_flashdata('message', UPDATE_ERROR_MSG);
        }
        redirect('doctor_serial', 'refresh');
    }
}
