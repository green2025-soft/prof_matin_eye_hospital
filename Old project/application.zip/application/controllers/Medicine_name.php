<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Medicine_name extends MY_Controller {


    private $type;
    private $tBUrl;
    public function __construct() {
        parent::__construct();
        
        $this->type = $this->input->get('type') === 'optic' ? 'optic' : 'medicine';
        
        $this->loadModel('DrugMedicine_model');
        $this->title        = ucfirst($this->type).' Name';
        $this->bUrl         = 'medicine_name';
        $this->tBUrl        = $this->bUrl.'?type='.$this->type;
        
        $this->load->library('pagination');
        $this->load->library('upload');

    }

 

    public function index() {
   
        $data['title'] = 'All '.$this->title;

        $generic_name_id = $this->input->get('generic_name_id');
        $product_id = $this->input->get('product_id');
        $page = (isset($_GET['page']) && $_GET['page'] > 1)  ? $_GET['page']  : 1;
        $limit = 100;
        $offset = ($page - 1) * $limit;

        $where = array() ;
        $where['type'] = $this->type;
        $where['warehouse'] = 'Pharmacy';

        if(intval($product_id) > 0){
            $where['record_id'] = $product_id;
        }
        if(intval($generic_name_id) > 0){   
            $where['generic_id'] = $generic_name_id;
        }

        $totalProducts = $this->Common_model->countAll('drug_medicine',$where);

        $data['pagination']['pages'] = ceil($totalProducts / $limit);
        $data['pagination']['current_page'] = $page;
        $data['page'] = $page;
        $data['limit'] = $limit;
        $data['product_id'] = $product_id;
        $data['generic_name_id'] = $generic_name_id;
        // ddd($page);

        $data['values'] = $this->model->paginatedMedicines($generic_name_id, $product_id, $limit, $offset);
        $data['type']   = $this->type;
        $this->data     = $data;

        $this->render('admin/medicine_name/index');
    }


    
    public function create()
    {
        $this->data = [
            'title'         => 'Create '.$this->title,
            'type'          => $this->type
        ];
        $this->render('admin/medicine_name/create');
    }

    public function edit($record_id)
    {
         $this->data = [
            'title'     => 'Edit '.$this->title,
            'value'     => $this->model->find($record_id),
            'type'      => $this->type
        ];
        $this->render('admin/medicine_name/create');

    }

    public function saveOrUpdate() {
        $request    = $this->input->post();
        $update_id  = $request['update_id'];
        if($update_id == 0 || empty($update_id)){ 
            $where = [
                'generic_id'        => $request['generic_id'],
                'dosage_id'         => $request['dosage_id'],
                'manufacturer_id'   => $request['manufacturer_id'],
                'brand_name'        => $request['brand_name'],
            ];
            $getRow =$this->model->where($where)->first();
            if(isset($getRow)){
                $this->session->set_flashdata('message', EXIST_MSG);
                redirect($this->bUrl.'/create?type='.$this->bUrl, 'refresh');
            }

        }
        $this->model->updateOrInsert($request, $update_id);
        $this->crudAlertMessage($update_id, $this->tBUrl); 
    }


    public function delete($id) {
        $this->model->getDelete($id);
        $this->crudAlertMessage($id, $this->tBUrl, true); 
    }
}
