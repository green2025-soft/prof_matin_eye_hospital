<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Generic_name extends MY_Controller {


    private $type;
    private $tBUrl;
    public function __construct() {
        parent::__construct();
        
        $this->type = $this->input->get('type') === 'optic' ? 'optic' : 'medicine';
        
        $this->loadModel('DrugGeneric_model');
        $this->title    = 'Generic Name';
        $this->bUrl     = 'generic_name';
        $this->tBUrl    = $this->bUrl.'?type='.$this->type;

    }


    public function index()
    {
        $this->data = [
            'title'     => 'All '.$this->title,
            'values'    => $this->model->order_by('generic_name', 'asc')->select('record_id, generic_name')->all(),
            'type'      => $this->type
        ];
        
        $this->render('admin/generic_name/index');
    }
   


    public function saveOrUpdate() {
        $request    = $this->input->post();
        $update_id  = $request['update_id'];
        $this->model->updateOrInsert($request, $update_id);
        $this->crudAlertMessage($update_id, $this->tBUrl); 
    }

    public function delete($id) {
        $this->model->getDelete($id);
        $this->crudAlertMessage($id, $this->tBUrl, true); 
    }
}
