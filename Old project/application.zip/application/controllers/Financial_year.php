<?php

defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Financial_year extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Insert Finacial Year';
            $data['page_title'] = 'Insert Finacial Year';
            $data['info_header'] = 'Finacial Year';
            $data['values'] = $this->Common_model->findAll('financial_years', array(), 'record_id', 'asc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/financial_year/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function saveOrUpdate()
    {
        $data = $_POST;
        $update_id = $data['update_id'];
        $from_date = $data['from_date'];
        $to_date = $data['to_date'];
        unset($data['update_id']);
        $check = 0;
        $start = date('d F, Y', strtotime($data['from_date']));
        $end = date('d F, Y', strtotime($data['to_date']));

        $data['financial_year'] = $start . ' - ' . $end;

        if ($update_id == 0) {
            $financial_years = $this->Common_model->findAll('financial_years', array(), 'record_id', 'asc');
            foreach ($financial_years as $key => $value) {
                $dates = getDatesFromRange($value->from_date, $value->to_date);
                if (in_array($from_date, $dates)) {
                    $check = 1;
                    break;
                }
            }

            if ($check == 1) {
                $this->session->set_flashdata('message', EXIST_MSG);
                redirect('financial_year');
            }
            $insert = $this->Common_model->saveData('financial_years', $data);
            if ($insert) {
                $this->session->set_flashdata('message', INSERT_MSG);
            } else {
                $this->session->set_flashdata('message', INSERT_ERROR_MSG);
            }
        } else {
            $financial_years = $this->Common_model->findAll('financial_years', array('record_id != ' => $update_id), 'record_id', 'asc');
            foreach ($financial_years as $key => $value) {
                $dates = getDatesFromRange($value->from_date, $value->to_date);
                if (in_array($from_date, $dates)) {
                    $check = 1;
                    break;
                }
            }

            if ($check == 1) {
                $this->session->set_flashdata('message', EXIST_MSG);
                redirect('financial_year');
            }
            $update = $this->Common_model->updateData('financial_years', $data, array('record_id' => $update_id));
            if ($update) {
                $this->session->set_flashdata('message', UPDATE_MSG);
            } else {
                $this->session->set_flashdata('message', UPDATE_ERROR_MSG);
            }
        }
        redirect('financial_year');
    }

    public function saveOrUpdate1()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST;
            $update_id = $input['update_id'];
            unset($input['update_id']);
            $input['financial_year'] = date('d F, Y', strtotime($input['from_date'])) . ' - ' . date('d F, Y', strtotime($input['to_date']));
            if ($update_id == 0 || empty($update_id)) {
                $insert = $this->Common_model->saveData('financial_years', $input);
                if ($insert) {
                    $this->session->set_flashdata('message', INSERT_MSG);
                } else {
                    $this->session->set_flashdata('message', INSERT_ERROR_MSG);
                }
            } else {
                $update = $this->Common_model->updateData('financial_years', $input, array('record_id' => $update_id));
                if ($update) {
                    $this->session->set_flashdata('message', UPDATE_MSG);
                } else {
                    $this->session->set_flashdata('message', UPDATE_ERROR_MSG);
                }
            }
            redirect('financial_year');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if ($this->Common_model->delete_info('record_id', $id, 'financial_years')) {
                $this->session->set_flashdata('message', DELETE_MSG);
            } else {
                $this->session->set_flashdata('message', DELETE_ERROR_MSG);
            }
            // redirect("crud/previousPage");
            redirect('financial_year', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
