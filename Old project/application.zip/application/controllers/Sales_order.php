<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Sales_order extends MY_Controller
{

	// static $library 	 = array('user_agent');

	private $type;
    private $tBUrl;

	public function __construct()
	{
		parent::__construct();
		// $this->load->library(self::$library);

		$this->type = $this->input->get('type') === 'optic' ? 'optic' : 'medicine';
        $this->loadModel('SalesOrder_model');

		$this->load->model(['SalesDetails_model'=>'sodM','DrugMedicine_model'=>'medicineM']);

		$this->title    	= "Sales " . ($this->type === 'optic' ? 'Optic' : 'Medicine');
        $this->bUrl     	= 'sales_order';
        $this->tBUrl     	= $this->bUrl.'?type='.$this->type;
		
	}

	public function index()
    {
		$from_date 	= $this->input->get('from_date')??date('Y-m-d');
		$to_date 	= $this->input->get('to_date')??date('Y-m-d');
		if (!admin()) {
			$where['show_hide'] = 'Show';
		}

		$where = [
			'sales_date >=' => $from_date,
			'sales_date <=' => $to_date,
		];

        $this->data = [
            'title'     	=> 'All '.$this->title,
            'values'    	=> $this->model->order_by('sales_id', 'DESC')->where($where)->all(),
            'type'      	=> $this->type,
            'from_date'		=> $from_date,
            'to_date'      	=> $to_date,
        ];
		
        
        $this->render('admin/sales_order/index');
    }


	public function create()
    {
		$where 		= [];
		$select 	= '--Select--';
		if (isset($value)) {
			$where['record_id'] = $value->admission_id;
			$select = '';
		} else {
			//$where['patient_status'] = 'Admitted';
			$select = '--Select--';
		}

		$patients = $this->Common_model->findAll('admission_fee_invoice', $where, 'record_id', 'desc');

        $this->data = [
            'title'         => 'Create '.$this->title,
			 'type'      	=> $this->type,
			 'patients'		=> $patients,
			 'select'		=> $select
        ];
		
        $this->render('admin/sales_order/create');
    }


	
	public function saveOrUpdate()
    {
            $input			= $this->input->post();
            $update_id		= $input['update_id'];
			$date 			= $input['sales_date'];
			$prefix         = date('Ymd', strtotime($date));
			
            $this->db->trans_start();
            if(!$update_id){
                $salesQuery       	= $this->model->select_max('sales_no')->first();
                $sales_no          	= (int) ($salesQuery->sales_no ?? 0) + 1;
                $input['sales_no'] 	= $sales_no;
            }else{
				$this->deleteStock($update_id);
			}

			$input['prefix']    = $prefix;
            $data   = $this->model->filterTableData($input);
            $id     = $this->model->updateOrInsert($data, $update_id);
            $this->sodM->getDelete($id, 'sales_order_id');
			$order_qtys = $input['order_qty'];
			foreach ($order_qtys as $key => $value) {
				$extRow 	= ['sales_order_id' => $id, 'sales_date' => $date];
				$row 		= $this->sodM->filterBatchRow($input, $key, $extRow);
				$detailId  	=  $this->sodM->create($row);
				$this->updateStock($row['product_id'], $value, $date, $detailId, $row['purchase_price'], $row['sales_price']);
			}
            
            $this->db->trans_complete();

			$url = $this->bUrl."/view/$id?type=$this->type";
            
            $this->crudAlertMessage($update_id, $url); 
    }



	public function edit($record_id)
    {
		$value = $this->model->find($record_id);
        $this->data = [
            'title'         => 'Edit '.$this->title,
			 'type'      	=> $this->type,
			 'value'		=> $value,
			 'values'    	=> $this->sodM->where('sales_order_id', $record_id)->all()
        ];
        $this->render('admin/sales_order/create');
    }
	


	public function view($purchase_id)
	{
		$value = $this->model->with('customer')->find($purchase_id);

		 $this->data = [
            'title'         => $this->title.' Invoice',
			 'type'      	=> $this->type,
			 'value'		=> $value,
			 'customer'		=> $value->customer,
			 'values'    	=> $this->sodM->where('sales_order_id', $purchase_id)->all()
        ];
        $this->render('admin/sales_order/invoice');

	}

	public function view2($purchase_id){
		redirect($this->bUrl.'/view/'.$purchase_id, 'refresh'); 
	}
	


	public function delete($id)
	{
		$this->db->trans_start();
		$this->deleteStock($id);
		$this->model->getDelete($id);
		$this->sodM->getDelete($id, 'sales_order_id');
		$this->db->trans_complete();
		$this->crudAlertMessage($id, $this->tBUrl, true); 
			
	}

	public function find_stock()
	{
		$product_id = $this->input->post('product_id');
		$stock = $this->Common_model->item_balance($product_id);
		echo $stock;
		exit(0);
	}

	public function add_stock()
	{
		$product_id = $this->input->post('product_id');
		$order_qty = $this->input->post('order_qty');
		$stock_info = $this->Common_model->findById('product_stock', array('product_id' => $product_id));
					$new_stock = $stock_info->stock_qty+$order_qty;
					$this->Common_model->updateData('product_stock', array('stock_qty' => $new_stock), array('product_id' => $product_id));
					echo $new_stock;
		exit;
	}

	public function load_product()
	{
		$sales_type = $this->input->post('sales_type');
		$type = $this->input->post('type');
		$warehouse = $this->input->post('warehouse');
		$option = "<option value=''>--Select $type--</option>";
		$purchase = $this->Common_model->group_by_usual('purchase_type', $sales_type, 'product_id', 'purchase_order_details');
		foreach ($purchase as $key => $value) {
			$medicine = $this->Common_model->getProductById($value->product_id);
			
			if($medicine->product_stock > 0 && $type == $medicine->type){
			$product_category = !empty($medicine->dosage_name) ? ' - ' . $medicine->dosage_name : '';
			$generic_name = !empty($medicine->generic_name) ? ' - ' . $medicine->generic_name : '';
			$strength = !empty($medicine->strength) ? ' - ' . $medicine->strength : '';
			$dose = !empty($medicine->dosage_name) ? ' - ' . $medicine->dosage_name : '';
			$stock = !empty($medicine->product_stock) ? $medicine->product_stock : 0;
			$option .= '<option value="' . $medicine->record_id . '" data-product_name="' . $medicine->brand_name . $product_category . $generic_name . $strength . '" data-unit_price="' . $medicine->unit_price . '" data-unit_mrp="' . $medicine->unit_mrp . '" data-unit_id="1" data-unit_name="Pcs" data-product_code="' . $medicine->record_id . '" data-stock="' . $stock. '">' . $medicine->brand_name . $strength .$dose." - ".$medicine->record_id.'</option>';
		}
	}
	
		echo $option;
		exit;
	}

	public function delete_stock()
	{
		$id = $this->input->post('id');
		
		$order_info = $this->Common_model->findById('sales_order_details', array('sales_order_details_id' => $id));
		$stock_info = $this->Common_model->findById('drug_medicine', array('record_id' => $order_info->product_id));
		$new_stock = $stock_info->product_stock+$order_info->order_qty;
		$this->Common_model->updateData('drug_medicine', array('product_stock' => $new_stock), array('record_id' => $stock_info->record_id));

		$stock_history = $this->Common_model->findById('product_stock_history', array('product_id' => $stock_info->record_id, 'stock_date' =>$order_info->sales_date));
			$history = array(
				'stock_qty' => $new_stock,
				'sales_qty' => $stock_history->sales_qty-$order_info->order_qty
			);
			$this->Common_model->updateData('product_stock_history', $history, array('record_id' => $stock_history->record_id));
		//echo $new_stock;
		exit;
	}

	public function delete_sales_stock($id)
	{
	$sales_order_details = $this->Common_model->findAll('sales_order_details',array('sales_order_id'=>$id),'sales_order_details_id ','asc');
			foreach($sales_order_details as $detail){
				$stock_info = $this->Common_model->findById('drug_medicine', array('record_id' => $detail->product_id));
				$new_stock = $stock_info->product_stock+$detail->order_qty;
				$this->Common_model->updateData('drug_medicine', array('product_stock' => $new_stock), array('record_id' => $stock_info->record_id));

				$stock_history = $this->Common_model->findById('product_stock_history', array('product_id' => $stock_info->record_id, 'stock_date' =>$detail->sales_date));
					$history = array(
						'stock_qty' => $new_stock,
						'sales_qty' => $stock_history->sales_qty-$detail->order_qty
					);
					$this->Common_model->updateData('product_stock_history', $history, array('record_id' => $stock_history->record_id));

			}
			//exit;
	}

	public function load_package()
	{
		$package_id = $this->input->post('package_id');
		$packages = $this->Common_model->findAll("package_details", array('package_id' => $package_id), "record_id", "asc");
		$tr = "";
		foreach ($packages as $key => $value) {
				$product = $this->Common_model->getProductById($value->product_id);
				$stock = !empty($product->product_stock) ? $product->product_stock : 0;
			if ($stock > 0) {
				$unit_id = 1;
				$product_name = isset($product) ? $product->brand_name . ' - ' . $product->strength .' - ' . $product->dosage_name. ' - ' .$product->record_id : "";
				$purchase_price = isset($product) ? $product->unit_price : 0;
				$unit_name = 'Pcs';

				$html  = '<input type="hidden" name="product_id[]" value="' . $value->product_id . '">';
				$html .= '<input type="hidden" name="sales_order_details_id[]" value="0">';
				$html .= '<input type="hidden" name="item_sales_type[]" value="' . $value->type . '">';
				$html .= '<input type="hidden" name="unit_id[]" value="' . $unit_id . '">';
				$html .= '<input type="hidden" name="unit_name[]" value="' . $unit_name . '">';
				$html .= '<input type="hidden" name="sales_price[]" value="' . $value->unit_price . '">';
				$html .= '<input type="hidden" name="purchase_price[]" value="' . $purchase_price . '">';
				$html .= '<input type="hidden" name="order_qty[]" value="' . $value->quantity . '">';
				$html .= '<input type="hidden" name="free_qty[]" value="0">';
				$html .= '<input type="hidden" name="vat_amount[]" value="0">';
				$html .= '<input type="hidden" name="discount_amount[]" value="0">';
				$html .= '<input type="hidden" name="discount_per_product[]" value="0">';
				$html .= '<input type="hidden" name="sub_total[]" value="' . $value->total_price . '">';
				$html .= '<input type="hidden" name="net_total[]" value="' . $value->total_price . '">';

				$editRow = '<a data-sales_order_details_id="0" href="javascript:void(0)" style="margin-right:5px;" class="btn btn-info btn-sm editRow hide"><span class="fa fa-pencil"></span></a>';
				$deleteRow = '<a data-sales_order_details_id="0" href="javascript:void(0)" class="btn btn-danger btn-sm deleteRow"><span class="fa fa-trash-o"></span></a>';

				$tr .= '<tr>';
				$tr .= '<td class="hide">' . $html . '</td>';
				$tr .= '<td class="serial"></td>';
				$tr .= '<td class="">' . $product_name . '</td>';
				$tr .= '<td class="hide">' . $unit_name . '</td>';
				$tr .= '<td style="text-align:right;" class="">' . $value->unit_price . '</td>';
				$tr .= '<td style="text-align:right;" class="order_qty">' . $value->quantity . '</td>';
				$tr .= '<td style="text-align:right;" class="hide free_qty">0</td>';
				$tr .= '<td style="text-align:right;" class="hide vat_amount">0</td>';
				$tr .= '<td style="text-align:right;" class="hide sub_total">' . $value->total_price . '</td>';
				$tr .= '<td style="text-align:right;" class="hide discount_amount">0</td>';
				$tr .= '<td style="text-align:right;" class="net_total">' . $value->total_price . '</td>';
				$tr .= '<td class="">' . $editRow . '' . $deleteRow . '</td>';
				$tr .= '</tr>';
			}
		}
		echo $tr;
		exit;
	}

	
	private function updateStock($product_id, $qty, $date, $detailId, $price=0, $salePrice=0){
		updateStock($product_id,$detailId, $qty, $date,'sales',$price, $salePrice);
	}

	private function deleteStock($id){
		$purchase_order_details = $this->Common_model->findAll('sales_order_details',['sales_order_id'=>$id, 'sales_type'=>'Medicine'],'sales_order_details_id','asc');
		foreach($purchase_order_details as $detail){
			deleteStock($detail->sales_order_details_id, $detail->product_id, 'sales');
		}
		
	}
}
