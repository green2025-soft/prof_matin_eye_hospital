<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Due_collection extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Due Collection List';
            $data['page_title'] = 'Due Collection List';
            $data['values'] = $this->Common_model->findAll('due_collections',array(),'mr_id','desc');
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/due_collection/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function Create() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Due Collection';
            $data['page_title'] = 'Due Collection';
            $data['info_header'] = '';
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/due_collection/create', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate()
    {
      $mr_date = $this->input->post('mr_date');
      $patient_id = $this->input->post('patient_id');
      $invoice_amounts = $this->input->post('invoice_amount');
      $invoice_ids = $this->input->post('invoice_id');
      $invoice_types = $this->input->post('invoice_type');
      $collection_type = $this->input->post('collection_type');
      $current_collections = $this->input->post('current_collection');
      $mr_amount = array_sum($current_collections) ; 
      $prefix  = str_replace('-', '', $mr_date);
      $maxMr = $this->Common_model->findMax('due_collections',array('prefix'=>$prefix),'mr_no');
      $mr_no = isset($maxMr)?$maxMr->mr_no + 1 : 1 ;

      if($mr_amount > 0){
        $prefix1 = 'Col'. date("Ymd",strtotime($mr_date));
        $maxInvoice1 = $this->Common_model->findMax('create_bill',array('prefix'=>$prefix,'type'=>'Collection'),'invoice_no');
        $invoice_no1 = isset($maxInvoice1)?$maxInvoice1->invoice_no + 1 : 1 ;

        $invoice_data = array(
          'date' => $mr_date,
          'prefix' => $prefix1,
          'invoice_no' => $invoice_no1,
          'type' => 'Collection',
          'particular' => "Due Collection",
          'patient_id' => $patient_id,
          'amount' => $mr_amount,
          'sub_total' => $mr_amount,
          'paid' => $mr_amount,
          'due' => 0,
          'advance' => 0,
          'return_amount' => 0,
        );

        $invoice_id = $this->Common_model->saveData('create_bill',$invoice_data);

        $mr = array(
          'invoice_id'=>$invoice_id,
          'patient_id'=>$patient_id,
          'collection_type'=>$collection_type,
          'prefix'=>$prefix,
          'mr_no'=>$mr_no,
          'mr_date'=>$mr_date,
          'mr_amount'=>$mr_amount,
        );
      }
      $insert = $mr_id = $this->Common_model->saveData('due_collections',$mr);

      if($mr_id){
          foreach ($current_collections as $key => $value) {
            if($value > 0){
              $data = array(
                  'mr_id'=>$mr_id,
                  'mr_date'=>$mr_date,
                  'invoice_type'=>$invoice_types[$key],
                  'collection_type'=>$collection_type,
                  'patient_id'=>$patient_id,
                  'invoice_id'=>$invoice_ids[$key],
                  'invoice_amount'=>$invoice_amounts[$key],
                  'current_collection'=>$value,
              );
              $this->Common_model->saveData('due_collection_details',$data);
          }
      }
      if($insert){
        $this->session->set_flashdata('message',INSERT_MSG);
    }else{
        $this->session->set_flashdata('message',INSERT_ERROR_MSG);
    }
}
redirect("due_collection/view/$mr_id");
}

public function view($mr_id)
  {
    $data['title'] = "Due Collection";
    $data['page_title'] = "Due Collection";
    $data['info_header'] = "";
    $data['signatureType'] = 'Staff';
    $data['redirect'] = base_url('due_collection/create');
    $data['value'] = $this->Common_model->findById('due_collections',array('mr_id'=>$mr_id));
    $data['patient'] = $this->Common_model->findById('patient',array('record_id'=>$data['value']->patient_id));

    $where = array('due_collection_details.mr_id '=>$mr_id);
    $options = array(
      'joins' => array(
        array(
          'table' => 'create_bill',
          'condition' => 'create_bill.record_id = due_collection_details.invoice_id',
          'jointype' => 'LEFT'
        )
      ),
      'select' => 'due_collection_details.*,create_bill.prefix,create_bill.invoice_no,create_bill.sub_total',
      'where' => $where,
      'order' => array(
        'due_collection_details.mr_details_id' => 'asc',
      ),
    );
    $data['values'] = $this->Common_model->commonJoins("due_collection_details", $options);

    $this->load->view('admin/layouts/header');
        $this->load->view('admin/due_collection/invoice', $data);
        $this->load->view('admin/layouts/footer');
  }
  public function view2($mr_id)
  {
    $data['title'] = "Due Collection";
    $data['page_title'] = "Due Collection";
    $data['info_header'] = "";
    $data['signatureType'] = 'Staff';
    $data['redirect'] = base_url('due_collection');
    $data['value'] = $this->Common_model->findById('due_collections',array('mr_id'=>$mr_id));
    $data['patient'] = $this->Common_model->findById('patient',array('record_id'=>$data['value']->patient_id));

    $where = array('due_collection_details.mr_id '=>$mr_id);
    $options = array(
      'joins' => array(
        array(
          'table' => 'create_bill',
          'condition' => 'create_bill.record_id = due_collection_details.invoice_id',
          'jointype' => 'LEFT'
        )
      ),
      'select' => 'due_collection_details.*,create_bill.prefix,create_bill.invoice_no,create_bill.sub_total',
      'where' => $where,
      'order' => array(
        'due_collection_details.mr_details_id' => 'asc',
      ),
    );
    $data['values'] = $this->Common_model->commonJoins("due_collection_details", $options);

    $this->load->view('admin/layouts/header');
        $this->load->view('admin/due_collection/invoice', $data);
        $this->load->view('admin/layouts/footer');
  }

public function load_patient(){
    $patient_id = $this->input->post('patient_id');
    $where['patient_id'] = $patient_id ;
    $data['values'] = $this->Common_model->findAll('create_bill',$where,'record_id','asc') ;
    $this->load->view('admin/due_collection/invoice_list',$data);
}

public function delete($id) {
    $user_type = $this->session->ses_user_type;
    if ($user_type == "admin"  || $user_type == "staff") {
       $mr = $this->Common_model->findById('due_collections',array('mr_id'=>$id));
        if(isset($mr)){
            $this->Common_model->delete_info('mr_id', $id, 'due_collections');
            $this->Common_model->delete_info('mr_id', $id, 'due_collection_details');
            $this->Common_model->delete_info('record_id', $mr->invoice_id, 'create_bill');
            $this->session->set_flashdata('message',DELETE_MSG);
        }else{
            $this->session->set_flashdata('message',DELETE_ERROR_MSG);
        }
        redirect('due_collection', 'refresh');
    } else {
        $data['wrong_msg'] = "";
        $this->load->view('website/login_check', $data);
    }
}
}
