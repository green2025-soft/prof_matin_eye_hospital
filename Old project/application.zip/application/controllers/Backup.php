<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Backup extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Backup';
            $data['page_title'] = 'Backup';
            $data['info_header'] = 'Backup';
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/backup/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function export(){
        $database = $this->db->database;
        $time = date('Y-m-d h:m:s');
        $database_name = $time.'-'.$database ;
        // Load the DB utility class
        $this->load->dbutil();

        // Backup your entire database and assign it to a variable


        $backup = $this->dbutil->backup(); 

        // Load the file helper and write the file to your server

        $this->load->helper('file');

        write_file("/path/to/$database_name.sql", $backup); 

        // Load the download helper and send the file to your desktop

        $this->load->helper('download');

        force_download("$database_name.sql", $backup);
    }
}
