<?php

defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Partner_investment extends MY_Controller
{
    
    public function __construct()
    {
        parent::__construct();
        $this->title    = 'Partner Investment';
        $this->bUrl     = 'partner_investment';

        $this->loadModel('PartnerInvestment_model');
    }
    public function index()
    {
        $this->data = [
            'title'     => 'All '.$this->title,
            'values'    => $this->model->order_by('id', 'DESC')->all()
        ];
        
        $this->render('admin/partner_investment/index');
    }

    public function create()
    {
        $this->data = [
            'title'     => 'Create '.$this->title,
        ];
        $this->render('admin/partner_investment/create');
    }

    
    public function edit($record_id)
    {
         $this->data = [
            'title'     => 'Edit '.$this->title,
            'value'     => $this->model->find($record_id),
        ];
        $this->render('admin/partner_investment/create');

    }

    public function saveOrUpdate()
    {
            $input = $this->input->post();
            $update_id = $input['update_id'];
            $this->model->updateOrInsert($input, $update_id);
            $this->crudAlertMessage($update_id, $this->bUrl);
    }


    public function delete($id)
    {
        $this->model->getDelete($id);
        $this->crudAlertMessage($id, $this->bUrl, true);
    }
    
}
