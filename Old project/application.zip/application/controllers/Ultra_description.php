<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Ultra_description extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Ultra Description';
            $data['page_title'] = 'Ultra Description';
            $data['info_header'] = 'All Ultra Description';
            $data['values'] = $this->Common_model->findAll('ultra_descriptions',array(),'record_id','desc') ;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/ultra_description/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function saveOrUpdate() {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST ;
            $update_id = $input['update_id'] ;
            unset($input['update_id']);
            $description_title = $input['description_title'];
            if($update_id == 0 || empty($update_id)){       
                $getRow = $this->Common_model->findById('ultra_descriptions',array('description_title'=>$description_title));
                if(isset($getRow)){
                    $this->session->set_flashdata('message', EXIST_MSG);
                    redirect('ultra_description', 'refresh');
                }
                $insert = $this->Common_model->saveData('ultra_descriptions', $input);
                if($insert){
                    $this->session->set_flashdata('message',INSERT_MSG);
                }else{
                    $this->session->set_flashdata('message',INSERT_ERROR_MSG);
                }
            }else{
                $update = $this->Common_model->updateData('ultra_descriptions', $input,array('record_id'=>$update_id));
                if($update){
                    $this->session->set_flashdata('message',UPDATE_MSG);
                }else{
                    $this->session->set_flashdata('message',UPDATE_ERROR_MSG);
                }
            }
            redirect('ultra_description', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id) {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if($this->Common_model->delete_info('record_id', $id, 'ultra_descriptions')){
                $this->session->set_flashdata('message',DELETE_MSG);
            }else{
                $this->session->set_flashdata('message',DELETE_ERROR_MSG);
            }
           // redirect("crud/previousPage");
            redirect('ultra_description', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
}
