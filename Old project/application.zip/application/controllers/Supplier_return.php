<?php

defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Supplier_return extends MY_Controller {

  private $type;
  private $tBUrl;

  
  public function __construct() {
    parent::__construct();
    $this->type = $this->input->get('type') === 'optic' ? 'optic' : 'medicine';

    $this->loadModel('SupplierReturn_model');
    $this->title    = 'Supplier Return';
    $this->bUrl     = 'supplier_return';
    $this->tBUrl    = $this->bUrl.'?type='.$this->type;

    $this->load->model(['SupplierReturnDetails_model'=>'srdM']);

  }

     public function index()
    {
        $this->data = [
            'title'     => 'All '.$this->title,
            'values'    => $this->model->where('status !=', "Delete")->order_by('return_id', 'DESC')->all(),
            'type'      => $this->type
        ];
        
        $this->render('admin/supplier_return/index');
    }

  


  public function create()
  {
      $this->data = [
          'title'         => $this->title,
          'type'          => $this->type
      ];
      $this->render('admin/supplier_return/create');
  }

  public function saveOrUpdate() {
    $input			        = $this->input->post();
    $update_id		      = $input['update_id'];
    $order_qtys         = $input['order_qty'];
    $date 			        = $input['return_date'];
    $product_ids        = $input['product_id'];
    $total_order_qty    = array_sum($order_qtys);
    $prefix             = date('Ymd', strtotime($date));

    $input['total_order_qty']     = $total_order_qty;
    $input['grand_return_amount'] = $input['grand_net_total'];
    $input['prefix']    = $prefix;

     $this->db->trans_start();
    if($update_id){
        $returnQue              = $this->model->select_max('return_no')->first();
        $return_no              = (int) ($returnQue->return_no ?? 0) + 1;
        $input['return_no']     = $return_no;
    }
    // dd($input);

    $data   = $this->model->filterTableData($input);
    $id     = $this->model->updateOrInsert($data, $update_id);
    $this->srdM->getDelete($id, 'return_id');

     foreach ($product_ids as $key => $value) {
        if ($value && $product_ids[$key] > 0) {
          $returnDetails = [
            'return_id'        => $id,
            'return_date'      => $date,
            'product_id'       => $value,
            'return_type'      => $input['item_return_type'][$key],
            'unit_id'          => $input['unit_id'][$key],
            'unit_name'        => $input['unit_name'][$key],
            'purchase_price'   => $input['unit_price'][$key],
            'return_qty'       => $order_qtys[$key],
            'return_amount'    => $input['net_total'][$key],
          ];

          $detailId =  $this->srdM->create($returnDetails);
          $this->updateStock($product_ids[$key], $order_qtys[$key], $date, $detailId, $input['unit_price'][$key], $input['unit_mrp'][$key]);
        }
     }

      $this->db->trans_complete();
      $this->crudAlertMessage($update_id, $this->tBUrl); 

  }



  public function load_invoice_products(){
    $purchase_id = $this->input->post('purchase_id');
    
    $data['value'] = $this->Common_model->findById('purchase_orders',array('purchase_id'=>$purchase_id));
    $data['supplier'] = $this->Common_model->findById('suppliers',array('record_id'=>$data['value']->supplier_id));

    $where = array('purchase_order_details.purchase_order_id '=>$purchase_id);
    $options = array(
      'joins' => array(
        array(
          'table' => 'product_name',
          'condition' => 'product_name.record_id = purchase_order_details.product_id',
          'jointype' => 'LEFT'
        ),
        array(
          'table' => 'generic_names',
          'condition' => 'generic_names.record_id = product_name.product_category_generic_name_id',
          'jointype' => 'LEFT'
        ),
        array(
          'table' => 'units',
          'condition' => 'units.record_id = purchase_order_details.unit_id',
          'jointype' => 'LEFT'
        ),

      ),
      'select' => 'purchase_order_details.*,product_name.product_name,product_name.product_category,units.unit_short_name,generic_names.generic_name',
      'where' => $where,
      'order' => array(
        'purchase_order_details.purchase_order_details_id' => 'asc',
      ),
    );
    $data['values'] = $this->Common_model->commonJoins("purchase_order_details", $options);

    $this->load->view('admin/supplier_return/product_list',$data);
  }

  	public function delete($id)
    {
      $this->deleteStock($id);
      $this->model->getDelete($id, 'return_id');
      $this->srdM->getDelete($id, 'return_id');
      $this->crudAlertMessage($id, $this->tBUrl, true); 
    }


public function view($purchase_id)
	{
		$value = $this->model->find($purchase_id);

		 $this->data = [
      'title'     => $this->title.' Invoice',
			 'type'     => $this->type,
			 'value'		=> $value,
			 'values'   => $this->srdM->where('return_id', $purchase_id)->all()
        ];
        $this->render('admin/supplier_return/view');

	}


  public function delete_purchase_return_stock($id)
	{
	$return_details = $this->Common_model->findAll('return_details',array('return_id'=>$id),'return_details_id','asc');
			foreach($return_details as $detail){
				$stock_info = $this->Common_model->findById('drug_medicine', array('record_id' => $detail->product_id));
				$new_stock = $stock_info->product_stock+$detail->return_qty;
				$this->Common_model->updateData('drug_medicine', array('product_stock' => $new_stock), array('record_id' => $stock_info->record_id));

				$stock_history = $this->Common_model->findById('product_stock_history', array('product_id' => $stock_info->record_id, 'stock_date' =>$detail->return_date));
					$history = array(
						'stock_qty' => $new_stock,
						'purchase_return_qty' => $stock_history->purchase_return_qty-$detail->return_qty
					);
					$this->Common_model->updateData('product_stock_history', $history, array('record_id' => $stock_history->record_id));

			}
			//exit;
	}

  private function updateStock($product_id, $qty, $date, $detailId, $price=0, $salePrice=0){
		updateStock($product_id,$detailId, $qty, $date,'purchase_return',$price, $salePrice);
	}

	private function deleteStock($id){
		$purchase_order_details = $this->Common_model->findAll('return_details',['return_id'=>$id, 'return_type'=>'Medicine'],'return_details_id','asc');
		foreach($purchase_order_details as $detail){
			deleteStock($detail->return_details_id, $detail->product_id, 'purchase_return');
		}
		
	}

}
