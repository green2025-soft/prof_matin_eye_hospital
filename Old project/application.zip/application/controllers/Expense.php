<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Expense extends CI_Controller
{

	static $library 	 = array('Numbertowords', 'upload');
	public function __construct()
	{
		parent::__construct();
		$this->load->library(self::$library);
	}
	public function index()
	{
		$data['title'] = "Expense List";
		$data['page_title'] = "Expense List";
		$from_date = $this->input->get('from_date');
        $to_date = $this->input->get('to_date');
		$where = array() ;
		$where['status != '] = 'Delete' ;

		if (!empty($from_date) && !empty($to_date)) {
			$where['expense_date >= '] = $from_date;
			$where['expense_date <= '] = $to_date;
		} elseif (!empty($from_date) && empty($to_date)) {
			$where['expense_date'] = $from_date;
		} elseif (empty($from_date) && !empty($to_date)) {
			$where['expense_date'] = $to_date;
		}
		if (!admin()) {
			$where['show_hide'] = 'Show';
		}
		
		$data['values'] 		= $this->Common_model->findAll("expenses", $where, "expense_id", "desc");
		$data['heading'] 		= 'Expense List from '.$from_date.' to '.$to_date;
		$data['permissions'] 	= getPermissions();
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/expense/index', $data);
		$this->load->view('admin/layouts/footer');
	}
	public function create()
	{
		$data['title'] = "Expense Entry";
		$data['page_title'] = "Expense Entry";
		$data['expense_heads'] = $this->Common_model->findAll('expense_head', array(), 'head', 'asc');
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/expense/create', $data);
		$this->load->view('admin/layouts/footer');
	}


	public function search_expense()
	{
		$data['title'] = "Search Expense";
		$data['page_title'] = "Search Expense";

		$from_date = $this->input->get('from_date');
		$to_date = $this->input->get('to_date');
		$expense_head_id = $this->input->get('expense_head_id');

		if (!isset($from_date) && !isset($to_date) && !isset($expense_head_id)) {
			$from_date = $to_date = date('Y-m-d');
		}

		$where = array();
		if (!admin()) {
			$where['show_hide'] = 'Show';
		}
		if (!empty($from_date) && !empty($to_date)) {
			$where['expense_date >= '] = $from_date;
			$where['expense_date <= '] = $to_date;
		} elseif (!empty($from_date) && empty($to_date)) {
			$where['expense_date'] = $from_date;
		} elseif (empty($from_date) && !empty($to_date)) {
			$where['expense_date'] = $to_date;
		}

		if ($expense_head_id) {
			$where['expense_head_id'] = $expense_head_id;
			$values = $this->Common_model->findAll('expense_details', $where, 'expense_details_id', 'desc');
		} else {
			$values = $this->Common_model->findAllGroupBySum('expense_details', $where, 'expense_head_id', 'expense_amount');
		}

		$data['values'] = $values;
		$data['from_date'] = $from_date;
		$data['to_date'] = $to_date;
		$data['expense_head_id'] = $expense_head_id;

		$this->load->view('admin/layouts/header');
		$this->load->view('admin/expense/search_expense', $data);
		$this->load->view('admin/layouts/footer');
	}



	public function saveOrUpdate()
	{
		$update_id = $this->input->post('update_id');
		$expense_date = $this->input->post('expense_date');
		$expense_type = $this->input->post('expense_type');
		$voucher_no = $this->input->post('voucher_no');
		$comments = $this->input->post('comments');
		$expense_details_ids = $this->input->post('expense_details_id');

		$expense_head_ids =  $this->input->post('expense_head_id');
		$expense_titles = $this->input->post('expense_title');
		$expense_amounts = $this->input->post('expense_amount');
		$voucher_amount = array_sum($expense_amounts);

		$path = 'assets/img/expense/';
		$file_field = 'attached_file';
		$attached_file = NULL;

		$prefix  = str_replace('-', '', $expense_date);
		$maxExpense = $this->Common_model->findMax('expenses', array('prefix' => $prefix), 'expense_no');
		$expense_no = isset($maxExpense) ? $maxExpense->expense_no + 1 : 1;


		if (empty($update_id) || $update_id == 0) {
			$upload_data = do_upload('expenses', array('expense_id' => $update_id), $path, $file_field);
			if (!empty($upload_data)) $attached_file = $path . $upload_data['file_name'];


			$expenseData = array(
				'prefix' => $prefix,
				'expense_no' => $expense_no,
				'expense_type' => $expense_type,
				'voucher_no' => $voucher_no,
				'expense_date' => $expense_date,
				'voucher_amount' => $voucher_amount,
				'comments' => $comments,
				'attached_file' => $attached_file
			);

			$expense_id = $this->Common_model->saveData('expenses', $expenseData);
			$update_id = $expense_id;
			if ($expense_id) {
				foreach ($expense_amounts as $key => $value) {
					if ($value > 0) {
						$data = array(
							'expense_id' => $expense_id,
							'expense_date' => $expense_date,
							'expense_type' => $expense_type,
							'expense_head_id' => $expense_head_ids[$key],
							'expense_title' => $expense_titles[$key],
							'expense_amount' => $value,
						);
						$this->Common_model->saveData('expense_details', $data);
					}
				}
			}
		} else {
			$expense = $this->Common_model->findById('expenses', array('expense_id' => $update_id));
			if ($expense->expense_date != $expense_date) {
				$prefix  = str_replace('-', '', $expense_date);
				$maxExpense = $this->Common_model->findMax('expenses', array('prefix' => $prefix), 'expense_no');
				$expense_no = isset($maxExpense) ? $maxExpense->expense_no + 1 : 1;
			}
			$attached_file = $expense->attached_file;
			$upload_data = do_upload('expenses', array('expense_id' => $update_id), $path, $file_field);
			if (!empty($upload_data)) $attached_file = $path . $upload_data['file_name'];

			$expenseData = array(
				'prefix' => $prefix,
				'expense_no' => $expense_no,
				'expense_type' => $expense_type,
				'voucher_no' => $voucher_no,
				'expense_date' => $expense_date,
				'voucher_amount' => $voucher_amount,
				'comments' => $comments,
				'attached_file' => $attached_file
			);

			$this->Common_model->updateData('expenses', $expenseData, array('expense_id' => $update_id));
			$expense_id = $update_id;
			if ($expense_id) {
				foreach ($expense_amounts as $key => $value) {
					if ($value > 0) {
						$expense_details_id = $expense_details_ids[$key];
						$data = array(
							'expense_id' => $expense_id,
							'expense_date' => $expense_date,
							'expense_type' => $expense_type,
							'expense_head_id' => $expense_head_ids[$key],
							'expense_title' => $expense_titles[$key],
							'expense_amount' => $value,
						);
						if ($expense_details_id) {
							$this->Common_model->updateData('expense_details', $data, array('expense_details_id' => $expense_details_id));
						} else {
							$this->Common_model->saveData('expense_details', $data);
						}
					}
				}
			}
			redirect("expense/view2/$expense_id");
		}
		redirect("expense/view/$expense_id");
	}

	public function view($expense_id)
	{
		$data['title'] = "View Expense";
		$data['page_title'] = "View Expense";
		$data['signatureType'] = 'Staff';
		$data['redirect'] = base_url('expense/create');
		$data['value'] = $this->Common_model->findById("expenses", array('expense_id' => $expense_id));
		$data['values'] = $this->Common_model->findAll('expense_details', array('expense_id' => $expense_id), 'expense_details_id', 'asc');
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/expense/voucher', $data);
		$this->load->view('admin/layouts/footer');
	}
	public function view2($expense_id)
	{
		$data['title'] = "View Expense";
		$data['page_title'] = "View Expense";
		$data['signatureType'] = 'Staff';
		$data['redirect'] = base_url('expense');
		$data['value'] = $this->Common_model->findById("expenses", array('expense_id' => $expense_id));
		$data['values'] = $this->Common_model->findAll('expense_details', array('expense_id' => $expense_id), 'expense_details_id', 'asc');
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/expense/voucher', $data);
		$this->load->view('admin/layouts/footer');
	}
	public function edit($expense_id)
	{
		$data['title'] = "Edit Expense";
		$data['page_title'] = "Edit Expense";
		$data['expense_heads'] = $this->Common_model->findAll('expense_head', array(), 'head', 'asc');
		$data['value'] = $this->Common_model->findById('expenses', array('expense_id' => $expense_id));
		$data['values'] = $this->Common_model->findAll('expense_details', array('expense_id' => $expense_id), 'expense_details_id', 'asc');
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/expense/create', $data);
		$this->load->view('admin/layouts/footer');;
	}
	public function delete($id)
	{
		$user_type = $this->session->ses_user_type;
		if ($user_type == "admin"  || $user_type == "staff") {
			$expense = $this->Common_model->findById('expenses', array('expense_id' => $id));
			if (isset($expense)) {
				$this->Common_model->delete_info('expense_id', $id, 'expenses');
				$this->Common_model->delete_info('expense_id', $id, 'expense_details');
				$this->session->set_flashdata('message', DELETE_MSG);
			} else {
				$this->session->set_flashdata('message', DELETE_ERROR_MSG);
			}
			redirect('expense', 'refresh');
		} else {
			$data['wrong_msg'] = "";
			$this->load->view('website/login_check', $data);
		}
	}
	
	public function approval($id) {
		$user_type = $this->session->ses_user_type;
		if ($user_type == "admin"  || $user_type == "staff") {
			$expense = $this->Common_model->findById('expenses',array('expense_id'=>$id));
			if(isset($expense)){
				if($expense->approval == 'Pending'){
					$data = array('approval'=>'Approved');
				}else{
					$data = array('approval'=>'Pending');
				}
				// dd($data );
				$this->Common_model->updateData('expenses',$data,array('expense_id'=>$id));
				$this->Common_model->updateData('expense_details',$data,array('expense_id'=> $id));
				$this->session->set_flashdata('message',UPDATE_MSG);
			}else{
				$this->session->set_flashdata('message',UPDATE_ERROR_MSG);
			}
			if($expense->expense_type == 'Pharmacy'){
				$redirect = base_url('expense/pharmacy_expense_list') ;
			}else{
				$redirect = base_url('expense') ;
			}
			redirect($redirect, 'refresh');
		} else {
			$data['wrong_msg'] = "";
			$this->load->view('website/login_check', $data);
		}
	}
	public function pharmacy_expense_list()
	{
		$data['title'] = "Expense List";
		$data['page_title'] = "Expense List";
		
		$where = array() ;
		if (!admin()) {
			$where['show_hide'] = 'Show';
		  }
		$where['status != '] = 'Delete';
		$where['expense_type'] = 'Pharmacy';
		$data['expense_type'] = 'Pharmacy';
		$data['values'] = $this->Common_model->findAll("expenses",$where,"expense_id","desc");
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/expense/index', $data);
		$this->load->view('admin/layouts/footer');
	}
	public function create_pharmacy_expense()
	{
		$data['expense_type'] = 'Pharmacy';
		$data['title'] = "Expense Entry";
		$data['page_title'] = "Expense Entry";
		$data['expense_heads'] = $this->Common_model->findAll('expense_head', array(),'head','asc');
		$this->load->view('admin/layouts/header');
		$this->load->view('admin/expense/create', $data);
		$this->load->view('admin/layouts/footer');
	}
}
