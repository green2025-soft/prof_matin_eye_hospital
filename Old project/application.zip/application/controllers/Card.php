<?php

defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Card extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Add Membership';
            $data['page_title'] = 'Add Membership';
            $data['info_header'] = 'Membership List';
            $data['values'] = $this->Common_model->findAll('cards', array(), 'record_id', 'asc');

            $max = $this->Common_model->findMax('cards', array(), 'card_no');
            $card_no = isset($max) ? isset($max->card_no) ? $max->card_no + 1 : 1 : 1;
            $card_no = str_pad($card_no, 4, "0", STR_PAD_LEFT);
            $data['card_no'] = 'M' . $card_no;
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/card/index', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }
    public function view($record_id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $data['title'] = 'Membership Card';
            $data['page_title'] = 'Membership Card';
            $data['info_header'] = 'Membership Card';
            $data['redirect'] = base_url('card') ;
            $data['value'] = $this->Common_model->findById('cards', array('record_id'=>$record_id));
            $data['patient'] = $this->Common_model->findById('patient', array('record_id'=>$data['value']->patient_id));
            $this->load->view('admin/layouts/header');
            $this->load->view('admin/card/view', $data);
            $this->load->view('admin/layouts/footer');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function saveOrUpdate()
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin" || $user_type == "staff") {
            $input = $_POST;
            $update_id = $input['update_id'];
            $patient_id = $input['patient_id'];
            unset($input['update_id']);
            $popup = $this->input->post('popup');
            if (isset($popup)) {
                unset($input['popup']);
            }
            $record_id = 0;
            if ($update_id == 0 || empty($update_id)) {
                $getRow = $this->Common_model->findById("cards", array('patient_id' => $input['patient_id']));
                if (isset($getRow)) {
                    $this->session->set_flashdata('message', EXIST_MSG);
                    redirect('card');
                }
                $max = $this->Common_model->findMax('cards', array(), 'card_no');
                $card_no = isset($max) ? isset($max->card_no) ? $max->card_no + 1 : 1 : 1;
                $input['card_no'] = $card_no;


                $insert = $this->Common_model->saveData('cards', $input);
                $record_id = $insert;
                $update_id = $insert;
                if ($insert) {
                    $this->session->set_flashdata('message', INSERT_MSG);
                } else {
                    $this->session->set_flashdata('message', INSERT_ERROR_MSG);
                }
            } else {
                $record_id = $update_id;
                $getRow = $this->Common_model->findById("cards", array('record_id != ' => $record_id, 'card_no' => $input['card_no']));
                if (isset($getRow)) {
                    $this->session->set_flashdata('message', EXIST_MSG);
                    redirect('card');
                }
                unset($input['card_no']) ;
                $update = $this->Common_model->updateData('cards', $input, array('record_id' => $update_id));
                if ($update) {
                    $this->session->set_flashdata('message', UPDATE_MSG);
                } else {
                    $this->session->set_flashdata('message', UPDATE_ERROR_MSG);
                }
            }
            if (isset($popup)) {
                $card = $this->Common_model->findById('cards', array('record_id' => $record_id));
                echo json_encode($card);
                exit;
            }
            redirect('card');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function delete($id)
    {
        $user_type = $this->session->ses_user_type;
        if ($user_type == "admin"  || $user_type == "staff") {
            if ($this->Common_model->delete_info('record_id', $id, 'cards')) {
                $this->session->set_flashdata('message', DELETE_MSG);
            } else {
                $this->session->set_flashdata('message', DELETE_ERROR_MSG);
            }
            // redirect("crud/previousPage");
            redirect('card', 'refresh');
        } else {
            $data['wrong_msg'] = "";
            $this->load->view('website/login_check', $data);
        }
    }

    public function getCardByCardNo()
    {
        $card_no = $this->input->post("card_no");
        $card = $this->Common_model->findById("cards", array('card_no' => $card_no));
        echo json_encode($card);
        exit;
    }
    public function getCardByPatient()
    {
        $patient_id = $this->input->post("patient_id");
        $card = $this->Common_model->findById("cards", array('patient_id' => $patient_id));
        echo json_encode($card);
        exit;
    }
}
