<?php

defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Dhaka');

class Campaign extends MY_Controller
{
    
    public function __construct()
    {
        parent::__construct();
        $this->title    = 'Campaign';
        $this->bUrl     = 'campaign';

        $this->loadModel('Campaign_model');
    }
    public function index()
    {
        $request = $this->input->get();
        $fromDate = $request['from_date'] ?? date('Y-m-d');
        $toDate = $request['to_date'] ?? date('Y-m-d');

        $this->model->where('date >=', $fromDate);
        $this->model->where('date <=', $toDate );
        
        $this->data = [
            'title'     => 'All '.$this->title,
            'from_date' => $fromDate,
            'to_date'   => $toDate,
            'values'    => $this->model->with(['doctor', 'salesman', 'nurse', 'patient'])->order_by('id', 'DESC')->all()
        ];
        
        $this->render('admin/campaign/index');
    }

    public function create()
    {
        $this->data = [
            'title'     => 'Create '.$this->title,
        ];
        $this->render('admin/campaign/create');
    }

    
    public function edit($record_id)
    {
         $this->data = [
            'title'     => 'Edit '.$this->title,
            'value'     => $this->model->find($record_id),
        ];
        $this->render('admin/campaign/create');

    }

    public function saveOrUpdate()
    {
            $input = $this->input->post();
            $update_id = $input['update_id'];
            $data = $this->model->filterTableData($input);
            $this->model->updateOrInsert($data, $update_id);
            $this->crudAlertMessage($update_id, $this->bUrl);
    }


    public function delete($id)
    {
        $this->model->getDelete($id);
        $this->crudAlertMessage($id, $this->bUrl, true);
    }
    
}
