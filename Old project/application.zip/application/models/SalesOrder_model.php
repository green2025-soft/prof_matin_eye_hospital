<?php

defined('BASEPATH') or exit('No direct script access allowed');

class SalesOrder_model extends MY_Model
{
    protected $table      = 'sales_orders';   
    protected $primaryKey = 'sales_id ';

    protected $createOrUpdateBy = true;
    private $type;

    public function __construct()
    {
        parent::__construct();
        $this->type = $this->input->get('type') === 'optic' ? 'optic' : 'medicine';
        $this->load->model(['Auditor_model'=>'auditM']);
    }


    protected $relations = [
        'details' => [
            'model'      => 'SalesDetails_model',
            'table'      => 'sales_order_details',
            'foreignKey' => 'sales_order_id',
            'localKey'   => 'sales_id',
            'type'       => 'hasMany',
        ],
        'customer' => [
            'model'      => 'Patient_model',
            'table'      => 'patient',
            'foreignKey' => 'customer_id',
            'localKey'   => 'record_id',
            'type'       => 'belongsTo',
        ]
    ];

    public function all()
    {
        $this->db->where('type', $this->type);
        return parent::all();
    }

    protected function saving($data, $id = null)
    {
        $data['type'] = $this->type;
        $action  = $id?'Update':'Insert';
        $this->createAudit($action, $data['sales_no'], $id, $data['paid_amount']);
        return $data;
    }

    protected function deleteing($id){
       $this->createAudit('Delete','',$id);
    }

    private function createAudit($action, $invoiceNo='', $id='', $presentAmount=0, $comments=''){
        if($id){
            $data = $this->find($id);
            $previousAmount = $data->paid_amount??0;
            $invoiceNo  = $data->sales_no??0;
        }
        $this->auditM->create_audit($this->table, $id,$action, $invoiceNo, $previousAmount, $presentAmount, $comments);
    }

    
}
