<?php

defined('BASEPATH') or exit('No direct script access allowed');

class DrugMedicine_model extends MY_Model
{
    protected $table      = 'drug_medicine';   
    protected $primaryKey = 'record_id';

    protected $createOrUpdateBy = true;
    private $type;

    public function __construct()
    {
        parent::__construct();
        $this->type = $this->input->get('type') === 'optic' ? 'optic' : 'medicine';
    }

   
    protected function saving($data, $id = null)
    {
        $data['type'] = $this->type;
        
        return $data;
    }


    protected function applyMedicineQuery()
    {
        
        $this->db->select("
                drug_medicine.*,
                drug_generic.generic_name,
                drug_dosage.dosage_name,
                drug_manufacturer.manufacturer_name,
                shelf.shelf_name,
                shelf.shelf_no
            ")
            ->join('drug_generic', 'drug_generic.record_id = drug_medicine.generic_id','left')
            ->join('drug_dosage','drug_dosage.record_id = drug_medicine.dosage_id','left')
            ->join('drug_manufacturer','drug_manufacturer.record_id = drug_medicine.manufacturer_id','left')
            ->join('shelf', 'shelf.record_id = drug_medicine.shelf_id', 'left')
            ->where('drug_medicine.type', $this->type)
            ->where('drug_medicine.warehouse', 'Pharmacy');

        return $this;
    }



    public function paginatedMedicines($genericNameId, $productId, $limit, $offset){
            
            $this->applyMedicineQuery();
    
            if($genericNameId > 0){
                $this->db->where('generic_id', $genericNameId);
            }
    
            if($productId > 0){
                $this->db->where('drug_medicine.record_id', $productId);
            }
             
            $this->db->where('drug_medicine.type', $this->type);
            $this->db->where('drug_medicine.warehouse', 'Pharmacy');
    
            $this->db->limit($limit, $offset);
    
            $this->db->order_by('drug_generic.generic_name', 'ASC')->group_by('drug_medicine.record_id');
            return $this->all();
    }

     public function search_product($term) {
            $this->db->from('drug_medicine');
            $this->applyMedicineQuery();
            $this->db->group_start();
                $this->db->like('brand_name', $term);
                $this->db->or_like('drug_medicine.record_id', $term);
                // $this->db->or_like('drug_medicine.product_code', $term);
            $this->db->group_end();
            $this->db->order_by(
                "CASE 
                    WHEN drug_medicine.brand_name = " . $this->db->escape($term) . " THEN 0
                    WHEN drug_medicine.brand_name LIKE " . $this->db->escape($term . '%') . " THEN 1
                    ELSE 2
                END",
                '',
                false
            );
            $this->db->order_by('drug_medicine.brand_name', 'ASC');
            $this->db->limit(100);

            $query = $this->db->get();
    
    
            $results = [];
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $row) {
                    
                    // Return both ID and name
                    $results[] = [
                        'label'         => $row->brand_name." (".$row->record_id.")",
                        'value'         => $row->brand_name." (".$row->record_id.")",
                        'id'            => $row->record_id,
                        'unit_price'    => $row->unit_price,
                        'unit_mrp'      => $row->unit_mrp,
                        'product_stock' => $row->product_stock,
                    ];
                }
            }
    
            return $results;
        }
}
