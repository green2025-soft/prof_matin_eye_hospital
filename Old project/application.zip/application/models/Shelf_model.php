<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Shelf_model extends MY_Model
{
    protected $table      = 'shelf';   
    protected $primaryKey = 'record_id';

    protected $createOrUpdateBy = true;
    private $type;

    public function __construct()
    {
        parent::__construct();
        $this->type = $this->input->get('type') === 'optic' ? 'optic' : 'medicine';
    }

    public function all()
    {
        $this->db->where('type', $this->type);
        return parent::all();
    }

    protected function saving($data, $id = null)
    {
        $data['type'] = $this->type;
        return $data;
    }
}
