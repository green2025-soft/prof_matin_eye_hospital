<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Patient_model extends MY_Model
{
    protected $table      = 'patient'; 
    
    protected $primaryKey = 'record_id';

    public function __construct()
    {
        parent::__construct();
    }
}
