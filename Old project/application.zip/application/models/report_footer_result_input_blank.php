<style>
   @media print {
   .footersine {
  position: fixed;
  width: 100%;
  bottom: 10px;
  box-sizing: border-box;
}

}
</style>




<div class="row signature1 footersine ">
<div class="row signature result-input-footer" style="margin-left: -50px;">

<div class="col-sm-5 col-xs-6 hide">
    <p></p>
    <span style="font-weight: bold;"><?= $testDetails->staff_name?></span><br>
    <span><?= $testDetails->staff_designation?></span>
</div>

<div class="col-sm-6 col-xs-6 hide">
    <div id="sign">
    <p></p>
    
    <span style="font-weight: bold;"><?= $testDetails->duty_doc_name?></span><br>
    <span><?= $testDetails->duty_doc_designation?></span>
</div>

</div>
</div>
  
    <?php $contact = $this->Common_model->findById('contact', array('id' => 1));?>
    <div class="col-sm-12 col-xs-12 hide" style="border-top: 1px solid #000; margin-top:20px; text-align:center; font-weight:bold; front-size:18px; background:#e67e22 !important;">
            <div class="col-xs-12">
                <i class="fa fa-home"></i>
                <?= isset($contact) ? $contact->address : '' ?><br>
                <i class="fa fa-phone"></i>
                <?= isset($contact) ? $contact->hotline : '' ?><?= isset($contact) ? !empty($contact->hotline2) ? ', ' . $contact->hotline2 : '' : ''?>
                <?= isset($contact) ? !empty($contact->hotline3) ? ', ' . $contact->hotline3 : '' : '' ?>
            </div>
            <div class="col-xs-12">
                <i class="fa fa-envelope"></i>
                <?= isset($contact) ? $contact->email : '' ?>
                <i class="fa fa-globe"></i>
                <?= isset($contact) ? ($contact->web) : '' ?>
                
            </div>


        </div>
       
</div>
