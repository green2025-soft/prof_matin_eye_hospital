<?php

defined('BASEPATH') or exit('No direct script access allowed');

class SaleTest_model extends MY_Model
{
    protected $table      = 'sales_test';   
    protected $primaryKey = 'record_id';

    public function __construct()
    {
        parent::__construct();
    }

    public function saveBatch($invoice_id)
    {
        $request        = $this->input->post();
        $testIds        = $request['test_id'] ?? [];

        if (empty($testIds)) {
            return false;
        }

        $rows = [];

        foreach ($testIds as $i => $testId) {
            $getData = fn($key) => $request[$key][$i] ?? null;
            $rows[] = $this->filterTableData([
                'invoice_no'        => $invoice_id,
                'date'              => $request['date'], 
                'patient_id'        => $request['patient_id'],
                'reference_by'      => $request['reference_by'],
                'doctor_id'         => $getData('doctor_id'),
                'test_category_id'  => $getData('test_category_id'),
                'test_id'           => $testId,
                'test_name'         => $getData('test_name'),
                'eye_type'          => $getData('eye_type'),
                'doctor_name'       => $getData('doctor_name'),
                'test_category'     => $getData('test_category'),
                'test_price'        => $getData('test_price'),
            ]);
        }

        $this->db->trans_start();
        $this->getDelete($invoice_id, 'invoice_no');
        $this->insert_batch($this->table, $rows);

        $this->db->trans_complete();

        return $this->db->trans_status();
    }
}
