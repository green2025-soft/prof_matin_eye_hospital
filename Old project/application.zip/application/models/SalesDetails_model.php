<?php

defined('BASEPATH') or exit('No direct script access allowed');

class SalesDetails_model extends MY_Model
{
    protected $table      = 'sales_order_details';   
    protected $primaryKey = 'sales_order_details_id';

    protected $createOrUpdateBy = true;
    

    public function __construct()
    {
        parent::__construct();
    }


    protected $relations = [
        'product' => [
            'model'      => 'DrugMedicine_model',
            'table'      => 'drug_medicine',
            'foreignKey' => 'product_id',
            'localKey'   => 'record_id',
            'type'       => 'belongsTo',
        ]
    ];



}
