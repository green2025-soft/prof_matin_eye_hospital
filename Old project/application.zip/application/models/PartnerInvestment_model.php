<?php

defined('BASEPATH') or exit('No direct script access allowed');

class PartnerInvestment_model extends MY_Model
{
    protected $table      = 'partner_investments';   

    public function __construct()
    {
        parent::__construct();
    }
}
