<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Doctor_model extends MY_Model
{
    protected $table      = 'doctor';   
    protected $primaryKey = 'record_id';

    protected $createOrUpdateBy = true;

    public function __construct()
    {
        parent::__construct();
    }
}
