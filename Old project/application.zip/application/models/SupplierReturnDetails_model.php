<?php

defined('BASEPATH') or exit('No direct script access allowed');

class SupplierReturnDetails_model extends MY_Model
{
    protected $table      = 'return_details';   
    protected $primaryKey = 'return_details_id';

    protected $createOrUpdateBy = true;

    public function __construct()
    {
        parent::__construct();
    }

}
