<?php

defined('BASEPATH') or exit('No direct script access allowed');

class BankTransation_model extends MY_Model
{
    protected $table      = 'bank_transations';  
    
    protected $primaryKey = 'record_id';

    protected $createOrUpdateBy = true;

    public function __construct()
    {
        parent::__construct();
    }


}
