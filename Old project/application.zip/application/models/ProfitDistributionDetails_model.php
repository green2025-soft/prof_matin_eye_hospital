<?php

defined('BASEPATH') or exit('No direct script access allowed');

class ProfitDistributionDetails_model extends MY_Model
{
    protected $table      = 'profit_distribution_details';   

    public function __construct()
    {
        parent::__construct();
    }


     protected $relations = [
        'partner' => [
            'model'      => 'PartnerInvestment_model',
            'table'      => 'partner_investments',
            'foreignKey' => 'partner_id',
            'localKey'   => 'id',
            'type'       => 'belongsTo',
        ],
    ];
}
