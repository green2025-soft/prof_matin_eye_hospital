<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Campaign_model extends MY_Model
{
    protected $table      = 'campaigns';   

    protected $relations = [
        'doctor' => [
            'model'      => 'Doctor_model',
            'table'      => 'doctor',
            'foreignKey' => 'doctor_id',
            'localKey'   => 'record_id',
            'type'       => 'belongsTo',
        ],
        'salesman' => [
            'table'      => 'staff',
            'foreignKey' => 'salesman_id',
            'localKey'   => 'record_id',
            'type'       => 'belongsTo',
        ],
        'nurse' => [
            'table'      => 'staff',
            'foreignKey' => 'nurse_id',
            'localKey'   => 'record_id',
            'type'       => 'belongsTo',
        ],
        'patient' => [
            'model'      => 'Patient_model',
            'table'      => 'patient',
            'foreignKey' => 'patient_id',
            'localKey'   => 'record_id',
            'type'       => 'belongsTo',
        ],
    ];

    public function __construct()
    {
        parent::__construct();
    }
}
