<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Common_model extends CI_Model
{

    static $except_table = array('admission_fee_invoice', 'ambulance_receipts', 'appointments', 'emergencys', 'due_collection_details', 'expense_details', 'income_details', 'medicine_requisition_details', 'mr_details', 'operation_equipment', 'purchase_order_details', 'sales_order_details', 'sms_log_details', 'supplier_payment_details', 'sales_test', 'lab_product_in_details', 'return_details', 'customer_return_details');

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->library(array('user_agent'));
    }

    function get_contact()
    {
        $query = $this->db->get('contact');
        return $query->result();
    }

    function get_about()
    {
        $query = $this->db->get('about');
        return $query->result();
    }

    function get_doctor()
    {
        $query = $this->db->get('doctor');
        return $query->result();
    }

    function get_our_service()
    {
        $query = $this->db->get('our_service');
        return $query->result();
    }

    function update_about($max_id, $about)
    {

        $data = array(
            'id' => $max_id,
            'about' => $about
        );
        $this->load->database();
        $this->db->replace('about', $data);
    }

    function data_date_to_date_group_by($table_name, $distinct_column, $date_column, $date_from, $date_to)
    {
        $this->db->where($date_column . '>=', $date_from);
        $this->db->where($date_column . '<=', $date_to);
        $this->db->group_by($distinct_column);
        $this->db->order_by($date_column);
        $query = $this->db->get($table_name);
        return $query->result();
    }

    function doc_commission_doc($date_from, $date_to, $doc_name)
    {
        $this->db->where('date >=', $date_from);
        $this->db->where('date<=', $date_to);
        $this->db->where('doctor_name', $doc_name);
        $this->db->group_by('invoice_no');
        $this->db->order_by('record_id');
        $query = $this->db->get('sales_test');
        return $query->result();
    }
    function doc_commission_without_doc($date_from, $date_to)
    {
        $this->db->where('date >=', $date_from);
        $this->db->where('date<=', $date_to);
        $this->db->group_by('invoice_no');
        $this->db->order_by('record_id');
        $query = $this->db->get('sales_test');
        return $query->result();
    }

    function get_distinct_value_where($column_name, $table_name, $column_with_value_array)
    {
        $this->db->select($column_name);
        $this->db->distinct();
        $this->db->where($column_with_value_array);
        $query = $this->db->get($table_name);
        return $query->result();
    }

    function get_distinct_value($column_name, $table_name)
    {
        $this->db->select($column_name);
        $this->db->distinct();
        $query = $this->db->get($table_name);
        return $query->result();
    }

    function get_bank_name()
    {
        $this->db->select('bank_name');
        $this->db->distinct();
        $query = $this->db->get('create_bank_name');
        return $query->result();
    }

    function get_last_data_byid($table_name, $where_column, $where_column_value)
    {
        $this->db->where($where_column, $where_column_value);
        $this->db->order_by('record_id', 'DESC');
        $this->db->limit(1);
        $query = $this->db->get($table_name);
        return $query->result();
    }

    function get_all_info_limit_offset($table_name, $limit, $offset)
    {
        $this->db->limit($limit, $offset);
        $query = $this->db->get($table_name);
        return $query->result();
    }
    function get_all_info_limit($table_name, $limit)
    {
        $this->db->limit($limit);
        $query = $this->db->get($table_name);
        return $query->result();
    }

    function get_distinct_value_order_by($column_name, $table_name)
    {
        $this->db->order_by('record_id', 'DESC');
        $this->db->select($column_name);
        $this->db->distinct();
        $query = $this->db->get($table_name);
        return $query->result();
    }
    function find_distinct_value($table, $where, $column)
    {
        $this->db->order_by('record_id', 'DESC');
        $this->db->select($column);
        $this->db->distinct();
        $this->db->where($where);
        $query = $this->db->get($table);
        return $query->result();
    }

    function check_value_get_data_with_guardians($table_name, $column_with_value_array)
    {
        $this->db->select('26_grade_mark_management.*,15_insert_guardian_info.name,15_insert_guardian_info.mobile');
        $this->db->from('26_grade_mark_management');
        $this->db->join('15_insert_guardian_info', '26_grade_mark_management.student_id = 15_insert_guardian_info.student_id');
        $this->db->where($column_with_value_array);
        $query = $this->db->get();
        if ($query->num_rows() == 0) {
            return FALSE;
        } else {
            return $query->result();
        }
    }

    function get_all_info_by_array($table_name, $column_with_value_array)
    {
        $this->db->where($column_with_value_array);
        $query = $this->db->get($table_name);
        return $query->result();
    }

    function get_all_info_by_class_name($table_name, $where_column, $where_column_value)
    {
        $this->db->where($where_column, $where_column_value);
        $query = $this->db->get($table_name);
        return $query->result();
    }

    function get_teacher_unique_id_distinct($where_column_value)
    {
        $this->db->select('teacher_unique_id');
        $this->db->distinct();
        $this->db->where('subject_name', $where_column_value);
        $query = $this->db->get('25_teacher_subject_management');
        return $query->result();
    }

    function get_distinct_subject_classwise($class_name)
    {
        $this->db->select('subject_name');
        $this->db->distinct();
        $this->db->where('class_name', $class_name);
        $query = $this->db->get('25_teacher_subject_management');
        return $query->result();
    }

    function get_distinct_teacher_id_classwise($class_name)
    {
        $this->db->select('teacher_unique_id');
        $this->db->distinct();
        $this->db->where('class_name', $class_name);
        $query = $this->db->get('25_teacher_subject_management');
        return $query->result();
    }

    function get_routine_time($column_with_value_array)
    {
        $this->db->order_by('class_time');
        $this->db->select('class_time');
        $this->db->distinct();
        $this->db->where($column_with_value_array);
        $query = $this->db->get('40_create_class_routine');
        return $query->result();
    }

    function data_date_to_date($table_name, $date_column, $date_from, $date_to)
    {
        $this->db->where($date_column . '>=', $date_from);
        $this->db->where($date_column . '<=', $date_to);
        $query = $this->db->get($table_name);
        return $query->result();
    }

    function update_data_onerow($table_name, $data, $where_column, $where_column_value)
    {
        $this->db->where($where_column, $where_column_value);
        $this->db->update($table_name, $data);
    }

    function insert_data($table_name, $data)
    {
        $query = $this->db->insert($table_name, $data);
        return $query;
    }

    function update_data_all_column($table_name, $data)
    {
        $this->db->update($table_name, $data);
    }

    function one_column_one_info($column_name, $id_column, $one_id, $table_name)
    {
        $this->db->select($column_name);
        $this->db->where($id_column, $one_id);
        $query = $this->db->get($table_name);
        return $query->result();
    }

    function get_allinfo_byid($table_name, $where_column, $where_column_value)
    {
        $this->db->where($where_column, $where_column_value);
        $query = $this->db->get($table_name);
        return $query->result();
    }

    function get_allinfo_byid_array($table_name, $where_column, $where_column_value)
    {
        $this->db->where($where_column, $where_column_value);
        $query = $this->db->get($table_name);
        return $query->result_array();
    }

    function get_allinfo_byid_limit_offset($limit, $offset, $table_name, $where_column, $where_column_value)
    {
        $this->db->limit($limit, $offset);
        $this->db->where($where_column, $where_column_value);
        $query = $this->db->get($table_name);
        return $query->result();
    }

    function get_all_info($table_name)
    {
        $query = $this->db->get($table_name);
        return $query->result();
    }

    function get_all_info_orderby($table_name, $order_column, $order_details)
    {
        $this->db->order_by($order_column, $order_details);
        $query = $this->db->get($table_name);
        return $query->result();
    }

    function get_userid_balance($id)
    {
        $this->db->select('user_id, amount');
        $this->db->where('mlm_apply_agent_id', $id);
        $query = $this->db->get('mlm_apply_agent');
        return $query->result();
    }

    function check_value($table_name, $column_with_value_array)
    {
        $this->db->where($column_with_value_array);
        $query = $this->db->get($table_name);
        if ($query->num_rows() == 0) {
            return FALSE;
        } else {
            return TRUE;
        }
    }

    function check_value_get_data($table_name, $column_with_value_array)
    {
        $this->db->where($column_with_value_array);
        $query = $this->db->get($table_name);
        if ($query->num_rows() == 0) {
            return FALSE;
        } else {
            return $query->result();
        }
    }

    function get_left_right_id($table_name, $parent_id, $parent_id_value)
    {
        $this->db->select('left_id, right_id');
        $this->db->where($parent_id, $parent_id_value);
        $query = $this->db->get($table_name);
        return $query->result();
    }

    function delete_info($table_id, $deleted_id, $table_name)
    {
        $present_paid_amount = 0;
        $previous_paid_amount = 0;
        $invoice_no = '';
        $comments = '';
        $loginId = $this->session->userData('ses_record_id');
        if ($table_name == 'create_bill') {
            $bill = $this->findById('create_bill', array('record_id' => $deleted_id));
            $previous_paid_amount = 0;
            $present_paid_amount = isset($bill) ? $bill->paid : 0;
            $comments = isset($bill) ? $bill->comments : 0;
            $invoice_no = isset($bill) ? $bill->prefix . $bill->invoice_no . ' (' . $bill->type . ')' : 0;
        }

        if ($table_name == 'expenses') {
            $expenses = $this->findById('expenses', array('expense_id' => $deleted_id));
            $present_paid_amount = isset($expenses) ? $expenses->voucher_amount : 0;
            $invoice_no = isset($expenses) ? $expenses->prefix . $expenses->expense_no : '';
        }

        if ($table_name == 'sonologist') {
            $sonologist = $this->findById('sonologist', array('record_id' => $deleted_id));
            $present_paid_amount = isset($sonologist) ? $sonologist->amount : 0;
            $invoice_no = isset($sonologist) ? $sonologist->record_id : '';
        }

        if ($table_name == 'purchase_orders' || $table_name == 'sales_orders') {
            $column = 'purchase_id';
            $no = "purchase_no";
            if ($table_name == 'sales_orders') {
                $column = 'sales_id';
                $no = "sales_no";
            }
            $bill = $this->findById($table_name, array("$column" => $deleted_id));
            $present_paid_amount = isset($bill) ? $bill->grand_net_total : 0;
            $invoice_no = isset($bill) ? $bill->prefix . $bill->$no : '';
        }

        $this->db->where($table_id, $deleted_id);
        $query = $this->db->delete($table_name);
        if (in_array($table_name, self::$except_table)) {
        } else {
            $this->auditors($table_name, $deleted_id, 'Delete', $loginId, $comments, $previous_paid_amount, $present_paid_amount, $invoice_no);
        }
        return $query;
    }

    function data_between_date($table_name, $column_name, $start_date, $end_date)
    {
        $this->db->where($column_name . '<=', $start_date);
        $this->db->where($column_name . '>=', $end_date);
        $query = $this->db->get($table_name);
        return $query->result();
    }

    function data_between_date_order_by($table_name, $column_name, $start_date, $end_date)
    {
        $this->db->where($column_name . '<=', $start_date);
        $this->db->where($column_name . '>=', $end_date);
        $this->db->order_by($column_name);
        $query = $this->db->get($table_name);
        return $query->result();
    }

    function data_between_date_where($table_name, $column_date, $start_date, $end_date, $where_column, $where_column_value)
    {
        $this->db->where($where_column, $where_column_value);
        $this->db->where($column_date . '<=', $start_date);
        $this->db->where($column_date . '>=', $end_date);
        $query = $this->db->get($table_name);
        return $query->result();
    }

    function weekly_user_created($table_name, $column_date, $start_date, $end_date, $column_user, $column_user_value)
    {
        $this->db->where($column_user, $column_user_value);
        $this->db->where($column_date . '<=', $start_date);
        $this->db->where($column_date . '>=', $end_date);
        $query = $this->db->get($table_name);
        if ($query->num_rows() == 0) {
            return FALSE;
        } else {
            return TRUE;
        }
    }

    function weekly_user_incentive($table_name, $column_date, $start_date, $end_date, $column_user, $column_user_value)
    {
        $this->db->where($column_user, $column_user_value);
        $this->db->where($column_date . '<=', $start_date);
        $this->db->where($column_date . '>=', $end_date);
        $query = $this->db->get($table_name);
        if ($query->num_rows() == 0) {
            return FALSE;
        } else {
            return $query->result();
        }
    }

    function row_number_until_date($table_name, $date_column, $date)
    {
        $this->db->where($date_column . '<=', $date);
        $query = $this->db->get($table_name);
        return $query->num_rows();
    }

    function data_until_date_where_id($table_name, $date_column, $date, $where_column, $where_value)
    {
        $this->db->where($date_column . '<=', $date);
        $this->db->where($where_column, $where_value);
        $query = $this->db->get($table_name);
        return $query->result();
    }

    function data_until_date($table_name, $date_column, $date)
    {
        $this->db->where($date_column . '<=', $date);
        $query = $this->db->get($table_name);
        return $query->result();
    }

    function row_number_single_date($table_name, $date_column, $date)
    {
        $this->db->where($date_column, $date);
        $query = $this->db->get($table_name);
        return $query->num_rows();
    }

    function commission_until_date($table_name, $date_column, $date, $select_column)
    {
        $this->db->select_sum($select_column);
        $this->db->where($date_column . '<=', $date);
        $query = $this->db->get($table_name);
        $value = $query->row($select_column);
        if (empty($value)) {
            return 0;
        } else {
            return $value;
        }
    }

    function commission_single_date($table_name, $date_column, $date, $select_column)
    {
        $this->db->select_sum($select_column);
        $this->db->where($date_column, $date);
        $query = $this->db->get($table_name);
        $value = $query->row($select_column);
        if (empty($value)) {
            return 0;
        } else {
            return $value;
        }
    }

    function toalpayment_until_date($date)
    {
        $this->db->select_sum('getting_amount');
        $this->db->where('action', "yes");
        $this->db->where('STR_TO_DATE(date, "%d %M, %Y") <=', $date);
        $query = $this->db->get('mlm_withdraw');
        $value = $query->row('getting_amount');
        if (empty($value)) {
            return 0;
        } else {
            return $value;
        }
    }

    function toalpayment_data_until_date($date)
    {
        $this->db->where('action', "yes");
        $this->db->where('STR_TO_DATE(date, "%d %M, %Y") <=', $date);
        $query = $this->db->get('mlm_withdraw');
        return $query->result();
    }

    function toalpayment_data_single_date($date)
    {
        $this->db->where('action', "yes");
        $this->db->where('STR_TO_DATE(date, "%d %M, %Y")=', $date);
        $query = $this->db->get('mlm_withdraw');
        return $query->result();
    }

    function totalpayment_single_date($date)
    {
        $this->db->select_sum('getting_amount');
        $this->db->where('action', "yes");
        $this->db->where('STR_TO_DATE(date, "%d %M, %Y")=', $date);
        $query = $this->db->get('mlm_withdraw');
        $value = $query->row('getting_amount');
        if (empty($value)) {
            return 0;
        } else {
            return $value;
        }
    }

    function find_last_id($column_name, $table_name)
    {
        $this->db->order_by($column_name, 'DESC');
        $this->db->limit(1);
        $query = $this->db->get($table_name);
        return $query->result();
    }

    function find_doc_commission($doctor)
    {
        $this->db->where("doctor_name", $doctor);
        $this->db->order_by("record_id", 'DESC');
        $this->db->limit(1);
        $query = $this->db->get("consultancy");
        return $query->row('doctor_commission');
    }

    function sum_one_columm_date_to_date_with_condition($table_name, $sum_col, $column_with_value_array, $date_column, $date_from, $date_to)
    {
        $this->db->select_sum($sum_col);
        $this->db->where($column_with_value_array);
        $this->db->where($date_column . '>=', $date_from);
        $this->db->where($date_column . '<=', $date_to);
        $query = $this->db->get($table_name);
        if ($query->num_rows() == 0) {
            return FALSE;
        } else {
            return $query->result();
        }
    }

    function check_value_get_one_column($column_name, $column_with_value_array, $table_name)
    {
        $this->db->select($column_name);
        $this->db->where($column_with_value_array);
        $query = $this->db->get($table_name);
        if ($query->num_rows() == 0) {
            return FALSE;
        } else {
            return $query->result();
        }
    }

    function data_date_to_date_with_check($table_name, $column_with_value_array, $date_column, $date_from, $date_to)
    {
        $this->db->where($column_with_value_array);
        $this->db->where($date_column . '>=', $date_from);
        $this->db->where($date_column . '<=', $date_to);
        $query = $this->db->get($table_name);
        return $query->result();
    }

    function one_column_group_by($column_name, $table_name)
    {
        $this->db->select($column_name);
        $this->db->group_by($column_name);
        $query = $this->db->get($table_name);
        return $query->result();
    }

    function get_allinfo_byid_groupby($where_column, $where_column_value, $table_name)
    {
        $this->db->where($where_column, $where_column_value);
        $this->db->group_by($where_column);
        $query = $this->db->get($table_name);
        return $query->result();
    }

    function group_by_usual($where_column, $where_column_value, $distinct_column, $table_name)
    {
        $this->db->where($where_column, $where_column_value);
        $this->db->group_by($distinct_column);
        $query = $this->db->get($table_name);
        return $query->result();
    }

    function update_data_onerow_where_array($table_name, $data, $column_with_value_array)
    {
        $this->db->where($column_with_value_array);
        $this->db->update($table_name, $data);
    }

    function find_last_id_where($column_name, $column_with_value_array, $table_name)
    {
        $this->db->where($column_with_value_array);
        $this->db->insert_id($column_name);
        $query = $this->db->get($table_name);
        if ($query->num_rows() < 1) {
            return FALSE;
        } else {
            return $query->result();
        }
    }
    public function save_batch($table, $data)
    {
        return $this->db->insert_batch($table, $data);
    }
    public function saveData($table, $data)
    {

        $loginId = $this->session->userData('ses_record_id');
        $data['created_by'] = $loginId;

        $this->db->insert($table, $data);
        $last_id = $this->db->insert_id();
        $comments = "";
        if (array_key_exists('comments', $data)) {
            $comments = $data['comments'];
        }
        $present_paid_amount = '';
        $previous_paid_amount = '';
        $invoice_no = '';

        if ($table == 'create_bill') {
            if (array_key_exists("paid", $data)) {
                $present_paid_amount = $data['paid'];
            }
            $bill = $this->findById('create_bill', array('record_id' => $last_id));
            $present_paid_amount = isset($bill) ? $bill->paid : 0;
            $invoice_no = isset($bill) ? $bill->prefix . $bill->invoice_no . ' (' . $bill->type . ')' : '';
        }
        if ($table == 'expenses') {
            if (array_key_exists("voucher_amount", $data)) {
                $present_paid_amount = $data['voucher_amount'];
            }
            $expenses = $this->findById('expenses', array('expense_id' => $last_id));
            $present_paid_amount = isset($expenses) ? $expenses->voucher_amount : 0;
            $invoice_no = isset($expenses) ? $expenses->prefix . $expenses->expense_no : '';
        }
        if ($table == 'sonologist') {
            if (array_key_exists("amount", $data)) {
                $present_paid_amount = $data['amount'];
            }
            $sonologist = $this->findById('sonologist', array('record_id' => $last_id));
            $present_paid_amount = isset($sonologist) ? $sonologist->amount : 0;
            $invoice_no = isset($sonologist) ? $sonologist->record_id : '';
        }
        if ($table == 'purchase_orders' || $table == 'sales_orders') {
            $column = 'purchase_id';
            $no = "purchase_no";
            if ($table == 'sales_orders') {
                $column = 'sales_id';
                $no = "sales_no";
            }
            if (array_key_exists("grand_net_total", $data)) {
                $present_paid_amount = $data['grand_net_total'];
            }
            $bill = $this->findById($table, array("$column" => $last_id));
            $present_paid_amount = isset($bill) ? $bill->grand_net_total : 0;
            $invoice_no = isset($bill) ? $bill->prefix . $bill->$no : '';
        }

        if (in_array($table, self::$except_table)) {
        } else {
            $this->auditors($table, $last_id, 'Insert', $loginId, $comments, $previous_paid_amount, $present_paid_amount, $invoice_no);
        }
        return $last_id;
    }
    public function updateData($table, $data, $where)
    {
        $loginId = $this->session->userData('ses_record_id');
        $data['updated_by'] = $loginId;
        //$data['updated_at'] = date('Y-m-d h:m:s') ;
        if (count($where)) {
            $last_id = reset($where);
        } else {
            $last_id = 0;
        }
        $comments = "";
        $invoice_no = "";
        if (array_key_exists("comments", $data)) {
            $comments = $data["comments"];
        }

        $present_paid_amount = 0;
        $previous_paid_amount = 0;

        if ($table == 'create_bill') {
            $bill = $this->findById('create_bill', array('record_id' => $last_id));
            $previous_paid_amount = isset($bill) ? $bill->paid : 0;
            $invoice_no = isset($bill) ? $bill->prefix . $bill->invoice_no . ' (' . $bill->type . ')' : '';
            if (array_key_exists("paid", $data)) {
                $present_paid_amount = $data['paid'];
            }
        }
        if ($table == 'expenses') {
            if (array_key_exists("voucher_amount", $data)) {
                $present_paid_amount = $data['voucher_amount'];
            }
            $expenses = $this->findById('expenses', array('expense_id' => $last_id));
            $previous_paid_amount = isset($expenses) ? $expenses->voucher_amount : 0;
            $invoice_no = isset($expenses) ? $expenses->prefix . $expenses->expense_no : '';
        }
        if ($table == 'sonologist') {
            if (array_key_exists("amount", $data)) {
                $present_paid_amount = $data['amount'];
            }
            $sonologist = $this->findById('sonologist', array('record_id' => $last_id));
            $previous_paid_amount = isset($sonologist) ? $sonologist->amount : 0;
            $invoice_no = isset($sonologist) ? $sonologist->record_id : '';
        }

        if ($table == 'purchase_orders' || $table == 'sales_orders') {
            $column = 'purchase_id';
            $no = "purchase_no";
            if ($table == 'sales_orders') {
                $column = 'sales_id';
                $no = "sales_no";
            }
            if (array_key_exists("grand_net_total", $data)) {
                $present_paid_amount = $data['grand_net_total'];
            }
            $bill = $this->findById($table, array("$column" => $last_id));
            $previous_paid_amount = isset($bill) ? $bill->grand_net_total : 0;
            $invoice_no = isset($bill) ? $bill->prefix . $bill->$no : '';
        }


        if (in_array($table, self::$except_table)) {
        } else {
            $this->auditors($table, $last_id, 'Update', $loginId, $comments, $previous_paid_amount, $present_paid_amount, $invoice_no);
        }
        return $this->db->update($table, $data, $where);
    }
    public function deleteData($table, $where)
    {
        $this->db->delete($table, $where);
    }
    public function findById($table, $where)
    {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($where);
        $query = $this->db->get();
        return $query->row();
    }
    public function findFirstOrLast($table, $where, $orderBy, $serialized)
    {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($where);
        $this->db->order_by($orderBy, $serialized);
        $query = $this->db->get();
        return $query->row();
    }

    public function findAll($table, $where, $orderBy, $serialized)
    {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($where);

        if (is_array($orderBy)) {
            foreach ($orderBy as $key => $value) {
                $this->db->order_by($value, $serialized);
            }
        } else {
            $this->db->order_by($orderBy, $serialized);
        }
        $query = $this->db->get();
        return $query->result();
    }
    public function findAllLimit($table, $where, $orderBy, $serialized, $limit)
    {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($where);
        $this->db->order_by($orderBy, $serialized);
        $this->db->limit($limit, 0);
        $query = $this->db->get();
        return $query->result();
    }
    public function findAllForPagination($table, $where, $orderBy, $serialized, $onset, $limit, $where_in = array(), $where_in_column = '', $groupByColumn = '')
    {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($where);
        if (count($where_in) && !empty($where_in_column))
            $this->db->where_in($where_in_column, $where_in);
        $this->db->order_by($orderBy, $serialized);
        if (!empty($groupByColumn))
            $this->db->group_by($groupByColumn);
        $this->db->limit($limit, $onset);
        $query = $this->db->get();
        return $query->result();
    }
    public function findAllWhereIn($table, $where, $where_in, $columns, $orderBy, $serialized)
    {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($where);
        if (isset($where_in) && count($where_in)) {
            $this->db->where_in($columns, $where_in);
        }
        $this->db->order_by($orderBy, $serialized);
        $query = $this->db->get();
        return $query->result();
    }
    public function findAllWhereNotIn($table, $where, $where_not_in, $columns, $orderBy, $serialized)
    {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($where);
        if (isset($where_not_in) && count($where_not_in)) {
            $this->db->where_not_in($columns, $where_not_in);
        }
        $this->db->order_by($orderBy, $serialized);
        $query = $this->db->get();
        return $query->result();
    }
    public function calCulateSum($table, $where, $sumField, $where_in = array(), $where_in_column = '')
    {
        $this->db->select_sum($sumField);
        $this->db->from($table);
        $this->db->where($where);
        if (isset($where_in) && count($where_in) && !empty($where_in_column)) {
            $this->db->where_in($where_in_column, $where_in);
        }
        $query = $this->db->get();
        return $query->row()->$sumField;
    }
    public function calculateSumMultiple($table, $where, $columns, $where_in = array(), $where_in_column = '')
    {
        foreach ($columns as $key => $value) {
            $this->db->select("sum($value) as $value");
        }
        $this->db->from($table);
        $this->db->where($where);
        if (isset($where_in) && count($where_in) && !empty($where_in_column)) {
            $this->db->where_in($where_in_column, $where_in);
        }
        $query = $this->db->get();
        return $query->row();
    }
    public function findMax($table, $where, $fieldName)
    {
        $this->db->select_max($fieldName);
        $this->db->where($where);
        $result = $this->db->get($table);
        return $result->row();
    }
    /*function findAllGroupBy($table,$where,$column) {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($where);
        $this->db->group_by($column);
        $query = $this->db->get();
        return $query->result();
    }*/
    public function findAllGroupBy($table, $where, $groupBy, $orderBy = '', $serialized = '')
    {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($where);
        if (is_array($groupBy)) {
            foreach ($groupBy as $key => $value) {
                $this->db->group_by($value);
            }
        } else {
            $this->db->group_by($groupBy);
        }
        if (!empty($orderBy) && !empty($serialized)) {
            $this->db->order_by($orderBy, $serialized);
        }
        $query = $this->db->get();
        return $query->result();
    }
    function findAllGroupBySum($table, $where, $groupByColumn, $sumColumn)
    {
        $this->db->select("$table.*,sum($sumColumn) as $sumColumn");
        $this->db->from($table);
        $this->db->where($where);
        $this->db->group_by($groupByColumn);
        $query = $this->db->get();
        return $query->result();
    }
    function findAllGroupByCount($table, $where, $groupByColumn1, $groupByColumn2, $orderBy, $serialized)
    {
        $this->db->select("$table.*,count('*') as no_of_test");
        $this->db->from($table);
        $this->db->where($where);
        $this->db->group_by($groupByColumn1);
        if (!empty($groupByColumn2)) {
            $this->db->group_by($groupByColumn2);
        }
        $this->db->order_by($orderBy, $serialized);
        $query = $this->db->get();
        return $query->result();
    }

    public function commonJoins($table, $options, $where_in = '', $column = '')
    {
        $this->db->select($options['select'])->from($table);
        if (is_array($options['joins']) && count($options['joins']) > 0) {
            foreach ($options['joins'] as $k => $v) {
                $this->db->join($v['table'], $v['condition'], $v['jointype']);
            }
        }
        if (!empty($where_in) && !empty($column)) {
            $this->db->where_in($column, $where_in);
        } else {
            $this->db->where($options['where']);
        }
        foreach ($options['order'] as $key => $value) {
            $this->db->order_by($key, $value);
        }
        if (isset($options['limit'])) {
            $this->db->limit($options['limit'], 0);
        }
        if (array_key_exists('result', $options)) {
            if ($options['result'] === 'array') {
                return $this->db->get()->result_array();
            }
        }
        return $this->db->get()->result_object();
    }
    public function commonJoinsRow($table, $options)
    {
        $this->db->select($options['select'])->from($table);
        if (is_array($options['joins']) && count($options['joins']) > 0) {
            foreach ($options['joins'] as $k => $v) {
                $this->db->join($v['table'], $v['condition'], $v['jointype']);
            }
        }
        $this->db->where($options['where']);
        foreach ($options['order'] as $key => $value) {
            $this->db->order_by($key, $value);
        }
        if (array_key_exists('result', $options)) {
            if ($options['result'] === 'array') {
                return $this->db->get()->result_array();
            }
        }
        return $this->db->get()->row();
    }
    public function average_purchase($product_id)
    {
        $this->db->select('round(SUM(purchase_price * order_qty) / SUM(order_qty),2) as average_purchase');
        $this->db->from('purchase_order_details');
        $this->db->where('product_id', $product_id);
        $this->db->where('status', 'Active');
        $query = $this->db->get();
        return $query->row()->average_purchase;
    }
    public function item_balance($product_id)
    {
        $order_qty = 0;
        $free_qty = 0;
        $this->db->select("sum(order_qty) as order_qty,sum(free_qty) as free_qty");
        $this->db->from('purchase_order_details');
        $this->db->where('product_id', $product_id);
        $this->db->where('status', 'Active');
        $purchase_query = $this->db->get()->row();
        $order_qty = isset($purchase_query) ? $purchase_query->order_qty : 0;
        $free_qty = isset($purchase_query) ? $purchase_query->free_qty : 0;
        $purchase_qty = $order_qty + $free_qty;

        $order_qty = 0;
        $free_qty = 0;
        $this->db->select("sum(order_qty) as order_qty,sum(free_qty) as free_qty");
        $this->db->from('sales_order_details');
        $this->db->where('product_id', $product_id);
        $this->db->where('status', 'Active');
        $sales_query = $this->db->get()->row();
        $order_qty = isset($sales_query) ? $sales_query->order_qty : 0;
        $free_qty = isset($sales_query) ? $sales_query->free_qty : 0;
        $sales_qty = $order_qty + $free_qty;


        $order_qty = 0;
        $free_qty = 0;
        $this->db->select("sum(return_qty) as return_qty");
        $this->db->from('return_details');
        $this->db->where('product_id', $product_id);
        $this->db->where('status', 'Active');
        $supplier_return_query = $this->db->get()->row();
        $supplier_return_qty = isset($supplier_return_query) ? $supplier_return_query->return_qty : 0;

        $order_qty = 0;
        $free_qty = 0;
        $this->db->select("sum(return_qty) as return_qty");
        $this->db->from('customer_return_details');
        $this->db->where('product_id', $product_id);
        $this->db->where('status', 'Active');
        $customer_return_query = $this->db->get()->row();
        $customer_return_qty = isset($customer_return_query) ? $customer_return_query->return_qty : 0;
        $balance = $purchase_qty + $customer_return_qty - $sales_qty - $supplier_return_qty;

        return $balance;
    }
    public function item_balance_lab($product_id)
    {
        $in_quantity = 0;
        $free_qty = 0;
        $this->db->select("sum(quantity) as quantity");
        $this->db->from('lab_product_in_details');
        $this->db->where('product_id', $product_id);
        $out_query = $this->db->get()->row();
        $in_quantity = isset($out_query) ? $out_query->quantity : 0;

        $out_quantity = 0;
        $this->db->select("sum(quantity) as quantity");
        $this->db->from('lab_product_out_details');
        $this->db->where('product_id', $product_id);
        $out_query = $this->db->get()->row();
        $out_quantity = isset($out_query) ? $out_query->quantity : 0;

        $balance = $in_quantity - $out_quantity;

        return $balance;
    }
    public function item_balance_details($product_id)
    {
        $order_qty = 0;
        $free_qty = 0;
        $this->db->select("sum(order_qty) as order_qty,sum(free_qty) as free_qty");
        $this->db->from('purchase_order_details');
        $this->db->where('product_id', $product_id);
        $this->db->where('status', 'Active');
        $purchase_query = $this->db->get()->row();
        $order_qty = isset($purchase_query) ? $purchase_query->order_qty : 0;
        $free_qty = isset($purchase_query) ? $purchase_query->free_qty : 0;
        $purchase_qty = $order_qty + $free_qty;

        $order_qty = 0;
        $free_qty = 0;
        $this->db->select("sum(order_qty) as order_qty,sum(free_qty) as free_qty");
        $this->db->from('sales_order_details');
        $this->db->where('product_id', $product_id);
        $this->db->where('status', 'Active');
        $sales_query = $this->db->get()->row();
        $order_qty = isset($sales_query) ? $sales_query->order_qty : 0;
        $free_qty = isset($sales_query) ? $sales_query->free_qty : 0;
        $sales_qty = $order_qty + $free_qty;


        $order_qty = 0;
        $free_qty = 0;
        $this->db->select("sum(return_qty) as return_qty");
        $this->db->from('return_details');
        $this->db->where('product_id', $product_id);
        $this->db->where('status', 'Active');
        $supplier_return_query = $this->db->get()->row();
        $supplier_return_qty = isset($supplier_return_query) ? $supplier_return_query->return_qty : 0;

        $order_qty = 0;
        $free_qty = 0;
        $this->db->select("sum(return_qty) as return_qty");
        $this->db->from('customer_return_details');
        $this->db->where('product_id', $product_id);
        $this->db->where('status', 'Active');
        $customer_return_query = $this->db->get()->row();
        $customer_return_qty = isset($customer_return_query) ? $customer_return_query->return_qty : 0;
        $balance = $purchase_qty + $customer_return_qty - $sales_qty - $supplier_return_qty;

        $response = new stdClass;
        $response->purchase_qty = $purchase_qty;
        $response->sales_qty = $sales_qty;
        $response->supplier_return_qty = $supplier_return_qty;
        $response->customer_return_qty = $customer_return_qty;
        $response->balance = $balance;
        return $response;
    }
    public function countAll($table, $where, $where_in = array(), $where_in_column = '', $groupByColumn = '')
    {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($where);
        if (count($where_in) && !empty($where_in_column))
            $this->db->where_in($where_in_column, $where_in);
        if (!empty($groupByColumn))
            $this->db->group_by($groupByColumn);
        return $this->db->count_all_results();
    }
    private function auditors($table_name, $insert_update_id, $action, $action_by, $comments, $previous_paid_amount, $present_paid_amount, $invoice_no)
    {
        $refer =  $this->agent->referrer();
        $refer = str_replace(base_url(), '', $refer);
        $menu_link = $refer;
        $a = "delete";
        if (strpos($refer, $a) !== false) {
            $ex = explode('/', $refer);
            $menu_link = $ex[0];
        }
        $a = "edit";

        if (strpos($refer, $a) !== false) {
            $ex = explode('/', $refer);
            $menu_link = $ex[0];
        }
        $a = "delete";
        if (strpos($refer, $a) !== false) {
            $ex = explode('/', $refer);
            $menu_link = $ex[0];
        }
        $menu = $this->findById('menu_list', array('menu_link' => $menu_link));
        $data = array(
            'table_name' => $table_name,
            'insert_update_id' => $insert_update_id,
            'parent_menu_id' => isset($menu) ? $menu->parent_id : 0,
            'sub_menu_id' => isset($menu) ? $menu->menu_id : 0,
            'url' => $refer,
            'action' => $action,
            'action_by' => $action_by,
            'comments' => $comments,
            'previous_paid_amount' => $previous_paid_amount,
            'present_paid_amount' => $present_paid_amount,
            'invoice_no' => $invoice_no,
        );
        $this->db->insert('auditors', $data);
        return 1;
    }
    public function columns($table, $where, $column)
    {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($where);
        $query = $this->db->get();
        $result = $query->result_array();
        return array_column($result, $column);
    }

    public function getTestFields($test_cat_id, $test_name_id){

        $this->db->select('
                    test_fields.record_id, 
                    test_fields.field_name, 
                    test_fields.reference_value, 
                    test_fields.priority, 
                    test_fields.field_code, 
                    test_name.test_name, 
                    test_fields.field_unit_name, 
                    test_category.test_category,
                    test_group_name.group_name')
                    ->from('test_fields')
                    ->join('test_name', 'test_name.record_id = test_fields.test_name_id')
                    ->join('test_category', 'test_category.record_id = test_fields.test_category_id')
                    ->join('test_group_name', 'test_group_name.record_id = test_fields.test_group_id', 'left');
        if($test_cat_id > 0){
            $this->db->where('test_fields.test_category_id', $test_cat_id);
        }
        if($test_name_id > 0){
            $this->db->where('test_fields.test_name_id', $test_name_id);
        }
        $this->db->order_by('test_fields.record_id', 'DESC');

        return $this->db->get()->result();
    }

    function getTestDetails($testID){
        $this->db->select('
                    test_name.*, 
                    test_category.test_category as category_name, 
                    test_category.analyzer_name')
                    ->from('test_name')
                    ->join('test_category', 'test_category.record_id = test_name.test_category_id');
                    if(is_array($testID)){
                        $this->db->where_in('test_name.record_id', $testID);
                        return $this->db->get()->result();
                    }else{
                        $this->db->where('test_name.record_id', $testID);
                        return $this->db->get()->row();
                    } 
    }

    function checkIfTestExists($date, $invoice_id, $patient_id, $test_category_id, $test_name_id){

        $this->db->select('test_reports.*')
                 ->from('test_reports')
                 ->join('test_report_names', 'test_report_names.test_report_id = test_reports.record_id')
                 ->where('test_reports.collection_date', $date)
                 ->where('test_reports.invoice_id', $invoice_id)
                 ->where('test_reports.patient_id', $patient_id)
                 ->where('test_reports.test_category_id', $test_category_id)
                 ->where('test_report_names.test_name_id', $test_name_id);

        return $this->db->get()->row();

    }

    function getTestReportDetails($reportID){

        $testReportInfo = $this->getReportInfo($reportID);

        $testReportFields = $this->getTestReportFieldDetails($testReportInfo->record_id);

        $groupWiseTestFields = [];
        foreach($testReportFields as $row){

            if(!isset($groupWiseTestFields[$row->test_group_id])){
                $groupWiseTestFields[$row->test_group_id] = new stdClass;
                $groupWiseTestFields[$row->test_group_id]->name = $row->group_name;
                $groupWiseTestFields[$row->test_group_id]->fields = [];
            }
            $groupWiseTestFields[$row->test_group_id]->fields[] = $row;
        }

        $testReportDetails = new stdClass;
        $testReportDetails = $testReportInfo;
        $testReportDetails->reportFieldData = $groupWiseTestFields;

        // ddd($testReportDetails);

        return $testReportDetails;
    }

    function getTestReportFieldDetails($reportID){

        $this->db->select('test_fields.field_name, 
                           test_fields.reference_value,
                           test_fields.field_unit_name,
                           test_fields.test_group_id,
                           test_group_name.group_name, 
                           test_report_fields.test_field_id, 
                           test_report_fields.value 
                           ')
                           ->from('test_report_fields')
                           ->join('test_fields', 'test_fields.record_id = test_report_fields.test_field_id')
                           ->join('test_group_name', 'test_group_name.record_id = test_fields.test_group_id', 'left')
                           ->where('test_report_fields.test_report_id', $reportID)
                           ->order_by('test_group_name.record_id', 'ASC')
                           ->order_by('test_fields.priority', 'ASC');

                           return $this->db->get()->result();

    }

    function getReportInfo($reportID){

        $this->db->select('test_reports.*, 
                            cb.invoice_no,
                           doctor.name as referred_doc,
                           ref_doctor.name as referred_doc,
                           duty_doctor.name as duty_doc_name,
                           duty_doctor.photo as duty_doc_sign,
                           ref_doctor_designation.designation as ref_doc_designation,
                           duty_doctor_designation.designation as duty_doc_designation,
                           staff.name as staff_name,
                           staff.image as staff_sign,
                           staff2.name as staff_name2,
                           staff2.image as staff_sign2,
                           staff3.name as staff_name3,
                           staff3.image as staff_sign3,
                           staff4.name as staff_name4,
                           staff4.image as staff_sign4,
                           staff.designation as staff_designation,
                           staff2.designation as staff2_designation,
                           staff3.designation as staff3_designation,
                           staff4.designation as staff4_designation,
                           test_category.test_category as category_name,
                           test_category.analyzer_name,
                           test_category.report_header,
                           test_category.test_method,
                           specimen
                           ')
                           ->from('test_reports')
                           ->join('test_category', 'test_category.record_id = test_reports.test_category_id')
                           ->join('doctor as ref_doctor', 'ref_doctor.record_id = test_reports.doctor_id')
                           ->join('designation as ref_doctor_designation', 'ref_doctor_designation.record_id = ref_doctor.designation_id')
                           ->join('doctor as duty_doctor', 'duty_doctor.record_id = test_reports.duty_doctor_id', 'left')
                           ->join('designation as duty_doctor_designation', 'duty_doctor_designation.record_id = duty_doctor.designation_id', 'left')
                           ->join('staff', 'staff.record_id = test_reports.duty_staff_id', 'left')
                           ->join('create_bill cb', 'cb.record_id = test_reports.invoice_id', 'left')
                           ->join('staff as staff2', 'staff2.record_id = test_reports.duty_staff_id2', 'left')
                           ->join('staff as staff3', 'staff3.record_id = test_reports.created_by', 'left')
                           ->join('staff as staff4', 'staff4.record_id = test_reports.approved_by', 'left')
                           ->join('doctor', 'doctor.record_id = test_reports.doctor_id')
                           ->join('specimens', 'specimens.test_category_id = test_reports.test_category_id', 'left')
                           ->where('test_reports.record_id', $reportID);

        return $this->db->get()->row();
    }

    function getAllReports($fromDate, $toDate, $testNameID){
        $this->db->select('test_reports.*,
                           ref_doctor.name as referred_doc,
                           duty_doctor.name as duty_doc_name,
                           ref_doctor_designation.designation as ref_doc_designation,
                           duty_doctor_designation.designation as duty_doc_designation,
                           staff.name as staff_name,
                           staff.designation as staff_designation,
                           test_category.test_category as category_name,
                           test_category.analyzer_name,
                           test_category.report_header,
                           GROUP_CONCAT(test_name.test_name SEPARATOR "<br>") as test_names,
                           patient.name as patient_name
                           ')
                           ->from('test_reports')
                           ->join('test_category', 'test_category.record_id = test_reports.test_category_id')
                           ->join('test_report_names', 'test_report_names.test_report_id = test_reports.record_id')
                           ->join('test_name', 'test_name.record_id = test_report_names.test_name_id')
                           ->join('doctor as ref_doctor', 'ref_doctor.record_id = test_reports.doctor_id')
                           ->join('designation as ref_doctor_designation', 'ref_doctor_designation.record_id = ref_doctor.designation_id', 'left')
                           ->join('doctor as duty_doctor', 'duty_doctor.record_id = test_reports.duty_doctor_id', 'left')
                           ->join('designation as duty_doctor_designation', 'duty_doctor_designation.record_id = duty_doctor.designation_id', 'left')
                           ->join('staff', 'staff.record_id = test_reports.duty_staff_id', 'left')
                           ->join('patient', 'patient.record_id = test_reports.patient_id')
                           ->having('test_names IS NOT NULL');

                           if($fromDate){
                            $this->db->where('test_reports.collection_date>=', $fromDate);
                           }
                           if($toDate){
                            $this->db->where('test_reports.collection_date<=', $toDate);
                           }
                           if($testNameID){
                            $this->db->where('test_report_names.test_name_id', $testNameID);
                           }
                           $this->db->group_by('test_reports.record_id');
                           $this->db->order_by('test_reports.record_id', "DESC");

        return $this->db->get()->result();
    }

    function getInvoiceTestCategories($invoiceID, $PatientID, $date) { 

        $this->db->select('test_category.record_id, test_category.test_category')
                 ->from('test_category')
                 ->join('sales_test', 'sales_test.test_category_id = test_category.record_id')
                 ->where('sales_test.invoice_no', $invoiceID)
                 ->where('sales_test.patient_id', $PatientID)
                 ->where('sales_test.date', $date)
                 ->group_by('test_category.record_id')
                 ->order_by('test_category.test_category', 'ASC');

        return $this->db->get()->result();
    }

    public function getPreviousSimilarResult($testCatID, $testNameID){

        $this->db->select('test_report_fields.test_field_id, test_report_fields.value')
                 ->from('test_report_fields')
                 ->join('test_reports', 'test_reports.record_id = test_report_fields.test_report_id')
                 ->join('test_report_names', 'test_report_names.test_report_id = test_reports.record_id')
                 ->where('test_reports.test_category_id', $testCatID)
                 ->where('test_report_names.test_name_id', $testNameID)
                 ->group_by('test_report_fields.record_id');


        $lastInsertedData = $this->db->get()->result();

        $sortedData = [];
        if(!empty($lastInsertedData)){

            foreach($lastInsertedData as $row){

                $sortedData[$row->test_field_id] = new stdClass();
                $sortedData[$row->test_field_id] = $row; 

            }

        }
        return $sortedData;

    }
	
	function getAllReportsBlank($fromDate, $toDate, $testNameID){
        $this->db->select('test_reports.*, 
                           doctor.name as referred_doc,
                           ref_doctor.name as referred_doc,
                           duty_doctor.name as duty_doc_name,
                           ref_doctor_designation.designation as ref_doc_designation,
                           duty_doctor_designation.designation as duty_doc_designation,
                           staff.name as staff_name,
                           staff.designation as staff_designation,
                           test_category.test_category as category_name,
                           test_category.analyzer_name,
                           test_category.report_header,
                           test_name.test_name as test_names,
                           patient.name as patient_name
                          
                           ')
                           ->from('test_reports')
                           ->join('test_category', 'test_category.record_id = test_reports.test_category_id', 'left')
                           ->join('test_report_names', 'test_report_names.test_report_id = test_reports.record_id', 'left')
                           ->join('test_name', 'test_name.record_id = test_report_names.test_name_id', 'left')
                           ->join('doctor as ref_doctor', 'ref_doctor.record_id = test_reports.doctor_id', 'left')
                           ->join('designation as ref_doctor_designation', 'ref_doctor_designation.record_id = test_reports.doctor_id', 'left')
                           ->join('doctor as duty_doctor', 'duty_doctor.record_id = test_reports.duty_doctor_id', 'left')
                           ->join('designation as duty_doctor_designation', 'duty_doctor_designation.record_id = duty_doctor.designation_id', 'left')
                           ->join('staff', 'staff.record_id = test_reports.duty_staff_id', 'left')
                           ->join('doctor', 'doctor.record_id = test_reports.doctor_id', 'left')
                           ->join('patient', 'patient.record_id = test_reports.patient_id', 'left')
                           ->join('create_bill', 'create_bill.record_id = test_reports.invoice_id', 'left');
                           //->having('test_names IS NOT NULL');

                           if($fromDate){
                            $this->db->where('test_reports.collection_date>=', $fromDate);
                           }
                           if($toDate){
                            $this->db->where('test_reports.collection_date<=', $toDate);
                           }
                           if($testNameID){
                            $this->db->where('test_report_names.test_name_id', $testNameID);
                           }
                           $this->db->group_by('test_reports.record_id');
                           $this->db->order_by('test_reports.record_id', "DESC");

        return $this->db->get()->result();
    }

    function getRfCommissionReports($refCommWhere){

        $this->db->select('create_bill.*, 
                           reference_by.reference_name,
                           reference_by.record_id as ref_record_id,
                           test_doctor.name as doc_name, 
                           test_doctor.record_id as doc_id, 
                           ref_doctor.record_id as ref_doc_id,
                           ref_doctor.name as ref_doc_name')
                 ->from('create_bill')
                 ->join('doctor as test_doctor', 'test_doctor.record_id = create_bill.doctor_id')
                 ->join('reference_by', '(reference_by.record_id = create_bill.reference_by AND create_bill.discount_type IN (1,4))', 'LEFT')
                 ->join('doctor as ref_doctor', '(ref_doctor.record_id = create_bill.reference_by AND create_bill.discount_type IN (2,5))', 'LEFT')
                 ->where($refCommWhere)
                 ->order_by('create_bill.record_id');

        return $this->db->get()->result();

    }

    function get_last_appointment($date, $doctor)
    {
        $this->db->select('serial_no');
        $this->db->from('appointments');
        $this->db->where('date', $date);
        $this->db->where('doctor_id', $doctor);
        $this->db->order_by('record_id', 'DESC');
        $this->db->limit(1);
        //$query = $this->db->get('appointments');
        return $this->db->get()->row();
    }

/////////////////////pharmacy///////////////////////
    function recordProductDailyStock($productId, $purchasePrice, $salesPrice, $wholeSalePrice, $type){
        $currentStock = itemBalance($productId, $type);
        
        $todayDate = date("Y-m-d");

        $existingData = $this->db->get_where('product_stock_history', ['stock_date' => $todayDate, 'product_id' => $productId, 'type' => $type])->row();

        if(!empty($existingData)){
            $updateData['stock_qty'] =  $currentStock;
            $updateData['purchase_price'] =  $purchasePrice;
            $updateData['sales_price'] =  $salesPrice;
            $updateData['whole_sales_price'] =  $wholeSalePrice;

            $this->db->update('product_stock_history', $updateData, ['record_id' => $existingData->record_id]);
        }else{
            $insertData['stock_qty'] =  $currentStock;
            $insertData['purchase_price'] =  $purchasePrice;
            $insertData['sales_price'] =  $salesPrice;
            $insertData['whole_sales_price'] =  $wholeSalePrice;
            $insertData['stock_date'] =  $todayDate;
            $insertData['type'] =  $type;
            $insertData['product_id'] =  $productId;

            $this->db->insert('product_stock_history', $insertData);
        }
    }

    public function getMedicineDateToDatePurchaseOrders($fromDate, $toDate, $productID, $product_type){

        $this->db->select('
                        purchase_orders.purchase_date, 
                        SUM(purchase_order_details.order_qty + purchase_order_details.free_qty) as total,
                        purchase_order_details.product_id
                        ')
                 ->from('purchase_order_details')
                 ->join('purchase_orders', 'purchase_order_details.purchase_order_id = purchase_orders.purchase_id')
                 ->where('purchase_orders.purchase_date>=', $fromDate)
                 ->where('purchase_orders.purchase_date<=', $toDate)
                 ->where('purchase_order_details.product_id', $productID)
                 ->where('purchase_order_details.purchase_type', $product_type)
                 ->group_by('purchase_orders.purchase_date')
                 ->order_by('purchase_orders.purchase_date', "ASC");

        return $this->db->get()->result();
    }

    public function getMedicineDateToDateSalesOrders($fromDate, $toDate, $productID, $product_type){

        $this->db->select('
                        sales_orders.sales_date, 
                        SUM(sales_order_details.order_qty + sales_order_details.free_qty) as total,
                        sales_order_details.product_id
                        ')
                 ->from('sales_order_details')
                 ->join('sales_orders', 'sales_order_details.sales_order_id = sales_orders.sales_id')
                 ->where('sales_orders.sales_date>=', $fromDate)
                 ->where('sales_orders.sales_date<=', $toDate)
                 ->where('sales_order_details.product_id', $productID)
                 ->where('sales_order_details.sales_type', $product_type)
                 ->group_by('sales_orders.sales_date')
                 ->order_by('sales_orders.sales_date', "ASC");

        return $this->db->get()->result();
    }

    public function getMedicineDateToDatePurchaseReturns($fromDate, $toDate, $productID, $product_type){

        $this->db->select('
                        return_manages.return_date, 
                        SUM(return_details.return_qty) as total,
                        return_details.product_id
                        ')
                 ->from('return_details')
                 ->join('return_manages', 'return_details.return_id = return_manages.return_id')
                 ->where('return_manages.return_date>=', $fromDate)
                 ->where('return_manages.return_date<=', $toDate)
                 ->where('return_details.product_id', $productID)
                 ->where('return_details.return_type', $product_type)
                 ->group_by('return_manages.return_date')
                 ->order_by('return_manages.return_date', "ASC");

        return $this->db->get()->result();
    }

    public function getMedicineDateToDateSalesReturns($fromDate, $toDate, $productID, $product_type){

        $this->db->select('
                        customer_return_manages.return_date, 
                        SUM(customer_return_details.return_qty) as total,
                        customer_return_details.product_id
                        ')
                 ->from('customer_return_details')
                 ->join('customer_return_manages', 'customer_return_details.return_id = customer_return_manages.return_id')
                 ->where('customer_return_manages.return_date>=', $fromDate)
                 ->where('customer_return_manages.return_date<=', $toDate)
                 ->where('customer_return_details.product_id', $productID)
                 ->where('customer_return_details.return_type', $product_type)
                 ->group_by('customer_return_manages.return_date')
                 ->order_by('customer_return_manages.return_date', "ASC");
        
        return $this->db->get()->result();
        }

        public function getToDateProductBalance($productID, $toDate, $product_type){

            $this->db->select("sum(purchase_order_details.order_qty + purchase_order_details.free_qty) as total");
            $this->db->from('purchase_order_details');
            $this->db->join('purchase_orders', 'purchase_orders.purchase_id = purchase_order_details.purchase_order_id');
            $this->db->where('purchase_orders.purchase_date<', $toDate);
            $this->db->where('purchase_order_details.product_id', $productID);
            $this->db->where('purchase_order_details.purchase_type', $product_type);
            $this->db->where('purchase_order_details.status','Active');
            $purchase_query = $this->db->get()->row();
            $purchase_qty = ($purchase_query->total > 0) ?  $purchase_query->total : 0;
    
            $this->db->select("sum(sales_order_details.order_qty + sales_order_details.free_qty) as total");
            $this->db->from('sales_order_details');
            $this->db->join('sales_orders', 'sales_orders.sales_id = sales_order_details.sales_order_id');
            $this->db->where('sales_orders.sales_date<', $toDate);
            $this->db->where('sales_order_details.product_id',$productID);
            $this->db->where('sales_order_details.sales_type', $product_type);
            $this->db->where('sales_order_details.status','Active');
            $sales_query = $this->db->get()->row();
            $sales_qty = ($sales_query->total > 0) ? $sales_query->total: 0 ;
    
            $this->db->select("sum(return_qty) as return_qty");
            $this->db->from('return_details');
            $this->db->where('product_id',$productID);
            $this->db->where('return_type', $product_type);
            $this->db->where('status','Active');
            $this->db->where('created_at<', $toDate);
            $supplier_return_query = $this->db->get()->row();
            $supplier_return_qty = ($supplier_return_query->return_qty > 0) ?$supplier_return_query->return_qty:0 ;
    
            $this->db->select("sum(return_qty) as return_qty");
            $this->db->from('customer_return_details');
            $this->db->where('product_id',$productID);
            $this->db->where('return_type', $product_type);
            $this->db->where('status','Active');
            $this->db->where('created_at<', $toDate);
            $customer_return_query = $this->db->get()->row();
            $customer_return_qty = ($customer_return_query->return_qty > 0)?$customer_return_query->return_qty:0 ;
            $balance = $purchase_qty + $customer_return_qty - $sales_qty - $supplier_return_qty;
    
            $response = new stdClass;
            $response->purchase_qty = $purchase_qty ;
            $response->sales_qty = $sales_qty ;
            $response->supplier_return_qty = $supplier_return_qty ;
            $response->customer_return_qty = $customer_return_qty ;
            $response->balance = $balance ;
            return $response ;
    
        }

        function getAllPaginatedProducts($monthYear, $shelfId = 0, $product_id = 0, $limit = 50, $offset = 0, $supplierId = 0){

            $fromDate = date('Y-m-01 00:00:00', strtotime($monthYear));
            $toDate = date('Y-m-t 23:59:59', strtotime($monthYear));
    
            // $prevfromDate = date('Y-m-01', strtotime($monthYear." -1 month"));
            $prevfromDate = '';
            $prevtoDate = date('Y-m-t 23:59:59', strtotime($monthYear." -1 month"));
    
            $products = $this->getProductList($limit, $offset, $product_id, $shelfId, $supplierId);
            //$drug = $this->getMDrugList($limit, $offset, $product_id, $shelfId);
    
            // ddd($products);
    
            $prodArr = reOrderArr($products, 'record_id');
            
    
            //$previousPurchases = $this->getDateRangedPurchasedProducts('', $toDate, $prodArr);
            $previousPurchases = $this->getDateRangedPurchasedProducts($prevfromDate, $prevtoDate, $prodArr);
            $prevPurArr = serializeArr($previousPurchases, 'product_id');
    
            //$previousSales = $this->getDateRangedSoldProducts('', $toDate, $prodArr);
            $previousSales = $this->getDateRangedSoldProducts($prevfromDate, $prevtoDate, $prodArr);
            $prevSalesArr = serializeArr($previousSales, 'product_id');
    
            //$previousSupplierReturns = $this->getDateRangedSupplierReturnedProducts('', $toDate, $prodArr);
            $previousSupplierReturns = $this->getDateRangedSupplierReturnedProducts($prevfromDate, $prevtoDate, $prodArr);
            $prevSupReturnArr = serializeArr($previousSupplierReturns, 'product_id');
    
            //$previousCustomerReturns = $this->getDateRangedCustomerReturnedProducts('', $toDate, $prodArr);
            $previousCustomerReturns = $this->getDateRangedCustomerReturnedProducts($prevfromDate, $prevtoDate, $prodArr);
            $prevCusReturnArr = serializeArr($previousCustomerReturns, 'product_id');
    
            $currentPurchases = $this->getDateRangedPurchasedProducts($fromDate, $toDate, $prodArr);
            $curPurArr = serializeArr($currentPurchases, 'product_id');
    
            $currentSales = $this->getDateRangedSoldProducts($fromDate, $toDate, $prodArr);
            $curSaleArr = serializeArr($currentSales, 'product_id');
    
            $currentSupplierReturns = $this->getDateRangedSupplierReturnedProducts($fromDate, $toDate, $prodArr);
            $curSupReturnArr = serializeArr($currentSupplierReturns, 'product_id');
    
            $currentCustomerReturns = $this->getDateRangedCustomerReturnedProducts($fromDate, $toDate, $prodArr);
            $curCusReturnArr = serializeArr($currentCustomerReturns, 'product_id');
    
            $rArr = [];
    
            $rArr = $this->calculateAllProductData($products, $prevPurArr, $prevSalesArr, $prevSupReturnArr, $prevCusReturnArr, $curPurArr, $curSaleArr, $curSupReturnArr, $curCusReturnArr);
            // ddd($this->db->last_query());
            // ddd($rArr);
    
            return  $rArr;
    
        }

        function getProductList($limit, $offset, $productId, $shelfId, $supplierId){

            $this->db->select('product_name.record_id, product_name.product_name, product_name.code_no, shelf.shelf_name, shelf.shelf_no, purchase_order_details.order_qty, purchase_order_details.purchase_date, product_name.purchase_price, product_name.unit_price, product_name.sales_price,  product_name.type, product_name.shelf_id')
            ->from('product_name')
            ->join('purchase_order_details', 'purchase_order_details.product_id = product_name.record_id', 'left')
            ->join('shelf', 'shelf.record_id = product_name.shelf_id', 'left');
    
            if($productId > 0){
                $this->db->where('product_name.record_id', $productId);
            }
            if($shelfId > 0){
                $this->db->where('product_name.shelf_id', $shelfId);
            }
            if($supplierId > 0){
                $this->db->where('product_name.supplier_id', $supplierId);
            }
            $this->db->where('purchase_order_details.purchase_type', 'Product');
            if($limit > 0){
                $this->db->where('product_name.warehouse', 'Pharmacy')
                ->limit($limit, $offset);
            }
            $this->db->where('product_name.warehouse', 'Pharmacy');
            $this->db->where('product_name.type', 'product')
            ->order_by('purchase_order_details.purchase_date', 'DESC')
            ->group_by('product_name.record_id');
            return $this->db->get()->result();
    
        }

        function getDateRangedPurchasedProducts($fromDate, $toDate, $productArr = []){

            $this->db->select('product_name.product_name, purchase_order_details.product_id, SUM(purchase_order_details.order_qty) as total_bought, SUM(purchase_order_details.free_qty) as total_free_qty')
                     ->from('product_name')
                     ->join('purchase_order_details', 'purchase_order_details.product_id = product_name.record_id');
    
    
            if(!empty($fromDate) && !empty($toDate)){
                $this->db->where("purchase_order_details.purchase_date between '$fromDate' AND '$toDate'");
            }else if(!empty($fromDate)){
                $this->db->where('purchase_order_details.purchase_date>=', $fromDate);
            }else if(!empty($toDate)){
                $this->db->where('purchase_order_details.purchase_date<=', $toDate);
            }
            if(sizeof($productArr) > 0){
                $this->db->where_in('product_name.record_id', $productArr);
            }
    
            $this->db->where('purchase_order_details.purchase_type', 'Product');
    
            $this->db->order_by('purchase_order_details.purchase_date', 'desc')->group_by('purchase_order_details.product_id');
    
            return $this->db->get()->result();
        }
    
        function getDateRangedSoldProducts($fromDate, $toDate, $productArr = []){
    
            $this->db->select('product_name.product_name, sales_order_details.product_id, SUM(sales_order_details.order_qty) as total_sold, SUM(sales_order_details.free_qty) as total_free_qty')
                     ->from('product_name')
                     ->join('sales_order_details', 'sales_order_details.product_id = product_name.record_id');
    
            if(!empty($fromDate) && !empty($toDate)){
                $this->db->where("sales_order_details.sales_date between '$fromDate' AND '$toDate'");
            }else if(!empty($fromDate)){
                $this->db->where('sales_order_details.sales_date>=', $fromDate);
            }else if(!empty($toDate)){
                $this->db->where('sales_order_details.sales_date<=', $toDate);
            }
            if(sizeof($productArr) > 0){
                $this->db->where_in('product_name.record_id', $productArr);
            }
            $this->db->where('sales_order_details.sales_type', 'Product');
            $this->db->order_by('sales_order_details.sales_date', 'desc')->group_by('sales_order_details.product_id');
    
            return $this->db->get()->result();
        }
    
        function getDateRangedSupplierReturnedProducts($fromDate, $toDate, $productArr = []){
    
            $this->db->select('return_details.product_id, SUM(return_details.return_qty) as total_return, SUM(return_details.free_qty) as total_free_qty')
                     ->from('return_details')
                     ->join('return_manages', 'return_manages.return_id = return_details.return_id');
    
            if(!empty($fromDate) && !empty($toDate)){
                $this->db->where("return_manages.return_date between '$fromDate' AND '$toDate'");
            }else if(!empty($fromDate)){
                $this->db->where('return_manages.return_date>=', $fromDate);
            }else if(!empty($toDate)){
                $this->db->where('return_manages.return_date<=', $toDate);
            }
            if(sizeof($productArr) > 0){
                $this->db->where_in('return_details.product_id', $productArr);
            }
            $this->db->where('return_details.return_type', 'Product');
            $this->db->order_by('return_manages.return_date', 'desc')->group_by('return_details.product_id');
    
            return $this->db->get()->result();
        }
    
        function getDateRangedCustomerReturnedProducts($fromDate, $toDate, $productArr = []){
    
            $this->db->select('customer_return_details.product_id, SUM(customer_return_details.return_qty) as total_return, SUM(customer_return_details.free_qty) as total_free_qty')
                     ->from('customer_return_details')
                     ->join('customer_return_manages', 'customer_return_manages.return_id = customer_return_details.return_id');
    
            if(!empty($fromDate) && !empty($toDate)){
                $this->db->where("customer_return_manages.return_date between '$fromDate' AND '$toDate'");
            }else if(!empty($fromDate)){
                $this->db->where('customer_return_manages.return_date>=', $fromDate);
            }else if(!empty($toDate)){
                $this->db->where('customer_return_manages.return_date<=', $toDate);
            }
            if(sizeof($productArr) > 0){
                $this->db->where_in('customer_return_details.product_id', $productArr);
            }
    
            $this->db->where('customer_return_details.return_type', 'Product');
    
            $this->db->order_by('customer_return_manages.return_date', 'desc')->group_by('customer_return_details.product_id');
    
            return $this->db->get()->result();
        }

        function calculateAllProductData($products, $prevPurArr, $prevSalesArr, $prevSupReturnArr, $prevCusReturnArr, $curPurArr, $curSaleArr, $curSupReturnArr, $curCusReturnArr){

            $rArr = [];
    
            foreach($products as $product){
                $prodId = $product->record_id;
                if(!isset($rArr[$prodId])){
                    $rArr[$prodId] = new stdClass();
                    $rArr[$prodId] = $product;
                    $rArr[$prodId]->opening_qty = 0;
                    $rArr[$prodId]->purchase_qty = 0;
                    $rArr[$prodId]->sale_qty = 0;
                    $rArr[$prodId]->supplier_return_qty = 0;
                    $rArr[$prodId]->customer_return_qty = 0;
                    $rArr[$prodId]->closing_qty = 0;
                    $rArr[$prodId]->stock_value = 0;
                }
    
                if(isset($prevPurArr[$prodId])){
                    $rArr[$prodId]->opening_qty += $prevPurArr[$prodId]->total_bought + $prevPurArr[$prodId]->total_free_qty;
                }
    
                if(isset($prevSalesArr[$prodId])){
                    $rArr[$prodId]->opening_qty -= $prevSalesArr[$prodId]->total_sold + $prevSalesArr[$prodId]->total_free_qty;
                }
    
                if(isset($prevSupReturnArr[$prodId])){
                    $rArr[$prodId]->opening_qty -= $prevSupReturnArr[$prodId]->total_return + $prevSupReturnArr[$prodId]->total_free_qty;
                }
    
                if(isset($prevCusReturnArr[$prodId])){
                    $rArr[$prodId]->opening_qty += $prevCusReturnArr[$prodId]->total_return + $prevCusReturnArr[$prodId]->total_free_qty;
                }
    
                if(isset($curPurArr[$prodId])){
                    $rArr[$prodId]->purchase_qty += $curPurArr[$prodId]->total_bought + $curPurArr[$prodId]->total_free_qty;
                }
    
                if(isset($curSaleArr[$prodId])){
                    $rArr[$prodId]->sale_qty += $curSaleArr[$prodId]->total_sold + $curSaleArr[$prodId]->total_free_qty;
                }
    
                if(isset($curSupReturnArr[$prodId])){
                    $rArr[$prodId]->supplier_return_qty += $curSupReturnArr[$prodId]->total_return + $curSupReturnArr[$prodId]->total_free_qty;
                }
    
                if(isset($curCusReturnArr[$prodId])){
                    $rArr[$prodId]->customer_return_qty += $curCusReturnArr[$prodId]->total_return + $curCusReturnArr[$prodId]->total_free_qty;
                }
    
                $rArr[$prodId]->closing_qty = $rArr[$prodId]->opening_qty+$rArr[$prodId]->purchase_qty + $rArr[$prodId]->customer_return_qty - $rArr[$prodId]->sale_qty - $rArr[$prodId]->supplier_return_qty;
    
                $rArr[$prodId]->stock_value = $rArr[$prodId]->closing_qty * $product->unit_price;
            }
    
            return $rArr;
    
        }

        function getAllPaginatedMedicines($genericNameId, $productId, $limit, $offset){

            $this->db->select('
            drug_medicine.*,
            drug_generic.generic_name,
            drug_dosage.dosage_name,
            drug_manufacturer.manufacturer_name,
            shelf.shelf_name,
            shelf.shelf_no')
                    ->from('drug_medicine')
                    ->join('drug_generic', 'drug_generic.record_id = drug_medicine.generic_id', 'left')
                    ->join('drug_dosage', 'drug_dosage.record_id = drug_medicine.dosage_id', 'left')
                    ->join('drug_manufacturer', 'drug_manufacturer.record_id = drug_medicine.manufacturer_id', 'left')
                    ->join('shelf', 'shelf.record_id = drug_medicine.shelf_id', 'left');
    
            if($genericNameId > 0){
                $this->db->where('generic_id', $genericNameId);
            }
    
            if($productId > 0){
                $this->db->where('drug_medicine.record_id', $productId);
            }
             $this->db->where('drug_medicine.type', 'medicine');
            $this->db->where('drug_medicine.warehouse', 'Pharmacy');
    
            $this->db->limit($limit, $offset);
    
            $this->db->order_by('drug_generic.generic_name', 'ASC')->group_by('drug_medicine.record_id');
    
            return $this->db->get()->result();
        }
        function getAllPaginatedmedicine($monthYear, $shelfId = 0, $product_id = 0, $limit = 50, $offset = 0, $supplierId = 0){

            $fromDate = date('Y-m-01 00:00:00', strtotime($monthYear));
            $toDate = date('Y-m-t 23:59:59', strtotime($monthYear));
    
            // $prevfromDate = date('Y-m-01', strtotime($monthYear." -1 month"));
            $prevfromDate = '';
            $prevtoDate = date('Y-m-t 23:59:59', strtotime($monthYear." -1 month"));
    
            //$products = $this->getProductList($limit, $offset, $product_id, $shelfId);
            $products = $this->getMDrugList($limit, $offset, $product_id, $shelfId, $supplierId);
    
            // ddd($products);
    
            $prodArr = reOrderArr($products, 'record_id');
            
    
            //$previousPurchases = $this->getDateRangedPurchasedProducts('', $toDate, $prodArr);
            $previousPurchases = $this->getDateRangedPurchasedProducts_new($prevfromDate, $prevtoDate, $prodArr);
            $prevPurArr = serializeArr($previousPurchases, 'product_id');
    
            //$previousSales = $this->getDateRangedSoldProducts('', $toDate, $prodArr);
            $previousSales = $this->getDateRangedSoldProducts_new($prevfromDate, $prevtoDate, $prodArr);
            $prevSalesArr = serializeArr($previousSales, 'product_id');
    
            //$previousSupplierReturns = $this->getDateRangedSupplierReturnedProducts('', $toDate, $prodArr);
            $previousSupplierReturns = $this->getDateRangedSupplierReturnedProducts_new($prevfromDate, $prevtoDate, $prodArr);
            $prevSupReturnArr = serializeArr($previousSupplierReturns, 'product_id');
    
            //$previousCustomerReturns = $this->getDateRangedCustomerReturnedProducts('', $toDate, $prodArr);
            $previousCustomerReturns = $this->getDateRangedCustomerReturnedProducts_new($prevfromDate, $prevtoDate, $prodArr);
            $prevCusReturnArr = serializeArr($previousCustomerReturns, 'product_id');
    
            $currentPurchases = $this->getDateRangedPurchasedProducts_new($fromDate, $toDate, $prodArr);
            $curPurArr = serializeArr($currentPurchases, 'product_id');
    
            $currentSales = $this->getDateRangedSoldProducts_new($fromDate, $toDate, $prodArr);
            $curSaleArr = serializeArr($currentSales, 'product_id');
    
            $currentSupplierReturns = $this->getDateRangedSupplierReturnedProducts_new($fromDate, $toDate, $prodArr);
            $curSupReturnArr = serializeArr($currentSupplierReturns, 'product_id');
    
            $currentCustomerReturns = $this->getDateRangedCustomerReturnedProducts_new($fromDate, $toDate, $prodArr);
            $curCusReturnArr = serializeArr($currentCustomerReturns, 'product_id');
    
            $rArr = [];
    
            $rArr = $this->calculateAllProductData($products, $prevPurArr, $prevSalesArr, $prevSupReturnArr, $prevCusReturnArr, $curPurArr, $curSaleArr, $curSupReturnArr, $curCusReturnArr);
            // ddd($this->db->last_query());
            // ddd($rArr);
    
            return  $rArr;
        }

        function getMDrugList($limit, $offset, $productId, $shelfId, $supplierId){
        
            $this->db->select('product_name_new.product_id, product_name_new.product_id as record_id, product_name_new.shelf_id, shelf.shelf_name, shelf.shelf_no, purchase_order_details.order_qty, purchase_order_details.purchase_date, product_name_new.purchase_price, product_name_new.unit_price, product_name_new.sales_price, product_name_new.type,  drug_manufacturer.manufacturer_name')
            ->from('product_name_new')
            ->join('purchase_order_details', 'purchase_order_details.product_id = product_name_new.product_id', 'left')
            ->join('shelf', 'shelf.record_id = product_name_new.shelf_id', 'left');
            $this->db->join(' drug_medicine', 'product_name_new.product_id =  drug_medicine.record_id', 'left');
            $this->db->join(' drug_manufacturer', ' drug_manufacturer.record_id =  drug_medicine.manufacturer_id', 'left');
    
            if($productId > 0){
                $this->db->where('product_name_new.product_id', $productId);
            }
            if($shelfId > 0){
                $this->db->where('product_name_new.shelf_id', $shelfId);
            }
            if($supplierId > 0){
                $this->db->where(' drug_medicine.manufacturer_id', $supplierId);
            }
            $this->db->where('purchase_order_details.purchase_type', 'Medicine');
    
            if($limit > 0){
                $this->db->limit($limit, $offset);
            }
    
            $this->db->order_by('purchase_order_details.purchase_date', 'DESC')
            ->group_by('product_name_new.product_id');
            return $this->db->get()->result();
    
        }

        function getDateRangedPurchasedProducts_new($fromDate, $toDate, $productArr = []){

            $this->db->select('purchase_order_details.product_id, SUM(purchase_order_details.order_qty) as total_bought, SUM(purchase_order_details.free_qty) as total_free_qty')
                     ->from('product_name_new')
                     ->join('purchase_order_details', 'purchase_order_details.product_id = product_name_new.product_id');
    
    
            if(!empty($fromDate) && !empty($toDate)){
                $this->db->where("purchase_order_details.purchase_date between '$fromDate' AND '$toDate'");
            }else if(!empty($fromDate)){
                $this->db->where('purchase_order_details.purchase_date>=', $fromDate);
            }else if(!empty($toDate)){
                $this->db->where('purchase_order_details.purchase_date<=', $toDate);
            }
            if(sizeof($productArr) > 0){
                $this->db->where_in('product_name_new.product_id', $productArr);
            }
            $this->db->where('purchase_order_details.purchase_type', 'Medicine');
    
    
            $this->db->order_by('purchase_order_details.purchase_date', 'desc')->group_by('purchase_order_details.product_id');
    
            return $this->db->get()->result();
        }
    
        function getDateRangedSoldProducts_new($fromDate, $toDate, $productArr = []){
    
            $this->db->select('sales_order_details.product_id, SUM(sales_order_details.order_qty) as total_sold, SUM(sales_order_details.free_qty) as total_free_qty')
                     ->from('product_name_new')
                     ->join('sales_order_details', 'sales_order_details.product_id = product_name_new.product_id');
    
            if(!empty($fromDate) && !empty($toDate)){
                $this->db->where("sales_order_details.sales_date between '$fromDate' AND '$toDate'");
            }else if(!empty($fromDate)){
                $this->db->where('sales_order_details.sales_date>=', $fromDate);
            }else if(!empty($toDate)){
                $this->db->where('sales_order_details.sales_date<=', $toDate);
            }
            if(sizeof($productArr) > 0){
                $this->db->where_in('product_name_new.product_id', $productArr);
            }
            $this->db->where('sales_order_details.sales_type', 'Medicine');
    
            $this->db->order_by('sales_order_details.sales_date', 'desc')->group_by('sales_order_details.product_id');
    
            return $this->db->get()->result();
        }
    
        function getDateRangedSupplierReturnedProducts_new($fromDate, $toDate, $productArr = []){
    
            $this->db->select('return_details.product_id, SUM(return_details.return_qty) as total_return, SUM(return_details.free_qty) as total_free_qty')
                     ->from('return_details')
                     ->join('return_manages', 'return_manages.return_id = return_details.return_id');
    
            if(!empty($fromDate) && !empty($toDate)){
                $this->db->where("return_manages.return_date between '$fromDate' AND '$toDate'");
            }else if(!empty($fromDate)){
                $this->db->where('return_manages.return_date>=', $fromDate);
            }else if(!empty($toDate)){
                $this->db->where('return_manages.return_date<=', $toDate);
            }
            if(sizeof($productArr) > 0){
                $this->db->where_in('return_details.product_id', $productArr);
            }
    
            $this->db->where('return_details.return_type', 'Medicine');
    
            $this->db->order_by('return_manages.return_date', 'desc')->group_by('return_details.product_id');
    
            return $this->db->get()->result();
        }
    
        function getDateRangedCustomerReturnedProducts_new($fromDate, $toDate, $productArr = []){
    
            $this->db->select('customer_return_details.product_id, SUM(customer_return_details.return_qty) as total_return, SUM(customer_return_details.free_qty) as total_free_qty')
                     ->from('customer_return_details')
                     ->join('customer_return_manages', 'customer_return_manages.return_id = customer_return_details.return_id');
    
            if(!empty($fromDate) && !empty($toDate)){
                $this->db->where("customer_return_manages.return_date between '$fromDate' AND '$toDate'");
            }else if(!empty($fromDate)){
                $this->db->where('customer_return_manages.return_date>=', $fromDate);
            }else if(!empty($toDate)){
                $this->db->where('customer_return_manages.return_date<=', $toDate);
            }
            if(sizeof($productArr) > 0){
                $this->db->where_in('customer_return_details.product_id', $productArr);
            }
            $this->db->where('customer_return_details.return_type', 'Medicine');
            $this->db->order_by('customer_return_manages.return_date', 'desc')->group_by('customer_return_details.product_id');
    
            return $this->db->get()->result();
        }
    
        function getTotalProductStock_med($monthYear, $shelfId, $product_id = 0, $supplierId  = 0){
            $fromDate = date('Y-m-01', strtotime($monthYear));
            $toDate = date('Y-m-t', strtotime($monthYear));
            $prevfromDate = date('Y-m-01', strtotime($monthYear." -1 month"));
            $prevtoDate = date('Y-m-t', strtotime($monthYear." -1 month"));
    
            $products = $this->getMDrugList(0, 0, $product_id, $shelfId, $supplierId);
            
    
            $prodArr = [];
    
            if($product_id > 0){
                $prodArr = $product_id;
            }
    
             //$previousPurchases = $this->getDateRangedPurchasedProducts('', $toDate, $prodArr);
             $previousPurchases = $this->getDateRangedPurchasedProducts_new($prevfromDate, $prevtoDate, $prodArr);
             $prevPurArr = serializeArr($previousPurchases, 'product_id');
     
             //$previousSales = $this->getDateRangedSoldProducts('', $toDate, $prodArr);
             $previousSales = $this->getDateRangedSoldProducts_new($prevfromDate, $prevtoDate, $prodArr);
             $prevSalesArr = serializeArr($previousSales, 'product_id');
     
             //$previousSupplierReturns = $this->getDateRangedSupplierReturnedProducts('', $toDate, $prodArr);
             $previousSupplierReturns = $this->getDateRangedSupplierReturnedProducts_new($prevfromDate, $prevtoDate, $prodArr);
             $prevSupReturnArr = serializeArr($previousSupplierReturns, 'product_id');
     
             //$previousCustomerReturns = $this->getDateRangedCustomerReturnedProducts('', $toDate, $prodArr);
             $previousCustomerReturns = $this->getDateRangedCustomerReturnedProducts_new($prevfromDate, $prevtoDate, $prodArr);
             $prevCusReturnArr = serializeArr($previousCustomerReturns, 'product_id');
    
            $currentPurchases = $this->getDateRangedPurchasedProducts_new($fromDate, $toDate);
            $curPurArr = serializeArr($currentPurchases, 'product_id');
    
            $currentSales = $this->getDateRangedSoldProducts_new($fromDate, $toDate);
            $curSaleArr = serializeArr($currentSales, 'product_id');
    
            $currentSupplierReturns = $this->getDateRangedSupplierReturnedProducts_new($fromDate, $toDate);
            $curSupReturnArr = serializeArr($currentSupplierReturns, 'product_id');
    
            $currentCustomerReturns = $this->getDateRangedCustomerReturnedProducts_new($fromDate, $toDate);
            $curCusReturnArr = serializeArr($currentCustomerReturns, 'product_id');
    
            $rArr = [];
    
            $stockArr = $this->calculateAllProductData($products, $prevPurArr, $prevSalesArr, $prevSupReturnArr, $prevCusReturnArr, $curPurArr, $curSaleArr, $curSupReturnArr, $curCusReturnArr);
            // ddd($this->db->last_query());
            // ddd($rArr);
    
            $totalData = $this->calculateTotalProductStockData($stockArr);
    
            return  $totalData;
        }

        function getTotalProductStock($monthYear, $shelfId, $product_id = 0, $supplierid = 0){
            $fromDate = date('Y-m-01', strtotime($monthYear));
            $toDate = date('Y-m-t', strtotime($monthYear));
            $prevfromDate = date('Y-m-01', strtotime($monthYear." -1 month"));
            $prevtoDate = date('Y-m-t', strtotime($monthYear." -1 month"));
    
            $products = $this->getProductList(0, 0, $product_id, $shelfId, $supplierid);
            
    
            $prodArr = [];
    
            if($product_id > 0){
                $prodArr = $product_id;
            }
    
             //$previousPurchases = $this->getDateRangedPurchasedProducts('', $toDate, $prodArr);
             $previousPurchases = $this->getDateRangedPurchasedProducts($prevfromDate, $prevtoDate, $prodArr);
             $prevPurArr = serializeArr($previousPurchases, 'product_id');
     
             //$previousSales = $this->getDateRangedSoldProducts('', $toDate, $prodArr);
             $previousSales = $this->getDateRangedSoldProducts($prevfromDate, $prevtoDate, $prodArr);
             $prevSalesArr = serializeArr($previousSales, 'product_id');
     
             //$previousSupplierReturns = $this->getDateRangedSupplierReturnedProducts('', $toDate, $prodArr);
             $previousSupplierReturns = $this->getDateRangedSupplierReturnedProducts($prevfromDate, $prevtoDate, $prodArr);
             $prevSupReturnArr = serializeArr($previousSupplierReturns, 'product_id');
     
             //$previousCustomerReturns = $this->getDateRangedCustomerReturnedProducts('', $toDate, $prodArr);
             $previousCustomerReturns = $this->getDateRangedCustomerReturnedProducts($prevfromDate, $prevtoDate, $prodArr);
             $prevCusReturnArr = serializeArr($previousCustomerReturns, 'product_id');
    
            $currentPurchases = $this->getDateRangedPurchasedProducts($fromDate, $toDate);
            $curPurArr = serializeArr($currentPurchases, 'product_id');
    
            $currentSales = $this->getDateRangedSoldProducts($fromDate, $toDate);
            $curSaleArr = serializeArr($currentSales, 'product_id');
    
            $currentSupplierReturns = $this->getDateRangedSupplierReturnedProducts($fromDate, $toDate);
            $curSupReturnArr = serializeArr($currentSupplierReturns, 'product_id');
    
            $currentCustomerReturns = $this->getDateRangedCustomerReturnedProducts($fromDate, $toDate);
            $curCusReturnArr = serializeArr($currentCustomerReturns, 'product_id');
    
            $rArr = [];
    
            $stockArr = $this->calculateAllProductData($products, $prevPurArr, $prevSalesArr, $prevSupReturnArr, $prevCusReturnArr, $curPurArr, $curSaleArr, $curSupReturnArr, $curCusReturnArr);
            // ddd($this->db->last_query());
            // ddd($rArr);
    
            $totalData = $this->calculateTotalProductStockData($stockArr);
    
            return  $totalData;
        }

        function calculateTotalProductStockData($stockArr){

            $totalObj = new stdClass();
            $totalObj->openingQty = 0;
            $totalObj->purchaseQty = 0;
            $totalObj->salesQty = 0;
            $totalObj->supplierReturnQty = 0;
            $totalObj->customerReturnQty = 0;
            $totalObj->closingStock = 0;
            $totalObj->stockValue = 0;
    
            foreach($stockArr as $stock){
    
                $totalObj->openingQty+= $stock->opening_qty;
                $totalObj->purchaseQty+= $stock->purchase_qty;
                $totalObj->salesQty+= $stock->sale_qty;
                $totalObj->supplierReturnQty+= $stock->supplier_return_qty;
                $totalObj->customerReturnQty+= $stock->customer_return_qty;
                $totalObj->closingStock+= $stock->closing_qty;
                $totalObj->stockValue+= $stock->stock_value;
    
            }
    
            return $totalObj;
        } 

        public function search_product($term) {
            $this->db->select('
            drug_medicine.*,
            drug_generic.generic_name,
            drug_dosage.dosage_name,
            drug_manufacturer.manufacturer_name,
            shelf.shelf_name,
            shelf.shelf_no')
                    ->join('drug_generic', 'drug_generic.record_id = drug_medicine.generic_id', 'left')
                    ->join('drug_dosage', 'drug_dosage.record_id = drug_medicine.dosage_id', 'left')
                    ->join('drug_manufacturer', 'drug_manufacturer.record_id = drug_medicine.manufacturer_id', 'left')
                    ->join('shelf', 'shelf.record_id = drug_medicine.shelf_id', 'left');
            $this->db->like('brand_name', $term);
            $this->db->or_like('drug_medicine.record_id', $term);
            $this->db->order_by(
                "CASE 
                    WHEN drug_medicine.brand_name = " . $this->db->escape($term) . " THEN 0
                    WHEN drug_medicine.brand_name LIKE " . $this->db->escape($term . '%') . " THEN 1
                    ELSE 2
                END",
                '',
                false
            );
            $this->db->order_by('drug_medicine.brand_name', 'ASC');
            $this->db->limit(100);
            $this->db->where('drug_medicine.warehouse', 'Pharmacy');
           
            $query = $this->db->get('drug_medicine');
    
            $results = [];
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $row) {
                    $results[] = $row->brand_name;
                }
            }
    
            $results = [];
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $row) {
                    // Return both ID and name
                    $results[] = [
                        'label' => $row->brand_name .  " " . $row->strength   ." ".$row->dosage_name." ".$row->record_id,
                        'value' =>  $row->brand_name .  " " . $row->strength   ." ".$row->dosage_name." ".$row->record_id,
                        'id' => $row->record_id,
                        'unit_price' => $row->unit_price,
                        'unit_mrp' => $row->unit_mrp,
                        'product_stock' => $row->product_stock,
                    ];
                }
            }
    
            return $results;
        }

       

     public function getSalesDiscount($from_date, $to_date, $productId) {
    
            $this->db->select('s.sales_id, s.order_discount_amount');
            $this->db->from('sales_orders s');
            $this->db->join('sales_order_details sd', 'sd.sales_order_id = s.sales_id', 'left');
            
            $this->db->where('s.sales_date >=', $from_date);
            $this->db->where('s.sales_date <=', $to_date);

            if ($productId > 0) {
                $this->db->where('sd.product_id', $productId);
            }

            $this->db->group_by('s.sales_id'); // Prevent duplicate discount sums
            $result = $this->db->get()->result();

            $total = 0;
            foreach ($result as $row) {
                $total += $row->order_discount_amount;
            }

            return $total;
        }


        function selseMDrugList($from_date, $to_date, $productId, $type='')
        {
        $this->db->select('sales_order_details.product_id, drug_medicine.unit_price, drug_medicine.type')
        ->from('sales_order_details');
        $this->db->join('drug_medicine', 'sales_order_details.product_id =  drug_medicine.record_id', 'left');
        $this->db->where("sales_order_details.sales_date between '$from_date' AND '$to_date'");
        if($productId > 0){
            $this->db->where('sales_order_details.product_id', $productId);
        }
        $this->db->where('sales_order_details.sales_type', 'Medicine')
        ->order_by('drug_medicine.brand_name', 'asc')
        ->group_by('sales_order_details.product_id');
        if( $type){
            $this->db->where('drug_medicine.type', $type);
        }
        return $this->db->get()->result();
        }

        function getProductById($id){

            $this->db->select('
            drug_medicine.*,
            drug_generic.generic_name,
            drug_dosage.dosage_name,
            drug_manufacturer.manufacturer_name,
            shelf.shelf_name,
            shelf.shelf_no')
                    ->from('drug_medicine')
                    ->join('drug_generic', 'drug_generic.record_id = drug_medicine.generic_id', 'left')
                    ->join('drug_dosage', 'drug_dosage.record_id = drug_medicine.dosage_id', 'left')
                    ->join('drug_manufacturer', 'drug_manufacturer.record_id = drug_medicine.manufacturer_id', 'left')
                    ->join('shelf', 'shelf.record_id = drug_medicine.shelf_id', 'left');
    
            
            $this->db->where('drug_medicine.record_id', $id);
    
            return $this->db->get()->row();
        }

        function getAllProduct($manufacturer, $type, $warehouse, $product_id){

            $this->db->select('
            drug_medicine.*,
            drug_generic.generic_name,
            drug_dosage.dosage_name,
            drug_manufacturer.manufacturer_name,
            shelf.shelf_name,
            shelf.shelf_no')
                    ->from('drug_medicine')
                    ->join('drug_generic', 'drug_generic.record_id = drug_medicine.generic_id', 'left')
                    ->join('drug_dosage', 'drug_dosage.record_id = drug_medicine.dosage_id', 'left')
                    ->join('drug_manufacturer', 'drug_manufacturer.record_id = drug_medicine.manufacturer_id', 'left')
                    ->join('shelf', 'shelf.record_id = drug_medicine.shelf_id', 'left');
    
            if($manufacturer > 0){
                $this->db->where('drug_medicine.manufacturer_id', $manufacturer);
            }
    
            if($type){
                $this->db->where('drug_medicine.type', $type);
            }
    
            if($warehouse){
                $this->db->where('drug_medicine.warehouse', $warehouse);
            }
    
            if($product_id > 0){
                $this->db->where('drug_medicine.record_id', $product_id);
            }
    
            $this->db->order_by('drug_medicine.brand_name', 'ASC');
            return $this->db->get()->result();
        }

        function getAllPaginatedstock($monthYear, $shelfId = 0, $product_id = 0, $limit = 50, $offset = 0, $supplierId = 0){

            $fromDate = date('Y-m-01', strtotime($monthYear));
            $toDate = date('Y-m-t', strtotime($monthYear));
    
            $prevfromDate = '';
            $prevtoDate = date('Y-m-t 23:59:59', strtotime($monthYear." -1 month"));
    
            
            $products = $this->getstockProduct($limit, $offset, $product_id, $shelfId, $supplierId, $fromDate, $toDate);
    
            // $rArr = [];
            // $rArr = $products;
            // $rArr ['opening']= 0;
            // $rArr ['closing']= 0;
           
            return  $products;
        }
    
        function getstockProduct($limit, $offset, $productId, $shelfId, $supplierId, $fromDate, $toDate){
            
            $this->db->select('drug_medicine.brand_name, drug_medicine.strength, drug_medicine.unit_price, drug_medicine.unit_mrp, drug_medicine.product_stock,   
            drug_generic.generic_name,
            drug_dosage.dosage_name,
            drug_manufacturer.manufacturer_name,
            shelf.shelf_name,
            shelf.shelf_no,
            product_stock_history.product_id,
            SUM(purchase_qty) as total_purchase, SUM(purchase_return_qty) as total_purchase_return, SUM(sales_qty) as total_sales, SUM(sales_return_qty) as total_sales_return')
                    ->from('product_stock_history')
                    ->join('drug_medicine', 'drug_medicine.record_id = product_stock_history.product_id', 'left')
                    ->join('drug_generic', 'drug_generic.record_id = drug_medicine.generic_id', 'left')
                    ->join('drug_dosage', 'drug_dosage.record_id = drug_medicine.dosage_id', 'left')
                    ->join('drug_manufacturer', 'drug_manufacturer.record_id = drug_medicine.manufacturer_id', 'left')
                    ->join('shelf', 'shelf.record_id = drug_medicine.shelf_id', 'left');
    
            if($productId > 0){
                $this->db->where('product_stock_history.product_id', $productId);
            }
            if($shelfId > 0){
                $this->db->where('drug_medicine.shelf_id', $shelfId);
            }
            if($supplierId > 0){
                $this->db->where(' drug_medicine.manufacturer_id', $supplierId);
            }
            $this->db->where('drug_medicine.warehouse', 'Pharmacy');
            $this->db->where('drug_medicine.product_stock >', 0);
    
            if($limit > 0){
                $this->db->limit($limit, $offset);
            }
    
            if(!empty($fromDate) && !empty($toDate)){
                $this->db->where("product_stock_history.stock_date between '$fromDate' AND '$toDate'");
            }else if(!empty($fromDate)){
                $this->db->where('product_stock_history.stock_date>=', $fromDate);
            }else if(!empty($toDate)){
                $this->db->where('product_stock_history.stock_date<=', $toDate);
            }
    
            $this->db->order_by('product_stock_history.stock_date', 'DESC')
            ->group_by('product_stock_history.product_id');
            return $this->db->get()->result();
    
        }
    
        function getTotalStock($fromDate, $toDate, $shelfId, $productId,  $supplierId){
            
            $this->db->select('SUM(purchase_qty) as total_purchase, 
            SUM(purchase_return_qty) as total_purchase_return, 
            SUM(sales_qty) as total_sales, 
            SUM(sales_return_qty) as total_sales_return,
            product_stock_history.product_id,
            drug_medicine.unit_price, drug_medicine.unit_mrp,
            ')
                    ->from('product_stock_history')
                    ->join('drug_medicine', 'drug_medicine.record_id = product_stock_history.product_id', 'left');
                    
    
            if($productId > 0){
                $this->db->where('product_stock_history.product_id', $productId);
            }
            if($shelfId > 0){
                $this->db->where('drug_medicine.shelf_id', $shelfId);
            }
            if($supplierId > 0){
                $this->db->where(' drug_medicine.manufacturer_id', $supplierId);
            }
            $this->db->where('drug_medicine.warehouse', 'Pharmacy');
    
            if(!empty($fromDate) && !empty($toDate)){
                $this->db->where("product_stock_history.stock_date between '$fromDate' AND '$toDate'");
            }else if(!empty($fromDate)){
                $this->db->where('product_stock_history.stock_date>=', $fromDate);
            }else if(!empty($toDate)){
                $this->db->where('product_stock_history.stock_date<=', $toDate);
            }
    
            $this->db->order_by('product_stock_history.stock_date', 'DESC');
            $this->db->group_by('product_stock_history.product_id');
            return $this->db->get()->result();
            // $query = $this->db->get();
            // return $query->row();
    
        }
    
        function opening_stock($productId, $fromDate, $toDate){
            
            $this->db->select('SUM(purchase_qty) as total_purchase, 
            SUM(purchase_return_qty) as total_purchase_return, 
            SUM(sales_qty) as total_sales, 
            SUM(sales_return_qty) as total_sales_return,
            product_stock_history.product_id,
            drug_medicine.unit_price, drug_medicine.unit_mrp,
            ')
                    ->from('product_stock_history')
                    ->join('drug_medicine', 'drug_medicine.record_id = product_stock_history.product_id', 'left');
                    
            $this->db->where('product_stock_history.product_id', $productId);
            
            $this->db->where('drug_medicine.warehouse', 'Pharmacy');
            $this->db->where('product_stock_history.stock_date<', $fromDate);
            //$this->db->where('product_stock_history.stock_date>=', $fromDate);
            //$this->db->where('product_stock_history.stock_date<=', $toDate);
            
            $this->db->order_by('product_stock_history.stock_date', 'DESC')->limit(1);
            //return $this->db->get()->result();
             $query = $this->db->get();
             return $query->row();
    
        }
        
        function product_group_by($where)
        {
            $this->db->where($where);
            $this->db->group_by('product_id');
            $this->db->join(' drug_medicine', 'product_stock_history.product_id = drug_medicine.record_id', 'left');
             $this->db->where('drug_medicine.product_stock >', 0);
            $query = $this->db->get('product_stock_history');
            return $query->result();
        }

    /////////////////////pharmacy///////////////////////


    public function productStockBalanceSheet($start_date, $product_id = '', $supplier_id = '', $shelfId = '', $type='')
{
    $end_date     = date('Y-m-t', strtotime($start_date));
    $opening_upto = date('Y-m-d', strtotime($start_date . ' -1 day'));

    $this->db->select("
        dm.record_id,
        dm.brand_name,
        dm.strength,
        dm.unit_price,
        dm.unit_mrp,
        dm.product_stock,
        dg.generic_name,
        dd.dosage_name,
        ds.manufacturer_name,
        shelf.shelf_name,
        shelf.shelf_no,
        -- Opening Quantity
        IFNULL((
            SELECT SUM(
                CASE 
                    WHEN ps2.type IN ('purchase', 'sales_return') THEN ps2.quantity
                    WHEN ps2.type IN ('sales', 'purchase_return') THEN -ps2.quantity
                    ELSE 0
                END
            )
            FROM product_stocks ps2
            WHERE ps2.product_id = dm.record_id
              AND ps2.date <= '{$opening_upto}'
        ), 0) AS opening_qty,

        -- Opening Stock Value
        IFNULL((
            SELECT SUM(
                CASE 
                    WHEN ps2.type IN ('purchase', 'sales_return') THEN ps2.quantity * IFNULL(ps2.price, 0)
                    WHEN ps2.type IN ('sales', 'purchase_return') THEN -ps2.quantity * IFNULL(ps2.price, 0)
                    ELSE 0
                END
            )
            FROM product_stocks ps2
            WHERE ps2.product_id = dm.record_id
              AND ps2.date <= '{$opening_upto}'
        ), 0) AS opening_value,

        -- Net current period value (purchase + return - sales - return)
        IFNULL((
            SELECT SUM(
                CASE 
                    WHEN ps3.type IN ('purchase', 'sales_return') THEN ps3.quantity * IFNULL(ps3.price, 0)
                    WHEN ps3.type IN ('sales', 'purchase_return') THEN -ps3.quantity * IFNULL(ps3.price, 0)
                    ELSE 0
                END
            )
            FROM product_stocks ps3
            WHERE ps3.product_id = dm.record_id
              AND ps3.date BETWEEN '{$start_date}' AND '{$end_date}'
        ), 0) AS current_value,

        -- Purchase Qty
        (SELECT SUM(quantity)
         FROM product_stocks
         WHERE product_id = dm.record_id
           AND type = 'purchase'
           AND date BETWEEN '{$start_date}' AND '{$end_date}'
        ) AS purchase_qty,

        -- Sales Qty
        (SELECT SUM(quantity)
         FROM product_stocks
         WHERE product_id = dm.record_id
           AND type = 'sales'
           AND date BETWEEN '{$start_date}' AND '{$end_date}'
        ) AS sales_qty,

        -- Purchase Return Qty
        (SELECT SUM(quantity)
         FROM product_stocks
         WHERE product_id = dm.record_id
           AND type = 'purchase_return'
           AND date BETWEEN '{$start_date}' AND '{$end_date}'
        ) AS purchase_return_qty,

        -- Sales Return Qty
        (SELECT SUM(quantity)
         FROM product_stocks
         WHERE product_id = dm.record_id
           AND type = 'sales_return'
           AND date BETWEEN '{$start_date}' AND '{$end_date}'
        ) AS sales_return_qty,

            -- Closing Stock Value
    (
        IFNULL((
            SELECT SUM(
                CASE 
                    WHEN ps2.type IN ('purchase', 'sales_return') THEN ps2.quantity * IFNULL(ps2.price, 0)
                    WHEN ps2.type IN ('sales', 'purchase_return') THEN -ps2.quantity * IFNULL(ps2.price, 0)
                    ELSE 0
                END
            )
            FROM product_stocks ps2
            WHERE ps2.product_id = dm.record_id
              AND ps2.date <= '{$opening_upto}'
        ), 0) 
        +
        IFNULL((
            SELECT SUM(
                CASE 
                    WHEN ps3.type IN ('purchase', 'sales_return') THEN ps3.quantity * IFNULL(ps3.price, 0)
                    WHEN ps3.type IN ('sales', 'purchase_return') THEN -ps3.quantity * IFNULL(ps3.price, 0)
                    ELSE 0
                END
            )
            FROM product_stocks ps3
            WHERE ps3.product_id = dm.record_id
              AND ps3.date BETWEEN '{$start_date}' AND '{$end_date}'
        ), 0)
    ) AS closing_value,

    -- Closing Stock Qty
    (
        IFNULL((
            SELECT SUM(
                CASE
                    WHEN ps2.type IN ('purchase', 'sales_return') THEN ps2.quantity
                    WHEN ps2.type IN ('sales', 'purchase_return') THEN -ps2.quantity
                END
            )
            FROM product_stocks ps2
            WHERE ps2.product_id = dm.record_id
                AND ps2.date <= '{$opening_upto}'
        ),0)
        +
        IFNULL((
            SELECT SUM(
                CASE
                    WHEN ps3.type IN ('purchase', 'sales_return') THEN ps3.quantity
                    WHEN ps3.type IN ('sales', 'purchase_return') THEN -ps3.quantity
                END
            )
            FROM product_stocks ps3
            WHERE ps3.product_id = dm.record_id
                AND ps3.date BETWEEN '{$start_date}' AND '{$end_date}'
        ), 0)
        
    ) AS closing_qty

    ", false);

    $this->db->from('drug_medicine dm');
    $this->db->join('drug_generic dg', 'dg.record_id = dm.generic_id', 'left');
    $this->db->join('drug_dosage dd', 'dd.record_id = dm.dosage_id', 'left');
    $this->db->join('drug_manufacturer ds', 'ds.record_id = dm.manufacturer_id', 'left');
    $this->db->join('shelf', 'shelf.record_id = dm.shelf_id', 'left');
    $this->db->order_by('closing_qty', 'DESC', false);

    $this->db->where('dm.type', $type);

    if (!empty($product_id)) {
        $this->db->where('dm.record_id', $product_id);
    }
    if (!empty($supplier_id)) {
        $this->db->where('dm.manufacturer_id', $supplier_id);
    }
    if (!empty($shelfId)) {
        $this->db->where('dm.shelf_id', $shelfId);
    }

    $this->db->group_by('dm.record_id');
    $this->db->order_by('strength');

    return $this->db->get()->result();
}



}
