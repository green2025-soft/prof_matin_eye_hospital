<?php

defined('BASEPATH') or exit('No direct script access allowed');

class PurchaseDetails_model extends MY_Model
{
    protected $table      = 'purchase_order_details';   
    protected $primaryKey = 'purchase_order_details_id';

    protected $createOrUpdateBy = true;
    

    public function __construct()
    {
        parent::__construct();
    }


    protected $relations = [
        'product' => [
            'model'      => 'DrugMedicine_model',
            'table'      => 'drug_medicine',
            'foreignKey' => 'product_id',
            'localKey'   => 'record_id',
            'type'       => 'belongsTo',
        ]
    ];



}
