<?php

defined('BASEPATH') or exit('No direct script access allowed');

class GlassPrescription_model extends MY_Model
{
    protected $table      = 'glass_prescription';   
    protected $createOrUpdateBy = true;

    public function __construct()
    {
        parent::__construct();
    }

        protected $relations = [
        'details' => [
            'model'      => 'GlassPrescriptionDetails_model',
            'table'      => 'glass_prescription_details',
            'foreignKey' => 'gp_id',
            'localKey'   => 'id',
            'type'       => 'hasMany',
        ],
        'patient' => [
            'model'      => 'Patient_model',
            'table'      => 'patient',
            'foreignKey' => 'patient_id',
            'localKey'   => 'record_id',
            'type'       => 'belongsTo',
        ],
        'doctor' => [
            'model'      => 'Doctor_model',
            'table'      => 'doctor',
            'foreignKey' => 'doctor_id',
            'localKey'   => 'record_id',
            'type'       => 'belongsTo',
        ],
    ];

     public function saveTestInvoice(){}
}
