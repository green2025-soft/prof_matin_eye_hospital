<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Appointment_model extends MY_Model
{
    protected $table      = 'appointments';   
    protected $primaryKey = 'record_id';

    protected $createOrUpdateBy = true;

    public function __construct()
    {
        parent::__construct();
    }
}
