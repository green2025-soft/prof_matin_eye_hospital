<?php

defined('BASEPATH') or exit('No direct script access allowed');

class OperationBill_model extends MY_Model
{
    protected $table      = 'operation_details';   
    protected $primaryKey = 'record_id';

      protected $createOrUpdateBy = true;

    public function __construct()
    {
        parent::__construct();
    }
}
