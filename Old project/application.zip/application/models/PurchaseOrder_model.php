<?php

defined('BASEPATH') or exit('No direct script access allowed');

class PurchaseOrder_model extends MY_Model
{
    protected $table      = 'purchase_orders';   
    protected $primaryKey = 'purchase_id ';

    protected $createOrUpdateBy = true;
    private $type;

    public function __construct()
    {
        parent::__construct();
        $this->type = $this->input->get('type') === 'optic' ? 'optic' : 'medicine';
        $this->load->model(['Auditor_model'=>'auditM']);
    }


    protected $relations = [
        'details' => [
            'model'      => 'PurchaseDetails_model',
            'table'      => 'purchase_order_details',
            'foreignKey' => 'purchase_order_id',
            'localKey'   => 'purchase_id',
            'type'       => 'hasMany',
        ],
        'supplier' => [
            'model'      => 'DrugManufacture_model',
            'table'      => 'drug_manufacturer',
            'foreignKey' => 'supplier_id',
            'localKey'   => 'record_id',
            'type'       => 'belongsTo',
        ]
    ];

    public function all()
    {
        $this->db->where('type', $this->type);
        return parent::all();
    }

    protected function saving($data, $id = null)
    {
        $data['type'] = $this->type;
           $action  = $id?'Update':'Insert';
        $this->createAudit($action, $data['purchase_no'], $id, $data['paid_amount']);
        return $data;
    }


    protected function deleteing($id){
       $this->createAudit('Delete','',$id);
    }

      private function createAudit($action, $invoiceNo, $id='', $presentAmount=0, $comments=''){
        if($id){
            $data = $this->find($id);
            $previousAmount = $data->paid_amount??0;
            $invoiceNo  = $data->purchase_no??0;
        }
        $this->auditM->create_audit($this->table, $id,$action, $invoiceNo, $previousAmount, $presentAmount, $comments);
    }
}
