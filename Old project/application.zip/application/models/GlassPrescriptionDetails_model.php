<?php

defined('BASEPATH') or exit('No direct script access allowed');

class GlassPrescriptionDetails_model extends MY_Model
{
    protected $table      = 'glass_prescription_details';   

    public function __construct()
    {
        parent::__construct();
    }

      protected $relations = [
        'prescription' => [
            'model'      => 'GlassPrescription_model',
            'table'      => 'glass_prescription',
            'foreignKey' => 'gp_id',
            'localKey'   => 'id',
            'type'       => 'belongsTo',
        ],
    ];
}
