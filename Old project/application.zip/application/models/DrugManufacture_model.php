<?php

defined('BASEPATH') or exit('No direct script access allowed');

class DrugManufacture_model extends MY_Model
{
    protected $table      = 'drug_manufacturer';   
    protected $primaryKey = 'record_id';

    protected $createOrUpdateBy = true;


    public function __construct()
    {
        parent::__construct();
    }

}
