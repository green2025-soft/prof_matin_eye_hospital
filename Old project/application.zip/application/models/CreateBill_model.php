<?php

defined('BASEPATH') or exit('No direct script access allowed');

class CreateBill_model extends MY_Model
{
    protected $table      = 'create_bill';   
    protected $primaryKey = 'record_id';
    protected $createOrUpdateBy = true;

    public function __construct()
    {
        parent::__construct();
           $this->load->model('Auditor_model');
    }


    public function saveTestInvoice(){
        $request        = $this->input->post();
        $update_id      = $request['update_id'] ?? null;
        $data           = $this->filterTableData($request);
        $data['doctor_id'] =  $data['doctor_id'][0]??null;

        $data['type']       = 'Test Invoice';
        $data['particular'] = 'Test Invoice';
        $this->db->trans_start();
        if (empty($update_id)) {
            $result         = $this->select_max('test_record_id')->select_max('record_id')->where('type', 'Test Invoice')->first();
            $testRecordId   = (int) $result->test_record_id > 0? (int) $result->test_record_id + 1:(int) $result->record_id + 1;
            $data['test_record_id'] = $testRecordId;
            $prefix         = 'Inv' . date('Ymd', strtotime($request['date']));
            $maxInvoice     = $this->select_max('invoice_no')->where('type', 'Test Invoice')->first();
           
            $invoiceNo = (int) ($maxInvoice->invoice_no ?? 0) + 1;
            $data['prefix']        = $prefix;
            $data['invoice_no']    = $invoiceNo;
        }
        
        $invoiceId = $this->updateOrInsert($data, $update_id);
        
         
         $action = $update_id?'Update':'Insert';
         $this->createAuditors($invoiceId,  $action,  $update_id, $data['invoice_no']??'', $request['paid'],  $request['comments']);
         $this->db->trans_complete();
        
        return $invoiceId;
    }


    public function createAuditors($actionId, $action, $update_id='', $invoice_no='',  $curAmount=0, $comments='', $preAmount =0){
        if( $update_id){
            $bill = $this->where($this->primaryKey, $update_id)->first(); 
            
            $preAmount = $bill? $bill->paid:0;
             $invoice_no = $bill && !$invoice_no? $bill->invoice_no:$invoice_no;
        }
        
        
         $this->Auditor_model->create_audit($this->table, $actionId, $action, $invoice_no, $preAmount, $curAmount, $comments);
         
    }
}
