<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Auditor_model extends MY_Model
{
    protected $table      = 'auditors';   
    protected $primaryKey = 'record_id';
    protected $timestamp = false;
    

    public function __construct()
    {
        parent::__construct();
    }


    public function create_audit($table_name, $insert_update_id, $action, $invoice_no='', $previous_paid_amount=0, $present_paid_amount=0,  $comments='')
    {
        
        $action_by = $this->session->userdata('ses_record_id');
        $refer =  $this->agent->referrer();
        $refer = str_replace(base_url(), '', $refer);
        $menu_link = $refer;
        $a = "delete";
        if (strpos($refer, $a) !== false) {
            $ex = explode('/', $refer);
            $menu_link = $ex[0];
        }
        $a = "edit";

        if (strpos($refer, $a) !== false) {
            $ex = explode('/', $refer);
            $menu_link = $ex[0];
        }
        $a = "delete";
        if (strpos($refer, $a) !== false) {
            $ex = explode('/', $refer);
            $menu_link = $ex[0];
        }
        $menu = $this->findById('menu_list', array('menu_link' => $menu_link));
        $data = array(
            'table_name' => $table_name,
            'insert_update_id' => $insert_update_id,
            'parent_menu_id' => isset($menu) ? $menu->parent_id : 0,
            'sub_menu_id' => isset($menu) ? $menu->menu_id : 0,
            'url' => $refer,
            'action' => $action,
            'action_by' => $action_by,
            'comments' => $comments,
            'previous_paid_amount' => $previous_paid_amount,
            'present_paid_amount' => $present_paid_amount,
            'invoice_no' => $invoice_no,
        );

         return $this->create($data);
      
        return 1;
    }

    public function findById($table, $where)
    {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($where);
        $query = $this->db->get();
        return $query->row();
    }

}
