<?php

defined('BASEPATH') or exit('No direct script access allowed');

class DueCollection_model extends MY_Model
{
    protected $table      = 'due_collections';   
    protected $primaryKey = 'mr_id';

      protected $createOrUpdateBy = true;

    public function __construct()
    {
        parent::__construct();
    }
}
