<?php

defined('BASEPATH') or exit('No direct script access allowed');

class ProfitDistribution_model extends MY_Model
{
    protected $table      = 'profit_distributions';   

    protected $createOrUpdateBy = true;

    public function __construct()
    {
        parent::__construct();
    }

      protected $relations = [
        'details' => [
            'model'      => 'ProfitDistributionDetails_model',
            'table'      => 'profit_distribution_details',
            'foreignKey' => 'distribution_id',
            'localKey'   => 'id',
            'type'       => 'hasMany',
        ],
    ];
}
