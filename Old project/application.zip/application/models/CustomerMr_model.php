<?php

defined('BASEPATH') or exit('No direct script access allowed');

class CustomerMr_model extends MY_Model
{
    protected $table      = 'mr';   
    protected $primaryKey = 'mr_id';

    protected $createOrUpdateBy = true;

    private $type;

    public function __construct()
    {
        parent::__construct();
        $this->type = $this->input->get('type') === 'optic' ? 'optic' : 'medicine';
        $this->load->model(['Auditor_model'=>'auditM']);
    }

    public function all()
    {
        $this->db->where('type', $this->type);
        return parent::all();
    }

    protected function saving($data, $id = null)
    {
        $data['type'] = $this->type;
        $action  = $id?'Update':'Insert';
        $this->createAudit($action, $data['mr_no'], $id, $data['mr_amount']);
        return $data;
    }

   public function customerDueLists()
    {
        $mrSubQuery = $this->db
            ->select([
                'sales_id',
                $this->aggregateColumn('current_collection'),
                $this->aggregateColumn('discount_amount'),
            ], false)
            ->from('mr_details')
            ->group_by('sales_id')
            ->get_compiled_select();

        $totalDue   = $this->sumExpression('sales_orders.due_amount');
        $collection = $this->sumExpression('mr.current_collection');
        $discount   = $this->sumExpression('mr.discount_amount');

        $remainingDue = "$totalDue - ($collection + $discount)";
        $mainTable = 'sales_orders';

        return $this->db->select([
                'patient.*',
                "$mainTable.customer_id",
                $this->aggregateColumn("$mainTable.grand_net_total",'total_amount'),
                $this->aggregateColumn("$mainTable.paid_amount",'total_paid'),
                $this->aggregateColumn("$mainTable.due_amount",'total_due'),
                $this->aggregateColumn('mr.current_collection'),
                $this->aggregateColumn('mr.discount_amount'),
                "$remainingDue AS remaining_due",
            ], false)

            ->from("$mainTable")
            ->join('patient', "patient.record_id = $mainTable.customer_id", 'left')
            ->join("($mrSubQuery) AS mr", "mr.sales_id = $mainTable.sales_id", 'left', false)
            ->where("$mainTable.type", $this->type)
            ->where("$mainTable.customer_id >", 0)
            ->group_by("$mainTable.customer_id")
            ->having("$remainingDue > 0", null, false)
            ->order_by('patient.record_id', 'DESC')
            ->get()
            ->result();
    }



     protected function deleteing($id){
       $this->createAudit('Delete','',$id);
    }
    
    private function createAudit($action, $invoiceNo='', $id='', $presentAmount=0, $previousAmount=0, $comments=''){
        if($id){
            $data = $this->find($id);
            $previousAmount = $data->mr_amount??0;
            $invoiceNo  = $data->mr_no??0;
        }
        $this->auditM->create_audit($this->table, $id,$action, $invoiceNo, $previousAmount, $presentAmount, $comments);
    }






    }
