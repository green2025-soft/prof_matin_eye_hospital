<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-29 04:49:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 10:49:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'modernhospitalbd_admin'@'localhost' (using password: YES) /home/modernhospitalbd/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2020-09-29 10:49:34 --> Unable to connect to the database
ERROR - 2020-09-29 04:49:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 10:49:56 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 10:49:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 04:54:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 10:54:03 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 10:54:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 04:54:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 10:54:32 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 10:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 05:03:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 11:03:07 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 11:03:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 05:03:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 11:03:07 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 11:03:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 05:03:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 11:03:09 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 11:03:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 05:03:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:03:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:03:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:03:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:03:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:03:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:03:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 11:03:44 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 11:03:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 05:04:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 11:04:13 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 11:04:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 05:04:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 11:04:13 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 11:04:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 05:04:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 11:04:14 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 11:04:14 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 05:23:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 11:23:11 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 11:23:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 05:25:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 11:25:00 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 11:25:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 05:25:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 11:25:02 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 11:25:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 05:28:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 11:28:08 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 11:28:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 05:28:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:28:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:28:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:29:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:30:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 11:30:37 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 11:30:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 05:30:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:31:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:31:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:31:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-09-29 05:31:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:31:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:31:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-09-29 05:34:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:34:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-09-29 05:38:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:38:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:38:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:38:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:38:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:38:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-09-29 05:38:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:38:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:39:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:39:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:39:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:39:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:39:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:39:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:59:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 05:59:26 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2020-09-29 06:06:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:06:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:06:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:06:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:07:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:07:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:07:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:07:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:07:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:07:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:07:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:07:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:12:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:12:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:12:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-09-29 06:12:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:12:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-09-29 06:12:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:12:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-09-29 06:12:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:12:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-09-29 06:12:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:12:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:12:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:14:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:14:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:14:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:14:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:14:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 12:14:41 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 12:14:41 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 06:14:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:15:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:15:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:15:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:15:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:15:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:15:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:15:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 12:15:42 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 12:15:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 06:15:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:17:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:17:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:17:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:17:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:17:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 12:17:11 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 12:17:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 06:25:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:25:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:25:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:25:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 12:25:42 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 12:25:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 06:26:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:26:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:26:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:26:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:26:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 12:26:34 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 12:26:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 06:26:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 12:26:38 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 12:26:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 06:28:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 12:28:50 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 12:28:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 06:28:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:28:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 12:29:00 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 12:29:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 06:29:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:29:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 12:29:08 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 12:29:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 06:29:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:29:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:29:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:29:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:29:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:29:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:29:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:30:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:30:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 12:30:05 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 12:30:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 06:30:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 12:30:08 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 12:30:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 06:30:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:30:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:30:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:30:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 12:30:56 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 12:30:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 06:31:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:31:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:31:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:31:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:31:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:32:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:32:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:32:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 12:32:04 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 12:32:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 06:32:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:32:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:32:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:32:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 12:32:42 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 12:32:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 06:33:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:33:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:33:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:33:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:34:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 12:34:03 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 12:34:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 06:34:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:35:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:35:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:35:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 12:35:15 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 12:35:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 06:35:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 12:35:17 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 12:35:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 06:35:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:35:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 12:35:22 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 12:35:22 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 06:35:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:36:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:36:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:36:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:36:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:37:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 12:37:05 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 12:37:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 06:37:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:37:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:37:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:37:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:37:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 12:37:50 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 12:37:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 06:38:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:38:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 12:38:19 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 12:38:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 06:38:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:38:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:38:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:38:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 12:38:59 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 12:38:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 06:39:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 12:39:02 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 12:39:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 06:39:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:39:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 12:39:34 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 12:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 06:39:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:39:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 06:39:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 12:39:53 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 12:39:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 07:03:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:03:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:03:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:04:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:04:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:04:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:05:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:05:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:05:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:05:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:05:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:06:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:06:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:06:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:06:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:06:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 13:06:42 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 13:06:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 07:06:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:07:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 13:07:08 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 13:07:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 07:08:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:08:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:08:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 13:08:18 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 13:08:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 07:08:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:08:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 13:08:26 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 13:08:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 07:08:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:08:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:08:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 13:08:53 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 13:08:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 07:08:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:08:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:08:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:08:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:08:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:09:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:09:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 13:09:02 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 13:09:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 07:10:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:10:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:10:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:10:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:10:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:10:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:10:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 13:10:40 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 13:10:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 07:10:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:10:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:11:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:11:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:11:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:11:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 13:11:29 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 13:11:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 07:11:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:11:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:11:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:11:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:11:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:11:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:11:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 13:11:38 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 13:11:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 07:11:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:11:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:11:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:12:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 13:12:02 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 13:12:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 07:20:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 13:20:35 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 13:20:35 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 07:21:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:22:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:22:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:22:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:24:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:24:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:24:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:25:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:25:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:25:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:26:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:26:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:27:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:28:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:30:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:32:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:33:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:33:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:34:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:35:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:36:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:36:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:37:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:37:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:37:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:37:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:38:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:39:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:39:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:39:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:39:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:40:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:40:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-09-29 07:40:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:40:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-09-29 07:40:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:40:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-09-29 07:40:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:40:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-09-29 07:40:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:40:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:40:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:40:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:40:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:40:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:40:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:40:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:40:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:40:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:40:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:40:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:40:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:40:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:41:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:41:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:41:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:41:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:41:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:42:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:42:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:42:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:42:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:42:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:43:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:43:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:43:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:43:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:43:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:43:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:44:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:44:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:45:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:45:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:45:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:46:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:46:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:47:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:47:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 13:47:04 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 13:47:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 07:47:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:47:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:47:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:47:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:48:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:48:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:51:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:51:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:51:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:53:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:54:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:54:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:55:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:56:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:56:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:56:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:56:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:56:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:56:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:57:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:57:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:57:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:57:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:59:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:59:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:59:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 07:59:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:01:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:01:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:01:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:01:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:01:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:01:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:01:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:01:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:01:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:01:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:01:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:02:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:02:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:03:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:03:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:03:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:04:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:04:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:04:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:04:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:04:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:04:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:04:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:04:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:05:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:05:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:05:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:05:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:05:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:05:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:06:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:06:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 14:06:20 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 14:06:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 08:06:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:06:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:06:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:06:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:06:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:06:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:07:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:07:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:07:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:07:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:07:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:08:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:09:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:09:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:09:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:09:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:09:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:09:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:09:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:09:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:09:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:09:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:09:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:09:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:09:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:10:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:32:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:32:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:34:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:45:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:45:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:46:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:46:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:46:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:46:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:56:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:56:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:57:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:58:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:59:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:59:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:59:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 08:59:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:00:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:00:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:00:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:00:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:00:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:00:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:00:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:01:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$unit_price /home/modernhospitalbd/public_html/application/views/admin/lab_product_use_out.php 112
ERROR - 2020-09-29 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$total_price /home/modernhospitalbd/public_html/application/views/admin/lab_product_use_out.php 113
ERROR - 2020-09-29 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$unit_price /home/modernhospitalbd/public_html/application/views/admin/lab_product_use_out.php 112
ERROR - 2020-09-29 15:01:01 --> Severity: Notice --> Undefined property: stdClass::$total_price /home/modernhospitalbd/public_html/application/views/admin/lab_product_use_out.php 113
ERROR - 2020-09-29 09:01:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:01:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:01:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:01:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-09-29 09:01:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:01:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-09-29 09:01:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:01:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-09-29 09:01:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:01:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:02:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:02:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:02:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:02:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:02:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:02:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:03:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:07:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:07:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:07:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-09-29 09:07:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:15:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:16:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:16:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:16:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:16:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:16:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:16:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:17:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:17:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:17:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:18:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:18:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:18:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:18:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:19:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 15:19:02 --> Severity: Notice --> Undefined variable: sold_by /home/modernhospitalbd/public_html/application/views/admin/sales_test_invoice.php 48
ERROR - 2020-09-29 09:22:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:22:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 15:22:46 --> Severity: Notice --> Undefined variable: sold_by /home/modernhospitalbd/public_html/application/views/admin/sales_test_invoice.php 48
ERROR - 2020-09-29 09:23:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:23:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 15:23:07 --> Severity: Notice --> Undefined variable: sold_by /home/modernhospitalbd/public_html/application/views/admin/sales_test_invoice.php 48
ERROR - 2020-09-29 09:23:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:23:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 15:23:27 --> Severity: Notice --> Undefined variable: sold_by /home/modernhospitalbd/public_html/application/views/admin/sales_test_invoice.php 48
ERROR - 2020-09-29 09:25:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:25:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:25:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:26:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:26:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:26:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:26:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:26:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:26:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:27:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:27:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 15:27:26 --> Severity: Notice --> Undefined variable: sold_by /home/modernhospitalbd/public_html/application/views/admin/sales_test_invoice.php 48
ERROR - 2020-09-29 09:27:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:29:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:29:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:31:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:32:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:33:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:34:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:34:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:34:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:34:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 15:34:26 --> Severity: Notice --> Undefined property: stdClass::$address /home/modernhospitalbd/public_html/application/views/admin/show_honorarium_report_info.php 40
ERROR - 2020-09-29 15:34:26 --> Severity: Notice --> Undefined property: stdClass::$doctor_fee /home/modernhospitalbd/public_html/application/views/admin/show_honorarium_report_info.php 46
ERROR - 2020-09-29 15:34:26 --> Severity: Notice --> Undefined property: stdClass::$company_commission /home/modernhospitalbd/public_html/application/views/admin/show_honorarium_report_info.php 50
ERROR - 2020-09-29 15:34:26 --> Severity: Notice --> Undefined property: stdClass::$appointment_time /home/modernhospitalbd/public_html/application/views/admin/show_honorarium_report_info.php 52
ERROR - 2020-09-29 09:34:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:34:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:34:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:34:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:34:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:38:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:41:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:42:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:43:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:43:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:43:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:43:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:44:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:56:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:56:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:58:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 15:58:15 --> Severity: Notice --> Undefined variable: all_news /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 15:58:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/modernhospitalbd/public_html/application/views/website/home.php 6
ERROR - 2020-09-29 09:58:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:58:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:58:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:59:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:59:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:59:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-09-29 09:59:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:59:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-09-29 09:59:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 09:59:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-09-29 10:00:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 10:00:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-09-29 10:00:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 16:00:10 --> Severity: Notice --> Undefined variable: count /home/modernhospitalbd/public_html/application/views/admin/get_test_request_invoice.php 25
ERROR - 2020-09-29 16:00:10 --> Severity: Notice --> Undefined variable: count /home/modernhospitalbd/public_html/application/views/admin/get_test_request_invoice.php 25
ERROR - 2020-09-29 10:00:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 16:00:45 --> Severity: Notice --> Undefined variable: count /home/modernhospitalbd/public_html/application/views/admin/get_test_request_invoice.php 25
ERROR - 2020-09-29 16:00:45 --> Severity: Notice --> Undefined variable: count /home/modernhospitalbd/public_html/application/views/admin/get_test_request_invoice.php 25
ERROR - 2020-09-29 10:00:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 10:00:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 16:00:52 --> Severity: Notice --> Undefined variable: count /home/modernhospitalbd/public_html/application/views/admin/get_test_request_invoice.php 25
ERROR - 2020-09-29 16:00:52 --> Severity: Notice --> Undefined variable: count /home/modernhospitalbd/public_html/application/views/admin/get_test_request_invoice.php 25
ERROR - 2020-09-29 10:01:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 16:01:01 --> Severity: Notice --> Undefined variable: count /home/modernhospitalbd/public_html/application/views/admin/get_test_request_invoice.php 25
ERROR - 2020-09-29 16:01:01 --> Severity: Notice --> Undefined variable: count /home/modernhospitalbd/public_html/application/views/admin/get_test_request_invoice.php 25
ERROR - 2020-09-29 12:43:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 16:43:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'modernhospitalbd_admin'@'localhost' (using password: YES) F:\xampp\htdocs\modernhospital\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2020-09-29 16:43:05 --> Unable to connect to the database
