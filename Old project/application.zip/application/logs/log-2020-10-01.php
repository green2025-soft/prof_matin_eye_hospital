<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-01 07:45:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 07:45:19 --> Config Class Initialized
INFO - 2020-10-01 07:45:19 --> Hooks Class Initialized
DEBUG - 2020-10-01 07:45:19 --> UTF-8 Support Enabled
INFO - 2020-10-01 07:45:19 --> Utf8 Class Initialized
INFO - 2020-10-01 07:45:19 --> URI Class Initialized
INFO - 2020-10-01 07:45:19 --> Router Class Initialized
INFO - 2020-10-01 07:45:19 --> Output Class Initialized
INFO - 2020-10-01 07:45:19 --> Security Class Initialized
DEBUG - 2020-10-01 07:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 07:45:19 --> Input Class Initialized
INFO - 2020-10-01 07:45:19 --> Language Class Initialized
INFO - 2020-10-01 07:45:19 --> Loader Class Initialized
INFO - 2020-10-01 07:45:19 --> Helper loaded: url_helper
INFO - 2020-10-01 07:45:19 --> Helper loaded: file_helper
INFO - 2020-10-01 07:45:19 --> Helper loaded: category_helper
INFO - 2020-10-01 07:45:19 --> Database Driver Class Initialized
INFO - 2020-10-01 07:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 07:45:19 --> Helper loaded: form_helper
INFO - 2020-10-01 07:45:19 --> Form Validation Class Initialized
DEBUG - 2020-10-01 07:45:19 --> Zend Class Initialized
INFO - 2020-10-01 07:45:19 --> Controller Class Initialized
INFO - 2020-10-01 07:45:19 --> Model "Common_model" initialized
INFO - 2020-10-01 07:45:19 --> Model "Join_model" initialized
INFO - 2020-10-01 07:45:19 --> Helper loaded: utility_helper
INFO - 2020-10-01 07:45:19 --> File loaded: E:\xampp\htdocs\modernhospital\application\views\admin/header.php
ERROR - 2020-10-01 07:45:19 --> Severity: Notice --> Undefined index: 000 E:\xampp\htdocs\modernhospital\application\helpers\utility_helper.php 54
INFO - 2020-10-01 07:45:19 --> File loaded: E:\xampp\htdocs\modernhospital\application\views\admin/admission/invoice-individual.php
INFO - 2020-10-01 07:45:19 --> File loaded: E:\xampp\htdocs\modernhospital\application\views\admin/footer.php
INFO - 2020-10-01 07:45:19 --> Final output sent to browser
DEBUG - 2020-10-01 07:45:19 --> Total execution time: 0.0903
