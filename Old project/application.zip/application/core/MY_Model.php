<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class MY_Model extends CI_Model {

    protected $table        = '';   // Table name
     protected $prefix      = '';
    protected $primaryKey   = 'id'; // Primary key name
    protected $timestamp    = true; // Primary key name
    protected $updateedAt   = true; // Primary key name
    protected $createOrUpdateBy= false;
    protected $with         = [];
    protected $relations    = [];

    function __construct() {

        parent::__construct();
        if (!$this->timestamp){
            $this->updateedAt = $this->timestamp;
        }
         $modelName = get_class($this);
         if (empty($this->table)) {
             $name = preg_replace('/_model$/i', '', $modelName);
             if (preg_match('/[^aeiou]y$/i', $name)) {
                $name = substr($name, 0, -1) . 'ies';
            } elseif (!preg_match('/s$/i', $name)) {
                $name .= 's';
            }
             $this->table = $this->prefix . strtolower($name);
         }
    }

       // Create a new record
    public function create($data) {
        if ($this->timestamp){
            $data['created_at'] = date('Y-m-d H:i:s');
        }
        if ($this->createOrUpdateBy) {
            $userId = $this->session->userdata('ses_record_id');
            $data['created_by'] = $userId;
        }
        unset($data['update_id']);
        
        $data = $this->creating($data);
        
        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
    }

    public function updateData($id, $data, $primaryKey=null) {
        $primaryKey = $primaryKey ?? $this->primaryKey;
        
        unset($data['update_id']);	
        if ($this->updateedAt){
            $data['updated_at'] = date('Y-m-d H:i:s');
        }
        if ($this->createOrUpdateBy && $this->updateedAt) {
            $userId = $this->session->userdata('ses_record_id');
            $data['updated_by'] = $userId;
        }
        $data = $this->updating($id, $data);
        // Hooks may run queries that reset the builder; bind the ID to the UPDATE itself.
        $this->db->update($this->table, $data, [$primaryKey => $id]);
        return $id;
    }

    public function updateOrInsert($data, $id = null, $primaryKey=null) {
        // If the ID is provided, try to update the record
        $data = $this->saving($data, $id);
        if ($id) {
           return $this->updateData($id, $data, $primaryKey); 
        }else{
        
           return $this->create($data);
        }
    }

    protected function saving($data, $id = null)
    {
        return $id? $this->updating($id, $data) : $this->creating($data);
    }

     protected function creating($data)
    {
        return $data;
    }
    protected function created($id, $data)
    {
        // event after insert
    }
    protected function updating($id, $data)
    {
        return $data;
    }
    protected function updated($id, $data)
    {
        // event after update
    }

    public function all() {
        $items = $this->db->get($this->table)->result(); 
        return $this->loadRelations($items);
    }

    public function find($id, $primaryKey=null) {
        if (!$id) return null;
        $primaryKey = $primaryKey ?? $this->primaryKey;
        $item = $this->db->get_where($this->table, [$primaryKey => $id])->row();
        if (!$item) return null;
        $items = $this->loadRelations([$item]);
        return $items[0] ?? null;
    }

    public function first() {
        $item = $this->db->get($this->table)->row();
        if (!$item) return null;
        $items = $this->loadRelations([$item]);
        return $items[0] ?? null;
    }

    public function getDelete($id, $primaryKey=null){
         $primaryKey = $primaryKey ?? $this->primaryKey;
          $this->deleteing($id);
        return $this->db->delete($this->table, [$primaryKey => $id]);
    }

     protected function deleteing($id)
    {
        return $id;
    }


    public function groupBy($field){
        $this->db->group_by($field);
        return $this; 
    }

    public function filterTableData($data)
    {
        if (!is_array($data) || empty($this->table)) {
            return [];
        }

        $fields = $this->db->list_fields($this->table);

        return array_intersect_key(
            $data,
            array_flip($fields)
        );
    }

    public function filterBatchData($data, $extra = [])
    {
        if (!is_array($data) || empty($this->table))  return [];

        $fields = $this->db->list_fields($this->table);
        $fieldMap = array_flip($fields);

        $rows = [];

        // Determine number of rows
        $rowCount = 0;

        foreach ($data as $value) {
            if (is_array($value)) $rowCount = max($rowCount, count($value));
        }

        for ($i = 0; $i < $rowCount; $i++) {

            $row = [];

            foreach ($data as $field => $values) {
                if (isset($fieldMap[$field]) && is_array($values) ) $row[$field] = $values[$i] ?? null;
            }

            // Add common/static fields
            if (!empty($extra))  $row = array_merge($row, $extra);
        

            if (!empty($row))  $rows[] = $row;
            
        }

        return $rows;
    }

    public function filterBatchRow($data, $key, $extra = [])
    {
        if (!is_array($data) || empty($this->table)) {
            return [];
        }

        $fields = $this->db->list_fields($this->table);
        $fieldMap = array_flip($fields);

        $row = [];

        foreach ($data as $field => $values) {
            if (isset($fieldMap[$field]) && is_array($values)) {
                $row[$field] = $values[$key] ?? null;
            }
        }

        if (!empty($extra)) {
            $row = array_merge($row, $extra);
        }

        return $row;
    }



    public function insertBatch($rows){
        $this->insert_batch($this->table, $rows);
    }


/*
|--------------------------------------------------------------------------
| With
|--------------------------------------------------------------------------
*/

public function with($relations)
{
    $relations = is_array($relations)? $relations: [$relations];
    $this->with = array_merge($this->with,$relations);
    return $this;
}


/*
|--------------------------------------------------------------------------
| Get Relations
|--------------------------------------------------------------------------
*/

public function getRelations()
{
    return $this->relations;
}


/*
|--------------------------------------------------------------------------
| Load Relations
|--------------------------------------------------------------------------
*/

protected function loadRelations($items)
{
    if (empty($items) || empty($this->with)) {
        return $items;
    }

    foreach ($this->with as $relation) {
        $parts = explode('.', $relation);
        $items = $this->loadRelation($items,$parts,$this->relations);
    }

    $this->with = [];

    return $items;
}


/*
|--------------------------------------------------------------------------
| Load Relation
|--------------------------------------------------------------------------
*/

protected function loadRelation($items, $parts, $relations)
{
    if (empty($items) || empty($parts)) {
        return $items;
    }

    $name = array_shift($parts);

    if (!isset($relations[$name])) {
        return $items;
    }

    $config = $relations[$name];

    /*
    |--------------------------------------------------------------------------
    | Load current relation
    |--------------------------------------------------------------------------
    */

    $items = $this->fetchRelation($items,$name,$config);

    /*
    |--------------------------------------------------------------------------
    | Nested relation
    |--------------------------------------------------------------------------
    */

    if (!empty($parts) && !empty($config['model'])) {

        $modelName = $config['model'];

        $this->load->model($modelName);

        $model = $this->$modelName;

        foreach ($items as &$item) {

            if (!isset($item->$name)) {
                continue;
            }

            $related = $item->$name;

            if (empty($related)) {
                continue;
            }

            $relatedItems = is_array($related) ? $related : [$related];

            $relatedItems = $model->loadRelation($relatedItems,$parts,$model->getRelations());
            $item->$name = is_array($related)? $relatedItems: ($relatedItems[0] ?? null);
        }
    }

    return $items;
}


/*
|--------------------------------------------------------------------------
| Fetch Relation
|--------------------------------------------------------------------------
*/

    protected function fetchRelation($items, $name, $config)
    {
        $table      = $config['table'];
        $foreignKey = $config['foreignKey'];
        $localKey   = $config['localKey'] ?? $this->primaryKey;
        $type       = $config['type'] ?? 'hasMany';

        /*
        |--------------------------------------------------------------------------
        | belongsTo
        |--------------------------------------------------------------------------
        */

        if ($type === 'belongsTo') {
            $ids = [];

            foreach ($items as $item) {
                if (isset($item->$foreignKey)) {
                    $ids[] = $item->$foreignKey;
                }
            }

            $ids = array_unique(array_filter($ids));

            if (!$ids) {

                foreach ($items as &$item) {
                    $item->$name = null;
                }

                return $items;
            }

            $related = $this->db->where_in($localKey, $ids)->get($table)->result();

            $map = [];

            foreach ($related as $row) {
                $map[$row->$localKey] = $row;
            }

            foreach ($items as &$item) {
                $item->$name = $map[$item->$foreignKey] ?? null;
            }

            return $items;
        }


        /*
        |--------------------------------------------------------------------------
        | hasMany / hasOne
        |--------------------------------------------------------------------------
        */

        $ids = [];

        foreach ($items as $item) {

            if (isset($item->$localKey)) {
                $ids[] = $item->$localKey;
            }
        }

        $ids = array_unique(array_filter($ids));

        if (!$ids) {

            foreach ($items as &$item) {
                $item->$name = $type === 'hasMany'? []: null;
            }
            return $items;
        }

        $related = $this->db->where_in($foreignKey, $ids)->get($table)->result();

        $map = [];
        foreach ($related as $row) {
            $map[$row->$foreignKey][] = $row;
        }

        foreach ($items as &$item) {
            $list = $map[$item->$localKey] ?? [];
            $item->$name = $type === 'hasMany'? $list: ($list[0] ?? null);
        }

        return $items;
    }

    public function __call($method, $params)
    {
        if (!is_callable([$this->db, $method])) {
            throw new BadMethodCallException(
                "Method [{$method}] does not exist in Model or CI3 Database."
            );
        }
        $result = call_user_func_array(
            [$this->db, $method],
            $params
        );

        if ($result === $this->db) {
            return $this;
        }

        return $result;
    }

    protected function aggregateColumn($column, $alias = null, $function = 'SUM')
    {
        $alias = $alias ?: basename(str_replace('.', '/', $column));

        return "COALESCE($function($column), 0) AS $alias";
    }

    protected function sumExpression($column)
    {
        return "COALESCE(SUM($column), 0)";
    }

    protected function leftJoin($table, $condition, $escape = null)
    {
        $this->db->join($table, $condition, 'left', $escape);
        return $this;
    }
}
