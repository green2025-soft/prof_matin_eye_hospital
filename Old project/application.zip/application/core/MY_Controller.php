<?php
error_reporting(E_ALL);
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller {

// Common data that you can share across different controllers
    protected $data = [];
    // Base URL for redirection or form actions
    protected $bUrl = '';
    // Common model instance that can be loaded dynamically
    protected $model;
    protected $title;

    protected $isLogin      = true; // Primary key name
    protected $isAdminStaff = true;
    protected $isAdmin      = false;

    protected $userId;
    protected $branchId;
    protected $user;
    protected $userType;
    protected $folderName;

    function __construct() {
        parent::__construct();
        $user           = (object)$this->session->userdata;
        $this->user     = $user;
        $this->userId   = $user->ses_record_id;
        $this->userType = $user->ses_user_type;
        $this->branchId = $user->branch_id??'';

        if ($this->isLogin) {
            $this->isLogin();
        }

        if ($this->isAdminStaff) {
            $this->isAdminStaff();
        }
      
    }


   /**
     * Load admin layout with dynamic view.
     *
     * @return void
     *  @param string $view
     */
    protected function render($view) {
        // Load the common header, content, and footer
        if (!isset($this->data['title'])){
            $this->data['title'] = $this->title;
        }
        if (!isset($this->data['bUrl'])){
            $this->data['bUrl'] = $this->bUrl;
        }

        
        $this->data['page_title']   = $this->data['page_title'] ??  $this->data['title'];
        $this->data['info_header']  = $this->data['info_header'] ?? $this->data['title'];

        $this->data['loginUser']    = $this->user;
        $this->data['loginUserId']  = $this->userId;
        $this->data['loginUserType']= $this->userType;

      
        
        $this->load->view('admin/layouts/header', $this->data);
        $this->load->view($view, $this->data);  // Dynamic page
        $this->load->view('admin/layouts/footer', $this->data);
    }

    protected function loadModel($modelName)
    {
        $this->load->model($modelName);
        $parts = explode('/', $modelName);
        $modelClass = end($parts);
        $this->model = $this->$modelClass;
    }


    protected function crudAlertMessage($id=null,$url='', $isDelete=false) {
        $url = !empty($url)?$url:$this->bUrl;
        $message = INSERT_MSG;
        if ($id) {
            $message = UPDATE_MSG;  
        }
        if ($isDelete) {
            $message = DELETE_MSG;
        }
        $this->session->set_flashdata('message', $message);
        redirect($url, 'refresh'); 

    }


     protected function isLogin() {
        
        if (!$this->userId) {
            redirect('/login', 'refresh');
        }
    }


     protected function isAdminStaff() {
        $userRole =  $this->userType;

        if ($this->isAdmin && $userRole != "admin") {
            redirect('/login', 'refresh');
        }
    
        if ($userRole != "admin" && $userRole != "staff") {
            redirect('/login', 'refresh');
        }
    }





    
}
