<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Hospital\\Providers\\HospitalServiceProvider',
    1 => 'Modules\\Pharmacy\\Providers\\PharmacyServiceProvider',
    2 => 'Modules\\Prescription\\Providers\\PrescriptionServiceProvider',
    3 => 'Modules\\TenantCore\\Providers\\TenantCoreServiceProvider',
    4 => 'Modules\\Core\\Providers\\CoreServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Hospital\\Providers\\HospitalServiceProvider',
    1 => 'Modules\\Pharmacy\\Providers\\PharmacyServiceProvider',
    2 => 'Modules\\Prescription\\Providers\\PrescriptionServiceProvider',
    3 => 'Modules\\TenantCore\\Providers\\TenantCoreServiceProvider',
    4 => 'Modules\\Core\\Providers\\CoreServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);