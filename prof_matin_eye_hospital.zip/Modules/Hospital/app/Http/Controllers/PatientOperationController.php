<?php

namespace Modules\Hospital\Http\Controllers;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\View\View;
use Modules\Core\Http\Controllers\BaseController;
use Modules\Core\Http\Requests\ListRequest;
use Modules\Core\Models\Account;
use Modules\Core\Models\Setting;
use Modules\Hospital\Http\Requests\PatientOperationRequest;
use Modules\Hospital\Models\Doctor;
use Modules\Hospital\Models\Operation;
use Modules\Hospital\Models\Patient;
use Modules\Hospital\Models\PatientOperation;
use Modules\Hospital\Models\Reference;
use Modules\Hospital\Services\PatientOperationService;
use Modules\TenantCore\Models\PaymentType;

class PatientOperationController extends BaseController
{
    protected string $model = PatientOperation::class;

    protected string $title = 'Patient operation';

    protected string $service = PatientOperationService::class;

    protected string $views = 'hospital::patient-operations';

    protected string $parameter = 'patient_operation';

    public function index(ListRequest $request, PatientOperationService $operations): View
    {
        $branchId = max(0, (int) $request->attributes->get('branch_id', 0));
        $view = $this->listData($request);

        $data = [
            'invoiceBalances' => $operations->listInvoiceBalances(
                $request->user('web'),
                new PatientOperation,
                $view->getData()['records']->modelKeys(),
                $branchId,
            ),
            'filterDoctor' => $this->selectedOption(
                Doctor::where('branch_id', $branchId),
                $request->validated('filter_doctor_id'),
                ['id', 'doctor_id', 'name']
            ),
            'filterPatient' => $this->selectedOption(
                Patient::query(),
                $request->validated('filter_patient_id'),
                ['id', 'patient_id', 'name', 'mobile_no']
            ),
        ];

        return $view->with($data);
    }

    public function show(Request $request, PatientOperationService $operations): View
    {
        $data = $operations->invoiceData($request->user('web'), $this->record($request));

        return view('hospital::patient-operations.invoice', $data);
    }

    public function store(PatientOperationRequest $request, PatientOperationService $operations): RedirectResponse
    {
        $operation = $operations->save(
            $request->user('web'),
            $this->record($request),
            $request->payload(),
            (int) $request->attributes->get('branch_id')
        );

        return $this->redirectAfterWrite($operation)
            ->with('status', 'Patient operation'.($this->isUpdate($request) ? ' updated.' : ' created.'));
    }

    protected function formData(Account $actor, Model $record): array
    {
        $branchId = max(0, (int) request()->attributes->get('branch_id', 0));
        $today = now(config('app.timezone'))
            ->toDateString();
        $settings = Setting::values('hospital', $record->getConnectionName());
        $referenceEnabled = (bool) $settings['operation_reference_enabled'];

        return [
            'paymentDefault' => $settings['operation_payment_default'],
            'referenceEnabled' => $referenceEnabled,
            'canCreatePatient' => Gate::forUser($actor)->allows('create', Patient::class),
            'selectedReference' => $referenceEnabled ? $this->selectedOption(Reference::query(), getValue('reference_id', $record), ['id', 'reference_id', 'name', 'contact_no']) : null,
            'selectedPatient' => $this->selectedOption(Patient::query(), getValue('patient_id', $record), ['id', 'name', 'patient_id', 'mobile_no']),
            'selectedDoctor' => $this->selectedOption(
                Doctor::where('branch_id', $branchId),
                getValue('doctor_id', $record),
                ['id', 'doctor_id', 'name', 'consultation_fee', 'follow_up_fee']
            ),
            'paymentTypes' => PaymentType::orderBy('ordering')
                ->orderBy('id')
                ->get(['id', 'name']),
            'selectedOperation' => $this->selectedOption(Operation::query(), getValue('operation_id', $record), ['id', 'name', 'single_rate', 'both_rate']),
            'selectedConsultant' => $this->selectedOption(
                Doctor::where('branch_id', $branchId),
                getValue('consultant_id', $record),
                ['id', 'doctor_id', 'name']
            ),
            'patientTypes' => patientTypes(),
            'eyeTypes' => eyeTypes(),
            'entryDate' => $record->entry_date?->toDateString() ?? $today,
            'dueDate' => $record->due_date?->toDateString() ?? $today,
            'operationDate' => $record->operation_date?->toDateString() ?? $today,
        ];
    }
}
