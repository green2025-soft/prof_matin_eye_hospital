<?php

namespace Modules\Core\Models\Concerns;

use Closure;
use LogicException;
use Modules\Core\Models\Account;

trait HasCrudContract
{
    use HandlesModelQueries;

    protected array $selectorFilters = [];

    protected array $filterableIds = [];

    protected array $filterableRelations = [];

    protected array $containsSearch = [];

    protected string $defaultDirection = 'asc';

    public function writeTransaction(Account $actor, Closure $operation): mixed
    {
        return $this->getConnection()->transaction(fn (): mixed => $operation($actor), 3);
    }

    public function selectorFilters(): array
    {
        return $this->selectorFilters;
    }

    public function queryContract(): array
    {
        $exposed = $this->exposed ?? [];
        $columns = $this->listColumns ?? $exposed;

        if ($exposed === [] || $columns === [] || array_diff($columns, $exposed) !== []) {
            throw new LogicException(static::class.' must declare explicit safe CRUD fields.');
        }

        $relations = $this->exposedRelations ?? [];
        $with = $this->listWith ?? [];

        return [
            'constraints' => $this->queryConstraints ?? [],
            'searchable' => $this->searchable ?? ['name'],
            'containsSearch' => $this->containsSearch,
            'filterable' => $this->filterable ?? [],
            'filterableIds' => $this->filterableIds,
            'filterableRelations' => $this->filterableRelations,
            'sortable' => $this->sortable ?? ['name', 'id'],
            'defaultSort' => $this->defaultSort ?? 'name',
            'defaultDirection' => $this->defaultDirection,
            'listColumns' => $columns,
            'listWith' => $with,
            'formWith' => $this->formWith ?? $with,
            'allowedIncludes' => $this->allowedIncludes ?? array_keys($relations),
            'exposed' => $exposed,
            'exposedRelations' => $relations,
            'exposedCounts' => $this->exposedCounts ?? [],
        ];
    }
}
