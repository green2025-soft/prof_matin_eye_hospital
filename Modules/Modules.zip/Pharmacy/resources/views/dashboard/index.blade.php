@extends('core::layouts.app')

@section('title', $pageTitle)

@section('content')
    <div class="app-page-heading d-flex flex-wrap align-items-center justify-content-between gap-3 mb-3">
        <div>
            <h1 class="h4 fw-semibold mb-1">{{ $pageTitle }}</h1>
            <p class="text-body-secondary mb-0">{{ $branchName }} &middot; <time datetime="{{ $todayIso }}">{{ $todayLabel }}</time></p>
        </div>
        <div class="d-flex flex-wrap gap-2">
            @if ($canCreateSale)
                <a class="btn btn-primary" href="{{ route('pharmacy.sales.create', ['product_type' => $productType]) }}">
                    <i class="fa-solid fa-plus me-2" aria-hidden="true"></i>New sale
                </a>
            @endif
            @if ($canCreatePurchase)
                <a class="btn btn-outline-primary" href="{{ route('pharmacy.purchases.create', ['product_type' => $productType]) }}">
                    <i class="fa-solid fa-cart-flatbed me-2" aria-hidden="true"></i>New purchase
                </a>
            @endif
            @if ($canViewProducts)
                <a class="btn btn-outline-secondary" href="{{ route('pharmacy.products.index', ['type' => $productType]) }}">Products</a>
            @endif
        </div>
    </div>

    <nav class="nav nav-pills gap-1 mb-3" aria-label="Pharmacy product type">
        <a @class(['nav-link', 'active' => $productType === 'medicine'])
            href="{{ route('pharmacy.dashboard', ['product_type' => 'medicine']) }}"
            @if ($productType === 'medicine') aria-current="page" @endif>
            <i class="fa-solid fa-pills me-2" aria-hidden="true"></i>Medicine
        </a>
        <a @class(['nav-link', 'active' => $productType === 'optic'])
            href="{{ route('pharmacy.dashboard', ['product_type' => 'optic']) }}"
            @if ($productType === 'optic') aria-current="page" @endif>
            <i class="fa-solid fa-glasses me-2" aria-hidden="true"></i>Optic
        </a>
    </nav>

    @if ($canViewSales || $canViewPurchases || $canViewReports)
        <section class="app-stat-grid" aria-label="{{ $productTypeLabel }} financial overview, amounts in BDT">
            @if ($canViewSales)
                <a class="app-stat-card text-decoration-none text-reset"
                    href="{{ route('pharmacy.sales.index', ['product_type' => $productType, 'from_date' => $todayIso, 'to_date' => $todayIso]) }}">
                    <div class="d-flex align-items-center justify-content-between gap-2 mb-3">
                        <span class="app-stat-label">Today's sales</span>
                        <span class="app-stat-icon app-tone-success"><i class="fa-solid fa-receipt" aria-hidden="true"></i></span>
                    </div>
                    <p class="app-stat-value fs-4 text-break">{{ moneyDecimal($salesTotal) }} <span class="fs-6 fw-normal">BDT</span></p>
                    <p class="app-stat-caption mb-0">{{ number_format($salesCount) }} invoices &middot; Invoice totals</p>
                </a>
            @endif
            @if ($canViewPurchases)
                <a class="app-stat-card text-decoration-none text-reset"
                    href="{{ route('pharmacy.purchases.index', ['product_type' => $productType, 'from_date' => $todayIso, 'to_date' => $todayIso]) }}">
                    <div class="d-flex align-items-center justify-content-between gap-2 mb-3">
                        <span class="app-stat-label">Today's purchases</span>
                        <span class="app-stat-icon app-tone-primary"><i class="fa-solid fa-truck-ramp-box" aria-hidden="true"></i></span>
                    </div>
                    <p class="app-stat-value fs-4 text-break">{{ moneyDecimal($purchaseTotal) }} <span class="fs-6 fw-normal">BDT</span></p>
                    <p class="app-stat-caption mb-0">{{ number_format($purchaseCount) }} invoices &middot; Invoice totals</p>
                </a>
            @endif
            @if ($canViewReports)
                <a class="app-stat-card text-decoration-none text-reset"
                    href="{{ route('pharmacy.reports.customer-dues', ['product_type' => $productType]) }}">
                    <div class="d-flex align-items-center justify-content-between gap-2 mb-3">
                        <span class="app-stat-label">Customer due</span>
                        <span class="app-stat-icon app-tone-warning"><i class="fa-solid fa-wallet" aria-hidden="true"></i></span>
                    </div>
                    <p class="app-stat-value fs-4 text-break">{{ moneyDecimal($customerDue) }} <span class="fs-6 fw-normal">BDT</span></p>
                    <p class="app-stat-caption mb-0">All outstanding customer invoices</p>
                </a>
                <a class="app-stat-card text-decoration-none text-reset"
                    href="{{ route('pharmacy.reports.supplier-dues', ['product_type' => $productType]) }}">
                    <div class="d-flex align-items-center justify-content-between gap-2 mb-3">
                        <span class="app-stat-label">Supplier due</span>
                        <span class="app-stat-icon app-tone-info"><i class="fa-solid fa-file-invoice-dollar" aria-hidden="true"></i></span>
                    </div>
                    <p class="app-stat-value fs-4 text-break">{{ moneyDecimal($supplierDue) }} <span class="fs-6 fw-normal">BDT</span></p>
                    <p class="app-stat-caption mb-0">All outstanding supplier invoices</p>
                </a>
            @endif
        </section>
    @endif

    @if ($canViewReports)
        <section class="app-card p-3 mb-3" aria-labelledby="pharmacy-stock-heading">
            <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
                <h2 class="app-section-title" id="pharmacy-stock-heading">Stock &amp; reports</h2>
                <div class="d-flex flex-wrap gap-2">
                    <a class="btn btn-outline-secondary btn-sm"
                        href="{{ route('pharmacy.reports.stock', ['product_type' => $productType]) }}">
                        <i class="fa-solid fa-boxes-stacked me-2" aria-hidden="true"></i>Stock report
                    </a>
                    <a class="btn btn-outline-secondary btn-sm"
                        href="{{ route('pharmacy.reports.stock', ['product_type' => $productType, 'stock_status' => 'low']) }}">Low stock</a>
                    <a class="btn btn-outline-secondary btn-sm"
                        href="{{ route('pharmacy.reports.daily', ['product_type' => $productType, 'from_date' => $todayIso, 'to_date' => $todayIso]) }}">Daily report</a>
                    @if ($expiryCount !== null)
                        <a class="btn btn-outline-warning btn-sm text-body"
                            href="{{ route('pharmacy.reports.expiry', ['product_type' => 'medicine', 'expiry_before' => $expiryBefore]) }}">
                            Expiry alert <span class="badge text-bg-warning ms-1">{{ number_format($expiryCount) }}</span>
                        </a>
                    @endif
                </div>
            </div>
            @if ($expiryCount !== null)
                <p class="small text-body-secondary mt-2 mb-0">Expiry alert includes expired batches and batches expiring within 30 days.</p>
            @endif
        </section>
    @endif

    <div class="row row-cols-1 row-cols-xl-2 g-3">
        @if ($canViewSales)
            <div class="col flex-grow-1">
                <section class="app-card overflow-hidden h-100" aria-labelledby="pharmacy-recent-sales-heading">
                    <div class="app-section-head">
                        <div>
                            <h2 class="app-section-title" id="pharmacy-recent-sales-heading">Recent sales</h2>
                            <p class="app-section-note">Latest five {{ strtolower($productTypeLabel) }} invoices</p>
                        </div>
                        <a class="btn btn-outline-secondary btn-sm" href="{{ route('pharmacy.sales.index', ['product_type' => $productType]) }}">View all</a>
                    </div>
                    <ul class="list-group list-group-flush mb-0">
                        @forelse ($recentSales as $sale)
                            <li class="list-group-item bg-transparent p-0">
                                <a class="app-quick-link flex-wrap align-items-start justify-content-between gap-2"
                                    href="{{ route('pharmacy.sales.show', ['sale' => $sale, 'product_type' => $productType]) }}">
                                    <span class="d-flex flex-column flex-grow-1 overflow-hidden">
                                        <span class="fw-semibold text-break">
                                            {{ $sale->number }}
                                            <time class="small fw-normal text-body-secondary" datetime="{{ $sale->entry_date->toDateString() }}">&middot; {{ $sale->entry_date->format('d M Y') }}</time>
                                        </span>
                                        <span class="small text-body-secondary text-break">{{ $customers[$sale->customer_id]['name'] ?? 'Walk-in customer' }}</span>
                                    </span>
                                    <span class="text-end text-break mw-100">
                                        <span class="d-block fw-semibold">{{ moneyDecimal($sale->total) }} BDT</span>
                                        <span class="small text-body-secondary">Due {{ moneyDecimal($sale->outstanding) }}</span>
                                    </span>
                                </a>
                            </li>
                        @empty
                            <li class="app-dashboard-empty py-4">
                                <i class="fa-solid fa-receipt" aria-hidden="true"></i>
                                <h3>No sales yet</h3>
                                <p>Saved {{ strtolower($productTypeLabel) }} sales will appear here.</p>
                            </li>
                        @endforelse
                    </ul>
                </section>
            </div>
        @endif
        @if ($canViewPurchases)
            <div class="col flex-grow-1">
                <section class="app-card overflow-hidden h-100" aria-labelledby="pharmacy-recent-purchases-heading">
                    <div class="app-section-head">
                        <div>
                            <h2 class="app-section-title" id="pharmacy-recent-purchases-heading">Recent purchases</h2>
                            <p class="app-section-note">Latest five {{ strtolower($productTypeLabel) }} invoices</p>
                        </div>
                        <a class="btn btn-outline-secondary btn-sm" href="{{ route('pharmacy.purchases.index', ['product_type' => $productType]) }}">View all</a>
                    </div>
                    <ul class="list-group list-group-flush mb-0">
                        @forelse ($recentPurchases as $purchase)
                            <li class="list-group-item bg-transparent p-0">
                                <a class="app-quick-link flex-wrap align-items-start justify-content-between gap-2"
                                    href="{{ route('pharmacy.purchases.show', ['purchase' => $purchase, 'product_type' => $productType]) }}">
                                    <span class="d-flex flex-column flex-grow-1 overflow-hidden">
                                        <span class="fw-semibold text-break">
                                            {{ $purchase->number }}
                                            <time class="small fw-normal text-body-secondary" datetime="{{ $purchase->entry_date->toDateString() }}">&middot; {{ $purchase->entry_date->format('d M Y') }}</time>
                                        </span>
                                        <span class="small text-body-secondary text-break">{{ $purchase->supplier?->name ?? 'Supplier unavailable' }}</span>
                                    </span>
                                    <span class="text-end text-break mw-100">
                                        <span class="d-block fw-semibold">{{ moneyDecimal($purchase->total) }} BDT</span>
                                        <span class="small text-body-secondary">Due {{ moneyDecimal($purchase->outstanding) }}</span>
                                    </span>
                                </a>
                            </li>
                        @empty
                            <li class="app-dashboard-empty py-4">
                                <i class="fa-solid fa-truck-ramp-box" aria-hidden="true"></i>
                                <h3>No purchases yet</h3>
                                <p>Saved {{ strtolower($productTypeLabel) }} purchases will appear here.</p>
                            </li>
                        @endforelse
                    </ul>
                </section>
            </div>
        @endif
    </div>

    @if (! $canViewSales && ! $canViewPurchases && ! $canViewReports)
        <section class="app-card app-dashboard-empty">
            <i class="fa-solid fa-lock" aria-hidden="true"></i>
            <h2 class="h6">No dashboard figures available</h2>
            <p>Your permissions determine which sales, purchases and reports appear here.</p>
        </section>
    @endif
@endsection
