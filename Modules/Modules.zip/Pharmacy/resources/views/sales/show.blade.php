@extends('core::layouts.app')

@section('title', ucfirst($entry->product_type).' Sales Invoice')

@section('content')
    <div class="app-print-hidden">
        @include('core::partials.heading', ['title' => ucfirst($entry->product_type).' '.$entry->number])
        <div class="d-flex flex-wrap gap-2 mb-3">
            <a class="btn btn-outline-secondary btn-sm" href="{{ route($routePrefix.'.index', ['product_type' => $entry->product_type]) }}">
                <i class="fa-solid fa-arrow-left me-2" aria-hidden="true"></i>Back
            </a>
            <button class="btn btn-primary btn-sm" type="button" data-print>
                <i class="fa-solid fa-print me-2" aria-hidden="true"></i>Print
            </button>
            @can('update', $entry)
                <a class="btn btn-outline-primary btn-sm" href="{{ route($routePrefix.'.edit', [$resourceParameter => $entry, 'product_type' => $entry->product_type]) }}">
                    <i class="fa-solid fa-pen-to-square me-2" aria-hidden="true"></i>Edit
                </a>
            @endcan
            @can('delete', $entry)
                <form action="{{ route($routePrefix.'.destroy', [$resourceParameter => $entry, 'product_type' => $entry->product_type]) }}" method="POST" data-confirm="Delete this sales invoice and reverse its stock and amounts?">
                    @csrf
                    @method('DELETE')
                    <button class="btn btn-outline-danger btn-sm" type="submit"><i class="fa-solid fa-trash-can me-2" aria-hidden="true"></i>Delete</button>
                </form>
            @endcan
            @if ($canVoid)
                <form action="{{ route($routePrefix.'.void', [$resourceParameter => $entry, 'product_type' => $entry->product_type]) }}" method="POST" data-confirm="Void this sales invoice and reverse its stock and amounts?">
                    @csrf
                    <button class="btn btn-outline-danger btn-sm" type="submit">Void</button>
                </form>
            @endif
        </div>
    </div>

    @php
        $invoiceTitle = 'Sales Invoice';
        $outstandingMinor = $entry->voided_at ? 0 : $entry->outstandingMinor();
        $invoiceStatus = $entry->voided_at ? 'VOID' : ($outstandingMinor > 0 ? 'DUE' : 'PAID');
        $invoicePaper = in_array($invoicePaper ?? null, ['a4', 'a5', 'pos'], true) ? $invoicePaper : 'a4';
        $salePosWidth = is_string($salePosWidth ?? null) && preg_match('/\A\d{1,3}(?:\.\d{1,2})?\z/', $salePosWidth)
            && (float) $salePosWidth >= 20 && (float) $salePosWidth <= 300 ? $salePosWidth : '80';
        $salePosWidth = rtrim(rtrim(number_format((float) $salePosWidth, 2, '.', ''), '0'), '.');
    @endphp

    <style>
        @media print {
            @page pharmacy-sale {
                size: {{ match ($invoicePaper) { 'a5' => 'A5', 'pos' => $salePosWidth.'mm 297mm', default => 'A4' } }};
                margin: {{ $invoicePaper === 'pos' ? '2mm 0 0' : '10mm' }};
            }

            .app-shell,
            .app-page,
            .app-content,
            .app-sale-invoice {
                page: pharmacy-sale;
            }

            @if ($invoicePaper === 'pos')
                .app-shell,
                .app-page,
                .app-content {
                    width: 100%;
                    max-width: none;
                    min-height: 0;
                    margin: 0 !important;
                    padding: 0 !important;
                    overflow: visible;
                }
            @endif
        }
    </style>

    <article class="app-card app-invoice-document app-clinical-invoice app-pharmacy-invoice app-sale-invoice app-sale-invoice-{{ $invoicePaper }}" @if ($invoicePaper === 'pos') style="--sale-pos-width: {{ $salePosWidth }}mm" @endif aria-labelledby="pharmacy-invoice-title">
        @include('pharmacy::entries.partials.invoice-header')

        <div class="app-pharmacy-invoice-parties">
            <div>
                <h2 class="app-clinical-invoice-section-title">Customer</h2>
                <p class="fw-semibold mb-1">{{ $customer['name'] ?? '—' }}</p>
                <p class="mb-1">Patient ID: {{ $customer['patient_id'] ?? '—' }}</p>
                @if ($customer['mobile_no'] ?? '')
                    <p class="mb-1">Contact: {{ $customer['mobile_no'] }}</p>
                @endif
                @if ($customer['address'] ?? '')
                    <p class="app-pharmacy-invoice-note mb-0">{{ $customer['address'] }}</p>
                @endif
            </div>
            <div>
                @include('pharmacy::entries.partials.invoice-meta')
                @include('pharmacy::entries.partials.invoice-payment-meta')
                <dl class="app-clinical-invoice-meta mb-0">
                    <div><dt>Stock method</dt><dd>{{ strtoupper($entry->stock_method) }}</dd></div>
                </dl>
            </div>
        </div>

        @include('pharmacy::entries.partials.invoice-financial-items', ['showVat' => $entry->vat > 0])

        <div class="app-pharmacy-invoice-summary">
            <div>
                @if ($entry->notes)
                    <h2 class="app-clinical-invoice-section-title">Notes</h2>
                    <p class="app-pharmacy-invoice-note">{{ $entry->notes }}</p>
                @endif
            </div>
            <div class="app-clinical-invoice-totals">
                <dl class="mb-0">
                    <div>
                        <dt>Subtotal</dt>
                        <dd>{{ moneyDecimal($entry->subtotal) }}</dd>
                    </div>
                    <div>
                        <dt>Total discounts</dt>
                        <dd>{{ moneyDecimal($entry->discount) }}</dd>
                    </div>
                    @if ($entry->vat > 0)
                        <div>
                            <dt>VAT {{ $entry->vat_percent }}% ({{ $entry->vat_mode === 'inclusive' ? 'included' : 'added' }})</dt>
                            <dd>{{ moneyDecimal($entry->vat) }}</dd>
                        </div>
                    @endif
                    @include('pharmacy::entries.partials.invoice-totals')
                </dl>
            </div>
        </div>

        @include('pharmacy::entries.partials.invoice-footer')
    </article>
@endsection
