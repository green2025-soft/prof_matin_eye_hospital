<?php

namespace Modules\Pharmacy\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Modules\Core\Services\AccessManager;
use Symfony\Component\HttpFoundation\Response;

class EnsurePharmacyPermission
{
    public function __construct(private AccessManager $access) {}

    public function handle(Request $request, Closure $next): Response
    {
        $permissions = $request->attributes->get('navigation_permissions');

        // Route groups and page controls reuse the same role-and-plan capabilities.
        if ($permissions === null) {
            $subscription = $request->attributes->get('application_subscription');
            $permissions = $this->access->navigationPermissions($request->user('web'), $subscription?->plan);
            $request->attributes->set('navigation_permissions', $permissions);
        }

        $routeName = $request->route()->getName();
        $requiredPermissions = array_merge([
            'pharmacy.view',
            config('permissions.tenant_routes')[$routeName] ?? '',
        ], config('permissions.tenant_route_requirements', [])[$routeName] ?? []);
        $alternativePermissions = config('permissions.tenant_route_alternatives', [])[$routeName] ?? [];

        $grantedPermissions = array_keys($permissions);
        $missingPermissions = array_diff($requiredPermissions, $grantedPermissions);
        $hasAlternative = $alternativePermissions === []
            || array_intersect($alternativePermissions, $grantedPermissions) !== [];

        abort_unless(
            $missingPermissions === [] && $hasAlternative,
            403,
            'Your account or plan does not include this Pharmacy action.',
        );

        return $next($request);
    }
}
